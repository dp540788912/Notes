# -*-coding:utf-8-*-

import json
import os
import datetime
import tornado.ioloop
import tornado.web
import tornado.httpclient

from tornado import gen
from anytree import AnyNode, RenderTree
from anytree.exporter import DictExporter
from db import session_context as mysql_sc
from models import *
from config import config
from utils import save_md5_file, check_redis_session


class BaseHandler(tornado.web.RequestHandler):

    def initialize(self, *args, **kwargs):
        self.model = None
        self.fields = {}
        self.no_login = []

    def json_response(self, data):
        self.write(json.dumps(data))

    def get_payload(self):
        if self.request.headers['content-type'].lower().startswith("application/json"):
            return json.loads(str(self.request.body, 'utf-8'))
        return {}

    def prepare(self, *args, **kwargs):
        if hasattr(self, 'no_login') and self.request.method.lower() in self.no_login:
            self.current_user = {}
            return
        sessionid = self.get_cookie('sessionid')
        if not sessionid:
            self.json_response({
                'code': 401,
                'error': 'Sessionid not found.'
            })
            self.finish()
            return
        cookies = {
            'sessionid': sessionid,
        }
        res = check_redis_session(config.redis, sessionid)
        if not res:
            self.json_response({
                'code': 401,
                'error': 'User not login.',
            })
            self.finish()
            return
        self.current_user = res

    def get(self, *args, **kwargs):
        self.json_response({
            'code': 404,
            'error': 'Method not found.',
        })

    def post(self, *args, **kwargs):
        self.json_response({
            'code': 404,
            'error': 'Method not found.',
        })

    def put(self, *args, **kwargs):
        self.json_response({
            'code': 404,
            'error': 'Method not found.',
        })

    def delete(self, *args, **kwargs):
        self.json_response({
            'code': 404,
            'error': 'Method not found.',
        })


class ArticlesListHandler(BaseHandler):

    def post(self, *args, **kwargs):
        payload = self.get_payload()
        if 'title' not in payload or 'category' not in payload:
            self.json_response({
                'code': 10002,
                'error': '请求参数错误',
            })
            return
        userid = self.current_user['id']
        author = self.current_user['username']
        title = payload['title']
        category = payload['category']
        if category == 'notice':
            if not self.current_user['is_superuser']:
                self.json_response({
                    'code': 10010,
                    'error': '非管理员不能发布公告',
                })
                return
        model = {
            'userid': userid,
            'author': author,
            'title': title,
            'category': category,
        }
        if 'content' in payload:
            content = payload['content']
            model['content'] = content
        if 'attachment' in payload:
            attachment = payload['attachment']
            model['attachment'] = attachment
        if 'brief' in payload:
            model['brief'] = payload['brief']
        if 'attachments' in payload:
            model['attachments'] = payload['attachments']
        with mysql_sc() as sc:
            article = Articles(**model)
            sc.add(article)
            sc.commit()
            tags = payload.get('tags', [])
            for t in tags:
                tag = sc.query(Tags).filter(Tags.name == t).first()
                if not tag:
                    tag = Tags(name=t)
                    sc.add(tag)
                    sc.commit()
                aat = ArticlesAndTags(article_id=article.id, tag_id=tag.id)
                sc.add(aat)
                sc.commit()
            data = article.to_dict()
            self.json_response({
                'code': 0,
                'data': data,
            })

    def get(self, *args, **kwargs):
        userid = self.current_user['id']
        page = int(self.get_argument('page', 0))
        size = int(self.get_argument('size', 500))
        category = self.get_argument('category', '')
        tag = self.get_argument('tag', '')
        with mysql_sc() as sc:
            articles = sc.query(Articles).filter()
            if category:
                if category == 'article':
                    articles = articles.filter(
                        ~Articles.category.in_(['notice', 'feedback']),
                    )
                else:
                    articles = articles.filter(
                        Articles.category == category,
                    )
            if tag:
                aat = sc.query(ArticlesAndTags).join(
                    Tags, Tags.id == ArticlesAndTags.tag_id,
                ).filter(
                    Tags.name == tag,
                )
                articles = articles.filter(
                    Articles.id.in_([_o.article_id for _o in aat]),
                )
            articles = articles.order_by(Articles.created_time.desc()).offset(page * size).limit(size)
            data = []
            for article in articles:
                d = article.to_brief()
                data.append(d)
            self.json_response({
                'code': 0,
                'data': data,
            })


class ArticleDetailHandler(BaseHandler):

    def get(self, *args, **kwargs):
        article_id = kwargs['id']
        with mysql_sc() as sc:
            model = {
                'article_id': article_id,
                'userid': self.current_user['id'],
            }
            sc.add(ArticleAccessments(**model))
            sc.commit()
            article = sc.query(Articles).filter(
                Articles.id == article_id,
            ).first()
            if not article:
                self.json_response({
                    'code': 1005,
                    'data': '',
                })
                return
            data = article.to_dict()
            self.json_response({
                'code': 0,
                'data': data,
            })

    def put(self, *args, **kwargs):
        article_id = kwargs['id']
        payload = self.get_payload()
        userid = self.current_user['id']
        author = self.current_user['username']
        with mysql_sc() as sc:
            article = sc.query(Articles).filter(
                Articles.id == article_id,
            ).first()
            if not article:
                self.json_response({
                    'code': 1005,
                    'data': '',
                })
                return
            if article.category == 'notice':
                if not self.current_user['is_superuser']:
                    self.json_response({
                        'code': 10010,
                        'error': '非管理员不能编辑公告',
                    })
                    return
            if article.userid != userid:
                self.json_response({
                    'code': 10010,
                    'error': '非作者不能编辑',
                })
                return
            if 'title' in payload:
                article.title = payload['title']
            if 'category' in payload:
                article.category = payload['category']
            if 'content' in payload:
                article.content = payload['content']
            if 'attachment' in payload:
                article.attachment = payload['attachment']
            if 'brief' in payload:
                article.brief = payload['brief']
            if 'attachments' in payload:
                article.attachments = payload['attachments']
            if 'tags' in payload:
                tags = payload['tags']
                sc.query(ArticlesAndTags).filter(
                    ArticlesAndTags.article_id == article_id,
                ).delete()
                for t in tags:
                    tag = sc.query(Tags).filter(Tags.name == t).first()
                    if not tag:
                        tag = Tags(name=t)
                        sc.add(tag)
                        sc.commit()
                    aat = ArticlesAndTags(article_id=article.id, tag_id=tag.id)
                    sc.add(aat)
            sc.commit()

            data = article.to_dict()
            self.json_response({
                'code': 0,
                'data': data,
            })

    def delete(self, *args, **kwargs):
        article_id = kwargs['id']
        with mysql_sc() as sc:
            articles = sc.query(Articles).filter(Articles.id == article_id)
            article = articles.first()
            if not article:
                self.json_response({
                    'code': 1005,
                    'error': '',
                })
                return
            if article.category == 'notice':
                if not self.current_user['is_superuser']:
                    self.json_response({
                        'code': 10010,
                        'error': '非管理员不能删除公告',
                    })
                    return
            if article.userid != self.current_user['id'] and not self.current_user['is_superuser']:
                self.json_response({
                    'code': 10010,
                    'error': '非管理员和作者不能删除',
                })
                return
            articles.delete()
            sc.query(ArticlesAndTags).filter(ArticlesAndTags.article_id== article_id).delete()
            sc.query(ArticleAccessments).filter(ArticleAccessments.article_id == article_id).delete()
            sc.query(ArticleLikes).filter(ArticleLikes.article_id == article_id).delete()
            comments = sc.query(Comments).filter(Comments.article_id == article_id)
            sc.query(CommentLikes).filter(CommentLikes.comment_id.in_([c.id for c in comments])).delete(synchronize_session=False)
            comments.delete()
            self.json_response({
                'code': 0,
            })


class ArticleLikeHandler(BaseHandler):

    def post(self, *args, **kwargs):
        article_id = kwargs['id']
        userid = self.current_user['id']
        model = {
            'article_id': article_id,
            'userid': userid,
        }
        with mysql_sc() as sc:
            if sc.query(ArticleLikes).filter(
                ArticleLikes.article_id == article_id,
                ArticleLikes.userid == userid,
            ).first():
                self.json_response({
                    'code': 10006,
                    'error': '不能重复点赞',
                })
                return
            sc.add(ArticleLikes(**model))
        self.json_response({
            'code': 0,
        })

    def get(self, *args, **kwargs):
        article_id = kwargs['id']
        userid = self.current_user['id']
        with mysql_sc() as sc:
            like = sc.query(ArticleLikes).filter(
                ArticleLikes.article_id == article_id,
                ArticleLikes.userid == userid,
            )
            if like.first():
                self.json_response({
                    'code': 0,
                    'data': True,
                })
            else:
                self.json_response({
                    'code': 0,
                    'data': False,
                })

    def delete(self, *args, **kwargs):
        article_id = kwargs['id']
        userid = self.current_user['id']
        with mysql_sc() as sc:
            like = sc.query(ArticleLikes).filter(
                ArticleLikes.article_id == article_id,
                ArticleLikes.userid == userid,
            )
            if not like.first():
                self.json_response({
                    'code': 10007,
                    'error': '不能重复取消赞',
                })
                return
            like.delete()
        self.json_response({
            'code': 0,
        })


class CommentsListHandler(BaseHandler):

    def post(self, *args, **kwargs):
        payload = self.get_payload()
        commentator = self.current_user['username']
        userid = self.current_user['id']
        if 'article_id' not in payload:
            self.json_response({
                'code': 10002,
                'error': '请求参数错误',
            })
            return
        article_id = payload['article_id']
        model = {
            'article_id': article_id,
            'commentator': commentator,
            'userid': userid,
        }
        if 'reply_id' in payload:
            if 'top_comment_id' not in payload:
                self.json_response({
                    'code': 10002,
                    'error': '请求参数错误',
                })
                return
            model['top_comment_id'] = payload['top_comment_id']
            model['reply_id'] = payload['reply_id']
        if 'content' in payload:
            model['content'] = payload['content']
        if 'attachment' in payload:
            model['attachment'] = payload['attachment']
        with mysql_sc() as sc:
            comment = Comments(**model)
            sc.add(comment)
            sc.commit()
            self.json_response({
                'code': 0,
                'data': comment.to_dict(),
            })

    def get(self, *args, **kwargs):
        """
            'comments': {
                'total': 10,
                'data': [
                    {
                        'comment': {
                            'commentator': 'user1',
                            'content': 'xxx',
                            'attachment': 'xxx',
                            'created_time': '',
                            'updated_time': '',
                            },
                        },
                        'children': [
                            {
                                ...
                            },
                        ]
                    }
                ]
            }
        """
        article_id = self.get_argument('article_id', None)
        page = int(self.get_argument('page', 0))
        size = int(self.get_argument('size', 500))
        if article_id is None:
            self.json_response({
                'code': 10002,
                'error': '请求参数错误',
            })
            return
        data = {
            'total': 0,
            'data': []
        }
        with mysql_sc() as sc:
            article_comments = sc.query(Comments).filter(
                Comments.article_id == article_id,
            )

            top_comments = article_comments.filter(
                Comments.reply_id == -1
            )
            total_num = top_comments.count()
            data['total'] = total_num
            top_comments = top_comments.offset(page * size).limit(size)
            for t in top_comments:
                comment_data = t.to_dict()
                comment_data['replies'] = []
                comments = article_comments.filter(
                    Comments.top_comment_id == t.id,
                )
                for c in comments:
                    comment_data['replies'].append(c.to_dict())
                data['data'].append(comment_data)

                #root = AnyNode(comment=t.to_dict())
                #nodes = {t.id: root}
                #comments = article_comments.filter(
                #    Comments.top_comment_id == t.id,
                #).order_by(Comments.id.asc())
                #for c in comments:
                #    comment_id = c.id
                #    reply_id = c.reply_id
                #    node = AnyNode(parent=nodes[reply_id], comment=c.to_dict())
                #    nodes[comment_id] = node

                #data['data'].append(DictExporter().export(root))

        self.json_response({
            'code': 0,
            'data': data,
        })


class CommentDetailHandler(BaseHandler):

    def get(self, *args, **kwargs):
        comment_id = kwargs['id']
        with mysql_sc() as sc:
            comment = sc.query(Comments).filter(Comments.id == comment_id).first()
            if not comment:
                self.json_response({
                    'code': 1005,
                    'error': '',
                })
                return
            self.json_response({
                'code': 0,
                'data': comment.to_dict(),
            })

    def put(self, *args, **kwargs):
        comment_id = kwargs['id']
        payload = self.get_payload()
        with mysql_sc() as sc:
            comment = sc.query(Comments).filter(Comments.id == comment_id).first()
            if not comment:
                self.json_response({
                    'code': 1005,
                    'error': '',
                })
                return
            if 'content' in payload:
                comment.content = payload['content']
            if 'attachment' in payload:
                comment.attachment = payload['attachment']
            sc.commit()
            self.json_response({
                'code': 0,
                'data': comment.to_dict(),
            })

    def delete(self, *args, **kwargs):
        comment_id = kwargs['id']
        with mysql_sc() as sc:
            if sc.query(Comments).filter(Comments.reply_id == comment_id).all():
                self.json_response({
                    'code': 10009,
                    'error': '该评论已有人回复，不可删除',
                })
                return
            sc.query(CommentLikes).filter(CommentLikes.comment_id == comment_id).delete()
            sc.query(Comments).filter(Comments.id == comment_id).delete()
            self.json_response({
                'code': 0,
            })


class CommentLikeHandler(BaseHandler):

    def post(self, *args, **kwargs):
        comment_id = kwargs['id']
        userid = self.current_user['id']
        model = {
            'comment_id': comment_id,
            'userid': userid,
        }
        with mysql_sc() as sc:
            if sc.query(CommentLikes).filter(
                CommentLikes.comment_id == comment_id,
                CommentLikes.userid == userid,
            ).first():
                self.json_response({
                    'code': 10006,
                    'error': '不能重复点赞',
                })
                return
            sc.add(CommentLikes(**model))
        self.json_response({
            'code': 0,
        })

    def get(self, *args, **kwargs):
        comment_id = kwargs['id']
        userid = self.current_user['id']
        with mysql_sc() as sc:
            like = sc.query(CommentLikes).filter(
                CommentLikes.comment_id == comment_id,
                CommentLikes.userid == userid,
            )
            if like.first():
                self.json_response({
                    'code': 0,
                    'data': True,
                })
            else:
                self.json_response({
                    'code': 0,
                    'data': False,
                })

    def delete(self, *args, **kwargs):
        comment_id = kwargs['id']
        userid = self.current_user['id']
        with mysql_sc() as sc:
            like = sc.query(CommentLikes).filter(
                CommentLikes.comment_id == comment_id,
                CommentLikes.userid == userid,
            )
            if not like.first():
                self.json_response({
                    'code': 10007,
                    'error': '不能重复取消赞',
                })
                return
            like.delete()
        self.json_response({
            'code': 0,
        })


class UploadMediaListHandler(BaseHandler):

    def post(self, *args, **kwargs):
        userid = self.current_user['id']
        username = self.current_user['username']
        attachment = self.request.files['attachment'][0]
        file_name = save_md5_file(os.path.join(config.media['basepath'], 'media/share', username), attachment)
        if not file_name:
            self.json_response({
                'code': 10003,
                'error': '上传文件失败.',
            })
            return
        model = {
            'path': os.path.join('share', username, file_name),
            'userid': userid,
        }
        with mysql_sc() as sc:
            sc.add(Medias(**model))
        self.json_response({
            'code': 0,
            'data': os.path.join('/media/share', username, file_name),
        })


class NotebooksListHandler(BaseHandler):

    def get(self, *args, **kwargs):
        notebooks = []
        userid = self.current_user['id']
        username = self.current_user['username']
        base_path = os.path.join(config.notebooks['basepath'], '%s_%s' % (userid, username))
        for p, _, fs in os.walk(base_path):
            for f in fs:
                notebooks.append(os.path.join(p, f).replace(base_path, ''))
        self.json_response({
            'code': 0,
            'data': notebooks,
        })


class NotebooksDetailHandler(BaseHandler):

    def get(self, *args, **kwargs):
        data = None
        notebook = self.get_argument('notebook', None)
        if notebook is None:
            self.json_response({
                'code': 10002,
                'error': '请求参数错误',
            })
            return
        userid = self.current_user['id']
        username = self.current_user['username']
        fpath = os.path.join(config.notebooks['basepath'], '%s_%s' % (userid, username), notebook)
        if not os.path.exists(fpath):
            self.json_response({
                'code': 10008,
                'error': 'jupyter-notebook文件不存在',
            })
            return
        with open(fpath, 'r') as f:
            data = f.read()
        self.json_response({
            'code': 0,
            'data': data,
        })


class FeedBacksListHandler(BaseHandler):

    def post(self, *args, **kwargs):
        payload = self.get_payload()
        if 'content' not in payload:
            self.json_response({
                'code': 10002,
                'error': '请求参数错误',
            })
            return
        with mysql_sc() as sc:
            userid = self.current_user['id']
            author = self.current_user['username']
            category = 'feedback'
            title = 'feedback_%s_%s' % (userid, datetime.datetime.now().strftime('%Y%m%d'))
            feedback_model = {
                'userid': userid,
                'author': author,
                'title': title,
                'category': category,
            }
            if 'content' in payload:
                feedback_model['content'] = payload['content']
            article = Articles(**feedback_model)
            sc.add(article)
            sc.commit()

            feature_model = {
                'feedback_id': article.id,
                'userid': userid,
            }
            if 'contact' in payload:
                feature_model['contact'] = payload['contact']
            feature = FeedBackFeature(**feature_model)
            sc.add(feature)
            sc.commit()

            self.json_response({
                'code': 0,
                'data': article.to_feedback_dict(),
            })

    def get(self, *args, **kwargs):
        userid = self.current_user['id']
        page = int(self.get_argument('page', 0))
        size = int(self.get_argument('size', 500))
        replyed = int(self.get_argument('replyed', 2))
        category = 'feedback'
        with mysql_sc() as sc:
            articles = sc.query(Articles).filter(
                Articles.category == category,
            )
            if not self.current_user['is_superuser']:
                articles = articles.filter(
                    Articles.userid == userid,
                )
            articles = articles.order_by(Articles.created_time.desc()).offset(page * size).limit(size)
            data = []
            for article in articles:
                if replyed == 0:
                    if sc.query(Comments).filter(
                        Comments.article_id == article.id
                    ).all():
                        continue
                elif replyed == 1:
                    if not sc.query(Comments).filter(
                        Comments.article_id == article.id
                    ).all():
                        continue
                d = article.to_feedback_dict()
                data.append(d)
            self.json_response({
                'code': 0,
                'data': data,
            })


class FeedBacksDetailHandler(BaseHandler):

    def delete(self, *args, **kwargs):
        article_id = kwargs['id']
        with mysql_sc() as sc:
            articles = sc.query(Articles).filter(Articles.id == article_id)
            article = articles.first()
            if not article:
                self.json_response({
                    'code': 1005,
                    'error': '',
                })
                return
            if article.userid != self.current_user['id'] and not self.current_user['is_superuser']:
                self.json_response({
                    'code': 10010,
                    'error': '非管理员和作者不能删除',
                })
                return
            articles.delete()
            sc.query(ArticlesAndTags).filter(ArticlesAndTags.article_id== article_id).delete()
            sc.query(ArticleAccessments).filter(ArticleAccessments.article_id == article_id).delete()
            sc.query(ArticleLikes).filter(ArticleLikes.article_id == article_id).delete()
            comments = sc.query(Comments).filter(Comments.article_id == article_id)
            sc.query(CommentLikes).filter(CommentLikes.comment_id.in_([c.id for c in comments])).delete(synchronize_session=False)
            comments.delete()
            self.json_response({
                'code': 0,
            })

    def get(self, *args, **kwargs):
        article_id = kwargs['id']
        with mysql_sc() as sc:
            article = sc.query(Articles).filter(
                Articles.id == article_id,
            ).first()
            if not article:
                self.json_response({
                    'code': 1005,
                    'data': '',
                })
                return
            data = article.to_feedback_dict()
            self.json_response({
                'code': 0,
                'data': data,
            })

    def put(self, *args, **kwargs):
        article_id = kwargs['id']
        payload = self.get_payload()
        userid = self.current_user['id']
        author = self.current_user['username']
        with mysql_sc() as sc:
            article = sc.query(Articles).filter(
                Articles.id == article_id,
            ).first()
            if not article:
                self.json_response({
                    'code': 1005,
                    'data': '',
                })
                return
            if article.userid != userid:
                self.json_response({
                    'code': 10010,
                    'error': '非作者不能编辑',
                })
                return
            if sc.query(Comments).filter(
                Comments.article_id == article_id,
            ).all():
                self.json_response({
                    'code': 10011,
                    'error': '已回复的建议不可修改，可删除',
                })
                return
            if 'content' in payload:
                article.content = payload['content']

            feature = sc.query(FeedBackFeature).filter(
                FeedBackFeature.feedback_id == article_id,
            ).first()
            if not feature:
                self.json_response({
                    'code': 1005,
                    'data': '',
                })
            if 'contact' in payload:
                feature.contact = payload['contact']
            sc.commit()

            data = article.to_feedback_dict()
            self.json_response({
                'code': 0,
                'data': data,
            })


class FeedBackReplyListHandler(BaseHandler):

    def post(self, *args, **kwargs):
        payload = self.get_payload()
        commentator = self.current_user['username']
        userid = self.current_user['id']
        if 'feedback_id' not in payload:
            self.json_response({
                'code': 10002,
                'error': '请求参数错误',
            })
            return
        article_id = payload['feedback_id']
        model = {
            'article_id': article_id,
            'commentator': commentator,
            'userid': userid,
        }
        if 'content' in payload:
            model['content'] = payload['content']
        with mysql_sc() as sc:
            article = sc.query(Articles).filter(
                Articles.id == article_id,
            ).first()
            if not article:
                self.json_response({
                    'code': 1005,
                    'error': '',
                })
                return
            comment = Comments(**model)
            sc.add(comment)
            sc.commit()
            data = article.to_feedback_dict()
            self.json_response({
                'code': 0,
                'data': data,
            })


class FeedBackReplyDetailHandler(BaseHandler):

    def get(self, *args, **kwargs):
        comment_id = kwargs['id']
        with mysql_sc() as sc:
            comment = sc.query(Comments).filter(Comments.id == comment_id).first()
            if not comment:
                self.json_response({
                    'code': 1005,
                    'error': '',
                })
                return
            self.json_response({
                'code': 0,
                'data': comment.to_dict(),
            })

    def put(self, *args, **kwargs):
        comment_id = kwargs['id']
        payload = self.get_payload()
        with mysql_sc() as sc:
            comment = sc.query(Comments).filter(Comments.id == comment_id).first()
            if not comment:
                self.json_response({
                    'code': 1005,
                    'error': '',
                })
                return
            if not self.current_user['is_superuser']:
                self.json_response({
                    'code': 10010,
                    'error': '非管理员不能编辑',
                })
                return
            if 'content' in payload:
                comment.content = payload['content']
            sc.commit()
            self.json_response({
                'code': 0,
                'data': comment.to_dict(),
            })

    def delete(self, *args, **kwargs):
        comment_id = kwargs['id']
        with mysql_sc() as sc:
            comments = sc.query(Comments).filter(Comments.id == comment_id)
            comment = comments.first()
            if not comment:
                self.json_response({
                    'code': 1005,
                    'error': '',
                })
                return
            if not self.current_user['is_superuser']:
                self.json_response({
                    'code': 10010,
                    'error': '非管理员不能删除',
                })
                return
            comments.delete()
            self.json_response({
                'code': 0,
            })


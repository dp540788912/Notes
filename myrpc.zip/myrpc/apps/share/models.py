# -*-coding:utf-8-*-

from sqlalchemy.sql import func
from sqlalchemy import Column
from sqlalchemy.dialects.mysql import INTEGER, VARCHAR, LONGTEXT, DATETIME, JSON

from db import ModelBase
from db import session_context as mysql_sc


class Tags(ModelBase):

    __tablename__ = 'tags'

    id = Column(INTEGER, primary_key=True)
    name = Column(VARCHAR(255), unique=True, nullable=False)
    created_time = Column(DATETIME, server_default=func.now())
    updated_time = Column(DATETIME, server_default=func.now(), onupdate=func.now())


class ArticlesAndTags(ModelBase):

    __tablename__ = 'articles_and_tags'

    id = Column(INTEGER, primary_key=True)
    article_id = Column(INTEGER, nullable=False) # refer to articles id
    tag_id = Column(INTEGER, nullable=False) # refer to tags id
    created_time = Column(DATETIME, server_default=func.now())
    updated_time = Column(DATETIME, server_default=func.now(), onupdate=func.now())


class Articles(ModelBase):

    __tablename__ = 'articles'

    id = Column(INTEGER, primary_key=True)
    author = Column(VARCHAR(63), nullable=False)
    title = Column(VARCHAR(255), nullable=False)
    category = Column(VARCHAR(255), nullable=False)
    content = Column(LONGTEXT, nullable=True)
    attachment = Column(LONGTEXT, nullable=True) # notebook data
    brief = Column(VARCHAR(155), nullable=True)
    userid = Column(INTEGER, nullable=False)
    created_time = Column(DATETIME, server_default=func.now())
    updated_time = Column(DATETIME, server_default=func.now(), onupdate=func.now())
    attachments = Column(JSON, nullable=True)

    def get_tags(self):
        with mysql_sc() as sc:
            tags = sc.query(Tags).join(
                ArticlesAndTags, ArticlesAndTags.tag_id == Tags.id,
            ).filter(
                ArticlesAndTags.article_id == self.id,
            )
            return [t.name for t in tags]

    def get_accessment_num(self):
        with mysql_sc() as sc:
            return sc.query(ArticleAccessments).filter(
                ArticleAccessments.article_id == self.id,
            ).count()

    def get_likes_num(self):
        with mysql_sc() as sc:
            return sc.query(ArticleLikes).filter(
                ArticleLikes.article_id == self.id,
            ).count()

    def get_comments_num(self):
        with mysql_sc() as sc:
            return sc.query(Articles).filter(
                Comments.article_id == self.id,
            ).count()

    def get_brief(self):
        if self.brief:
            return self.brief
        elif self.content:
            return self.content[:150]
        elif self.attachment:
            return self.attachment[:150]
        else:
            return ''

    def get_feedback_contact(self):
        with mysql_sc() as sc:
            o = sc.query(FeedBackFeature).filter(
                FeedBackFeature.feedback_id == self.id,
            ).first()
            if o:
                return o.contact or ''
            else:
                return ''

    def get_feedback_reply(self):
        with mysql_sc() as sc:
            comments = sc.query(Comments).filter(
                Comments.article_id == self.id,
            )
            return [{
                        'id': c.id,
                        'content': c.content,
                        'created_time': c.created_time.strftime('%Y-%m-%d %H:%M:%S'),
                        'updated_time': c.updated_time.strftime('%Y-%m-%d %H:%M:%S'),
                    }
                for c in comments if c.content]

    def to_dict(self):
        return {
            'id': self.id,
            'author': self.author,
            'title': self.title,
            'category': self.category,
            'content': self.content or '',
            'attachment': self.attachment or '',
            'brief': self.get_brief(),
            'tags': self.get_tags(),
            'views': self.get_accessment_num(),
            'likes': self.get_likes_num(),
            'comments': self.get_comments_num(),
            'userid': self.userid,
            'created_time': self.created_time.strftime('%Y-%m-%d %H:%M:%S'),
            'updated_time': self.updated_time.strftime('%Y-%m-%d %H:%M:%S'),
            'attachments': self.attachments or [],
        }

    def to_brief(self):
        return {
            'id': self.id,
            'author': self.author,
            'title': self.title,
            'category': self.category,
            'brief': self.get_brief(),
            'tags': self.get_tags(),
            'views': self.get_accessment_num(),
            'likes': self.get_likes_num(),
            'comments': self.get_comments_num(),
            'userid': self.userid,
            'created_time': self.created_time.strftime('%Y-%m-%d %H:%M:%S'),
            'updated_time': self.updated_time.strftime('%Y-%m-%d %H:%M:%S'),
            'attachments': self.attachments or [],
        }

    def to_feedback_dict(self):
        return {
            'id': self.id,
            'author': self.author,
            'content': self.content or '',
            'attachment': self.attachment or '',
            'contact': self.get_feedback_contact(),
            'userid': self.userid,
            'created_time': self.created_time.strftime('%Y-%m-%d %H:%M:%S'),
            'updated_time': self.updated_time.strftime('%Y-%m-%d %H:%M:%S'),
            'reply': self.get_feedback_reply(),
        }


class ArticleAccessments(ModelBase):

    __tablename__ = 'article_accessments'

    id = Column(INTEGER, primary_key=True)
    article_id = Column(INTEGER, nullable=False) # refer to articles id
    userid = Column(INTEGER, nullable=False)
    created_time = Column(DATETIME, server_default=func.now())
    updated_time = Column(DATETIME, server_default=func.now(), onupdate=func.now())


class ArticleLikes(ModelBase):

    __tablename__ = 'article_likes'

    id = Column(INTEGER, primary_key=True)
    article_id = Column(INTEGER, nullable=False) # refer to articles id
    action = Column(INTEGER, default=0) # 0 is like and 1 is unlike
    userid = Column(INTEGER, nullable=False)
    created_time = Column(DATETIME, server_default=func.now())
    updated_time = Column(DATETIME, server_default=func.now(), onupdate=func.now())


class Comments(ModelBase):

    __tablename__ = 'comments'

    id = Column(INTEGER, primary_key=True)
    article_id = Column(INTEGER, nullable=False) # refer to articles id
    top_comment_id = Column(INTEGER, default=-1) # refer to top comments id. if top comment, value is -1
    reply_id = Column(INTEGER, default=-1) # refer to comments id
    commentator = Column(VARCHAR(63), nullable=False)
    content = Column(LONGTEXT, nullable=True)
    attachment = Column(LONGTEXT, nullable=True)
    userid = Column(INTEGER, nullable=False)
    created_time = Column(DATETIME, server_default=func.now())
    updated_time = Column(DATETIME, server_default=func.now(), onupdate=func.now())

    def to_dict(self):
        return {
            'id': self.id,
            'article_id': self.article_id,
            'top_comment_id': self.top_comment_id,
            'reply_id': self.reply_id,
            'commentator': self.commentator,
            'content': self.content or '',
            'attachment': self.attachment or '',
            'created_time': self.created_time.strftime('%Y-%m-%d %H:%M:%S'),
            'updated_time': self.updated_time.strftime('%Y-%m-%d %H:%M:%S'),
            'likes': self.get_likes_num(),
            'reply_commentator': self.get_reply_commentator(),
        }

    def get_likes_num(self):
        with mysql_sc() as sc:
            return sc.query(CommentLikes).filter(
                CommentLikes.comment_id == self.id
            ).count()

    def get_reply_commentator(self):
        with mysql_sc() as sc:
            o = sc.query(Comments).filter(Comments.id == self.reply_id).first()
            if o:
                return o.commentator
            else:
                return ''


class CommentLikes(ModelBase):

    __tablename__ = 'comment_likes'

    id = Column(INTEGER, primary_key=True)
    comment_id = Column(INTEGER, nullable=False) # refer to comment id
    action = Column(INTEGER, default=0) # 0 is like and 1 is unlike
    userid = Column(INTEGER, nullable=False)
    created_time = Column(DATETIME, server_default=func.now())
    updated_time = Column(DATETIME, server_default=func.now(), onupdate=func.now())


class Medias(ModelBase):

    __tablename__ = 'medias'

    id = Column(INTEGER, primary_key=True)
    path = Column(VARCHAR(255), nullable=False)
    userid = Column(INTEGER, nullable=False)
    created_time = Column(DATETIME, server_default=func.now())
    updated_time = Column(DATETIME, server_default=func.now(), onupdate=func.now())


class Attachments(ModelBase):

    __tablename__ = 'attachments'

    id = Column(INTEGER, primary_key=True)
    path = Column(VARCHAR(255), nullable=False)
    article_id = Column(INTEGER, nullable=False)
    comment_id = Column(INTEGER, nullable=True)
    userid = Column(INTEGER, nullable=False)
    created_time = Column(DATETIME, server_default=func.now())
    updated_time = Column(DATETIME, server_default=func.now(), onupdate=func.now())


class FeedBackFeature(ModelBase):

    __tablename__ = 'feedback_feature'

    id = Column(INTEGER, primary_key=True)
    feedback_id = Column(INTEGER, nullable=False) # refer to articles id
    contact = Column(VARCHAR(255), nullable=True)
    userid = Column(INTEGER, nullable=False)
    created_time = Column(DATETIME, server_default=func.now())
    updated_time = Column(DATETIME, server_default=func.now(), onupdate=func.now())


if __name__ == '__main__':
    from db import engine
    ModelBase.metadata.create_all(engine)


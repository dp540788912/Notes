# -*-coding:utf-8-*-

import os
import redis
import base64
import json
import hashlib

from log import logger


def save_md5_file(path, filelikeobj):
    file_md5 = get_file_md5(filelikeobj.body)
    if file_md5 is None:
        return None
    if not os.path.exists(path):
        os.makedirs(path)
    suffix = os.path.splitext(filelikeobj.filename)[1]
    file_name = '%s%s' % (file_md5, suffix)
    file_path = os.path.join(path, file_name)
    try:
        with open(file_path, 'wb') as f:
            f.write(filelikeobj.body)
    except Exception as e:
        logger.error(str(e))
        raise e
        return None
    return file_name


def get_file_md5(file_body):
    try:
        md5_obj = hashlib.md5()
        md5_obj.update(file_body)
        hash_code = md5_obj.hexdigest()
        md5_value = str(hash_code).lower()
        return md5_value
    except Exception as e:
        logger.error(str(e))
        raise e
        return None


def check_redis_session(redis_config, session):
    rds = redis.Redis(redis_config['host'], redis_config['port'])
    s = rds.get('session:%s' % session)
    if s:
        data = json.loads(str(base64.b64decode(s), 'utf-8').split(':', 1)[-1])
        if ('_auth_user_id' in data):
            res = {
                'id': data.get('_auth_user_id'),
                'username': data.get('_auth_user_name', ''),
                'nickname': data.get('_auth_user_nickname', ''),
            }
            if res['username'] == 'root':
                res['is_superuser'] = True
            else:
                res['is_superuser'] = False
            return res
    return {}


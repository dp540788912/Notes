# -*-coding:utf-8-*-

from handlers import *


urls = [
    (r"/api/v1/community/articles$", ArticlesListHandler),
    (r"/api/v1/community/articles/(?P<id>\d+)$", ArticleDetailHandler),
    (r"/api/v1/community/articles/like/(?P<id>\d+)$", ArticleLikeHandler),
    (r"/api/v1/community/comments$", CommentsListHandler),
    (r"/api/v1/community/comments/(?P<id>\d+)$", CommentDetailHandler),
    (r"/api/v1/community/comments/like/(?P<id>\d+)$", CommentLikeHandler),
    (r"/api/v1/community/media$", UploadMediaListHandler),
    (r"/api/v1/community/notebooks$", NotebooksListHandler),
    (r"/api/v1/community/notebooks/detail$", NotebooksDetailHandler),
    (r"/api/v1/community/feedbacks$", FeedBacksListHandler),
    (r"/api/v1/community/feedbacks/(?P<id>\d+)$", FeedBacksDetailHandler),
    (r"/api/v1/community/feedback_reply$", FeedBackReplyListHandler),
    (r"/api/v1/community/feedback_reply/(?P<id>\d+)$", FeedBackReplyDetailHandler),
]


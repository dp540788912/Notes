# -*-coding:utf-8-*-

import netifaces


class CommonConfig(object):
    Debug = True
    port = 18880
    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql
    redis = {
        'host': '127.0.0.1',
        'port': '6379',
    }
    media = {
        'basepath': '/home/rss/bss_server/site',
    }
    notebooks = {
        'basepath': '/home/rss/jupyter_userworkspace',
    }


class ProductionConfig_IDC(CommonConfig):
    Debug = False
    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'datahub',
        'user': 'operation',
        'passwd': '432bfa0bec42bd232818460647b3767a8e1cd7fd',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql


iplist = [netifaces.ifaddresses(i).get(netifaces.AF_INET)[0]['addr']
          for i in netifaces.interfaces() if netifaces.ifaddresses(i).get(netifaces.AF_INET)]

product_idc_list = ['192.168.10.100']

if any([i in iplist for i in product_idc_list]):
    Debug = False
    config = ProductionConfig_IDC()
else:
    Debug = True
    config = CommonConfig()


# -*-coding:utf-8-*-

import os
import logging

from logging.handlers import RotatingFileHandler
from config import config


if config.Debug:
    log_level = logging.DEBUG
else:
    log_level = logging.INFO

log_path = os.path.join(os.path.dirname(__file__), 'logs')
if not os.path.exists(log_path):
    os.makedirs(log_path)

log_file = os.path.join(log_path, 'server.log')
log_handler = RotatingFileHandler(log_file)
log_handler.setFormatter(logging.Formatter(
    '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]')
)
logger = logging.getLogger()
logger.setLevel(log_level)
logger.addHandler(log_handler)


# -*-coding:utf-8-*-

import tornado.ioloop
import tornado.web

from config import config
from log import logger
from urls import urls


class Application(tornado.web.Application):

    def __init__(self, handlers):
        self.logger = logger
        self.cfg = config
        tornado.web.Application.__init__(self, handlers)


def make_app():
    return Application(urls)


if __name__ == "__main__":
    app = make_app()
    app.listen(config.port)
    tornado.ioloop.IOLoop.current().start()


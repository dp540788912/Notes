# -*- coding:utf-8 -*-

import os
import redis
import base64
import json
import time
import datetime
import hashlib
import requests

from log import logger


def save_file(path, filelikeobj):
    logger.info('save %s to %s' % (filelikeobj.filename, path))
    if not os.path.exists(path):
        os.mkdir(path)
    data_fd = None 
    try: 
        with open(os.path.join(path, filelikeobj.filename), 'wb') as f:
            f.write(filelikeobj.body)
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True 


def check_redis_session(redis_config, session):
    rds = redis.Redis(redis_config['host'], redis_config['port'])
    s = rds.get('session:%s' % session)
    if s:
        data = json.loads(str(base64.b64decode(s), 'utf-8').split(':', 1)[-1])
        if ('_auth_user_id' in data):
            res = {
                'id': data.get('_auth_user_id'),
                'username': data.get('_auth_user_name', ''),
                'nickname': data.get('_auth_user_nickname', ''),
            }
            return res
    return {}


def query_redis_iphost(redis_config, host):
    iphost = ''
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        hosts = rds.smembers('a:oss:hosts')
        for h in hosts:
            h = str(h, 'utf-8')
            if h == host:
               iphost = h
    except Exception as e:
        logger.error(str(e))
        raise e
        return ''
    return iphost


def query_agent_online(redis_config, host):
    online = 2
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        d = rds.hget('oss:monitor:overview:host_status', host)
        if d:
            data = json.loads(str(d, 'utf-8'))
            online = 2 if data.get('agent_status', -2) == -2 else 0
    except Exception as e:
        logger.error(str(e))
        raise e
    finally:
        return online


def query_process_online(redis_config, host):
    res = {}
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        d = rds.hget('a:oss:monitor:processes', host)
        if d:
            data = json.loads(str(d, 'utf-8'))
            process_list = data.get('process', [])
            for process in process_list:
                process_id = process.get('process_id', 0)
                if process.get('status', -1) == -1:
                    res[process_id] = 2
                else:
                    if process.get('is_running', 0) == 1:
                        res[process_id] = 0
                    else:
                        res[process_id] = 2
    except Exception as e:
        logger.error(str(e))
        raise e
    finally:
        return res


def rpush_redis_cmd(redis_config, iphost, cmd):
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        r_queue = redis_config['cmd_key'] + iphost
        rds.rpush(r_queue, cmd)
        logger.info('rpush redis=[%s]: cmd=[%s]' % (r_queue, cmd))
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def lpop_redis_cmd(redis_config, iphost, seq):
    data = None
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        r_queue = redis_config['rsp_key'] + iphost
        for d in rds.lrange(r_queue, 0, -1):
            if json.loads(str(d, 'utf-8'))['seq'] == seq:
                data = d
                break
        rds.lrem(r_queue, data, 0)
        logger.info('lpop redis=[%s]: data=[%s]' % (r_queue, data))
        return data
    except Exception as e:
        logger.error(str(e))
        raise e
        return None


def update_redis_process(redis_config, iphost, path, running, process_id):
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        r_hash = 'oss:deploy:monitor:processes:%s' % iphost
        data = json.dumps({
            'path': path,
            'is_running': running,
            'process_id': process_id,
            'clock': time.time(),
            'monitor_progress': 0,
        })
        rds.hset(r_hash, process_id, data)
        logger.info('update: hset redis=[%s], process_id=[%s], data=[%s]' % (r_hash, process_id, data))
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def delete_redis_process(redis_config, iphost, process_id):
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        r_hash = 'oss:deploy:monitor:processes:%s' % iphost
        if not rds.hexists(r_hash, process_id):
            return False
        rds.hdel(r_hash, process_id)
        logger.info('delete: hdel redis=[%s], process_id=[%s]' % (r_hash, process_id))
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def extract_package(s_host, s_path, bfile, type):
    if type == 0 or type == 3:
        cmd = 'tar -xf %s --strip-components 1 -C %s' % (os.path.join(s_path, os.path.basename(bfile)), s_path)
    else:
        cmd = 'tar -xf %s -C %s' % (os.path.join(s_path, os.path.basename(bfile)), s_path)
    scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
    try:
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def make_dirs(s_host, s_path):
    cmd = 'mkdir -p %s' % s_path
    scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
    try:
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def backup_bfile(s_host, s_path, now):
    if not make_dirs(s_host, os.path.join(os.path.dirname(s_path), 'bak')):
        return False
    cmd = 'mv %s %s/bak/%s_%s' % (s_path, os.path.dirname(s_path),
                                  os.path.basename(s_path), datetime.datetime.strftime(now, '%Y%m%d%H%M%S'))
    scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
    try:
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def update_script_cpu(s_host, s_path, script_cpu_bind):
    cmd = 'sed -i \'s/taskset -c [0-9]*/taskset -c %s/\' %s/run.sh' % (script_cpu_bind, s_path)
    scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
    try:
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def upload_turing_bfile(l_user, l_host, s_host, s_path, bfile, deployed=False, script_cpu_bind=None):
    cmd = 'rsync -az %s@%s:%s %s' % (l_user, l_host, bfile, s_path)
    scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
    try:
        if deployed:
            backup_bfile(s_host, s_path, datetime.datetime.now())
        if not make_dirs(s_host, s_path):
            return False
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False
        if not extract_package(s_host, s_path, bfile, 0):
            return False
        if script_cpu_bind is not None:
            if not update_script_cpu(s_host, s_path, script_cpu_bind):
                return False
    except Exception as e:
        logger.error(str(e))
        return False
    return True


def upload_ev_file(l_user, l_host, s_host, s_path, ev_file, deployed=False, istest=False):
    if istest:
        s_path = os.path.join(s_path, 'test')
    cmd = 'rsync -az %s@%s:%s %s' % (l_user, l_host, ev_file, s_path)
    scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
    try:
        if not make_dirs(s_host, s_path):
            return False
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False
    except Exception as e:
        logger.error(str(e))
        return False
    return True


def copy_product_strategies(s_host, s_path, so_file, products, day_night):
    daynight = 'day' if day_night == 0 else 'night'
    so_name = os.path.basename(so_file)
    alphamixer = os.path.splitext(so_name)[0]
    try:
        for product in products:
            cmd = 'cp -f %s/%s.so %s/%s_%s_%s.so' % (s_path, alphamixer, s_path, alphamixer, product, daynight)
            scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
            res = os.system(scmd)
            logger.info('exec cmd: %s' % scmd)
            if res != 0:
                logger.info('cmd error: %s' % scmd)
                return False
            cmd = 'cp -f %s/%s.so %s/%s_%s2_%s.so' % (s_path, alphamixer, s_path, alphamixer, product, daynight)
            scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
            res = os.system(scmd)
            logger.info('exec cmd: %s' % scmd)
            if res != 0:
                logger.info('cmd error: %s' % scmd)
                return False
    except Exception as e:
        logger.error(str(e))
        return False
    return True


def upload_strategies_file(l_user, l_host, s_host, s_path, so_file, products, day_night, deployed=False, istest=False):
    logger.debug('products: %s' % products)
    if istest:
        s_path = os.path.join(s_path, 'test')
    cmd = 'rsync -az %s@%s:%s %s' % (l_user, l_host, so_file, s_path)
    scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
    try:
        if not make_dirs(s_host, s_path):
            return False
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False
        if not copy_product_strategies(s_host, s_path, so_file, products, day_night):
            return False
    except Exception as e:
        logger.error(str(e))
        return False
    return True


def run_agent_process(s_host, s_path, opt_type):
    if opt_type == 0:
        cmd = 'sh %s/run.sh' % s_path
    elif opt_type == 2:
        cmd = 'sh %s/task_kill.sh' % s_path
    else:
        return False
    scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
    try:
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False
    except Exception as e:
        logger.error(str(e))
        return False
    return True


def md5sum(filename):
    with open(filename, 'rb') as f:
        md5_obj = hashlib.md5()
        while True:
            d = f.read(8096)
            if not d:
                break
            md5_obj.update(d)
    return str(md5_obj.hexdigest())


def get_my_products(exchange):
    if exchange == 'cffex':
        return [
            'if', 't', 'tf',
        ]
    elif exchange == 'czce':
        return [
            'zzcf', 'zzfg', 'zzma', 'zzoi', 'zzrm',
            'zzsr', 'zzta', 'zzwh', 'zzzc',
        ]
    elif exchange == 'dce':
        return [
            'dla', 'dlbb', 'dlc', 'dlcs', 'dlfb',
            'dli', 'dlj', 'dljd', 'dljm', 'dll',
            'dlm', 'dlp', 'dlpp', 'dlv', 'dly',
        ]
    elif exchange == 'shfe':
        return [
            'shag', 'shal', 'shau', 'shbu', 'shcu',
            'shhc', 'shni', 'shpb', 'shrb', 'shru',
            'shzn',
        ]
    else:
        return []


def cmp_details_list(src_list, dest_list):
    src = ['__'.join([str(k) for k in v.values()]) for v in src_list]
    dest = ['__'.join([str(k) for k in v.values()]) for v in dest_list]
    if sorted(src) == sorted(dest):
        return True
    else:
        return False


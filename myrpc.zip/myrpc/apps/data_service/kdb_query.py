#-*-coding:utf-8-*-

from contextlib import contextmanager
from qpython import qconnection
import time
from config import config


class KdbQuery(object):
    def __init__(self, host=config.kdb['host'], port=config.kdb['port'],
                 username=config.kdb['user'], password=config.kdb['passwd']):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.connect()

    def __del__(self):
        self.release()

    def reconnect(self):
        try:
            self.release()
        finally:
            return self.connect()

    def release(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def connect(self):
        try:
            self.conn = qconnection.QConnection(host=self.host, port=self.port,
                                                username=self.username, password=self.password)
            self.conn.open()
            return self.conn.is_connected()
        except Exception as err:
            return False

    def check(self):
        if self.conn.is_connected():
            return True
        else:
            return False

    def sync_query(self, q_sql):
        data = None
        if self.check():
            data = self.conn.sync(str(q_sql))
        return data

    def async_query(self, q_sql):
        data = None
        if self.check():
            self.conn.async(str(q_sql))
            data = self.conn.receive()
        return data

    def query_crontab_result(self, task_name):
        ret = -1
        msg = []

        sql_query_flag = '.gw.asyncexec[" 0!select last FLAG by PROJECT from DataState where PROJECT=`%s ";`DataQuality]' % task_name
        sql_query_msg = '.gw.asyncexec["update string TRADE_DT,string UPDATETIME from ungroup 0!select by PROJECT from DataState where PROJECT=`%s ";`DataQuality]' % task_name
        
        # 1:succes 0:fail
        flag = self.async_query(sql_query_flag)
        if len(flag) == 1:
            ret = int(flag[0][1])-1
        detail = self.async_query(sql_query_msg)
        for r in detail:
            data = {}
            data['project'] = str(r['PROJECT'], encoding="utf-8")
            data['ip'] = str(r['IP'], encoding="utf-8")
            data['trade_dt'] = str(r['TRADE_DT'], encoding="utf-8")
            data['subproject'] = str(r['SUBPROJECT'], encoding="utf-8")
            data['errosubproject'] = str(r['ERROSUBPROJECT'], encoding="utf-8")
            data['flag'] = int(r['FLAG'])
            data['updatetime'] = str(r['UPDATETIME'], encoding="utf-8")
            msg.append(data)
        return ret, msg

@contextmanager
def kdb_contextMng():
    try:
        kdb_hd = KdbQuery()
        yield kdb_hd
    except Exception as e:
        kdb_hd.release()
    finally:
        kdb_hd.release()
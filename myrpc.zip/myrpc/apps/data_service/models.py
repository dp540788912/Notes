#-*-coding:utf-8-*-

from sqlalchemy.sql import func, or_
from sqlalchemy.orm import relationship
from sqlalchemy import Column, ForeignKey, PrimaryKeyConstraint
from sqlalchemy.dialects.mysql import BIGINT, DATETIME, DATE, TIME, INTEGER, VARCHAR, TEXT, LONGTEXT, FLOAT, DOUBLE, BOOLEAN, JSON, ENUM

from db import ModelBase, session, session_context as mysql_sc
from config import config

class Users(ModelBase):

    __tablename__ = 'users'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False)
    password = Column(VARCHAR(255), nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'password': self.password,
        }

class DataServiceBusinessType(ModelBase):

    __tablename__ = 'data_service_business_type'

    #1:原始数据检查 2:数据生产 3:每日更新检查 4:历史数据质检
    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(10), nullable=False, unique=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
        }

class CrontabTasks(ModelBase):

    __tablename__ = 'crontab_tasks'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(128), nullable=False, unique=True)             # crontab name
    scheduler = Column(VARCHAR(128), nullable=True)                      # format like linux crontab: m h dom mon dow
    script = Column(VARCHAR(256), nullable=True)
    para = Column(VARCHAR(256), nullable=True)
    enable = Column(INTEGER, nullable=True)
    description = Column(VARCHAR(256), nullable=True)                    # comments for crontab
    host = Column(VARCHAR(256), nullable=True)
    next_time = Column(VARCHAR(64), nullable=True, default='0')
    notify_method = Column(INTEGER, nullable=True)
    notify_users = Column(JSON, nullable=True)


    def to_dict(self):
        return {
            'task_id': self.id,
            'name': self.name,
            'script': self.script,
            'para': self.para,
            'scheduler': self.scheduler,
            'enable': self.enable,
            'description': self.description,
            'host': self.host,
            'next_time': self.next_time,
            'notify_method': self.notify_method,
            'notify_users': self.notify_users,
        }

class CrontabTasksLogs(ModelBase):

    __tablename__ = 'crontab_tasks_logs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(128), nullable=False)
    exe_time = Column(VARCHAR(128), nullable=False)                      # task finished datetime
    ret = Column(INTEGER, nullable=False)                                # 0 success, 1 running, others error
    msg = Column(TEXT, nullable=True)

class DataServiceCrontabID(ModelBase):

    __tablename__ = 'data_service_crontab_id'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    business_type = Column(ForeignKey('data_service_business_type.id', ondelete='CASCADE'))
    crontab_id = Column(ForeignKey('crontab_tasks.id', ondelete='CASCADE'))

    business_type_obj = relationship('DataServiceBusinessType')
    crontab_obj = relationship('CrontabTasks')


if __name__ == '__main__':
    from db import engine
    ModelBase.metadata.create_all(engine)

#-*- coding: utf-8 -*-

import json
import tornado.httpclient
from crontab import CronTab
import datetime
from db import Session, session_context as mysql_sc
from kdb_query import kdb_contextMng as kdb_conn
from models import *
from log import logger
from config import config



class BaseHandler(tornado.web.RequestHandler):

    def initialize(self, *args, **kwargs):
        self.model = None
        self.fields = {}    # key: model-key, value: payload-key
        self.no_login = []

    def prepare(self, *args, **kwargs):
        if hasattr(self, 'no_login') and self.request.method.lower() in self.no_login:
            self.current_user = {}
            return
        if self.request.headers.get('whitelist'):
            self.current_user = {
                'id': 999999,
                'username': self.request.headers['whitelist'],
                'nickname': self.request.headers['whitelist'],
            }
        else:
            sessionid = self.get_cookie('sessionid')
            if not sessionid:
                self.write(json.dumps({
                    'code': 401,
                    'error': 'Sessionid not found.'
                }))
                self.finish()
                return
            res = check_redis_session(config.redis, sessionid)
            if not res:
                self.write(json.dumps({
                    'code': 401,
                    'error': 'User not login.',
                }))
                self.finish()
                return
            self.current_user = res

    def get(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def post(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def put(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def delete(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))


class ListHandler(BaseHandler):

    def get(self, *args, **kwargs):
        res = []
        with mysql_sc() as sc:
            lines = sc.query(self.model).all()
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if sorted(payload.keys()) != sorted(self.fields.values()):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            data = {}
            for k, v in self.fields.items():
                data[k] = payload[v]
            with mysql_sc() as sc:
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class IDHandler(BaseHandler):

    def get(self, *args, **kwargs):
        with mysql_sc() as sc:
            o = sc.query(self.model).filter_by(id=kwargs['id']).first()
            if o:
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
            else:
                self.write(json.dumps({
                    'code': 404,
                    'error': 'Data not found.',
                }))

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    for k, v in self.fields.items():
                        if v in payload:
                            setattr(o, k, payload[v])
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                sc.query(self.model).filter_by(id=kwargs['id']).delete()
                self.write(json.dumps({
                    'code': 0,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

class UsersListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = Users
        self.fields = {
            'name': 'name',
            'password': 'password',
        }
        self.no_login = ['get']

class DataServiceBusinessTypeListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = DataServiceBusinessType
        self.fields = {
            'name': 'name',
        }
        self.no_login = ['get', 'post', 'put', 'delete']

class DataServiceCrontabListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = CrontabTasks
        self.fields = {
            'name': 'name',
            'scheduler': 'scheduler',
            'script': 'script',
            'para': 'para',
            'enable': 'enable',
            'description': 'description',
            'host': 'host',
            'notify_method': 'notify_method',
            'notify_users': 'notify_users',
        }

        self.header = [
            {
                'prop': 'name',
                'title': '任务名称'
            },
            {
                'prop': 'host',
                'title': '服务器IP'
            },
            {
                'prop': 'script',
                'title': '脚本'
            },
            {
                'prop': 'para',
                'title': '参数'
            },
            {
                'prop': 'scheduler',
                'title': '任务计划'
            },
            {
                'prop': 'description',
                'title': '任务描述'
            },
            {
                'prop': 'enable',
                'title': '是否启用'
            },
            {
                'prop': 'time',
                'title': '最近运行时间'
            },
            {
                'prop': 'last_exe_log',
                'title': '执行结果'
            },
            {
                'prop': 'query_log',
                'title': '查询结果'
            },
            {
                'prop': 'notify_method',
                'title': '通知方式'
            },
            {
                'prop': 'notify_users',
                'title': '通知人'
            }
        ]
        self.subheader = [
            {
                'prop': 'project',
                'title': 'project'
            },
            {
                'prop': 'ip',
                'title': 'ip'
            },
            {
                'prop': 'trade_dt',
                'title': 'trade_dt'
            },
            {
                'prop': 'subproject',
                'title': 'subproject'
            },
            {
                'prop': 'errosubproject',
                'title': 'errosubproject'
            },
            {
                'prop': 'flag',
                'title': 'flag'
            },
            {
                'prop': 'updatetime',
                'title': 'updatetime'
            }
        ]
        self.no_login = ['get', 'post', 'put', 'delete']

    def get(self, *args, **kwargs):
        type = int(self.get_argument('business_type', ''))
        out_data = []
        try:
            with mysql_sc() as sc:
                tasks = sc.query(
                    CrontabTasks,
                ).join(
                    DataServiceCrontabID, CrontabTasks.id == DataServiceCrontabID.crontab_id,
                ).filter(
                    DataServiceCrontabID.business_type == type,
                )

                if tasks:
                    with kdb_conn() as kdb_hd:
                        for task in tasks:
                            data = {
                                'business_type': type,
                                'task_id': task.id,
                                'name': task.name,
                                'script': task.script,
                                'para': task.para,
                                'scheduler': task.scheduler,
                                'description': task.description,
                                'enable': task.enable,
                                'next_time': task.next_time,
                                'host': task.host,
                                'notify_method': task.notify_method,
                                'notify_users': task.notify_users,
                                'last_exe_log': {
                                    'time': '',
                                    'return': -1,
                                    'msg': 'no query',
                                },
                                'query_log': {
                                    'return': -1,
                                    'msg': 'no query',
                                }
                            }
                            last_log = sc.query(CrontabTasksLogs).filter(
                                CrontabTasksLogs.name == task.name
                            ).order_by(
                                CrontabTasksLogs.id.desc()
                            ).first()
                            if last_log:
                                data['last_exe_log']['time'] = last_log.exe_time
                                data['last_exe_log']['return'] = -1 if 2==last_log.ret else last_log.ret
                                data['last_exe_log']['msg'] = last_log.msg

                            flag, msg = kdb_hd.query_crontab_result(task.name)
                            data['query_log']['return'] = flag
                            data['query_log']['msg'] = msg
                            out_data.append(data)

            self.write(json.dumps({
                'code': 0,
                'data': {
                    'data': out_data,
                    'header': self.header,
                    'subheader': self.subheader
                },
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


            
    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if not payload[0].get('business_type', None) or \
           not payload[0].get('name', None) or \
           not payload[0].get('script', None) or \
           not payload[0].get('scheduler', None):
            self.write(json.dumps({
                'code': 1007,
                'error': '必选参数不能为空',
            }))
            return
        out_data = []
        try:
            with mysql_sc() as sc:
                for task in payload:
                    logger.debug(task)
                    business_type = task.pop('business_type')
                    o = sc.query(CrontabTasks).filter(
                        CrontabTasks.name == task['name'],
                    ).first()
                    if not o:
                        current_time = datetime.datetime.now()
                        next_time = current_time + datetime.timedelta(
                            seconds=CronTab(task['scheduler']).next(current_time, default_utc=True))
                        task['next_time'] = next_time.strftime('%Y-%m-%d %H:%M:%S')
                        o = CrontabTasks(**task)
                        sc.add(o)
                        sc.commit()
                        r = DataServiceCrontabID(
                            business_type=business_type,
                            crontab_id=o.id
                        )
                        sc.add(r)

                        data = o.to_dict()
                        data['business_type'] = business_type
                        data['last_exe_log'] = {
                            'time': '',
                            'return': -1,
                            'msg': 'no query',
                        },
                        data['query_log'] = {
                            'return': -1,
                            'msg': 'no query',
                        }

                        out_data.append(data)
                    else:
                        self.write(json.dumps({
                            'code': 1001,
                            'error': "%s has existed" % task['name'],
                        }))
                        return

                sc.commit()
                logger.debug(out_data)
                self.write(json.dumps({
                    'code': 0,
                    'data': out_data
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        out_data = []
        try:
            with mysql_sc() as sc:
                for task in payload:
                    logger.debug(task)
                    o = sc.query(CrontabTasks).filter_by(id=task['task_id']).first()
                    if o:
                        for k, v in self.fields.items():
                            if v in task.keys() and v != 'task_id' and v != 'business_type':
                                setattr(o, k, task[v])
                        data = o.to_dict()
                        data['business_type'] = task['business_type']
                        out_data.append(data)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': out_data
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        logger.info(payload)
        try:
            with mysql_sc() as sc:
                for task_id in payload['task_id']:
                    sc.query(CrontabTasks).filter_by(id=task_id).delete()
                    sc.query(DataServiceCrontabID).filter_by(
                        business_type=payload['business_type'],
                        crontab_id=task_id
                    ).delete()

            self.write(json.dumps({
                'code': 0,
                'msg': "success"
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))
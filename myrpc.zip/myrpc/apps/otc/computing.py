#-*-coding:utf-8-*-
'''
Created on Oct 9, 2017
@author: Sheil-Wang
'''

import os
import sys
import math
import time


PI = 3.1415926


def getDate():
    trade_date = time.strftime('%Y%m%d',time.localtime(time.time()))
    return trade_date


#last valuation computing, mat parameter is yesterday's mat
def valuation_last(isExpired, endDate, tradeDate, closeCash, price, units, option_type, spot, strike, yesterdayMat, rate, sigma):
    if(isExpired == 'Y' and endDate < getDate()):
        return -closeCash
    else :
        if(tradeDate == getDate()):
            return price*units
        else:
            return get_bs_price(option_type, spot, strike, yesterdayMat, rate, sigma)*units


def valuation_d_time(isExpired, endDate, tradeDate, closeCash, price, units, option_type, spot, strike, todayMat, rate, sigma):
    return valuation_last(isExpired, endDate, tradeDate, closeCash, price, units, option_type, spot, strike, todayMat, rate, sigma)


def valuation_d_sigma(isExpired, endDate, tradeDate, closeCash, price, units, spotRef, option_type, spot, strike, todayMat, rate, sigma):
    if(isExpired == 'Y' and endDate < getDate()):
        return -closeCash
    else :
        if(tradeDate == getDate()):
            spot = spotRef
        return get_bs_price(option_type, spot, strike, todayMat, rate, sigma)*units


def valuation_today(isExpired, closeCash, units, option_type, spot, strike, todayMat, rate, sigma):
    if(isExpired == 'Y'):
        return -closeCash
    else :
        return get_bs_price(option_type, spot, strike, todayMat, rate, sigma)*units


def pnl_yesterday(isExpired, endDate, tradeDate, closeCash, price, units, option_type, spot, strike, yesterdayMat, rate, sigma):
    if(tradeDate != ""):
        if(tradeDate == getDate()):
            return 0.0
        else:
            return (closeCash + valuation_last(isExpired, endDate, tradeDate, closeCash, price, units, option_type, spot, strike, yesterdayMat, rate, sigma))
    else:
        return 0.0


def pnl_today(isExpired, tradeDate, closeCash, price, units, option_type, spot, strike, todayMat, rate, sigma):
    if(tradeDate != ""):
        return closeCash + valuation_today(isExpired, closeCash, units, option_type, spot, strike, todayMat, rate, sigma)
    else:
        return 0.0


def pnl_theta(tradeDate, valuationLast, valuationDTime):
    if(tradeDate != ""):
        if(tradeDate == getDate()):
            return 0.0
        else:
            return valuationDTime - valuationLast
    else:
        return 0.0


def pnl_vega(tradeDate, valuationDSigma, valuationDTime):
    if(tradeDate != ""):
        return valuationDSigma - valuationDTime
    else:
        return 0.0


def pnl_delta(tradeDate, valuationToday, valuationDSigma):
    if(tradeDate != ""):
        return valuationToday - valuationDSigma
    else:
        return 0.0


class Greeks:
    def _init__(self, delta=0.0, gamma=0.0, theta=0.0, rho=0.0, vega=0.0):
        self.delta = delta
        self.gamma = gamma
        self.theta = theta
        self.rho = rho
        self.vega = vega

    def set_delta(self, d):
        self.delta = d

    def get_delta(self):
        return self.delta

    def set_gamma(self, g):
        self.gamma = g

    def get_gamma(self):
        return self.gamma

    def set_theta(self, t):
        self.theta = t

    def get_theta(self):
        return self.theta

    def set_rho(self, r):
        self.rho = r

    def get_rho(self):
        return self.rho

    def set_vega(self, v):
        self.vega = v

    def get_vega(self):
        return self.vega

    def display_greeks(self):
        print("Display the greeks:")
        print("delta = %f, gamma = %f, theta= %f, rho = %f, vega = %f" % (self.delta, self.gamma, self.theta, self.rho, self.vega))


def Normal(z) :
    temp = float(math.exp((-1)*z*z / 2) / math.sqrt(2 * PI))
    return temp


def NormSDist(z) :
    #this guards against overflow
    if (z > 6) :
        return 1
    if (z < -6) :
        return 0
    gamma = 0.231641900
    a1 = 0.319381530
    a2 = -0.356563782
    a3 = 1.781477973
    a4 = -1.821255978
    a5 = 1.330274429
    k = 1.0 / (1 + math.fabs(z) * gamma)
    n = float(k * (a1 + k * (a2 + k * (a3 + k * (a4 + k * a5)))))
    n = float(1 - Normal(z) * n)
    if (z < 0):
        return 1.0 - n
    return n


def get_greeks(option_type, spot, strike, mat, rate, sigma):
    greeks = Greeks()
    if (mat < 0.0000000001):
        mat = 0.0000000001
    d1 = (math.log(spot / float(strike) ) + ((sigma*sigma) / 2)*mat) / (sigma * math.sqrt(mat))
    d2 = d1 - sigma * math.sqrt(mat)
    if (option_type == 'C'):
        delta = NormSDist(d1)
        theta = -(spot * Normal(d1) * sigma / (2.0 * math.sqrt(mat))) - (rate * strike * math.exp(-rate*mat)*NormSDist(d2))
        theta /= 365
    elif (option_type == 'P'):
        delta = -NormSDist(-d1)
        theta = -(spot * Normal(d1) * sigma / (2.0*math.sqrt(mat))) + (rate * strike * math.exp(-rate*mat)*NormSDist(-d2))
        theta /= 365
    else :
        raise ValueError("Error options' type: %s " % option_type)
    gamma = Normal(d1) / (spot * sigma * math.sqrt(mat))
    vega = spot * Normal(d1) * math.sqrt(mat)
    greeks.set_delta(delta)
    greeks.set_gamma(gamma)
    greeks.set_theta(theta)
    greeks.set_vega(vega)
    greeks.set_rho(0.0)
    return greeks


def get_bs_price(option_type, spot, strike, mat, rate, sigma):
    try:
        price = 0.0
        if (mat < 0.0000000001):
            mat = 0.0000000001
        d1 = (math.log(spot / float(strike)) + ((sigma*sigma) / 2)*mat) / (sigma * math.sqrt(mat))
        d2 = d1 - sigma * math.sqrt(mat)
        if (option_type == 'C'):
            price = (NormSDist(d1)*spot - NormSDist(d2)*strike)*math.exp(-rate*mat)
        elif (option_type == 'P'):
            price = (NormSDist(-d2)*strike - NormSDist(-d1)*spot)*math.exp(-rate*mat)
        else :
            raise ValueError("Error options' type: %s " % option_type)
        return round(price, 6)
    except Exception as e:
        return round(0.0, 6)


def get_sigma(option_type, spot, strike, mat, rate, target_price):
    high = 1.0
    low = 0.0
    while((high-low) > 0.00001):
        if(get_bs_price(option_type, spot, strike, mat, rate, (high + low)/2) > target_price):
            high = (high + low) / 2
        else :
            low =  (high + low) / 2
    iv = float((high + low) / 2)
    return  float(iv)


def get_front_greeks(isExpired, tradeDate, lots, units, option_type, spot, strike, mat, rate, sigma):
    greeks = Greeks()
    if(isExpired == "Y"):
        delta = 0.0
    else:
        if (tradeDate != ""):
            delta = (get_bs_price(option_type, spot+0.5, strike, mat, rate, sigma) - get_bs_price(option_type, spot-0.5, strike, mat, rate, sigma))*lots
        else:
            delta = 0.0
    if(isExpired == "Y"):
        gamma = 0.0
    else:
        if (tradeDate != ""):
            a = get_bs_price(option_type, spot+1, strike, mat, rate, sigma) + get_bs_price(option_type, spot-1, strike, mat, rate, sigma)
            b = 2*get_bs_price(option_type, spot, strike, mat, rate, sigma)
            gamma = (a - b) * lots
        else:
            gamma = 0.0
    if(isExpired == "Y"):
        vega = 0.0
    else:
        if (tradeDate != ""):
            vega = (get_bs_price(option_type, spot, strike, mat, rate, sigma+0.005) - get_bs_price(option_type, spot, strike, mat, rate, sigma-0.005))*lots
        else:
            vega = 0.0
    if(isExpired == "Y"):
        theta = 0.0
    else:
        if (tradeDate != ""):
            theta = (get_bs_price(option_type, spot, strike, mat-0.0041, rate, sigma) - get_bs_price(option_type, spot, strike, mat, rate, sigma))*units
        else:
            theta = 0.0
    greeks.set_delta(delta)
    greeks.set_gamma(gamma)
    greeks.set_vega(vega)
    greeks.set_theta(theta)
    greeks.set_rho(0.0)
    return greeks


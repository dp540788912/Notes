#-*- coding: utf-8 -*-

import os
import csv
import datetime
import json
import tornado.web
import tornado.httpclient
import requests
import redis
import codecs
import pandas as pd

from io import StringIO
from models import *
from kdb_api import *
from config import config
from log import logger
from computing import *
from utils import *


class BaseHandler(tornado.web.RequestHandler):

    def initialize(self, *args, **kwargs):
        self.model = None
        self.fields = {}    # key: model-key, value: payload-key
        self.no_login = []

    def prepare(self, *args, **kwargs):
        if hasattr(self, 'no_login') and self.request.method.lower() in self.no_login:
            self.current_user = {}
            return
        sessionid = self.get_cookie('sessionid')
        if not sessionid:
            self.write(json.dumps({
                'code': 401,
                'error': 'Sessionid not found.'
            }))
            self.finish()
            return
        res = check_redis_session(config.redis, sessionid)
        if not res:
            self.write(json.dumps({
                'code': 401,
                'error': 'User not login.',
            }))
            self.finish()
            return
        self.current_user = res

    def get(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def post(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def put(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def delete(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))


class ListHandler(BaseHandler):

    def get(self, *args, **kwargs):
        res = []
        with mysql_sc() as sc:
            lines = sc.query(self.model).all()
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if sorted(payload.keys()) != sorted(self.fields.values()):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            data = {}
            for k, v in self.fields.items():
                data[k] = payload[v]
            with mysql_sc() as sc:
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class IDHandler(BaseHandler):

    def get(self, *args, **kwargs):
        with mysql_sc() as sc:
            o = sc.query(self.model).filter_by(id=kwargs['id']).first()
            if o:
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
            else:
                self.write(json.dumps({
                    'code': 404,
                    'error': 'Data not found.',
                }))

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    for k, v in self.fields.items():
                        if v in payload:
                            setattr(o, k, payload[v])
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                sc.query(self.model).filter_by(id=kwargs['id']).delete()
                self.write(json.dumps({
                    'code': 0,
                }))
        except exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class ExchangesListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = Exchanges

    def get(self, *args, **kwargs):
        res = []
        with mysql_sc() as sc:
            lines = sc.query(self.model)
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))


class OTCEmployeesListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = OTCEmployees

    def get(self, *args, **kwargs):
        res = []
        with mysql_sc() as sc:
            lines = sc.query(self.model)
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))


class OTCCounterPartiesListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = OTCCounterParties

    def get(self, *args, **kwargs):
        res = []
        with mysql_sc() as sc:
            lines = sc.query(self.model)
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if 'name' not in payload:
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            with mysql_sc() as sc:
                data = {
                    'name': payload['name'],
                }
                a = OTCAccounts(**data)
                sc.add(a)
                sc.commit()
                data = {
                    'name': payload['name'],
                    'account_id': a.id,
                }
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if 'name' not in payload or 'id' not in payload:
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            with mysql_sc() as sc:
                o = sc.query(OTCCounterParties).filter(
                    OTCCounterParties.id == payload['id'],
                ).first()
                if o:
                    o.name = payload['name']
                    sc.commit()
                    self.write(json.dumps({
                        'code': 0,
                        'data': o.to_dict(),
                    }))
                else:
                    self.write(json.dumps({
                        'code': 400,
                        'error': 'data not found.',
                    }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if 'id' not in payload:
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            with mysql_sc() as sc:
                sc.query(OTCCounterParties).filter(
                    OTCCounterParties.id == payload['id'],
                ).delete()
            self.write(json.dumps({
                'code': 0,
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class OTCUnderlyingListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        pass

    def get(self, *args, **kwargs):
        res = []
        k_obj = KdbQuery()
        try:
            # only support four future exchange
            exch_code = {
                'A': 'shfe',
                'B': 'dce',
                'C': 'czce',
                'G': 'cffex',
            }
            exchange = self.get_argument('exchange', '')
            if not exchange:
                self.write(json.dumps({
                    'code': 400,
                    'error': 'Payload data error.',
                }))
                return
            if exchange.upper() not in exch_code:
                self.write(json.dumps({
                    'code': 400,
                    'error': 'Exchange not support.',
                }))
                return
            _exchange = exch_code[exchange.upper()]
            products = k_obj.get_products(_exchange)
            for product in products:
                res.append({
                    'name': product,
                    'lot_size': k_obj.get_products_unit(product)[product.lower()]
                })
            self.write(json.dumps({
                'code': 0,
                'data': res,
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class OTCInitSymbolsListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        pass

    def get(self, *args, **kwargs):
        kdb_obj = KdbQuery()
        try:
            product = self.get_argument('product', '')
            if not product:
                self.write(json.dumps({
                    'code': 400,
                    'error': 'Payload data error.',
                }))
                return
            trading_date = datetime.datetime.strptime(str(kdb_obj.get_trading_date()), '%Y%m%d')
            res = kdb_obj.get_symbols(product, trading_date.strftime('%Y.%m.%d'))
            if not res:
                trading_date = datetime.datetime.strptime(str(kdb_obj.get_last_trading_date()), '%Y%m%d')
                res = kdb_obj.get_symbols(product, trading_date.strftime('%Y.%m.%d'))
            self.write(json.dumps({
                'code': 0,
                'data': list(res.values()),
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class OTCVstrategiesListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = VStrategies

    def get(self, *args, **kwargs):
        res = []
        members = self._get_members()
        with mysql_sc() as sc:
            if not members:
                lines = []
            else:
                lines = sc.query(self.model).join(
                    StrategyPortfolio, StrategyPortfolio.id == self.model.portfolio_id,
                ).filter(
                    StrategyPortfolio.username.in_(members)
                )
            for line in lines:
                if line.strategy_obj:
                    res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def _get_members(self):
        headers = {'content-type': 'application/json'}
        cookies = {'sessionid': self.get_cookie('sessionid')}
        resp = requests.get(config.members_url, headers=headers, cookies=cookies)
        r = resp.json()
        if r['code'] != 0:
            return []
        us = r['data']['groups'][0]['users']
        return [u['name'] for u in us]


class OTCOptionProductsDetailHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = OTCOptionProducts

    def get(self, *args, **kwargs):
        with mysql_sc() as sc:
            o = sc.query(self.model).filter_by(id=kwargs['id']).first()
            if o:
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
            else:
                self.write(json.dumps({
                    'code': 404,
                    'error': 'Data not found.',
                }))


class OTCOptionProductsListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = OTCOptionProducts

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if 'lot_size' not in payload or 'produce_company_id' not in payload or \
           'producer_id' not in payload or 'exchange_id' not in payload or \
           'underlying' not in payload or 'current_symbol' not in payload or \
           'init_symbol' not in payload or 'contract_type' not in payload or \
           'expired_date' not in payload or 'strike_price' not in payload or 'strike_price_type' not in payload:
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            product_no = payload.get('product_no', '')
            underlying = payload['underlying']
            produce_company_id = payload['produce_company_id']
            with mysql_sc() as sc:
                if not product_no:
                    product_no = 'OTC' + str(produce_company_id).zfill(4)
                    last = sc.query(self.model).filter(
                        self.model.product_no.like(product_no + '%')
                    ).order_by(self.model.id.desc()).first()
                    if not last:
                        product_no += '000001'
                    else:
                        product_no += str(int(last.product_no[-6:]) + 1).zfill(6)
                    data = {
                        'product_no': product_no,
                        'produce_company_id': produce_company_id,
                        'producer_id': payload['producer_id'],
                        'exchange_id': payload['exchange_id'],
                        'underlying': underlying,
                        'current_symbol': payload['current_symbol'],
                        'init_symbol': payload['init_symbol'],
                        'contract_type': payload['contract_type'],
                        'expired_date': payload['expired_date'],
                        'strike_price': payload['strike_price'],
                        'strike_price_type': payload['strike_price_type'],
                        'lot_size': payload['lot_size'],
                    }
                    o = self.model(**data)
                    sc.add(o)
                else:
                    o = sc.query(self.model).filter(
                        self.model.product_no == product_no,
                    ).first()
                    if not o:
                        self.write(json.dumps({
                            'code': 500,
                            'error': 'Data not found.',
                        }))
                        return
                    o.product_no = product_no
                    o.produce_company_id = produce_company_id
                    o.producer_id = payload['producer_id']
                    o.exchange_id = payload['exchange_id']
                    o.underlying = underlying
                    o.current_symbol = payload['current_symbol']
                    o.init_symbol = payload['init_symbol']
                    o.contract_type = payload['contract_type']
                    o.expired_date = payload['expired_date']
                    o.strike_price = payload['strike_price']
                    o.strike_price_type = payload['strike_price_type']
                    o.lot_size = payload['lot_size']
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def get(self, *args, **kwargs):
        rows = []
        product_no = self.get_argument('product_no', '')
        with mysql_sc() as sc:
            if product_no:
                lines = sc.query(self.model).filter_by(product_no=product_no)
            else:
                lines = sc.query(self.model)
            for line in lines:
                rows.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': rows
        }))


class OTCOptionVolatilityListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = OTCOptionVolatility

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if 'name' not in payload:
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            model_name = payload['name']
            with mysql_sc() as sc:
                r = sc.query(self.model).filter(self.model.name == model_name).first()
                if not r:
                    data = {
                        'name': model_name,
                    }
                    o = self.model(**data)
                    sc.add(o)
                    sc.commit()
                else:
                    o = r
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def get(self, *args, **kwargs):
        rows = []
        with mysql_sc() as sc:
            lines = sc.query(self.model)
            for line in lines:
                rows.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': rows
        }))


class OTCOptionPriceListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = OTCOptionOrders

    def get(self, *args, **kwargs):
        spot_ref = self.get_argument('spot_ref', None)
        product_id = self.get_argument('product_id', None)
        opt_type = self.get_argument('opt_type', None)
        if not spot_ref or not product_id or not opt_type:
            self.write(json.dumps({
                'code': 400,
                'error': 'payload data error',
            }))
            return
        if int(opt_type) != 3:
            self.write(json.dumps({
                'code': 0,
                'data': None,
            }))
            return
        kdb_obj = KdbQuery()
        with mysql_sc() as sc:
            p = sc.query(OTCOptionProducts).filter_by(id=int(product_id)).first()
            if not p:
                self.write(json.dumps({
                    'code': 400,
                    'error': 'data not found',
                }))
                return
            contract_type = p.contract_type
            strike_price = get_price(p.strike_price_type, p.strike_price, spot_ref)
            price = max(((-1) ** contract_type) * (strike_price - float(spot_ref)), 0)
            self.write(json.dumps({
                'code': 0,
                'data': price,
            }))


class OTCOptionOrdersListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = OTCOptionOrders

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            if 'product_id' not in payload or 'vstrategy_id' not in payload or \
               'volatility_model_id' not in payload or 'counterparty_id' not in payload or \
               'trade_vol' not in payload or \
               'trd_type' not in payload or 'spot_ref' not in payload or \
               'direction' not in payload or 'weight' not in payload or \
               'delta_coff' not in payload or 'ccy' not in payload or \
               'init_volatility' not in payload or 'init_interest_rate' not in payload or \
               'opt_type' not in payload:
                self.write(json.dumps({
                    'code': 400,
                    'error': 'Payload data error.',
                }))
                return
            if payload['trd_type'] not in [1, 2, 3]:
                self.write(json.dumps({
                    'code': 400,
                    'error': u'不支持的TRD.Type',
                }))
                return

            if payload['opt_type'] not in [1, 2, 3]:
                self.write(json.dumps({
                    'code': 400,
                    'error': 'opt type error',
                }))
                return

            if payload['opt_type'] == 3 and ('price_type' not in payload or 'price' not in payload):
                self.write(json.dumps({
                    'code': 400,
                    'error': 'Payload data error.',
                }))
                return

            today_trade_date = datetime.datetime.strptime(KdbQuery().get_trading_date(), '%Y%m%d')
            if 'order_date' not in payload:
                order_date = today_trade_date.strftime('%Y-%m-%d')
            else:
                order_date = payload['order_date']
                order_date_list = order_date.split('-')
                order_date = '%s-%s-%s' % (order_date_list[0].zfill(4), order_date_list[1].zfill(2), order_date_list[2].zfill(2))
                if today_trade_date.strftime('%Y-%m-%d') > order_date:
                    self.write(json.dumps({
                        'code': 400,
                        'error': '交易起始日不能小于当前交易日.',
                    }))
                    return

            if payload['trd_type'] != 3 and payload['spot_ref'] == 0:
                self.write(json.dumps({
                    'code': 400,
                    'error': 'Payload data error.',
                }))
                return

            with mysql_sc() as sc:
                p = sc.query(OTCOptionProducts).filter(
                    OTCOptionProducts.id == payload['product_id'],
                ).first()
                if not p:
                    self.write(json.dumps({
                        'code': 400,
                        'error': 'data not found.',
                    }))
                    return
                if order_date > p.expired_date.strftime('%Y-%m-%d'):
                    self.write(json.dumps({
                        'code': 400,
                        'error': '开仓日不能大于到期日.',
                    }))
                    return

                if today_trade_date.strftime('%Y-%m-%d') < order_date:
                    if payload['spot_ref'] == 0:
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Payload data error.',
                        }))
                        return
                    else:
                        spot_ref = payload['spot_ref']
                else:
                    if payload['spot_ref'] == 0:
                        if 15 < datetime.datetime.now().hour < 21:
                            pre_trade_date = datetime.datetime.strptime(KdbQuery().get_last_trading_date(), '%Y%m%d')
                            spot_ref = KdbQuery().get_kdb_closeprice(pre_trade_date.strftime('%Y.%m.%d'), p.current_symbol)
                        else:
                            quote = query_ctp_quote()
                            symb_quote = quote.get(p.current_symbol, None)
                            if symb_quote is None:
                                spot_ref = 0
                            else:
                                spot_ref = float(symb_quote['open_price'])
                    else:
                        spot_ref = payload['spot_ref']

                if 'id' not in payload:
                    if payload['opt_type'] == 2 or payload['opt_type'] == 3:
                        if payload.get('ref_order_id', -1) <= 0:
                            self.write(json.dumps({
                                'code': 400,
                                'error': 'ref_order_id error.',
                            }))
                            return
                    data = {
                        'product_id': payload['product_id'],
                        'vstrategy_id': payload['vstrategy_id'],
                        'volatility_model_id': payload['volatility_model_id'],
                        'counterparty_id': payload['counterparty_id'],
                        'trade_vol': payload['trade_vol'],
                        'price_type': payload['price_type'],
                        'price': payload['price'],
                        'trd_type': payload['trd_type'],
                        'spot_ref': spot_ref,
                        'direction': payload['direction'],
                        'weight': payload['weight'],
                        'delta_coff': payload['delta_coff'],
                        'ccy': payload['ccy'],
                        'init_volatility': payload['init_volatility'],
                        'init_interest_rate': payload['init_interest_rate'],
                        'opt_type': payload['opt_type'],
                        'order_date': order_date,
                        'ref_order_id': payload.get('ref_order_id', -1),
                        'end_status': False,
                        'status': -1,
                    }
                    o = self.model(**data)
                    sc.add(o)
                else:
                    o = sc.query(self.model).filter_by(id=payload['id']).first()
                    if o.status != -1:
                        self.write(json.dumps({
                            'code': 500,
                            'error': '已下单的订单不可修改.'
                        }))
                        return
                    o.product_id = payload['product_id']
                    o.vstrategy_id = payload['vstrategy_id']
                    o.volatility_model_id = payload['volatility_model_id']
                    o.counterparty_id = payload['counterparty_id']
                    o.trade_vol = payload['trade_vol']
                    o.price_type = payload['price_type']
                    o.price = payload['price']
                    o.trd_type = payload['trd_type']
                    o.spot_ref = spot_ref
                    o.direction = payload['direction']
                    o.weight = payload['weight']
                    o.delta_coff = payload['delta_coff']
                    o.ccy = payload['ccy']
                    o.init_volatility = payload['init_volatility']
                    o.init_interest_rate = payload['init_interest_rate']
                    o.order_date = order_date
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                }))

        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class OTCOptionOrdersDetailHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = OTCOptionOrders

    def get(self, *args, **kwargs):
        ids = kwargs['ids'].split(',')
        if len(ids) > 1:
            self.write(json.dumps({
                'code': 404,
                'error': 'Payload data error',
            }))
            return
        with mysql_sc() as sc:
            o = sc.query(self.model).filter_by(id=ids[0]).first()
            res = o.brief()
            if res['spot_ref'] == 0 and res['price'] == 0:
                res['spot_ref'] = None
                res['price'] = None
            self.write(json.dumps({
                'code': 0,
                'data': res,
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                sc.query(self.model).filter(
                    self.model.id.in_(kwargs['ids'].split(','))
                ).delete(synchronize_session=False)
            self.write(json.dumps({
                'code': 0,
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class OTCOptionCloseOrdersDetailHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = OTCOptionOrders

    def get(self, *args, **kwargs):
        with mysql_sc() as sc:
            o = sc.query(self.model).filter_by(id=kwargs['id']).first()
            if o:
                if o.status != 2:
                    self.write(json.dumps({
                        'code': 400,
                        'error': u'只能对开仓单平仓',
                    }))
                    return
                res = o.brief()
                res['direction'] = [0, 2, 1][o.direction]
                res['opt_type'] = 2
                res['price_type'] = 1
                res['end_status'] = False
                res['status'] = -1
                res['price'] = None
                res['spot_ref'] = None
                self.write(json.dumps({
                    'code': 0,
                    'data': res,
                }))
            else:
                self.write(json.dumps({
                    'code': 404,
                    'error': 'Data not found.',
                }))


class OTCOptionDeliveryOrdersDetailHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = OTCOptionOrders

    def get(self, *args, **kwargs):
        kdb_obj = KdbQuery()
        with mysql_sc() as sc:
            o = sc.query(self.model).filter_by(id=kwargs['id']).first()
            if o:
                if o.status !=2 and o.status != 3:
                    self.write(json.dumps({
                        'code': 400,
                        'error': u'只能对持有单或平仓单行权',
                    }))
                    return
                p = sc.query(OTCOptionProducts).filter_by(id=o.product_id).first()
                contract_type = p.contract_type
                current_symbol = p.current_symbol
                trading_date = str(kdb_obj.get_trading_date())
                if trading_date <= p.expired_date.strftime('%Y%m%d'):
                    spot_ref = None
                    price = None
                else:
                    spot_ref = kdb_obj.get_kdb_closeprice(p.expired_date.strftime('%Y.%m.%d'), current_symbol)
                    if spot_ref is None:
                        quote = query_ctp_quote()
                        symb_quote = quote.get(current_symbol, None)
                        if symb_quote is None:
                            spot_ref = None
                            price = None
                        else:
                            spot_ref = float(symb_quote['last_price'])
                            strike_price = get_price(p.strike_price_type, p.strike_price, spot_ref)
                            price = max(((-1) ** contract_type) * (strike_price - spot_ref), 0)
                    else:
                        strike_price = get_price(p.strike_price_type, p.strike_price, spot_ref)
                        price = max(((-1) ** contract_type) * (strike_price - spot_ref), 0)
                res = o.brief()
                res['direction'] = [0, 2, 1][o.direction]
                res['spot_ref'] = spot_ref
                res['price'] = price
                res['price_type'] = 1
                res['opt_type'] = 3
                res['end_status'] = False
                res['status'] = -1
                refs = sc.query(self.model).filter(
                    self.model.opt_type == 3,
                    self.model.ref_order_id == kwargs['id'],
                )
                if not refs:
                    trade_vol = o.trade_vol
                else:
                    trade_vol = o.trade_vol - sum([i.trade_vol for i in refs])
                res['trade_vol'] = trade_vol
                self.write(json.dumps({
                    'code': 0,
                    'data': res,
                }))
            else:
                self.write(json.dumps({
                    'code': 404,
                    'error': 'Data not found.',
                }))


class OTCOptionSendOrdersListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = OTCOptionOrders

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if 'submit' not in payload or \
           'cancel' not in payload:
            self.write(json.dumps({
                'code': 400,
                'error': 'payload data error',
            }))
            return
        submit_ids = payload['submit']
        cancel_ids = payload['cancel']
        try:
            today_trade_date = datetime.datetime.strptime(KdbQuery().get_trading_date(), '%Y%m%d')
            with mysql_sc() as sc:
                orders = {} # k:vstrategy_id, v:[(o, 4/5)]
                for _id in submit_ids:
                    o = sc.query(self.model).filter(
                        self.model.id == _id,
                    ).first()
                    if o.status == 1:
                        continue
                    o.send_order_time = datetime.datetime.now()
                    if o.opt_type == 3 and today_trade_date.strftime('%Y-%m-%d') > o.product_obj['expired_date'].strftime('%Y-%m-%d'):
                        o.status = 4
                        o.end_status = True
                    else:
                        o.status = 0
                        sc.commit()
                        if str(o.order_date) > today_trade_date.strftime('%Y-%m-%d'):
                            continue
                        if o.vstrategy_id not in orders:
                            orders[o.vstrategy_id] = [(o, 4)]
                        else:
                            orders[o.vstrategy_id].append((o, 4))
                for _id in cancel_ids:
                    o = sc.query(self.model).filter(
                        self.model.id == _id,
                    ).first()
                    if o.status == 12:
                        continue
                    if o.opt_type == 3 and today_trade_date.strftime('%Y-%m-%d') > o.product_obj['expired_date'].strftime('%Y-%m-%d'):
                        continue
                    o.status = 11
                    sc.commit()
                    if o.vstrategy_id not in orders:
                        orders[o.vstrategy_id] = [(o, 5)]
                    else:
                        orders[o.vstrategy_id].append((o, 5))
                self.send_orders(orders, sc)
            self.write(json.dumps({
                'code': 0,
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def send_orders(self, orders, sc):
        now = datetime.datetime.now()
        if 3 <= now.hour < 9 or 15 <= now.hour < 21:
            return
        quote = query_ctp_quote()
        trading_date = KdbQuery().get_trading_date()
        for vstrategy_id, objs in orders.items():
            proc = sc.query(DeployConfs).filter(
                DeployConfs.vstrategy_id == vstrategy_id,
            ).order_by(DeployConfs.id.desc()).first()
            if not proc:
                continue
            host = proc.host
            process_id = proc.id
            msg_list = []
            for o, t in objs:
                if o.trd_type == 1:
                    price_type = 4
                elif o.trd_type == 2:
                    price_type = 0
                elif o.trd_type == 3:
                    price_type = 5
                else:
                    continue
                current_symbol = o.product_obj['current_symbol']
                symb_quote = quote.get(current_symbol, None)
                if symb_quote is None:
                    continue
                last_price = float(symb_quote['last_price'])
                expired_date = o.product_obj['expired_date']
                init_interest_rate = float(o.init_interest_rate) / 100
                spot_ref = float(o.spot_ref)
                strike_price = get_price(o.product_obj['strike_price_type'], o.product_obj['strike_price'], spot_ref)
                opt_price = float(o.price) if o.price_type == 1 else spot_ref * float(o.price) / 100
                contract_type = o.product_obj['contract_type']
                call_put = 'C' if contract_type == 1 else 'P'
                today_mat = get_trade_mat(datetime.datetime.strptime(trading_date, '%Y%m%d').strftime('%Y-%m-%d'), str(expired_date))
                next_mat = today_mat - 1.0/244 if today_mat - 1.0/244 > 0 else 0
                sigma = float(o.init_volatility) / 100
                units = get_units(o.direction, o.trade_vol)
                theta = (get_bs_price(call_put, last_price, strike_price, today_mat, init_interest_rate, sigma) - \
                        get_bs_price(call_put, last_price, strike_price, today_mat + 1.0/244, init_interest_rate, sigma)) * units
                msg = {
                    "order_type": t,
                    "serial_no": o.id,
                    "symbol": current_symbol,
                    "direction": 0 if o.direction == 1 else 1,
                    "volume": o.trade_vol * ((-1)**(1+o.direction)),
                    "price": spot_ref,
                    "price_type": price_type,
                    "c_p": 0 if contract_type == 1 else 1,
                    "expiry": int(expired_date.strftime('%Y%m%d')),
                    "strike": strike_price,
                    "sigma": round(sigma, 4),
                    "mat_next": round(next_mat, 4),
                    "mat_by_trade": round(today_mat, 4),
                    "unit_price": opt_price,
                    "delta_coff": float(o.delta_coff),
                    "theta": round(theta, 4),
                    "date": int(trading_date),
                    "tdx_date": int(trading_date),
                    "exchg": "-1",
                    "open_close": -1,
                    "speculator": -1,
                }
                msg_list.append(msg)

            if not msg_list:
                continue
            _now = datetime.datetime.now()
            seq = int(str(_now.second)+str(_now.microsecond))
            cmd = json.dumps({
                "type": 3,
                "data": {
                    "process_id": process_id,
                    "msg": msg_list,
                },
                "seq": seq,
            })

            if not rpush_redis_cmd(config.redis, 'oss:a:cmd:%s' % host, cmd):
                logger.error('send order error: host=[%s], cmd=[%s]' % (host, cmd))
                continue

            cmd = json.dumps({
                seq: [o.id for o, t in objs],
            })
            if not rpush_redis_cmd(config.redis, 'otc_seq_orders:%s' % host, cmd):
                continue

            if 9 <= _now.hour <= 15:
                day_night = 0
            else:
                day_night = 1
            _data = {
                'vstrategy_id': vstrategy_id,
                'trading_date': trading_date,
                'day_night': day_night,
                'seq_no': seq,
                'orders_data': msg_list,
            }
            o_model = OTCTradingOrders(**_data)
            sc.add(o_model)
            sc.commit()


class OTCOptionBatchOrdersDetailHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = OTCOptionOrders

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        ids = kwargs['ids'].split(',')
        payload = json.loads(str(self.request.body, 'utf-8'))
        opt_type = payload.get('opt_type', None)

        with mysql_sc() as sc:
            if opt_type == 2:
                for _id in ids:
                    o = sc.query(self.model).filter_by(id=_id).first()
                    data = {
                        'product_id': o.product_id,
                        'vstrategy_id': o.vstrategy_id,
                        'volatility_model_id': o.volatility_model_id,
                        'counterparty_id': o.counterparty_id,
                        'trade_vol': o.trade_vol,
                        'price_type': 1,
                        'price': 0,
                        'trd_type': o.trd_type,
                        'spot_ref': 0,
                        'direction': [0, 2, 1][o.direction],
                        'weight': o.weight,
                        'delta_coff': o.delta_coff,
                        'ref_order_id': o.id,
                        'ccy': o.ccy,
                        'init_interest_rate': o.init_interest_rate,
                        'init_volatility': o.init_volatility,
                        'opt_type': 2,
                        'end_status': False,
                        'status': -1,
                        'order_date': o.order_date,
                    }
                    o_model = self.model(**data)
                    sc.add(o_model)
                    sc.commit()
                self.write(json.dumps({
                    'code': 0,
                }))

            elif opt_type == 3:
                kdb_obj = KdbQuery()
                for _id in ids:
                    o = sc.query(self.model).filter_by(id=_id).first()
                    p = sc.query(OTCOptionProducts).filter_by(id=o.product_id).first()
                    contract_type = p.contract_type
                    current_symbol = p.current_symbol
                    trading_date = str(kdb_obj.get_trading_date())
                    if trading_date <= p.expired_date.strftime('%Y%m%d'):
                        spot_ref = 0.0
                        price = 0.0
                    else:
                        spot_ref = kdb_obj.get_kdb_closeprice(p.expired_date.strftime('%Y.%m.%d'), current_symbol)
                        if spot_ref is None:
                            quote = query_ctp_quote()
                            symb_quote = quote.get(current_symbol, None)
                            if symb_quote is None:
                                spot_ref = 0.0
                                price = 0.0
                            else:
                                spot_ref = float(symb_quote['last_price'])
                                strike_price = get_price(p.strike_price_type, p.strike_price, spot_ref)
                                price = max(((-1) ** contract_type) * (strike_price - spot_ref), 0)
                        else:
                            strike_price = get_price(p.strike_price_type, p.strike_price, spot_ref)
                            price = max(((-1) ** contract_type) * (strike_price - spot_ref), 0)
                    refs = sc.query(self.model).filter(
                        self.model.opt_type == 3,
                        self.model.ref_order_id == _id,
                    )
                    if not refs:
                        trade_vol = o.trade_vol
                    else:
                        trade_vol = o.trade_vol - sum([i.trade_vol for i in refs])
                    data = {
                        'product_id': o.product_id,
                        'vstrategy_id': o.vstrategy_id,
                        'volatility_model_id': o.volatility_model_id,
                        'counterparty_id': o.counterparty_id,
                        'trade_vol': trade_vol,
                        'price_type': 1,
                        'price': price,
                        'trd_type': o.trd_type,
                        'spot_ref': spot_ref,
                        'direction': [0, 2, 1][o.direction],
                        'weight': o.weight,
                        'delta_coff': o.delta_coff,
                        'ref_order_id': o.id,
                        'ccy': o.ccy,
                        'init_interest_rate': o.init_interest_rate,
                        'init_volatility': o.init_volatility,
                        'opt_type': 3,
                        'end_status': False,
                        'status': -1,
                        'order_date': o.order_date,
                    }
                    o_model = self.model(**data)
                    sc.add(o_model)
                    sc.commit()
                self.write(json.dumps({
                    'code': 0,
                }))

            else:
                self.write(json.dumps({
                    'code': 404,
                    'error': 'Payload data error.',
                }))


class OTCOptionEvsListHandlerV2(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.no_login = ['get']

    def get(self, *args, **kwargs):
        """
        @trade_date: '20000101'
        """
        _trade_date = self.get_argument('trade_date', None)
        _day_night = self.get_argument('day_night', None)
        if _trade_date is None:
            self.write(json.dumps({
                'code': 404,
                'error': 'Get argument error',
            }))
            return
        today_trade_date = datetime.datetime.strptime(KdbQuery().get_trading_date(), '%Y%m%d')
        trade_date = datetime.datetime.strptime(_trade_date, '%Y%m%d')
        pre_trade_date = datetime.datetime.strptime(KdbQuery().query_pre_tradedate(_trade_date), '%Y%m%d')

        if _day_night is None or _day_night not in ['0', '1']:
            if today_trade_date == trade_date:
                now = datetime.datetime.now()
                day_night = 0 if now.hour < 15 else 1
            else:
                day_night = 1
        else:
            day_night = int(_day_night)

        content = []
        with mysql_sc() as sc:
            ev_obj = sc.query(OTCEvDatas).filter(
                OTCEvDatas.trade_date == trade_date,
                OTCEvDatas.day_night == day_night,
            ).first()
            if ev_obj:
                content = ev_obj.content
            else:
                ev_o = sc.query(OTCEvDatas).filter(
                    OTCEvDatas.trade_date == trade_date,
                    OTCEvDatas.day_night == 1,
                ).first()
                if day_night == 0 and ev_o:
                    content = ev_o.content
                    for line_data in content:
                        order_obj = sc.query(OTCOptionOrders).filter_by(id=line_data['instr_id']).first()
                        if order_obj.trading_time:
                            line_data['hedged'] = 'Y'
                            if line_data['trd_type'] == 'nightopen':
                                line_data['trd_type'] = 'normal'
                else:
                    lines = sc.query(OTCOptionOrders).join(
                        OTCOptionProducts, OTCOptionProducts.id == OTCOptionOrders.product_id,
                    ).filter(
                        OTCOptionProducts.expired_date >= trade_date.strftime('%Y-%m-%d'),
                        OTCOptionOrders.order_date <= trade_date.strftime('%Y-%m-%d'),
                        or_(OTCOptionOrders.status == 0,
                            OTCOptionOrders.status == 1,
                            OTCOptionOrders.status == 2,
                            OTCOptionOrders.status == 3,
                            OTCOptionOrders.status == 4,
                        ),
                    )
                    for line in lines:
                        if line.ref_order_id > 0:
                            origin_order = sc.query(OTCOptionOrders).filter_by(id=line.ref_order_id).first()
                            if not origin_order:
                                self.write(json.dumps({
                                    'code': 500,
                                    'error': 'mysql data error.'
                                }))
                                return
                        if line.trd_type == 1:
                            ev_trd_type = 'normal'
                            if line.ref_order_id > 0:
                                strike = get_price(origin_order.product_obj['strike_price_type'], origin_order.product_obj['strike_price'], origin_order.spot_ref)
                            else:
                                strike = get_price(line.product_obj['strike_price_type'], line.product_obj['strike_price'], line.spot_ref)
                        elif line.trd_type == 2:
                            if trade_date.strftime('%Y-%m-%d') > line.order_date.strftime('%Y-%m-%d'):
                                continue
                            ev_trd_type = 'preset'
                            if line.ref_order_id > 0:
                                strike = get_price(origin_order.product_obj['strike_price_type'], origin_order.product_obj['strike_price'], origin_order.spot_ref)
                            else:
                                strike = get_price(line.product_obj['strike_price_type'], line.product_obj['strike_price'], line.spot_ref)
                        elif line.trd_type == 3:
                            if line.trading_time:
                                ev_trd_type = 'normal'
                            else:
                                ev_trd_type = 'nightopen'
                            if line.ref_order_id > 0:
                                strike = float(origin_order.spot_ref)
                            else:
                                strike = float(line.spot_ref)
                        else:
                            self.write(json.dumps({
                                'code': 400,
                                'error': 'TRD.Type not supported.'
                            }))
                            return
                        today_mat = get_trade_mat(trade_date.strftime('%Y-%m-%d'), str(line.product_obj['expired_date']))
                        next_mat = today_mat - 1.0/244 if today_mat - 1.0/244 > 0 else 0
                        pre_mat = today_mat + 1.0/244
                        pre_close_price = KdbQuery().get_kdb_closeprice(pre_trade_date.strftime('%Y.%m.%d'), line.product_obj['current_symbol'])
                        if not pre_close_price:
                            self.write(json.dumps({
                                'code': 501,
                                'error': 'query kdb close price error,'
                            }))
                            return
                        call_put = 'C' if line.product_obj['contract_type'] == 1 else 'P'
                        if line.ref_order_id > 0:
                            init_volatility = float(origin_order.init_volatility) / 100
                        else:
                            init_volatility = float(line.init_volatility) / 100
                        init_interest_rate = float(line.init_interest_rate) / 100
                        volume = int(line.trade_vol) * ((-1) ** (1 + line.direction))
                        theta = (get_bs_price(call_put, pre_close_price, strike, today_mat, init_interest_rate, init_volatility) - \
                                get_bs_price(call_put, pre_close_price, strike, pre_mat, init_interest_rate, init_volatility)) * volume
                        if trade_date.strftime('%Y-%m-%d') == line.order_date.strftime('%Y-%m-%d'):
                            opt_price = float(line.price) if line.price_type == 1 else float(line.spot_ref) * float(line.price) / 100
                        else:
                            opt_price = get_bs_price(call_put, pre_close_price, strike, pre_mat, init_interest_rate, init_volatility)
                        line_data = {
                            'instr_id': line.id,
                            'trade_date': trade_date.strftime('%Y%m%d'),
                            'delta_coff': float(line.delta_coff),
                            'underlying': line.product_obj['current_symbol'],
                            'call_put': call_put,
                            'expiry': line.product_obj['expired_date'].strftime('%Y%m%d'),
                            'strike': round(strike, 2),
                            'volume': volume,
                            'buy_sell': 'Buy' if line.direction == 1 else 'Sell',
                            'sigma': round(init_volatility, 4),
                            'mat_next': round(next_mat, 4),
                            'mat_by_trade': round(today_mat, 4),
                            'trd_type': ev_trd_type,
                            'hedged': 'Y' if line.trading_time else 'N',
                            'alpha': 'No',
                            'price': round(opt_price, 2),
                            'trx_date': line.order_date.strftime('%Y%m%d'),
                            'spot_ref': round(float(line.spot_ref), 2),
                            'theta': round(theta, 2),
                        }
                        content.append(line_data)
                data = {
                    'trade_date': trade_date,
                    'day_night': day_night,
                    'content': content,
                }
                sc.add(OTCEvDatas(**data))
        self.write(json.dumps({
            'code': 0,
            'data': content,
        }))


class OTCOptionEvsListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.no_login = ['get']

    def get(self, *args, **kwargs):
        """
        @trade_date: '20000101'
        """
        _trade_date = self.get_argument('trade_date', None)
        if _trade_date is None:
            self.write(json.dumps({
                'code': 404,
                'error': 'Get argument error',
            }))
            return
        today_trade_date = datetime.datetime.strptime(KdbQuery().get_trading_date(), '%Y%m%d')
        trade_date = datetime.datetime.strptime(_trade_date, '%Y%m%d')
        pre_trade_date = datetime.datetime.strptime(KdbQuery().query_pre_tradedate(_trade_date), '%Y%m%d')

        if today_trade_date == trade_date:
            now = datetime.datetime.now()
            day_night = 0 if now.hour < 15 else 1
        else:
            day_night = 1

        data = []
        with mysql_sc() as sc:
            ev_objs = sc.query(OTCEvContents).filter(
                OTCEvContents.trade_date == trade_date,
                OTCEvContents.day_night == day_night,
            ).all()
            if ev_objs:
                for ev_obj in ev_objs:
                    data.append(ev_obj.to_dict())
            else:
                ev_objs = sc.query(OTCEvContents).filter(
                    OTCEvContents.trade_date == trade_date,
                    OTCEvContents.day_night == 1,
                ).all()
                if day_night == 0 and ev_objs:
                    for ev_obj in ev_objs:
                        line_data = ev_obj.to_dict()
                        line_data['day_night'] = 0
                        order_obj = sc.query(OTCOptionOrders).filter_by(id=line_data['instr_id']).first()
                        if order_obj:
                            if order_obj.trading_time:
                                line_data['hedged'] = 'Y'
                        sc.add(OTCEvContents(**line_data))
                    sc.commit()
                else: 
                    lines = sc.query(OTCOptionOrders).join(
                        OTCOptionProducts, OTCOptionProducts.id == OTCOptionOrders.product_id,
                    ).filter(
                        OTCOptionProducts.expired_date >= trade_date.strftime('%Y-%m-%d'),
                        OTCOptionOrders.order_date <= trade_date.strftime('%Y-%m-%d'),
                        or_(OTCOptionOrders.status == 0,
                            OTCOptionOrders.status == 1,
                            OTCOptionOrders.status == 2,
                            OTCOptionOrders.status == 3,
                            OTCOptionOrders.status == 4,
                        ),
                    )

                    for line in lines:
                        if line.trd_type == 1:
                            ev_trd_type = 'normal'
                            strike = get_price(line.product_obj['strike_price_type'], line.product_obj['strike_price'], line.spot_ref)
                        elif line.trd_type == 2:
                            ev_trd_type = 'preset'
                            strike = get_price(line.product_obj['strike_price_type'], line.product_obj['strike_price'], line.spot_ref)
                            if trade_date.strftime('%Y-%m-%d') > line.order_date.strftime('%Y-%m-%d'):
                                continue
                        elif line.trd_type == 3:
                            if line.trading_time:
                                ev_trd_type = 'normal'
                            else:
                                ev_trd_type = 'nightopen'
                            strike = float(line.spot_ref)
                        else:
                            self.write(json.dumps({
                                'code': 400,
                                'error': 'TRD.Type not supported.'
                            }))
                        today_mat = get_trade_mat(trade_date.strftime('%Y-%m-%d'), str(line.product_obj['expired_date']))
                        next_mat = today_mat - 1.0/244 if today_mat - 1.0/244 > 0 else 0
                        pre_mat = today_mat + 1.0/244
                        pre_close_price = KdbQuery().get_kdb_closeprice(pre_trade_date.strftime('%Y.%m.%d'), line.product_obj['current_symbol'])
                        if not pre_close_price:
                            self.write(json.dumps({
                                'code': 501,
                                'error': 'query kdb close price error,'
                            }))
                            return
                        call_put = 'C' if line.product_obj['contract_type'] == 1 else 'P'
                        theta = get_bs_price(call_put, pre_close_price, strike, today_mat, float(line.init_interest_rate), float(line.init_volatility)) - \
                                get_bs_price(call_put, pre_close_price, strike, pre_mat, float(line.init_interest_rate), float(line.init_volatility))
                        if trade_date.strftime('%Y-%m-%d') == line.order_date.strftime('%Y-%m-%d'):
                            opt_price = float(line.price) if line.price_type == 1 else float(line.spot_ref) * float(line.price) / 100
                        else:
                            opt_price = get_bs_price(call_put, pre_close_price, strike, pre_mat, float(line.init_interest_rate), float(line.init_volatility))
                        line_data = {
                            'instr_id': line.id,
                            'trade_date': trade_date.strftime('%Y%m%d'),
                            'delta_coff': float(line.delta_coff),
                            'underlying': line.product_obj['current_symbol'],
                            'call_put': call_put,
                            'expiry': line.product_obj['expired_date'].strftime('%Y%m%d'),
                            'strike': round(strike, 2),
                            'volume': int(line.trade_vol) * ((-1) ** (1 + line.direction)),
                            'buy_sell': 'Buy' if line.direction == 1 else 'Sell',
                            'sigma': round(float(line.init_volatility), 4),
                            'mat_next': round(next_mat, 4),
                            'mat_by_trade': round(today_mat, 4),
                            'trd_type': ev_trd_type,
                            'hedged': 'Y' if line.trading_time else 'N',
                            'alpha': 'No',
                            'price': round(opt_price, 2),
                            'trx_date': line.order_date.strftime('%Y%m%d'),
                            'spot_ref': round(float(line.spot_ref), 2),
                            'theta': round(theta, 2),
                            'day_night': day_night,
                        }
                        sc.add(OTCEvContents(**line_data))
                    sc.commit()
                ev_objs = sc.query(OTCEvContents).filter(
                    OTCEvContents.trade_date == trade_date,
                    OTCEvContents.day_night == day_night,
                ).all()
                for ev_obj in ev_objs:
                    data.append(ev_obj.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': data,
        }))


class OTCOrdersDownloadListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.no_login = ['get']

    def get(self, *args, **kwargs):
        try:
            finished = int(self.get_argument('finished', '0'))
            data = self._get_order_data(finished)
            self._write_to_csv(data, finished)
            #self.write(json.dumps({
            #    'code': 0,
            #}))
        except Exception as e:
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def _downfile(self, df, filename):
        strIO = StringIO()
        strIO.write(str(codecs.BOM_UTF8, encoding='utf-8'))
        df.to_csv(strIO, index=False, encoding='utf-8')
        strIO.seek(0)
        self.set_header('Content-Type', 'application/octet-stream')
        self.set_header('Content-Disposition', 'attachment; filename=' + filename)
        self.write(strIO.read())
        self.finish()
        return

    def _write_to_csv(self, data, finished):
        _date = datetime.datetime.now().strftime('%Y%m%d')
        if finished:
            filename = 'done_orders_%s.csv' % _date
        else:
            filename = 'pos_orders_%s.csv' % _date
        with open(filename, 'w', encoding='utf-8') as f:
            keys = [
                u'标签', u'ID', u'开仓日期', u'标的', u'期权类型',
                u'到期日', u'货币', u'期货参考价', u'执行价', u'数量',
                u'期权单价', u'总权利金', u'交易方', u'权重',]
            values = [[d[k] for k in keys] for d in data]
            df = pd.DataFrame(values, columns=keys)
            return self._downfile(df, filename)

    def _get_order_data(self, finished):
        data = []
        with mysql_sc() as sc:
            rows = sc.query(OTCOptionOrders).filter(
                OTCOptionOrders.status == 2,
                OTCOptionOrders.finished == finished,
            )
            for r in rows:
                line = self._get_line_data(r)
                if line is None:
                    continue
                data.append(line)
            rows = sc.query(OTCOptionOrders).filter(
                OTCOptionOrders.status == 3,
                OTCOptionOrders.finished == finished,
            ).order_by(
                OTCOptionOrders.id.desc()
            )
            for r in rows:
                line = self._get_line_data(r)
                if line is None:
                    continue
                for i, d in enumerate(data):
                    if r.ref_order_id == d['ID']:
                        data.insert(i + 1, line)
                        break
            rows = sc.query(OTCOptionOrders).filter(
                OTCOptionOrders.status == 4,
                OTCOptionOrders.finished == finished,
            ).order_by(
                OTCOptionOrders.id.desc()
            )
            for r in rows:
                line = self._get_line_data(r)
                if line is None:
                    continue
                for i, d in enumerate(data):
                    if r.ref_order_id == d['ID']:
                        data.insert(i + 1, line)
                        break
        return data

    def _get_line_data(self, r):
        _trd_type = {
            1: u'市价成交',
            2: u'盘中挂单，当天不击穿则失效',
            3: u'夜盘开盘成交',
        }
        opt_price = float(r.price) if r.price_type == 1 else float(r.spot_ref) * float(r.price) / 100
        strike_price = get_price(r.product_obj['strike_price_type'], r.product_obj['strike_price'], r.spot_ref)
        line = {
            u'标签': _trd_type[r.trd_type],
            u'ID': r.id,
            u'开仓日期': r.order_date.strftime('%Y/%m/%d'),
            u'标的': r.product_obj['current_symbol'],
            u'期权类型': 'C' if r.product_obj['contract_type'] == 1 else 'P',
            u'到期日': r.product_obj['expired_date'].strftime('%Y/%m/%d'),
            u'货币': r.ccy,
            u'期货参考价': round(float(r.spot_ref), 2),
            u'执行价': round(strike_price, 2),
            u'数量': (-1) ** (1 + r.direction) * int(r.trade_vol),
            u'期权单价': round(opt_price, 2),
            u'总权利金': round(get_cash(r.direction, r.trade_vol, opt_price)),
            u'交易方': r.counterparty_obj['name'],
            u'权重': round(float(r.weight), 2),
        }
        return line


class OTCPostionOrdersDetailHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.product_fields = {
            'exchange_id': 'exchange_id',
            'underlying': 'underlying',
            'init_symbol': 'init_symbol',
            'contract_type': 'contract_type',
            'lot_size': 'lot_size',
            'strike_price': 'strike_price',
            'expired_date': 'expired_date',
        }
        self.order_fields = {
            'init_volatility': 'init_volatility',
            'init_interest_rate': 'init_interest_rate',
            'counterparty_id': 'counterparty_id',
            'trd_type': 'trd_type',
            'spot_ref': 'spot_ref',
            'trade_vol': 'trade_vol',
            'price': 'price',
            'ccy': 'ccy',
            'weight': 'weight',
            'delta_coff': 'delta_coff',
            'direction': 'direction',
            'order_date': 'order_date',
        }

    def get(self, *args, **kwargs):
        with mysql_sc() as sc:
            o = sc.query(OTCOptionOrders).filter_by(id=kwargs['id']).first()
            if not o:
                self.write(json.dumps({
                    'code': 400,
                    'error': 'data not found.',
                }))
                return
            self.write(json.dumps({
                'code': 0,
                'data': o.position_detail(),
            }))

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                o = sc.query(OTCOptionOrders).filter_by(id=kwargs['id']).first()
                if not o:
                    self.write(json.dumps({
                        'code': 400,
                        'error': 'data not found.',
                    }))
                    return
                p = sc.query(OTCOptionProducts).filter_by(id=o.product_id).first()
                if not p:
                    self.write(json.dumps({
                        'code': 400,
                        'error': 'data not found.',
                    }))
                    return
                for k, v in self.product_fields.items():
                    if v in payload:
                        setattr(p, k, payload[v])
                        if v == 'init_symbol':
                            setattr(p, 'current_symbol', payload[v])
                        if v == 'strike_price':
                            setattr(p, 'strike_price_type', 1)
                for k, v in self.order_fields.items():
                    if v in payload:
                        setattr(o, k, payload[v])
                        if v == 'price':
                            setattr(o, 'price_type', 1)

            self.write(json.dumps({
                'code': 0,
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class OTCTradingOrdersListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = OTCTradingOrders
        self.no_login = ['get']

    def get(self, *args, **kwargs):
        trade_date = self.get_argument('trade_date', None)
        day_night = self.get_argument('day_night', None)
        vstrategy_id = self.get_argument('vstrategy_id', None)
        if trade_date is None or vstrategy_id is None or day_night is None or day_night not in ['0', '1']:
            self.write(json.dumps({
                'code': 400,
                'error': 'payload data error.',
            }))
            return
        with mysql_sc() as sc:
            lines = sc.query(self.model).filter(
                self.model.trading_date == trade_date,
                self.model.day_night == day_night,
                self.model.vstrategy_id == vstrategy_id,
            )
            res = [l.to_dict() for l in lines]
            self.write(json.dumps({
                'code': 0,
                'data': res,
            }))


#-*- coding: utf-8 -*-

import threading
import time
import requests
import tornado.ioloop
import tornado.web
from handlers import *


port = 18801

urls = [
    (r"/api/v1/otc/common/exchanges$", ExchangesListHandler),
    (r"/api/v1/otc/common/employees$", OTCEmployeesListHandler),
    (r"/api/v1/otc/common/counterparties$", OTCCounterPartiesListHandler),
    (r"/api/v1/otc/common/underlyings$", OTCUnderlyingListHandler),
    (r"/api/v1/otc/common/symbols$", OTCInitSymbolsListHandler),
    (r"/api/v1/otc/common/vstrategis$", OTCVstrategiesListHandler),
    (r"/api/v1/otc/products$", OTCOptionProductsListHandler),
    (r"/api/v1/otc/products/(?P<id>\d+)$", OTCOptionProductsDetailHandler),
    (r"/api/v1/otc/volatilities$", OTCOptionVolatilityListHandler),
    (r"/api/v1/otc/orders$", OTCOptionOrdersListHandler),
    (r"/api/v1/otc/orders/(?P<ids>[0-9\,]*)$", OTCOptionOrdersDetailHandler),
    (r"/api/v1/otc/send/orders$", OTCOptionSendOrdersListHandler),
    (r"/api/v1/otc/close/orders/(?P<id>\d+)$", OTCOptionCloseOrdersDetailHandler),
    (r"/api/v1/otc/delivery/orders/(?P<id>\d+)$", OTCOptionDeliveryOrdersDetailHandler),
    (r"/api/v1/otc/batch/orders/(?P<ids>[0-9\,]*)$", OTCOptionBatchOrdersDetailHandler),
    (r"/api/v1/otc/price$", OTCOptionPriceListHandler),
    (r"/api/v1/otc/option_evs$", OTCOptionEvsListHandlerV2),
    (r"/api/v1/otc/download/orders$", OTCOrdersDownloadListHandler),
    (r"/api/v1/otc/position/orders/(?P<id>\d+)$", OTCPostionOrdersDetailHandler),
    (r"/api/v1/otc/option_orders$", OTCTradingOrdersListHandler),
]


class Application(tornado.web.Application):
    def __init__(self, handlers):
        self.logger = logger
        self.cfg = config
        tornado.web.Application.__init__(self, handlers)


if __name__ == "__main__":
    app = Application(urls)
    app.listen(port)
    tornado.ioloop.IOLoop.current().start()


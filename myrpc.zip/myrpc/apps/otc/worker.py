# encoding: utf-8

import os
import copy
import json
import requests
import datetime
import time
import redis
from tornado import gen
from log import logger
from redis_api import RedisConnector, MessageSet, MessageHashMap, MessageList, Singleton
from utils import *
from models import *
from config import *
from kdb_api import KdbQuery
from computing import *


class BaseWorker(object):

    def __init__(self, seconds=0.1):
        self.seconds = seconds

    @gen.coroutine
    def work_process(self):
        pass

    @gen.coroutine
    def run(self):
        while True:
            nxt = gen.sleep(self.seconds)
            yield self.work_process()
            yield nxt


class OTCTradeOrdersWorker(BaseWorker):

    def __init__(self, seconds=0.5):
        self.seconds = seconds
        self._rds = redis.Redis(config.redis['host'], config.redis['port'])
        self.seq_orders = {}

    def handle_agent_rsp(self, rsp, order_ids):
        ret = json.loads(str(rsp, 'utf-8'))['data']['return']
        if ret == 0:
            with mysql_sc() as sc:
                for _id in order_ids:
                    o = sc.query(OTCOptionOrders).filter(
                        OTCOptionOrders.id == _id,
                    ).first()
                    if not o:
                        continue
                    if o.status == 0:
                        o.status = 1
                    else:
                        o.status = 12
        else:
            with mysql_sc() as sc:
                sc.query(OTCOptionOrders).filter(
                    OTCOptionOrders.id.in_(order_ids),
                    OTCOptionOrders.status == 0,
                ).update({
                    OTCOptionOrders.status: -2,
                }, synchronize_session=False)

                sc.query(OTCOptionOrders).filter(
                    OTCOptionOrders.id.in_(order_ids),
                    OTCOptionOrders.status == 11,
                ).update({
                    OTCOptionOrders.status: 14,
                }, synchronize_session=False)

    def handle_strat_order_rsp(self, msg, quote):
        now = datetime.datetime.now()
        order_id = msg['serial_no']
        result = msg['result']
        with mysql_sc() as sc:
            o = sc.query(OTCOptionOrders).filter(
                OTCOptionOrders.id == order_id,
            ).first()
            if not o:
                return
            if result == 0:
                if o.opt_type == 1:
                    o.status = 2
                    o.trading_time = now
                    o.closing_fut_price = msg['price']
                    o.delta_coff = 0
                elif o.opt_type == 2:
                    o.status = 3
                    o.trading_time = now
                    o.closing_fut_price = msg['price']
                    o.delta_coff = 0
                else:
                    o.status = 4
                    o.trading_time = now
                    o.closing_fut_price = msg['price']
                    o.delta_coff = 0
                if o.trd_type == 3:
                    current_symbol = o.product_obj['current_symbol']
                    ctp_symbol = quote.get(current_symbol, None)
                    if ctp_symbol is None:
                        o.spot_ref = 0
                    else:
                        spot_ref = float(ctp_symbol['open_price'])
                        o.spot_ref = spot_ref
            else:
                o.status = -2

    def handle_strat_cancel_rsp(self, msg):
        order_id = msg['serial_no']
        result = msg['result']
        with mysql_sc() as sc:
            o = sc.query(OTCOptionOrders).filter(
                OTCOptionOrders.id == order_id,
            ).first()
            if not o:
                return
            if result == 0:
                o.status = 13
            else:
                if o.status == 12:
                    o.status = 14

    @gen.coroutine
    def work_process(self):
        try:
            quote = query_ctp_quote()
            hosts = self._rds.smembers('a:oss:hosts')
            for h in hosts:
                h = str(h, 'utf-8')
                self.seq_orders.setdefault(h, {})
                _q = 'otc_seq_orders:%s' % h
                rows = self._rds.lrange(_q, 0, -1)
                self._rds.delete(_q)
                for d in rows:
                    data = json.loads(str(d, 'utf-8'))
                    self.seq_orders[h] = dict(self.seq_orders[h], **data)

            for host, seq_dict in self.seq_orders.items():
                new_dict = {}
                for seq, order_ids in seq_dict.items():
                    rsp = lpop_redis_cmd(config.redis, 'a:oss:rsp:%s' % host, int(seq))
                    if not rsp:
                        new_dict[seq] = order_ids
                        continue
                    self.handle_agent_rsp(rsp, order_ids)
                self.seq_orders[host] = new_dict

            for h in hosts:
                h = str(h, 'utf-8')
                _q = 'a:oss:order:rsp:%s' % h
                rows = self._rds.lrange(_q, 0, -1)
                self._rds.delete(_q)
                if rows:
                    logger.info('order rsp: %s, %s' % (_q, rows))
                for d in rows:
                    d = json.loads(str(d, 'utf-8'))
                    print(d)
                    rsp_type = d['type']
                    data = d['data']
                    if rsp_type == 3:
                        for msg in data['msg']:
                            if msg['order_type'] == 4:
                                self.handle_strat_order_rsp(msg, quote)
                            elif msg['order_type'] == 5:
                                self.handle_strat_cancel_rsp(msg)
                            else:
                                continue
                    elif rsp_type == 4:
                        with mysql_sc() as sc:
                            local_time = data['local_time']
                            o = sc.query(OTCTradingOrders).filter_by(seq_no=d['seq']).first()
                            if o:
                                o.local_time = local_time
                                o.exchange_time = local_time
                                o.process_id = data['process_id']
                                o.serial_no = data['serial_no']
                                sc.query(OTCOptionOrders).filter(
                                    OTCOptionOrders.id.in_(data['serial_no']),
                                ).update({
                                    OTCOptionOrders.status: 6
                                }, synchronize_session=False)
        except Exception as e:
            logger.error(str(e))


class OTCCheckingOrdersWorker(BaseWorker):

    def __init__(self, seconds=1):
        self.seconds = seconds
        self.model = OTCOptionOrders

    @gen.coroutine
    def work_process(self):
        try:
            in_data = []
            out_data = []
            msg_type = 'otc_checking_orders'
            current_trade_date = str(KdbQuery().get_trading_date())
            _trd_type = {
                1: u'normal',
                2: u'preset',
                3: u'nightopen',
                4: u'对手价',
                5: u'最新价',
            }
            _opt_type = {
                2: u'平仓',
                3: u'行权',
                1: u'开仓',
            }
            _status = {
                1: u'暂未成交',
                0: u'系统正在处理',
                6: u'Agent正在处理',
                -1: u'未下单',
                -2: u'处理失败',
                11: u'正在处理撤单',
                12: u'正在撤销',
                13: u'已撤单',
                14: u'撤单失败',
            }
            headers = [
                {'title': u'订单ID', 'prop': 'id', 'sortable': True},
                {'title': u'产品平台ID', 'prop': 'product_no', 'sortable': True},
                {'title': u'报/撤单', 'prop': 'order_type', 'sortable': True},
                {'title': u'订单状态', 'prop': 'status', 'sortable': True},
                {'title': u'订单类型', 'prop': 'opt_type', 'sortable': True},
                {'title': u'交易起始日', 'prop': 'order_date', 'sortable': True},
                {'title': u'TRD.Type', 'prop': 'trd_type', 'sortable': True},
                {'title': u'标的', 'prop': 'underlying', 'sortable': True},
                {'title': u'期权类型', 'prop': 'call_put', 'sortable': True},
                {'title': u'到期日', 'prop': 'expiry', 'sortable': True},
                {'title': u'货币', 'prop': 'ccy', 'sortable': True},
                {'title': u'期货参考价', 'prop': 'spot_ref', 'sortable': True},
                {'title': u'执行价', 'prop': 'k', 'sortable': True},
                {'title': u'数量', 'prop': 'units', 'sortable': True},
                {'title': u'期权单价', 'prop': 'price', 'sortable': True},
                {'title': u'总权利金', 'prop': 'cash', 'sortable': True},
                {'title': u'交易方', 'prop': 'client_name', 'sortable': True},
                {'title': u'权重', 'prop': 'weight', 'sortable': True},
                {'title': u'DELTA COFF', 'prop': 'delta_coff', 'sortable': True},
            ]

            with mysql_sc() as sc:
                rows = sc.query(self.model).filter(
                    or_(
                        self.model.status <= 1,
                        self.model.status >= 11,
                    ),
                )
                for r in rows:
                    current_symbol = r.product_obj['current_symbol']
                    call_put = 'C' if r.product_obj['contract_type'] == 1 else 'P'
                    expired_date = str(r.product_obj['expired_date'])
                    direction = r.direction
                    strike_price = get_price(r.product_obj['strike_price_type'], r.product_obj['strike_price'], r.spot_ref)
                    units = get_units(direction, r.trade_vol)
                    price = float(r.price) if r.price_type == 1 else float(r.spot_ref) * float(r.price) / 100
                    line = {
                        'id': r.id,
                        'product_no': r.product_obj.get('product_no', None),
                        'trd_type': _trd_type.get(r.trd_type, None),
                        'underlying': current_symbol,
                        'call_put': call_put,
                        'expiry': expired_date,
                        'ccy': r.ccy,
                        'spot_ref': float(r.spot_ref),
                        'k': strike_price,
                        'units': units,
                        'price': price,
                        'cash': round(get_cash(direction, r.trade_vol, price), 4),
                        'client_name': r.counterparty_obj.get('name', None),
                        'weight': float(r.weight),
                        'delta_coff': float(r.delta_coff),
                        'opt_type': _opt_type.get(r.opt_type, None),
                        'status': _status.get(r.status, None),
                        'order_type': 1,
                        'order_date': r.order_date.strftime('%Y-%m-%d'),
                    }
                    if r.status == 13:
                        out_data.append(line)
                    else:
                        if r.status == 1 or r.status == 0 or r.status == 11 or r.status == 12:
                            if current_trade_date > r.order_date.strftime('%Y%m%d'):
                                line['status'] = u'过期'
                                out_data.append(line)
                            else:
                                in_data.append(line)
                        else:
                            in_data.append(line)
            res = {
                'headers': headers,
                'data': in_data + out_data,
            }
            send_websoket(msg_type, res)
        except Exception as e:
            logger.error(str(e))


class OTCOptionOrdersWorker(BaseWorker):

    def __init__(self, seconds=2):
        self.seconds = seconds
        self.model = OTCOptionOrders
        self.computed = False
        self.init_kdb_date()

    def init_kdb_date(self):
        k = KdbQuery()
        self.is_traded = k.check_day_monitor(datetime.datetime.now().strftime('%Y-%d-%m'))
        self.curr_trade_date = datetime.datetime.strptime(k.get_trading_date(), '%Y%m%d')
        self.next_trade_date = datetime.datetime.strptime(k.get_next_trading_date(), '%Y%m%d')
        self.pre_trade_date = datetime.datetime.strptime(k.get_last_trading_date(), '%Y%m%d')
        self.pre2_trade_date = datetime.datetime.strptime(k.get_last_last_trading_date(), '%Y%m%d')

    def cron_update_data(self, quote):
        now = datetime.datetime.now()
        if (now.hour == 15 and now.minute == 5) or (now.hour == 21 and now.minute == 5):
            if not self.computed:
                self.computed = True
                self.init_kdb_date()
                with mysql_sc() as sc:
                    lines = sc.query(OTCOptionOrders).filter(
                        OTCOptionOrders.finished == False,
                    )
                    for line in lines:
                        symbol = line.product_obj['current_symbol']
                        if quote.get(symbol, None) is None:
                            continue
                        self.update_order_data(line, quote[symbol])
        else:
            self.computed = False

    def update_order_data(self, r, quote):
        if not quote:
            return
        last_price = float(quote['last_price'])
        open_price = float(quote['open_price'])
        pre_close_price = float(quote['pre_close_price'])

        call_put = 'C' if r.product_obj['contract_type'] == 1 else 'P'
        symbol = r.product_obj['current_symbol']
        expired_date = r.product_obj['expired_date']
        order_date = r.order_date
        rate = float(r.init_interest_rate) / 100
        spot_ref = float(r.spot_ref)
        strike_price = get_price(r.product_obj['strike_price_type'], r.product_obj['strike_price'], spot_ref)
        _expired_date = datetime.datetime.strptime(str(expired_date), '%Y-%m-%d')
        _order_date = datetime.datetime.strptime(str(order_date), '%Y-%m-%d')
        today_mat = get_trade_mat(self.curr_trade_date.strftime('%Y-%m-%d'), str(expired_date))
        yesterday_mat = get_trade_mat(self.pre_trade_date.strftime('%Y-%m-%d'), str(expired_date))
        order_mat = get_trade_mat(str(order_date), str(expired_date))
        calendar_mat = get_calendar_mat(str(order_date), str(expired_date))
        price = float(r.price) if r.price_type == 1 else spot_ref * float(r.price) / 100
        units = get_units(r.direction, r.trade_vol)
        sigma = get_sigma(call_put, spot_ref, strike_price, order_mat, rate, price)
        calendar_sigma = get_sigma(call_put, spot_ref, strike_price, calendar_mat, rate, price)
        end_date, is_expired = get_end_date(expired_date, r.trading_time, self.curr_trade_date)
        closing_cash = float(r.closing_cash) if r.closing_cash else 0.0
        _valuation_last = valuation_last(is_expired, end_date, order_date.strftime('%Y%m%d'), closing_cash, price, units, call_put, pre_close_price, strike_price, yesterday_mat, rate, sigma)
        _valuation_d_time = valuation_d_time(is_expired, end_date, order_date.strftime('%Y%m%d'), closing_cash, price, units, call_put, pre_close_price, strike_price, today_mat, rate, sigma)
        _valuation_d_sigma = valuation_d_sigma(is_expired, end_date, order_date.strftime('%Y%m%d'), closing_cash, price, units, spot_ref, call_put, pre_close_price, strike_price, today_mat, rate, sigma)
        _pnl_yesterday = get_cash(r.direction, r.trade_vol, price) + _valuation_last
        _pnl_theta = _valuation_d_time - _valuation_last
        _pnl_vega = _valuation_d_sigma - _valuation_d_time

        r.pre_close_price = pre_close_price
        r.today_mat = today_mat
        r.yesterday_mat = yesterday_mat
        r.order_trade_mat = order_mat
        r.trade_sigma = sigma
        r.calendar_sigma = calendar_sigma
        r.valuation_last = _valuation_last
        r.valuation_d_time = _valuation_d_time
        r.valuation_d_sigma = _valuation_d_sigma
        r.pnl_yesterday = _pnl_yesterday
        r.pnl_theta = _pnl_theta
        r.pnl_vega = _pnl_vega

    def get_status(self, status, ref_order_id):
        if status == 2:
            return 2
        elif status == 3:
            return 4
        elif status == 4:
            return 5
        else:
            if ref_order_id > 0:
                return 3
            else:
                return 1

    def settle_finished_data(self, r, quote):
        if not quote:
            return
        last_price = float(quote['last_price'])
        pre_close_price = float(quote['pre_close_price'])
        open_price = float(quote['open_price'])

        call_put = 'C' if r.product_obj['contract_type'] == 1 else 'P'
        direction = r.direction
        expired_date = r.product_obj['expired_date']
        order_date = r.order_date
        rate = float(r.init_interest_rate) / 100
        spot_ref = float(r.spot_ref)
        strike_price = get_price(r.product_obj['strike_price_type'], r.product_obj['strike_price'], spot_ref)
        _expired_date = datetime.datetime.strptime(str(expired_date), '%Y-%m-%d')
        _order_date = datetime.datetime.strptime(str(order_date), '%Y-%m-%d')
        today_mat = get_trade_mat(self.curr_trade_date.strftime('%Y-%m-%d'), str(expired_date))
        order_mat = get_trade_mat(str(order_date), str(expired_date))
        price = float(r.price) if r.price_type == 1 else spot_ref * float(r.price) / 100
        lot_size = float(r.product_obj['lot_size'])
        units = get_units(direction, r.trade_vol)
        lots = units / lot_size
        sigma = get_sigma(call_put, spot_ref, strike_price, order_mat, rate, price)
        end_date, is_expired = get_end_date(expired_date, r.trading_time, self.curr_trade_date)
        closing_cash = float(r.closing_cash) if r.closing_cash else 0.0

        _valuation_today = valuation_today(is_expired, closing_cash, units, call_put, last_price, strike_price, today_mat, rate, sigma)
        _pnl_today = get_cash(direction, r.trade_vol, price) + _valuation_today
        _pnl_delta = _valuation_today - r.valuation_d_sigma
        front_greek = get_front_greeks(is_expired, order_date.strftime('%Y%m%d'), lots, units, call_put, last_price, strike_price, today_mat, rate, sigma)

        r.valuation_today = _valuation_today
        r.pnl_today = _pnl_today
        r.pnl_delta = _pnl_delta
        r.delta = front_greek.delta
        r.gamma = front_greek.gamma
        r.vega = front_greek.vega
        r.theta = front_greek.theta

    def get_line_data(self, r, quote):
        symbol = r.product_obj['current_symbol']
        #if quote.get(symbol, None) is None:
        #    return
        quote = quote.get(symbol, {})
        last_price = float(quote.get('last_price', 0))
        pre_close_price = float(quote.get('pre_close_price', 0))
        open_price = float(quote.get('open_price', 0))

        if r.today_mat is None or r.yesterday_mat is None or r.order_trade_mat is None or r.trade_sigma is None or r.calendar_sigma is None or \
           r.valuation_last is None or r.valuation_d_time is None or r.valuation_d_sigma is None or \
           r.pnl_yesterday is None or r.pnl_theta is None or r.pnl_vega is None or r.pre_close_price is None:
            self.update_order_data(r, quote)
        if r.finished:
            if r.valuation_today is None or r.pnl_today is None or r.pnl_delta is None or \
               r.delta is None or r.gamma is None or r.vega is None or r.theta:
                self.settle_finished_data(r, quote)

        _trd_type = {
            1: u'normal',
            2: u'preset',
            3: u'nightopen',
            4: u'对手价',
            5: u'最新价',
        }
        current_symbol = r.product_obj['current_symbol']
        call_put = 'C' if r.product_obj['contract_type'] == 1 else 'P'
        expired_date = r.product_obj['expired_date']
        direction = r.direction
        order_date = r.order_date
        today_mat = r.today_mat
        yesterday_mat = r.yesterday_mat
        rate = float(r.init_interest_rate) / 100
        spot_ref = float(r.spot_ref)
        strike_price = get_price(r.product_obj['strike_price_type'], r.product_obj['strike_price'], spot_ref)
        price = float(r.price) if r.price_type == 1 else spot_ref * float(r.price) / 100
        sigma = r.trade_sigma
        units = get_units(direction, r.trade_vol)
        lot_size = float(r.product_obj['lot_size'])
        lots = units / lot_size
        end_date, is_expired = get_end_date(expired_date, r.trading_time, self.curr_trade_date)
        closing_fut_price = float(r.closing_fut_price) if r.closing_fut_price else 0.0
        closing_cash = float(r.closing_cash) if r.closing_cash else 0.0
        _valuation_last = r.valuation_last
        _valuation_d_time = r.valuation_d_time
        _valuation_d_sigma = r.valuation_d_sigma
        if r.finished:
            _valuation_today = r.valuation_today
            _pnl_delta = r.pnl_delta
            _pnl_today = r.pnl_today
            _delta = r.delta
            _gamma = r.gamma
            _vega = r.vega
            _theta = r.theta
        else:
            _valuation_today = valuation_today(is_expired, closing_cash, units, call_put, last_price, strike_price, today_mat, rate, sigma)
            _pnl_delta = _valuation_today - _valuation_d_sigma
            _pnl_today = get_cash(direction, r.trade_vol, price) + _valuation_today
            front_greek = get_front_greeks(is_expired, order_date.strftime('%Y%m%d'), lots, units, call_put, last_price, strike_price, today_mat, rate, sigma)
            _delta = front_greek.delta
            _gamma = front_greek.gamma
            _vega = front_greek.vega
            _theta = front_greek.theta

        line = {
            'id': r.id,
            'product_no': r.product_obj.get('product_no', None),
            'trd_type': _trd_type.get(r.trd_type, None),
            'trading_date': str(order_date),
            'underlying': current_symbol,
            'call_put': call_put,
            'expiry': str(expired_date),
            'ccy': r.ccy,
            'spot_ref': round(spot_ref, 4),
            'k': round(strike_price, 4),
            'units': units,
            'price': round(price, 4),
            'cash': round(get_cash(direction, r.trade_vol, price)),
            'group': r.product_obj.get('underlying', None),
            'lotx': lot_size,
            'weight': round(float(r.weight), 4),
            'fut_price_yesterday': round(pre_close_price, 4),
            'sigma_yesterday': round(sigma, 4),
            'fut_price_today': round(last_price, 4),
            'sigma_today': round(sigma, 4),
            'lots': lots,
            'notional': round(spot_ref * units * float(r.weight), 4),
            'valuation_last': round(_valuation_last, 4),
            'valuation_d_time': round(_valuation_d_time, 4),
            'valuation_d_sigma': round(_valuation_d_sigma, 4),
            'valuation_today': round(_valuation_today, 4),
            'client_name': r.counterparty_obj.get('name', None),
            'pnl_yesterday': round(r.pnl_yesterday, 4),
            'pnl_today': round(_pnl_today, 4),
            't_yesterday': round(yesterday_mat, 4),
            't_today': round(today_mat, 4),
            'delta': round(_delta, 4),
            'gamma': round(_gamma, 4),
            'vega': round(_vega, 4),
            'theta': round(_theta, 4),
            'pnl_theta': round(r.pnl_theta, 4),
            'pnl_vega': round(r.pnl_vega, 4),
            'pnl_delta': round(_pnl_delta, 4),
            'iv_trading_date': round(sigma, 4),
            'iv_calendar_date': round(r.calendar_sigma, 4),
            'status': self.get_status(r.status, r.ref_order_id),
            'done': 0,
        }
        return line

    @gen.coroutine
    def work_process(self):
        try:
            quote = query_ctp_quote()
            self.cron_update_data(quote)
            data = []
            _finish_orders = []
            _orders = []

            headers = [
                {'title': u'订单ID', 'prop': 'id', 'sortable': True},
                {'title': u'产品平台ID', 'prop': 'product_no', 'sortable': True},
                {'title': u'TRD.Type', 'prop': 'trd_type', 'sortable': True},
                #{'title': u'订单类型', 'prop': 'status', 'sortable': True},
                {'title': u'开仓日期', 'prop': 'trading_date', 'sortable': True},
                {'title': u'标的', 'prop': 'underlying', 'sortable': True},
                {'title': u'期权类型', 'prop': 'call_put', 'sortable': True},
                {'title': u'到期日', 'prop': 'expiry', 'sortable': True},
                {'title': u'货币', 'prop': 'ccy', 'sortable': True},
                {'title': u'期货参考价', 'prop': 'spot_ref', 'sortable': True},
                {'title': u'执行价', 'prop': 'k', 'sortable': True},
                {'title': u'数量', 'prop': 'units', 'sortable': True},
                {'title': u'期权单价', 'prop': 'price', 'sortable': True},
                {'title': u'总权利金', 'prop': 'cash', 'sortable': True},
                {'title': u'交易方', 'prop': 'client_name', 'sortable': True},
                {'title': u'权重', 'prop': 'weight', 'sortable': True},
                {'title': u'标的类别', 'prop': 'group', 'sortable': True},
                {'title': u'合约参数', 'prop': 'lotx', 'sortable': True},
                {'title': u"期货昨收价", 'prop': 'fut_price_yesterday', 'sortable': True},
                {'title': u"昨vol", 'prop': 'sigma_yesterday', 'sortable': True},
                {'title': u"期货今收价", 'prop': 'fut_price_today', 'sortable': True},
                {'title': u"今vol", 'prop': 'sigma_today', 'sortable': True},
                {'title': u"成交手数", 'prop': 'lots', 'sortable': True},
                {'title': u"名义本金", 'prop': 'notional', 'sortable': True},
                {'title': u"VALUATION LAST", 'prop': 'valuation_last', 'sortable': True},
                {'title': u"VALUATIONd TIME", 'prop': 'valuation_d_time', 'sortable': True},
                {'title': u"VALUATIONd SIGMA", 'prop': 'valuation_d_sigma', 'sortable': True},
                {'title': u"VALUATION TODAY", 'prop': 'valuation_today', 'sortable': True},
                {'title': u"pnl Yesterday", 'prop': 'pnl_yesterday', 'sortable': True},
                {'title': u"pnl Today", 'prop': 'pnl_today', 'sortable': True},
                {'title': u"T(Y'DAY)", 'prop': 't_yesterday', 'sortable': True},
                {'title': u"T(TODAY)", 'prop': 't_today', 'sortable': True},
                {'title': u"DELTA", 'prop': 'delta', 'sortable': True},
                {'title': u"GAMMA", 'prop': 'gamma', 'sortable': True},
                {'title': u"VEGA", 'prop': 'vega', 'sortable': True},
                {'title': u"THETA", 'prop': 'theta', 'sortable': True},
                {'title': u"PnL THETA", 'prop': 'pnl_theta', 'sortable': True},
                {'title': u"PnL VEGA", 'prop': 'pnl_vega', 'sortable': True},
                {'title': u"PnL DELTA", 'prop': 'pnl_delta', 'sortable': True},
                {'title': u'IV(交易日)', 'prop': 'iv_trading_date', 'sortable': True},
                {'title': u'IV(日历日)', 'prop': 'iv_calendar_date', 'sortable': True},
            ]

            msg_type = 'otc_orders'
            current_trade_date = str(KdbQuery().get_trading_date())

            with mysql_sc() as sc:
                objs = sc.query(OTCOptionOrders).filter(
                    or_(
                        OTCOptionOrders.status == 2,
                        OTCOptionOrders.status == 3,
                    )
                )
                for o in objs:
                    rows = sc.query(OTCOptionOrders).filter(
                        OTCOptionOrders.status == 4,
                        OTCOptionOrders.ref_order_id == o.id,
                    )
                    _vol = sum([row.trade_vol for row in rows])
                    if o.trade_vol == _vol:
                        o.finished = True
                        for row in rows:
                            row.finished = True

                rows = sc.query(self.model).filter(
                    self.model.status == 2,
                )
                for r in rows:
                    line = self.get_line_data(r, quote)
                    if line is None:
                        continue
                    if current_trade_date >= r.product_obj['expired_date'].strftime('%Y%m%d'):
                        line['done'] = 2
                    if r.finished:
                        line['done'] = 1
                        _finish_orders.append(line)
                    else:
                        _orders.append(line)

                rows = sc.query(self.model).filter(
                    self.model.status == 3,
                ).order_by(self.model.id.desc())
                for r in rows:
                    line = self.get_line_data(r, quote)
                    if line is None:
                        continue
                    if current_trade_date >= r.product_obj['expired_date'].strftime('%Y%m%d'):
                        line['done'] = 2
                    if r.finished:
                        line['done'] = 1
                        for i, d in enumerate(_finish_orders):
                            if r.ref_order_id == d['id']:
                                _finish_orders.insert(i + 1, line)
                                break
                    else:
                        for i, d in enumerate(_orders):
                            if r.ref_order_id == d['id']:
                                _orders.insert(i + 1, line)
                                break

                rows = sc.query(self.model).filter(
                    self.model.status == 4,
                ).order_by(self.model.id.desc())
                for r in rows:
                    line = self.get_line_data(r, quote)
                    if line is None:
                        continue
                    if current_trade_date >= r.product_obj['expired_date'].strftime('%Y%m%d'):
                        line['done'] = 2
                    if r.finished:
                        line['done'] = 1
                        for i, d in enumerate(_finish_orders):
                            if r.ref_order_id == d['id']:
                                _finish_orders.insert(i + 1, line)
                                break
                    else:
                        for i, d in enumerate(_orders):
                            if r.ref_order_id == d['id']:
                                _orders.insert(i + 1, line)
                                break

            data = _orders
            res = {
                'headers': headers,
                'data': sorted(data, key=lambda x: (x['done'] == 1, x['done'] == 0, x['done'] == 2)),
            }
            send_websoket(msg_type, res)
            finish_res = {
                'headers': headers,
                'data': sorted(_finish_orders, key=lambda x: (x['done'] == 1, x['done'] == 0, x['done'] == 2)),
            }
            send_websoket('otc_finish_orders', finish_res)

        except Exception as e:
            logger.error(str(e))



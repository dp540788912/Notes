# encoding: utf-8

import redis
import json


def Singleton(cls):
    instances = {}
    def _singleton(*args, **kw):
        if cls not in instances:
            instances[cls] = cls(*args, **kw)
        return instances[cls]
    return _singleton


@Singleton
class BaseConnectionPool(object):
    def __init__(self):
        self.pool = redis.ConnectionPool(host='127.0.0.1', port=6379, db=0)

    def create_rds(self):
        return redis.Redis(connection_pool=self.pool)


@Singleton
class BaseConnector(object):
    def __init__(self):
        self.rds = None

    def instance(self):
        if self.rds is None:
            self.rds = BaseConnectionPool().create_rds()
        return self.rds

    def create(self):
        rds = BaseConnectionPool().create_rds()
        return rds


class RedisConnector(object):
    '''
    Redis Connector using Singleton mode
    '''

    @staticmethod
    def reuse():
        return BaseConnector().instance()

    @staticmethod
    def new():
        return BaseConnector().create()


class MessageSet(object):

    def __init__(self, key='', reuse=True):
        if reuse:
            self.__rds = RedisConnector.reuse()
        else:
            self.__rds = RedisConnector.new()
        self.key = key

    def put_msg(self, item):
        return self.__rds.sadd(self.key, item)

    def get_msg(self):
        return self.__rds.smembers(self.key)

    def del_set(self, item):
        return self.__rds.srem(self.key, item)

    def is_have(self, item):
        return self.__rds.sismember(self.key, item)


class MessageHashMap:

    def __init__(self, key='', reuse=True):
        if reuse:
            self.__rds = RedisConnector.reuse()
        else:
            self.__rds = RedisConnector.new()
        self.key = key

    def count(self):
        return self.__rds.hlen(self.key)

    def is_have(self, item):
        return self.__rds.hexists(self.key, item) > 0

    def key_exist(self, key, item):
        return self.__rds.hexists(key, item) > 0

    def put_msg(self, item, data):
        self.__rds.hset(self.key, item, data)

    def put_key_msg(self, key, item, data):
        self.__rds.hset(key, item, data)

    def get_msg(self, item):
        return self.__rds.hget(self.key, item)

    def get_key_msg(self, key, item):
        if self.key_exist(key, item):
            return self.__rds.hget(key, item)
        return None

    def get_all(self):
        return self.__rds.hgetall(self.key)

    def get_key_all(self, key):
        return self.__rds.hgetall(key)

    def get_hash_keys(self):
        return self.__rds.hkeys(self.key)

    def get_hash_values(self):
        return self.__rds.hvals(self.key)

    def get_match_keys(self, key_name=''):
        return self.__rds.keys(key_name+'*')

    def del_hash(self):
        self.__rds.delete(self.key)

    def del_hash_item(self, item):
        self.__rds.hdel(self.key, item)


class RedisQueue(object):

    def __init__(self, rds, name, namespace='queue'):
        self.rds = rds
        self.namespace = namespace
        self.key = ':'.join((namespace, name))

    def qsize(self):
        return self.rds.llen(self.key)

    def empty(self):
        return self.qsize() == 0

    def show(self):
        return self.rds.lrange(self.key, 0, -1)

    def put(self, item):
        self.rds.rpush(self.key, item)

    def bulk_put(self, item):
        self.rds.rpush(self.key, *item)

    def lput(self, item):
        self.rds.lpush(self.key, item)

    def bulk_lput(self, item):
        self.rds.lpush(self.key, *item)

    def put_msg(self, dst, msg):
        key = ':'.join((self.namespace, dst))
        self.rds.rpush(key, msg)

    def get(self, block=False, timeout=0):
        if block:
            data = self.rds.blpop(self.key, timeout=timeout)
            if data:
                _, item = data
        else:
            item = self.rds.lpop(self.key)
        return item

    def pop_host_msg(self, hostip):
        data = None
        try:
            for d in self.rds.lrange(self.key, 0, -1):
                j_data = json.loads(str(d, 'utf-8', 'ignore'))
                if j_data.get('ip', '') == hostip:
                    data = d
                    break
            self.rds.lrem(self.key, data, 0)
        except Exception as e:
            return None
        return data

    def pop_host_pid_msg(self, hostip, process_id):
        data = None
        try:
            for d in self.rds.lrange(self.key, 0, -1):
                j_data = json.loads(str(d, 'utf-8', 'ignore'))
                if j_data.get('ip', '') == hostip and j_data.get('process_id', -1) == process_id:
                    data = d
                    break
            self.rds.lrem(self.key, data, 0)
        except Exception as e:
            return None
        return data

    def pop_host_alert_msg(self, hostip):
        data = None
        try:
            for d in self.rds.lrange(self.key, 0, -1):
                j_data = json.loads(str(d, 'utf-8', 'ignore'))
                if 'data' in j_data:
                    if j_data['data'].get('ip', '') == hostip:
                        data = d
                        break
            self.rds.lrem(self.key, data, 0)
        except Exception as e:
            return None
        return data

    def pop_all_msg(self, to_load=False):
        data = None
        try:
            data = self.rds.lrange(self.key, 0, -1)
            if to_load:
                data = [json.loads(str(d, 'utf-8', 'ignore')) for d in data]
            self.rds.delete(self.key)
        except Exception as e:
            return None
        return data


class MessageList(RedisQueue):

    def __init__(self, key='', reuse=True):
        if reuse:
            self.rds = RedisConnector.reuse()
        else:
            self.rds = RedisConnector.new()
        self.key = key


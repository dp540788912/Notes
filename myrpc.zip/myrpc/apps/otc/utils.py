# encoding: utf-8

import re
import json
import requests
import datetime
import os
import redis
import base64
import time
from redis_api import RedisConnector, MessageSet, MessageHashMap, MessageList
from log import logger
from computing import *
from kdb_api import KdbQuery
from config import config


def send_websoket(msg_type, msg_data, user_id=None, socket_id=None):
    rds = redis.Redis(config.redis['host'], config.redis['port'])
    """
    data = {
        'msg_type': '1111',
        'msg_data': '22222',
        'user_id': 2,
    }
    """
    data = {
        'msg_type': msg_type,
        'msg_data': msg_data,
        'user_id': user_id,
        'socket_id': socket_id,
    }
    return rds.publish("websocketmessage", json.dumps(data))


def get_type_agent(agent_type):
    rds_map = MessageHashMap("a:rss:websocket")
    agents = []
    for _, v in rds_map.get_all().items():
        a = json.loads(str(v, 'utf-8'))
        if (a['msg_type'] == agent_type) or (agent_type == 'all'):
            agents.append(a)
    return agents


def check_redis_session(redis_config, session):
    rds = redis.Redis(redis_config['host'], redis_config['port'])
    s = rds.get('session:%s' % session)
    if s:
        data = json.loads(str(base64.b64decode(s), 'utf-8').split(':', 1)[-1])
        if ('_auth_user_id' in data):
            print(data)
            res = {
                'id': data.get('_auth_user_id'),
                'username': data.get('_auth_user_name', ''),
                'nickname': data.get('_auth_user_nickname', ''),
            }
            return res
    return {}


def query_redis_iphost(redis_config, host):
    iphost = ''
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        hosts = rds.smembers('a:oss:hosts')
        for h in hosts:
            h = str(h, 'utf-8')
            if h == host:
               iphost = h
    except Exception as e:
        logger.error(str(e))
        raise e
        return ''
    return iphost


def rpush_redis_cmd(redis_config, r_queue, cmd):
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        rds.rpush(r_queue, cmd)
        logger.info('rpush redis=[%s]: cmd=[%s]' % (r_queue, cmd))
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def lpop_redis_cmd(redis_config, r_queue, seq):
    data = None
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        for d in rds.lrange(r_queue, 0, -1):
            if json.loads(str(d, 'utf-8'))['seq'] == seq:
                data = d
                break
        rds.lrem(r_queue, data, 0)
        logger.info('lpop redis=[%s]: data=[%s]' % (r_queue, data))
        return data
    except Exception as e:
        logger.error(str(e))
        raise e
        return None


def get_units(direction, trade_vol):
    try:
        if int(direction) == 1:
            return int(trade_vol)
        else:
            return -1 * int(trade_vol)
    except Exception as e:
        return None


def get_cash(direction, trade_vol, price):
    try:
        if int(direction) == 1:
            return -1 * int(trade_vol) * float(price)
        else:
            return int(trade_vol) * float(price)
    except Exception as e:
        return None


def get_end_date(expired_date, trading_time, curr_trade_date):
    """
    @expired_date: '2000-01-01'
    @trading_time: datetime
    @curr_trade_date: datetime
    """
    expired_date = datetime.datetime.strptime(str(expired_date), '%Y-%m-%d')
    if trading_time:
        return trading_time.strftime('%Y%m%d'), 'N'
    if curr_trade_date > expired_date:
        return expired_date.strftime('%Y%m%d'), 'Y'
    else:
        return 'N/A', 'N'


def get_trade_mat(start_date, end_date):
    """
    @start_date/end_date: '2000-01-01'
    """
    start_date = datetime.datetime.strptime(str(start_date), '%Y-%m-%d')
    end_date = datetime.datetime.strptime(str(end_date), '%Y-%m-%d')
    days = KdbQuery().count_trading_days(start_date.strftime('%Y.%m.%d'), end_date.strftime('%Y.%m.%d'))
    return round(days / 244.0, 4)


def get_calendar_mat(order_date, expired_date):
    """
    @start_date/end_date: '2000-01-01'
    """
    expired_date = datetime.datetime.strptime(str(expired_date), '%Y-%m-%d')
    trading_date = datetime.datetime.strptime(str(order_date), '%Y-%m-%d')
    d = (expired_date - trading_date).days 
    return round(d / 365.0, 4)


def query_ctp_quote():
    try:
        r = requests.get(config.quote_url)
        res = r.json()['data']
        return res
    except Exception as e:
        return {}


def get_price(price_type, price, spot):
    if price_type == 1:
        return float(price)
    else:
        return float(price) * float(spot) / 100


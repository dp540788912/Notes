# -*-coding:utf-8-*-

from sqlalchemy.sql import func, or_
from sqlalchemy.orm import relationship
from sqlalchemy import Column, ForeignKey
from sqlalchemy.dialects.mysql import DATETIME, DATE, TIME, INTEGER, SMALLINT, BIGINT, VARCHAR, TEXT, FLOAT, DOUBLE, BOOLEAN, JSON
from db import ModelBase, session_context as mysql_sc


class OTCCompanies(ModelBase):

    __tablename__ = 'otc_companies'

    id = Column(INTEGER, primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)


class OTCEmployees(ModelBase):

    __tablename__ = 'otc_employees'

    id = Column(INTEGER, primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)
    company_id = Column(INTEGER, nullable=False)    # ForeignKey('otc_companies.id')

    @property
    def company_obj(self):
        with mysql_sc() as sc:
            o = sc.query(OTCCompanies).filter_by(id=self.company_id).first()
            if not o:
                return {}
            return {
                'name': o.name,
            }

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'company_id': self.company_id,
            'company_name': self.company_obj.get('name', ''),
        }


class Exchanges(ModelBase):

    __tablename__ = 'exchanges'

    id = Column(INTEGER, primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)
    code = Column(VARCHAR(10), nullable=False, unique=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'code': self.code,
        }


class OTCModels(ModelBase):

    __tablename__ = 'otc_models'

    id = Column(INTEGER, primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)
    type = Column(SMALLINT, nullable=False)     # 1:波动率 2:定价
    filepath = Column(VARCHAR(256), nullable=True)
    description = Column(TEXT, nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name
        }


class OTCAccounts(ModelBase):

    __tablename__ = 'otc_accounts'

    id = Column(INTEGER, primary_key=True)
    name = Column(VARCHAR(64), nullable= False)


class OTCCounterParties(ModelBase):

    __tablename__ = 'otc_counter_parties'

    id = Column(INTEGER, primary_key=True)
    name = Column(VARCHAR(32), nullable=False)
    contact = Column(JSON, nullable=True)
    account_id = Column(INTEGER, nullable=False)    # ForeignKey('otc_accounts.id')

    @property
    def account_obj(self):
        with mysql_sc() as sc:
            o = sc.query(OTCAccounts).filter_by(id=self.account_id).first()
            if not o:
                return {}
            return {
                'id': o.id,
                'name': o.name,
            }

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'account_id': self.account_id,
            'account_name': self.account_obj.get('name', None),
        }


class OTCOptionProducts(ModelBase):

    __tablename__ = 'otc_option_products'

    id = Column(BIGINT, primary_key=True)
    product_no = Column(VARCHAR(128), nullable=False, unique=True)
    produce_company_id = Column(INTEGER, nullable=False)    # ForeignKey('otc_companies.id')
    producer_id = Column(INTEGER, nullable=False)   # ForeignKey('otc_employees.id')
    exchange_id = Column(INTEGER, nullable=False)   # ForeignKey('exchanges.id')
    underlying = Column(VARCHAR(32), nullable=False)
    current_symbol = Column(VARCHAR(32), nullable=False)
    init_symbol = Column(VARCHAR(32), nullable=False)
    contract_type = Column(SMALLINT, nullable=False)    # 1:call; 2:put
    expired_date = Column(DATE, nullable=False)
    strike_price = Column(DOUBLE, nullable=False)
    strike_price_type = Column(SMALLINT, nullable=False)
    lot_size = Column(FLOAT, nullable=False)
    create_time = Column(DATETIME, nullable=False, server_default=func.now())

    def brief(self):
        return {
            'id': self.id,
            'product_no': self.product_no,
            'produce_company_id': self.produce_company_id,
            'producer_id': self.producer_id,
            'exchange_id': self.exchange_id,
            'underlying': self.underlying,
            'current_symbol': self.current_symbol,
            'init_symbol': self.init_symbol,
            'contract_type': self.contract_type,
            'expired_date': self.expired_date,
            'strike_price': self.strike_price,
            'strike_price_type': self.strike_price_type,
            'lot_size': self.lot_size,
        }

    @property
    def company_obj(self):
        with mysql_sc() as sc:
            o = sc.query(OTCCompanies).filter_by(id=self.produce_company_id).first()
            if not o:
                return {}
            return {
                'name': o.name,
            }

    @property
    def producer_obj(self):
        with mysql_sc() as sc:
            o = sc.query(OTCEmployees).filter_by(id=self.producer_id).first()
            if not o:
                return {}
            return {
                'name': o.name,
            }

    @property
    def exchange_obj(self):
        with mysql_sc() as sc:
            o = sc.query(Exchanges).filter_by(id=self.exchange_id).first()
            if not o:
                return {}
            return {
                'name': o.name,
            }

    def to_dict(self):
        return {
            'id': self.id,
            'product_no': self.product_no,
            'produce_company_id': self.produce_company_id,
            'produce_company_name': self.company_obj.get('name', None),
            'producer_id': self.producer_id,
            'producer_name': self.producer_obj.get('name', None),
            'exchange_id': self.exchange_id,
            'exchange_name': self.exchange_obj.get('name', None),
            'underlying': self.underlying,
            'current_symbol': self.current_symbol,
            'init_symbol': self.init_symbol,
            'contract_type': self.contract_type,
            'expired_date': str(self.expired_date),
            'strike_price': float(self.strike_price),
            'strike_price_type': self.strike_price_type,
            'lot_size': self.lot_size,
            'create_time': str(self.create_time),
        }


class OTCOptionVolatility(ModelBase):

    __tablename__ = 'otc_option_volatility'

    id = Column(BIGINT, primary_key=True)
    name = Column(VARCHAR(256), nullable=False, unique=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
        }

    def brief(self):
        return {
            'id': self.id,
            'name': self.name,
        }


class Strategy(ModelBase):

    __tablename__ = 'strategy'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column('id_no', VARCHAR(256))


class VStrategies(ModelBase):

    __tablename__ = 'vstrategies'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(INTEGER, nullable=False)
    portfolio_id = Column(INTEGER, nullable=False)

    @property
    def strategy_obj(self):
        with mysql_sc() as sc:
            o = sc.query(Strategy).filter_by(id=self.strategy_id).first()
            if not o:
                return {}
            return {
                'id': o.id,
                'name': o.name,
            }

    def to_dict(self):
        return {
            'id': self.id,
            'strategy_name': self.strategy_obj.get('name', None),
        }


class StrategyPortfolio(ModelBase):

    __tablename__ = 'strategy_portfolio'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    username = Column(VARCHAR(32), nullable=False)


class DeployConfs(ModelBase):

    __tablename__ = 'deploy_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(256), nullable=True)
    host = Column(VARCHAR(45), nullable=False)
    deploy_path = Column(VARCHAR(256), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    program_type_id = Column(ForeignKey('program_types.id'), nullable=True)
    vstrategy_id = Column(ForeignKey('vstrategies.id'), nullable=True)
    result = Column(INTEGER, default=0)
    status = Column(INTEGER, default=1)
    program_id = Column(ForeignKey('programs.id'), nullable=True)
    request_id = Column(ForeignKey('online_request.id'), nullable=True)
    valid = Column(BOOLEAN, default=True, nullable=True)


class OTCOptionOrders(ModelBase):

    __tablename__ = 'otc_option_orders'

    id = Column(BIGINT, primary_key=True)
    product_id = Column(BIGINT, nullable=False)  # ForeignKey('otc_option_products.id')
    vstrategy_id = Column(BIGINT, nullable=True)    # ForeignKey('vstrategies.id')
    volatility_model_id = Column(INTEGER, nullable=False)   # ForeignKey('otc_option_volatility.id')
    init_volatility = Column(DOUBLE, nullable=True)
    init_interest_rate = Column(DOUBLE, nullable=True)
    counterparty_id = Column(INTEGER, nullable=False)   # ForeignKey('otc_counter_parties.id')
    trade_vol = Column(INTEGER, nullable=False)
    price = Column(DOUBLE, nullable=False)
    price_type = Column(SMALLINT, nullable=False) # 1:固定值;2:百分比
    trd_type = Column(SMALLINT, nullable=False)   # 1:Normal(一定成交);2:挂单价;3:Nightopen(夜盘开盘价);4:对手价;5:最新价;
    spot_ref = Column(DOUBLE, nullable=False)
    direction = Column(SMALLINT, nullable=False)    # 1:buy 2:sell
    weight = Column(DOUBLE, nullable=False)
    delta_coff = Column(DOUBLE, nullable=False)
    ccy = Column(VARCHAR(16), nullable=False, default='CNY')
    opt_type = Column(SMALLINT, nullable=False, default=1)   #1:开仓;2平仓;3行权
    ref_order_id = Column(BIGINT, nullable=False, default=-1)    #关联订单的ID
    end_status = Column(BOOLEAN, nullable=False)
    status = Column(SMALLINT, nullable=False, default=-1)   #订单状态 1:新建;2:持有;3:平仓;4:行权;5:取消;0:系统正在处理;6:agent正在处理;-2:处理失败;-1:未下单;11正在处理撤单;12正在撤销;13已撤单;14撤单失败
    order_date = Column(DATE, nullable=True)

    closing_fut_price = Column(DOUBLE, nullable=True)
    closing_cash = Column(DOUBLE, nullable=True)
    sigma = Column(DOUBLE, nullable=True)
    trading_time = Column(DATETIME, nullable=True)
    end_time = Column(DATETIME, nullable=True)
    create_time = Column(DATETIME, nullable=False, server_default=func.now())

    # new.20171023
    finished = Column(BOOLEAN, nullable=True, default=False)
    pre_close_price = Column(FLOAT, nullable=True)
    today_mat = Column(FLOAT, nullable=True)
    yesterday_mat = Column(FLOAT, nullable=True)
    order_trade_mat = Column(FLOAT, nullable=True)
    trade_sigma = Column(FLOAT, nullable=True)
    calendar_sigma = Column(FLOAT, nullable=True)
    valuation_last = Column(FLOAT, nullable=True)
    valuation_d_time = Column(FLOAT, nullable=True)
    valuation_d_sigma = Column(FLOAT, nullable=True)
    valuation_today = Column(FLOAT, nullable=True)
    pnl_today = Column(FLOAT, nullable=True)
    pnl_yesterday = Column(FLOAT, nullable=True)
    pnl_theta = Column(FLOAT, nullable=True)
    pnl_vega = Column(FLOAT, nullable=True)
    pnl_delta = Column(FLOAT, nullable=True)
    delta = Column(FLOAT, nullable=True)
    gamma = Column(FLOAT, nullable=True)
    vega = Column(FLOAT, nullable=True)
    theta = Column(FLOAT, nullable=True)
    send_order_time = Column(DATETIME, nullable=True)

    def position_detail(self):
        return {
            'exchange_id': self.product_obj['exchange_id'],
            'underlying': self.product_obj['underlying'],
            'init_symbol': self.product_obj['init_symbol'],
            'contract_type': self.product_obj['contract_type'],
            'lot_size': self.product_obj['lot_size'],
            'strike_price': float(self.product_obj['strike_price']) if self.product_obj['strike_price_type'] == 1 \
                            else float(self.spot_ref) * float(self.product_obj['strike_price']),
            'expired_date': str(self.product_obj['expired_date']),
            'init_volatility': float(self.init_volatility),
            'init_interest_rate': float(self.init_interest_rate),
            'counterparty_id': self.counterparty_id,
            'trd_type': self.trd_type,
            'spot_ref': float(self.spot_ref),
            'trade_vol': self.trade_vol,
            'price': float(self.price) if self.price_type == 1 else float(self.spot_ref) * float(self.price),
            'ccy': self.ccy,
            'weight': float(self.weight),
            'delta_coff': float(self.delta_coff),
            'direction': self.direction,
            'order_date': str(self.order_date),
        }

    def brief(self):
        return {
            'id': self.id,
            'product_id': self.product_id,
            'vstrategy_id': self.vstrategy_id,
            'volatility_model_id': self.volatility_model_id,
            'init_volatility': float(self.init_volatility),
            'init_interest_rate': float(self.init_interest_rate),
            'counterparty_id': self.counterparty_id,
            'trade_vol': self.trade_vol,
            'price': float(self.price),
            'price_type': self.price_type,
            'trd_type': self.trd_type,
            'spot_ref': float(self.spot_ref),
            'direction': self.direction,
            'weight': float(self.weight),
            'delta_coff': float(self.delta_coff),
            'ccy': self.ccy,
            'opt_type': self.opt_type,
            'ref_order_id': self.ref_order_id,
            'order_date': str(self.order_date),
        }

    def ev_trd_type(self):
        if self.trd_type == 1:
            return 'normal'
        elif self.trd_type == 2:
            return 'preset'
        else:
            return 'nightopen'

    def to_ev(self):
        return {
            'instr_id': self.id,
            'trade_date': 0,
            'delta_coff': float(self.delta_coff),
            'underlying': self.product_obj['current_symbol'],
            'call_put': 'C' if self.product_obj['contract_type'] == 1 else 'P',
            'expiry': self.product_obj['expired_date'].strftime('%Y%m%d'),
            'strike': float(self.product_obj['strike_price']),
            'volume': int(self.trade_vol) * ((-1) ** (1 + self.direction)),
            'buy_sell': 'Buy' if self.direction == 1 else 'Sell',
            'sigma': 0,
            'mat_next': 0,
            'mat_by_trade': 0,
            'trd_type': self.ev_trd_type(),
            'hedged': 'Y' if self.trading_time else 'N',
            'alpha': 'No',
            'price': 0,
            'trx_date': str(self.order_date).replace('-', ''),
            'spot_ref': float(self.spot_ref),
            'theta': 0,
        }

    @property
    def exchange_obj(self):
        with mysql_sc() as sc:
            o = sc.query(Exchanges).join(
                OTCOptionProducts, OTCOptionProducts.exchange_id == Exchanges.id,
            ).fiter(
                OTCOptionProducts.id == self.product_id,
            ).first()
            if not o:
                return {}
            return o.to_dict()

    @property
    def product_obj(self):
        with mysql_sc() as sc:
            o = sc.query(OTCOptionProducts).filter_by(id=self.product_id).first()
            if not o:
                return {}
            return o.brief()

    @property
    def strategy_obj(self):
        with mysql_sc() as sc:
            o = sc.query(Strategy).join(
                VStrategies, VStrategies.strategy_id == Strategy.id,
            ).filter(
                VStrategies.id == self.vstrategy_id,
            ).first()
            if not o:
                return {}
            return {
                'id': o.id,
                'name': o.name,
            }

    @property
    def counterparty_obj(self):
        with mysql_sc() as sc:
            o = sc.query(OTCCounterParties).filter_by(id=self.counterparty_id).first()
            if not o:
                return {}
            return {
                'id': o.id,
                'name': o.name,
            }

    @property
    def volatility_model_obj(self):
        with mysql_sc() as sc:
            o = sc.query(OTCOptionVolatility).filter_by(id=self.volatility_model_id).first()
            if not o:
                return {}
            return o.brief()

    def to_dict(self):
        return {
            'id': self.id,
            'product_id': self.product_id,
            'current_symbol': self.producer_obj.get('current_symbol', None),
            'vstrategy_id': self.vstrategy_id,
            'strategy_name': self.strategy_obj.get('name', None),
            'counterparty_id': self.counterparty_id,
            'counterparty_name': self.counterparty_obj.get('name', None),
            'volatility_model_id': self.volatility_model_id,
            'volatility_model_name': self.volatility_model_obj.get('name', None),
            'trade_vol': self.trade_vol,
            'price': float(self.price),
            'trd_type': self.trd_type,
            'spot_ref': float(self.spot_ref),
            'direction': self.direction,
            'weight': float(self.weight),
            'create_time': str(self.create_time),
            'trading_time': str(self.trading_time) if self.trading_time else None,
            'order_date': str(self.order_date) if self.order_date else None,
            'end_time': str(self.end_time) if self.end_time else None,
            'closing_fut_price': float(self.closing_fut_price) if self.closing_fut_price else None,
            'closing_cash': float(self.closing_cash) if self.closing_cash else None,
            'end_status': self.end_status,
            'status': self.status,
            'sigma': float(self.sigma) if self.sigma else None,
            'delta_coff': float(self.delta_coff) if self.delta_coff else None,
            'ref_order_id': self.ref_order_id if self.ref_order_id != -1 else None,
            'ccy': self.ccy,
            'order_date': str(self.order_date),
        }


class OTCEvDatas(ModelBase):

    __tablename__ = 'otc_ev_datas'

    id = Column(BIGINT, primary_key=True, nullable=False)
    trade_date = Column(DATE, nullable=False)
    day_night = Column(SMALLINT, nullable=False)
    content = Column(JSON, nullable=False)


class OTCEvContents(ModelBase):

    __tablename__ = 'otc_ev_contents'

    id = Column(BIGINT, primary_key=True)
    instr_id = Column(BIGINT, nullable=False)
    trade_date = Column(DATE, nullable=False)
    delta_coff = Column(FLOAT, nullable=False)
    underlying = Column(VARCHAR(32), nullable=False)
    call_put = Column(VARCHAR(1), nullable=False)
    expiry = Column(DATE, nullable=False)
    strike = Column(FLOAT, nullable=False)
    volume = Column(INTEGER, nullable=False)
    buy_sell = Column(VARCHAR(8), nullable=False)
    sigma = Column(FLOAT, nullable=False)
    mat_next = Column(FLOAT, nullable=False)
    mat_by_trade = Column(FLOAT, nullable=False)
    trd_type = Column(VARCHAR(32), nullable=False)
    hedged = Column(VARCHAR(2), nullable=False)
    alpha = Column(VARCHAR(2), nullable=False, default='No')
    price = Column(FLOAT, nullable=False)
    trx_date = Column(DATE, nullable=False)
    spot_ref = Column(FLOAT, nullable=False)
    theta = Column(FLOAT, nullable=False)
    day_night = Column(SMALLINT, nullable=False)

    def to_dict(self):
        return {
            'instr_id': self.instr_id,
            'trade_date': self.trade_date.strftime('%Y%m%d'),
            'delta_coff': self.delta_coff,
            'underlying': self.underlying,
            'call_put': self.call_put,
            'expiry': self.expiry.strftime('%Y%m%d'),
            'strike': self.strike,
            'volume': self.volume,
            'buy_sell': self.buy_sell,
            'sigma': self.sigma,
            'mat_next': self.mat_next,
            'mat_by_trade': self.mat_by_trade,
            'trd_type': self.trd_type,
            'hedged': self.hedged,
            'alpha': self.alpha,
            'price': self.price,
            'trx_date': self.trx_date.strftime('%Y%m%d'),
            'spot_ref': self.spot_ref,
            'theta': self.theta,
        }


class OTCTradingOrders(ModelBase):

    __tablename__ = 'otc_trading_orders'

    id = Column(BIGINT, primary_key=True)
    create_time = Column(DATETIME, nullable=False, server_default=func.now())
    vstrategy_id = Column(BIGINT, nullable=False)
    trading_date = Column(DATE, nullable=False)
    day_night = Column(SMALLINT, nullable=False)
    seq_no = Column(VARCHAR(16), nullable=False)
    orders_data = Column(JSON, nullable=False)
    local_time = Column(VARCHAR(32), nullable=True)
    exchange_time = Column(VARCHAR(32), nullable=True)
    process_id = Column(INTEGER, nullable=True)
    serial_no = Column(JSON, nullable=True)

    def to_dict(self):
        return {
            'vstrategy_id': self.vstrategy_id,
            'trading_date': str(self.trading_date),
            'day_night': self.day_night,
            'seq_no': self.seq_no,
            'orders_data': self.orders_data,
            'local_time': self.local_time,
            'exchange_time': self.exchange_time,
            'process_id': self.process_id,
            'serial_no': self.serial_no,
        }


if __name__ == '__main__':
    from db import engine
    ModelBase.metadata.create_all(engine)


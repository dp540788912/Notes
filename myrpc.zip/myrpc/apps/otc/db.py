#-*-coding:utf-8-*-

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from contextlib import contextmanager
from config import config


ModelBase = declarative_base()


engine = create_engine(
    config.mysql['db_uri'] + '?charset=utf8',
    encoding='utf-8',
    pool_recycle=3600,
    echo=False,
    pool_size=50,
)


Session = sessionmaker(bind=engine)


def session():
    return Session()


@contextmanager
def session_context():
    session = Session()
    try:
        yield session
        session.commit()
    except:
        session.rollback()
        raise
    finally:
        session.close()


#-*-coding:utf-8-*-

import netifaces


class CommonConfig(object):
    Debug = True
    kdb = {
        'host': '192.168.1.41',
        'port': 9000,
        'user': 'superuser1',
        'passwd': 'password',
    }
    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql
    redis = {
        'host': '127.0.0.1',
        'port': '6379',
        'cmd_key': 'oss:a:cmd:',
        'rsp_key': 'a:oss:rsp:',
    }
    quote_url = 'http://192.168.1.170:10008/api/v1/speedquote/quote/last_ctp'
    members_url = 'http://127.0.0.1/api/v1/members'


class ProductionConfig_IDC(CommonConfig):
    Debug = False
    kdb = {
        'host': '192.168.10.102',
        'port': 9000,
        'user': 'superuser1',
        'passwd': 'password',
    }
    mysql = {
        'host': '192.168.10.100',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql
    redis = {
        'host': '192.168.10.100',
        'port': '6379',
        'cmd_key': 'oss:a:cmd:',
        'rsp_key': 'a:oss:rsp:',
    }
    quote_url = 'http://192.168.10.100:10008/api/v1/speedquote/quote/last_ctp'
    members_url = 'http://192.168.10.100/api/v1/members'


class DebugConfig_13(CommonConfig):
    Debug = False
    quote_url = 'http://121.46.13.124:10008/api/v1/speedquote/quote/last_ctp'


iplist = [netifaces.ifaddresses(i).get(netifaces.AF_INET)[0]['addr']
          for i in netifaces.interfaces() if netifaces.ifaddresses(i).get(netifaces.AF_INET)]

product_idc_list = ['192.168.10.104']
debug_13_iplist = ['192.168.1.13']

if any([i in iplist for i in product_idc_list]):
    Debug = False
    config = ProductionConfig_IDC()
elif any([i in iplist for i in debug_13_iplist]):
    Debug = False
    config = DebugConfig_13()
else:
    Debug = True
    config = CommonConfig()


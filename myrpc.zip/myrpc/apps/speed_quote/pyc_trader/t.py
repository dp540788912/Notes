with open("account.csv") as f:
      lines=f.readlines()

dic={}

for x in lines:
    print x.split(',')
    if x.split(',')[0] not in dic:
        dic[x.split(',')[0]]=[x.split(',')[1],x.split(',')[2].strip()]
print dic

#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>

#include "ctp_platform_interface.h"

#define  TEST_ACCOUNT_CNT	(1) #define  MAX_STRATEGY_CNT   (32)

static unsigned int s_all_acount_cnt = 0;



int  port[5]= { 41205, 41205, 41205, 41205, 41205};

char  ip_addr[5][64] = {
	"180.168.212.75",
	"180.169.101.177",
	"101.231.3.125",
	"180.169.101.177"
};

char account[5][16] = {
	"81241335",
	"120300555",
	"910080",
	"100103186"
};

char broker_id[5][16] = {
	"8000",
	"66666",
	"8888",
	"66666"
};

char pwd[5][256] = {
	"R4Vg3pVoJIPp0nABd9Xs7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
	"R4Vg3pVoJIPp0nABd9Xs7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
	"R4Vg3pVoJIPp0nABd9Xs7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
	"R4Vg3pVoJIPp0nABd9Xs7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=="
};




void
fill_quote_cfg(ctp_cfg_t *cfg, int exchg_tag)
{
	memcpy(cfg->ip, ip_addr[exchg_tag], sizeof(cfg->ip));
	memcpy(cfg->broker_id, broker_id[exchg_tag], sizeof(cfg->broker_id));
	memcpy(cfg->login_info_ar[0].account, account[exchg_tag], sizeof(cfg->login_info_ar[0].account));
	memcpy(cfg->login_info_ar[0].passwd, pwd[exchg_tag], sizeof(cfg->login_info_ar[0].passwd));
	cfg->port = port[exchg_tag];
	cfg->account_cnt = 1;
	cfg->exchg_tag = (enum exchg_code)exchg_tag;

}



void Quit_Signal_Handler(int signal)
{
	printf("call Quit_Signal_Handler \n");
	ctp_trader_destory();
	
	exit(0);
}



int 
main()
{
	signal(SIGINT, Quit_Signal_Handler);
	query_account_info_ret_t  *ret_account = NULL;
	all_exchg_ctp_cfg_t all_exchg_info;
	query_pos_info_ret_t *pos = NULL;
	query_order_info_ret_t   *ret_order = NULL;
	all_exchg_info.exchg_tunnel_cnt = TEST_ACCOUNT_CNT;

	ctp_cfg_t cfg;
	int idx = 0;
	for (idx = 0; idx < TEST_ACCOUNT_CNT; idx++)
	{
		fill_quote_cfg(&cfg, idx);
		memcpy((char *)(&all_exchg_info.ctp_cfg_info_ar[idx]), &cfg, sizeof(ctp_cfg_t));
		all_exchg_info.exchg_tunnel_cnt++;
	}

	ctp_trader_init(&all_exchg_info);
	sleep(2);

	printf("[INFO]: FINISH  fill_quote_cfg ! \n");


	while (1){	
		ret_account = ctp_query_account_info();
		if (ret_account == NULL){
			printf("[ERROR]: %s , %d \n", __FUNCTION__, __LINE__);
		}

		printf("[INFO]: query position info start ~ \n");
		pos = ctp_query_position_info();
		if (pos == NULL) {
			printf("[ERROR]: %s , %d \n", __FUNCTION__, __LINE__);
		}

		printf("[INFO]: ctp_query_order_info start ~ \n");
		ret_order = ctp_query_cur_order_info();
		if (ret_order == NULL) {
			printf("[ERROR]: %s , %d \n", __FUNCTION__, __LINE__);
		}

		
		sleep(30);
	};
	return  0;
}

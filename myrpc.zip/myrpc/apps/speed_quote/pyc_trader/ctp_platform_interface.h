#ifndef CTP_TRADER_INTERFACE_H
#define CTP_TRADER_INTERFACE_H

#ifdef __cplusplus
extern "C"
{
#endif

#define  ACCOUNT_LEN		(32)
#define  SYMBOL_LEN			(32)
#define  TIME_LEN			(16)
#define  ORDER_DETAIL_LEN	(64)
#define  EXCHGE_LEN			(16)
#define  STRATEGY_NAME_LEN	(64)

typedef struct strategy_info
{
	char strategy_name[64];
	char symbol[32];
}strategy_info_t;

enum exchg_code
{
	DCE = 0,
	SHFE = 1,
	CZCE = 2,
	CFFEX = 3
};

typedef struct user_login_info{
	char  		account[32];
	char  		passwd[128];
}user_login_info_t;

typedef struct ctp_cfg
{
	char  				ip[32];
	int   				port;
	enum exchg_code 			exchg_tag;
	unsigned int		account_cnt;
	user_login_info_t   login_info_ar[64];
	char  				broker_id[32];
}ctp_cfg_t;

typedef struct all_exchg_ctp_cfg
{
	ctp_cfg_t		ctp_cfg_info_ar[8];
	unsigned int	exchg_tunnel_cnt;
}all_exchg_ctp_cfg_t;

typedef struct interface_account_info
{
	char	account[ACCOUNT_LEN];
	double  static_interest;
	double  fee;
	double  close_profit;
	double  hold_profit;
	double  dynamic_profit;
	double  frozen_margin;
	double  place_frozen;
	double  fund_avail;
	double  rate_degree;
}interface_account_info_t;


typedef  struct interface_strategy_info{
	char		strategy_name[STRATEGY_NAME_LEN];
	double		fee;
	double		close_profit;
	double		frozen_margin;
}interface_strategy_info_t;

typedef struct query_account_info_ret {
	unsigned int				account_cnt;
	interface_account_info_t	*account_ar;
}query_account_info_ret_t;

typedef struct interface_position_info
{
	char			account[ACCOUNT_LEN];
	char			symbol[SYMBOL_LEN];
	char			dir;
	unsigned int	tot_pos;
	unsigned int	yd_pos;
	unsigned int	td_pos;
	unsigned int	close_avail_pos;
	double			avg_price;
	double			pos_profit_loss;
	double			frozen_margin;
	char			exchg[EXCHGE_LEN];

}interface_position_info_t;

typedef struct query_pos_info_ret {
	interface_position_info_t  *p_pos;
	unsigned int				tot_pos_cnt;
}query_pos_info_ret_t;

typedef struct interface_order_info
{
	char			account[ACCOUNT_LEN];
	char			symbol[SYMBOL_LEN];
	unsigned long	exchg_entrust_no;
	unsigned long	exchg_deal_entrust_no;
	char			dir;
	char			open_close;
	char			status;
	double			price;
	unsigned int	org_vol;
	unsigned int	remain_vol;
	unsigned int	deal_vol;
	char			place_time[TIME_LEN];
	char			fill_time[TIME_LEN];
	char			order_detail[ORDER_DETAIL_LEN];
}interface_order_info_t;

typedef struct query_order_info_ret {
	unsigned  int				tot_order_cnt;
	interface_order_info_t		*p_order;
}query_order_info_ret_t;

int ctp_trader_init(all_exchg_ctp_cfg_t *exchg_cfg_info);

int ctp_trader_destory();

query_order_info_ret_t *ctp_query_history_order_info();
query_order_info_ret_t *ctp_query_cur_order_info();
//int ctp_query_strategy_info();
query_pos_info_ret_t *ctp_query_position_info();
query_account_info_ret_t * ctp_query_account_info();

#ifdef __cplusplus
}
#endif

#endif

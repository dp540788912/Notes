import requests
import json
#
#
headers = {
        'content-type': 'application/json',
        'whitelist': 'operater',
        }
#
#data = {
#        'name': 'test2',
#        'deploy_path': '/home/dev/test2',
#        'ip_addr': '192.168.1.2',
#        'port': 988888,
#        'valid': True,
#        'server_id': 1,
#        'config_template_id': 3,
#        'account_id': 2,
#
#        }
#
#url = 'http://192.168.3.27:18888/api/v1/shannon/common/pre_tunnel_confs/3'
#
##r = requests.get(url, headers=headers)
##r = requests.post(url, data=json.dumps(data), headers=headers)
#
#r = requests.delete(url, headers=headers)
##r = requests.put(url, data=json.dumps(data), headers=headers)
#
#print r.text

data = open('login.config','r')
print data

url='http://192.168.1.10:8000/speedquote/trader/orders'
#print requests.post(url, data=data, headers=headers).text
print requests.get(url, headers=headers).text




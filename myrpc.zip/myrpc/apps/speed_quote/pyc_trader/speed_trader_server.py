import json
import time
import os
import tornado.httpserver
import tornado.ioloop
import tornado.options
import tornado.web
import pytrader
import readXml
import requests

from tornado.options import define,options

define("port",default=10009,help="run on the given port",type=int)



def getmap():
   url ='http://192.168.1.170:18886/api/v1/turing/trader/xml' 
   jsonstr = requests.get(url).text
   dic={}
   data = json.loads(jsonstr)['data']
   for x in data:
#       {'account': '910080', 'so_name': 'hi76', 'symbol': 'ZC705'}
        t=x['so_name']
        if t not in dic:
            dic[t]= [[x['symbol']],[x['account']]] 
        else:
            dic[t][0].append(x['symbol'])
            dic[t][1].append(x['account'])
   return dic


STRADICT=getmap()






class InitHandler(tornado.web.RequestHandler):
    def get(self):
        arg=self.get_argument('flag','1')
        if int(arg)  == 1:
            try:
                with open('login.config','r') as f:
                    jjson = f.read()
                pytrader.py_init_by_json(jjson)
                dit = {
                        'code' : 0,
                        }
            except Exception as msg:
                 dit = {
                         'code' : -1,
                         'error':msg
                         }
            self.write(json.dumps(dit))

        elif int(arg) == 0:
            try:
                pytrader.py_trader_destroy()
                dit = {
                        'code':0
                        }
            except Exception as msg:
                dit={
                        'code':-1,
                        'error':msg
                        }
            self.write(json.dumps(dit))

    def post(self):
        json_data =  self.request.body
        try: 
            pytrader.py_init_by_json(json_data)
            dit = { 'code':0 }
        except Exception as msg:
            dit={
                    'code' : -1,
                    'error': msg
                    }
        self.write(json.dumps(dit))


        

class CtpOrderQuery(tornado.web.RequestHandler):
    def get(self):
        arg=self.get_argument('flag','cur')
        if arg=='his':
            try:
                res=pytrader.py_ctp_query_history_get()
                dit ={
                        'code':0,
                        'data': res
                        }
            except Exception as msg:
                dit={
                        'code' :-1,
                        'error':msg
                        }
            self.write(json.dumps(dit))

        elif  arg == 'cur':
            try:
                res=pytrader.py_ctp_query_cur_order_info()
                dit = {
                        'code' :0,
                        'data':res
                        }
            except Exception as msg:
                dit = {
                        'code' :-1,
                        'error': msg
                        }
            self.write(json.dumps(dit))

class CtpPositionQuery(tornado.web.RequestHandler):
    def get(self):
        try:
            res=pytrader.py_ctp_query_position_info()
            dit = {
                    'code' :0,
                    'data': res
                    }
        except Exception as msg:
            dit = {
                    'code' :-1,
                    'error':msg
                    }
        self.write(json.dumps(dit))

class CtpAccountQuery(tornado.web.RequestHandler):
    def get(self):
       try:
            res=pytrader.py_ctp_query_account_info()
            dit={
                    'code' :0,
                    'data':res
                    }
       except Exception as msg:
            dit = {
                    'code':-1,
                    'error':msg
                    }
       self.write(json.dumps(dit))


class AccountByAccount(tornado.web.RequestHandler):
    def get(self):
     try:
        arg=self.get_argument('account','[\'81241327\',\'30900126\']')
        res=pytrader.py_ctp_query_account_info()
        print (res)
        account_list = eval(arg)
        print(len(res))
        print(account_list)
       # res_filter = filter(lambda x: True if x['account'] in arg else False,res)
        res_filter = [x for x in res if x['account'] in arg ]
        dit={

             'code':0,
             'data':res_filter
            }
     except Exception as msg:
        dit ={
             'code':-1,
             'error':msg
            }
     self.set_header('Content-Type','application/json;charset=UTF-8')
     self.write(json.dumps(dit))


class PositionByAccount(tornado.web.RequestHandler):
    def get(self):
     try:
        arg=self.get_argument('account','[\'81241327\',\'30900126\']')
        res=pytrader.py_ctp_query_position_info()
        account_list = eval(arg)
        #res_filter = filter(lambda x: True if x['account'] in arg else False,res)
        res_filter = [x for x in res if x['account'] in arg ]
        dit={

             'code':0,
             'data':res_filter
            }
     except Exception as msg: 
        dit = {
            'code':-1,
            'error':msg
            }
     self.set_header('Content-Type','application/json;charset=UTF-8')
     self.write(json.dumps(dit))

class CurOrderByAccount(tornado.web.RequestHandler):
    def get(self):
     try:
        arg=self.get_argument('account','[\'81241327\',\'30900126\']')
        res=pytrader.py_ctp_query_cur_order_info()
        account_list = eval(arg)
        #res_filter = filter(lambda x: True if x['account'] in arg else False,res)
        res_filter = [x for x in res if x['account'] in arg ]
        dit={

             'code':0,
             'data':res_filter
            }
     except Exception as msg: 
        dit = {
            'code':-1,
            'error':msg
            }
     self.set_header('Content-Type','application/json;charset=UTF-8')
     self.write(json.dumps(dit))


        
        
class HisOrderByAccount(tornado.web.RequestHandler):
    def get(self):
     try:
        arg=self.get_argument('account','[\'81241327\',\'30900126\']')
        res=pytrader.py_ctp_query_history_get()
        account_list = eval(arg)
        #res_filter = filter(lambda x: True if x['account'] in arg else False,res)
        res_filter = [x for x in res if x['account'] in arg ]
        dit={

             'code':0,
             'data':res_filter
            }
     except Exception as msg: 
        dit = {
            'code':-1,
            'error':msg
            }
     self.set_header('Content-Type','application/json;charset=UTF-8')
     self.write(json.dumps(dit))




class CurOrderByStg(tornado.web.RequestHandler):
    def get(self):
      try:
        stra_map = STRADICT
        arg=self.get_argument('strategy','[\'hi055p2\',\'hi76\']')
        stralist = eval(arg)
        symlist = []
        for x in stralist:
            symlist.extend(stra_map[x][0])
        accountlist = []
        for x in stralist:
            accountlist.extend(stra_map[x][1])
        def filter_condition(x):
            if x['account'] in accountlist and x['symbol'] in symlist:
                return True
            else :
                return False
        res=pytrader.py_ctp_query_cur_order_info()
        #res_filter = filter(filter_condition,res) 
        res_filter = [x for x in res if filter_condition(x)]
        dit={

             'code':0,
             'data':res_filter
            }
      except Exception as msg: 
        dit = {
            'code':-1,
            'error':msg
            }
      self.set_header('Content-Type','application/json;charset=UTF-8')
      self.write(json.dumps(dit))




class HisOrderByStg(tornado.web.RequestHandler):
    def get(self):
      try:
        stra_map = STRADICT
        arg=self.get_argument('strategy','[\'hi055p2\',\'hi76\']')
        stralist = eval(arg)
        symlist = []
        for x in stralist:
            symlist.extend(stra_map[x][0])
        accountlist = []
        for x in stralist:
            accountlist.extend(stra_map[x][1])
        def filter_condition(x):
            if x['account'] in accountlist and x['symbol'] in symlist:
                return True
            else :
                return False
        res=pytrader.py_ctp_query_history_get()
        res_filter = [x for x in res if filter_condition(x)]
        dit={

             'code':0,
             'data':res_filter
            }
      except Exception as msg: 
        dit = {
            'code':-1,
            'error':msg
            }
      self.set_header('Content-Type','application/json;charset=UTF-8')
      self.write(json.dumps(dit))


    

# wait to do
class PositionByAccount(tornado.web.RequestHandler):
    def get(self):
      try:
        arg=self.get_argument('strategy','[\'hi055p2\',\'hi76\']')
       # res=pytrader.py_ctp_query_position_info()
        res_filter = []
        stratelist = eval(arg)
        dit={

             'code':0,
             'data':res_filter
            }
      except Exception as msg: 
        dit = {
            'code':-1,
            'error':msg
            }
      self.set_header('Content-Type','application/json;charset=UTF-8')
      self.write(json.dumps(dit))









urls=[         
        (r'/api/v1/speedquote/trader',InitHandler),
        (r'/api/v1/speedquote/trader/orders',CtpOrderQuery),
        (r'/api/v1/speedquote/trader/positions',CtpPositionQuery),
        (r'/api/v1/speedquote/trader/accounts',CtpAccountQuery),
        (r'/api/v1/speedquote/trader/account/account',AccountByAccount),
        (r'/api/v1/speedquote/trader/ordercur/account',CurOrderByAccount),
        (r'/api/v1/speedquote/trader/orderhis/account',HisOrderByAccount),
        (r'/api/v1/speedquote/trader/position/account',PositionByAccount),
        (r'/api/v1/speedquote/trader/ordercur/strategy',CurOrderByStg),
        (r'/api/v1/speedquote/trader/orderhis/strategy',HisOrderByStg),
        (r'/api/v1/speedquote/trader/position/strategy',PositionByAccount),

      ]

if __name__=="__main__":
    with open('test/login.config.bak','r') as f:
         jjson = f.read()
    pytrader.py_init_by_json(jjson)
    time.sleep(3)
    tornado.options.parse_command_line()
    app=tornado.web.Application(
            handlers=urls
    )
    http_server=tornado.httpserver.HTTPServer(app)
    http_server.listen(options.port)
    tornado.ioloop.IOLoop.instance().start()
    pass

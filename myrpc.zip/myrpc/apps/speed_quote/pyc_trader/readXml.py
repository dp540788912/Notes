import json
from lxml import etree
import os
from account import account_map

absolute_path = "/home/mycapitaltrade/TraderXmlConfig/day"


def xmltree():
    turingdir = os.listdir(absolute_path)
    res=[]
    for i in range(len(turingdir)):
            ll = os.path.join(absolute_path,turingdir[i])
            xml = [os.path.join(ll,x) for x in os.listdir(ll) if x[-4:] ==".xml"]
            with open(xml[0]) as f:
                xmls = f.read()
                selector=etree.HTML(xmls)
                res.append(selector)
    return res




def Symbol2Exch(sym):
    if len(sym)==6:return "SHFE"
    if sym[0].isupper(): return "CZCE"
    else: return "DCE"

def Account2Symbol(account):
    res={}
    for selector in  xmltree():
            sub_ar =  selector.xpath("//symbol/text()")
            content =  selector.xpath("//account/user_id/text()")
            res[content[0]]=sub_ar
    return res.get(account)


def get_account_by_exch():
     res={}
     for selector in xmltree():
            sub_ar =  selector.xpath("//symbol/text()")
            content =  selector.xpath("//account/user_id/text()")
            tmp=Symbol2Exch(sub_ar[0]) 
            if tmp not in res:
                   res[tmp]=[content[0]]
            else:
                   res[tmp].append(content[0])
     return res






def Stra2AccountSym():
    stra_map={}
    for selector in xmltree():
            sub_ar =  selector.xpath("//symbol/text()")
            content =  selector.xpath("//account/user_id/text()")
            stra = selector.xpath("//strategy_so/text()")
            stra=map(lambda x:x.split('/')[-1][0:-3],stra)
            for i in range(len(stra)):
                stra_map[stra[i]]=[sub_ar[i],content[0]]
    return stra_map
 



def gen_json_quote():
    ctp_cfg_info_ar=[]
    for selector in xmltree():
            sub_ar =  selector.xpath("//symbol/text()")
            content =  selector.xpath("//account")
            for x in content:
                user_id = x.xpath("//user_id/text()")[0]
                passwd = x.xpath("//passwd/text()")[0]
            if passwd != "R4Vg3pVoJIPp0nABd9Xs7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==":
                continue
            config_one={'user_id':user_id,
                     'passwd':passwd,
                     'sub_ar':sub_ar,
                     'subcribe_cnt':len(sub_ar),
                     'port':41213,
                     'ip':account_map[user_id][0],
                     'broker_id':account_map[user_id][1]
                     }
            ctp_cfg_info_ar.append(config_one)
    configjson={}
    configjson["ctp_cfg_info_ar"] = ctp_cfg_info_ar
    configjson["exchg_quote_cnt"] = len(ctp_cfg_info_ar)
    return json.dumps(configjson)




def gen_json_trader():
    ctp_cfg_info_ar=[]
    for selector in xmltree():
            account_info=[]
            sub_ar =  selector.xpath("//symbol/text()")
            content =  selector.xpath("//account")
            for x in content:
                user_id = x.xpath("//user_id/text()")[0]
                passwd = x.xpath("//passwd/text()")[0]
            if passwd != "R4Vg3pVoJIPp0nABd9Xs7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==":
                continue
            print( user_id )
            config_one={
                     'port':41213,
                     'ip':account_map[user_id][0],
                     'broker_id':account_map[user_id][1]
                     }
            ctp_cfg_info_ar.append(config_one)
    configjson={}
    configjson["ctp_cfg_info_ar"] = ctp_cfg_info_ar
    configjson["exchg_quote_cnt"] = len(ctp_cfg_info_ar)
    return json.dumps(configjson)






def getAllAccounts():
   filt="//account/passwd/text()"
   pss="R4Vg3pVoJIPp0nABd9Xs7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=="
   return [ selector.xpath("//account/user_id/text()")[0]
           for selector in xmltree() if selector.xpath(filt)[0]==pss]
def accountsCheck():
     accounts=getAllAccounts()
     rmap={}
     maplist=[':'.join(account_map[x]) for x in accounts]
     for i in range(len(maplist)):
         if maplist[i] not in rmap:
             rmap[maplist[i]]=[accounts[i]]
         else:
             rmap[maplist[i]].append(accounts[i])
     return rmap

     
def genJson():
    pss="R4Vg3pVoJIPp0nABd9Xs7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=="
    iplist = accountsCheck()
    exch_cfg_ar=[]
    for x in iplist.keys():
         exch_cfg={}
         exch_cfg['ip']=x.split(':')[0]
         exch_cfg['broker_id'] = x.split(':')[1]
         exch_cfg['port'] = 41205
         account_info_list=[]
         for y in iplist[x]:
             if y == "910079": continue
             account_info = {}
             account_info['account'] = y
             account_info['passwd'] = pss
             account_info_list.append(account_info)
         exch_cfg['account_info'] = account_info_list
         exch_cfg['account_cnt'] = len(account_info_list)
         exch_cfg_ar.append(exch_cfg) 
    config = {}
    config['exchg_tunnel_cnt'] = len(exch_cfg_ar)
    config['exchg_cfg_ar'] = exch_cfg_ar
    return json.dumps(config,indent =2)

    




#print genJson()







'''
#absolute_path = "/home/mycapitaltrade/TraderXmlConfig/day"
#turingdir = os.listdir(absolute_path)
#
##for i in range(len(turingdir)):
#    ll = os.path.join(absolute_path,turingdir[i])
#    xml = [os.path.join(ll,x) for x in os.listdir(ll) if x[-4:] ==".xml"]
#    with open(xml[0]) as f:
#        xmls = f.read()
#        selector=etree.HTML(xmls)
#        sub_ar =  selector.xpath("//symbol/text()")
#        content =  selector.xpath("//account")
#        for x in content:
#            user_id = x.xpath("//user_id/text()")[0]
#            passwd = x.xpath("//passwd/text()")[0]
#        if passwd != "R4Vg3pVoJIPp0nABd9Xs7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==":
#            continue
#        config_one={'user_id':user_id,
#                 'passwd':passwd,
#                 'sub_ar':sub_ar,
#                 'subcribe_cnt':len(sub_ar),
#                 'port':41213,
#                 'ip':account_map[user_id][0],
#                 'broker_id':account_map[user_id][1]
#                 }
#        ctp_cfg_info_ar.append(config_one)
#
##print json.dumps(ctp_cfg_info_ar)
#
#configjson={}
#
#configjson["ctp_cfg_info_ar"] = ctp_cfg_info_ar
#configjson["exchg_quote_cnt"] = len(ctp_cfg_info_ar)
#print json.dumps(configjson)
#
#




#absolute_path = "/home/mycapitaltrade/TraderXmlConfig/day"
#turingdir = os.listdir(absolute_path)
#userid=[]
#
#ctp_cfg_info_ar=[]
#for i in range(len(turingdir)):
#    ll = os.path.join(absolute_path,turingdir[i])
#    xml = [os.path.join(ll,x) for x in os.listdir(ll) if x[-4:] ==".xml"]
#    with open(xml[0]) as f:
#        xmls = f.read()
#        selector=etree.HTML(xmls)
#        sub_ar =  selector.xpath("//symbol/text()")
#        print sub_ar
#        content =  selector.xpath("//account")
#        for x in content:
#            user_id = x.xpath("//user_id/text()")[0]
#            passwd = x.xpath("//passwd/text()")[0]
#        userid.append(user_id)
#        config_one={'user_id':user_id,
#                 'passwd':passwd,
#                 'sub_ar':sub_ar,
#                 'subcribe_cnt':len(sub_ar),
#                 'port':41213,
#                 'ip':account_map[user_id][0],
#                 'broker_id':account_map[user_id][1]
#                 }
#        ctp_cfg_info_ar.append(config_one)
#
##print json.dumps(ctp_cfg_info_ar)
##
##configjson={}
##
##configjson["ctp_cfg_info_ar"] = ctp_cfg_info_ar
##configjson["exchg_quote_cnt"] = len(ctp_cfg_info_ar)
##print json.dumps(configjson)
##
'''

#import ctypes
#libquote=ctypes.CDLL('./libctp_quote.so')
#libquote.ctp_quote_destory()
#print libquote.get_ctp_quote_info()


import pytrader
import time



#print pytrader.py_ctp_query_history_get()
#print pytrader.py_ctp_query_cur_order_info()
#print pytrader.py_ctp_query_position_info()
#print pytrader.py_ctp_query_account_info()
#print pytrader.py_ctp_quote_init()
#while(True):
#    print pytrader.py_get_ctp_quote_info()
#    time.sleep(5)
#print pytrader.py_ctp_quote_destory()

#print pytrader.py_init()
#print pytrader.py_ctp_query_history_get()
#print pytrader.py_ctp_query_cur_order_info()
#print pytrader.py_ctp_query_position_info()

with open('login.config.bak','r')as f:
    jjson=f.read()

print (pytrader.py_init_by_json(jjson))
#print pytrader.py_init()
#print pytrader.py_trader_destroy()
#print pytrader.py_init()
while True:
   # ##print (pytrader.py_ctp_query_cur_order_info())

    #print (pytrader.py_ctp_query_account_info())
    print (pytrader.py_ctp_query_cur_order_info())
   # pytrader.py_ctp_query_history_get()
    time.sleep(5)
#print pytrader.py_trader_destroy()

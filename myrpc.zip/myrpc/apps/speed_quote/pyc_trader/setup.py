from distutils.core import setup, Extension
from Cython.Build import cythonize

ext = Extension(name='pytrader', 
        sources=['pytrader.pyx'],
        library_dirs=["."],
        libraries=["trader"],
        extra_link_args=['-Wl,--no-undefined']
        )
setup(ext_modules=cythonize(ext))


# -*- coding: utf-8 -*-


import os
import requests
from clean_future_quote_log import MyLogger

log_root_path = os.path.join("/home/rss/bss_server/myrpc/apps/speed_quote/equity_quote/crontab", "clean_future_quote_logs")
if not os.path.exists(log_root_path):
    os.mkdir(log_root_path)
log_file_path = os.path.join(log_root_path, "clean_future_quote.log")
logger = MyLogger("info", log_file_path)

try:
    data = requests.get('http://127.0.0.1:10010/api/v1/speedquote/clean_future_quote')
    data = data.json()

    code = data['code']
    logger.info("code: " + str(code))
    if code == 0:
        logger.info("clean_data: " + str(data['data']['clean_data']))
    else:
        logger.error("error: " + str(data['data']['error']))

except Exception as e:
    print(e)
    logger.error(e)

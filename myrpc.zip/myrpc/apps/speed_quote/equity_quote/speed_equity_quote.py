# -*- coding: utf-8 -*-

import datetime
import decimal
import json
import os
import pickle
import re
import signal
import sys
import time

import aredis
import config
import market_scan
import numpy as np
import quote_type
import tornado.httpserver
import tornado.ioloop
import tornado.web
from config import logger
from qpython import qconnection
from tornado import gen

stop_signal = False


def get_kdb_data(sql, pandas=True):
    with qconnection.QConnection(config.KDB_IP, config.KDB_PORT,
                                 config.KDB_USERNAME, config.KDB_PASSWORD,
                                 timeout=10) as q:
        q.async(sql)
        dat = q.receive(pandas=pandas)
    return dat


class MyEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, bytes):
            return o.decode()
        elif isinstance(o, np.integer):
            return int(o)
        elif isinstance(o, np.float):
            return float(o)
        elif isinstance(o, np.ndarray):
            return o.tolist()
        elif isinstance(o, decimal.Decimal):
            return float(o)
        elif isinstance(o, datetime.datetime):
            return o.strftime('%Y%m%d %X.%f')
        elif isinstance(o, datetime.date):
            return o.strftime('%Y%m%d')
        else:
            return super(MyEncoder, self).default(o)


class BaseHandler(tornado.web.RequestHandler):
    def data_received(self, chunk):
        pass


class LastQuoteHandler(BaseHandler):
    def get(self):
        try:
            if 'quote' not in self.application.map_buffer:
                data = {}
                for k, v in self.application.quote.items():
                    if v:
                        data[k] = {'LastPrice': v.get('LastPrice', None)}
                dit = {'code': 0, 'data': data}
                self.application.map_buffer['quote'] = json.dumps(dit)
            ret_msg = self.application.map_buffer['quote']
        except Exception as e:
            ret_msg = {'code': -1, 'error': str(e)}
        self.write(ret_msg)


class UpdateTimeHandler(BaseHandler):
    def get(self):
        try:
            self.write({
                'code': 0,
                'data': {
                    sym: {'Time': v.get('Time', None), 'Date': v.get('TradingDate', None)}
                    for sym, v in self.application.quote.items() if 'Time' in v
                }
            })
        except Exception as e:
            self.write({'code': -1, 'error': str(e)})


class LastPriceHandler(BaseHandler):
    def get(self):
        try:
            data = {}
            for k, v in self.application.quote.items():
                if v:
                    data[k] = v.get('LastPrice', None)
            dit = data
        except Exception as e:
            dit = {'code': -1, 'error': str(e)}
        self.write(json.dumps(dit))


class GetDataHandler(BaseHandler):
    def __init__(self, *args, **kwargs):
        super(GetDataHandler, self).__init__(*args, **kwargs)
        self.cur_key = ''

    def set_key(self):
        raise NotImplemented

    async def get(self):
        self.set_key()
        if not self.cur_key:
            self.write({'code': -1, 'error': 'key not exist'})
            return
        if self.cur_key not in self.application.map_buffer:
            if not hasattr(self.application, self.cur_key):
                self.write({'code': -1, 'error': 'key %s not valid' % self.cur_key})
                return
            data = getattr(self.application, self.cur_key)
            self.application.map_buffer[self.cur_key] = json.dumps({'code': 0, 'data': data})
        buf = self.application.map_buffer[self.cur_key]
        self.write(buf)


class StockLastPriceHandler(GetDataHandler):
    def set_key(self):
        self.cur_key = 'stock_last_price'


class FutureLastPriceHandler(GetDataHandler):
    def set_key(self):
        self.cur_key = 'future_last_price'


class OptionLastPriceHandler(GetDataHandler):
    def set_key(self):
        self.cur_key = 'option_last_price'


class AllLastPriceHandler(GetDataHandler):
    def set_key(self):
        self.cur_key = 'all_last_price'


class StockTotalVolumeHandler(GetDataHandler):
    def set_key(self):
        self.cur_key = 'stock_total_volume'


class FutureTotalVolumeHandler(GetDataHandler):
    def set_key(self):
        self.cur_key = 'future_total_volume'


class OptionTotalVolumeHandler(GetDataHandler):
    def set_key(self):
        self.cur_key = 'option_total_volume'


class AllTotalVolumeHandler(GetDataHandler):
    def set_key(self):
        self.cur_key = 'all_total_volume'


class LogQuoteHandler(BaseHandler):
    def post(self, *args, **kwargs):
        """change the flag->config.log_quote to control if write quote to log.
        input json:
            {
                log_quote: true/false
            }
            The first letter of true/false must be lowercase in json format. Also true can be replace with 1.
            {
                log_quote: 1/other
            }
        """
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if 'log_quote' in payload:
            if payload['log_quote']:
                logger.debug("start quote log detail")
                config.log_quote = True
            else:
                logger.debug("stop quote log detail")
                config.log_quote = False
        dit = {'code': 0, 'data': 1}
        self.write(json.dumps(dit))


class InnerFutureQuoteHandler(BaseHandler):
    def get(self):
        try:
            data = {}
            for k, v in self.application.quote.items():
                if re.match(r'[A-Za-z]+?\d+@CTP', k) and v:
                    symbol = k.replace('@CTP', '')
                    data[symbol] = {
                        'LastPrice': v.get('LastPrice', None),
                        'Volume': int(v.get('Volume', None)),
                    }
            dit = {'code': 0, 'data': data}
        except Exception as e:
            dit = {'code': -1, 'error': str(e)}
        self.write(json.dumps(dit))


class OptionRTQuoteHandler(BaseHandler):
    def get(self, *args, **kwargs):
        try:
            data = {}
            for k in self.application.quote:
                if ' ' in k:
                    data[k] = self.application.quote[k]
            dit = {'code': 0, 'data': data}
        except Exception as e:
            dit = {'code': -1, 'error': str(e)}
        self.write(json.dumps(dit, cls=MyEncoder))


class GetLastPrice(BaseHandler):
    def get(self, *args, **kwargs):
        try:
            code = self.get_argument('code', None)
            if code is None:
                self.write({
                    'code': 2000,
                    'error': "code 为空"
                })
            elif code in self.application.quote:
                self.write({
                    'code': 0,
                    'data': {
                        'LastPrice': self.application.quote[code].get('LastPrice', -1)
                    }
                })
            else:
                self.write({
                    'code': 2000,
                    'error': "合约未找到"
                })
        except Exception as err:
            self.write({
                'code': 2000,
                'error': "执行错误 %s" % err
            })


class UpdateFromDBHandler(BaseHandler):
    async def get(self):
        try:
            auth_code = self.get_argument('authcode', None)
            if auth_code != config.auth_code:
                self.write({
                    'code': 3000,
                    'error': "用户权限不对"
                })
                return
            source = []
            if self.get_argument('future', None):
                source.append('cfuture')
                # get latest future eop (dce, shfe, czce, cffex)
                sql = '.gw.asyncexec["select SYMBOL,CLOSEPRICE,EXCHANGE from CFuturesEODPrices where ' \
                      'TRADE_DT=max TRADE_DT"; `FuturesBasicInfo]'
                ret = get_kdb_data(sql)
                if not isinstance(ret, bytes):
                    for idx, v in ret.iterrows():
                        symbol = v['SYMBOL'].decode()
                        if v['EXCHANGE'] in (b'czce', b'cffex'):
                            symbol = symbol.upper()
                        # if symbol in self.application.quote:
                        if symbol:
                            self.application.quote['%s' % symbol] = {'LastPrice': float(v['CLOSEPRICE'])}
                            # self.application.quote['%s@CTP' % symbol] = {'LastPrice': float(v['CLOSEPRICE'])}
                            await self.application.r.hset(config.future_last_price,
                                                          '%s' % symbol, float(v['CLOSEPRICE']))
                else:
                    logger.debug("query cfuture failed %s", ret)
            if self.get_argument('stock', None):
                # update stock future
                source.append('stock')
                sql = '.gw.asyncexec["select SYMBOL,S_DQ_CLOSE from AShareEODPrices where TRADE_DT=max TRADE_DT";' \
                      '`EquityFactor]'
                ret = get_kdb_data(sql)
                if not isinstance(ret, bytes):
                    for idx, v in ret.iterrows():
                        symbol = v['SYMBOL'].decode()[:-3]
                        # if symbol in self.application.quote:
                        if symbol:
                            self.application.quote[symbol] = {'LastPrice': float(v['S_DQ_CLOSE'])}
                            await self.application.r.hset(config.stock_last_price,
                                                          symbol, float(v['S_DQ_CLOSE']))
                else:
                    logger.debug("query cfuture failed %s", ret)
            if self.get_argument('forex', None):
                sql = '.gw.asyncexec["select SYMBOL, EXCHANGE, CLOSEPRICE from ForeignEODPrices where ' \
                      'TRADE_DT=max TRADE_DT"; `FuturesBasicInfo]'
                ret = get_kdb_data(sql)
                if not isinstance(ret, bytes):
                    for idx, v in ret.iterrows():
                        symbol = v['SYMBOL'].decode()
                        exchange = v['EXCHANGE'].decode()
                        # ignore the
                        if exchange == 'IDEALPRO':
                            continue
                        # if symbol in self.application.quote:
                        if symbol:
                            adj_symbol = '%s@%s' % (symbol, exchange)
                            self.application.quote[adj_symbol] = {'LastPrice': float(v['CLOSEPRICE'])}
                            await self.application.r.hset(config.future_last_price,
                                                          adj_symbol, float(v['CLOSEPRICE']))
                else:
                    logger.debug("query cfuture failed %s", ret)
            self.write({
                'code': 0,
                'data': '操作成功'
            })
        except Exception as err:
            self.write({
                'code': 3000,
                'error': str(err)
            })


class UpdateManualHandler(BaseHandler):
    def get(self, *args, **kwargs):
        try:
            authcode = self.get_argument('authcode')
            if authcode != config.auth_code:
                self.write({
                    'code': 3000,
                    'error': "用户权限不对"
                })
                return
            cmd = self.get_argument('opt')
            if cmd == 'delete':
                code = self.get_argument('code')
                if code and code in self.application.quote:
                    del self.application.quote[code]
            elif cmd == 'backup':
                data = pickle.dumps(self.application.quote)
                try:
                    with open(config.backup_file, "wb") as f:
                        f.write(data)
                    logger.info("Backup the quote to disk")
                except Exception as err:
                    logger.error("Write the backup file %s", err, exc_info=True)
            elif cmd == 'recover':
                try:
                    if os.path.isfile(config.backup_file):
                        with open(config.backup_file, "rb") as f:
                            data = f.read()
                            self.application.quote = pickle.loads(data)
                        logger.info("Recover the quote from disk")
                    else:
                        logger.info("Recover Backup file not found")
                except Exception as err:
                    logger.error("Load the backup file failed %s", err, exc_info=True)
            elif cmd == 'update':
                code = self.get_argument('code')
                price = float(self.get_argument('last_px', '0'))
                self.application.quote[code] = {'LastPrice': price}
            self.write({
                'code': 0,
                'data': '手动操作 %s 成功' % cmd
            })
        except Exception as err:
            self.write({
                'code': 3000,
                'error': str(err)
            })


class CleanFutureQuoteHandler(BaseHandler):
    def kdb_days_to_date(self, days):
        """
        Change KDB dates stamp to normal date

        Parameters
        ---------
        days: integer
            kdb date stamp, example: 6971
        Returns
        -------
        str

        Examples
        -------
        >>> kdb_days_to_date(6971)
        """
        origin_date = datetime.date(2000, 1, 1)
        return str(origin_date + datetime.timedelta(days=days))

    def get_delist_dates(self):
        """
        查询合约到期日，返回过期的合约列表

        :return:
            A dict.
            For example:

            {'AU1305': '2020-05-07'}
        """
        data_dtype = np.dtype([
            ('S_INFO_WINDCODE', 'S11'),
            ('S_INFO_CODE', 'S7'),
            ('FS_INFO_SCCODE', 'S3'),
            ('FS_INFO_TYPE', '<i4'),
            ('FS_INFO_CCTYPE', '<i4'),
            ('S_INFO_EXCHMARKET', 'S5'),
            ('S_INFO_LISTDATE', '<i4'),
            ('S_INFO_DELISTDATE', '<i4'),
            ('FS_INFO_DLMONTH', '<i4'),
            ('FS_INFO_LPRICE', '<f8'),
            ('FS_INFO_LTDLDATE', '<i4'),
            ('OPDATE', '<f8'),
            ('OPMODE', '<i4'),
            ('date', '<i4')
        ], align=False)
        file_path = "/mnt/beegfs_npq107/basic/expire_date.npq"
        delist_dates = {}
        data = np.fromfile(file_path, dtype=data_dtype)
        # 由于获取到的到期日比真实的到期日提前了一周所有，这里设置now_date为两周前比较稳妥
        now_date = (datetime.datetime.now() + datetime.timedelta(days=-14)).strftime("%Y-%m-%d")
        for d in data:
            delist_date = self.kdb_days_to_date(int(d['S_INFO_DELISTDATE']))
            if now_date > delist_date:
                delist_dates[d['S_INFO_CODE'].decode('utf-8')] = delist_date
        return delist_dates

    def clean(self, name_list, targets, delist_dates):
        """
        执行清理数据的操作

        :param targets:         待清理的字典列表    For example: [list1, list2, ...]
        :param delist_dates:    到期日数据字典     For example: {'AU1305': '2020-05-07', ...}
        :return:
            clean_data: 已被清理的数据字典       For example: {'list1': ['AU1305', ...], ...}
        """
        clean_data = {}
        for index, target in enumerate(targets):
            clean_data_one = []

            for item in target.keys():
                if '@' in item:
                    item_ = item.split('@')[0].upper()
                    if item_ in delist_dates:
                        clean_data_one.append(item)
                else:
                    if item in delist_dates:
                        clean_data_one.append(item)

            for item in clean_data_one:
                del target[item]

            clean_data[name_list[index]] = clean_data_one
        return clean_data

    def get(self, *args, **kwargs):
        """
        清理过期的期货行情
        """
        try:
            delist_dates = self.get_delist_dates()

            dict_list = [
                self.application.future_last_price,
                self.application.future_total_volume,
                self.application.all_last_price,
                self.application.all_total_volume,
                self.application.quote,
            ]
            name_list = [
                "future_last_price",
                "future_total_volume",
                "all_last_price",
                "all_total_volume",
                "quote",
            ]

            clean_data = self.clean(name_list, dict_list, delist_dates)

            self.write({
                'code': 0,
                'data': {"clean_data": clean_data}
            })
        except Exception as err:
            self.write({
                'code': 3000,
                'error': str(err)
            })


class Application(tornado.web.Application):
    """
    Speed quote application
    """

    def __init__(self):
        tornado.ioloop.IOLoop.configure('tornado.platform.asyncio.AsyncIOLoop')
        handlers = [
            (r'/api/v1/speedquote/equityquote', LastQuoteHandler),
            (r'/api/v1/speedquote/latest_price', GetLastPrice),
            (r'/api/v1/speedquote/equityquote2', LastPriceHandler),
            (r'/api/v1/speedquote/option_rt_quote', OptionRTQuoteHandler),
            (r'/api/v1/speedquote/in_future_quote', InnerFutureQuoteHandler),

            (r'/api/v1/speedquote/update_from_db', UpdateFromDBHandler),
            (r'/api/v1/speedquote/update_manual', UpdateManualHandler),

            (r'/api/v1/speedquote/stock_last_price', StockLastPriceHandler),
            (r'/api/v1/speedquote/future_last_price', FutureLastPriceHandler),
            (r'/api/v1/speedquote/option_last_price', OptionLastPriceHandler),
            (r'/api/v1/speedquote/all_last_price', AllLastPriceHandler),

            (r'/api/v1/speedquote/stock_total_volume', StockTotalVolumeHandler),
            (r'/api/v1/speedquote/future_total_volume', FutureTotalVolumeHandler),
            (r'/api/v1/speedquote/option_total_volume', OptionTotalVolumeHandler),
            (r'/api/v1/speedquote/all_total_volume', AllTotalVolumeHandler),

            (r'/api/v1/speedquote/log_quote', LogQuoteHandler),
            (r'/api/v1/speedquote/update_time', UpdateTimeHandler),

            (r'/api/v1/speedquote/clean_future_quote', CleanFutureQuoteHandler),  # 设置定时任务调用接口，清理过期的期货行情
        ]
        # Previous tick date
        self.previous_stock_timestamp = None
        # Latest Quote container
        self.quote = {}

        # Container of last_price/total_volume of all/option/stock/future
        self.stock_last_price = {}
        self.option_last_price = {}
        self.future_last_price = {}
        self.all_last_price = {}
        self.stock_total_volume = {}
        self.option_total_volume = {}
        self.future_total_volume = {}
        self.all_total_volume = {}

        # cache for all response data
        self.map_buffer = {}

        # Set up redis connection.
        # Set up redis connection.
        self.already_dumped = False
        try:
            self.r = aredis.StrictRedis(host=config.REDIS_IP, port=6379, db=0)
            self.mkt_scan_hdl = market_scan.ScanMgr(self.r)
            ev_loop = tornado.ioloop.IOLoop.instance()
            ev_loop.run_sync(self.load_quote_from_redis)
        except Exception as e:
            logger.error("Transmit Server Started Failed %s", e, exc_info=True)
            sys.exit(2)
        super(Application, self).__init__(handlers)

    def mkt_routine_work(self):
        config.worker.apply_async(self.mkt_scan_hdl.check, (self.quote,))

    async def load_price_and_volume_from_redis(self):
        await self.load_dict_from_redis(config.all_last_price, self.all_last_price)
        await self.load_dict_from_redis(config.stock_last_price, self.stock_last_price)
        await self.load_dict_from_redis(config.option_last_price, self.option_last_price)
        await self.load_dict_from_redis(config.future_last_price, self.future_last_price)
        await self.load_dict_from_redis(config.all_total_volume, self.all_total_volume, is_int=True)
        await self.load_dict_from_redis(config.stock_total_volume, self.stock_total_volume, is_int=True)
        await self.load_dict_from_redis(config.option_total_volume, self.option_total_volume, is_int=True)
        await self.load_dict_from_redis(config.future_total_volume, self.future_total_volume, is_int=True)

    async def load_dict_from_redis(self, key, container, is_int=False):
        try:
            last_price = await self.r.hgetall(key)
            if last_price:
                for k, v in last_price.items():
                    if v:
                        if is_int:
                            container[k.decode('utf-8')] = int(v.decode('utf-8'))
                        else:
                            container[k.decode('utf-8')] = float(v.decode('utf-8'))
        except Exception as e:
            logger.error("load dict from redis error %s", e, exc_info=True)

    async def load_quote_from_redis(self):
        """
        load the quote from redis, it including two parts
            1. json of all kinds symbol's latest price
            2. several symbol's latest price queue
            3. last_price/total_volume of all/option/stock/future
        :return:
        """
        # load last_price/total_volume of all/option/stock/future from redis
        await self.load_price_and_volume_from_redis()

        quote = await self.r.hget(config.backup_quote, "quote")
        try:
            if quote:
                _quote = pickle.loads(quote)
                self.quote = {key: _quote[key] for key in _quote.keys() if key.find("@b'") == -1}
        except Exception as err:
            logger.error("load quote failed %s", err)

    async def dump_quote_to_redis(self):
        """
        Dump the quote data into redis
        :return:
        """
        await self.r.hset(config.backup_quote, "quote", pickle.dumps(self.quote))
        await self.mkt_scan_hdl.dump()
        logger.info("backup the data into redis success")
        self.already_dumped = True

    async def clean_option_quote(self):
        now = datetime.datetime.now()
        if now.hour in (8, 19) and 0 < now.minute < 10:
            to_del = []
            for code in self.quote:
                if ' ' in code:
                    to_del.append(code)
            for code in to_del:
                del self.quote[code]
            await self.r.delete(config.option_last_price)
            await self.r.delete(config.option_total_volume)
            self.option_last_price = {}
            self.option_total_volume = {}

    async def update_cache_buffer(self):
        for key in ['stock_last_price', 'stock_total_volume',
                    'future_last_price', 'future_total_volume',
                    'option_last_price', 'option_total_volume' 
                    'all_last_price', 'all_total_volume']:
            if hasattr(self, key):
                t1 = time.time()
                self.map_buffer[key] = json.dumps({
                    'code': 0, 'data': getattr(self, key)
                })
                t2 = time.time()
                if config.log_quote:
                    logger.info("dumps %s take time %s seconds", key, t2 - t1)
                await gen.sleep(0.1)
        data = {}
        t1 = time.time()
        for k, v in self.quote.items():
            if v:
                data[k] = {'LastPrice': v.get('LastPrice', None)}
        t2 = time.time()
        await gen.sleep(0.1)

        if config.log_quote:
            logger.info("transfer into dict time %s", t2 - t1)

        t1 = time.time()
        self.map_buffer['quote'] = json.dumps({'code': 0, 'data': data})
        t2 = time.time()
        if config.log_quote:
            logger.info("dumps original all time %s seconds", t2 - t1)

    async def top_signal_handler(self):
        """
        Store all memory into redis and stop the running server
        :return:
        """
        global stop_signal
        if not stop_signal:
            return None
        if self.already_dumped:
            return

        logger.info("Prepare to Reserve the Runtime Data")
        # dump latest price json data
        await self.dump_quote_to_redis()

        # stop the running server
        logger.info("Prepare to Stop the Running Server")
        http_server.stop()
        instance = tornado.ioloop.IOLoop.instance()
        deadline = time.time() + config.EXIT_WAIT_SECS

        def terminate():
            now = time.time()
            if now < deadline:
                instance.add_timeout(now + 1, terminate)
            else:
                instance.stop()
                logger.info('Shutdown Tornado IOLoop')
                print("Exit Success")

        terminate()

    def fetch_eod_prices(self):
        """ Fetch close prices.

        Notes
        -----
            Currently only close prices of equities is supported.
        """
        # TODO: #1 Synchronous Mode. this function will block main ioloop(http requests).
        hour = datetime.datetime.now().hour
        # Only fetch eod prices after day trading session.
        if (hour > 20) or (hour < 9):
            try:
                sql = '.gw.asyncexec["select SYMBOL,S_DQ_CLOSE from AShareEODPrices where' \
                      ' TRADE_DT = max TRADE_DT";`EquityFactor]'
                data = get_kdb_data(sql, False)
                data = dict(data)
                for k, v in data.items():
                    self.quote[k.decode()[0:-3]] = {'LastPrice': v}
                    self.stock_last_price[k.decode()[0:-3]] = v
            except:
                logger.debug("fetch eod failed %s", exc_info=True)

    async def fetch_equity_spot_quote(self):
        """
        Fetch quote

        get stoke and shge data from redis and futures data from speedquote interface
        1) equity quote from redis queue 'a:oss:quote:level_one' (raw binary format)
        2) shge quote from redis queue 'a:oss:quote:level_one' (json foramt)
        3) ctp quote from api

        Parameters:
        ----------
        quote: dict
            quote container
        r: redis handle

        """
        try:
            async with await self.r.pipeline(transaction=True) as _pipe:
                await _pipe.lrange(config.equity_queue, 0, -1)
                await _pipe.delete(config.equity_queue)
                pipe_return = await _pipe.execute()
        except Exception as e:
            logger.error("fetch equity from redis failed: %s", e)
            return None

        if pipe_return:
            # items are in pipe_return[0]
            for x in pipe_return[0]:
                if x[0:2] != b'{"':
                    # Binary data
                    # 16 bit length symbol
                    buffer_size = len(x)
                    if buffer_size == quote_type.level_one_dtype.itemsize:
                        tt = np.frombuffer(x, dtype=quote_type.level_one_dtype)
                    # 32 bit length symbol
                    elif buffer_size == quote_type.new_level_one_dtype.itemsize:
                        tt = np.frombuffer(x, dtype=quote_type.new_level_one_dtype)
                    # not valid buffer of data
                    elif buffer_size == quote_type.new2_level_one_dtype.itemsize:
                        tt = np.frombuffer(x, dtype=quote_type.new2_level_one_dtype)
                    else:
                        return None
                    tmp = dict(zip(tt.dtype.names, tt[0]))
                    tmp['szCode'] = tmp['szCode'].decode('utf-8')
                else:
                    tmp = json.loads(x.decode('utf-8'))

                # log quote
                if config.log_quote:
                    logger.info(tmp)

                # filter out foreign T code
                if tmp['szCode'].startswith('T1') and tmp['type'] == 5:
                    continue

                if tmp['szCode'].startswith('T2') and tmp['type'] == 5:
                    continue

                if tmp.get('LastPrice', 0) == 0:
                    logger.debug("Received lastprice == 0, data: %s", tmp)
                else:
                    # all option contracts include one space at least
                    if ' ' not in tmp['szCode']:
                        self.quote[tmp['szCode']] = tmp
                    if "Exchange" in tmp:
                        exch_sym = "%s@%s" % (tmp['szCode'], tmp['Exchange'].decode('utf-8'))
                        self.quote[exch_sym] = tmp
                    else:
                        logger.error("quote without exchange %s" % tmp)

                    # The last_price/total_volume of all/option/stock/future is put in dict and redis.
                    self.all_last_price[tmp['szCode']] = tmp['LastPrice']
                    self.all_total_volume[tmp['szCode']] = int(tmp['Volume'])

                    # Use pipeline to decrease the
                    # async with await self.r.pipeline(transaction=True) as _pipe:
                    # update global price and volume
                    # await _pipe.hset(config.all_last_price, tmp['szCode'], tmp['LastPrice'])
                    # await _pipe.hset(config.all_total_volume, tmp['szCode'], int(tmp['Volume']))
                    if " " in tmp['szCode']:
                        self.option_last_price[tmp['szCode']] = tmp['LastPrice']
                        self.option_total_volume[tmp['szCode']] = int(tmp['Volume'])
                        # update option price and volume
                        # await self.r.hset(config.option_last_price, tmp['szCode'], tmp['LastPrice'])
                        # await self.r.hset(config.option_total_volume, tmp['szCode'], int(tmp['Volume']))
                    elif "Exchange" in tmp:
                        if tmp["Exchange"] in (b'SH', b'SZ', 'SH', 'SZ'):
                            # update all stock price and volume
                            self.stock_last_price[tmp['szCode']] = tmp['LastPrice']
                            self.stock_total_volume[tmp['szCode']] = int(tmp['Volume'])
                            # await self.r.hset(config.stock_last_price, tmp['szCode'], tmp['LastPrice'])
                            # await self.r.hset(config.stock_total_volume, tmp['szCode'], int(tmp['Volume']))
                        else:
                            # update all future price and volume
                            self.future_last_price[tmp['szCode']] = tmp['LastPrice']
                            self.future_total_volume[tmp['szCode']] = int(tmp['Volume'])
                            # await self.r.hset(config.future_last_price, tmp['szCode'], tmp['LastPrice'])
                            # await self.r.hset(config.future_total_volume, tmp['szCode'], int(tmp['Volume']))
                    else:
                        logger.error("quote without exchange %s" % tmp)


def bottom_signal_handler(sig, frame):
    global stop_signal
    logger.debug("Caught Signal: %s", sig)
    stop_signal = True


if __name__ == "__main__":
    signal.signal(signal.SIGINT, bottom_signal_handler)
    signal.signal(signal.SIGTERM, bottom_signal_handler)

    app = Application()
    http_server = tornado.httpserver.HTTPServer(app)
    http_server.listen(config.port)

    # coroutine
    tornado.ioloop.PeriodicCallback(app.clean_option_quote, 360000).start()
    tornado.ioloop.PeriodicCallback(app.top_signal_handler, 1000).start()
    tornado.ioloop.PeriodicCallback(app.update_cache_buffer, 3000).start()
    tornado.ioloop.PeriodicCallback(app.fetch_equity_spot_quote, 2000).start()

    # routine
    tornado.ioloop.PeriodicCallback(app.fetch_eod_prices, 180000).start()
    tornado.ioloop.PeriodicCallback(app.mkt_routine_work, 90000).start()
    tornado.ioloop.IOLoop.instance().start()

# -*- coding: utf-8 -*-


import redis
import numpy as np
from csv import DictReader


rd_cli = redis.StrictRedis(host='192.168.4.123', port=6379, db=0)


new_level_one_dtype = np.dtype([
    ('type', 'i4'),
    ('TradingDay', 'i4'),
    ('Time', 'i4'),
    ('szCode', 'S32'),
    ('LastPrice', 'f8'),
    ('AskPrice', 'f8'),
    ('AskVol', 'i4'),
    ('BidPrice', 'f8'),
    ('BidVol', 'i4'),
    ('Volume', 'i8'),
    ('Turnover', 'f8'),
    ('HighLimited', 'f8'),
    ('LowLimited', 'f8'),
    ('OpenPrice', 'f8'),
    ('HighestPrice', 'f8'),
    ('LowestPrice', 'f8'),
    ('OpenInterest', 'f8')
], align=True)


def load_csv_quote(file):
    input_file = DictReader(open(file))
    print(input_file.fieldnames)
    data = [row for row in input_file]
    return data


def dict_to_struct(data_dict):
    data = np.zeros(1, dtype=new_level_one_dtype)
    data['szCode'] = 'btc_usdt'
    data['BidPrice'] = float(data_dict['b1'])
    data['AskPrice'] = float(data_dict['a1'])
    data['BidVol'] = float(data_dict['bq1'])
    data['AskVol'] = float(data_dict['aq1'])
    data['LastPrice'] = float(100.0)
    return data


if __name__ == "__main__":
    file = "exch_okcoin_btc_usdt_snapshot_20180517.csv"
    out = load_csv_quote(file)
    # rd_cli.set('bing', 'abc')
    for tick in out:
        np_data = dict_to_struct(tick)
        buf = bytes(np_data.tobytes())
        rd_cli.lpush('a:oss:quote:level_one', buf)


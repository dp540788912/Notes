# -*- coding: utf-8 -*-

"""
Load from stock tick
"""

import json

import redis


def write_to_redis():
    rh = redis.StrictRedis(host='192.168.1.14', port=6379)
    redis_key = 'a:oss:quote:level_one'
    data = {'AskVol': 200, 'szCode': u'300473', 'LastPrice': 33.170000000000002,
            'HighLimited': 37.189999999999998, 'AskPrice': 33.280000000000001,
            'HighestPrice': 33.869999999999997, 'LowLimited': 30.43,
            'OpenPrice': 33.810000000000002, 'Volume': 76000, 'TradingDay': 20180903,
            'BidVol': 500, 'BidPrice': 33.170000000000002, 'Time': 101439000,
            'LowestPrice': 33.009999999999998, 'type': 1,
            'OpenInterest': 0.0, 'Turnover': 2545177.0}

    str_data = json.dumps(data)
    print("lpush one key")
    rh.lpush(redis_key, str_data)


if __name__ == '__main__':
    write_to_redis()

import sys
sys.path.insert(0, '..')
from tornado import gen
import time


import config
# Change settings.
config.KDB_IP = "192.168.1.41"
config.KDB_USERNAME ='user1'
config.KDB_PASSWORD='password'

from speed_equity_quote import *
#####################

@gen.coroutine
def get_kdb_data():
    #TODO:Replace with npq data.
    date = time.strftime("%Y.%m.%d",time.localtime())
    print(config.KDB_IP)
    start=time.time()
    with qconnection.QConnection(config.KDB_IP,config.KDB_PORT,config.KDB_USERNAME,config.KDB_PASSWORD) as q:
        print('1')
        q.async('.gw.asyncexec["select SYMBOL,S_DQ_CLOSE from AShareEODPrices where TRADE_DT = max TRADE_DT";`EquityFactor]')#%(date))
        print('2')
        dat = yield q.receive()
        print('3')
    end=time.time()
    print('elapsed:',end-start)
    print(dat)
    return dict(dat)

#@gen.coroutine
def get_eof_prices():
    print("periodic")
    data =get_kdb_data()
    for k in data:
        print(k)


def test_main():
    app = Application()
    urls = [(r'/api/v1/speedquote/equityquote', LastCtpQuoteQuery),
            ]
    http_server = tornado.httpserver.HTTPServer(app)
    http_server.listen(config.port)
    #tornado.ioloop.PeriodicCallback(app.fetch_futures_quote,2000).start() 
    #tornado.ioloop.PeriodicCallback(get_eof_prices, 1000).start() 
    tornado.ioloop.PeriodicCallback(get_kdb_data, 1000).start() 
    #tornado.ioloop.PeriodicCallback(app.fetch_equity_spot_quote,2000).start() 
    tornado.ioloop.IOLoop.instance().start()

if __name__ == "__main__":
    test_main()


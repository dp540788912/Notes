#!/usr/bin/env python


import json
import redis
import quote_type
import numpy as np


redis_config = {
    'host': '127.0.0.1',
    'port': 6379,
    'db': 0
}


while True:
    rcn = redis.Redis(**redis_config)
    x = rcn.lindex('a:oss:quote:level_one', 0)
    # not json
    if x is not None and x[0:2] != b'{"':
        buffer_size = len(x)
        print(buffer_size, quote_type.level_one_dtype.itemsize, quote_type.new_level_one_dtype.itemsize)
        if buffer_size == quote_type.level_one_dtype.itemsize:
            print("one")
            tt = np.frombuffer(x, dtype=quote_type.level_one_dtype)
        # 32 bit length symbol
        elif buffer_size == quote_type.new_level_one_dtype.itemsize:
            tt = np.frombuffer(x, dtype=quote_type.new_level_one_dtype)
            print("two")
        # not valid buffer of data
        else:
            print("error")
            break
            tt = np.frombuffer(x, dtype=quote_type.level_one_dtype)
        tmp = dict(zip(tt.dtype.names, tt[0]))
        tmp['szCode'] = tmp['szCode'].decode('utf-8')
    else:
        # Json 
        if x is None:
            print("None")
            continue
        tmp = json.loads(x.decode('utf-8'))
    print(tmp)


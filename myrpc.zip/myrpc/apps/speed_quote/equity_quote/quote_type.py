# coding: utf-8

import numpy as np

level_one_dtype = np.dtype([
    ('type', 'i4'),
    ('TradingDay', 'i4'),
    ('Time', 'i4'),
    ('szCode', 'S16'),
    ('LastPrice', 'f8'),
    ('AskPrice', 'f8'),
    ('AskVol', 'i4'),
    ('BidPrice', 'f8'),
    ('BidVol', 'i4'),
    ('Volume', 'i8'),
    ('Turnover', 'f8'),
    ('HighLimited', 'f8'),
    ('LowLimited', 'f8'),
    ('OpenPrice', 'f8'),
    ('HighestPrice', 'f8'),
    ('LowestPrice', 'f8'),
    ('OpenInterest', 'f8')
], align=True)

new_level_one_dtype = np.dtype([
    ('type', 'i4'),
    ('TradingDay', 'i4'),
    ('Time', 'i4'),
    ('szCode', 'S32'),
    ('LastPrice', 'f8'),
    ('AskPrice', 'f8'),
    ('AskVol', 'i4'),
    ('BidPrice', 'f8'),
    ('BidVol', 'i4'),
    ('Volume', 'i8'),
    ('Turnover', 'f8'),
    ('HighLimited', 'f8'),
    ('LowLimited', 'f8'),
    ('OpenPrice', 'f8'),
    ('HighestPrice', 'f8'),
    ('LowestPrice', 'f8'),
    ('OpenInterest', 'f8')
], align=True)

new2_level_one_dtype = np.dtype([
    ('type', 'i4'),
    ('TradingDay', 'i4'),
    ('Time', 'i4'),
    ('szCode', 'S32'),
    ('LastPrice', 'f8'),
    ('AskPrice', 'f8'),
    ('AskVol', 'i4'),
    ('BidPrice', 'f8'),
    ('BidVol', 'i4'),
    ('Volume', 'i8'),
    ('Turnover', 'f8'),
    ('HighLimited', 'f8'),
    ('LowLimited', 'f8'),
    ('OpenPrice', 'f8'),
    ('HighestPrice', 'f8'),
    ('LowestPrice', 'f8'),
    ('OpenInterest', 'f8'),
    ('Exchange', 'S32'),
    ('VProcessID', 'i4')
], align=True)


if __name__ == "__main__":
    import numpy as np
    x = np.zeros(1, dtype=new_level_one_dtype)
    print(x.itemsize)

    x = np.zeros(1, dtype=level_one_dtype)
    print(x.itemsize)

    print(new_level_one_dtype.itemsize)

    x = np.zeros(1, dtype=new2_level_one_dtype)
    print(new2_level_one_dtype.itemsize)
    print(x.dtype.names)

    print(len(b'abc'))


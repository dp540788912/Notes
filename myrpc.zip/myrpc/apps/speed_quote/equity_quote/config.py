# coding: utf-8

import logging
import netifaces
from multiprocessing.pool import ThreadPool
from logging.handlers import RotatingFileHandler

iplist = [netifaces.ifaddresses(i).get(netifaces.AF_INET)[0]['addr']
          for i in netifaces.interfaces()
          if netifaces.ifaddresses(i).get(netifaces.AF_INET)]

if '192.168.10.100' in iplist or '192.168.10.109' in iplist:
    DEBUG = False
else:
    DEBUG = True

# Equity quote service port
port = 10010

# Equity quote key in redis.
equity_queue = 'a:oss:quote:level_one'
backup_quote = 'a:oss:speed_quote:backup'
auth_code = '67MI5CmnoYUFvtITCE2ABQ=='
backup_file = "backup_quote.pkl"

stock_last_price = 'a:oss:quote:stock_last_price'
future_last_price = 'a:oss:quote:future_last_price'
option_last_price = 'a:oss:quote:option_last_price'
all_last_price = 'a:oss:quote:all_last_price'

stock_total_volume = 'a:oss:stock_total_volume'
future_total_volume = 'a:oss:future_total_volume'
option_total_volume = 'a:oss:option_total_volume'
all_total_volume = 'a:oss:all_total_volume'


worker = ThreadPool(1)

if DEBUG:
    KDB_IP = "192.168.1.41"
    REDIS_IP = "192.168.4.164"
    KDB_CACHE_IP = '192.168.4.123'
    mysql_cfg = {
        'host': '192.168.1.14',
        'port': 3306,
        'user': 'root',
        'passwd': '123456',
        'db': 'datahub'
    }
    # CTP quote querying API
    ctp_quote_url = "http://192.168.1.14:10008/api/v1/speedquote/quote/last_ctp"
    # alert API
    plf_alert_url = "http://192.168.1.14:18886/api/v1/event_handle/trigger_event/event"
else:
    KDB_IP = "192.168.10.102"
    REDIS_IP = "127.0.0.1"
    KDB_CACHE_IP = '192.168.10.103'
    mysql_cfg = {
        'host': '127.0.0.1',
        'port': 3306,
        'user': 'root',
        'passwd': '123456',
        'db': 'datahub'
    }
    # CTP quote querying API
    ctp_quote_url = "http://127.0.0.1:10008/api/v1/speedquote/quote/last_ctp"
    # alert API
    plf_alert_url = "http://127.0.0.1:18886/api/v1/event_handle/trigger_event/event"

KDB_CACHE_PORT = 5500
KDB_PORT = 9000
KDB_USERNAME = "fR#cV%nL@cL=uR`bD(mM)lO/iD(fE#"
KDB_PASSWORD = "eB1*cC2&uK3#gL6@gD7^pS4#bH9^cG"
ROTATE_LOG_SIZE = 1024 * 1024 * 50
LOG_BACKUP_COUNT = 10


# previous 12 tick data
EXIT_WAIT_SECS = 2
MAX_QUEUE_SIZE = 4320
DEF_FETCH_SIZE = 4320
QUEUE_QUOTE_LIST = {
    # spot usdt
    'btc_usdt', 'bch_usdt', 'eth_usdt', 'etc_usdt', 'ltc_usdt', 'eos_usdt', 'xrp_usdt',
    # spot btc
    'bch_btc', 'eth_btc', 'ltc_btc', 'etc_btc', 'eos_btc', 'xrp_btc',
    # spot eth
    'bch_eth', 'ltc_eth', 'etc_eth', 'eos_eth', 'xrp_eth',
    # future btc
    'fut_btc_tw', 'fut_btc_nw', 'fut_btc_qt', 'fut_ltc_tw', 'fut_ltc_nw',
    'fut_ltc_qt', 'fut_eth_tw', 'fut_eth_nw', 'fut_eth_qt',
    # future etc
    'fut_etc_tw', 'fut_etc_nw', 'fut_etc_qt', 'fut_bch_tw', 'fut_bch_nw', 'fut_bch_qt',
    # future xrp
    'fut_xrp_tw', 'fut_xrp_nw', 'fut_xrp_qt',
    # future eos
    'fut_eos_tw', 'fut_eos_nw', 'fut_eos_qt',
}

logger = logging.getLogger()
if DEBUG:
    logger.setLevel(logging.DEBUG)
else:
    logger.setLevel(logging.INFO)
handler = RotatingFileHandler("equity_quote.log",
                              maxBytes=ROTATE_LOG_SIZE,
                              backupCount=LOG_BACKUP_COUNT)
formatter = logging.Formatter(fmt='%(asctime)s - %(pathname)s[line:%(lineno)d] - %(levelname)s: %(message)s')
handler.setFormatter(formatter)
logger.handlers.clear()
logger.addHandler(handler)

log_quote = False

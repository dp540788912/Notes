# -*- coding: utf-8 -*-

import datetime
import functools
import pickle
from qpython import qconnection
from contextlib import contextmanager

import requests
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import config
from config import logger, mysql_cfg

engine = create_engine('mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s?charset=utf8' % mysql_cfg,
                       pool_pre_ping=True,
                       pool_recycle=3600)
Session = sessionmaker(bind=engine)


@contextmanager
def session_context():
    session = Session()
    try:
        yield session
        session.commit()
    except:
        session.rollback()
        raise
    finally:
        session.close()


def singleton(cls):
    instances = {}

    @functools.wraps(cls)
    def wrapper(*args, **kwargs):
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)
        return instances[cls]
    return wrapper


def is_domestic_future_time(sp_time):
    # AM9:00—10:15 10:30-11:30 PM 13:30-15:00 21:00-02:30
    if datetime.time(9, 0, 30) <= sp_time <= datetime.time(10, 15, 0):
        return True
    if datetime.time(10, 30, 30) <= sp_time <= datetime.time(11, 30, 0):
        return True
    if datetime.time(13, 30, 30) <= sp_time <= datetime.time(15, 00, 0):
        return True
    if datetime.time(21, 0, 30) <= sp_time <= datetime.time(23, 59, 59):
        return True
    if datetime.time(0, 0, 0) <= sp_time <= datetime.time(2, 30, 0):
        return True
    return False


def is_domestic_stock_time(sp_time):
    # 9:30-11:30 PM1:00-3:00
    if datetime.time(9, 30, 30) <= sp_time <= datetime.time(11, 30, 0):
        return True
    if datetime.time(13, 0, 30) <= sp_time <= datetime.time(15, 0, 0):
        return True
    return False


def is_trading_time(join_key, now_time):
    exchange, process_id = join_key
    if exchange in ["SH", "SZ", b"SH", b"SZ"]:
        return is_domestic_stock_time(now_time)
    else:
        return is_domestic_future_time(now_time)


def scan_market(pre_static, market, now_time):
    """
    identify whether market is not update for one minute
    return (alert_key_list, current_static)
    :return:
    """
    alert_key_list = []
    current_static = {}
    for key, item in market.items():
        if "Exchange" in item and "Volume" in item and "VProcessID" in item:
            # print("right?")
            join_key = (item["Exchange"], item["VProcessID"])
            # print(join_key)
            current_static.setdefault(join_key, 0)
            current_static[join_key] += item["Volume"]
    if pre_static is None:
        return alert_key_list, current_static
    for join_key, item in current_static.items():
        if pre_static.get(join_key) == item:
            if not is_trading_time(join_key, now_time):
                # non-trading time means always valid
                continue
            alert_key_list.append(join_key)
    return alert_key_list, current_static


def get_trade_days():
    kdate = str(datetime.datetime.today().date()).replace('-', '.')
    sql = '.gw.asyncexec["select TRADE_DT, HAS_NIGHT from Calendar where TRADE_DT>=%s, EXCHANGE=`SHFE";' \
          '`FuturesBasicInfo]' % kdate
    day_night_list = set()
    with qconnection.QConnection(config.KDB_IP, config.KDB_PORT, config.KDB_USERNAME, config.KDB_PASSWORD) as q:
        q.async(sql)
        ret = q.receive(pandas=True)
        for idx, row in ret.iterrows():
            the_date = str(row.TRADE_DT.date())
            day_night_list.add((the_date, 0))
            if row.HAS_NIGHT == 1:
                day_night_list.add((the_date, 1))
    return day_night_list


def get_host_by_process_id(process_id):
    with session_context() as sc:
        items = sc.execute("select id, host from deploy_confs where id=%d" % process_id).fetchall()
        if items:
            return items[0][1]
    return "Host of process_id %s" % process_id


def alert_to_platform(exchange, process_id, is_err=True):
    try:
        if isinstance(exchange, bytes):
            exchange = exchange.decode('utf-8')
        host = get_host_by_process_id(process_id)
        # it not found the host, then take 192.168.10.114 as the default address 546 as the default process_id
        if "Host" in host or process_id == 0:
            logger.info("alert host not found %s, %s, %s", exchange, process_id, is_err)
            host = "192.168.10.106"
            process_id = 1039
        headers = {
            'content-type': 'application/json',
            'whitelist': 'operater',
        }
        post_msg = {
            "key": "103",
            "host": host,
            "process_id": int(process_id),
            "operator": "=",
            "threshold": -1,
            "msg": "[交易所行情异常] Exchange %s Host %s ProcessID %s quote not update for one minute" %
                   (exchange, host, process_id),
            "status": -1 if is_err else 0,
            "clock": str(datetime.datetime.now()),
        }
        # print(post_msg)
        logger.info("alert to platform %s, %s, %s", exchange, process_id, is_err)
        # resp = requests.post(config.plf_alert_url, json=post_msg, headers=headers)
        # logger.info("the alert ret msg is %s", resp.content)
    except Exception as err:
        logger.error("alert to platform failed %s", err, exc_info=True)


@singleton
class ScanMgr:
    def __init__(self, r_conn):
        self.r_conn = r_conn
        self.alert_set = set()
        self.pre_static = None
        self.trading_days = get_trade_days()
        # logger.debug("the trading days %s", sorted(list(self.trading_days)))

    async def dump(self):
        # print("dump alert_set", self.alert_set)
        # print("dump pre_static", self.pre_static)
        await self.r_conn.hset(config.backup_quote, "alert_set", pickle.dumps(self.alert_set))
        await self.r_conn.hset(config.backup_quote, "pre_static", pickle.dumps(self.pre_static))
        logger.debug("dump alert_set %s", self.alert_set)
        logger.debug("dump pre_static %s", self.pre_static)

    async def load(self):
        alert_set = await self.r_conn.hget(config.backup_quote, "alert_set")
        if alert_set:
            self.alert_set = pickle.loads(alert_set)
            # print("load alert_set", self.alert_set)
            logger.debug("load alert_set is %s", self.alert_set)
        else:
            self.alert_set = set()
        pre_static = await self.r_conn.hget(config.backup_quote, "pre_static")
        if pre_static:
            self.pre_static = pickle.loads(pre_static)
            # print("load pre_static", self.pre_static)
            logger.debug("load pre_static is %s", self.pre_static)
        else:
            self.pre_static = None

    def clear_alert(self):
        # clear alert history while trading day finish
        self.alert_set.clear()
        self.pre_static.clear()

    def check(self, market):
        """
        check market data every one minute
        :return:
        """
        # print("run one minute call", market)
        now_time = datetime.datetime.now()
        date_str = str(now_time.date())
        if 17 > now_time.hour > 8:
            day_night = 0
        else:
            day_night = 1
        # print(date_str, day_night)
        if (date_str, day_night) not in self.trading_days:
            return
        # print("come to right switch")
        now_time = now_time.time()
        alert_key_list, current_static = scan_market(self.pre_static, market, now_time)
        # print(alert_key_list, current_static)

        for alert_msg in alert_key_list:
            if alert_msg not in self.alert_set:
                # send alert msg and insert item into alert_set
                exchange, process_id = alert_msg
                if not is_trading_time((exchange, process_id), now_time):
                    # non-trading time will not update the status
                    continue
                self.alert_set.add(alert_msg)
                alert_to_platform(exchange, process_id, is_err=True)
        to_remove = []
        for alert_msg in self.alert_set:
            if alert_msg not in alert_key_list:
                # send recover msg and remove item in self.alert_set
                exchange, process_id = alert_msg
                if not is_trading_time((exchange, process_id), now_time):
                    # non-trading time will not update the status
                    continue
                to_remove.append(alert_msg)
                alert_to_platform(exchange, process_id, is_err=False)
        for item in to_remove:
            self.alert_set.remove(item)
        self.pre_static = current_static


if __name__ == '__main__':
    import sys
    import inspect
    import aredis
    import asyncio
    r = aredis.StrictRedis(host=config.REDIS_IP, port=6379, db=0)

    def test_case0():
        print("test_case0")
        x = ScanMgr(r)
        x.check({"a": {"Exchange": "SHFE", "VProcessID": 80, "Volume": 200},
                 "b": {"Exchange": "SHFE", "VProcessID": 81, "Volume": 200}})
        x.check({"a": {"Exchange": "SHFE", "VProcessID": 80, "Volume": 200},
                 "b": {"Exchange": "SHFE", "VProcessID": 81, "Volume": 200}})
        x.check({})

    def test_case1():
        print("test_case1")
        x = ScanMgr(r)
        x.check({"a": {"Exchange": "SHFE", "VProcessID": 80, "Volume": 200}})
        x.check({"a": {"Exchange": "SHFE", "VProcessID": 80, "Volume": 200}})

    def test_case2():
        print("test_case2")
        x = ScanMgr(r)
        x.check({"a": {"Exchange": "SHFE", "VProcessID": 80, "Volume": 200},
                 "b": {"Exchange": "SHFE", "VProcessID": 81, "Volume": 200}})
        x.check({"a": {"Exchange": "SHFE", "VProcessID": 80, "Volume": 210},
                 "b": {"Exchange": "SHFE", "VProcessID": 81, "Volume": 200}})
        x.check({"a": {"Exchange": "SHFE", "VProcessID": 80, "Volume": 210},
                 "b": {"Exchange": "SHFE", "VProcessID": 81, "Volume": 220}})
        x.check({"a": {"Exchange": "SHFE", "VProcessID": 80, "Volume": 210},
                 "b": {"Exchange": "SHFE", "VProcessID": 81, "Volume": 220}})

    def test_case3():
        print("test_case3")
        x = ScanMgr(r)
        asyncio.get_event_loop().run_until_complete(x.dump())
        asyncio.get_event_loop().run_until_complete(x.load())

    def test_case4():
        _quote = {"HO1901@b'NYMEX'": 1, "000099.SH": 2}
        out = {key: _quote[key] for key in _quote.keys() if key.find("@b'") == -1}
        print(out)


    def test_all():
        funcs = [obj for name, obj in inspect.getmembers(sys.modules[__name__])
                 if (inspect.isfunction(obj) and name.startswith('test_case'))]
        return any(f() for f in funcs)

    test_all()

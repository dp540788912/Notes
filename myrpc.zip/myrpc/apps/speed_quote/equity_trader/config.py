# coding: utf-8

import os
import logging
import netifaces
from logging.handlers import RotatingFileHandler

iplist = [netifaces.ifaddresses(i).get(netifaces.AF_INET)[0]['addr']
          for i in netifaces.interfaces() if netifaces.ifaddresses(i).get(netifaces.AF_INET)]

if '192.168.10.100' in iplist or '192.168.10.109' in iplist:
    DEBUG = False
else:
    DEBUG = True

# Equity quote service port
port = 13333
EXIT_WAIT_SECS = 1

"""
Start Redis Configuration
"""
if DEBUG:
    redis_ip = '127.0.0.1'
else:
    redis_ip = '192.168.30.100'

redis_port = 6379

# Fetch account information queue
check_queue = 'a:oss:query:result'
# Backup account information queue
backup_queue = 'a:oss:backup:account_data'

"""
Log Configuration
"""
ROTATE_LOG_SIZE = 1024 * 1024 * 50
LOG_BACKUP_COUNT = 10
logger = logging.getLogger()
if DEBUG:
    logger.setLevel(logging.DEBUG)
else:
    logger.setLevel(logging.INFO)

cur_dir = os.path.abspath(os.path.dirname(__file__))
log_file = os.path.join(cur_dir, 'equity_query.log')

handler = RotatingFileHandler(log_file,
                              maxBytes=ROTATE_LOG_SIZE,
                              backupCount=LOG_BACKUP_COUNT)
formatter = logging.Formatter(fmt='%(asctime)s - %(pathname)s[line:%(lineno)d] - %(levelname)s: %(message)s')
handler.setFormatter(formatter)
logger.handlers.clear()
logger.addHandler(handler)

# -*- coding: utf-8 -*-

from enum import Enum

from equity_trader.config import logger
from equity_trader.parser.CTP import CTP
from equity_trader.parser.FS import FS
from equity_trader.parser.GT import GT
from equity_trader.parser.SL import SL
from equity_trader.parser.TDX import TDX
from equity_trader.parser.ZX import ZX
from equity_trader.parser.common import SingleTunnel, convert_np_type


class APITypeEnum(Enum):
    CTP_TYPE = 1
    ZX_TYPE = 6
    SL_TYPE = 9
    FS_TYPE = 14
    HB_TDX_TYPE = 17
    ZX_TDX_TYPE = 21
    HT_TDX_TYPE = 24
    GT_TYPE = 100

    __PARSER_MAPPER__ = {
        CTP_TYPE: CTP,
        ZX_TYPE: ZX,
        SL_TYPE: SL,
        FS_TYPE: FS,
        HB_TDX_TYPE: TDX,
        ZX_TDX_TYPE: TDX,
        HT_TDX_TYPE: TDX,
        GT_TYPE: GT,
    }

    __CTP_KEY__ = ['PreBalance', 'Balance']
    __TDX_KEY__ = ['total_assets', 'total_assets']
    __GEN_KEY__ = ['margin', 'margin']

    __CASH_KEY_MAPPER__ = {
        CTP_TYPE: __CTP_KEY__,
        ZX_TYPE: __CTP_KEY__,
        SL_TYPE: __CTP_KEY__,
        FS_TYPE: __CTP_KEY__,
        HB_TDX_TYPE: __TDX_KEY__,
        ZX_TDX_TYPE: __TDX_KEY__,
        HT_TDX_TYPE: __TDX_KEY__,
        GT_TYPE: __GEN_KEY__,
    }

    __ALL_TDX_TYPE__ = [HB_TDX_TYPE, ZX_TDX_TYPE, HT_TDX_TYPE]

    def get_parser(self):
        return self.__PARSER_MAPPER__[self.value]

    def get_cash_key(self):
        return self.__CASH_KEY_MAPPER__[self.value]

    @classmethod
    def get_tdx_type(cls):
        return cls.__ALL_TDX_TYPE__

    @classmethod
    def has_value(cls, value):
        return any(value == item.value for item in cls)


class Tunnels:
    Positions = {}
    Accounts = {}

    def __init__(self):
        self.Positions.clear()
        self.Accounts.clear()

    def add(self, data):
        c = SingleTunnel(data)
        # can't deal with current api type now
        if not APITypeEnum.has_value(c.api_type):
            logger.debug("we can't deal with: %s", data)
            return
        api_enum = APITypeEnum(c.api_type)
        data_parser = api_enum.get_parser()(data)
        # debug the input message
        data_parser.print_p()
        account_key = str(c.counter)
        # new message of account position
        if c.data_type == 1:
            data_parser.parse_buffer()
            if c.api_type in APITypeEnum.get_tdx_type():
                # query all data in one query opt for tdx
                self.Positions[account_key] = data_parser.position_list
            else:
                if account_key not in self.Positions:
                    self.Positions[account_key] = []
                if data_parser.position_list:
                    if isinstance(data_parser.position_list, list):
                        self.Positions[account_key].extend(data_parser.position_list)
                    else:
                        self.Positions[account_key].append(data_parser.position_list)
            logger.info("new come position information: %s", self.Positions[account_key])
        # new message of account cash
        elif c.data_type == 0:
            data_parser.parse_buffer()
            if len(data_parser.buf_json) == 1:
                # list of dictionary data
                json_res = data_parser.buf_json[0]
                json_res = convert_np_type(json_res)
                # new format
                if 'currency' in json_res and 'margin' in json_res:
                    self.Accounts[account_key] = [json_res]
                else:
                    cash_key = api_enum.get_cash_key()
                    self.Accounts[account_key] = {
                        'PreBalance': json_res[cash_key[0]],
                        'Balance': json_res[cash_key[1]]
                    }
            else:
                self.Accounts[account_key] = []
                for jr in data_parser.buf_json:
                    jr = convert_np_type(jr)
                    self.Accounts[account_key].append(jr)
            logger.info("new come account information: %s", self.Accounts[account_key])

    @staticmethod
    def _remove_duplicate(dict_list):
        res = []
        for dic in dict_list:
            if dic.keys() not in [x.keys() for x in res if x]:
                res.append(dic)
        return res

    def tidy(self):
        tmp = {}
        for k, v in self.Positions.items():
            # key is account, v is account position, do data copy
            tmp[k] = [] + v
        res = {}
        for k, v in tmp.items():
            res[k] = self.__class__._remove_duplicate(v)
        self.Positions = res

# -*- coding: utf-8 -*-

import numpy as np
import redis
from equity_trader.config import logger
from equity_trader.parser.common import AbstractSingleTunnel
from equity_trader.tradelist import get_end_price

my_ctp_order = np.dtype([
    ('BrokerID', 'S11'),
    ('InvestorID', 'S13'),
    ('InstrumentID', 'S31'),
    ('OrderRef', 'S13'),
    ('UserID', 'S16'),
    ('OrderPriceType', 'S1'),
    ('Direction', 'S1'),
    ('CombOffsetFlag', 'S5'),
    ('CombHedgeFlag', 'S5'),
    ('LimitPrice', 'f8'),
    ('VolumeTotalOriginal', 'i4'),
    ('TimeCondition', 'S1'),
    ('GTDDate', 'S9'),
    ('VolumeCondition', 'S1'),
    ('MinVolume', 'i4'),
    ('ContingentCondition', 'S1'),
    ('StopPrice', 'f8'),
    ('ForceCloseReason', 'S1'),
    ('IsAutoSuspend', 'i4'),
    ('BusinessUnit', 'S21'),
    ('RequestID', 'i4'),
    ('OrderLocalID', 'S13'),
    ('ExchangeID', 'S9'),
    ('ParticipantID', 'S11'),
    ('ClientID', 'S11'),
    ('ExchangeInstID', 'S31'),
    ('TraderID', 'S21'),
    ('InstallID', 'i4'),
    ('OrderSubmitStatus', 'S1'),
    ('NotifySequence', 'i4'),
    ('TradingDay', 'S9'),
    ('SettlementID', 'i4'),
    ('OrderSysID', 'S21'),
    ('OrderSource', 'S1'),
    ('OrderStatus', 'S1'),
    ('OrderType', 'S1'),
    ('VolumeTraded', 'i4'),
    ('VolumeTotal', 'i4'),
    ('InsertDate', 'S9'),
    ('InsertTime', 'S9'),
    ('ActiveTime', 'S9'),
    ('SuspendTime', 'S9'),
    ('UpdateTime', 'S9'),
    ('CancelTime', 'S9'),
    ('ActiveTraderID', 'S21'),
    ('ClearingPartID', 'S11'),
    ('SequenceNo', 'i4'),
    ('FrontID', 'i4'),
    ('SessionID', 'i4'),
    ('UserProductInfo', 'S11'),
    ('StatusMsg', 'S81'),
    ('UserForceClose', 'i4'),
    ('ActiveUserID', 'S16'),
    ('BrokerOrderSeq', 'i4'),
    ('RelativeOrderSysID', 'S21'),
    ('ZCETotalTradedVolume', 'i4'),
    ('IsSwapOrder', 'i4'),
], align=True)

my_ctp_trade = np.dtype([
    ('BrokerID', 'V11'),
    ('InvestorID', 'V13'),
    ('InstrumentID', 'V31'),
    ('OrderRef', 'V13'),
    ('UserID', 'V16'),
    ('ExchangeID', 'S9'),
    ('TradeID', 'S21'),
    ('Direction', 'S1'),
    ('OrderSysID', 'S21'),
    ('ParticipantID', 'S11'),
    ('ClientID', 'S11'),
    ('TradingRole', 'S1'),
    ('ExchangeInstID', 'S31'),
    ('OffsetFlag', 'S'),
    ('HedgeFlag', 'S'),
    ('Price', 'f8'),
    ('Volume', 'i4'),
    ('TradeDate', 'S9'),
    ('TradeTime', 'S9'),
    ('TradeType', 'S'),
    ('PriceSource', 'S'),
    ('TraderID', 'S21'),
    ('OrderLocalID', 'S13'),
    ('ClearingPartID', 'S11'),
    ('BusinessUnit', 'S21'),
    ('SequenceNo', 'i4'),
    ('TradingDay', 'S9'),
    ('SettlementID', 'i4'),
    ('BrokerOrderSeq', 'i4'),
    ('TradeSource', 'S1'),
], align=True)

my_ctp_balance = np.dtype([
    ('BrokerID', 'S11'),
    ('AccountID', 'S13'),
    ('PreMortgage', 'f8'),
    ('PreCredit', 'f8'),
    ('PreDeposit', 'f8'),
    ('PreBalance', 'f8'),
    ('PreMargin', 'f8'),
    ('InterestBase', 'f8'),
    ('Interest', 'f8'),
    ('Deposit', 'f8'),
    ('Withdraw', 'f8'),
    ('FrozenMargin', 'f8'),
    ('FrozenCash', 'f8'),
    ('FrozenCommission', 'f8'),
    ('CurrMargin', 'f8'),
    ('CashIn', 'f8'),
    ('Commission', 'f8'),
    ('CloseProfit', 'f8'),
    ('PositionProfit', 'f8'),
    ('Balance', 'f8'),
    ('Available', 'f8'),
    ('WithdrawQuota', 'f8'),
    ('Reserve', 'f8'),
    ('TradingDay', 'S9'),
    ('SettlementID', 'i4'),
    ('Credit', 'f8'),
    ('Mortgage', 'f8'),
    ('ExchangeMargin', 'f8'),
    ('DeliveryMargin', 'f8'),
    ('ExchangeDeliveryMargin', 'f8'),
], align=True)

my_ctp_position = np.dtype([
    ('InstrumentID', 'S31'),
    ('BrokerID', 'S11'),
    ('InvestorID', 'S13'),
    ('PosiDirection', 'S1'),
    ('HedgeFlag', 'S1'),
    ('PositionDate', 'S1'),
    ('YdPosition', 'i4'),
    ('Position', 'i4'),
    ('LongFrozen', 'i4'),
    ('ShortFrozen', 'i4'),
    ('LongFrozenAmount', 'f8'),
    ('ShortFrozenAmount', 'f8'),
    ('OpenVolume', 'i4'),
    ('CloseVolume', 'i4'),
    ('OpenAmount', 'f8'),
    ('CloseAmount', 'f8'),
    ('PositionCost', 'f8'),
    ('PreMargin', 'f8'),
    ('UseMargin', 'f8'),
    ('FrozenMargin', 'f8'),
    ('FrozenCash', 'f8'),
    ('FrozenCommission', 'f8'),
    ('CashIn', 'f8'),
    ('Commission', 'f8'),
    ('CloseProfit', 'f8'),
    ('PositionProfit', 'f8'),
    ('PreSettlementPrice', 'f8'),
    ('SettlementPrice', 'f8'),
    ('TradingDay', 'S9'),
    ('SettlementID', 'i4'),
    ('OpenCost', 'f8'),
    ('ExchangeMargin', 'f8'),
    ('CombPosition', 'i4'),
    ('CombLongFrozen', 'i4'),
    ('CombShortFrozen', 'i4'),
    ('CloseProfitByDate', 'f8'),
    ('CloseProfitByTrade', 'f8'),
    ('TodayPosition', 'i4'),
    ('MarginRateByMoney', 'f8'),
    ('MarginRateByVolume', 'f8'),
], align=True)


class CTP(AbstractSingleTunnel):
    m = [my_ctp_balance, my_ctp_position, my_ctp_order, my_ctp_trade]

    def __init__(self, data_frame):
        super(CTP, self).__init__(data_frame)

    def parse_buffer(self):
        res = []
        try:
            data_type = self.m[self.data_type]
            keys = self.m[self.data_type].names
            parsed_data = np.frombuffer(self.buf, dtype=data_type)
            for x in parsed_data:
                res.append(dict(zip(keys, x)))
            self.buf_json = res
            logger.info("CTP %s", self.buf_json)
            self.set_position()
        except Exception as err:
            logger.error("the error time:%s, %s", self.__class__.__name__, err, exc_info=True)
        return res

    def set_position(self):
        if self.data_type == 1:
            position_dic = {}
            for x in self.buf_json:
                key = x['InstrumentID'].decode()
                if key.startswith("SP ") or key.startswith("SPC"):
                    logger.info("CTP Received position symbol SP(C) symbol: %s, bypass", key)
                    continue
                if not int(x['Position']):
                    logger.info("CTP Received position symbol %s pos is 0", key)
                    continue
                position_dic.setdefault(key, {
                    'long': 0,
                    'short': 0,
                    'price': get_end_price(key, "future", self.get_date(), 1)
                })
                direction_flag = None
                date_flag = None
                volume = int(x['Position'])
                # sum the today position and yesterday position
                if int(x['PositionDate']) == 1:
                    # this means today position
                    date_flag = 'today'
                    if int(x['PosiDirection']) == 2:
                        # this parsed as long position
                        direction_flag = 'long'
                        position_dic[key]['long'] += volume
                    if int(x['PosiDirection']) == 3:
                        # this parsed as short position
                        direction_flag = 'short'
                        position_dic[key]['short'] += volume
                elif int(x['PositionDate']) == 2:
                    date_flag = 'yesterday'
                    # this means yesterday position
                    if int(x['PosiDirection']) == 2:
                        direction_flag = 'long'
                        # this parsed as long position
                        position_dic[key]['long'] += volume
                    if int(x['PosiDirection']) == 3:
                        direction_flag = 'short'
                        # this parsed as short position
                        position_dic[key]['short'] += volume
                logger.debug("Received position symbol: %s direction: %s, date_spec: %s, volume: %s",
                             key, direction_flag, date_flag, volume)
            # get the first symbol data in the queue
            for symbol, value in position_dic.items():
                for x in self.position_list:
                    if symbol in x.keys():
                        break
                else:
                    self.position_list.append({symbol: value})


if __name__ == "__main__":
    from equity_trader import config

    r = redis.Redis(host=config.redis_ip, port=config.redis_port, db=0)

    def get_data(rh):
        _pipe = rh.pipeline()
        _pipe.lrange(config.check_queue, 0, -1)
        return _pipe.execute()[0]

    data = get_data(r)
    for i in range(len(data)):
        if i == 5:
            t = CTP(data[i])
            print(data[i])
            t.print_p()
            data = t.parse_buffer()
            print(t.position_list)

# -*- coding: utf-8 -*-
"""
Fei Shu Tunnel
"""

import time

import numpy as np
import redis
from equity_trader.config import logger
from equity_trader.parser.common import AbstractSingleTunnel

my_sgit_order = np.dtype([
    ('BrokerID', 'S11'),
    ('InvestorID', 'S13'),
    ('InstrumentID', 'S81'),
    ('OrderRef', 'S13'),
    ('UserID', 'S16'),
    ('OrderPriceType', 'S'),
    ('Direction', 'S'),
    ('CombOffsetFlag', 'S5'),
    ('CombHedgeFlag', 'S5'),
    ('LimitPrice', 'f8'),
    ('VolumeTotalOriginal', 'i4'),
    ('TimeCondition', 'S'),
    ('GTDDate', 'S9'),
    ('VolumeCondition', 'S'),
    ('MinVolume', 'i4'),
    ('ContingentCondition', 'S'),
    ('StopPrice', 'f8'),
    ('ForceCloseReason', 'S'),
    ('IsAutoSuspend', 'i4'),
    ('BusinessUnit', 'S21'),
    ('RequestID', 'i4'),
    ('OrderLocalID', 'S13'),
    ('ExchangeID', 'S9'),
    ('ParticipantID', 'S11'),
    ('ClientID', 'S11'),
    ('ExchangeInstID', 'S31'),
    ('TraderID', 'S21'),
    ('InstallID', 'i4'),
    ('OrderSubmitStatus', 'S'),
    ('NotifySequence', 'i4'),
    ('TradingDay', 'S9'),
    ('SettlementID', 'i4'),
    ('OrderSysID', 'S21'),
    ('OrderSource', 'S'),
    ('OrderStatus', 'S'),
    ('OrderType', 'S'),
    ('VolumeTraded', 'i4'),
    ('VolumeTotal', 'i4'),
    ('InsertDate', 'S9'),
    ('InsertTime', 'S9'),
    ('ActiveTime', 'S9'),
    ('SuspendTime', 'S9'),
    ('UpdateTime', 'S9'),
    ('CancelTime', 'S9'),
    ('ActiveTraderID', 'S21'),
    ('ClearingPartID', 'S11'),
    ('SequenceNo', 'i4'),
    ('FrontID', 'i4'),
    ('SessionID', 'i4'),
    ('UserProductInfo', 'S11'),
    ('StatusMsg', 'S81'),
    ('UserForceClose', 'i4'),
    ('ActiveUserID', 'S16'),
    ('BrokerOrderSeq', 'i4'),
    ('RelativeOrderSysID', 'S21'),
    ('ZCETotalTradedVolume', 'i4'),
    ('IsSwapOrder', 'i4'),
], align=True)

my_sgit_trade = np.dtype([
    ('BrokerID', 'S11'),
    ('InvestorID', 'S13'),
    ('InstrumentID', 'S81'),
    ('OrderRef', 'S13'),
    ('UserID', 'S16'),
    ('ExchangeID', 'S9'),
    ('TradeID', 'S81'),
    ('Direction', 'S'),
    ('OrderSysID', 'S'),
    ('ParticipantID', 'S11'),
    ('ClientID', 'S11'),
    ('TradingRole', 'S'),
    ('ExchangeInstID', 'S31'),
    ('OffsetFlag', 'S'),
    ('HedgeFlag', 'S'),
    ('Price', 'f8'),
    ('Volume', 'i4'),
    ('TradeDate', 'S9'),
    ('TradeTime', 'S9'),
    ('TradeType', 'S'),
    ('PriceSource', 'S'),
    ('TraderID', 'S21'),
    ('OrderLocalID', 'S13'),
    ('ClearingPartID', 'S11'),
    ('BusinessUnit', 'S21'),
    ('SequenceNo', 'i4'),
    ('TradingDay', 'S9'),
    ('SettlementID', 'i4'),
    ('BrokerOrderSeq', 'i4'),
    ('TradeSource', 'S'),
], align=True)

my_sgit_position = np.dtype([
    ('InstrumentID', 'S81'),
    ('BrokerID', 'S11'),
    ('InvestorID', 'S13'),
    ('PosiDirection', 'S'),
    ('HedgeFlag', 'S'),
    ('PositionDate', 'S'),
    ('YdPosition', 'i4'),
    ('Position', 'i4'),
    ('LongFrozen', 'i4'),
    ('ShortFrozen', 'i4'),
    ('LongFrozenAmount', 'f8'),
    ('ShortFrozenAmount', 'f8'),
    ('OpenVolume', 'i4'),
    ('CloseVolume', 'i4'),
    ('OpenAmount', 'f8'),
    ('CloseAmount', 'f8'),
    ('PositionCost', 'f8'),
    ('PreMargin', 'f8'),
    ('UseMargin', 'f8'),
    ('FrozenMargin', 'f8'),
    ('FrozenCash', 'f8'),
    ('FrozenCommission', 'f8'),
    ('CashIn', 'f8'),
    ('Commission', 'f8'),
    ('CloseProfit', 'f8'),
    ('PositionProfit', 'f8'),
    ('PreSettlementPrice', 'f8'),
    ('SettlementPrice', 'f8'),
    ('TradingDay', 'S9'),
    ('SettlementID', 'i4'),
    ('OpenCost', 'f8'),
    ('ExchangeMargin', 'f8'),
    ('CombPosition', 'i4'),
    ('CombLongFrozen', 'i4'),
    ('CombShortFrozen', 'i4'),
    ('CloseProfitByDate', 'f8'),
    ('CloseProfitByTrade', 'f8'),
    ('TodayPosition', 'i4'),
    ('MarginRateByMoney', 'f8'),
    ('MarginRateByVolume', 'f8'),
    ('StrikeFrozen', 'i4'),
    ('StrikeFrozenAmount', 'f8'),
    ('AbandonFrozen', 'i4'),
], align=True)

my_sgit_balance = np.dtype([
    ('BrokerID', 'S11'),
    ('AccountID', 'S13'),
    ('PreMortgage', 'f8'),
    ('PreCredit', 'f8'),
    ('PreDeposit', 'f8'),
    ('PreBalance', 'f8'),
    ('PreMargin', 'f8'),
    ('InterestBase', 'f8'),
    ('Interest', 'f8'),
    ('Deposit', 'f8'),
    ('Withdraw', 'f8'),
    ('FrozenMargin', 'f8'),
    ('FrozenCash', 'f8'),
    ('FrozenCommission', 'f8'),
    ('CurrMargin', 'f8'),
    ('CashIn', 'f8'),
    ('Commission', 'f8'),
    ('CloseProfit', 'f8'),
    ('PositionProfit', 'f8'),
    ('Balance', 'f8'),
    ('Available', 'f8'),
    ('WithdrawQuota', 'f8'),
    ('Reserve', 'f8'),
    ('TradingDay', 'S9'),
    ('SettlementID', 'i4'),
    ('Credit', 'f8'),
    ('Mortgage', 'f8'),
    ('ExchangeMargin', 'f8'),
    ('DeliveryMargin', 'f8'),
    ('ExchangeDeliveryMargin', 'f8'),
    ('ReserveBalance', 'f8'),
    ('CurrencyID', 'S4'),
    ('PreFundMortgageIn', 'f8'),
    ('PreFundMortgageOut', 'f8'),
    ('FundMortgageIn', 'f8'),
    ('FundMortgageOut', 'f8'),
    ('FundMortgageAvailable', 'f8'),
    ('MortgageableFund', 'f8'),
    ('SpecProductMargin', 'f8'),
    ('SpecProductFrozenMargin', 'f8'),
    ('SpecProductCommission', 'f8'),
    ('SpecProductFrozenCommission', 'f8'),
    ('SpecProductPositionProfit', 'f8'),
    ('SpecProductCloseProfit', 'f8'),
    ('SpecProductPositionProfitByAlg', 'f8'),
    ('SpecProductExchangeMargin', 'f8'),
], align=True)


class FS(AbstractSingleTunnel):
    m = [my_sgit_balance, my_sgit_position, my_sgit_order, my_sgit_trade]

    def __init__(self, data_frame):
        super(FS, self).__init__(data_frame)

    def parse_buffer(self):
        res = []
        try:
            data_type = self.m[self.data_type]
            keys = self.m[self.data_type].names
            np_data = np.frombuffer(self.buf, dtype=data_type)
            for x in np_data:
                res.append(dict(zip(keys, x)))
            self.buf_json = res
            self.set_position()
        except Exception as err:
            logger.error("the error time:%s, %s", self.__class__.__name__, err, exc_info=True)
        return res

    def set_position(self):
        print("************FS(SGE)***********")
        if self.data_type == 1:
            for x in self.buf_json:
                position_dic = {}
                key = x['InvestorID'].decode()
                if key:
                    position_dic[key] = {
                        'long': int(x['Position']),
                        'short': 0,
                        'price': 0,
                    }
                    self.position_list.append(position_dic)


if __name__ == "__main__":
    from equity_trader import config

    r = redis.Redis(host=config.redis_ip, port=config.redis_port, db=0)

    def get_data(rh):
        _pipe = rh.pipeline()
        _pipe.lrange(config.check_queue, 0, -1)
        return _pipe.execute()[0]

    data = get_data(r)
    for i in range(len(data)):
        # print(data[i])
        if i == 1:
            t = FS(data[i])
            t.print_p()
            print(t.parse_buffer())

# -*- coding: utf-8 -*-

"""
TongDaXin tunnel
"""

from equity_trader.config import logger
from equity_trader.parser.common import AbstractSingleTunnel, chi2eng
from equity_trader.tradelist import get_end_price


class TDX(AbstractSingleTunnel):
    def __init__(self, data):
        super(TDX, self).__init__(data)

    @staticmethod
    def _fill_list(length, list_in):
        source_length = len(list_in)
        if source_length > length:
            return list_in[0:source_length]
        if source_length == length:
            return list_in
        else:
            empty_str = [''] * (length - source_length)
            return list_in + empty_str

    def parse_buffer(self):
        res = []
        try:
            if self.buf:
                self.buf = self.buf.decode('gbk')
                # print(self.buf, len(self.buf))
                keys = self.buf.split('\n')[0].split('\t')
                keys = [chi2eng().get(x) for x in keys]
                values = [TDX._fill_list(len(keys), x.split('\t')) for x in self.buf.split('\n')[1:]]
                # print("the key", keys, "the value", values)
                for value in values:
                    # print(value, type(value))
                    value = ['' if all(v == 0 for v in item.encode('utf-8')) else item.strip() for item in value]
                    res.append(dict(zip(keys, value)))
                self.buf_json = res  # parse binary data to json
                self.set_position()
        except Exception as err:
            logger.error("the error time:%s, %s", self.__class__.__name__, err, exc_info=True)
        return res

    def set_position(self):
        if self.data_type == 1:
            for x in self.buf_json:
                position_dic = {}
                stock_code = x.get('stock_code', None)
                if ('security_quantity' not in x) or stock_code is None:
                    continue
                if stock_code in ['SHXGED', 'SZXGED']:
                    continue
                position_dic[stock_code] = {
                    'long': float(x['security_quantity']),
                    'short': 0,
                    'last_price': x['latest_price'],
                    'price': get_end_price(stock_code, "stock", self.get_date(), 0)
                }
                for ix in self.position_list:
                    if stock_code in ix.keys():
                        break
                else:
                    self.position_list.append(position_dic)
            print(self.position_list)

    def debug_account(self):
        print(self.buf_json)


if __name__ == '__main__':
    import numpy as np
    from equity_trader.parser.common import dtype_with_var_len

    def get_size_data(size):
        data_dtype = np.dtype(dtype_with_var_len("S%d" % size), align=False)
        data = np.zeros(shape=1, dtype=data_dtype)
        data['mode_id'] = 1
        data['data_type'] = 4
        data['api_type'] = 17
        data['counter'] = 0
        data['size'] = size
        return data


    def zx_tdx():
        data = get_size_data(169)
        data['buf'] = """资金帐号\t币种\t资金余额\t可用资金\t冻结资金\t模式\t参数\t总资产\t可取资金\t提示信息1\t检查风险标志\t保留信息
    \t0\t364879.32\t364463.54\t12.400\t0\t\t5124155.06\t364463.54\t0.000\t\t""".encode('gbk')
        return data.tobytes()


    def hb_tdx():
        data = get_size_data(161)
        data['buf'] = """币种\t资金余额\t可用资金\t总资产\t可取资金\t资金帐号\t保留信息
    0\t184792.35\t184792.35\t9916232.35\t184792.35\t60000008946\t\t""".encode('gbk')
        return data.tobytes()


    def ht_tdx():
        data = get_size_data(134)
        data['buf'] = """币种\t资金余额\t可用资金\t冻结资金\t总资产\t可取资金\t融资金额\t模式\t保留信息
    0\t480070.590\t2138079.180\t236986.550\t4222331.730\t480070.590\t0\t\t\t""".encode('gbk')
        return data.tobytes()


    all_data = {
        'zx': zx_tdx(),
        'hb': hb_tdx(),
        'ht': ht_tdx(),
    }

    for key, val in all_data.items():
        t = TDX(val)
        t.print_p()
        t.parse_buffer()
        t.debug_account()

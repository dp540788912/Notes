# -*- coding: utf-8 -*-

"""
ZhongXin tunnel
"""

import numpy as np
import redis
from equity_trader.config import logger
from equity_trader.parser.common import AbstractSingleTunnel
from equity_trader.tradelist import get_end_price

hs_qry_balance_type = np.dtype([
    ('money_type', 'S4'),
    ('current_balance', 'S22'),
    ('enable_balance', 'S22'),
    ('fetch_balance', 'S22'),
    ('frozen_balance', 'S22'),
    ('unfrozen_balance', 'S22')
], align=True)

hs_qry_position_type = np.dtype([
    ('fund_account', 'S19'),
    ('ffare_kind', 'S22'),
    ('bfare_kind', 'S22'),
    ('profit_flag', 'S2'),
    ('exchange_type', 'S5'),
    ('stock_account', 'S12'),
    ('stock_code', 'S7'),
    ('stock_type', 'S5'),
    ('stock_name', 'S9'),
    ('hold_amount', 'S22'),
    ('current_amount', 'S22'),
    ('cost_price', 'S22'),
    ('income_balance', 'S22'),
    ('hand_flag', 'S2'),
    ('frozen_amount', 'S22'),
    ('unfrozen_amount', 'S22'),
    ('enable_amount', 'S22'),
    ('real_buy_amount', 'S22'),
    ('real_sell_amount', 'S22'),
    ('uncome_buy_amount', 'S22'),
    ('uncome_sell_amount', 'S22'),
    ('entrust_sell_amount', 'S22'),
    ('asset_price', 'S22'),
    ('last_price', 'S22'),
    ('market_value', 'S22'),
    ('position_str', 'S33'),
    ('price_step', 'S22'),
    ('sum_buy_amount', 'S22'),
    ('sum_buy_balance', 'S22'),
    ('sum_sell_amount', 'S22'),
    ('sum_sell_balance', 'S22'),
    ('real_buy_balance', 'S22'),
    ('real_sell_balance', 'S22'),
    ('delist_flag', 'S2'),
    ('delist_date', 'S22')
], align=True)

hs_qry_order_type = np.dtype([
    ('init_date', 'S9'),
    ('fund_account', 'S19'),
    ('batch_no', 'S9'),
    ('entrust_no', 'S9'),
    ('exchange_type', 'S5'),
    ('stock_account', 'S11'),
    ('stock_code', 'S6'),
    ('entrust_bs', 'S2'),
    ('entrust_price', 'S13'),
    ('entrust_amount', 'S22'),
    ('business_amount', 'S22'),
    ('business_price', 'S13'),
    ('report_no', 'S9'),
    ('report_time', 'S9'),
    ('entrust_type', 'S2'),
    ('entrust_status', 'S2'),
    ('entrust_time', 'S9'),
    ('entrust_date', 'S9'),
    ('entrust_prop', 'S4'),
    ('stock_name', 'S9'),
    ('cancel_info', 'S21'),
    ('withdraw_amount', 'S22'),
    ('position_str', 'S33')
], align=True)

hs_qry_trade_type = np.dtype([
    ('serial_no', 'S9'),
    ('date', 'S9'),
    ('exchange_type', 'S5'),
    ('fund_account', 'S19'),
    ('stock_account', 'S12'),
    ('stock_code', 'S7'),
    ('entrust_bs', 'S2'),
    ('business_price', 'S13'),
    ('business_amount', 'S22'),
    ('business_time', 'S9'),
    ('real_type', 'S2'),
    ('real_status', 'S2'),
    ('business_times', 'S6'),
    ('entrust_no', 'S9'),
    ('business_balance', 'S22'),
    ('stock_name', 'S9'),
    ('report_no', 'S9'),
    ('position_str', 'S33'),
    ('entrust_prop', 'S4'),
    ('business_no', 'S9')
], align=True)


class ZX(AbstractSingleTunnel):
    m = [hs_qry_balance_type, hs_qry_position_type, hs_qry_order_type, hs_qry_trade_type]

    def __init__(self, data_frame):
        super(ZX, self).__init__(data_frame)

    def parse_buffer(self):
        res = []
        try:
            data_type = self.m[self.data_type]
            keys = self.m[self.data_type].names
            np_data = np.frombuffer(self.buf, dtype=data_type)
            for x in np_data:
                res.append((dict(zip(keys, x))))
            self.buf_json = res
            self.set_position()
        except Exception as err:
            logger.error("the error time:%s, %s", self.__class__.__name__, err, exc_info=True)
        return res

    def set_position(self):
        if self.data_type == 1:
            for x in self.buf_json:
                key = x['stock_code'].decode()
                position_dic = {}
                if x['hold_amount']:
                    pos = float(x['hold_amount'])
                else:
                    continue
                position_dic[key] = {
                    'long': pos,
                    'short': 0,
                    'price': get_end_price(key, "stock", self.get_date(), 0)
                }
                if position_dic[key] is None:
                    position_dic[key] = 0
                self.position_list.append(position_dic)


if __name__ == "__main__":
    from equity_trader import config
    r = redis.Redis(host=config.redis_ip, port=config.redis_port, db=0)

    def get_data(rh):
        _pipe = rh.pipeline()
        _pipe.lrange(config.check_queue, 0, -1)
        return _pipe.execute()[0]

    data = get_data(r)
    for i in range(len(data)):
        if i == 3:
            t = ZX(data[i])
            t.print_p()
            t.parse_buffer()
            print(t.position_list)

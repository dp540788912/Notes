# -*- coding: utf-8 -*-

import abc
import copy
import datetime
import time

import numpy as np
from equity_trader.config import logger


def dtype_with_var_len(vstr):
    return [
        ('mode_id', 'i4'),
        ('data_type', 'i4'),
        ('api_type', 'i4'),
        ('counter', 'S32'),
        ('size', 'i4'),
        ('buf', vstr),
    ]


def convert_np_type(dit):
    ret_dict = copy.deepcopy(dit)
    for k, v in dit.items():
        if type(v) == np.bytes_:
            try:
                ret_dict[k] = v.decode('gbk')
            except Exception as err:
                logger.error("item decode failed %s, %s, %s", k, v, err)
                ret_dict[k] = ""
        if type(v) == np.int32:
            ret_dict[k] = int(v)
    return ret_dict


class AbstractSingleTunnel(metaclass=abc.ABCMeta):
    head_dtype = np.dtype([
        ('mode_id', 'i4'),
        ('data_type', 'i4'),
        ('api_type', 'i4'),
        ('counter', 'S32'),
        ('size', 'i4')
    ], align=False)

    def __init__(self, data):
        header = np.frombuffer(data, dtype=AbstractSingleTunnel.head_dtype, count=1)
        self.mode_id = header[0][0]  # from redis
        self.data_type = header[0][1]  # 0:account, 1:position, 2:order, 3:trader
        self.api_type = header[0][2]  # from which Tunnel
        self.counter = header[0][3].decode('utf-8')  # account id (broker id)
        self.size = header[0][4]  # binary data size
        # print(self.mode_id, self.data_type, self.api_type, self.counter, self.size)
        self.print_p()
        logger.info("given size: %s, cal size: %s", self.size, len(data) - 48)
        new_head = np.dtype(dtype_with_var_len("V%d" % self.size), align=False)
        self.buf = np.frombuffer(data, dtype=new_head)[0][5]  # cut the data part to buf
        self.buf = bytes(self.buf)  # binary data
        self.position_list = []
        self.buf_json = None

    def print_p(self):
        logger.info("mode_id:%s,data_type:%s,api_type:%s,counter:%s,size:%s",
                    self.mode_id, self.data_type, self.api_type, self.counter, self.size)

    @staticmethod
    def check_time(start_time, end_time, weibo_time):
        """
            check the weibo_time is weather within (start_time, end_time) or not
            e.g.
            start_time = "2017-11-16 09:00:00"
            end_time = "2017-11-16 12:00:00"
            weibo_time = "2017-11-16 13:00:00"
            check_time(self,start_time, end_time, weibo_time)
            Return: False
        """
        start_time = time.strptime(start_time, '%Y-%m-%d %H:%M:%S')
        end_time = time.strptime(end_time, '%Y-%m-%d %H:%M:%S')
        weibo_time = time.strptime(str(weibo_time), '%Y-%m-%d %H:%M:%S')
        if int(time.mktime(start_time)) <= int(time.mktime(weibo_time)) and int(time.mktime(end_time)) >= int(
                time.mktime(weibo_time)):
            return True
        else:
            return False

    @staticmethod
    def get_yesterday():
        """
            returns: "%Y-%m-%d":e.g:"2017.10.01"
        """
        yesterday = datetime.date.today() - datetime.timedelta(days=1)
        return str(yesterday)

    @staticmethod
    def get_date():
        """
            if current time in 01:00:00 - 17:00:00 date return yesterday
            else: return today
            use for get end price(settle_price or close_price)
        """
        today = time.strftime("%Y-%m-%d", time.localtime())
        now = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        start_time = "%s 01:00:00" % today
        end_time = "%s 17:00:00" % today
        if AbstractSingleTunnel.check_time(start_time, end_time, now):
            return AbstractSingleTunnel.get_yesterday()
        else:
            return today

    @abc.abstractmethod
    def parse_buffer(self):
        """
        used to parse binary data to json,
        different Tunnel has different method
        """
        raise NotImplementedError


class SingleTunnel(AbstractSingleTunnel):
    def parse_buffer(self):
        pass


def chi2eng():
    """
    Some Chinese Dict to English
    """
    return {
        '币种': 'currency',
        '资金余额': 'account_balance',
        '可用资金': 'available_capital',
        '总资产': 'total_assets',
        '可取资金': 'capital_funds',
        '资金帐号': 'account_num',
        '保留信息': 'reserved_info',
        '委托价格': 'delgate_price',
        '撤单数量': 'cancel_vol',
        '冻结资金': 'frozen_fund',
        '证券代码': 'stock_code',
        '证券名称': 'stock_name',
        '证券数量': 'security_quantity',
        '可卖数量': 'available_quantity',
        '摊薄成本价': 'diluted_cost_price',
        '摊簿成本价': 'diluted_cost_price',
        '当前价': 'latest_price',
        '最新市值': 'lastest_capitalization',
        '摊薄浮动盈亏': 'diluted_floating',
        '摊簿浮动盈亏': 'diluted_floating',
        '实现盈亏': 'achieve_profit_loss',
        '参考盈亏比例(%)': 'profit_loss_ratio(%)',
        '冻结数量': 'frozen_quantity',
        '股东代码': 'shareholder_code',
        '交易所代码': 'exch_code',
        '交易所名称': 'exch',
        '委托时间': 'delegate_time',
        '买卖标志': 'trade_mark',
        '委托类别': 'delegate_class',
        '委托价值': 'delegate_value',
        '委托数量': 'delegate_quantity',
        '成交价格': 'price',
        '成交数量': 'volumne',
        '委托编号': 'delegate_code',
        '报价方式': 'quotation',
        '状态说明': 'status_info',
        '可撤单标志': 'cancel_mark',
        '成交时间': 'closing_time',
        '发生金额': 'actual_payment',
        '成交编号': 'closing_code',
        '撤单标志': 'cansel_mark',
        '资金账号': 'account',
        '模式': 'pattern',
        '参数': 'argument',
        '提示信息1': 'promote_information',
        '检查风险标志': 'check_risk_flag',
        '参考持股': 'reference_position',
        '可用股份': 'available_position',
        '成本价': 'cost_price',
        '当前成本': 'current_cost',
        '浮动盈亏': 'floating_pl',
        '盈亏比例(%)': 'floating_pl_ratio',
        '在途股份': 'stock_in_transmit',
        '股份余额': 'security_quantity',
        '帐号类别': 'account_type',
        '融资金额': 'financing_amount',
        '总库存（含超限库存）': 'total_repertory',
        '总市值（含超限库存）': 'total_market_value',
        '今买数量': 'today_buy_volume',
        '今卖数量': 'today_sell_volume',
    }

# -*- coding: utf-8 -*-

"""
This is not implement version
"""

import numpy as np
import redis
from equity_trader.config import logger
from equity_trader.parser.common import AbstractSingleTunnel

dd_balance = np.dtype([
    ('BZ', 'S4'),
    ('KYZJ', 'f8'),
    ('T2KYZJ', 'f8'),
    ('YJLX', 'f8'),
    ('ZHYE', 'f8'),
    ('ZHZT', 'i4'),
    ('KHH', 'S21'),
    ('ZJZH', 'S21'),
    ('DJJE', 'f8'),
    ('T2DJJE', 'f8'),
    ('JGDM', 'S5'),
    ('ZZC', 'f8'),
    ('ZXSZ', 'f8'),
    ('ZQSZ', 'f8'),
    ('FZJE', 'f8'),
], align=True)

dd_position = np.dtype([
    ('BZ', 'S4'),
    ('DRMCCJJE', 'f8'),
    ('DRMCCJSL', 'i8'),
    ('DRMCWTSL', 'i8'),
    ('DRMRCJJE', 'f8'),
    ('DRMRCJSL', 'i8'),
    ('DRMRWTSL', 'i8'),
    ('FLTSL', 'i8'),
    ('GDH', 'S11'),
    ('JYS', 'S3'),
    ('KCRQ', 'i8'),
    ('KMCSL', 'i8'),
    ('ZQDM', 'S7'),
    ('ZQLB', 'S3'),
    ('ZQMC', 'S9'),
    ('ZQSL', 'i8'),
    ('JCCL', 'i8'),
    ('WJSSL', 'i8'),
    ('BDRQ', 'i8'),
    ('KSGSL', 'i8'),
    ('KSHSL', 'i8'),
    ('DJSL', 'i8'),
    ('MCDXSL', 'i8'),
    ('MRDXSL', 'i8'),
    ('SGCJSL', 'i8'),
    ('SHCJSL', 'i8'),
    ('BROWINDEX', 'i8'),
    ('JYDW', 'i8'),
    ('MCSL', 'i8'),
    ('MRSL', 'i8'),
    ('PGSL', 'i8'),
    ('SGSL', 'i8'),
    ('TBFDYK', 'f8'),
    ('TBBBJ', 'f8'),
    ('TBCBJ', 'f8'),
    ('CCJJ', 'f8'),
    ('FDYK', 'f8'),
    ('HLJE', 'f8'),
    ('LJYK', 'f8'),
    ('MCJE', 'f8'),
    ('MRJE', 'f8'),
    ('MRJJ', 'f8'),
    ('PGJE', 'f8'),
    ('ZXSZ', 'f8'),
    ('BBJ', 'f8'),
    ('ZXJ', 'f8'),
    ('GPSZ', 'f8'),
    ('LXBJ', 'f8'),
    ('ZSP', 'f8'),
], align=True)

dd_qry_order = np.dtype([
    ('BZ', 'S4'),
    ('CJJE', 'f8'),
    ('CJJG', 'f8'),
    ('CJSJ', 'S9'),
    ('CJSL', 'i4'),
    ('GDH', 'S11'),
    ('JYS', 'S3'),
    ('QSZJ', 'f8'),
    ('WTFS', 'i4'),
    ('WTH', 'i4'),
    ('WTJG', 'f8'),
    ('WTLB', 'i4'),
    ('WTSL', 'i4'),
    ('ZQDM', 'S7'),
    ('ZQLB', 'S3'),
    ('ZQMC', 'S9'),
    ('WTSJ', 'S9'),
    ('SBSJ', 'S9'),
    ('SBJG', 'i4'),
    ('CXBZ', 'S2'),
    ('CXWTH', 'i4'),
    ('DJZJ', 'f8'),
    ('ZJZH', 'S21'),
    ('JGSM', 'S67'),
    ('CDSL', 'i4'),
    ('SBWTH', 'S11'),
    ('DDLX', 'i4'),
    ('WTPCH', 'i4'),
    ('ZJDJLSH', 'i4'),
    ('ZQDJLSH', 'i4'),
    ('SBRQ', 'i4'),
    ('SBJLH', 'i4'),
    ('WTRQ', 'i4'),
    ('BROWINDEX', 'i8'),
    ('ADDR_IP', 'S17'),
    ('ADDR_MAC', 'S13'),
], align=True)

dd_qry_trade = np.dtype([
    ('BZ', 'S4'),
    ('CJBH', 'S17'),
    ('CJJE', 'f8'),
    ('CJJG', 'f8'),
    ('CJSL', 'i4'),
    ('GDH', 'S11'),
    ('JYS', 'S3'),
    ('QSJE', 'f8'),
    ('WTH', 'i4'),
    ('WTLB', 'i4'),
    ('ZJZH', 'S21'),
    ('ZQDM', 'S7'),
    ('ZQLB', 'S3'),
    ('ZQMC', 'S9'),
    ('CXBZ', 'S2'),
    ('S1', 'f8'),
    ('HBXH', 'i4'),
    ('LXBJ', 'f8'),
    ('SBWTH', 'S11'),
    ('BROWINDEX', 'i8'),
    ('WTPCH', 'i4'),
    ('LX', 'f8'),
    ('CJSJ', 'S9'),
    ('CLSJ', 'S9'),
], align=True)


class DD(AbstractSingleTunnel):
    m = [dd_balance, dd_position, dd_qry_order, dd_qry_trade]

    def __init__(self, data_frame):
        super(DD, self).__init__(data_frame)

    def parse_buffer(self):
        res = []
        try:
            data_type = self.m[self.data_type]
            keys = self.m[self.data_type].names
            np_data = np.frombuffer(self.buf, dtype=data_type)
            for x in np_data:
                res.append(dict(zip(keys, x)))
            self.buf_json = res
            # self.set_position()
        except Exception as err:
            logger.error("the error time:%s, %s", self.__class__.__name__, err, exc_info=True)
        return res


if __name__ == "__main__":
    from equity_trader import config

    r = redis.Redis(host=config.redis_ip, port=config.redis_port, db=0)

    def get_data(rh):
        _pipe = rh.pipeline()
        _pipe.lrange(config.check_queue, 0, -1)
        return _pipe.execute()[0]

    data = get_data(r)
    for i in range(len(data)):
        # print(data[i])
        if i == 1:
            t = DD(data[i])
            t.print_p()
            print(t.parse_buffer())

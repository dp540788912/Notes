# -*- coding: utf-8 -*-

"""
General tunnel message parser
"""

import numpy as np
from equity_trader.config import logger
from equity_trader.parser.common import AbstractSingleTunnel


gt_cash_dtype = np.dtype([
    ('margin', 'f8'),
    ('currency', 'S8'),
])

gt_pos_dtype = np.dtype([
    ('symbol', 'S32'),
    ('direction', 'S4'),
    ('volume', 'i4'),
    ('price', 'f8'),
])


class GT(AbstractSingleTunnel):
    m = [gt_cash_dtype, gt_pos_dtype]

    def __init__(self, *args, **kwargs):
        super(GT, self).__init__(*args, **kwargs)

    def parse_buffer(self):
        res = []
        try:
            data_type = self.m[self.data_type]
            # print(data_type.itemsize, len(self.buf))
            keys = self.m[self.data_type].names
            parsed_data = np.frombuffer(self.buf, dtype=data_type)
            for x in parsed_data:
                res.append(dict(zip(keys, x)))
            self.buf_json = res
            # print(self.buf_json)
            self.set_position()
        except Exception as err:
            logger.error("the error time:%s, %s", self.__class__.__name__, err, exc_info=True)
        return res

    def set_position(self):
        # received data is position
        if self.data_type == 1:
            position_dic = {}
            for x in self.buf_json:
                symbol = x['symbol'].decode()
                if not symbol:
                    continue
                if symbol.startswith("SP ") or symbol.startswith("SPC"):
                    continue
                position_dic.setdefault(symbol, {
                    'long': 0,
                    'short': 0,
                    'price': 0,
                })
                direction = x['direction']
                volume = int(x['volume'])
                price = float(x['price'])
                if volume < 0 or price < 0:
                    logger.error("the position data error %s", x)
                    continue
                # long position
                if direction == b'0':
                    position_dic[symbol].update({
                        'long': volume,
                        'price': price,
                    })
                elif direction == b'1':
                    position_dic[symbol].update({
                        'short': volume,
                        'price': price
                    })
                logger.debug("Received position symbol: %s direction: %s, volume: %s", symbol, direction, volume)
            # get the first symbol data in the queue
            for symbol, value in position_dic.items():
                # if the symbol not exist in position list then add it
                for x in self.position_list:
                    if symbol in x.keys():
                        break
                else:
                    self.position_list.append({symbol: value})
            # print(self.position_list)


if __name__ == '__main__':
    data = b't\x03\x00\x00\x00\x00\x00\x00d\x00\x00\x00620061060839\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00' \
           b'\x00\x00\x00\x00\x00\x00\x00\x00\x10\x00\x00\x00\x1f\x85\xeb\x86\xc2\xc0\xa7ARMB\x00\x00\x00\x00\x00'
    gt = GT(data)
    gt.parse_buffer()
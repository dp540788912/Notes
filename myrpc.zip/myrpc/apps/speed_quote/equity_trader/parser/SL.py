# -*- coding: utf-8 -*-

import config
import numpy as np
import redis
from equity_trader.parser.common import AbstractSingleTunnel, convert_np_type

my_rem_position = np.dtype([
    ('m_actId', 'S17'),
    ('m_Symbol', 'S9'),
    ('m_PosiDirection', 'i4'),
    ('m_InitOvnQty', 'i4'),
    ('m_OvnQty', 'i4'),
    ('m_FrozenOvnQty', 'i4'),
    ('m_TodayQty', 'i4'),
    ('m_FrozenTodayQty', 'i4'),
    ('m_OvnMargin', 'f8'),
    ('m_TodayMargin', 'f8'),
    ('m_HedgeFlag', 'S1'),
], align=False)

my_rem_balance = np.dtype([
    ('m_account', 'S17'),
    ('m_InitialBp', 'f8'),
    ('m_AvailableBp', 'f8'),
    ('m_Margin', 'f8'),
    ('m_FrozenMargin', 'f8'),
    ('m_CommissionFee', 'f8'),
    ('m_FrozenCommission', 'f8'),
    ('m_OvnInitMargin', 'f8'),
    ('m_TotalLiquidPL', 'f8'),
    ('m_TotalMarketPL', 'f8'),
], align=False)

my_rem_order = np.dtype([
    ('m_Userid', 'i4'),
    ('m_Timestamp', 'i8'),
    ('m_ClientOrderToken', 'i4'),
    ('m_SideType', 'S1'),
    ('m_Quantity', 'i4'),
    ('m_InstrumentType', 'S1'),
    ('m_symbol', 'S9'),
    ('m_Price', 'f8'),
    ('m_account', 'S17'),
    ('m_ExchengeID', 'S1'),
    ('m_ForceCloseReason', 'S1'),
    ('m_MarketOrderToken', 'i8'),
    ('m_OrderStatus', 'S1'),
    ('m_CloseTime', 'i8'),
    ('m_FilledQty', 'i4'),
    ('m_Tif', 'i4'),
    ('m_MinQty', 'i4'),
    ('m_CustomField', 'i8'),
    ('m_MarketOrderId', 'S25'),
    ('m_HedgeFlag', 'S1'),
], align=True)

my_rem_trade = np.dtype([
    ('m_Userid', 'i4'),
    ('m_Timestamp', 'i8'),
    ('m_ClientOrderToken', 'i4'),
    ('m_MarketOrderToken', 'i8'),
    ('m_ExecutedQuantity', 'i4'),
    ('m_ExecutionPrice', 'f8'),
    ('m_ExecutionID', 'i8'),
    ('m_MarketExecID', 'S25'),
], align=True)


class SL(AbstractSingleTunnel):
    m = [my_rem_balance, my_rem_position, my_rem_order, my_rem_trade]

    def __init__(self, data_frame):
        super(SL, self).__init__(data_frame)

    def parse_buffer(self):
        dtype_ = self.m[self.data_type]
        np_data = np.frombuffer(self.buf, dtype=dtype_)
        data_dict = dict(zip(self.m[self.data_type].names, np_data[0]))
        data_dict = convert_np_type(data_dict)
        self.buf_json = data_dict
        self.set_position()
        return data_dict

    def set_position(self):
        if self.data_type == 1:
            x = self.buf_json
            if x['m_Symbol']:
                position_dic = {}
                key = x['m_Symbol']
                position_dic[key] = {
                    'long': 0,
                    'short': 0,
                    'price': 0,
                }
                if x['m_PosiDirection'] == 1:
                    position_dic[key]['long'] = int(x['m_OvnQty'])
                if x['m_PosiDirection'] == 5:
                    position_dic[key]['short'] = int(x['m_OvnQty'])

                self.position_list.append(position_dic)


if __name__ == "__main__":
    from equity_trader import config

    r = redis.Redis(host=config.redis_ip, port=config.redis_port, db=0)

    def get_data(rh):
        _pipe = rh.pipeline()
        _pipe.lrange(config.check_queue, 0, -1)
        return _pipe.execute()[0]

    data = get_data(r)
    for i in range(len(data)):
        # print(data[i])
        if i == 6:
            print(data[i])
            t = SL(data[i])
            t.print_p()
            print(t.parse_buffer())
            print(t.position_list)

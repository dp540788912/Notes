# -*- coding: utf-8 -*-

import json
import pickle
import signal
import time
from functools import partial

import redis
import tornado.httpserver
import tornado.ioloop
import tornado.web
from equity_trader import config
from equity_trader.config import logger
from equity_trader.entrance import Tunnels

account_position = {}
account_cash = {}
backup_account_position = {}
backup_account_cash = {}
stop_signal = False


class JsonHandler(tornado.web.RequestHandler):
    """Request handler where requests and responses speak JSON."""

    def data_received(self, chunk):
        pass

    def prepare(self):
        # Incorporate request JSON into arguments dictionary.
        if self.request.body:
            try:
                body = self.request.body.decode('utf-8') if isinstance(self.request.body, bytes) else self.request.body
                json_data = json.loads(body)
                self.request.arguments.update(json_data)
            except ValueError:
                message = 'Unable to parse JSON.'
                logger.debug("%s %s" % (message, self.request.body))


class AccountPositionHandler(tornado.web.RequestHandler):
    def data_received(self, chunk):
        pass

    def get(self, *args, **kwargs):
        account = self.get_argument('account', '')
        if account == '':
            query_data = account_position
        else:
            # find in latest, backup and default data
            for data in [account_position, backup_account_position]:
                if account in data:
                    query_data = {account: data[account]}
                    break
            else:
                query_data = {account: {'data': None, 'timestamp': '1970-01-01 00:00:00'}}
        ret_data = {
            'code': 0,
            'data': query_data
        }
        self.write(json.dumps(ret_data))


class AccountCashHandler(tornado.web.RequestHandler):
    def data_received(self, chunk):
        pass

    def get(self):
        account = self.get_argument('account', '')
        if account == '':
            query_data = account_cash
        else:
            # find in latest, backup and default data
            for data in [account_cash, backup_account_cash]:
                if account in data:
                    query_data = {account: data[account]}
                    break
            else:
                query_data = {account: {'data': None, 'timestamp': '1970-01-01 00:00:00'}}
        ret_data = {
            'code': 0,
            'data': query_data
        }
        self.write(json.dumps(ret_data))


class AccountOperationHandler(JsonHandler, tornado.web.RequestHandler):

    def data_received(self, chunk):
        pass

    def post(self):
        account = self.request.arguments.get('account', '')
        data_type = self.request.arguments.get('data_type', 'all')
        operation = self.request.arguments.get('operation', '')

        if data_type == 'all':
            data_type = ['cash', 'position']
        elif isinstance(data_type, str):
            data_type = [data_type]
        logger.debug("account: %s, data_type: %s, operation: %s execute", account, data_type, operation)
        if account == '' or operation == '' or operation not in ['del']:
            self.write({
                'code': -1,
                'error': "account or operation not valid"
            })
        else:
            global account_position
            global account_cash

            if isinstance(account, str):
                account_l = [account]
            elif isinstance(account, list):
                account_l = account
            else:
                account_l = []
            for account in account_l:
                for dt in data_type:
                    if dt == 'cash' and account in account_cash:
                        backup_account_cash[account] = account_cash[account]
                        del account_cash[account]
                    elif dt == 'position' and account in account_position:
                        backup_account_position[account] = account_position[account]
                        del account_position[account]
            self.write({
                'code': 0,
                'data': 'Operation success'
            })


def pull_redis(rh):
    global account_position
    global account_cash

    _pipe = rh.pipeline()
    _pipe.lrange(config.check_queue, 0, -1)
    # remove the queue after retrieving all necessary data
    _pipe.delete(config.check_queue)
    data = _pipe.execute()[0]
    if data is None or len(data) == 0:
        return

    logger.debug("load from redis one time")
    tunnel = Tunnels()
    for i in range(len(data)):
        try:
            tunnel.add(data[i])
        except Exception as err:
            logger.debug("the data is %s", data[i])
            logger.error("tunnel parser error %s", err, exc_info=True)
    tunnel.tidy()
    tmp_positions = tunnel.Positions
    tmp_accounts = tunnel.Accounts
    if tmp_positions:
        now_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        for k, v in tmp_positions.items():
            account_position[k] = {'data': v, 'timestamp': now_time}
    if tmp_accounts:
        now_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        for k, v in tmp_accounts.items():
            account_cash[k] = {'data': v, 'timestamp': now_time}


def on_exit(rh):
    """
    write data into redis while process exit
    :return:
    """
    all_global = globals()

    write_data = pickle.dumps({
        'cash': all_global['account_cash'],
        'backup_cash': all_global['backup_account_cash'],
        'position': all_global['account_position'],
        'backup_position': all_global['backup_account_position']
    })
    try:
        rh.set(config.backup_queue, write_data)
    except Exception as err:
        logger.error("backup on exit failed %s", err)
    else:
        logger.debug("write backup success")


def on_init(rh):
    """
    load the account and position from redis
    :return:
    """
    all_global = globals()
    try:
        read_data = rh.get(config.backup_queue)
        if read_data:
            parsed_data = pickle.loads(read_data)
            all_global['account_cash'] = parsed_data['cash']
            all_global['backup_account_cash'] = parsed_data['backup_cash']
            all_global['account_position'] = parsed_data['position']
            all_global['backup_account_position'] = parsed_data['backup_position']
    except Exception as err:
        logger.error("load backup on init failed %s", err)
    else:
        logger.debug("load on_init success")


def bottom_signal_handler(sig, _):
    global stop_signal
    logger.debug("Caught Signal: %s, prepare to stop", sig)
    stop_signal = True


def check_stop(http_server, rh):
    global stop_signal
    if not stop_signal:
        return
    logger.info("Prepare to Stop the Running Server")
    http_server.stop()
    instance = tornado.ioloop.IOLoop.instance()
    deadline = time.time() + config.EXIT_WAIT_SECS
    # write back to redis
    on_exit(rh)
    # mark as exited
    stop_signal = False

    def terminate():
        now = time.time()
        if now < deadline:
            instance.add_timeout(now + 1, terminate)
        else:
            instance.stop()
            logger.info('Shutdown Tornado IOLoop')
            print("Exit Success")

    terminate()


def start():
    handlers = [
        ('/api/v1/speedquote/equitytrader', AccountPositionHandler),
        ('/api/v1/speedquote/equityaccount', AccountCashHandler),
        ('/api/v1/speedquote/accountclear', AccountOperationHandler),
    ]
    app = tornado.web.Application(handlers=handlers, debug=config.DEBUG)
    rh = redis.Redis(host=config.redis_ip, port=config.redis_port, db=0)
    on_init(rh)

    http_server = tornado.httpserver.HTTPServer(app)
    http_server.listen(config.port)

    signal.signal(signal.SIGINT, bottom_signal_handler)
    signal.signal(signal.SIGTERM, bottom_signal_handler)

    # try to fetch data from redis every 5 seconds
    tornado.ioloop.PeriodicCallback(partial(pull_redis, rh), 5000).start()
    tornado.ioloop.PeriodicCallback(partial(check_stop, http_server, rh), 500).start()
    tornado.ioloop.IOLoop.instance().start()


if __name__ == "__main__":
    start()

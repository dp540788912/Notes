#include "ctp_quote_interface.h"
#include "ctp_quote.h"
#include "easylogging++.h"

INITIALIZE_EASYLOGGINGPP

#define  MAX_EXCHG_QUOTE_CNT	(4)

static unsigned int s_tot_quote_connect_cnt = 0;
static ctp_quote_info_t  s_ret_realtime_quote;
my_ctp_quote_handler *s_quote_ctp[MAX_EXCHG_QUOTE_CNT];

int
ctp_quote_init(all_exchg_ctp_quote_cfg_t *exchg_quote_cfg_info)
{
	unsigned int idx = 0;
	s_tot_quote_connect_cnt = exchg_quote_cfg_info->exchg_quote_cnt;
	s_ret_realtime_quote.tot_cnt = 0;
	s_ret_realtime_quote.p_addr = (ctp_level1_quote_t *)calloc(QUOTE_ITEM_MAX * s_tot_quote_connect_cnt, sizeof(ctp_level1_quote_t));
	if (s_ret_realtime_quote.p_addr == NULL)
	{
		printf("[ERROR]: %s , %d \n", __FUNCTION__, __LINE__);
		return -1;
	}
	for (idx = 0; idx < exchg_quote_cfg_info->exchg_quote_cnt; idx++) {
		s_quote_ctp[idx] = new my_ctp_quote_handler((user_login_info_t *)(&exchg_quote_cfg_info->ctp_cfg_info_ar[idx]));
	}
    el::Configurations defaultConf;
    defaultConf.setToDefault();
    // Values are always std::string
    defaultConf.set(el::Level::Info, 
                    el::ConfigurationType::Format, "%datetime %level %msg");
    // default logger uses default configurations
    el::Loggers::reconfigureLogger("default", defaultConf);
	return 0;
}

static void
show_recv_quote_data()
{
	unsigned int idx = 0;
	printf("[QUOTE]: num %u\n", s_ret_realtime_quote.tot_cnt);
    return; /* Return early.*/

	ctp_level1_quote_t *info;
	for (idx = 0; idx < s_ret_realtime_quote.tot_cnt; idx++) {
		info = &s_ret_realtime_quote.p_addr[idx];
		printf("[QUOTE]: %s %f %d %f %d \n", info->symbol, info->ap1, info->av1, info->bp1, info->bv1);
	}

}


ctp_quote_info_t* get_ctp_quote_info()
{
	unsigned int idx = 0;
	s_ret_realtime_quote.tot_cnt = 0;
	for (idx = 0; idx < s_tot_quote_connect_cnt; idx++) {
		s_ret_realtime_quote.tot_cnt += s_quote_ctp[idx]->get_realtime_quote_data(
                (char *)(&s_ret_realtime_quote.p_addr[s_ret_realtime_quote.tot_cnt]));
	}
	show_recv_quote_data();
	return &s_ret_realtime_quote;
}

int ctp_quote_destory()
{
	unsigned int idx;
	for (idx = 0; idx < s_tot_quote_connect_cnt; idx++) {
		//s_quote_ctp[idx]->~my_ctp_quote_handler();
		delete s_quote_ctp[idx]; 
	}

	if (s_ret_realtime_quote.p_addr) {
		free(s_ret_realtime_quote.p_addr);
		s_ret_realtime_quote.p_addr = NULL;
	}
	
	printf("[FINISH]! \n");
}

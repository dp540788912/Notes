#include <ctime>
#include "ctp_quote.h"
#include "easylogging++.h"


///当客户端与交易后台建立起通信连接时（还未登录前），该方法被调用。
void 
my_ctp_quote_handler::OnFrontConnected()
{
	int ret = 0;
	char  extract_passwd[256];
	memset(extract_passwd, 0, sizeof(extract_passwd));
	CThostFtdcReqUserLoginField login_req;
	memset(&login_req, 0, sizeof(CThostFtdcReqUserLoginField));
	memcpy(login_req.BrokerID, login_info.BrokerID, sizeof(login_req.BrokerID));
	memcpy(login_req.UserID, login_info.UserID, sizeof(login_req.UserID));
	my_decrypt(login_info.Passwd, extract_passwd, 256);
	memcpy(login_req.Password, extract_passwd, sizeof(login_req.Password));

	ret = p_api->ReqUserLogin(&login_req, request_id++);
	if (ret) {
		LOG(ERROR) << "[SEND_LOGIN_ERROR] " <<  __FUNCTION__ << ":" << __LINE__ << "error_id " << ret;
	}
}


int 
my_ctp_quote_handler::malloc_memcpy_for_quote()
{
	memset(&inner_quote_ar, 0, sizeof(inner_quote_ar));
	inner_quote_ar.max_cnt = QUOTE_ITEM_MAX;
	inner_quote_ar.cur_idx = 0;
	inner_quote_ar.last_idx = 0;
	inner_quote_ar.p_addr = (level1_quote_t *)calloc(inner_quote_ar.max_cnt, sizeof(level1_quote_t));
	if (inner_quote_ar.p_addr == NULL)
	{
		LOG(ERROR) << __FUNCTION__ << ":" << __LINE__;
		return -1;
	}
	return 0;
}

int
my_ctp_quote_handler::free_malloc_memory()
{
	if (inner_quote_ar.p_addr) {
		free(inner_quote_ar.p_addr);
		inner_quote_ar.p_addr = NULL;
	}
	
}

void 
my_ctp_quote_handler::OnRspUserLogin(CThostFtdcRspUserLoginField *pRspUserLogin, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{

	if (pRspInfo->ErrorID == 0) {
		login_status = 1;
		printf("[LOGIN_INFO]: LOGIN OK ! %s, %d , subcribe_cnt:%d, user_id:%s\n", 
                                __func__,
                                __LINE__,
                                login_info.subcribe_cnt,
                                login_info.UserID);

		for (int idx = 0; idx < login_info.subcribe_cnt; idx++) {
			printf("[DEBUG_INFO]: Symbol:%s , %d\n",login_info.subcribe[idx], idx);
		}
		p_api->SubscribeMarketData(login_info.subcribe, login_info.subcribe_cnt);
	} else {
		LOG(ERROR) << "[LOGIN FAILED]" << __func__ << ":" << __LINE__ << "error_id " << pRspInfo->ErrorID;
	}
}

void 
my_ctp_quote_handler::OnRspError(CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	LOG(ERROR) << "[RSP ERROR]: " <<  __func__ << ":" << __LINE__ << "nRequestID: " << nRequestID;
}

void 
my_ctp_quote_handler::OnRspUserLogout(CThostFtdcUserLogoutField *pUserLogout, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	LOG(INFO) << "[LOGOUT_INFO]:" << __func__ << ":" << __LINE__;
}

void 
my_ctp_quote_handler::OnFrontDisconnected(int nReason)
{
	LOG(INFO) << "[FRONT DISCONNECT ERROR]:" <<  __FUNCTION__ << ":" << __LINE__ << "reason: " << nReason;
}

void 
my_ctp_quote_handler::OnRspSubMarketData(CThostFtdcSpecificInstrumentField *pSpecificInstrument,
        CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	LOG(INFO) << "[OnRspSubMarketData]:" << __func__ << ":" << __LINE__;
}

unsigned int 
timestamp_convert(char *src, int millisec)
{
	unsigned int t;
	/* src like: HH:MM:SS.mmm 10:23:10 */
	t = src[0] - 48;
	t = t * 10;
	t = t + (src[1] - 48);
	t = t * 10;
	t = t + (src[3] - 48);
	t = t * 10;
	t = t + (src[4] - 48);
	t = t * 10;
	t = t + (src[6] - 48);
	t = t * 10;
	t = t + (src[7] - 48);
	t = t*1000 + millisec;
	return t;
}

/**
 * write the tick data into log file
 */
static void
record_error_market_tick(level1_quote_t *quote)
{
    LOG(ERROR) << "|symbol: " << quote->symbol \
               << "|open_price: " << quote->open_price \
               << "|pre_settlement_price: " << quote->pre_settlement_price \
               << "|pre_close_price: " << quote->pre_close_price \
               << "|exchange_time: " << quote->exchg_timestamp \
               << "|ap1: " << quote->ap1 \
               << "|bp1: " << quote->bp1 \
               << "|av1: " << quote->av1 \
               << "|bv1: " << quote->bv1;
}

/**
 * check tick valid or not
 * 1. if localtime is during trading date and trading time
 * 2. check the timestamp in tick valid or not
 */
static bool
is_quote_valid(level1_quote_t *quote)
{
	time_t rawtime;
	struct tm * timeinfo;
	time(&rawtime);
	timeinfo = localtime(&rawtime);
	int wday = timeinfo->tm_wday;
	int hour = timeinfo->tm_hour;
	/* all sunday */
	if (wday == 0) {
		return false;
	}
	/* monday morning */
	if (wday == 1 && hour < 8) {
		return false;
	}
	/* saturday after middlenight */
	if (wday == 6 && hour > 3) {
		return false;
	}
	/* time during 3:40 ~ 8:40 */
	if (quote->exchg_timestamp < 80000000 && quote->exchg_timestamp > 330000000) {
		return false;
	}
	/* time during 11:40 ~ 1:20 */
	if (quote->exchg_timestamp > 114000000 && quote->exchg_timestamp < 132000000) {
		return false;
	}
	/* time during 16:00 ~ 20:30 */
	if (quote->exchg_timestamp > 160000000 && quote->exchg_timestamp < 203000000) {
		return false;
	}
	return true;
}

void 
my_ctp_quote_handler::OnRtnDepthMarketData(CThostFtdcDepthMarketDataField *pDepthMarketData)
{
#if 0
	printf("[QUOTE_INFO] symbol:%s,Turnover:%f, Volume:%d, time: %s  \n",
		pDepthMarketData->InstrumentID,
		pDepthMarketData->Turnover,
		pDepthMarketData->Volume,
		pDepthMarketData->UpdateTime);
#endif
	level1_quote_t *quote;
	quote = &inner_quote_ar.p_addr[inner_quote_ar.cur_idx];
	memcpy(quote->symbol, pDepthMarketData->InstrumentID, sizeof(pDepthMarketData->InstrumentID));
	quote->ap1 = pDepthMarketData->AskPrice1;
	quote->av1 = pDepthMarketData->AskVolume1;
	quote->bp1 = pDepthMarketData->BidPrice1;
	quote->bv1 = pDepthMarketData->BidVolume1;
	quote->turnover = pDepthMarketData->Turnover;
	quote->tot_trade_vol = pDepthMarketData->Volume;
	quote->last_price = pDepthMarketData->LastPrice;
	quote->up_limited = pDepthMarketData->UpperLimitPrice;
	quote->down_limited  = pDepthMarketData->LowestPrice;
	quote->history_highest_price = pDepthMarketData->HighestPrice;
	quote->history_lowest_price = pDepthMarketData->LowerLimitPrice;
	quote->open_price = pDepthMarketData->OpenPrice;
	quote->pre_close_price = pDepthMarketData->PreClosePrice;
	quote->pre_settlement_price =  pDepthMarketData->PreSettlementPrice;
	quote->exchg_timestamp = timestamp_convert(pDepthMarketData->UpdateTime, pDepthMarketData->UpdateMillisec);
#if 0
        printf("[DEBUG]: %s %f %f %f %d %f %f %d %d \n",quote->symbol,
                        quote->open_price,
                        quote->pre_settlement_price,
                        quote->pre_close_price,
                        quote->exchg_timestamp,
                        quote->ap1,quote->bp1,quote->av1,quote->bv1);
#endif
	if (is_quote_valid(quote)) {
		/* TODO: A new buffer should be malloced when cur_idx reaches to (buffer size-1) */
		inner_quote_ar.cur_idx++;
		if (inner_quote_ar.cur_idx >= QUOTE_ITEM_MAX) {
			/* rolling back  */
			inner_quote_ar.cur_idx = 0;
		}
	} else {
		record_error_market_tick(quote);
	}
}


int 
my_ctp_quote_handler::get_realtime_quote_data(char *src)
{
	int gap = inner_quote_ar.cur_idx- inner_quote_ar.last_idx;
	if (gap > 0) {
		memcpy(src, &inner_quote_ar.p_addr[inner_quote_ar.last_idx], gap*sizeof(level1_quote_t));
	}
	else if (gap < 0) {
        /* TOCHECK: Is overflow dealing is neccessary here? */
		gap += inner_quote_ar.max_cnt;
		uint64_t overflow_offset = (inner_quote_ar.max_cnt - inner_quote_ar.last_idx) * sizeof(level1_quote_t);
		memcpy(src, (char *)(&inner_quote_ar.p_addr[inner_quote_ar.last_idx]), overflow_offset);
		memcpy(src + overflow_offset, inner_quote_ar.p_addr, sizeof(level1_quote_t)*inner_quote_ar.cur_idx);
	}

	inner_quote_ar.last_idx = inner_quote_ar.cur_idx;
	return gap;
}

my_ctp_quote_handler::my_ctp_quote_handler(user_login_info_t *login) : 
    login_info(*login), request_id(0), login_status(0)
{
	int ret = 0;
	char ip_port_addr[64];
        for (int sym_idx = 0; sym_idx < login_info.subcribe_cnt; sym_idx++)
        {
               login_info.subcribe[sym_idx] = login_info.sub_ar[sym_idx];
        }
	snprintf(ip_port_addr, sizeof(ip_port_addr), "tcp://%s:%d", login->ip, login->port);
	p_api = CThostFtdcMdApi::CreateFtdcMdApi();
	p_api->RegisterSpi(this);
	p_api->RegisterFront(ip_port_addr);
	p_api->Init();
	malloc_memcpy_for_quote();
	LOG(INFO) << "[OK]: constructor" << __func__ << ":" << __LINE__ << "addr: " << ip_port_addr;
}

my_ctp_quote_handler::~my_ctp_quote_handler()
{
	if (p_api) {
		p_api->RegisterSpi(this);
		p_api->Release();
		p_api = NULL;
	}
	free_malloc_memory();
	LOG(INFO) << "[OK]: ~ " << __func__ << ":" << __LINE__;
}

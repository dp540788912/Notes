#ifndef CTP_QUOTE_INTERFACE_H
#define CTP_QUOTE_INTERFACE_H

#ifdef __cplusplus
extern "C"
{
#endif

typedef struct ctp_quote_cfg
{
	char			ip[32];
	int				port;
	char			BrokerID[32];
	char			UserID[32];
	char			Passwd[128];
	unsigned int	subcribe_cnt;
	char			sub_ar[512][32];
	char			*subcribe[512];
}ctp_quote_cfg_t;

typedef struct ctp_level1_quote {
	char			symbol[32];
	double			last_price;
	double			price_chg;
	double			ap1;
	unsigned int    av1;
	double			bp1;
	unsigned int	bv1;
	unsigned int	tot_trade_vol;
	double			turnover;
	unsigned int	open_interest;
	unsigned int 	exchg_timestamp;
	double			up_limited;
	double			down_limited;
	double			open_price;
	double			pre_close_price;
    double          pre_settlement_price;
	double			history_highest_price;
	double			history_lowest_price;
}ctp_level1_quote_t;

typedef struct all_exchg_ctp_quote_cfg
{
	ctp_quote_cfg_t		ctp_cfg_info_ar[4];
	unsigned int		exchg_quote_cnt;
}all_exchg_ctp_quote_cfg_t;

typedef struct ctp_quote_info
{
	unsigned  int		tot_cnt;
	ctp_level1_quote_t  *p_addr;

}ctp_quote_info_t;


int ctp_quote_init(all_exchg_ctp_quote_cfg_t *exchg_quote_cfg_info);

ctp_quote_info_t* get_ctp_quote_info();

int ctp_quote_destory();


#ifdef __cplusplus
}
#endif

#endif

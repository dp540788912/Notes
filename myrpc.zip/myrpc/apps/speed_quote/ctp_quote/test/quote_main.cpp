#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include "ctp_quote_interface.h"


#define  MAX_EXCHG_TEST_CNT		(4)

unsigned  int tot_test_cnt = MAX_EXCHG_TEST_CNT;



int  port[5] = { 41213, 41213, 41213, 41213, 41213 };

char  ip_addr[5][64] = {
	"180.168.212.75",
	"180.169.101.177",
	"101.231.3.125",
	"180.169.101.177"
};

char account[5][16] = {
	"81241335",
	"120300555",
	"910080",
	"100103186"
};

char broker_id[5][16] = {
	"8000",
	"66666",
	"8888",
	"66666"
};

char pwd[5][256] = {
	"R4Vg3pVoJIPp0nABd9Xs7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
	"R4Vg3pVoJIPp0nABd9Xs7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
	"R4Vg3pVoJIPp0nABd9Xs7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==",
	"R4Vg3pVoJIPp0nABd9Xs7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=="
};

char  dce_test_symbol_ar[2][32] = {"m1809","l1809"};
char  shfe_test_symbol_ar[2][32] = { "ru1809", "rb1809" };
char  czce_test_symbol_ar[2][32] = { "SR809", "FG809" };
char  cffex_test_symbol_ar[2][32] = {  "T1809", "T1806" };


void
filled_login_info(ctp_quote_cfg_t *login, int idx)
{
	memset(login, 0, sizeof(ctp_quote_cfg_t));
	memcpy(login->ip, ip_addr[idx], sizeof(login->ip));
	memcpy(login->Passwd, pwd[idx], sizeof(login->Passwd));
	memcpy(login->BrokerID, broker_id[idx], sizeof(login->BrokerID));
	memcpy(login->UserID, account[idx], sizeof(login->UserID));
	login->port = port[idx];

	login->subcribe_cnt = 2;
	int sub_idx = 0;

	switch (idx){
		case 0:
			for (sub_idx = 0; sub_idx < login->subcribe_cnt; sub_idx++) {
				strcpy(login->sub_ar[sub_idx], dce_test_symbol_ar[sub_idx]);
			}
			break;

		case 1:
			for (sub_idx = 0; sub_idx < login->subcribe_cnt; sub_idx++) {
				strcpy(login->sub_ar[sub_idx], shfe_test_symbol_ar[sub_idx]);
			}
			break;

		case 2:
			for (sub_idx = 0; sub_idx < login->subcribe_cnt; sub_idx++) {
				strcpy(login->sub_ar[sub_idx], czce_test_symbol_ar[sub_idx]);
			}
			break;

		default:
			for (sub_idx = 0; sub_idx < login->subcribe_cnt; sub_idx++) {
				strcpy(login->sub_ar[sub_idx], cffex_test_symbol_ar[sub_idx]);
			}
			break;
	}  
	

}

void show_login_info(ctp_quote_cfg_t *src)
{
	printf("[SHOW_CFG_INFO]: ip:%s, port:%d, BrokerID:%s, pwd:%s, account:%s \n",
		src->ip,
		src->port,
		src->BrokerID,
		src->Passwd,
		src->UserID);

	printf("[SUBCRIBE_SYMBOL]: tot_cnt:%d \n",src->subcribe_cnt);
	int idx = 0;
	for (idx = 0; idx < src->subcribe_cnt; idx ++){
		printf("symbol: %s \n", src->sub_ar[idx]);
	}
	
}



void Quit_Signal_Handler(int signal)
{
	printf("call Quit_Signal_Handler \n");
	ctp_quote_destory();

	exit(0);
}


int
main()
{
	signal(SIGINT, Quit_Signal_Handler);
	all_exchg_ctp_quote_cfg_t exchg_quote_cfg_info;
	exchg_quote_cfg_info.exchg_quote_cnt = 4;
	int idx = 0;

	for (idx = 0; idx < exchg_quote_cfg_info.exchg_quote_cnt; idx++) {
		filled_login_info(&exchg_quote_cfg_info.ctp_cfg_info_ar[idx], idx);
		show_login_info(&exchg_quote_cfg_info.ctp_cfg_info_ar[idx]);
		printf("[INFO]: %s , %d , idx:%d  \n", __FUNCTION__, __LINE__, idx);
	}

	ctp_quote_init(&exchg_quote_cfg_info);

	while (1)
	{
		get_ctp_quote_info();
		sleep(1);
	};

	return 0;
}

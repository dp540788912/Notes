#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>

#include "ctp_trader.h"
#include "ctp_platform_interface.h"

#define  MAX_OBJ_CNT		(40)
#define  MAX_STRATEGY_CNT   (32)

ctp_trader *obj_ctp[MAX_OBJ_CNT];
unsigned int s_all_acount_cnt = 0;
query_pos_info_ret_t ret_pos_data;
query_account_info_ret_t  ret_account_data;
query_order_info_ret_t ret_history_order_data;
query_order_info_ret_t ret_realtime_order_data;


void
show_cfg(users_cfg_t *input_cfg)
{
	printf("[INFO]: front_addr:%s, brokerid : %s, account : %s, pwd : %s \n",
		input_cfg->front_addr,
		input_cfg->brokerid,
		input_cfg->account,
		input_cfg->password);
}



int
malloc_mem_for_order(query_order_info_ret_t *data)
{
	unsigned int default_order_cnt = (s_all_acount_cnt * 4096);
	data->tot_order_cnt = 0;
	/* default every account use 4096 order */
	data->p_order = (interface_order_info_t *)calloc(default_order_cnt, sizeof(interface_order_info_t));
	if (data->p_order == NULL) {
		printf("[ERROR]: calloc got error %s, %d \n", __func__, __LINE__);
		return -1;
	}
	printf("[INFO]: %s , %d , default_order_cnt:%d ,  sizeof(interface_order_info_t):%d \n", __FUNCTION__, __LINE__, default_order_cnt, sizeof(interface_order_info_t));
	return 0;
}


int
create_connect_to_exchg(users_cfg_t *input_cfg)
{
	int ret = 0;
	static  unsigned int obj_idx = 0;
	obj_ctp[obj_idx] = new ctp_trader(*input_cfg);
	
	obj_ctp[obj_idx]->add_account_cnt(1);
	/* long short position */
	obj_ctp[obj_idx]->add_symbol_pos_cnt(MAX_STRATEGY_CNT * 2);
	
	obj_ctp[obj_idx]->malloc_account_info_mem();
	ret = obj_ctp[obj_idx]->malloc_history_order_info();
	if (ret) {
		printf("[ERROR]: %s, %d \n", __FUNCTION__, __LINE__);
	}

	ret = obj_ctp[obj_idx]->malloc_cur_order_info();
	if (ret) {
		printf("[ERROR]: %s, %d \n", __FUNCTION__, __LINE__);
	}
	ret = obj_ctp[obj_idx]->malloc_pos_info_mem();
	if (ret) {
		printf("[ERROR]: %s, %d \n", __FUNCTION__, __LINE__);
	}

	ret = obj_ctp[obj_idx]->Qry_settlement_info();
	if (ret) {
		printf("[ERROR]: Qry_settlement_info, ret:%d \n", ret);
	}
	
	sleep(1);

	ret = obj_ctp[obj_idx]->Qry_settlement_info_confirm();
	if (ret) {
		printf("[ERROR]: Qry_settlement_info_confirm, ret:%d \n", ret);
	}
	sleep(1);



	obj_idx++;
	sleep(1);
	return 0;
}


void
send_query_account()
{
	volatile int obj_idx = 0, ret = 0;
	printf("[SEND_QUERY_POS]: s_all_acount_cnt:%d \n", s_all_acount_cnt);
	for (obj_idx = 0; obj_idx < s_all_acount_cnt; obj_idx++) {
		
		ret = obj_ctp[obj_idx]->QryFund();
		if (ret) {
			printf("[ERROR]: QryFund, ret:%d, obj_idx: %d \n", ret, obj_idx);
			sleep(1);
		}

		printf("[DEBUG]: %s, %d ,obj_idx:%d \n", __FUNCTION__, __LINE__, obj_idx);
	}
}

void
send_query_order()
{
	int obj_idx = 0, ret = 0;
	printf("[SEND_QUERY_POS]: s_all_acount_cnt:%d \n", s_all_acount_cnt);
	for (obj_idx = 0; obj_idx < s_all_acount_cnt; obj_idx++) {
		while (1) {
			sleep(1);
			ret = obj_ctp[obj_idx]->QryTrade();
			if (ret) {
				printf("[ERROR]: QryTrade, ret:%d \n", ret);
				sleep(2);
			}
			else{
				break;
			}
		}

		sleep(1);
		while (1) {
			ret = obj_ctp[obj_idx]->QryOrder();
			if (ret) {
				printf("[ERROR]: QryOrder(), ret:%d \n", ret);
				sleep(2);
			}
			else{
				break;
			}
		}
	}
}

void
send_query_pos()
{
	int obj_idx = 0, ret = 0;
	printf("[SEND_QUERY_POS]: s_all_acount_cnt:%d \n", s_all_acount_cnt);
	for (obj_idx = 0; obj_idx < s_all_acount_cnt; obj_idx++) {
		while (1)
		{
			ret = obj_ctp[obj_idx]->QryPosition();
			if (ret) {
				printf("[ERROR]: QryPosition, ret:%d \n", ret);
				sleep(2);
			}
			else{
				break;
			}
		}

	}
}

void
clear_flag_status()
{
	int obj_idx = 0, ret = 0;
	printf("[CLEAR_ACCOUNT_POS_STATUS]: s_all_acount_cnt:%d \n", s_all_acount_cnt);
	for (obj_idx = 0; obj_idx < s_all_acount_cnt; obj_idx++) {
		obj_ctp[obj_idx]->clear_flag_status();
	}
}

int ctp_trader_init(all_exchg_ctp_cfg_t *all_exchg_cfg_info)
{
	unsigned int account_cnt = 0, strategy_cnt = 0, all_tunnel_cnt = 0;
	ctp_cfg_t *cfg_info;
	all_tunnel_cnt = all_exchg_cfg_info->exchg_tunnel_cnt;
	int ret = 0;
	char extract_passwd[256];
	
	users_cfg_t input_cfg;
	int idx = 0, strategy_idx = 0, tunnel_idx = 0;
	ret = malloc_mem_for_order(&ret_realtime_order_data);
        printf("[INFO]: %s, %d ret_realtime_order_data: %x \n", __func__,__LINE__,ret_realtime_order_data.p_order);
	if (ret) {
		 printf("[ERROR]: %s, %d \n", __func__, __LINE__);
                 return -1;
	}

	for (tunnel_idx = 0; tunnel_idx < all_tunnel_cnt; tunnel_idx++)
	{
		cfg_info = (ctp_cfg_t *)(&all_exchg_cfg_info->ctp_cfg_info_ar[tunnel_idx]);
		account_cnt = cfg_info->account_cnt;
		s_all_acount_cnt += account_cnt;
		memset(&input_cfg, 0, sizeof(users_cfg_t));
		memcpy(input_cfg.brokerid, cfg_info->broker_id, sizeof(input_cfg.brokerid));
		snprintf(input_cfg.front_addr, 64, "tcp://%s:%d", cfg_info->ip, cfg_info->port);
		
		input_cfg.exchg_code_sym = cfg_info->exchg_tag;

		for (idx = 0; idx < account_cnt; idx++)
		{
			memcpy(input_cfg.account, cfg_info->login_info_ar[idx].account, sizeof(input_cfg.account));
			memset(extract_passwd, 0, 256);
			my_decrypt(cfg_info->login_info_ar[idx].passwd, extract_passwd, 256);
			printf("[passwd]: %s \n",extract_passwd);
			memcpy(input_cfg.password, extract_passwd, sizeof(input_cfg.password));
			show_cfg(&input_cfg);
			create_connect_to_exchg(&input_cfg);
		}

	}

	printf("finish ctp_trader_init! s_all_acount_cnt:%d \n", s_all_acount_cnt);
	return  0;

}


int ctp_trader_destory_func(int exchg_code)
{
	printf("ctp_trader_destory ! \n");
	delete obj_ctp[exchg_code];
}

unsigned int 
get_account_all_exchg_account_cnt()
{
	int idx = 0;
	unsigned int tot_cnt = 0; 
	for (idx = 0; idx < s_all_acount_cnt; idx++) {
		tot_cnt += obj_ctp[idx]->get_account_cnt();
	}
	return tot_cnt;
}

void
get_account_all_exchg_info(query_account_info_ret_t *dest)
{
	unsigned int idx = 0, cnt = 0;
	char *src = NULL;
	/* every time need clear  */
	dest->account_cnt = 0;

	for (idx = 0; idx < s_all_acount_cnt; idx++)	{
		while (1) {
			src = (char *)(obj_ctp[idx]->query_account_info());
			if (src) {
				memcpy((char *)(&dest->account_ar[dest->account_cnt]), src, sizeof(inner_account_info_t));
				break;
			}
		}
		dest->account_cnt += obj_ctp[idx]->get_account_cnt();
		obj_ctp[idx]->clear_account_flag_status();
	}

}

int
malloc_account_ret_mem(query_account_info_ret_t *ret_data)
{
	char *ret = NULL;
	unsigned int tot_account_cnt = get_account_all_exchg_account_cnt();
	ret_data->account_cnt = 0;
	ret_data->account_ar = (interface_account_info_t *)calloc(tot_account_cnt, sizeof(interface_account_info_t));
	if (ret_data->account_ar == NULL) {
		printf("[ERROR]: %s, %d \n", __func__, __LINE__);
		return -1;
	}

	return 0;
}

void
show_get_all_exchg_info(query_account_info_ret_t *data)
{	
	int idx ; 
	inner_account_info_t *show;
	for(idx = 0; idx < data->account_cnt; idx++) {
		show = (inner_account_info_t *)(&(data->account_ar[idx]));
		printf("[ACCOUNT_INFO]: addr:%x, account:%s , static_interest:%f, close_profit:%f, dynamic:%f, avail:%f, rate_degres:%f\n", 
				show,
				show->account,
				show->static_interest,
				show->close_profit,
				show->dynamic_profit,
				show->fund_avail,
				show->rate_degree);
	}

}

query_account_info_ret_t *
ctp_query_account_info()
{
	static int account_flag = 1;	
	char *s_ret_mem = NULL;
	int idx = 0, cnt = 0, ret = 0;
	unsigned int tot_account_cnt = 0;

	/* the first query case */
	if (account_flag) {
		
		account_flag = 0;
		ret = malloc_account_ret_mem(&ret_account_data);
		if (ret) {
			printf("[ERROR]: %s, %d \n", __func__, __LINE__);
		}
		printf("[INFO]: all_account:%d \n", tot_account_cnt);	
	}

	send_query_account();
	get_account_all_exchg_info(&ret_account_data);
	
#if DEBUG_INFO
	show_get_all_exchg_info(&ret_account_data);
#endif

	printf("[INFO]: FINISH ctp_query_account_info() ! \n");

	return &ret_account_data;
}


unsigned int
get_all_pos_cnt()
{
	int idx = 0;
	unsigned int tot_pos_cnt = 0;
	for (idx = 0; idx < s_all_acount_cnt; idx++) {
		tot_pos_cnt += obj_ctp[idx]->get_symbol_pos_tot_cnt();
	}

	return tot_pos_cnt;
}

int 
malloc_pos_mem(query_pos_info_ret_t *data)
{
	char *ret = NULL;
	unsigned int tot_pos_cnt = get_all_pos_cnt();
	//data->tot_pos_cnt = tot_pos_cnt;
	printf("[INFO]: %s, %d, tot_pos_cnt:%u \n", __FUNCTION__, __LINE__, tot_pos_cnt);
	/* long  short position  */
	data->p_pos = (interface_position_info_t *)calloc(tot_pos_cnt, sizeof(interface_position_info_t));
	if (data->p_pos == NULL) {
		printf("[ERROR]: %s, %d \n", __func__, __LINE__);
		return -1;
	}

	return 0;
	
}

void
get_all_pos_info(query_pos_info_ret_t *ret_pos_data)
{
	int idx = 0, inner_idx = 0, cur_cnt = 0;
	unsigned int start_idx = 0 ;
	interface_position_info_t *src = NULL;
	ret_pos_data->tot_pos_cnt = 0;
	printf("[INFO]: %s, %d,  \n", __FUNCTION__, __LINE__);
	for (idx = 0; idx < s_all_acount_cnt; idx++)	{

		while (1) {
			cur_cnt = obj_ctp[idx]->get_symbol_cur_pos_cnt();
			if (cur_cnt > 0) {
				src = (interface_position_info_t *)(obj_ctp[idx]->query_pos_info());
				memcpy((char *)(&ret_pos_data->p_pos[ret_pos_data->tot_pos_cnt]), (char *)(src), cur_cnt*sizeof(interface_position_info_t));
				printf("[DATA]: %s , %d  cur_cnt: %d , \n", __FUNCTION__ , __LINE__, cur_cnt);
				ret_pos_data->tot_pos_cnt += cur_cnt;
				break;
			}
			else if (cur_cnt == 0) {
				break;
			}
		}
		obj_ctp[idx]->clear_pos_flag_status();

	}

}

void
show_pos_data(query_pos_info_ret_t *data)
{
	int idx = 0;
	interface_position_info_t *src;
	printf("[SHOW_POS_DATA]: tot_pos_cnt: %d,  \n", data->tot_pos_cnt);
	for (idx = 0; idx < data->tot_pos_cnt; idx++)
	{
		src = (&data->p_pos[idx]);
		printf("[POS_INFO]:account:%s, avg_price:%f, close_pos:%d, dir:%c ,symbol:%s, td_pos:%d, yd_pos:%d, tot_pos:%d, frozen_margin:%f \n", 
				src->account,
				src->avg_price,
				src->close_avail_pos,
				src->dir,
				src->symbol,
				src->td_pos,
				src->yd_pos,
				src->tot_pos,
				src->frozen_margin);
	}


}

query_pos_info_ret_t *ctp_query_position_info()
{
	
	static int pos_flag = 1;
	int ret = 0;
	
	if (pos_flag) {
		pos_flag = 0;
		ret = malloc_pos_mem(&ret_pos_data);
		if (ret) {
			printf("[ERROR]: %s, %d \n", __func__, __LINE__);
		}
	}
	
	send_query_pos();
	get_all_pos_info(&ret_pos_data);
	show_pos_data(&ret_pos_data);
	return &ret_pos_data;

}

int 
get_all_order_info(query_order_info_ret_t *data)
{
	int idx = 0, ret = 0;
	data->tot_order_cnt = 0;
	printf("[SHOW_INFO]: SHOW FILLED INFO! , s_all_acount_cnt: %u  %s, %d \n", s_all_acount_cnt,__func__, __LINE__);
	for (idx = 0; idx < s_all_acount_cnt; idx++) {
	
		while (1) {
			ret = obj_ctp[idx]->get_history_order_finish_info((char *)(data->p_order));
			if (ret >= 0) {
				break;
			}
		}
		data->tot_order_cnt += ret;


		while (1) {
			ret = obj_ctp[idx]->get_history_order_hold_info((char *)(&data->p_order[data->tot_order_cnt]));
			if (ret >= 0) {
				break;
			}
		}
		data->tot_order_cnt += ret;
		obj_ctp[idx]->clear_cur_order_flag_status();
	}
}

int
realtime_get_all_order_info(query_order_info_ret_t *data)
{
	int idx = 0, ret = 0;
	data->tot_order_cnt = 0;
	printf("[SHOW_INFO]: SHOW FILLED INFO! , s_all_acount_cnt: %u  %s , %d ,%x\n", s_all_acount_cnt, __func__, __LINE__,data->p_order);
        if (data->p_order == NULL) {
                printf("[ERROR]: %s , %d \n",__func__, __LINE__);
                return -1;
        }
	for (idx = 0; idx < s_all_acount_cnt; idx++) {
		ret = obj_ctp[idx]->get_realtime_order_deal_info((char *)(data->p_order));
		data->tot_order_cnt += ret;

		ret = obj_ctp[idx]->get_realtime_order_rsp_info((char *)(&data->p_order[data->tot_order_cnt]));
		data->tot_order_cnt += ret;
	}
        printf("[INFO]: Finish  %s , %d \n",__func__, __LINE__);
        return 0;
}

void
show_filled_order_info(query_order_info_ret_t *data)
{
	printf("[SHOW_INFO]: tot_cnt:%d \n", data->tot_order_cnt);
	int idx = 0;
	interface_order_info_t *src;
	for (idx = 0; idx < data->tot_order_cnt ; idx++) {
		src = &data->p_order[idx];
#if 1		
		printf("account:%s ,symbol:%s, dir:%c, open_close:%c, place_time:%s ,filled_time:%s, exchg_entrust_no:%lu, exchg_trade_no:%lu ,price:%f, vol:%d \n",
				src->account,
				src->symbol,
				src->dir,
				src->open_close,
				src->place_time,
				src->fill_time,
				src->exchg_entrust_no,
				src->exchg_deal_entrust_no,
				src->price,
				src->deal_vol);
#endif
	}
}


query_order_info_ret_t *
ctp_query_history_order_info()
{
	static int order_flag = 1;
	int ret = 0;
	
	if (order_flag) {
		order_flag = 0;
		ret = malloc_mem_for_order(&ret_history_order_data);
		if (ret) {
			printf("[ERROR]: %s, %d \n", __func__, __LINE__);
			return &ret_history_order_data;
		}
	}

	send_query_order();
	get_all_order_info(&ret_history_order_data);
	show_filled_order_info(&ret_history_order_data);
	
	return &ret_history_order_data;
}


query_order_info_ret_t *ctp_query_cur_order_info()
{
	static int order_flag = 1;
	int ret = 0;

	if (order_flag) {
		order_flag = 0;
	}

	
	realtime_get_all_order_info(&ret_realtime_order_data);
	show_filled_order_info(&ret_realtime_order_data);

	return &ret_realtime_order_data;
}


int 
ctp_trader_destory()
{
	int idx = 0;
	for (idx = 0; idx < s_all_acount_cnt; idx++) {
		ctp_trader_destory_func(idx);
	}

	free(ret_history_order_data.p_order);
	free(ret_pos_data.p_pos);
	free(ret_account_data.account_ar);
	free(ret_realtime_order_data.p_order);
	printf("[DESTORY_OK] !\n");
}



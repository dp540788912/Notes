#include "list.h"

#define  ACCOUNT_LEN		(32)
#define  SYMBOL_LEN			(32)
#define  TIME_LEN			(16)
#define  ORDER_DETAIL_LEN	(64)
#define  EXCHGE_LEN			(16)
#define  STRATEGY_NAME_LEN	(64)

typedef struct inner_account_info
{
	char	account[ACCOUNT_LEN];
	double  static_interest;
	double  fee;
	double  close_profit;
	double  hold_profit;
	double  dynamic_profit;
	double  frozen_margin;
	double  place_frozen;
	double  fund_avail;
	double  rate_degree;
}inner_account_info_t;

typedef struct inner_order_info
{
	char			account[ACCOUNT_LEN];
	char			symbol[SYMBOL_LEN];
	unsigned long	exchg_entrust_no;
	unsigned long	exchg_deal_entrust_no;
	char			dir;
	char			open_close;
	char			status;
	double			price;
	unsigned int	org_vol;
	unsigned int	remain_vol;
	unsigned int	deal_vol;
	char			place_time[TIME_LEN];
	char			fill_time[TIME_LEN];
	char			order_detail[ORDER_DETAIL_LEN];
}inner_order_info_t;

typedef struct inner_position_info
{
	char			account[ACCOUNT_LEN];
	char			symbol[SYMBOL_LEN];
	char			dir;
	unsigned int	tot_pos;
	unsigned int	yd_pos;
	unsigned int	td_pos;
	unsigned int	close_avail_pos;
	double			avg_price;
	double			pos_profit_loss;
	double			frozen_margin;
	char			exchg[EXCHGE_LEN];

}inner_position_info_t;

typedef struct inner_strategy_info
{
	char		strategy_name[STRATEGY_NAME_LEN];
	double		fee;
	double		close_profit;
	double		hold_profit;
	double		frozen_margin;
	double		place_frozen;
	double		fund_avail;
}inner_strategy_info_t;


typedef struct users_cfg {
	char front_addr[64];
	char brokerid[16];
	char account[16];
	char password[16];
	int  exchg_code_sym;
}users_cfg_t;


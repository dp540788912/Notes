#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h> 
#include "ctp_trader.h"


static  char exchg_code_map_ar[4][8] = { "DCE", "SHFE", "CZCE", "CFFEX"};
static  int account_idx = 0;

	void 
check_ctp_flow_dir(char *flow_dir)
{
	int ret = access(flow_dir, F_OK);
	if (ret)
	{
		ret  = mkdir(flow_dir, S_IRUSR | S_IWUSR | S_IXUSR);
		if (ret) {
			printf("[ERROR]: %s, %d \n", __FUNCTION__, __LINE__);
		}
	}
	printf("[INFO]: flow_dir: %s  \n" , flow_dir);
}

ctp_trader::ctp_trader(users_cfg_t &cfg) : cfg_(cfg), ready_(false)
{
	char flow_dir[64];
	snprintf(flow_dir, 64, "./flow_ctp/%s",cfg_.account);
	check_ctp_flow_dir(flow_dir);
	api_ = CThostFtdcTraderApi::CreateFtdcTraderApi(flow_dir);
	api_->RegisterSpi(this);

	api_->SubscribePrivateTopic(THOST_TERT_QUICK);
	api_->SubscribePublicTopic(THOST_TERT_QUICK);

	api_->RegisterFront(cfg.front_addr);

	api_->Init();

	memset(&manage_account_ar, 0, sizeof(manage_account_info_t));
	memset(&manage_pos_ar, 0, sizeof(manage_pos_info_t));
	memset(&manage_strategy_ar, 0, sizeof(inner_manager_strategy_t));
	memset(&manage_order_ar, 0, sizeof(inner_manager_order_t));
	memset(&realtime_order_ar, 0, sizeof(inner_manager_realtime_order_t));
	while(ready_ == false) {
		sleep(3);
	}
	account_idx++;
	printf("INIT OK! \n");
}

ctp_trader::~ctp_trader()
{
	if (api_) {
		api_->RegisterSpi(NULL);
		api_->Release();
		api_ = NULL;
		printf("call destructor %s, %d \n", __func__, __LINE__);
	}

	if (manage_account_ar.p_account) {
		free(manage_account_ar.p_account);
		printf("[INFO]: free  manage_account_ar ok ! \n");
	}

	if (manage_pos_ar.p_pos) {
		free(manage_pos_ar.p_pos);
		printf("[INFO]: free  manage_pos_ar ok ! \n");
	}

	if (manage_order_ar.finish_order) {
		free(manage_order_ar.finish_order);
		printf("[INFO]: free manage_order_ar.finish_order !\n");
	}

	if (manage_order_ar.hold_order) {
		free(manage_order_ar.hold_order);
		printf("[INFO]: free manage_order_ar.hold_order !\n");
	}

	if (realtime_order_ar.exchg_deal_order) {
		free(realtime_order_ar.exchg_deal_order);
		printf("[INFO]: free realtime_order_ar.exchg_deal_order \n");
	}

	if (realtime_order_ar.exchg_rsp_order) {
		free(realtime_order_ar.exchg_rsp_order);
		printf("[INFO]: free realtime_order_ar.exchg_rsp_order \n");
	}
}

	int
ctp_trader::Qry_settlement_info()
{
	int ret = 0;
	CThostFtdcQrySettlementInfoField pQrySettlementInfo;
	memset(&pQrySettlementInfo, 0, sizeof(pQrySettlementInfo));
	memcpy(pQrySettlementInfo.BrokerID, cfg_.brokerid, sizeof(pQrySettlementInfo.BrokerID));
	memcpy(pQrySettlementInfo.InvestorID, cfg_.account, sizeof(pQrySettlementInfo.InvestorID));

	ret = api_->ReqQrySettlementInfo(&pQrySettlementInfo, 0);
	if (ret) {
		printf("[ERROR]: %s, %d , ret:%d\n", __func__, __LINE__, ret);
	}

	return ret;
}

	int 
ctp_trader::Qry_settlement_info_confirm()
{
	int ret = 0;
	CThostFtdcQrySettlementInfoConfirmField pQrySettlementInfoConfirm;
	memset(&pQrySettlementInfoConfirm, 0, sizeof(pQrySettlementInfoConfirm));

	memcpy(pQrySettlementInfoConfirm.BrokerID, cfg_.brokerid, sizeof(pQrySettlementInfoConfirm.BrokerID));
	memcpy(pQrySettlementInfoConfirm.InvestorID, cfg_.account, sizeof(pQrySettlementInfoConfirm.InvestorID));

	ret = api_->ReqQrySettlementInfoConfirm(&pQrySettlementInfoConfirm, 0);
	if (ret){
		printf("[ERROR]: %s, %d , ret:%d\n", __func__, __LINE__, ret);
	}

	return ret;
}

	int
ctp_trader::malloc_account_info_mem()
{
	manage_account_ar.p_account = (inner_account_info_t *)calloc(manage_account_ar.account_cnt, sizeof(inner_account_info_t));
	if (manage_account_ar.p_account == NULL) {
		printf("[ERROR]: calloc %s , %d \n", __func__, __LINE__);
		return -1;
	}

	return 0;
}

	int
ctp_trader::malloc_pos_info_mem()
{
	manage_pos_ar.p_pos = (inner_position_info_t *)calloc(manage_pos_ar.tot_pos_cnt, sizeof(inner_position_info_t));
	if (manage_pos_ar.p_pos == NULL) {
		printf("[ERROR]: calloc %s , %d \n", __func__, __LINE__);
		return -1;
	}

	return 0;
}

	void
ctp_trader::add_account_cnt(int cnt)
{
	manage_account_ar.account_cnt += cnt;
}

	int 
ctp_trader::get_account_cnt()
{
	return manage_account_ar.account_cnt;
}


	unsigned int 
ctp_trader::add_symbol_pos_cnt(int strategy_cnt)
{
	manage_pos_ar.tot_pos_cnt += strategy_cnt;
	return manage_pos_ar.tot_pos_cnt;
}


	unsigned int 
ctp_trader::get_symbol_cur_pos_cnt()
{
	if (manage_pos_ar.finish_flag) {
		return manage_pos_ar.cur_pos_cnt;
	}
	else{
		return -1;
	}
}

	void
ctp_trader::clear_cur_pos_cnt()
{

}

	unsigned int
ctp_trader::get_symbol_pos_tot_cnt()
{
	return manage_pos_ar.tot_pos_cnt;
}

	char *
ctp_trader::query_pos_info()
{
	return ((char *)(manage_pos_ar.p_pos));
}

	char *
ctp_trader::query_account_info()
{
	if (manage_account_ar.finish_flag) {
		return ((char *)(manage_account_ar.p_account));
	}
	else {
		return NULL;
	}
}


	char * 
ctp_trader::get_order_info_start_addr()
{

}


	int
ctp_trader::get_history_order_finish_info(char *src)
{
	int idx = 0;

	if (manage_order_ar.deal_finish_flag) {
		printf("[DEBUG]: get_order_finish_info finish_cnt:%d \n", manage_order_ar.finish_cur_cnt);
		if (manage_order_ar.finish_cur_cnt) {
			memcpy(src, manage_order_ar.finish_order, sizeof(inner_order_info_t)*manage_order_ar.finish_cur_cnt);

			printf("account: %s, symbol:%s  \n", manage_order_ar.finish_order[0].account, manage_order_ar.finish_order[0].symbol);
		}
		return manage_order_ar.finish_cur_cnt;
	}

	return -1;
}

	int 
ctp_trader::get_realtime_order_deal_info(char *data)
{
	int idx = 0, gap = 0 ;
	unsigned int cur_idx, last_idx, overflow_offset ;
	cur_idx = realtime_order_ar.deal_cur_cnt;
	last_idx = realtime_order_ar.last_deal_idx;
	gap = cur_idx - last_idx;
        printf("[INFO]: %s , %d ,gap: %d, cur:%d  last:%d \n", __func__, __LINE__, gap, cur_idx, last_idx);
	if (gap > 0) {
		realtime_order_ar.last_deal_idx = cur_idx;
		memcpy(data, (char *)(&realtime_order_ar.exchg_deal_order[last_idx]), sizeof(inner_order_info_t)*gap);
		printf("[REAL_DEAL_TIME_UPDATE]: cur_idx:%d , last_idx:%d , gap:%d , account:%s, symbol:%s \n", 
				cur_idx,
				last_idx, 
				gap,
				((inner_order_info_t *)data)->account,
				((inner_order_info_t *)data)->symbol);
		printf("[REAL_DEAL_TIME_ORGINAL]: cur_idx:%d , last_idx:%d , gap:%d , account:%s, symbol:%s \n",
				cur_idx,
				last_idx,
				gap,
				realtime_order_ar.exchg_deal_order[cur_idx].account,
				realtime_order_ar.exchg_deal_order[cur_idx].symbol);
	}
	else if (gap < 0)
	{
		gap = gap + realtime_order_ar.max_order_cnt;
		overflow_offset = (realtime_order_ar.max_order_cnt - last_idx) * sizeof(inner_order_info_t);
		memcpy(data, (char *)(&realtime_order_ar.exchg_deal_order[last_idx]), overflow_offset);
		memcpy(data + overflow_offset, realtime_order_ar.exchg_deal_order, sizeof(inner_order_info_t)*cur_idx);
		realtime_order_ar.last_deal_idx = cur_idx;
	}



	return gap;
}


	int 
ctp_trader::get_realtime_order_rsp_info(char *data)
{
	int gap = 0;
	unsigned int cur_idx, last_idx, overflow_offset;
	cur_idx = realtime_order_ar.rsp_cur_cnt;
	last_idx = realtime_order_ar.last_rsp_idx;
	gap = cur_idx - last_idx;
        printf("[INFO]: %s , %d , gap: %d, cur: %d , last:%d \n", __func__, __LINE__, gap, cur_idx, last_idx);
	if (gap > 0) {
		realtime_order_ar.last_rsp_idx = cur_idx;
		memcpy(data, (char *)(&realtime_order_ar.exchg_rsp_order[last_idx]), sizeof(inner_order_info_t)*gap);
		printf("[REAL_RSP_TIME]: cur_idx:%d , last_idx:%d , gap:%d , account:%s, symbol:%s \n",
				cur_idx,
				last_idx,
				gap,
				((inner_order_info_t *)data)->account,
				((inner_order_info_t *)data)->symbol);
	}
	else if (gap < 0)
	{
		gap = gap + realtime_order_ar.max_order_cnt;
		overflow_offset = (realtime_order_ar.max_order_cnt - last_idx) * sizeof(inner_order_info_t);
		memcpy(data, (char *)(&realtime_order_ar.exchg_rsp_order[last_idx]), overflow_offset);
		memcpy(data + overflow_offset, realtime_order_ar.exchg_rsp_order, sizeof(inner_order_info_t)*cur_idx);
		realtime_order_ar.last_rsp_idx = cur_idx;
	}

	return gap;
}

	int 
ctp_trader::get_history_order_hold_info(char *src)
{
	int idx = 0;
	inner_order_info_t *info;
	if (manage_order_ar.rsp_finish_flag) {
		printf("[DEBUG]: get_order_finish_info finish_cnt:%d \n", manage_order_ar.hold_cur_cnt);
		if (manage_order_ar.finish_cur_cnt) {
			memcpy(src, manage_order_ar.hold_order, sizeof(inner_order_info_t)*manage_order_ar.hold_cur_cnt);
			info = (inner_order_info_t *)src;
			printf("account: %s, symbol:%s  \n", manage_order_ar.hold_order[0].account, manage_order_ar.hold_order[0].symbol);
		}
		return manage_order_ar.hold_cur_cnt;
	}

	return -1;
}

	int	 
ctp_trader::malloc_history_order_info()
{
	int idx = 0;
	manage_order_ar.max_order_cnt = 2048;
	manage_order_ar.hold_order = (inner_order_info_t *)calloc(manage_order_ar.max_order_cnt, sizeof(inner_order_info_t));
	if (manage_order_ar.hold_order == NULL) {
		printf("[ERROR]: calloc %s , %d \n", __func__, __LINE__);
		return -1;
	}

	manage_order_ar.finish_order = (inner_order_info_t *)calloc(manage_order_ar.max_order_cnt, sizeof(inner_order_info_t));
	if (manage_order_ar.finish_order == NULL) {
		printf("[ERROR]: calloc %s , %d \n", __func__, __LINE__);
		return -1;
	}

	return 0;
}


	int
ctp_trader::malloc_cur_order_info()
{
	int idx = 0;
	realtime_order_ar.max_order_cnt = 2048;
	realtime_order_ar.exchg_deal_order = (inner_order_info_t *)calloc(realtime_order_ar.max_order_cnt, sizeof(inner_order_info_t));
	if (realtime_order_ar.exchg_deal_order == NULL) {
		printf("[ERROR]: calloc %s , %d \n", __func__, __LINE__);
		return -1;
	}

	realtime_order_ar.exchg_rsp_order = (inner_order_info_t *)calloc(realtime_order_ar.max_order_cnt, sizeof(inner_order_info_t));
	if (realtime_order_ar.exchg_rsp_order == NULL) {
		printf("[ERROR]: calloc %s , %d \n", __func__, __LINE__);
		return -1;
	}

	return 0;
}

int ctp_trader::QryFund()
{
	int ret = 0;
	if (ready_ == false) {
		ret = -1;
		return ret;
	}
	CThostFtdcQryTradingAccountField qry_param;
	memset(&qry_param, 0, sizeof(CThostFtdcQryTradingAccountField));
	strncpy(qry_param.BrokerID, cfg_.brokerid, sizeof(qry_param.BrokerID));
	strncpy(qry_param.InvestorID, cfg_.account, sizeof(qry_param.InvestorID));
	strncpy(qry_param.CurrencyID, "CNY", sizeof(qry_param.InvestorID));
	ret = api_->ReqQryTradingAccount(&qry_param, 0);

	return ret;
}

int ctp_trader::QryPosition()
{
	int ret = 0;
	if (ready_ == false) {
		ret = -1;
		return ret;
	}
	CThostFtdcQryInvestorPositionField qry_param;
	memset(&qry_param, 0, sizeof(CThostFtdcQryInvestorPositionField));
	strncpy(qry_param.BrokerID, cfg_.brokerid, sizeof(qry_param.BrokerID));
	strncpy(qry_param.InvestorID, cfg_.account, sizeof(qry_param.InvestorID));
	ret = api_->ReqQryInvestorPosition(&qry_param, 0);
	return ret;
}

int ctp_trader::QryOrder()
{
	int ret = 0;
	if (ready_ == false) {
		ret = -1;
		return ret;
	}
	CThostFtdcQryOrderField qry_param;
	memset(&qry_param, 0, sizeof(CThostFtdcQryOrderField));
	///经纪公司编号
	strncpy(qry_param.BrokerID, cfg_.brokerid, sizeof(TThostFtdcBrokerIDType));
	///交易所代码
	strncpy(qry_param.ExchangeID, exchg_code_map_ar[cfg_.exchg_code_sym], sizeof(TThostFtdcExchangeIDType));
	///投资者编号
	strncpy(qry_param.InvestorID, cfg_.account, sizeof(TThostFtdcInvestorIDType));
	printf("[INFO]: %s , %d , exchg_code: %s\n", __FUNCTION__, __LINE__, exchg_code_map_ar[cfg_.exchg_code_sym]);
	ret = api_->ReqQryOrder(&qry_param, 0);
	return ret;
}

int ctp_trader::QryTrade()
{
	int ret = 0;
	if (ready_ == false) {
		ret = -1;
		return ret;
	}
	CThostFtdcQryTradeField qry_param;
	memset(&qry_param, 0, sizeof(CThostFtdcQryTradeField));
	///经纪公司编号
	strncpy(qry_param.BrokerID, cfg_.brokerid, sizeof(TThostFtdcBrokerIDType));
	///交易所代码
	strncpy(qry_param.ExchangeID, exchg_code_map_ar[cfg_.exchg_code_sym], sizeof(TThostFtdcExchangeIDType));
	///投资者编号
	strncpy(qry_param.InvestorID, cfg_.account, sizeof(TThostFtdcInvestorIDType));

	printf("[INFO]: %s , %d , exchg_code: %s\n", __FUNCTION__, __LINE__, exchg_code_map_ar[cfg_.exchg_code_sym]);

	ret = api_->ReqQryTrade(&qry_param, 0);
	return ret;
}

void ctp_trader::OnFrontConnected()
{
	printf("OnFrontConnected\n");

	CThostFtdcReqUserLoginField login_data;
	memset(&login_data, 0, sizeof(CThostFtdcReqUserLoginField));
	strncpy(login_data.BrokerID, cfg_.brokerid, sizeof(TThostFtdcBrokerIDType));
	strncpy(login_data.UserID, cfg_.account, sizeof(TThostFtdcUserIDType));
	strncpy(login_data.Password, cfg_.password, sizeof(TThostFtdcPasswordType));

	printf(" broker_id: %s\n user_id: %s\n password: %s \n",
			login_data.BrokerID,
			login_data.UserID,
			login_data.Password);
	api_->ReqUserLogin(&login_data, 0);
}

void ctp_trader::OnRspUserLogin(CThostFtdcRspUserLoginField *pRspUserLogin, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{

	if (pRspInfo->ErrorID == 0) {
		ready_ = true;
	}else {
		printf("OnRspUserLogin, error_id: %d, error_msg: %s \n",
				pRspInfo->ErrorID, pRspInfo->ErrorMsg);
		exit(0);
	}
}

void ctp_trader::OnRspQryOrder(CThostFtdcOrderField *pOrder, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
#if 0
	if (pOrder) {
		printf("[OnRtnOrder]  Inv_ID: %s,symbol:%s ,Ref: %d, LocalID: %d, O_Sys_ID: %d, OrderStatus: %c,InsertTime:%s,VolumeTraded:%d,VolumeTotal:%d, Dir:%c, open_close:%c,price:%f ,vol:%d,Broker_Seq:%d \n",
				pOrder->InvestorID,
				pOrder->InstrumentID,
				atoi(pOrder->OrderRef),
				atoi(pOrder->OrderLocalID),
				atoi(pOrder->OrderSysID),
				pOrder->OrderStatus,
				pOrder->InsertTime,
				pOrder->VolumeTraded,
				pOrder->VolumeTotal,
				pOrder->Direction,
				pOrder->CombOffsetFlag[0],
				pOrder->LimitPrice,
				pOrder->VolumeTotalOriginal,
				pOrder->BrokerOrderSeq);
	}

#endif

	if (bIsLast) {
		manage_order_ar.rsp_finish_flag = 1;
		printf("OnRspQryOrder, bIsLast: %d, AccountID:%s \n", bIsLast, cfg_.account);
	}

	if (pRspInfo == NULL || pRspInfo->ErrorID == 0) {
		/* if not please new order */
		if (manage_order_ar.hold_cur_cnt >= manage_order_ar.max_order_cnt) {
			printf("[ERROR]: overflow %s, %d ,hold_cur_cnt:%d \n", __FUNCTION__, __LINE__, manage_order_ar.hold_cur_cnt);
			return ;
		}
		inner_order_info_t  *order_info;
		order_info = &manage_order_ar.hold_order[manage_order_ar.hold_cur_cnt];
		if (pOrder) {
			memcpy(order_info->account, pOrder->InvestorID, sizeof(pOrder->InvestorID));
			order_info->deal_vol = pOrder->VolumeTraded;
			order_info->dir = pOrder->Direction;
			order_info->exchg_entrust_no = atoi(pOrder->OrderSysID);
			order_info->org_vol = pOrder->VolumeTotalOriginal;
			memcpy(order_info->place_time, pOrder->InsertTime, sizeof(pOrder->InsertTime));
			order_info->open_close = pOrder->CombOffsetFlag[0];
			order_info->remain_vol = pOrder->VolumeTotal;
			order_info->status = pOrder->OrderStatus;
			order_info->price = pOrder->LimitPrice;
			memcpy(order_info->symbol, pOrder->InstrumentID, sizeof(pOrder->InstrumentID));
			manage_order_ar.hold_cur_cnt++;
		}
	}



}

void ctp_trader::OnRspQryTrade(CThostFtdcTradeField *pTrade, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{

#if 0
	if (pTrade) {
		printf("[OnRtnTrade] Inv_ID:%s ,Ref: %d, symbol:%s ,exhg_ID:%s,LocalID: %d,O_Sys_ID:%d,Dir:%c,open_close:%c, price:%f,deal_vol:%d, TradeTime:%s, TradeID:%s,Broker_Seq:%d \n",
				pTrade->InvestorID,
				atoi(pTrade->OrderRef),
				pTrade->InstrumentID,
				pTrade->ExchangeID,
				atoi(pTrade->OrderLocalID),
				atoi(pTrade->OrderSysID),
				pTrade->Direction,
				pTrade->OffsetFlag,
				pTrade->Price,
				pTrade->Volume,
				pTrade->TradeTime,
				pTrade->TradeID,
				pTrade->BrokerOrderSeq);
	}
#endif 

	inner_order_info_t  *order_info;
	if (bIsLast) {
		manage_order_ar.deal_finish_flag = 1;
		printf("OnRspQryTrade, bIsLast: %d , InvestorID:%s \n", bIsLast, cfg_.account);
	}

	if (pRspInfo == NULL || pRspInfo->ErrorID == 0) {
		order_info = &manage_order_ar.finish_order[manage_order_ar.finish_cur_cnt];
		if (manage_order_ar.finish_cur_cnt >= manage_order_ar.max_order_cnt) {
			printf("[ERROR]: %s, %d \n", __FUNCTION__, __LINE__);
			return ;
		}

		if (pTrade) {
			memcpy(order_info->account, pTrade->InvestorID, sizeof(pTrade->InvestorID));
			order_info->deal_vol = pTrade->Volume;
			order_info->dir = pTrade->Direction;
			order_info->price = pTrade->Price;
			order_info->exchg_entrust_no = atoi(pTrade->OrderSysID);
			order_info->exchg_deal_entrust_no = atoi(pTrade->TradeID);
			memcpy(order_info->fill_time, pTrade->TradeTime, sizeof(pTrade->TradeTime));
			order_info->open_close = pTrade->OffsetFlag;
			memcpy(order_info->symbol, pTrade->InstrumentID, sizeof(pTrade->InstrumentID));

			manage_order_ar.finish_cur_cnt++;
		}

	}

}

void ctp_trader::OnRspUserLogout(CThostFtdcUserLogoutField *pUserLogout, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	printf("OnRspUserLogout \n");
}

void ctp_trader::OnRspOrderInsert(CThostFtdcInputOrderField *pInputOrder, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	printf("[OnRspOrderInsert] ");
	if (pRspInfo) {
		printf("error_no: %d, error_msg: %s \n", pRspInfo->ErrorID, pRspInfo->ErrorMsg);
	}
	if (pInputOrder) {
		printf("OrderRef: %s, InvestorID: %s \n", pInputOrder->OrderRef, pInputOrder->InvestorID);
	}
}

void ctp_trader::OnRspOrderAction(CThostFtdcInputOrderActionField *pInputOrderAction, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	printf("[OnRspOrderAction] ");
	if (pRspInfo) {
		printf("error_no: %d, error_msg: %s \n", pRspInfo->ErrorID, pRspInfo->ErrorMsg);
	}
	if (pInputOrderAction) {
		printf("OrderActionRef: %s, OrderRef: %s, OrderSysID: %s \n",
				pInputOrderAction->OrderActionRef, pInputOrderAction->OrderRef, pInputOrderAction->OrderSysID);
	}
}

	int
ctp_trader::handle_order_rsp(CThostFtdcOrderField *pOrder)
{
	inner_order_info_t *order_info;
	int idx = 0;
	/* if not please new order */
	if (realtime_order_ar.rsp_cur_cnt >= realtime_order_ar.max_order_cnt) {
		printf("[ERROR]: overflow %s, %d ,hold_cur_cnt:%d, max_order_cnt:%d \n", __FUNCTION__, __LINE__, realtime_order_ar.rsp_cur_cnt,realtime_order_ar.max_order_cnt);
		realtime_order_ar.rsp_cur_cnt = 0;
		if (realtime_order_ar.max_order_cnt == 0) {
			printf("[ERROR]: memory not ready! \n");
			return -1;
		}
	}

	order_info = &realtime_order_ar.exchg_rsp_order[realtime_order_ar.rsp_cur_cnt];

	memcpy(order_info->account, pOrder->InvestorID, sizeof(pOrder->InvestorID));
	order_info->deal_vol = pOrder->VolumeTraded;
	order_info->dir = pOrder->Direction;
	order_info->exchg_entrust_no = atoi(pOrder->OrderSysID);
	order_info->org_vol = pOrder->VolumeTotalOriginal;
	memcpy(order_info->place_time, pOrder->InsertTime, sizeof(pOrder->InsertTime));
	order_info->open_close = pOrder->CombOffsetFlag[0];
	order_info->remain_vol = pOrder->VolumeTotal;
	order_info->status = pOrder->OrderStatus;
	order_info->price = pOrder->LimitPrice;
	memcpy(order_info->symbol, pOrder->InstrumentID, sizeof(pOrder->InstrumentID));
	realtime_order_ar.rsp_cur_cnt++;
	printf("[RSP_ORDER_INFO] : rsp_cur_cnt:%d , symbol:%s , exchg_enturst_no:%d \n",
			realtime_order_ar.rsp_cur_cnt,
			order_info->symbol,
			order_info->exchg_entrust_no);
	return 0;
}

void ctp_trader::OnRtnOrder(CThostFtdcOrderField *pOrder)
{
	//return;
	handle_order_rsp(pOrder);
#if 0
	if (pOrder) {
		printf("[OnRtnOrder]  Inv_ID: %s,symbol:%s ,Ref: %d, LocalID: %d, O_Sys_ID: %d, OrderStatus: %c,InsertTime:%s,VolumeTraded:%d,VolumeTotal:%d, Dir:%c, open_close:%c,price:%f ,vol:%d,Broker_Seq:%d \n",
				pOrder->InvestorID, 
				pOrder->InstrumentID,
				atoi(pOrder->OrderRef),
				atoi(pOrder->OrderLocalID),
				atoi(pOrder->OrderSysID),
				pOrder->OrderStatus,
				pOrder->InsertTime,
				pOrder->VolumeTraded,
				pOrder->VolumeTotal,
				pOrder->Direction,
				pOrder->CombOffsetFlag[0],
				pOrder->LimitPrice,
				pOrder->VolumeTotalOriginal,
				pOrder->BrokerOrderSeq);
	}
#endif 
}

	inner_order_info_t *
ctp_trader::query_order_info_details(unsigned int entrust_no)
{
	int idx = 0;
	for (idx = 0; idx < manage_order_ar.hold_cur_cnt; idx++) {
		if (manage_order_ar.hold_order[idx].exchg_entrust_no == entrust_no) {
			return (&manage_order_ar.hold_order[idx]);
		}
	}
	printf("[ERROR]: Didn't find entrust_no %s, %d \n", __FUNCTION__, __LINE__);
	return NULL;
}

	int
ctp_trader::handle_order_trade_return(CThostFtdcTradeField *pTrade)
{
	inner_order_info_t   *order_info;

	/* avoid memory overflow */
	if (realtime_order_ar.deal_cur_cnt >= realtime_order_ar.max_order_cnt) {
		realtime_order_ar.deal_cur_cnt = 0;
	}

	order_info = &realtime_order_ar.exchg_deal_order[realtime_order_ar.deal_cur_cnt];
	memcpy(order_info->account, pTrade->InvestorID, sizeof(pTrade->InvestorID));
	order_info->deal_vol = pTrade->Volume;
	order_info->dir = pTrade->Direction;
	order_info->price = pTrade->Price;
	order_info->exchg_deal_entrust_no = atoi(pTrade->TradeID);
	order_info->exchg_entrust_no = atoi(pTrade->OrderSysID);
	memcpy(order_info->fill_time, pTrade->TradeTime, sizeof(pTrade->TradeTime));
	order_info->open_close = pTrade->OffsetFlag;
	memcpy(order_info->symbol, pTrade->InstrumentID, sizeof(pTrade->InstrumentID));

	if (order_info->remain_vol){
		order_info->status = THOST_FTDC_OST_PartTradedQueueing;
	}
	else  {
		order_info->status = THOST_FTDC_OST_AllTraded;
	}

	realtime_order_ar.deal_cur_cnt++;
	printf("[FINISH_INFO]: finish_cnt: %d , symbol:%s,  entrust_no:%d \n", 
			realtime_order_ar.deal_cur_cnt,
			order_info->symbol,
			order_info->exchg_entrust_no);

	return 0;
}

void ctp_trader::OnRtnTrade(CThostFtdcTradeField *pTrade)
{
	//return;
	handle_order_trade_return(pTrade);
#if 0
	if (pTrade) {
		printf("[OnRtnTrade] Inv_ID:%s ,Ref: %d, symbol:%s ,exhg_ID:%s,LocalID: %d,O_Sys_ID:%d,Dir:%c,open_close:%c, price:%f,deal_vol:%d, TradeTime:%s, TradeID:%s,Broker_Seq:%d \n",
				pTrade->InvestorID,
				atoi(pTrade->OrderRef),
				pTrade->InstrumentID,
				pTrade->ExchangeID,
				atoi(pTrade->OrderLocalID),
				atoi(pTrade->OrderSysID),
				pTrade->Direction,
				pTrade->OffsetFlag,
				pTrade->Price,
				pTrade->Volume,
				pTrade->TradeTime,
				pTrade->TradeID,
				pTrade->BrokerOrderSeq);
	}
#endif
}


void ctp_trader::OnRspQryTradingAccount(CThostFtdcTradingAccountField *pTradingAccount, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{

	if (pRspInfo) {
		printf("error_no: %d, error_msg: %s \n", pRspInfo->ErrorID, pRspInfo->ErrorMsg);
		return;
	}

	if (bIsLast) {
		printf("OnRspQryTradingAccount, isLast: %d , account: %s \n", bIsLast, pTradingAccount->AccountID);
		manage_account_ar.finish_flag = 1;
	}

#if 0	
	if (pTradingAccount) {
		double total = pTradingAccount->PreBalance + pTradingAccount->CloseProfit + pTradingAccount->PositionProfit - pTradingAccount->Commission;
		printf("account:%s,PreBalance:%f,WithdrawQuota:%f,ExchangeMargin: %f, Commission: %f, CloseProfit: %f, PositionProfit: %f, Available: %f, PreDeposit: %f, FrozenCommission: %f, dynamic_interest: %f,  risk_degree:%f \n",
				pTradingAccount->AccountID,
				pTradingAccount->PreBalance,
				pTradingAccount->WithdrawQuota,
				pTradingAccount->ExchangeMargin,
				pTradingAccount->Commission,
				pTradingAccount->CloseProfit,
				pTradingAccount->PositionProfit,
				pTradingAccount->Available,
				pTradingAccount->PreDeposit,
				pTradingAccount->FrozenCommission,
				total,
				100 * ( pTradingAccount->ExchangeMargin) / total);
	}
#endif


	double dynamic = pTradingAccount->PreBalance + pTradingAccount->CloseProfit + pTradingAccount->PositionProfit - pTradingAccount->Commission;
	memcpy(manage_account_ar.p_account[0].account, pTradingAccount->AccountID, sizeof(pTradingAccount->AccountID));
	manage_account_ar.p_account[0].static_interest = pTradingAccount->PreBalance;
	manage_account_ar.p_account[0].fee = pTradingAccount->Commission;
	manage_account_ar.p_account[0].close_profit = pTradingAccount->CloseProfit;
	manage_account_ar.p_account[0].hold_profit = pTradingAccount->PositionProfit;
	manage_account_ar.p_account[0].dynamic_profit = dynamic;
	manage_account_ar.p_account[0].frozen_margin = pTradingAccount->ExchangeMargin;
	//manage_account_ar.p_account[0].place_frozen = ;
	manage_account_ar.p_account[0].fund_avail = pTradingAccount->Available;
	manage_account_ar.p_account[0].rate_degree = pTradingAccount->ExchangeMargin / dynamic;

}


	inner_position_info_t *
ctp_trader::lookup_avail_pos_addr(CThostFtdcInvestorPositionField *pInvestorPosition)
{
	int idx = 0;
	char *symbol = pInvestorPosition->InstrumentID;
	char dir = pInvestorPosition->PosiDirection;
	printf("[INFO]: %s, %d , tot_pos_cnt:%d \n", __FUNCTION__, __LINE__, manage_pos_ar.tot_pos_cnt);
	for (idx = 0; idx < manage_pos_ar.tot_pos_cnt; idx++) {

		if (*(unsigned long *)(manage_pos_ar.p_pos[idx].account) != 0 && !(strcmp(manage_pos_ar.p_pos[idx].symbol, symbol)) && (manage_pos_ar.p_pos[idx].dir == dir)) {
			printf("[INFO]: Have position ! \n");
			return (&manage_pos_ar.p_pos[idx]);
		}
		else if (*(unsigned long *)manage_pos_ar.p_pos[idx].account == 0) {
			manage_pos_ar.cur_pos_cnt++;
			return (&manage_pos_ar.p_pos[idx]);
		}
	}

	return NULL;
}


	void 
ctp_trader::set_symbol_with_strategy(int cnt, char *src)
{
	manage_strategy_ar.strategy_cnt = cnt;
	memcpy(manage_strategy_ar.strategy_info_ar, src, sizeof(symbol_strategy_info_t)*cnt);
}

	void 
ctp_trader::query_strategy_info()
{

}

	void 
ctp_trader::clear_flag_status()
{
	manage_pos_ar.finish_flag = 0;
	manage_pos_ar.cur_pos_cnt = 0;

	manage_account_ar.finish_flag = 0;

	manage_order_ar.deal_finish_flag = 0;
	manage_order_ar.finish_cur_cnt = 0;

	manage_order_ar.hold_cur_cnt = 0;
	manage_order_ar.rsp_finish_flag = 0;

}

	void
ctp_trader::handle_td_yd_pos(CThostFtdcInvestorPositionField *pInvestorPosition)
{

	inner_position_info_t *pos_ar = &manage_pos_ar.p_pos[manage_pos_ar.cur_pos_cnt];
	if (pos_ar == NULL)	{
		printf("[ERROR]:  %s , %d \n", __FUNCTION__, __LINE__);
		return;
	}

	/* Position = TodayPosition +  YdPosition */
	memcpy(pos_ar->account, pInvestorPosition->InvestorID, sizeof(pInvestorPosition->InvestorID));
	pos_ar->avg_price = pInvestorPosition->PositionCost / pInvestorPosition->Position;
	pos_ar->close_avail_pos = pInvestorPosition->YdPosition;
	pos_ar->dir = pInvestorPosition->PosiDirection;
	pos_ar->exchg;
	pos_ar->frozen_margin = pInvestorPosition->UseMargin;
	pos_ar->pos_profit_loss = pInvestorPosition->PositionProfit;
	memcpy(pos_ar->symbol, pInvestorPosition->InstrumentID, sizeof(pInvestorPosition->InstrumentID));
	pos_ar->td_pos = pInvestorPosition->TodayPosition;
	pos_ar->yd_pos = pInvestorPosition->YdPosition;
	pos_ar->tot_pos = pInvestorPosition->Position;
	manage_pos_ar.cur_pos_cnt++;
	printf("[QUERY_POS_OK] %s, %d, account:%s ,symbol:%s, cur_pos_cnt:%d \n", __FUNCTION__, __LINE__, pos_ar->account, pos_ar->symbol, manage_pos_ar.cur_pos_cnt);

}


void ctp_trader::OnRspQryInvestorPosition(CThostFtdcInvestorPositionField *pInvestorPosition, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	int ret = 0;
	if (pRspInfo) {
		printf("[ERROR]: error_no: %d, error_msg: %s \n", pRspInfo->ErrorID, pRspInfo->ErrorMsg);
		return ;
	}

	if (bIsLast) {
		manage_pos_ar.finish_flag = 1;
		printf("[INFO]: OnRspQryInvestorPosition bIsLast:%d, account:%s \n", bIsLast, cfg_.account);
	}

	inner_position_info_t  *avail_pos = NULL;
	if (pInvestorPosition == NULL) {
		return;
	}

#if 1
	/* it's means both TD AND YD POS */
	if (pInvestorPosition->YdPosition >= 0 && pInvestorPosition->Position > 0) {
		handle_td_yd_pos(pInvestorPosition);
	}
	else {
#if 0	
		printf("[BY_PASS_POS] account: %s, symbol:%s , dir:%c, YdPosition:%d , TodayPosition:%d, tot_pos:%d \n",
				pInvestorPosition->InvestorID,
				pInvestorPosition->InstrumentID,
				pInvestorPosition->PosiDirection,
				pInvestorPosition->YdPosition,
				pInvestorPosition->TodayPosition,
				pInvestorPosition->Position);
		/* bypass */
#endif
	}

#else		
	if (pInvestorPosition) {
		printf("\nInstrumentID: %s, "
				"PosiDirection: %c, "
				"HedgeFlag: %c, "
				"YdPosition: %d, "
				"Position: %d, "
				"LongFrozen: %d, "
				"ShortFrozen: %d, "
				"LongFrozenAmount: %f, "
				"ShortFrozenAmount: %f, "
				"OpenVolume: %d, "
				"CloseVolume: %d, "
				"OpenAmount: %f, "
				"CloseAmount: %f, "
				"PositionCost: %f, "
				"UseMargin: %f, "
				"FrozenMargin: %f, "
				"FrozenCash: %f, "
				"FrozenCommission: %f, "
				"CashIn: %f, "
				"Commission: %f, "
				"CloseProfit: %f, "
				"PositionProfit: %f, "
				"OpenCost: %f, \n"
				"ExchangeMargin: %f, "
				"CloseProfitByDate: %f, "
				"CloseProfitByTrade: %f, "
				"PositionProfit: %f, "
				"TodayPosition: %d, "
				"MarginRateByMoney: %f, "
				"MarginRateByVolume: %f, "
				"StrikeFrozenAmount: %f \n",
			pInvestorPosition->InstrumentID,
			pInvestorPosition->PosiDirection,
			pInvestorPosition->HedgeFlag,
			pInvestorPosition->YdPosition,
			pInvestorPosition->Position,
			pInvestorPosition->LongFrozen,
			pInvestorPosition->ShortFrozen,
			pInvestorPosition->LongFrozenAmount,
			pInvestorPosition->ShortFrozenAmount,
			pInvestorPosition->OpenVolume,
			pInvestorPosition->CloseVolume,
			pInvestorPosition->OpenAmount,
			pInvestorPosition->CloseAmount,
			pInvestorPosition->PositionCost,
			pInvestorPosition->UseMargin,
			pInvestorPosition->FrozenMargin,
			pInvestorPosition->FrozenCash,
			pInvestorPosition->FrozenCommission,
			pInvestorPosition->CashIn,
			pInvestorPosition->Commission,
			pInvestorPosition->CloseProfit,
			pInvestorPosition->PositionProfit,
			pInvestorPosition->OpenCost,
			pInvestorPosition->ExchangeMargin,
			pInvestorPosition->CloseProfitByDate,
			pInvestorPosition->CloseProfitByTrade,
			pInvestorPosition->PositionProfit,
			pInvestorPosition->TodayPosition,
			pInvestorPosition->MarginRateByMoney,
			pInvestorPosition->MarginRateByVolume,
			pInvestorPosition->StrikeFrozenAmount);
	}
#endif
}



	void
ctp_trader::OnRspQrySettlementInfo(CThostFtdcSettlementInfoField *pSettlementInfo, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	return ;
	//printf("OnRspQrySettlementInfo , isLast: %d \n", bIsLast);

	if (pRspInfo) {
		printf("[ERROR] : error_no: %d, error_msg: %s \n", pRspInfo->ErrorID, pRspInfo->ErrorMsg);
	}

#if 0
	printf("[OnRspQrySettlementInfo]: TradingDay:%s ,BrokerID:%s, InvestorID:%s , content:%s \n", 
			pSettlementInfo->TradingDay,
			pSettlementInfo->BrokerID,
			pSettlementInfo->InvestorID,
			pSettlementInfo->Content);
#else

	printf("[OnRspQrySettlementInfo]: TradingDay:%s ,BrokerID:%s, InvestorID:%s \n",
			pSettlementInfo->TradingDay,
			pSettlementInfo->BrokerID,
			pSettlementInfo->InvestorID);

#endif
}


	void
ctp_trader::OnRspQrySettlementInfoConfirm(CThostFtdcSettlementInfoConfirmField *pSettlementInfoConfirm, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	return ;

	//printf("OnRspQrySettlementInfoConfirm , isLast: %d \n", bIsLast);

	if (pRspInfo) {
		printf("[ERROR] : error_no: %d, error_msg: %s \n", pRspInfo->ErrorID, pRspInfo->ErrorMsg);
	}

	printf("[OnRspQrySettlementInfoConfirm]: BrokerID:%s, InvestorID:%s , ConfirmDate: %s , \n",
			pSettlementInfoConfirm->BrokerID,
			pSettlementInfoConfirm->InvestorID,
			pSettlementInfoConfirm->ConfirmDate,
			pSettlementInfoConfirm->ConfirmTime);
}


	void 
ctp_trader::clear_pos_flag_status()
{
	manage_pos_ar.finish_flag = 0;
	manage_pos_ar.cur_pos_cnt = 0;
}

	void
ctp_trader::clear_account_flag_status()
{
	manage_account_ar.finish_flag = 0;
}


	void
ctp_trader::clear_cur_order_flag_status()
{
	manage_order_ar.deal_finish_flag = 0;
	manage_order_ar.finish_cur_cnt = 0;

	manage_order_ar.hold_cur_cnt = 0;
	manage_order_ar.rsp_finish_flag = 0;
}


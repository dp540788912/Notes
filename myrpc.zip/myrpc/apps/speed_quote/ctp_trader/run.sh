#!/bin/sh

ulimit -c unlimited 

export LD_LIBRARY_PATH=./

./tt

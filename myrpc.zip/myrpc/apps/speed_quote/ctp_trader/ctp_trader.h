#ifndef CTP_TRADER_INNER_H
#define CTP_TRADER_INNER_H

#ifdef __cplusplus
extern "C"
{
#endif


#include "ThostFtdcTraderApi.h"
#include "ctp_common.h"

typedef struct manage_account_info
{
	inner_account_info_t 	*p_account;
	unsigned int 			account_cnt;
	unsigned int			finish_flag; /* finish_flag == 0 not finish, finsh_flag == 1 finish ok */
}manage_account_info_t;

typedef struct manage_pos_info
{
	unsigned int			tot_pos_cnt;
	unsigned int			cur_pos_cnt;
	unsigned int			finish_flag;/* finish_flag == 0 not finish, finsh_flag == 1 finish ok */
	inner_position_info_t	*p_pos;
}manage_pos_info_t;

typedef struct symbol_strategy_info
{
	char strategy_name[64];
		char symbol[32];
}symbol_strategy_info_t;

typedef struct  inner_manager_strategy{
	unsigned int			strategy_cnt;
		symbol_strategy_info_t	strategy_info_ar[32];
}inner_manager_strategy_t;

typedef struct order_item
{
	inner_order_info_t      order;
	struct list_head		list;
}order_item_t;

typedef struct inner_manager_order
{
	unsigned int			max_order_cnt;
	inner_order_info_t		*hold_order;
	unsigned int			hold_cur_cnt;
	inner_order_info_t		*finish_order;
	unsigned int			finish_cur_cnt;
	unsigned int			rsp_finish_flag;/* rsp_finish_flag == 0 not finish, rsp_finish_flag == 1 finish ok */
	unsigned int			deal_finish_flag;/* deal_finish_flag == 0 not finish, deal_finish_flag == 1 finish ok */
}inner_manager_order_t;


typedef struct  inner_manager_realtime_order{
	unsigned int			max_order_cnt;
	inner_order_info_t		*exchg_rsp_order;
	unsigned int			rsp_cur_cnt;
	inner_order_info_t		*exchg_deal_order;
	unsigned int			deal_cur_cnt;
	unsigned int			last_rsp_idx; 
	unsigned int			last_deal_idx;
}inner_manager_realtime_order_t;

class ctp_trader : public CThostFtdcTraderSpi
{
	public:
		ctp_trader(users_cfg_t &cfg);
		virtual ~ctp_trader();

		int Qry_settlement_info();
		int Qry_settlement_info_confirm();
		int QryFund();
		int QryPosition();
		int QryOrder();
		int QryTrade();

		int malloc_account_info_mem();
		void add_account_cnt(int account_cnt);
		int get_account_cnt();
		char *query_account_info();

		void set_symbol_with_strategy(int cnt, char *src);

		int malloc_pos_info_mem();
		unsigned int add_symbol_pos_cnt(int strategy_cnt);
		unsigned int get_symbol_pos_tot_cnt();
		unsigned int get_symbol_cur_pos_cnt();
		void clear_cur_pos_cnt();
		char *query_pos_info();
		void get_pos_info();
		void clear_flag_status();


		int get_history_order_finish_info(char *data);
		int get_history_order_hold_info(char *data);

		int get_realtime_order_deal_info(char *data);
		int get_realtime_order_rsp_info(char *data);

		void handle_td_yd_pos(CThostFtdcInvestorPositionField *pInvestorPosition);
		void handle_yd_pos(CThostFtdcInvestorPositionField *pInvestorPosition);
		inner_position_info_t * lookup_avail_pos_addr(CThostFtdcInvestorPositionField *pInvestorPosition);
		int check_sub_symbol(char *symbol);


		char * get_order_info_start_addr();
		int	 malloc_history_order_info();
		int  malloc_cur_order_info();
		int handle_order_rsp(CThostFtdcOrderField *pOrder);
		int handle_order_trade_return(CThostFtdcTradeField *pTrade);
		inner_order_info_t *query_order_info_details(unsigned int entrust_no);

		void clear_pos_flag_status();
		void clear_account_flag_status();
		void clear_cur_order_flag_status();

		void query_strategy_info();

		virtual void OnFrontConnected();
		virtual void OnRspUserLogin(CThostFtdcRspUserLoginField *pRspUserLogin, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
		virtual void OnRspQryOrder(CThostFtdcOrderField *pOrder, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
		virtual void OnRspQryTrade(CThostFtdcTradeField *pTrade, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
		virtual void OnRspUserLogout(CThostFtdcUserLogoutField *pUserLogout, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
		virtual void OnRspOrderInsert(CThostFtdcInputOrderField *pInputOrder, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
		virtual void OnRspOrderAction(CThostFtdcInputOrderActionField *pInputOrderAction, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
		virtual void OnRtnOrder(CThostFtdcOrderField *pOrder);
		virtual void OnRtnTrade(CThostFtdcTradeField *pTrade);
		virtual void OnRspQryTradingAccount(CThostFtdcTradingAccountField *pTradingAccount, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
		virtual void OnRspQryInvestorPosition(CThostFtdcInvestorPositionField *pInvestorPosition, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);

		virtual void OnRspQrySettlementInfo(CThostFtdcSettlementInfoField *pSettlementInfo,	CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
		virtual void OnRspQrySettlementInfoConfirm(CThostFtdcSettlementInfoConfirmField *pSettlementInfoConfirm, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
	private:
		users_cfg_t cfg_;
		CThostFtdcTraderApi *api_ = NULL;
		manage_account_info_t manage_account_ar;


		inner_manager_strategy_t  manage_strategy_ar;
		manage_pos_info_t manage_pos_ar;

		inner_manager_order_t manage_order_ar;
		inner_manager_realtime_order_t realtime_order_ar;
		bool ready_;
};


#ifdef __cplusplus
}
#endif

#endif

# encoding : utf-8

# Port where ctp quoter will forward quotes to. 
listen_port = 10008

config_file = 'accounts.json'
kdb_ip = '192.168.10.102'
kdb_port = 9000

KDB_USERNAME = "fR#cV%nL@cL=uR`bD(mM)lO/iD(fE#"
KDB_PASSWORD = "eB1*cC2&uK3#gL6@gD7^pS4#bH9^cG"

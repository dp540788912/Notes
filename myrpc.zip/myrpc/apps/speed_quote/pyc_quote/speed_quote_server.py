import json
import time

import signal
import config
import logging
import tornado.web
import tornado.httpserver
from qpython import qconnection
from functools import partial

import pyquote

MAX_WAIT_SECONDS_BEFORE_SHUTDOWN = 3


def get_data_from_kdb(sql):
    with qconnection.QConnection(config.kdb_ip, config.kdb_port, config.KDB_USERNAME, config.KDB_PASSWORD) as q:
        q.async(sql)
        return q.receive()


def load_config(ip, filepath):
    with open(filepath) as f:
        jsondata = json.load(f)

    kdb_info_query = [
        '.gw.asyncexec["select distinct Symbol from CzceDepth where date = last date";`FuturesCzce]',
        '.gw.asyncexec["select distinct Symbol from ShfeDepth where date = last date";`FuturesShfe]',
        '.gw.asyncexec["select distinct Symbol from DceDepth where date = last date";`FuturesDce]',
        '.gw.asyncexec["select distinct Symbol from cffexquote where date = last date";`FuturesCffex]'
    ]
    index = 0
    for sql in kdb_info_query:
        data = get_data_from_kdb(sql)
        data = [x[0].decode('utf-8') for x in data]
        # Do filtering on shfe will be harmless.
        filter_data = [x for x in data if len(x) < 7]
        # TODO: remove this dirty method
        if index == 3:
            index = 2
            jsondata['ctp_cfg_info_ar'][index][u'sub_ar'].extend(filter_data)
            jsondata['ctp_cfg_info_ar'][index][u'subcribe_cnt'] += len(filter_data)
        else:
            jsondata['ctp_cfg_info_ar'][index][u'sub_ar'] = filter_data
            jsondata['ctp_cfg_info_ar'][index][u'subcribe_cnt'] = len(filter_data)
        index += 1
    return json.dumps(jsondata)


class CtpQuoteQuery(tornado.web.RequestHandler):
    def get(self):
        try:
            res = pyquote.py_get_ctp_quote_info()
            dit = {
                'code': 0,
                'data': res
            }
        except Exception as e:
            dit = {
                'code': -1,
                'error': str(e)
            }
            # print(dit)
        result = json.dumps(dit)
        self.write(result)


class LastCtpQuoteQuery(tornado.web.RequestHandler):
    def get(self):
        try:
            res = pyquote.py_get_last_quote_info()
            dit = {
                'code': 0,
                'data': res
            }
        except Exception as e:
            dit = {
                'code': -1,
                'error': str(e)
            }
        self.write(json.dumps(dit))


def sig_handler(server, sig, frame):
    io_loop = tornado.ioloop.IOLoop.instance()

    def stop_loop(deadline):
        now = time.time()
        if now < deadline and (io_loop._callbacks or io_loop._timeouts):
            logging.info('waiting for next tick')
            io_loop.add_timeout(now + 1, stop_loop, deadline)
        else:
            io_loop.stop()
            logging.info('shutdown finally')

    def shutdown():
        logging.info('stopping http server')
        pyquote.on_shutdown()
        server.stop()
        logging.info('will shutdown in %s seconds ...', MAX_WAIT_SECONDS_BEFORE_SHUTDOWN)
        stop_loop(time.time() + MAX_WAIT_SECONDS_BEFORE_SHUTDOWN)

    logging.warning('caught signal: %s', sig)
    io_loop.add_callback_from_signal(shutdown)


if __name__ == "__main__":
    jjson = load_config(config.kdb_ip, config.config_file)
    pyquote.py_ctp_quote_init_by_json(jjson)
    pyquote.on_load()
    # Wait util login is finished.
    time.sleep(10)
    urls = [
        (r'/api/v1/speedquote/quote/ctp_lv1s', CtpQuoteQuery),
        (r'/api/v1/speedquote/quote/last_ctp', LastCtpQuoteQuery),
    ]
    app = tornado.web.Application(
        handlers=urls
    )
    http_server = tornado.httpserver.HTTPServer(app)
    http_server.listen(config.listen_port)
    signal.signal(signal.SIGINT, partial(sig_handler, http_server))
    signal.signal(signal.SIGTERM, partial(sig_handler, http_server))
    tornado.ioloop.IOLoop.instance().start()

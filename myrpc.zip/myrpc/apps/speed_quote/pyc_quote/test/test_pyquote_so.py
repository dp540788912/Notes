import pyquote 
import time

with open('config.json','r') as f:
    jjson =f.read()

#print(type(jjson))
print(pyquote.py_ctp_quote_init_by_json(jjson))
while True:
    time.sleep(5)
    #r= pyquote.py_get_ctp_quote_info()
    r= pyquote.py_get_last_quote_info()
    print(r)

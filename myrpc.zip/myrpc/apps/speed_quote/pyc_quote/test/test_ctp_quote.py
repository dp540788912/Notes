import requests
import json
#
#
#
#data = {
#        'name': 'test2',
#        'deploy_path': '/home/dev/test2',
#        'ip_addr': '192.168.1.2',
#        'port': 988888,
#        'valid': True,
#        'server_id': 1,
#        'config_template_id': 3,
#        'account_id': 2,
#
#        }
#
#url = 'http://192.168.3.27:18888/api/v1/shannon/common/pre_tunnel_confs/3'
#
##r = requests.get(url, headers=headers)
##r = requests.post(url, data=json.dumps(data), headers=headers)
#
#r = requests.delete(url, headers=headers)
##r = requests.put(url, data=json.dumps(data), headers=headers)
#
#print r.text

host='http://127.0.0.1:8000/api/v1'

def test_init():
    data = open('config.json','r')
    url_init='/speedquote/quote'
    r = requests.post(host+url_init,data=data)
    print(r.text)

def test_ctp_quote():
    url_ctp='/speedquote/quote/ctp_lv1s'
    r = requests.get(host+url_ctp)
    print(r.text)

def test_all_st():
    url='/speedquote/quote/strategy'
    r = requests.get(host+url)
    print(r.text)

def test_last_ctp():
    url_ctp='/speedquote/quote/last_ctp'
    r = requests.get(host+url_ctp)
    print(r.text)

test_last_ctp()
    

#test_init()
#test_ctp_quote()
#test_all_st()
#url='http://192.168.1.10:9000/speedquote/quote'
#print requests.post(url, data=data, headers=headers).text
#url='http://192.168.1.10:9000/speedquote/quote/ctp_lv1s'
#print requests.get(url,headers=headers).text




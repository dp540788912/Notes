# -*- coding: utf-8 -*-

host_events_handles = [
    {
        "key": "cpu.l1",
        "operator": ">",
        "threshold": 0.5,
        "alert_type": 2,
        "application": "cpu",
        "severity": "warn",
        "interval": 5,
        "desc": "前1分钟内系统负载",
        "key_cn": "前1分钟内系统负载"
    },
    {
        "key": "cpu.l5",
        "operator": ">",
        "threshold": 0.5,
        "alert_type": 2,
        "application": "cpu",
        "severity": "warn",
        "interval": 5,
        "desc": "前5分钟内系统负载",
        "key_cn": "前5分钟内系统负载"
    },
    {
        "key": "cpu.l15",
        "operator": ">",
        "threshold": 0.5,
        "alert_type": 2,
        "application": "cpu",
        "severity": "warn",
        "interval": 5,
        "desc": "前15分钟内系统负载",
        "key_cn": "前15分钟内系统负载"
    },
    {
        "key": "cpu.util",
        "operator": ">",
        "threshold": 50,
        "alert_type": 2,
        "application": "cpu",
        "severity": "warn",
        "interval": 5,
        "desc": "总的CPU使用率",
        "key_cn": "总的CPU使用率"

    },
    {
        "key": "ram.total",
        "operator": "=",
        "threshold": 0,
        "alert_type": 2,
        "application": "memory",
        "severity": "warn",
        "interval": 5,
        "desc": "内存总量，单位MB",
        "key_cn": "内存总量"
    },
    {
        "key": "ram.free",
        "operator": "<",
        "threshold": 2048,
        "alert_type": 5,
        "application": "memory",
        "severity": "warn",
        "interval": 1,
        "desc": "空闲内存总量，单位MB",
        "key_cn": "空闲内存总量"
    },
    {
        "key": "ram.util",
        "operator": ">",
        "threshold": 80,
        "alert_type": 2,
        "application": "memory",
        "severity": "warn",
        "interval": 5,
        "desc": "内存使用率，取值范围[0,100]",
        "key_cn": "内存使用率"
    },
    {
        "key": "swap.used",
        "operator": ">",
        "threshold": 2048,
        "alert_type": 2,
        "application": "swap",
        "severity": "warn",
        "interval": 5,
        "desc": "使用的SWAP总量，单位MB",
        "key_cn": "使用的SWAP总量"
    },
    {
        "key": "swap.util",
        "operator": ">",
        "threshold": 10,
        "alert_type": 2,
        "application": "swap",
        "severity": "warn",
        "interval": 5,
        "desc": "SWAP使用率，取值范围[0,100]",
        "key_cn": "SWAP使用率"
    },
    {
        "key": "disk./.free",
        "operator": "<",
        "threshold": 10000,
        "alert_type": 2,
        "application": "disk",
        "severity": "avg",
        "interval": 5,
        "desc": "空闲的/分区总量，单位MB",
        "key_cn": "空闲的/分区总量"
    },
    {
        "key": "disk./.util",
        "operator": ">",
        "threshold": 90,
        "alert_type": 2,
        "application": "disk",
        "severity": "avg",
        "interval": 5,
        "desc": "/分区使用率，取值范围[0,100]",
        "key_cn": "/分区使用率"
    },
    {
        "key": "disk./home.free",
        "operator": "<",
        "threshold": 50000,
        "alert_type": 2,
        "application": "disk",
        "severity": "avg",
        "interval": 5,
        "desc": "空闲的/home分区总量，单位MB",
        "key_cn": "空闲的/home分区总量"
    },
    {
        "key": "disk./home.util",
        "operator": ">",
        "threshold": 90,
        "alert_type": 2,
        "severity": "avg",
        "application": "disk",
        "interval": 5,
        "desc": "/home分区使用率，取值范围[0,100]",
        "key_cn": "/home分区使用率"
    },
    {
        "key": "disk./var.free",
        "operator": "<",
        "threshold": 10000,
        "alert_type": 2,
        "application": "disk",
        "severity": "avg",
        "interval": 5,
        "desc": "空闲的/var分区总量，单位MB",
        "key_cn": "空闲的/var分区总量"
    },
    {
        "key": "disk./var.util",
        "operator": ">",
        "threshold": 90,
        "alert_type": 2,
        "application": "disk",
        "severity": "avg",
        "interval": 5,
        "desc": "/var分区使用率，取值范围[0,100]",
        "key_cn": "/var分区使用率"
    },
    {
        "key": "dev.xele_nic",
        "operator": "=",
        "threshold": -1,
        "alert_type": 2,
        "application": "dev",
        "severity": "warn",
        "interval": 5,
        "desc": "xele卡状态, 0:正常 -1:异常",
        "key_cn": "xele卡状态"
    },
    {
        "key": "agent.conn",
        "operator": "=",
        "threshold": -2,
        "alert_type": 2,
        "application": "agent",
        "severity": "disaster",
        "interval": 1,
        "desc": "agent状态, 0:正常 -1:故障 -2:离线",
        "key_cn": "agent状态"
    },
    {
        "key": "clock.diff",
        "operator": ">",
        "threshold": 120,
        "alert_type": 2,
        "application": "clock",
        "severity": "high",
        "interval": 3,
        "desc": "交易服务器与BSS所在服务器的时差，单位秒",
        "key_cn": "时差"
    },
]

process_common_events_handles = [
    {
        "key": "process.run_status",
        "operator": "=",
        "threshold": -1,
        "alert_type": 2,
        "severity": "disaster",
        "application": "process",
        "interval": 1,
        "desc": "进程运行状态, -1:异常 0:正常",
        "key_cn": "进程运行"
    },
    {
        "key": "process.start_status",
        "operator": "=",
        "threshold": -1,
        "alert_type": 2,
        "application": "process",
        "severity": "disaster",
        "interval": 1,
        "desc": "进程启动状态, -1:异常 0:正常",
        "key_cn": "进程启动"
    },
    {
        "key": "1309",
        "operator": "=",
        "threshold": -1,
        "alert_type": 1,
        "application": "process",
        "severity": "high",
        "interval": 1,
        "desc": "香农自定义告警, agent上报的告警，-1:告警产生",
        "key_cn": "香农自定义告警"
     }
]

quote_process_events_handles = [
    {
        "key": "101",
        "operator": "=",
        "threshold": -1,
        "alert_type": 2,
        "application": "quote",
        "severity": "disaster",
        "interval": 1,
        "desc": "行情连接断开, agent上报的告警，-1:告警产生 0:告警恢复",
        "key_cn": "行情连接断开"
    },
    {
        "key": "102",
        "operator": "=",
        "threshold": -1,
        "alert_type": 2,
        "application": "quote",
        "severity": "disaster",
        "interval": 1,
        "desc": "行情数据中断, agent上报的告警，-1:告警产生 0:告警恢复",
        "key_cn": "行情数据中断"
    },
    {
        "key": "103",
        "operator": "=",
        "threshold": -1,
        "alert_type": 2,
        "application": "quote",
        "severity": "disaster",
        "interval": 1,
        "desc": "交易所行情断开, 行情转发服务上报的告警，-1:告警产生 0:告警恢复",
        "key_cn": "交易所行情断开"
    },
    {
        "key": "107",
        "operator": "=",
        "threshold": -1,
        "alert_type": 2,
        "application": "quote",
        "severity": "disaster",
        "interval": 1,
        "desc": "行情登陆失败, agent上报的告警，-1:告警产生 0:告警恢复",
        "key_cn": "行情登陆失败"
    },
]

tunnel_process_events_handles = [
    {
        "key": "201",
        "operator": "=",
        "threshold": -1,
        "alert_type": 2,
        "application": "tunnel",
        "severity": "disaster",
        "interval": 1,
        "desc": "通道连接断开, agent上报的告警，-1:告警产生 0:告警恢复",
        "key_cn": "通道连接断开"
    },
    {
        "key": "202",
        "operator": "=",
        "threshold": -1,
        "alert_type": 2,
        "application": "tunnel",
        "severity": "disaster",
        "interval": 1,
        "desc": "通道中断, agent上报的告警，-1:告警产生 0:告警恢复",
        "key_cn": "通道中断"
    },
{
        "key": "1301",
        "operator": "=",
        "threshold": -1,
        "alert_type": 1,
        "application": "compliance",
        "severity": "warn",
        "interval": 1,
        "desc": "自成交, agent上报的告警，-1:告警产生",
        "key_cn": "自成交"
    },
    {
        "key": "1302",
        "operator": "=",
        "threshold": -1,
        "alert_type": 1,
        "application": "compliance",
        "severity": "warn",
        "interval": 1,
        "desc": "开仓上限, agent上报的告警，-1:告警产生",
        "key_cn": "开仓上限"
    },
    {
        "key": "1303",
        "operator": "=",
        "threshold": -1,
        "alert_type": 1,
        "application": "compliance",
        "severity": "warn",
        "interval": 1,
        "desc": "撤单上限, agent上报的告警，-1:告警产生",
        "key_cn": "撤单上限"
    },
    {
        "key": "1304",
        "operator": "=",
        "threshold": -1,
        "alert_type": 1,
        "application": "compliance",
        "severity": "avg",
        "interval": 1,
        "desc": "报单被内部拒单,agent上报的告警， -1:告警产生",
        "key_cn": "内部拒单"
    },
    {
        "key": "1305",
        "operator": "=",
        "threshold": -1,
        "alert_type": 1,
        "application": "compliance",
        "severity": "high",
        "interval": 1,
        "desc": "报单被外部拒单, agent上报的告警，-1:告警产生",
        "key_cn": "外部拒单"
    },
    {
        "key": "1306",
        "operator": "=",
        "threshold": -1,
        "alert_type": 1,
        "application": "compliance",
        "severity": "high",
        "interval": 1,
        "desc": "报单被交易所拒单, agent上报的告警，-1:告警产生",
        "key_cn": "交易所拒单"
    },
    {
        "key": "1307",
        "operator": "=",
        "threshold": -1,
        "alert_type": 1,
        "application": "compliance",
        "severity": "warn",
        "interval": 1,
        "desc": "长时间未收到报单的成交回报, agent上报的告警，-1:告警产生",
        "key_cn": "长时间未收到报单的成交回报"
    },
    {
        "key": "1308",
        "operator": "=",
        "threshold": -1,
        "alert_type": 1,
        "application": "compliance",
        "severity": "high",
        "interval": 1,
        "desc": "提币失败, agent上报的告警，-1:告警产生",
        "key_cn": "提币"
     }
]

stra_process_events_handles = [
    {
        "key": "301",
        "operator": "=",
        "threshold": -1,
        "alert_type": 2,
        "application": "strategy",
        "severity": "disaster",
        "interval": 1,
        "desc": "策略进程向行情进程订阅失败, agent上报的告警，-1:告警产生 0:告警恢复",
        "key_cn": "策略订阅失败"
    },
    {
        "key": "302",
        "operator": "=",
        "threshold": -1,
        "alert_type": 2,
        "application": "strategy",
        "severity": "disaster",
        "interval": 1,
        "desc": "策略进程接收行情数据中断, agent上报的告警，-1:告警产生 0:告警恢复",
        "key_cn": "策略接收行情数据中断"
    },
    {
        "key": "303",
        "operator": "=",
        "threshold": -1,
        "alert_type": 2,
        "application": "strategy",
        "severity": "high",
        "interval": 1,
        "desc": "策略进程接收行情数据延迟, agent上报的告警，-1:告警产生 0:告警恢复",
        "key_cn": "策略接收行情数据延迟"
    },
]
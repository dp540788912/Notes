#-*- coding: utf-8 -*-

import re
import json
import urllib.request
import requests
import tornado.web
import datetime
from db import Session, session_context as mysql_sc
from models import *
from config import config
from default_complate import *
from utils import *
from mail import Notification
from kdb_query import kdb_contextMng as kdb_conn
 

class BaseHandler(tornado.web.RequestHandler):

    def initialize(self, *args, **kwargs):
        self.model = None
        self.fields = {}    # key: model-key, value: payload-key
        self.no_login = []

    def prepare(self, *args, **kwargs):
        if hasattr(self, 'no_login') and self.request.method.lower() in self.no_login:
            self.current_user = {}
            return
        if self.request.headers.get('whitelist'):
            self.current_user = {
                'id': 999999,
                'username': self.request.headers['whitelist'],
                'nickname': self.request.headers['whitelist'],
            }
        else:
            sessionid = self.get_cookie('sessionid')
            if not sessionid:
                self.write(json.dumps({
                    'code': 401,
                    'error': 'Sessionid not found.'
                }))
                self.finish()
                return
            cookies = {
                'sessionid': sessionid,
            }
            res = check_redis_session(config.redis, sessionid)
            if not res:
                self.write(json.dumps({
                    'code': 401,
                    'error': 'User not login.',
                }))
                self.finish()
                return
            self.current_user = res

    def get(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def post(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def put(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def delete(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))


class ListHandler(BaseHandler):

    def get(self, *args, **kwargs):
        res = []
        with mysql_sc() as sc:
            lines = sc.query(self.model).all()
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        #print('POST: payload = %s' % payload)

        if sorted(payload.keys()) != sorted(self.fields.values()):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return

        try:
            data = {}
            for k, v in self.fields.items():
                data[k] = payload[v]
            with mysql_sc() as sc:
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

class IDHandler(BaseHandler):

    def get(self, *args, **kwargs):
        with mysql_sc() as sc:
            o = sc.query(self.model).filter_by(id=kwargs['id']).first()
            if o:
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
            else:
                self.write(json.dumps({
                    'code': 404,
                    'error': 'Data not found.',
                }))

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    for k, v in self.fields.items():
                        if v in payload:
                            setattr(o, k, payload[v])
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                sc.query(self.model).filter_by(id=kwargs['id']).delete()
                self.write(json.dumps({
                    'code': 0,
                    'data': 'deleted'
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

class AlertHistoryListHandler(ListHandler):
    def get(self, *args, **kwargs):
        info = []
        hostip = self.get_argument('hostip', '')
        start_date = self.get_argument('startdate', '')
        end_date = self.get_argument('enddate', '')
        if (not hostip) or (not start_date) or (not end_date):
            self.write(json.dumps({
                'code': 400,
                'error': 'Request arguments error.',
            }))
            return
        next_end_date = datetime.datetime.strptime(end_date, '%Y-%m-%d') + datetime.timedelta(days=1)
        with mysql_sc() as sc:
            lines = sc.query(AlertHistory.clock.label('clock'),
                             EventHistory.msg.label('msg'),
                             EventHistory.status.label('status'),
                             EventHistory.processid.label('process_id'),
                             TriggerEventHandles.alert_type.label('alert_type'),
                             TriggerEventHandles.itemkey.label('alert_id'),
                             TriggerEventHandles.application.label('application'),
                             TriggerEventHandles.severity.label('severity'),
                             SeveritySetting.color.label('color')
                             ).join(EventHistory, EventHistory.id==AlertHistory.eventid
                                    ).join(TriggerEventHandles,TriggerEventHandles.id==EventHistory.objectid
                                           ).join(SeveritySetting, SeveritySetting.name==TriggerEventHandles.severity
                                                  ).filter(
                TriggerEventHandles.hostip==hostip,
                AlertHistory.clock>=start_date,
                AlertHistory.clock<=datetime.datetime.strftime(next_end_date, '%Y-%m-%d'),
            ).order_by(AlertHistory.id.desc())
            for line in lines:
                out_line = {}
                out_line['alert_id'] = line.alert_id
                out_line['process_id'] = line.process_id
                out_line['msg'] = line.msg
                out_line['severity'] = line.severity
                out_line['status'] = line.status
                out_line['category'] = line.application
                out_line['alert_type'] = line.alert_type
                out_line['color'] = line.color
                out_line['clock'] = str(line.clock)
                #print(out_line)
                info.append(out_line)
        self.write(json.dumps({
            'code': 0,
            'data': {
                'type': 'shannon_detail',
                'category': 'alert_history',
                'info': info,
            }
        }))

    def post(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def put(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def delete(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))


class SeveritySettingListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = SeveritySetting
        self.post_fields = {
            'name': 'name',
            'color': 'color',
            'wx': 'wx',
            'email': 'email',
            'sms': 'sms',
            'notify_users': 'notify_users',
            'ring_type': 'ring_type'
        }
        self.fields = {
            'id': 'id',
            'name': 'name',
            'color': 'color',
            'wx': 'wx',
            'email': 'email',
            'sms': 'sms',
            'notify_users': 'notify_users',
            'ring_type': 'ring_type'
        }

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        logger.debug('POST: payload = %s' % payload)

        if sorted(payload[0].keys()) != sorted(self.post_fields.values()):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return

        try:
            with mysql_sc() as sc:
                out_data = []
                for record in payload:
                    data = {}
                    for k, v in self.post_fields.items():
                        data[k] = record[v]
                    o = self.model(**data)
                    sc.add(o)
                    out_data.append(o.to_dict())
                sc.commit()
                notify_monitor_module("severity")
                self.write(json.dumps({
                    'code': 0,
                    'data': out_data,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        logger.debug('PUT: payload = %s' % payload)

        if sorted(payload[0].keys()) != sorted(self.fields.values()):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return

        try:
            with mysql_sc() as sc:
                out_data = []
                for record in payload:
                    o = sc.query(self.model).filter_by(id=record['id']).first()
                    if o:
                        for k, v in self.fields.items():
                            if v in record and v != 'id':
                                setattr(o, k, record[v])
                        out_data.append(o.to_dict())
                sc.commit()
                notify_monitor_module("severity")
                self.write(json.dumps({
                    'code': 0,
                    'data': out_data,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return

        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                for item_id in payload:
                    sc.query(self.model).filter_by(id=item_id).delete()
                sc.commit()
                notify_monitor_module("severity")
                self.write(json.dumps({
                    'code': 0
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

class SeveritySettingIDHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = SeveritySetting
        self.fields = {
            'name': 'name',
            'color': 'color',
            'wx': 'wx',
            'email': 'email',
            'sms': 'sms',
            'notify_users': 'notify_users',
            'ring_type': 'ring_type'
        }

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    for k, v in self.fields.items():
                        if v in payload:
                            setattr(o, k, payload[v])
                sc.commit()
                notify_monitor_module("severity")
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                sc.query(self.model).filter_by(id=kwargs['id']).delete()
                notify_monitor_module("severity")
                self.write(json.dumps({
                    'code': 0,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class DeployModelRegHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.fields = {
            'itemkey_cn': 'key_cn',
            'operator': 'operator',
            'threshold': 'threshold',
            'severity': 'severity',
            'interval': 'interval',
            'alert_type': 'alert_type',
            'application': 'application',
            'description': 'desc',
            'monitor_time': 'monitor_time'
        }

    def is_update_alert_define(self, old, new):
        is_changed = False
        for k, v in self.fields.items():
            if v == 'monitor_time' and v not in new.keys():
                continue
            if getattr(old, k) != new[v]:
                setattr(old, k, new[v])
                is_changed = True
        return is_changed

    def add_process_event_handle(self, hostip, processid):
        with mysql_sc() as sc:
            try:
                self.add_process_alert_define(sc, process_common_events_handles, hostip, processid)

                shannon_host = sc.query(ShannonServers).filter_by(ip=hostip).first()
                if shannon_host:
                    process_type = sc.query(
                        ProgramTypes.name,
                        DeployConfs.vstrategy_id
                    ).join(
                        DeployConfs, DeployConfs.program_type_id == ProgramTypes.id
                    ).filter(
                        DeployConfs.id == processid
                    ).first()
                    if process_type:
                        if process_type.name in ['shannon_quote', 'platform_quote_server', 'shannon_bit_forward']:
                            self.add_process_alert_define(sc, quote_process_events_handles, hostip, processid)
                        elif process_type.name in ['shannon_tunnel', 'shannon_bit_tunnel']:
                            self.add_process_alert_define(sc, tunnel_process_events_handles, hostip, processid)
                        elif process_type.name == 'shannon_trader':
                            vid = process_type.vstrategy_id
                            self.add_process_alert_define(sc, stra_process_events_handles, hostip, processid, vid)
                else:
                    turing_host = sc.query(TuringServers).filter_by(ip=hostip).first()
                    if turing_host:
                        turing_process_type = sc.query(
                            TuringProgramTypes.name,
                        ).join(
                            TuringPrograms, TuringPrograms.type_id == TuringProgramTypes.id
                        ).join(
                            TuringDeployConfs, TuringDeployConfs.program_id == TuringPrograms.id
                        ).filter(
                            TuringDeployConfs.id == processid
                        ).first()
                        if turing_process_type:
                            if turing_process_type.name == 'platform_quote_server' or turing_process_type.name.startswith('quote'):
                                self.add_process_alert_define(sc, quote_process_events_handles, hostip, processid)
                            elif turing_process_type.name.startswith('turing') or turing_process_type.name.startswith('galileo'):
                                self.add_process_alert_define(sc, quote_process_events_handles, hostip, processid)
                                self.add_process_alert_define(sc, tunnel_process_events_handles, hostip, processid)
                                self.add_process_alert_define(sc, stra_process_events_handles, hostip, processid)
                    else:
                        logger.error('Cannot judge host type of %s, so cannot add alert defines of process %d !', hostip, processid)
                sc.commit()
                return True

            except Exception as e:
                import traceback
                traceback.print_exc()
                #logger.error(str(e))
                return False


    def union_exchg_monitor_times(self, process_monitor_times, monitor_time_str):
        '''
        :param process_monitor_times: [{'start': datetime.time(9, 0), 'end': datetime.time(10, 15)}]
        :param monitor_time_str: '9:00-10:15,10:30-11:30'
        :return: [{'start': datetime.time(9, 0), 'end': datetime.time(10, 15)}, {'start': datetime.time(10, 30), 'end': datetime.time(11, 30)}]
        '''
        monitor_time_list = monitor_time_str.split(',')
        for time_slice_str in monitor_time_list:
            time_slice_obj = time_slice_str2obj(time_slice_str)
            is_joined = False
            for idx, value in enumerate(process_monitor_times):
                join_time = time_slice_union(value, time_slice_obj)
                if join_time:
                    process_monitor_times[idx] = join_time
                    is_joined = True
            if not is_joined:
                process_monitor_times.append(time_slice_obj)
        return process_monitor_times

    def intersect_exchg_monitor_times(self, time_list1, time_list2):
        time_list = []
        for t1 in time_list1:
            tmp = []
            for t2 in time_list2:
                t = time_slice_intersect(t1, t2)
                if t:
                    tmp.append(t)
            if tmp:
                time_list.extend(tmp)
        return time_list

    def add_process_alert_define(self, sc, handles, hostip, processid, vstrategy_id=None):
        for eh in handles:
            process_monitor_times_str = ''
            if eh['key'] == '303' and vstrategy_id:
                symbols_accounts = sc.query(VStrategies.symbols_accounts).filter_by(id=vstrategy_id).first()
                exchg_symbols = {}
                for item in symbols_accounts.symbols_accounts['day']:
                    if item['exchange'] not in exchg_symbols.keys():
                        exchg_symbols[item['exchange']] = []
                    if item['product'] not in exchg_symbols[item['exchange']]:
                        exchg_symbols[item['exchange']].append(item['product'])
                for item in symbols_accounts.symbols_accounts['night']:
                    if item['exchange'] not in exchg_symbols.keys():
                        exchg_symbols[item['exchange']] = []
                    if item['product'] not in exchg_symbols[item['exchange']]:
                        exchg_symbols[item['exchange']].append(item['product'])
                logger.info('exchange and symbols: {}'.format(exchg_symbols))
                exchg_monitor_time = {}
                for exchg, contracts in exchg_symbols.items():
                    exchg_monitor_time[exchg] = []
                    contract_monitor_times = sc.query(OPSExchgProductMonitorTime).filter(
                        OPSExchgProductMonitorTime.exchange == exchg,
                        OPSExchgProductMonitorTime.product.in_(contracts)
                    ).all()
                    # 同一交易所求监控时间的并集
                    for item in contract_monitor_times:
                        logger.info('{}, {}, {}'.format(item.exchange, item.product, item.monitor_time))
                        exchg_monitor_time[exchg] = self.union_exchg_monitor_times(exchg_monitor_time[exchg], item.monitor_time)
                    if not exchg_monitor_time[exchg]:
                        from datetime import time as ttime
                        exchg_monitor_time[exchg] = [{'start': ttime(0, 0), 'end': ttime(23, 59)}]
                logger.info('exchange monitor time: {}'.format(exchg_monitor_time))

                # 不同交易所求监控时间的交集
                from datetime import time as ttime
                process_monitor_times = [{'start': ttime(0, 0), 'end': ttime(23, 59)}]
                for exchg, t in exchg_monitor_time.items():
                    process_monitor_times = self.intersect_exchg_monitor_times(process_monitor_times, t)
                logger.info('process monitor time obj: {}'.format(process_monitor_times))
                process_monitor_times_str = ','.join([time_slice_obj2str12h(t) for t in process_monitor_times])
            logger.info('process monitor times str: {}'.format(process_monitor_times_str))

            processkey = eh['key'] + '.' + str(processid)
            q = sc.query(TriggerEventHandles).filter_by(
                hostip=hostip,
                itemkey=processkey
            ).first()
            if q:
                eh['monitor_time'] = process_monitor_times_str
                if self.is_update_alert_define(q, eh):
                    sc.commit()
                    logger.info("Update alert: %s." % q.to_dict())
                continue

            teh = TriggerEventHandles(
                hostip=hostip,
                itemkey=processkey,
                itemkey_cn=eh['key_cn'],
                operator=eh['operator'],
                threshold=eh['threshold'],
                severity=eh['severity'],
                interval=eh['interval'],
                alert_type=eh['alert_type'],
                application=eh['application'],
                description=eh['desc'],
                users=[],
                monitor_time=process_monitor_times_str,
                enabled=True,
            )
            sc.add(teh)
            sc.flush()
            logger.info("Add alert: %s." % teh.to_dict())

    def add_host_event_handle(self, hostip):
        with mysql_sc() as sc:
            try:
                for eh in host_events_handles:
                    q = sc.query(TriggerEventHandles).filter_by(
                        hostip=hostip,
                        itemkey=eh['key'],
                        operator=eh['operator'],
                        threshold=eh['threshold']
                    ).first()
                    if q:
                        if self.is_update_alert_define(q, eh):
                            sc.commit()
                            logger.info("Update alert: %s." % q.to_dict())
                        continue

                    teh = TriggerEventHandles(
                        hostip=hostip,
                        itemkey=eh['key'],
                        itemkey_cn=eh['key_cn'],
                        operator=eh['operator'],
                        threshold=eh['threshold'],
                        severity=eh['severity'],
                        interval=eh['interval'],
                        alert_type=eh['alert_type'],
                        application=eh['application'],
                        description=eh['desc'],
                        users=[],
                        monitor_time='',
                        enabled=True,
                    )
                    sc.add(teh)
                    sc.commit()
                    logger.info("Add alert: %s." % teh.to_dict())

                notify_monitor_module("host")
                return True

            except Exception as e:
                logger.error(str(e))
                return False


    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return

        ret = False
        try:
            payload = json.loads(str(self.request.body, 'utf-8'))
            logger.info("payload = %s" % payload)
            if "host" == payload['type']:
                host_ip = payload['host']
                ret = self.add_host_event_handle(host_ip)
            elif "process" == payload['type']:
                host_ip = payload['host']
                process_id = payload['process_id']
                ret = self.add_process_event_handle(host_ip,process_id)
            else:
                self.write(json.dumps({
                    'code': 400,
                    'data': 'Request arguments error.',
                }))
                return

            if ret == True:
                notify_monitor_module("alert")
                self.write(json.dumps({
                    'code': 0,
                    'data': 'Success',
                }))
            elif ret == False:
                self.write(json.dumps({
                    'code': 500,
                    'error': 'server error.',
                }))
            return
            pass
        except:
            import traceback
            traceback.print_exc()


class CustomAlertListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = TriggerEventHandles
        self.fields = {
            'hostip': 'host',
            'itemkey': 'key',
            'itemkey_cn': 'key_cn',
            'operator': 'operator',
            'threshold': 'threshold',
            'application': 'category',
            'severity': 'severity',
            'interval': 'interval',
            'alert_type': 'alert_type',
            'description': 'desc',
            'msg': 'msg',
            'recovery_msg': 'recovery_msg',
            'users': 'notify_users',
            'monitor_time': 'monitor_time',
            'enabled': 'enabled'
        }

    def get(self, *args, **kwargs):
        res = []
        host = self.get_argument('host', '')
        with mysql_sc() as sc:
            try:
                if host:
                    lines = sc.query(TriggerEventHandles).filter_by(hostip=host)
                else:
                    lines = sc.query(TriggerEventHandles).all()

                for line in lines:
                    res.append(line.to_dict())

                self.write(json.dumps({
                    'code': 0,
                    'data': res
                }))
            except Exception as e:
                logger.error(str(e))
                self.write(json.dumps({
                    'code': 500,
                    'error': str(e),
                }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        logger.debug('POST: payload = %s' % payload)

        if sorted(payload.keys()) != sorted(self.fields.values()):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return

        try:
            data = {}
            for k, v in self.fields.items():
                data[k] = payload[v]
            with mysql_sc() as sc:
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))

            notify_monitor_module("alert")
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

class CustomAlertIDHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = TriggerEventHandles
        self.fields = {
            'hostip': 'host',
            'itemkey': 'key',
            'itemkey_cn': 'key_cn',
            'operator': 'operator',
            'threshold': 'threshold',
            'application': 'category',
            'severity': 'severity',
            'interval': 'interval',
            'alert_type': 'alert_type',
            'description': 'desc',
            'msg': 'msg',
            'recovery_msg': 'recovery_msg',
            'users': 'notify_users',
            'monitor_time': 'monitor_time',
            'enabled': 'enabled'
        }

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    for k, v in self.fields.items():
                        if v in payload:
                            setattr(o, k, payload[v])
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))

            notify_monitor_module("alert")
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                sc.query(self.model).filter_by(id=kwargs['id']).delete()
                self.write(json.dumps({
                    'code': 0,
                }))

            notify_monitor_module("alert")
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class CustomAlertBatchSettingHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = TriggerEventHandles
        self.post_fields = {
            'hostip': 'host',
            'itemkey': 'key',
            'itemkey_cn': 'key_cn',
            'operator': 'operator',
            'threshold': 'threshold',
            'application': 'category',
            'severity': 'severity',
            'interval': 'interval',
            'alert_type': 'alert_type',
            'description': 'desc',
            'msg': 'msg',
            'recovery_msg': 'recovery_msg',
            'users': 'notify_users',
            'monitor_time': 'monitor_time',
            'enabled': 'enabled'
        }
        self.fields = {
            'id': 'id',
            'hostip': 'host',
            'itemkey': 'key',
            'itemkey_cn': 'key_cn',
            'operator': 'operator',
            'threshold': 'threshold',
            'application': 'category',
            'severity': 'severity',
            'interval': 'interval',
            'alert_type': 'alert_type',
            'description': 'desc',
            'msg': 'msg',
            'recovery_msg': 'recovery_msg',
            'users': 'notify_users',
            'monitor_time': 'monitor_time',
            'enabled': 'enabled'
        }

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        logger.debug('POST: payload = %s' % payload)

        if sorted(payload[0].keys()) != sorted(self.post_fields.values()):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return

        try:
            with mysql_sc() as sc:
                out_data = []
                for record in payload:
                    data = {}
                    for k, v in self.post_fields.items():
                        data[k] = record[v]
                    o = self.model(**data)
                    sc.add(o)
                    out_data.append(o.to_dict())
                sc.commit()
                notify_monitor_module("alert")
                self.write(json.dumps({
                    'code': 0,
                    'data': out_data,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def get(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def delete(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return

        payload = json.loads(str(self.request.body, 'utf-8'))
        logger.debug('DELETE: payload = %s' % payload)
        try:
            with mysql_sc() as sc:
                for item_id in payload:
                    sc.query(self.model).filter_by(id=item_id).delete()
                sc.commit()
                notify_monitor_module("alert")
                self.write(json.dumps({
                    'code': 0
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return

        payload = json.loads(str(self.request.body, 'utf-8'))
        logger.debug('PUT: payload = %s' % payload)
        if sorted(payload[0].keys()) != sorted(self.fields.values()):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return

        try:
            with mysql_sc() as sc:
                out_data = []
                for item in payload:
                    o = sc.query(self.model).filter_by(id=item['id']).first()
                    if o:
                        for k, v in self.fields.items():
                            if v in item and v != 'id':
                                setattr(o, k, item[v])
                        out_data.append(o.to_dict())
                sc.commit()
                notify_monitor_module("alert")
                self.write(json.dumps({
                    'code': 0,
                    'data': out_data,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class TriggerEventListHandler(ListHandler, Notification):

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return

        try:
            payload = json.loads(str(self.request.body, 'utf-8'))
            ret = self.process_trigger_event(payload)
            if ret == 0:
                self.write(json.dumps({
                    'code': 0,
                    'data': payload
                }))
            else:
                self.write(json.dumps({
                    'code': ret,
                    'error': 'No found the alert define.',
                }))

        except Exception as e:
            logger.error('%s. Payload: %s' % (str(e), self.request.body))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def process_trigger_event(self, data):
        teh = TriggerEventHandles.get_define(data['host'], data['key'], data['operator'], data['threshold'])
        if teh is None:
            logger.error("Not found define of %s %s %s on %s" % (data['key'], data['operator'], data['threshold'], data['host']))
            return 1404

        if len(re.findall('start_status', data['key'])) == 0:
            ret, gst = is_send_alert(teh['id'], teh['interval'], teh['severity'], data['process_id'], data['status'])
        else:
            ret = 1
            gst = SeveritySetting.get_notify_users(teh['severity'])

        clock = datetime.datetime.strptime(data['clock'], '%Y-%m-%d %H:%M:%S.%f')
        isalert = 1 if ret == 1 else 0
        event = EventHistory.save(1, teh['id'], data['process_id'], data['status'], data['msg'], clock, isalert)

        if ret == 0 or ret == 404:
            return ret

        """alert"""
        subject = ""
        if data['status'] == -1:
            subject = "%s%s异常" % (data['host'], teh['key_cn'])
        elif data['status'] == 0:
            subject = "%s%s恢复" % (data['host'], teh['key_cn'])

        AlertHistory.save(event['id'], subject, clock)

        ret, email_list, wx_list, mobile_num_list, svr_type = get_notify_users(gst['notify_users'], teh['notify_users'], teh['host'])
        logger.debug("ret=%d, email_list=%s, wx_list=%s, mobile_num_list=%s" % (ret, email_list, wx_list, mobile_num_list))
        if AlertFilterRegularMng().is_filter_alert(data['msg']):
            logger.info('Alert was filtered. %s', data['msg'])
            return ret

        if 0 == ret:
            self.send_alert(email_list, wx_list, mobile_num_list, subject, data['msg'], gst, data['status'], svr_type)
        return ret

class BulkTriggerEventListHandler(ListHandler, Notification):

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return

        try:
            payload = json.loads(str(self.request.body, 'utf-8'))
            ret = self.process_bulk_trigger_event(payload)
            if ret == 0:
                self.write(json.dumps({
                    'code': 0,
                    'data': payload
                }))
            else:
                self.write(json.dumps({
                    'code': ret,
                    'error': 'No found.',
                }))

        except Exception as e:
            logger.error('%s. Payload: %s' % (str(e), self.request.body))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def process_bulk_trigger_event(self, bulk_events):
        eg = self.events_group(bulk_events)

        with mysql_sc() as sc:
            for event_arr in eg:
                self.process_trigger_event_group(event_arr, sc)

        return 0

    def process_trigger_event_group(self, event_arr, sc):
        logger.debug("process trigger event group: %s" % event_arr)
        first_event = event_arr[0]
        teh = TriggerEventHandles.get_define(first_event['host'], first_event['key'], first_event['operator'], first_event['threshold'])
        if teh is None:
            logger.error("Not found define of %s %s %s on host %s" % (first_event['key'], first_event['operator'], first_event['threshold'], first_event['host']))
            return 404

        if len(re.findall('start_status', first_event['key'])) == 0:
            ret, gst = is_send_alert(teh['id'], teh['interval'], teh['severity'], first_event['process_id'], first_event['status'])
        else:
            ret = 1
            gst = SeveritySetting.get_notify_users(teh['severity'])

        isalert = 1 if ret == 1 else 0
        for i in range(len(event_arr)):
            clock = datetime.datetime.strptime(event_arr[i]['clock'], '%Y-%m-%d %H:%M:%S.%f')
            event = EventHistory.save(1, teh['id'], event_arr[i]['process_id'], event_arr[i]['status'], event_arr[i]['msg'], clock, isalert)
            eventid = event['id']

        if ret == 0 or ret == 404:
            return ret

        """alert"""
        subject = ""
        if first_event['status'] == -1:
            subject = "%s%s异常" % (first_event['host'], teh['key_cn'])
        elif first_event['status'] == 0:
            subject = "%s%s恢复" % (first_event['host'], teh['key_cn'])

        AlertHistory.save(eventid, subject, clock)

        ret, email_list, wx_list, mobile_num_list, svr_type = get_notify_users(gst['notify_users'], teh['notify_users'], teh['host'])
        logger.debug("ret=%d, email_list=%s, wx_list=%s, mobile_num_list=%s" % (ret, email_list, wx_list, mobile_num_list))
        if AlertFilterRegularMng().is_filter_alert(first_event['msg']):
            logger.info('Alert was filtered. %s', first_event['msg'])
            return ret

        if 0 == ret:
            self.send_alert(email_list, wx_list, mobile_num_list, subject, first_event['msg'], gst, first_event['status'], svr_type)
        return ret

    def events_group(self, bulk_events):
        g1 = {}
        g2 = []
        for event in bulk_events:
            k = "%s_%s_%s%s%s" % (event['host'], event['process_id'], event['key'], event['operator'], event['threshold'])
            if k not in g1.keys():
                g1[k] = []
            g1[k].append(event)

        for k, v in g1.items():
            tmp = []
            for e in v:
                if e['status'] == 0:
                    if tmp:
                        g2.append(tmp)
                        g2.append([e])
                        tmp = []
                    else:
                        g2.append([e])
                else:
                    tmp.append(e)
            if tmp:
                g2.append(tmp)

        return g2


class BussinessEventHandleListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = BusinessEventHandles
        self.fields = {
            'event_key': 'event_key',
            'dep': 'dep',
            'action_type': 'action_type',
            'notify_users': 'notify_users',
            'msg': 'msg',
            'description': 'desc',
            'interval': 'interval',
            'enabled': 'enabled',
        }

    def get(self, *args, **kwargs):
        res = []
        dep = self.get_argument('dep', '')
        with mysql_sc() as sc:
            try:
                if dep:
                    lines = sc.query(self.model).filter_by(dep=dep)
                else:
                    lines = sc.query(self.model).all()

                for line in lines:
                    res.append(line.to_dict())

                self.write(json.dumps({
                    'code': 0,
                    'data': res
                }))
            except Exception as e:
                logger.error(str(e))
                self.write(json.dumps({
                    'code': 500,
                    'error': str(e),
                }))


    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if 'event_key' not in payload.keys() or 'dep' not in payload.keys():
            self.write(json.dumps({
                'code': 400,
                'error': "No event_key or dep",
            }))
            return

        try:
            with mysql_sc() as sc:
                o = sc.query(self.model).filter_by(event_key=payload['event_key'], dep=payload['dep']).first()
                if o:
                    for k, v in self.fields.items():
                        if v in payload:
                            setattr(o, k, payload[v])

                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

class BussinessEventListHandler(ListHandler, Notification):

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return

        try:
            payload = json.loads(str(self.request.body, 'utf-8'))
            ret = self.process_business_event(payload)
            if ret == 0:
                self.write(json.dumps({
                    'code': 0,
                    'data': payload
                }))
            elif ret == 404:
                self.write(json.dumps({
                    'code': 404,
                    'error': 'No found.',
                }))

        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def is_send_notifying(self, id, interval, sc):
        ret = 0
        history = sc.query(EventHistory).filter(
            EventHistory.eventtype == 2,
            EventHistory.objectid == id,
            EventHistory.isalert == 1,  # 1:send alarm 0:no alarm
            EventHistory.r_create_time >= (datetime.datetime.now() - datetime.timedelta(minutes=interval)),
        ).order_by(EventHistory.id.desc()).first()
        if history:
            logger.info("Event %d occurred. It had alerted over last %d minutes, so no repeat." % (id, interval))
        else:
            ret = 1

        return ret

    def process_business_event(self, data):
        with mysql_sc() as sc:
            eh = sc.query(BusinessEventHandles).filter_by(
                event_key=data['event_key'],
                dep=data['dep'],
            ).first()
            if not eh:
                logger.error("Not found define of %s %s" % (data['dep'],data['event_key']))
                return 404

            ret = self.is_send_notifying(eh.id, eh.interval, sc)
            event = EventHistory(
                eventtype=2,
                objectid=eh.id,
                processid=-1,
                status=-1,
                msg="%s.%s" % (eh.dep, eh.event_key),
                clock=datetime.datetime.strptime(data['clock'], '%Y-%m-%d %H:%M:%S.%f'),
                isalert=(1 if ret == 1 else 0),
                r_create_time=datetime.datetime.now()
            )
            sc.add(event)
            sc.commit()
            if ret == 0:
                return ret

            """alert"""
            subject = eh.msg
            clock = datetime.datetime.strptime(data['clock'], '%Y-%m-%d %H:%M:%S.%f')
            alert = AlertHistory(
                eventid=event.id,
                subject=subject,
                clock=clock
            )
            sc.add(alert)
            sc.commit()

            users = eh.notify_users
            email_list = []
            mobile_num_list = []
            for user in users:
                u = sc.query(Users).filter_by(name=user).first()
                if u:
                    email_list.append(u.email)
                    mobile_num_list.append(u.mobile_num)
                else:
                    logger.error("No found %s in table Users." % user)

            # 1:email,2:sms,3:email&sms
            is_email, is_sms = 0, 0
            if 1 == eh.action_type:
                is_email = 1
            elif 2 == eh.action_type:
                is_sms = 1
            elif 3 == eh.action_type:
                is_email = 1
                is_sms = 1

            if is_email == 1:
                tornado.ioloop.IOLoop.instance().add_callback(
                    self.async_send_mail,
                    subject=subject,
                    msg="",
                    email_list=email_list,
                )
            if is_sms == 1:
                tornado.ioloop.IOLoop.instance().add_callback(
                    self.async_send_sms,
                    content=subject,
                    sms_list=mobile_num_list
                )
            return 0

class TuringMonitorHostSettingListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringServers
        self.fields = {
            'id': 'id',
            'ip': 'ip',
            'broker_id': 'broker_id',
            'monitor_status': 'monitor_status',
            'principal': 'principal'
        }

    def post(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def delete(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return

        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                out_data = []
                for record in payload:
                    o = sc.query(self.model).filter_by(id=record['id']).first()
                    if o:
                        for k, v in self.fields.items():
                            if v in record and v != 'id':
                                setattr(o, k, record[v])
                        out_data.append(o.to_dict())
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': out_data,
                }))

            notify_monitor_module("host")
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class ShannonMonitorHostSettingListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = ShannonServers
        self.fields = {
            'id': 'id',
            'ip': 'ip',
            'broker_id': 'broker_id',
            'monitor_status': 'monitor_status',
            'principal': 'principal'
        }

    def post(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def delete(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return

        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                out_data = []
                for record in payload:
                    o = sc.query(self.model).filter_by(id=record['id']).first()
                    if o:
                        for k, v in self.fields.items():
                            if v in record and v != 'id':
                                setattr(o, k, record[v])
                        out_data.append(o.to_dict())
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': out_data,
                }))

            notify_monitor_module("host")
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

class StrategyAccidentListHandler(ListHandler):
    def initialize(self, *args, **kwargs):
        self.model = StrategyAccident
        self.fields = {
            'id': 'id',
            'ip': 'ip',
            'process_id': 'process_id',
            'vstrategy_id': 'vstrategy_id',
            'calendar_time_start': 'calendar_time_start',
            'calendar_time_end': 'calendar_time_end',
            'trading_date_start': 'trading_date_start',
            'trading_date_end': 'trading_date_end',
            'description': 'desc',
        }
        self.header = [
            {
                'prop': 'id',
                'title': 'ID',
                'sortable': True
            },
            {
                'prop': 'ip',
                'title': '服务器IP',
                'sortable': True
            },
            {
                'prop': 'process_id',
                'title': '策略进程ID',
                'sortable': True
            },
            {
                'prop': 'calendar_time_start',
                'title': '故障发生时间',
                'sortable': True
            },
            {
                'prop': 'calendar_time_end',
                'title': '故障恢复时间',
                'sortable': True
            },
            {
                'prop': 'trading_date_start',
                'title': '受影响的起始交易日',
                'sortable': True
            },
            {
                'prop': 'trading_date_end',
                'title': '受影响的终止交易日',
                'sortable': True
            },
            {
                'prop': 'desc',
                'title': '故障描述'
            },
        ]

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return

        payload = json.loads(str(self.request.body, 'utf-8'))
        logger.debug(payload)
        out_data = []
        try:
            with mysql_sc() as sc:
                for pid in payload['process_id']:
                    proc_info = sc.query(DeployConfs).filter_by(id=pid).first()
                    if proc_info:
                        vstra_id = proc_info.vstrategy_id
                        accident = StrategyAccident(
                            ip=payload['ip'],
                            process_id=int(pid),
                            vstrategy_id=int(vstra_id),
                            calendar_time_start=datetime.datetime.strptime(payload['calendar_time_start'], '%Y-%m-%d %H:%M'),
                            calendar_time_end=datetime.datetime.strptime(payload['calendar_time_end'], '%Y-%m-%d %H:%M'),
                            trading_date_start=datetime.datetime.strptime(payload['trading_date_start'], '%Y-%m-%d').date(),
                            trading_date_end=datetime.datetime.strptime(payload['trading_date_end'], '%Y-%m-%d').date(),
                            description=payload['desc']
                        )
                        sc.add(accident)
                        sc.commit()
                        data = accident.to_dict()
                        out_data.append(data)
                    else:
                        self.write(json.dumps({
                            'code': 404,
                            'error': "Not found process %d" % pid
                        }))
                        return
                self.write(json.dumps({
                    'code': 0,
                    'data': out_data
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def get(self, *args, **kwargs):
        out_data = []
        try:
            with mysql_sc() as sc:
                accidents = sc.query(self.model).order_by(
                    self.model.id.desc()
                ).all()
                for r in accidents:
                    data = r.to_dict()
                    out_data.append(data)
            self.write(json.dumps(
                {
                    'code': 0,
                    'data': {
                        'data': out_data,
                        'header': self.header,
                    }
                }
            ))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return

        payload = json.loads(str(self.request.body, 'utf-8'))
        out_data = []
        try:
            with mysql_sc() as sc:
                for r in payload:
                    logger.debug(r)
                    o = sc.query(self.model).filter_by(id=r['id']).first()
                    if o:
                        for k, v in self.fields.items():
                            if v in r.keys() and v != 'id':
                                setattr(o, k, r[v])
                        data = o.to_dict()
                        out_data.append(data)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': out_data
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return

        payload = json.loads(str(self.request.body, 'utf-8'))
        logger.info(payload)
        try:
            with mysql_sc() as sc:
                for id in payload:
                    sc.query(self.model).filter_by(id=id).delete()

            self.write(json.dumps({
                'code': 0,
                'msg': "success"
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

class TradingDateIDHandler(IDHandler):
    def initialize(self, *args, **kwargs):
        self.no_login = ['get']

    def get(self, *args, **kwargs):
        try:
            trading_date = ''
            str_time = self.get_argument('calendar_time', '')
            logger.debug("rcv calendar_time = %s" % str_time)
            calendar_time = datetime.datetime.strptime(str_time, "%Y-%m-%d %H:%M")
            calendar_date = calendar_time.strftime('%Y-%m-%d')
            hour_min = int(calendar_time.strftime('%H%M'))
            if hour_min >= 500 and hour_min < 1700:
                trading_date = calendar_time.strftime('%Y-%m-%d')
                logger.info("day time, so trading_date=%s" % trading_date)
            else:
                period = -1
                if hour_min>=1700 and hour_min < 2359:
                    period = 1
                elif hour_min>=0 and hour_min < 459:
                    period = 0

                with kdb_conn() as kdb_hd:
                    str_date = kdb_hd.get_trading_date(calendar_date, period)
                    trading_date = datetime.datetime.strptime(str_date, "%Y%m%d").strftime('%Y-%m-%d')
                    logger.info("query calendar_date=%s, period=%d from KDB+, get trading_date=%s" % (calendar_date, period, trading_date))

            self.write(json.dumps({
                'code': 0,
                'data': {
                    'trading_date': trading_date,
                },
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def post(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def put(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def delete(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))


class QYWXSendTextIDHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.qywx_url = 'https://qyapi.weixin.qq.com'
        self.corpid = 'ww7c9916c2f31d5aa4'

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return

        try:
            payload = json.loads(str(self.request.body, 'utf-8'))

            if 'touser' not in payload.keys() and 'toparty' not in payload.keys() and 'totag' not in payload.keys():
                self.write(json.dumps({
                    'code': 1100,
                    'error': 'touser、toparty、totag不能同时为空',
                }))
                return
            if 'secret' not in payload.keys() or not payload['secret']:
                self.write(json.dumps({
                    'code': 1101,
                    'error': 'secret is error',
                }))
                return
            if 'agentid' not in payload.keys() or not payload['agentid']:
                self.write(json.dumps({
                    'code': 1102,
                    'error': 'agentid is error',
                }))
                return
            if 'msg' not in payload.keys() or len(payload['msg']) == 0:
                self.write(json.dumps({
                    'code': 1103,
                    'error': 'msg is not exist or NULL',
                }))
                return

            token = self.get_token(payload['secret'])
            touser = payload['touser'] if 'touser' in payload.keys() else ''
            toparty = payload['toparty'] if 'toparty' in payload.keys() else ''
            totag = payload['totag'] if 'totag' in payload.keys() else ''
            msg = self.messages(payload['agentid'], payload['msg'], touser, toparty, totag)
            send_url = '%s/cgi-bin/message/send?access_token=%s' % (self.qywx_url, token)
            respone = urllib.request.urlopen(urllib.request.Request(url=send_url, data=msg)).read()
            logger.info("send wx: %s" % msg)
            rsp = json.loads(respone.decode())
            logger.info("rcv rsp: %s" % rsp)
            if rsp['errcode'] == 0:
                self.write(json.dumps({
                    'code': 0,
                    'msg': 'Succesfully'
                }))
            else:
                errmsg = rsp['errmsg']
                if 'invaliduser' in rsp and len(rsp['invaliduser']) > 0:
                    errmsg = '%s. invaliduser:%s' % (errmsg, rsp['invaliduser'])
                if 'invalidparty' in rsp and len(rsp['invalidparty']) > 0:
                    errmsg = '%s. invalidparty:%s' % (errmsg, rsp['invalidparty'])
                if 'invalidtag' in rsp and len(rsp['invalidtag']) > 0:
                    errmsg = '%s. invalidtag:%s' % (errmsg, rsp['invalidtag'])

                self.write(json.dumps({
                    'code': 1104,
                    'msg': errmsg
                }))
        except Exception as e:
            logger.error('Failed to send weixin(%s), Exception: %s' % (self.request.body, str(e)))
            self.write(json.dumps({
                'code': 500,
                'msg': str(e),
            }))

    def get_token(self, secret):
        token_url = '%s/cgi-bin/gettoken?corpid=%s&corpsecret=%s' % (self.qywx_url, self.corpid, secret)
        token = json.loads(urllib.request.urlopen(token_url).read().decode())['access_token']
        return token

    def messages(self, agentid, msg, users='',party='',tag=''):
        info = {
            "msgtype": 'text',
            "agentid": agentid,
            "text": {'content': msg},
            "safe": 0
        }
        if users:
            info["touser"] = users
        if party:
            info["toparty"] = party
        if tag:
            info["totag"] = tag

        msges = (bytes(json.dumps(info), 'utf-8'))
        return msges


@Singleton
class AlertFilterRegularMng(object):

    def __init__(self):
        self.model = OPSAlertFilterRegulars
        self.regulars = self.load_regulars()

    def load_regulars(self):
        regular_dict = {}
        with mysql_sc() as sc:
            regs = sc.query(self.model).all()
            for reg in regs:
                regular_dict[reg.id] = self.regular_str2list(reg.regular)
        return regular_dict

    def regular_str2list(self, regular):
        new_reg = regular.split(',')
        return [reg.strip() for reg in new_reg]

    def regular_is_exist(self, regular):
        for id, reg in self.regulars.items():
            if set(reg) == set(regular):
                return -1
        return 0

    def is_filter_alert(self, msg):
        for id, reg in self.regulars.items():
            founds = 0
            for r in reg:
                if len(re.findall(r, msg)) >= 1:
                    founds += 1
            if len(reg) == founds:
                return True
        return False


class AlertFilterRegularHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = OPSAlertFilterRegulars
        self.regMng = AlertFilterRegularMng()

    def get(self, *args, **kwargs):
        res = []
        with mysql_sc() as sc:
            lines = sc.query(self.model).all()
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        #print('POST: payload = %s' % payload)

        try:
            regular = self.regMng.regular_str2list(payload['regular'])
            if 0 != self.regMng.regular_is_exist(regular):
                self.write(json.dumps({
                    'code': 1500,
                    'error': '该告警规则已存在！',
                }))
                return

            data = {'regular': payload['regular']}
            with mysql_sc() as sc:
                o = self.model(**data)
                sc.add(o)
                sc.commit()

                self.regMng.regulars[o.id] = regular
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        #print('POST: payload = %s' % payload)

        try:
            regular = self.regMng.regular_str2list(payload['regular'])
            if 0 != self.regMng.regular_is_exist(regular):
                self.write(json.dumps({
                    'code': 1500,
                    'error': '该告警规则已存在！',
                }))
                return
            self.regMng.regulars[payload['id']] = regular

            with mysql_sc() as sc:
                o = sc.query(self.model).filter_by(id=payload['id']).first()
                o.regular = payload['regular']
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return

        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            self.regMng.regulars.pop(payload['id'])
            with mysql_sc() as sc:
                sc.query(self.model).filter_by(id=payload['id']).delete()
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': 1
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class ExchgProductMonitorTimeMngListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = OPSExchgProductMonitorTime
        self.fields = {
            'exchange': 'exchange',
            'product': 'product',
            'monitor_time': 'monitor_time',
        }


class ExchgProductMonitorTimeMngIDHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = OPSExchgProductMonitorTime
        self.fields = {
            'exchange': 'exchange',
            'product': 'product',
            'monitor_time': 'monitor_time',
        }


class AlertRingMngHandler(BaseHandler):

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))

        try:
            redis_key = 'oss:event_handle:monitor:ring_mng'
            write_redis(redis_key, payload)
            self.write(json.dumps({
                'code': 0,
                'data': 1
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

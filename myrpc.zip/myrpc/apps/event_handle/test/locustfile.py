# encoding: utf-8
from locust import HttpLocust, TaskSet, task
from datetime import datetime
import subprocess
import json

headers = {
    'content-type': 'application/json',
    'whitelist': 'operater',
}

class UserBehavior(TaskSet):
    #Execute before any task.
    def on_start(self):
        pass

    '''
    #the @task takes an optional weight argument.
    @task(1)
    def get_severity_setting(self):
        r = self.client.get("/api/v1/event_handle/severity_setting", headers=headers)
        if json.loads((r.content))["code"] != 0:
            r.failure("Got wrong response:"+r.content)

    
    @task(1)
    def get_custom_alert(self):
        r = self.client.get("/api/v1/event_handle/custom_alert", headers=headers)
        if json.loads((r.content))["code"] != 0:
            r.failure("Got wrong response:"+r.content)

    @task(1)
    def get_all_business_event(self):
        r = self.client.get("/api/v1/event_handle/business_event/handle", headers=headers)
        if json.loads((r.content))["code"] != 0:
            r.failure("Got wrong response:" + r.content)

    @task(1)
    def get_business_event_by_dep(self):
        r = self.client.get("/api/v1/event_handle/business_event/handle?dep=dim", headers=headers)
        if json.loads((r.content))["code"] != 0:
            r.failure("Got wrong response:" + r.content)
    
    @task(1)
    def post_trigger_event(self):
        dt = datetime.now()
        event = {
            "key": "process.is_running.80",
            "host": "192.168.30.13",
            "operator": "=",
            "threshold": -1,
            "msg": "process exit exceptionally on host 192.168.30.13",
            "status": -1,
            "clock": str(dt),
        }
        r = self.client.post("/api/v1/event_handle/trigger_event", data=json.dumps(event), headers=headers)
        #if json.loads((r.content))["code"] != 0:
        #    r.failure("Got wrong response:" + r.content)

    '''
    @task(1)
    def post_business_event(self):
        dt = datetime.now()
        event = {
            "event_key": "update_produce_para",
            "dep": "dim",
            "clock": str(dt),
        }
        r = self.client.post("/api/v1/event_handle/business_event/event", data=json.dumps(event), headers=headers)
        #if json.loads((r.content))["code"] != 0:
        #   r.failure("Got wrong response:" + r.content)
    




class WebUserLocust(HttpLocust):
    #Speicify the weight of the locust.
    #weight = 1
    #The taskset class name is the value of the task_set.
    task_set = UserBehavior
    #Wait time between the execution of tasks.
    min_wait = 0
    max_wait = 0

'''
if __name__ == '__main__':
    subprocess.Popen('locust --host=http://192.168.1.13', shell=True)
'''

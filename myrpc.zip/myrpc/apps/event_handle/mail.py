# -*- coding:utf-8 -*-

import smtplib
import json
import requests
from email.header import Header
from email.mime.text import MIMEText
from email.utils import parseaddr, formataddr
from config import config
from tornado.concurrent import run_on_executor
from concurrent.futures import ThreadPoolExecutor
import tornado.web
from log import logger


def get_wx_token(svr_type, is_token_expired):
    if svr_type == 1:  # turing
        if not hasattr(get_wx_token, 'wx_token_turing') or is_token_expired:
            corpid = 'ww7c9916c2f31d5aa4'
            #agentid = 1000010
            secret = 'Y2Y7wcdfP7ksrT8w9kWgJNcUiM6oedE0GsQ_jFfnsVM'
            token_url = 'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=%s&corpsecret=%s' % (corpid, secret)
            response = requests.get(token_url)
            if response.status_code == 200:
                token = response.json()['access_token']
                logger.info('new wx_token_turing: {}'.format(token))
                setattr(get_wx_token, 'wx_token_turing', token)
                return token
            else:
                logger.error('Failed to get wx_token_turing, rsp: {}'.format(response))
                return None
        return getattr(get_wx_token, 'wx_token_turing')
    else:
        if not hasattr(get_wx_token, 'wx_token_shannon') or is_token_expired:
            corpid = 'ww7c9916c2f31d5aa4'
            #agentid = 1000002
            secret = 'cmr4XaRxsSbVJBIOGjLlraty6Uw-kwd_zd4Qixq-VQE'
            token_url = 'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=%s&corpsecret=%s' % (corpid, secret)
            response = requests.get(token_url)
            if response.status_code == 200:
                token = response.json()['access_token']
                logger.info('new wx_token_shannon: {}'.format(token))
                setattr(get_wx_token, 'wx_token_shannon', token)
                return token
            else:
                logger.error('Failed to get wx_token_shannon, rsp: {}'.format(response))
                return None
        return getattr(get_wx_token, 'wx_token_shannon')


class Notification(object):
    executor = ThreadPoolExecutor(2)

    def __init__(self):
        # email params
        self.FROM_ADDR = "warning@mycapital.net"
        self.PASSWORD = "Mycapital0427"
        self.SMTP_SERVER = "smtp.qiye.163.com"
        self.SMTP_SERVER_PORT = 25

    @run_on_executor
    def async_send_mail(self, subject, msg, email_list):
        self.send_email(subject, msg, email_list)

    @run_on_executor
    def async_send_sms(self, content, sms_list):
        self.send_sms(content, sms_list)

    @run_on_executor
    def async_send_wx(self, content, wx_list, svr_type):
        self.send_wx(content, wx_list, svr_type)

    def format_addr(self, address):
        name, addr = parseaddr(address)
        return formataddr((Header(name, 'utf-8').encode(), addr))

    def send_email(self, title, content, to_addrs):
        email_title = title
        msg = MIMEText(content, "plain", "utf-8")
        msg["From"] = self.format_addr("<%s>" % self.FROM_ADDR)
        msg_to = ""
        for to_addr in to_addrs:
            msg_to += self.format_addr("<%s>" % to_addr) + ','
        msg["To"] = msg_to[:-1]
        msg["Subject"] = Header(email_title, "utf-8").encode()

        server = smtplib.SMTP(self.SMTP_SERVER, self.SMTP_SERVER_PORT)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(self.FROM_ADDR, self.PASSWORD)
        server.sendmail(self.FROM_ADDR, to_addrs, msg.as_string())
        server.quit()

    def send_sms(self, content, sms_list):
        payload = {
            'to': ','.join(sms_list),
            'do': 'sms',
            'msg': content
        }

        try:
            r = requests.post(config.sms_url, data=payload)
        except Exception as e:
            return -1, str(e)

        if r.text.strip() == 'success':
            return 0, "success"
        else:
            err = "Http return %s" % r.text.strip()
            return -1, err

    def send_wx(self, content, wx_list, svr_type):
        msg_url = 'https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=%s'
        if svr_type == 1:  # turing
            agentid = 1000010
        else:
            agentid = 1000002
        token_expired = False
        try:
            while True:
                token = get_wx_token(svr_type, token_expired)
                if not token:
                    logger.error('token is None, cannot send wx !')
                    continue

                msg_url = msg_url % token
                payload = {
                    "touser": "|".join(wx_list),
                    "toparty": "",
                    "msgtype": "text",
                    "agentid": agentid,
                    "text": {
                        "content": content
                    },
                    "safe": "0"
                }
                r = requests.post(msg_url, json=payload)
                if r.status_code == 200:
                    json_data = r.json()
                    if json_data['errcode'] == 0:
                        logger.info('send wx: {}'.format(content))
                        return 0, 'ok'
                    elif json_data['errcode'] == 42001 or json_data['errcode'] == 40014:
                        # 40014: invalid access_token, 42001: access_token expired
                        logger.error('retry for token. {}'.format(json_data))
                        token_expired = True
                        continue
                    else:
                        logger.error('wx server return {}'.format(json_data))
                        return -1, json_data
                else:
                    logger.error('Http return status_code: {}'.format(r.status_code))
                    return -1, 'status_code=%s' % r.status_code
        except Exception as e:
            return -1, str(e)

    def send_alert(self, email_list, wx_list, mobile_num_list, alert_subject, alert_content, global_alert_setting,
                   alert_status, svr_type):
        if global_alert_setting['wx'] == 1 and len(wx_list) > 0:
            tornado.ioloop.IOLoop.instance().add_callback(
                self.async_send_wx,
                content=alert_content,
                wx_list=wx_list,
                svr_type=svr_type
            )

        if global_alert_setting['email'] == 1:
            tornado.ioloop.IOLoop.instance().add_callback(
                self.async_send_mail,
                subject=alert_subject,
                msg=alert_content,
                email_list=email_list,
            )

        if global_alert_setting['sms'] == 1 and len(mobile_num_list) > 0:
            '''rice要求故障恢复不发短信'''
            if alert_status == 0:
                return 0

            tornado.ioloop.IOLoop.instance().add_callback(
                self.async_send_sms,
                content=alert_content,
                sms_list=mobile_num_list
            )

        return 0

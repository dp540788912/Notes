# encoding: utf-8

import tornado.ioloop
import tornado.web

from handlers import *


urls = [
    (r"/api/v1/event_handle/severity_setting", SeveritySettingListHandler),
    (r"/api/v1/event_handle/severity_setting/(?P<id>\d+)$", SeveritySettingIDHandler),
    (r"/api/v1/event_handle/deploy_reg_handle", DeployModelRegHandler),
    (r"/api/v1/event_handle/custom_alert", CustomAlertListHandler),
    (r"/api/v1/event_handle/custom_alert/(?P<id>\d+)$", CustomAlertIDHandler),
    (r"/api/v1/event_handle/custom_alert/batch_setting", CustomAlertBatchSettingHandler),
    (r"/api/v1/event_handle/trigger_event/event", TriggerEventListHandler),
    (r"/api/v1/event_handle/trigger_event/bulk_events", BulkTriggerEventListHandler),
    (r"/api/v1/event_handle/history_alert$", AlertHistoryListHandler),
    (r"/api/v1/event_handle/business_event/reg", BussinessEventHandleListHandler),
    (r"/api/v1/event_handle/business_event/event", BussinessEventListHandler),
    (r"/api/v1/event_handle/monitor_setting/host/shannon", ShannonMonitorHostSettingListHandler),
    (r"/api/v1/event_handle/monitor_setting/host/turing", TuringMonitorHostSettingListHandler),
    (r"/api/v1/event_handle/strategy_accident", StrategyAccidentListHandler),
    (r"/api/v1/event_handle/trading_date", TradingDateIDHandler),
    (r"/api/v1/event_handle/qywx/message/send/text", QYWXSendTextIDHandler),
    (r"/api/v1/event_handle/alert_filter_regular", AlertFilterRegularHandler),
    (r"/api/v1/event_handle/exchg_product_monitor_time", ExchgProductMonitorTimeMngListHandler),
    (r"/api/v1/event_handle/exchg_product_monitor_time/(?P<id>\d+)$", ExchgProductMonitorTimeMngIDHandler),
    (r"/api/v1/event_handle/alert_ring_mng", AlertRingMngHandler),
]


class Application(tornado.web.Application):
    def __init__(self, handlers):
        self.logger = logger
        self.cfg = config
        tornado.web.Application.__init__(self, handlers)


def make_app():
    return Application(urls)


if __name__ == "__main__":
    app = make_app()
    app.listen(config.port)
    tornado.ioloop.IOLoop.current().start()


# encoding:utf-8

from sqlalchemy.sql import func, or_, and_
from sqlalchemy.orm import relationship
from sqlalchemy import Column, ForeignKey
from sqlalchemy.dialects.mysql import BIGINT, DATETIME, DATE, TIME, INTEGER, VARCHAR, TEXT, LONGTEXT, FLOAT, DOUBLE, BOOLEAN, JSON, SMALLINT, DECIMAL
from db import ModelBase, session_context as mysql_sc
from sqlalchemy import UniqueConstraint
import datetime

class SeveritySetting(ModelBase):
    __tablename__ = 'severity_setting'

    id = Column(SMALLINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(16), nullable=False, unique=True)
    color = Column(VARCHAR(16), nullable=False, unique=True)
    wx = Column(SMALLINT(), nullable=False)
    email = Column(SMALLINT(), nullable=False)
    sms = Column(SMALLINT(), nullable=False)
    notify_users = Column(JSON())
    ring_type = Column(SMALLINT(), nullable=False)

    @staticmethod
    def get_notify_users(severity):
        with mysql_sc() as sc:
            severity_setting = sc.query(SeveritySetting).filter_by(name=severity).first()
            if severity_setting:
                return severity_setting.to_dict()
            else:
                return None

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'color': self.color,
            'wx': self.wx,
            'email': self.email,
            'sms': self.sms,
            'notify_users': self.notify_users,
            'ring_type': self.ring_type
        }

class EventHistory(ModelBase):
    __tablename__ = 'event_history'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    # eventtype 1:触发器事件; 2:业务事件
    eventtype = Column(SMALLINT(),nullable=False)
    objectid = Column(INTEGER(), nullable=False)
    processid = Column(BIGINT(), nullable=False)
    # 事件状态，-1：事件产生；0：事件恢复
    status = Column(SMALLINT(), nullable=False)
    msg = Column(VARCHAR(512))
    clock = Column(DATETIME, nullable=False)
    # 1:send alarm 0:no alarm
    isalert = Column(SMALLINT, nullable=False)
    r_create_time = Column(DATETIME, default=datetime.datetime.now(), nullable=False)

    @staticmethod
    def get_history_alert_status(eventtype, objectid, process_id, interval):
        with mysql_sc() as sc:
            history_alert_status = sc.query(EventHistory.status.label('status')).filter(
                EventHistory.eventtype == eventtype,
                EventHistory.objectid == objectid,
                EventHistory.processid == process_id,
                # EventHistory.msg == msg,
                EventHistory.isalert == 1,  # 1:send alarm 0:no alarm
                EventHistory.r_create_time >= (datetime.datetime.now() - datetime.timedelta(minutes=interval)),
            ).order_by(EventHistory.id.desc()).first()
            if history_alert_status:
                return history_alert_status.status
            else:
                return None

    @staticmethod
    def save(eventtype, objectid, processid, status, msg, clock, isalert):
        with mysql_sc() as sc:
            event = EventHistory(
                eventtype=eventtype,
                objectid=objectid,
                processid=processid,
                status=status,
                msg=msg,
                clock=clock,
                isalert=isalert,
                r_create_time=datetime.datetime.now()
            )
            sc.add(event)
            sc.commit()
            return event.to_dict()

    def to_dict(self):
        return {
            'id': self.id,
            'eventtype': self.eventtype,
            'objectid': self.objectid,
            'processid': self.processid,
            'status': self.status,
            'msg': self.msg,
            'clock': str(self.clock),
            'isalert': self.isalert
        }


class AlertHistory(ModelBase):

    __tablename__ = 'alert_history'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    eventid = Column(BIGINT, nullable=False)
    subject = Column(VARCHAR(255), nullable=True)
    clock = Column(DATETIME, nullable=False)

    @staticmethod
    def save(eventid, subject, clock):
        with mysql_sc() as sc:
            alert = AlertHistory(
                eventid=eventid,
                subject=subject,
                clock=clock
            )
            sc.add(alert)
            sc.commit()
            return

    def to_dict(self):
        return {
            'id': self.id,
            'eventid': self.eventid,
            'subject': self.subject,
            'clock': str(self.clock),
        }


class TriggerEventHandles(ModelBase):

    __tablename__ = 'trigger_event_handles'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    hostip = Column(VARCHAR(31), nullable=False)
    itemkey = Column(VARCHAR(255), nullable=False)
    itemkey_cn = Column(VARCHAR(255), nullable=False)
    operator = Column(VARCHAR(1), nullable=False)
    threshold = Column(DECIMAL(65, 2), nullable=False)
    # severity: warn,avg,high
    severity = Column(VARCHAR(31), nullable=False)
    interval = Column(INTEGER(), nullable=False)
    # 告警类型，1:事件告警 2：故障告警
    alert_type = Column(SMALLINT(), nullable=False)
    # application: 业务类型
    application = Column(VARCHAR(31), nullable=False)
    users = Column(JSON())
    msg = Column(VARCHAR(512))
    recovery_msg = Column(VARCHAR(512))
    description = Column(VARCHAR(255))
    monitor_time = Column(VARCHAR(255))
    enabled = Column(BOOLEAN(), nullable=False)

    UniqueConstraint('hostip', 'itemkey', 'operator', 'threshold')

    @staticmethod
    def get_define(host, key, operator, threshold):
        with mysql_sc() as sc:
            teh = sc.query(TriggerEventHandles).filter_by(
                hostip=host,
                itemkey=key,
                operator=operator,
                threshold=threshold
            ).first()
            if teh:
                return teh.to_dict()
            else:
                return None

    def to_dict(self):
        return {
            'id': self.id,
            'host': self.hostip,
            'key': self.itemkey,
            'key_cn': self.itemkey_cn,
            'operator': self.operator,
            'threshold': float(self.threshold),
            'severity': self.severity,
            'interval': self.interval,
            'alert_type': self.alert_type,
            'category': self.application,
            'desc': self.description,
            'msg': self.msg,
            'recovery_msg': self.recovery_msg,
            'notify_users': self.users if self.users else [],
            'monitor_time': self.monitor_time,
            'enabled': self.enabled
        }

class BusinessEventHandles(ModelBase):

    __tablename__ = 'business_event_handles'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    event_key = Column(VARCHAR(255), nullable=False)
    dep = Column(VARCHAR(48), nullable=False)
    # 1:email,2:sms,3:email&sms
    action_type = Column(SMALLINT(), nullable=False)
    notify_users = Column(JSON(), nullable=False)
    msg = Column(VARCHAR(512), nullable=False)
    description = Column(VARCHAR(255))
    interval = Column(INTEGER(), nullable=False)
    enabled = Column(BOOLEAN(), nullable=False)

    UniqueConstraint('event_key', 'dep')

    def to_dict(self):
        return {
            'id': self.id,
            'event_key': self.event_key,
            'dep': self.dep,
            'action_type': self.action_type,
            'notify_users': self.notify_users,
            'msg': self.msg,
            'desc': self.description,
            'interval': self.interval,
            'enabled': self.enabled
        }

class Users(ModelBase):

    __tablename__ = 'users'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False)
    email = Column(VARCHAR(128), nullable=False)
    mobile_num = Column(VARCHAR(128), nullable=False)
    wx_id = Column(VARCHAR(128), nullable=True)

    @staticmethod
    def detail(user):
        with mysql_sc() as sc:
            u = sc.query(Users).filter_by(name=user).first()
            if u:
                return u.to_dict()
            else:
                return None

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'mobile_num': self.mobile_num,
            'wx_id': self.wx_id,
        }

class ProgramTypes(ModelBase):

    __tablename__ = 'program_types'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)

class ShannonServers(ModelBase):

    __tablename__ = 'servers'

    id = Column(BIGINT, primary_key=True)
    ip = Column(VARCHAR(45), nullable=False, unique=True)
    broker_id = Column(INTEGER, nullable=False)
    # 1: 监控 0:不监控
    monitor_status = Column(SMALLINT(), nullable=False)
    principal = Column(JSON(), nullable=False)

    @staticmethod
    def host_principal(host_ip):
        with mysql_sc() as sc:
            r = sc.query(ShannonServers).filter_by(ip=host_ip, monitor_status=1).first()
            if r:
                return r.principal
            else:
                return None

    def to_dict(self):
        return {
            'id': self.id,
            'ip': self.ip,
            'broker_id': self.broker_id,
            'monitor_status': self.monitor_status,
            'principal': self.principal
        }

class TuringServers(ModelBase):

    __tablename__ = 'turing_servers'

    id = Column(BIGINT, primary_key=True)
    ip = Column(VARCHAR(45), nullable=False, unique=True)
    broker_id = Column(INTEGER, nullable=False)
    # 1: 监控 0:不监控
    monitor_status = Column(SMALLINT(), nullable=False)
    principal = Column(JSON(), nullable=False)

    @staticmethod
    def host_principal(host_ip):
        with mysql_sc() as sc:
            r = sc.query(TuringServers).filter_by(ip=host_ip, monitor_status=1).first()
            if r:
                return r.principal
            else:
                return None

    def to_dict(self):
        return {
            'id': self.id,
            'ip': self.ip,
            'broker_id': self.broker_id,
            'monitor_status': self.monitor_status,
            'principal': self.principal
        }

class StrategyAccident(ModelBase):
    __tablename__ = 'strategy_accident'

    id = Column(BIGINT, primary_key=True)
    ip = Column(VARCHAR(45), nullable=False)
    process_id = Column(BIGINT(unsigned=True), nullable=False)
    vstrategy_id = Column(BIGINT(unsigned=True), nullable=False)
    calendar_time_start = Column(DATETIME, nullable=False)
    calendar_time_end = Column(DATETIME, nullable=False)
    trading_date_start = Column(DATE, nullable=False)
    trading_date_end = Column(DATE, nullable=False)
    description = Column(VARCHAR(3072), nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'ip': self.ip,
            'process_id': self.process_id,
            'vstrategy_id': self.vstrategy_id,
            'calendar_time_start': str(self.calendar_time_start),
            'calendar_time_end': str(self.calendar_time_end),
            'trading_date_start': str(self.trading_date_start),
            'trading_date_end': str(self.trading_date_end),
            'desc': self.description
        }

class DeployConfs(ModelBase):

    __tablename__ = 'deploy_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(256), nullable=True)
    host = Column(VARCHAR(45), nullable=False)
    deploy_path = Column(VARCHAR(256), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    program_type_id = Column(ForeignKey('program_types.id'), nullable=True)
    vstrategy_id = Column(ForeignKey('vstrategies.id'), nullable=True)
    content = Column(LONGTEXT, nullable=True)
    result = Column(INTEGER, default=0)
    status = Column(INTEGER, default=1)
    program_id = Column(ForeignKey('programs.id'), nullable=True)
    request_id = Column(ForeignKey('online_request.id'), nullable=True)
    valid = Column(BOOLEAN, default=True, nullable=True)

    program_type_obj = relationship('ProgramTypes')
    #program_obj = relationship('Programs')
    #request_obj = relationship('OnlineRequest')
    #vstrategy_obj = relationship('VStrategies')


class VStrategies(ModelBase):

    __tablename__ = 'vstrategies'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    status = Column(INTEGER, default=11)
    portfolio_id = Column(ForeignKey('strategy_portfolio.id', ondelete='CASCADE'))
    strategy_id = Column(INTEGER, nullable=False)
    strategy_weight = Column(FLOAT, nullable=True, default=0)
    symbols_accounts = Column(JSON, nullable=True)
    source = Column(VARCHAR(32), nullable=True)
    name = Column(VARCHAR(128), nullable=True)
    closing_out = Column(INTEGER, nullable=True)


class TuringProgramTypes(ModelBase):

    __tablename__ = 'turing_program_types'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(128), nullable=False, unique=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
        }


class TuringPrograms(ModelBase):

    __tablename__ = 'turing_programs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(128), nullable=False)
    type_id = Column(ForeignKey('turing_program_types.id'))
    filepath = Column(VARCHAR(256), nullable=False)
    version = Column(VARCHAR(32), nullable=False)

    program_type_obj = relationship('TuringProgramTypes')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'type': {
                'id': self.program_type_obj.id,
                'name': self.program_type_obj.name,
            },
            'filepath': self.filepath,
            'version': self.version,
        }


class TuringDeployConfs(ModelBase):

    __tablename__ = 'turing_deploy_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(256), nullable=True)
    host = Column(VARCHAR(45), nullable=False)
    deploy_path = Column(VARCHAR(256), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    program_id = Column(BIGINT(unsigned=True), nullable=True)
    content = Column(LONGTEXT, nullable=True)
    result = Column(INTEGER, nullable=True, default=0)
    status = Column(INTEGER, nullable=True, default=1)
    valid = Column(BOOLEAN, default=True, nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'host': self.host,
            'deploy_path': self.deploy_path,
            'day_night': self.day_night,
            'program_id': self.program_id,
            'result': self.result,
            'status': self.status,
            'valid': self.valid,
        }


class OPSAlertFilterRegulars(ModelBase):

    __tablename__ = 'ops_alert_filter_regulars'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    regular = Column(VARCHAR(128), nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'regular': self.regular,
        }


class OPSExchgProductMonitorTime(ModelBase):

    __tablename__ = 'ops_exchg_product_monitor_time'

    id = Column(INTEGER(unsigned=True), primary_key=True)
    exchange = Column(VARCHAR(8), nullable=False)
    product = Column(VARCHAR(16))
    monitor_time = Column(VARCHAR(128), nullable=False)

    UniqueConstraint('exchange', 'product')

    def to_dict(self):
        return {
            'id': self.id,
            'exchange': self.exchange,
            'product': self.product,
            'monitor_time': self.monitor_time,
        }


def add_default_data_to_severity_setting():
    with mysql_sc() as sc:
        ss1 = SeveritySetting(name="warn", color="#FFC859", wx=1, email=0, sms=0, notify_users=[])
        ss2 = SeveritySetting(name="avg", color="#FFA059", wx=1, email=1, sms=0, notify_users=[])
        ss3 = SeveritySetting(name="high", color="#E45959", wx=1, email=1, sms=1, notify_users=[])

        sc.add(ss1)
        sc.add(ss2)
        sc.add(ss3)

        sc.commit()



if __name__ == '__main__':
    from db import engine
    ModelBase.metadata.create_all(engine)
    #add_default_data_to_severity_setting()


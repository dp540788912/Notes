# -*- coding:utf-8 -*-

import os
import redis
import base64
import json
#import time
import re
import datetime
from redis_api import MessageList
from models import *
from log import logger
from config import config


def check_redis_session(redis_config, session):
    rds = redis.Redis(redis_config['host'], redis_config['port'])
    s = rds.get('session:%s' % session)
    if s:
        data = json.loads(str(base64.b64decode(s), 'utf-8').split(':', 1)[-1])
        if ('_auth_user_id' in data):
            res = {
                'id': data.get('_auth_user_id'),
                'username': data.get('_auth_user_name', ''),
                'nickname': data.get('_auth_user_nickname', ''),
            }
            return res
    return {}

def get_url(url,svr_ip=config.mysql['host'],svr_port=config.mysql['port']):
    return "http://" + svr_ip + ":" + str(svr_port) + url


def notify_monitor_module(type):
    redis_key = "oss:monitor:event_handle:update_conf"
    try:
        data = {
            "update": type,
            "clock": datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
        }
        MessageList(redis_key).put(json.dumps(data))
        logger.info("[%s]Write %s" % (redis_key, data))
    except Exception as e:
        logger.error("[%s]Write %s, but catch exception: %s" % (redis_key, data, str(e)))
        return

def write_redis(redis_key, data):
    try:
        MessageList(redis_key).put(json.dumps(data))
        logger.info("[%s]Write %s" % (redis_key, data))
    except Exception as e:
        logger.error("[%s]Write %s, but catch exception: %s" % (redis_key, data, str(e)))
        return


def is_send_alert(id, interval, severity, process_id, status):
    ret = 0
    history_status_send = EventHistory.get_history_alert_status(1, id, process_id, interval)
    if history_status_send is None:
        ret = 1
    else:
        if history_status_send == status and status == -1:
            logger.info("Event %d occurred. It had alerted over last %d minutes, so no repeat." % (id, interval))
        elif history_status_send != status and status == 0:
            logger.info("Event %d recovered. " % (id))
            ret = 1
        elif history_status_send != status and status == -1:
            logger.info("Event %d occurred again. " % (id))
            ret = 1
        else:
            logger.info("Event %d recovered again. It had alerted over last %d minutes, so no repeat." % (id, interval))

    if ret == 0:
        return ret, None

    severity_setting = SeveritySetting.get_notify_users(severity)
    if severity_setting and severity_setting['email'] == 0 and severity_setting['sms'] == 0 and severity_setting['wx'] == 0:
        ret = 0
    elif severity_setting is None:
        logger.error("Not found define of severity %s" % (severity))
        return 404, None

    return ret, severity_setting

def get_notify_users(global_notify_users, item_notify_users, host_ip):
    notify_users = []
    email_list = []
    wx_list = []
    mobile_num_list = []
    svr_type = 0 # 0:shannon 1:turing

    host_set1 = ShannonServers.host_principal(host_ip)
    if host_set1:
        notify_users.extend(host_set1)
    host_set2 = TuringServers.host_principal(host_ip)
    if host_set2:
        svr_type = 1
        for user in host_set2:
            if user not in notify_users:
                notify_users.append(user)

    for user in global_notify_users:
        if user not in notify_users:
            notify_users.append(user)
    for user in item_notify_users:
        if user not in notify_users:
            notify_users.append(user)

    if 0 == len(notify_users):
        logger.warn("No users to notify, so cannot alert !")
        return 415, email_list, wx_list, mobile_num_list, svr_type

    for user in notify_users:
        u = Users.detail(user)
        if u is None:
            logger.error("No found %s in table Users." % user)
        else:
            if u['email']:
                email_list.append(u['email'])
            else:
                logger.warn("Email of user %s is NUll !" % user)

            if u['wx_id']:
                wx_list.append(u['wx_id'])
            else:
                logger.warn("weixin id of user %s is NUll !" % user)

            if u['mobile_num']:
                mobile_num_list.append(u['mobile_num'])
            else:
                logger.warn("Mobile number of user %s is NUll !" % user)

    return 0, email_list, wx_list, mobile_num_list, svr_type


def Singleton(cls):
    instances = {}
    def _singleton(*args, **kw):
        if cls not in instances:
            instances[cls] = cls(*args, **kw)
        return instances[cls]
    return _singleton

def time_slice_str2obj(time_str):
    time_re = re.compile(r'^(0\d|\d|1\d|2[0-4]):([0-5]\d)$')
    time_s_e = time_str.split('-')
    if not time_s_e or len(time_s_e) != 2:
        return None
    time_obj = {}
    try:
        start = time_re.match(time_s_e[0].replace('：', ':').replace(' ', ''))
        end = time_re.match(time_s_e[1].replace('：', ':').replace(' ', ''))
        #start = time_re.match(time_s_e[0].replace(' ', ''))
        #end = time_re.match(time_s_e[1].replace(' ', ''))
        if start and end:
            from datetime import time as ttime
            hour = int(start.group(1))
            minute = int(start.group(2))
            time_obj["start"] = ttime(hour, minute)
            hour = int(end.group(1))
            minute = int(end.group(2))
            time_obj["end"] = ttime(hour, minute)
    except:
        import traceback
        traceback.print_exc()
    return time_obj

def time_slice_union(time_slice1, time_slice2):
    new_slice = {}
    if (time_slice1['end'] < time_slice2['end'] and time_slice1['end'] > time_slice2['start']):
        new_slice['end'] = time_slice2['end']
        if time_slice1['start'] < time_slice2['start']:
            new_slice['start'] = time_slice1['start']
        else:
            new_slice['start'] = time_slice2['start']
    elif (time_slice1['end'] >= time_slice2['end'] and time_slice2['end'] > time_slice1['start']):
        new_slice['end'] = time_slice1['end']
        if time_slice2['start'] < time_slice1['start']:
            new_slice['start'] = time_slice2['start']
        else:
            new_slice['start'] = time_slice1['start']
    return new_slice

def time_slice_intersect(time_slice1, time_slice2):
    new_slice = {}
    if (time_slice1['end'] < time_slice2['end'] and time_slice1['end'] > time_slice2['start']):
        new_slice['end'] = time_slice1['end']
        if time_slice1['start'] < time_slice2['start']:
            new_slice['start'] = time_slice2['start']
        else:
            new_slice['start'] = time_slice1['start']
    elif (time_slice1['end'] >= time_slice2['end'] and time_slice2['end'] > time_slice1['start']):
        new_slice['end'] = time_slice2['end']
        if time_slice2['start'] < time_slice1['start']:
            new_slice['start'] = time_slice1['start']
        else:
            new_slice['start'] = time_slice2['start']
    return new_slice

def time_obj2str12h(time_obj):
    from datetime import time as ttime
    if time_obj <= ttime(12, 0):
        return '{}am'.format(time_obj.strftime('%H:%M'))
    else:
        h = time_obj.hour - 12
        time_obj = ttime(h, time_obj.minute)
        return '{}pm'.format(time_obj.strftime('%H:%M'))

def time_slice_obj2str12h(time_obj):
    return '{}-{}'.format(time_obj2str12h(time_obj['start']), time_obj2str12h(time_obj['end']))

def time_slice_obj2str24h(time_obj):
    return '{}-{}'.format(time_obj['start'].strftime('%H:%M'), time_obj['end'].strftime('%H:%M'))
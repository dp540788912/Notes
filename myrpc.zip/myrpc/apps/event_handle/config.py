# encoding: utf-8

import netifaces

class CommonConfig(object):
    pass


class ProductionConfig(CommonConfig):
    Debug = False

    port = 18886
    kdb = {
        'host': '192.168.10.102',
        'port': 9000,
        'user': 'superuser1',
        'passwd': 'password',
    }
    mysql = {
        'host': '192.168.10.80',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql

    redis = {
        'host': '127.0.0.1',
        'port': '6379',
    }

    sms_url = 'http://192.168.30.11:54321'
    wx_url = 'http://192.168.10.100:18886/api/v1/event_handle/qywx/message/send/text'


class DebugConfig(CommonConfig):
    Debug = True

    port = 18886
    kdb = {
        'host': '192.168.1.41',
        'port': 9000,
        'user': 'superuser1',
        'passwd': 'password',
    }
    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql

    redis = {
        'host': '127.0.0.1',
        'port': '6379',
    }

    sms_url = 'http://192.168.1.11:54321'
    wx_url = 'http://127.0.0.1:18886/api/v1/event_handle/qywx/message/send/text'


class Debug170Config(CommonConfig):
    Debug = True

    port = 18886
    kdb = {
        'host': '192.168.1.41',
        'port': 9000,
        'user': 'superuser1',
        'passwd': 'password',
    }
    mysql = {
        'host': '192.168.1.214',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql

    redis = {
        'host': '127.0.0.1',
        'port': '6379',
    }

    sms_url = 'http://192.168.1.11:54321'
    wx_url = 'http://192.168.1.13:18886/api/v1/event_handle/qywx/message/send/text'


iplist = [netifaces.ifaddresses(i).get(netifaces.AF_INET)[0]['addr']
          for i in netifaces.interfaces() if netifaces.ifaddresses(i).get(netifaces.AF_INET)]


debug_iplist = ['192.168.1.13', '192.168.1.14']

product_list = ['192.168.10.100']

debug170_iplist = ['192.168.1.170']

if any([i in iplist for i in product_list]):
    Debug = False
    config = ProductionConfig()
elif any([i in iplist for i in debug_iplist]):
    Debug = True
    config = DebugConfig()
elif any([i in iplist for i in debug170_iplist]):
    Debug = True
    config = Debug170Config()
else:
    raise ValueError('config error')


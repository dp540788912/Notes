# -*- coding: utf-8 -*-
# @Time    : 2018/5/28 8:59 PM
# @Author  : Colin
# @File    : migrate.py
# @Email   : zhouchaolin@mycapital.net


from myrpc.apps.auth.tools import migrate_data, database_mgr


# delete the user_type_info table
migrate_data.target_engine.execute("drop table user_type_info")

# create table not exist
database_mgr.create_if_not_exist(migrate_data.target_engine)

# migrate all necessary data
migrate_data.start()

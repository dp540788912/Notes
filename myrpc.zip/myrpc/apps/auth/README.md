## 功能:

1. 用户登录/登出/注册/授权(原有逻辑)
2. 用户/用户组管理，root 可对全部用户进行操作
   - 管理员重置密码后需要用户修改密码
   - 首次提供给用户的账户用户修改密码
   - 基于邮件重置密码
   - 账户本身可以自己修改信息
   - 管理员/manager 重置密码
   - 查询自身用户所在组的 role
   - 用户组的 role 只有对应的 manager 可以修改
3. 基于 redis 的 session 管理
4. 菜单管理，实现不同 group 不同 menu(原有逻辑)
5. 基于 tornado 的 csrf

## 数据表:

1. users

2. user_group

3. user_group_info

4. user_type

5. user_type_info

6. menu

7. credential_type

8. user_credential_info

9. group_menu

10. company

## IP 转发
nginx 配置项
```
proxy_set_header Host $host;
proxy_set_header X-Real-IP $remote_addr;
proxy_set_header X-Forwarded-Host $remote_addr;
proxy_set_header X-Forwarded-Server $host;
proxy_set_header X-Forwarded-For $remote_addr;
```



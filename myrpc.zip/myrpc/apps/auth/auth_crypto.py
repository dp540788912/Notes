# -*- coding: utf-8 -*-
# @Time    : 2018/5/22 5:03 PM
# @Author  : Colin
# @File    : auth_crypto.py.py
# @Email   : zhouchaolin@mycapital.net

import base64
import datetime
import hashlib
import importlib
import json
import os
import random
import time
from _operator import _compare_digest as compare_digest
from collections import OrderedDict
from decimal import Decimal

from myrpc.apps.auth.config import logger

SECRET_KEY = '!(t-9afl0voh)6&2-kfoho1bt&*r)hfio4=p79*c4zyrpfr(x4'


class Promise:
    """
    Base class for the proxy class created in the closure of the lazy function.
    It's used to recognize promises in code.
    """
    pass


def mask_hash(hash, show=6, char="*"):
    """
    Return the given hash, with only the first ``show`` number shown. The
    rest are masked with ``char`` for security reasons.
    """
    masked = hash[:show]
    masked += char * len(hash[show:])
    return masked


_PROTECTED_TYPES = (
    type(None), int, float, Decimal, datetime.datetime, datetime.date, datetime.time,
)


def is_protected_type(obj):
    """Determine if the object instance is of a protected type.

    Objects of protected types are preserved as-is when passed to
    force_text(strings_only=True).
    """
    return isinstance(obj, _PROTECTED_TYPES)


def constant_time_compare(val1, val2):
    """Return True if the two strings are equal, False otherwise."""
    return compare_digest(force_bytes(val1), force_bytes(val2))


def force_bytes(s, encoding='utf-8', strings_only=False, errors='strict'):
    """
    Similar to smart_bytes, except that lazy instances are resolved to
    strings, rather than kept as lazy objects.

    If strings_only is True, don't convert (some) non-string-like objects.
    """
    # Handle the common case first for performance reasons.
    if isinstance(s, bytes):
        if encoding == 'utf-8':
            return s
        else:
            return s.decode('utf-8', errors).encode(encoding, errors)
    if strings_only and is_protected_type(s):
        return s
    if isinstance(s, memoryview):
        return bytes(s)
    if isinstance(s, Promise) or not isinstance(s, str):
        return str(s).encode(encoding, errors)
    else:
        return s.encode(encoding, errors)


def pbkdf2(password, salt, iterations, dklen=0, digest=None):
    """Return the hash of password using pbkdf2."""
    if digest is None:
        digest = hashlib.sha256
    if not dklen:
        dklen = None
    password = force_bytes(password)
    salt = force_bytes(salt)
    return hashlib.pbkdf2_hmac(digest().name, password, salt, iterations, dklen)


def get_random_string(length=12,
                      allowed_chars='abcdefghijklmnopqrstuvwxyz'
                                    'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'):
    """
    Return a securely generated random string.

    The default length of 12 with the a-z, A-Z, 0-9 character set returns
    a 71-bit value. log_2((26+26+10)^12) =~ 71 bits
    """
    random.seed(
        hashlib.sha256(
            ('%s%s%s' % (random.getstate(), time.time(), SECRET_KEY)).encode()
        ).digest()
    )
    return ''.join(random.choice(allowed_chars) for i in range(length))


class BasePasswordHasher:
    """
    Abstract base class for password hashers

    When creating your own hasher, you need to override algorithm,
    verify(), encode() and safe_summary().

    PasswordHasher objects are immutable.
    """
    algorithm = None
    library = None

    def _load_library(self):
        if self.library is not None:
            if isinstance(self.library, (tuple, list)):
                name, mod_path = self.library
            else:
                mod_path = self.library
            try:
                module = importlib.import_module(mod_path)
            except ImportError as e:
                raise ValueError("Couldn't load %r algorithm library: %s" %
                                 (self.__class__.__name__, e))
            return module
        raise ValueError("Hasher %r doesn't specify a library attribute" %
                         self.__class__.__name__)

    def salt(self):
        """Generate a cryptographically secure nonce salt in ASCII."""
        return get_random_string()

    def verify(self, password, encoded):
        """Check if the given password is correct."""
        raise NotImplementedError('subclasses of BasePasswordHasher must provide a verify() method')

    def encode(self, password, salt):
        """
        Create an encoded database value.

        The result is normally formatted as "algorithm$salt$hash" and
        must be fewer than 128 characters.
        """
        raise NotImplementedError('subclasses of BasePasswordHasher must provide an encode() method')

    def safe_summary(self, encoded):
        """
        Return a summary of safe values.

        The result is a dictionary and will be used where the password field
        must be displayed to construct a safe representation of the password.
        """
        raise NotImplementedError('subclasses of BasePasswordHasher must provide a safe_summary() method')

    def must_update(self, encoded):
        return False

    def harden_runtime(self, password, encoded):
        """
        Bridge the runtime gap between the work factor supplied in `encoded`
        and the work factor suggested by this hasher.

        Taking PBKDF2 as an example, if `encoded` contains 20000 iterations and
        `self.iterations` is 30000, this method should run password through
        another 10000 iterations of PBKDF2. Similar approaches should exist
        for any hasher that has a work factor. If not, this method should be
        defined as a no-op to silence the warning.
        """
        logger.warn('subclasses of BasePasswordHasher should provide a harden_runtime() method')


class PBKDF2PasswordHasher(BasePasswordHasher):
    """
    Secure password hashing using the PBKDF2 algorithm (recommended)

    Configured to use PBKDF2 + HMAC + SHA256.
    The result is a 64 byte binary string.  Iterations may be changed
    safely but you must rename the algorithm if you change SHA256.
    """
    algorithm = "pbkdf2_sha256"
    iterations = 100000
    digest = hashlib.sha256

    def encode(self, password, salt, iterations=None):
        assert password is not None
        assert salt and '$' not in salt
        if not iterations:
            iterations = self.iterations
        hash = pbkdf2(password, salt, iterations, digest=self.digest)
        hash = base64.b64encode(hash).decode('ascii').strip()
        return "%s$%d$%s$%s" % (self.algorithm, iterations, salt, hash)

    def verify(self, password, encoded):
        algorithm, iterations, salt, hash = encoded.split('$', 3)
        assert algorithm == self.algorithm
        encoded_2 = self.encode(password, salt, int(iterations))
        return constant_time_compare(encoded, encoded_2)

    def safe_summary(self, encoded):
        algorithm, iterations, salt, hash = encoded.split('$', 3)
        assert algorithm == self.algorithm
        return OrderedDict([
            (_('algorithm'), algorithm),
            (_('iterations'), iterations),
            (_('salt'), mask_hash(salt)),
            (_('hash'), mask_hash(hash)),
        ])

    def must_update(self, encoded):
        algorithm, iterations, salt, hash = encoded.split('$', 3)
        return int(iterations) != self.iterations

    def harden_runtime(self, password, encoded):
        algorithm, iterations, salt, hash = encoded.split('$', 3)
        extra_iterations = self.iterations - int(iterations)
        if extra_iterations > 0:
            self.encode(password, salt, extra_iterations)


def make_password(password):
    if not hasattr(make_password, 'hasher'):
        make_password.hasher = PBKDF2PasswordHasher()
        make_password.salt = make_password.hasher.salt()
    return make_password.hasher.encode(password, make_password.salt)


def check_password(raw_password, encode_password):
    if not hasattr(check_password, 'hashser'):
        check_password.hasher = PBKDF2PasswordHasher()
    return check_password.hasher.verify(raw_password, encode_password)


def generate_xsrf_key():
    return hashlib.sha1(os.urandom(128)).hexdigest()


def generate_session_id():
    return hashlib.sha1(os.urandom(128)).hexdigest()


def encode_session(dict_data):
    raw_data = "tornado:" + json.dumps(dict_data)
    return base64.b64encode(raw_data.encode('utf-8'))


def decode_session(raw_data):
    return json.loads(str(base64.b64decode(raw_data), 'utf-8').split(':', 1)[-1])


if __name__ == "__main__":
    hf = PBKDF2PasswordHasher()
    out = hf.verify('Mycap@2017!@', 'pbkdf2_sha256$15000$OIK8X7jeSWMe$7lyrtd9BSglbqrgPwfZBrfjlVqchQbLC0oHQGjlatuU=')
    out1 = make_password('Mycap@2017!@')
    out2 = hf.verify('Mycap@2017!@', out1)
    print(out)
    print(out1)
    print(out2)

    out = encode_session({"abc": 123})
    print(out)

    s2 = "pbkdf2_sha256$100000$eQLd1lCnIJPf$koihFPoSRaQcLejNhNSKfwMlDqbm+F4rXNLwpsaZ4rU="
    s1 = "123456"

    h = check_password(s1, s2)
    print("h: ", h)

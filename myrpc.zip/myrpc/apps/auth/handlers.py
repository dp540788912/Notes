# -*- coding:utf-8 -*-

import datetime
import hashlib
import json
import random
import uuid

from sqlalchemy import or_
from sqlalchemy.sql import text
from tornado import gen
from tornado.web import RequestHandler

from celery_task.auth import tasks
from celery_task.tools import async_celery_call
from myrpc.apps.auth.auth_crypto import make_password
from myrpc.apps.auth.common import ListMixin, CreateMixin, DetailMixin, DeleteMixin, \
    CurrentUserMixin, JsonPayloadMixin, NegErrCode, \
    session_rds, connect_rds, MyHost
from myrpc.apps.auth.config import config, logger, OTC_REGISTER_USER_AUTH_REASON
from myrpc.apps.auth.db import session_context as mysql_sc
from myrpc.apps.auth.models import UserType, UserCredential, CredentialType, \
    Users, Accounts, UserTypeInfo, UserGroupInfo, UserGroup, Company, GroupsMenuOrder


class UserTypeHandler(ListMixin, JsonPayloadMixin, CreateMixin, RequestHandler):

    def initialize(self):
        self.model = UserType
        self.fields = {
            'name': 'name',
            'description': 'description',
        }


class UserTypeDetailHandle(DetailMixin, DeleteMixin, RequestHandler):

    def initialize(self):
        self.model = UserType


class CredentialTypeHandler(ListMixin, JsonPayloadMixin, CreateMixin, RequestHandler):

    def initialize(self):
        self.model = CredentialType
        self.fields = {
            'name': 'name',
        }


class CredentialTypeDetailHandle(DetailMixin, DeleteMixin, RequestHandler):

    def initialize(self):
        self.model = CredentialType


class UserListHandle(ListMixin, CurrentUserMixin, RequestHandler):

    def initialize(self):
        self.model = Users

    def prepare(self):
        self.get_current_user()

    def get(self, *args, **kwargs):
        res = []
        groups = []
        for g in self.current_user['groups']:
            groups.append(g['name'])
        with mysql_sc() as sc:
            lines = []
            if self.current_user.get('is_superuser', False):
                lines = sc.query(Users).filter(or_(
                    Users.audit_result == 0,
                    Users.is_audit == 0
                )).all()
            elif 'dvt' in groups or 'dvs' in groups:
                lines = sc.query(Users).filter(
                    Users.reason == OTC_REGISTER_USER_AUTH_REASON
                ).all()
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': sorted(res, key=lambda d: d['create_date'], reverse=True)
        }))


class RegisterHandle(JsonPayloadMixin, RequestHandler):

    def post(self, *args, **kwargs):
        payload = self.get_payload()
        try:
            with mysql_sc() as sc:
                data = {
                    'name': payload['name'],
                    'password': payload['password'],
                    'nickname': payload.get('nickname') or payload['name'],
                    'firstname': payload.get('firstname') or payload['name'],
                    'lastname': payload.get('lastname') or payload['name'],
                    'email': payload['email'],
                    'mobile_num': payload.get('mobile_num') or '',
                    'channel': payload.get('channel') or '',
                    'referer': payload.get('referer') or '',
                    'is_audit': False,
                    'is_active': False,
                    'experience': payload.get('experience') or '',
                    'advantage': payload.get('advantage') or '',
                    'wechat': payload.get('wechat') or '',
                    'chg_password': False,
                }
                for k in ['id', 'r_create_user_id', 'r_update_user_id']:
                    if k in payload:
                        data[k] = payload[k]
                if not data['mobile_num']:
                    del data['mobile_num']
                else:
                    if sc.query(Users).filter(Users.mobile_num == data['mobile_num']).first():
                        self.write(json.dumps({
                            'code': 2100,
                            'error': 'telephone number exists.',
                        }))
                        return
                    if sc.query(Users).filter(or_(Users.email == data['email'],
                                                  Users.name == data['name'])).first():
                        self.write({
                            'code': 2100,
                            'error': 'email or username already exist.'
                        })
                        return
                o = Users(**data)
                sc.add(o)
                for u_t_id in payload.get('role_ids', []):
                    ut = UserTypeInfo(
                        user_id=o.id,
                        user_type_id=int(u_t_id)
                    )
                    sc.add(ut)
                if payload.get('credential_type_id') and payload.get('credential_content'):
                    uc = UserCredential(
                        user_id=o.id,
                        credential_type_id=int(payload['credential_type_id']),
                        credential_content=payload['credential_content'],
                        default=True,
                    )
                    sc.add(uc)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class AuditHandle(CurrentUserMixin, JsonPayloadMixin, RequestHandler):
    def post(self, *args, **kwargs):
        self.get_current_user()
        payload = self.get_payload()
        try:
            with mysql_sc() as sc:
                o = sc.query(Users).filter_by(id=kwargs['id']).first()
                if o:
                    o.is_audit = True
                    o.audit_result = payload['audit_result']
                    o.auditor = self.current_user['id']
                    o.reason = payload['reason']
                    if payload.get('nickname'):
                        o.nickname = payload['nickname']
                    md5 = hashlib.md5()
                    md5.update(uuid.uuid4().hex.encode('utf8'))
                    active_code = md5.hexdigest()
                    o.active_code = active_code
                else:
                    self.write(json.dumps({
                        'code': 400,
                        'data': 'can not found user id=%s' % kwargs['id'],
                    }))
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': {
                        'active_code': active_code
                    },
                }))
                return
        except Exception as e:
            self.write(json.dumps({
                'code': 500,
                'data': str(e),
            }))


class CompanyManagerMixin(RequestHandler):
    def __init__(self, *args, **kwargs):
        super(CompanyManagerMixin, self).__init__(*args, **kwargs)
        self.customer_group = None

    def get_manager_groups(self):
        """
        fetch all the groups of current user only if
        :return:
        """
        with mysql_sc() as sc:
            if self.current_user.get('is_superuser', False):
                groups_ref = sc.query(UserGroupInfo).all()
            else:
                groups_ref = sc.query(UserGroupInfo).filter(UserGroupInfo.user_id == self.current_user['id']).all()

            # for grp_ref in groups_ref:
            #    print(grp_ref.user_group_obj.company_id, grp_ref.user_group_obj.type)

            company_ids = [grp_ref.user_group_obj.company_id
                           for grp_ref in groups_ref if grp_ref.user_group_obj.type == "manager" and
                           grp_ref.user_group_obj.company_id != -1]
            if not company_ids:
                return []
            groups = sc.query(UserGroup).filter(UserGroup.company_id.in_(company_ids)).all()
            if not groups:
                return []
            else:
                group_id_list = []
                for group in groups:
                    group_id_list.append(group.id)
                    if group.type == "customer":
                        self.customer_group = group.id
                return group_id_list

    @staticmethod
    def get_social_credit_code(user):
        for credential in user.user_credentials:
            # social_credit_code - 2, id_number -1
            # TODO: update const number
            if credential.credential_type_id == 2:
                return credential.credential_content
        return ''


class LogoHandler(MyHost, RequestHandler):
    def data_received(self, chunk):
        pass

    def get(self, *args, **kwargs):
        try:
            self.fetch_domain()
            with mysql_sc() as sc:
                cpy = sc.query(Company).filter(Company.domain == self.domain).first()
                if not cpy:
                    self.write({
                        'code': NegErrCode.REQ_NOT_VALID,
                        'error': 'domain not found'
                    })
                    return
                data = cpy.to_dict()
                self.write({
                    'code': NegErrCode.API_SUCCESS,
                    'data': data
                })
        except Exception as err:
            logger.error("some error happened in logo handler %s", err, exc_info=True)
            self.write({
                'code': NegErrCode.REQ_NOT_VALID,
                'error': 'domain not found'
            })


class CompanyHandler(JsonPayloadMixin, CurrentUserMixin, RequestHandler):
    def data_received(self, chunk):
        pass

    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user.get('is_superuser', False):
            self.write({
                'code': NegErrCode.PERMISSION_DENY,
                'error': '权限错误'
            })
            return
        companies = []
        with mysql_sc() as sc:
            cps = sc.query(Company).all()
            for company in cps:
                company_info = company.to_dict()
                company_info['groups'] = [
                    grp.to_dict() for grp in sc.query(UserGroup).filter(UserGroup.company_id == company.id).all()
                ]
                companies.append(company_info)

        self.write({
            'code': NegErrCode.API_SUCCESS,
            'data': companies
        })

    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user.get('is_superuser', False):
            self.write({
                'code': NegErrCode.PERMISSION_DENY,
                'error': '权限错误'
            })
            return
        try:
            payload = self.get_payload()
            name = payload['name']
            domain = payload.get('domain', '')
            logo = payload.get('logo', '')
            favicon = payload.get('favicon', '')
            description = payload.get('description')
            # create two group bind to the company
            with mysql_sc() as sc:
                c = Company(name=name, domain=domain, logo=logo, favicon=favicon)
                sc.add(c)
                sc.flush()
                if description:
                    c.description = description
                ug = UserGroup(name='%s_manager' % name, type="manager",
                               company_id=c.id, description='the %s manager' % name)
                sc.add(ug)
                ug = UserGroup(name='%s_customer' % name, type="customer",
                               company_id=c.id, description='the %s customer' % name)
                sc.add(ug)
                data = c.to_dict()
                data['groups'] = [
                    grp.to_dict() for grp in sc.query(UserGroup).filter(UserGroup.company_id == c.id).all()
                ]
            self.write({
                'code': NegErrCode.API_SUCCESS,
                'data': data
            })
        except Exception as err:
            logger.error("create company error payload: %s, error %s", payload, err)
            self.write({
                'code': NegErrCode.CREATE_FAILED,
                'error': '创建失败'
            })

    def put(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user.get('is_superuser', False):
            self.write({
                'code': NegErrCode.PERMISSION_DENY,
                'error': '权限错误'
            })
            return
        try:
            company_id = int(kwargs['id'])
            payload = self.get_payload()
            name = payload['name']
            domain = payload.get('domain', None)
            logo = payload.get('logo', None)
            description = payload.get('description', None)
            favicon = payload.get('favicon', None)
            with mysql_sc() as sc:
                cpy = sc.query(Company).filter(Company.id == company_id).first()
                if not cpy:
                    self.write({
                        'code': NegErrCode.ARGUMENT_NOT_VALID,
                        'error': '公司未找到 %s' % company_id
                    })
                    return
                if cpy.name != name:
                    # update the group name
                    m_dict = {"name": '%s_manager' % name, "description": 'the %s manager' % name}
                    sc.query(UserGroup).filter(UserGroup.company_id == cpy.id) \
                        .filter(UserGroup.type == 'manager') \
                        .update(m_dict, synchronize_session='fetch')
                    c_dict = {'name': '%s_customer' % name, 'description': 'the %s customer' % name}
                    sc.query(UserGroup).filter(UserGroup.company_id == cpy.id) \
                        .filter(UserGroup.type == 'customer') \
                        .update(c_dict, synchronize_session='fetch')
                    cpy.name = name
                    # sc.commit()
                if domain is not None:
                    cpy.domain = domain
                if description is not None:
                    cpy.description = description
                if logo is not None:
                    cpy.logo = logo
                if favicon is not None:
                    cpy.favicon = favicon
                data = cpy.to_dict()
                data['groups'] = [
                    grp.to_dict() for grp in sc.query(UserGroup).filter(UserGroup.company_id == cpy.id).all()
                ]
            self.write({
                'code': NegErrCode.API_SUCCESS,
                'data': data
            })
        except Exception as err:
            logger.error("put company error %s", err, exc_info=True)
            self.write({
                'code': NegErrCode.UPDATE_FAILED,
                'error': '修改失败 %s' % err
            })

    def delete(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user.get('is_superuser', False):
            self.write({
                'code': NegErrCode.PERMISSION_DENY,
                'error': '权限错误'
            })
            return
        self.write({
            'code': NegErrCode.NOT_FINISH_ERROR,
            'error': '暂不支持删除公司'
        })


class CompanyUserListHandler(JsonPayloadMixin, CurrentUserMixin, CompanyManagerMixin, RequestHandler):
    """
    provide create(POST) and list view(GET)
    """

    def get(self, *args, **kwargs):
        """
        fetch all company user
        :param args:
        :param kwargs:
        :return:
        """
        self.get_current_user()
        mgr_groups = self.get_manager_groups()
        if not mgr_groups and not self.current_user.get('is_superuser', False):
            self.write({
                'code': NegErrCode.PERMISSION_DENY,
                'error': '没有权限'
            })
            return
        try:
            role = self.get_argument('role', None)
            if role is None:
                # TODO, update this constant string
                filter_group_type = ["manager", "customer"]
            else:
                filter_group_type = [role]
            get_users = {}
            with mysql_sc() as sc:
                for grp_id in mgr_groups:
                    if self.current_user.get('is_superuser', False):
                        ug_rs = sc.query(UserGroupInfo).all()
                    else:
                        ug_rs = sc.query(UserGroupInfo).filter(UserGroupInfo.user_group_id == grp_id).all()
                    for ug_r in ug_rs:
                        if ug_r.user_group_obj.type not in filter_group_type:
                            continue
                        u = ug_r.user_obj
                        if u.id not in get_users:
                            get_users[u.id] = {
                                'name': u.name,
                                'description': u.description,
                                'address': u.address,
                                'linkman': u.linkman,
                                'telephone': u.telephone,
                                'email': u.email,
                                'social_credit_code': self.__class__.get_social_credit_code(u),
                                'groups': [
                                    grp.user_group_obj.to_dict() for grp in sc.query(UserGroupInfo).filter(
                                        UserGroupInfo.user_id == u.id
                                    ).all()
                                ]
                            }
            self.write({
                'code': NegErrCode.API_SUCCESS,
                'data': get_users
            })
        except Exception as err:
            logger.error("get company user list error %s", err)
            self.write({
                'code': NegErrCode.FETCH_FAILED,
                'error': '取数据失败'
            })

    def post(self, *args, **kwargs):
        """
        create one company user or manager user
        :param args:
        :param kwargs:
        :return:
        """
        self.get_current_user()
        payload = self.get_payload()
        try:
            data = {
                'r_create_user_id': self.current_user['id'],
                'r_update_user_id': self.current_user['id'],
                'name': payload['name'],
                'description': payload['description'],
                'address': payload.get('address', ''),
                'linkman': payload.get('linkman', ''),
                'telephone': payload.get('telephone', ''),
                'password': make_password(payload.get('password', config.DEFAULT_PASSWORD)),
            }
            if 'email' in payload:
                data['email'] = payload['email']
        except KeyError as err:
            logger.error("create manager or customer failed %s", err)
            self.write({
                'code': NegErrCode.ARGUMENT_NOT_VALID,
                'error': '键值错误'
            })
            return
        mgr_groups = self.get_manager_groups()
        if not mgr_groups and not self.current_user['is_superuser']:
            self.write({
                'code': NegErrCode.PERMISSION_DENY,
                'error': '没有权限'
            })
            return
        group_id = payload.get('group_id', None)
        if group_id is None:
            group_id = self.customer_group
        if group_id not in mgr_groups and not self.current_user['is_superuser']:
            self.write({
                'code': NegErrCode.ARGUMENT_NOT_VALID,
                'error': '组 id 错误'
            })
        try:
            with mysql_sc() as sc:
                # create user, make it safe
                data['is_superuser'] = False
                data['chg_password'] = True
                u = Users(**data)
                sc.add(u)
                sc.flush()
                customer_info = u.to_customer()
                # add credential
                if payload.get('social_credit_code', ''):
                    # TODO: improve this 2-social_credit_code, 1-id_number
                    uc = UserCredential(user_id=u.id, credential_type_id=2,
                                        credential_content=payload['social_credit_code'])
                    sc.add(uc)
                customer_info['social_credit_code'] = payload.get('social_credit_code', '')
                customer_info['group'] = group_id
                # bind user to group
                ug = UserGroupInfo(user_id=u.id, user_group_id=group_id)
                sc.add(ug)
            self.write({
                'code': NegErrCode.API_SUCCESS,
                'data': customer_info
            })
        except Exception as err:
            logger.error("create user failed %s", err)
            self.write({
                'code': NegErrCode.CREATE_FAILED,
                'error': '创建失败'
            })


class CompanyUserItemHandler(JsonPayloadMixin, CurrentUserMixin, CompanyManagerMixin, RequestHandler):
    """
    provide detail view(GET), update(PUT), delete(DELETE)
    """

    def __init__(self, *args, **kwargs):
        self.user_detail = {}
        self.manager_ids = []
        super(CompanyUserItemHandler, self).__init__(*args, **kwargs)

    def is_user_manage(self, user_id):
        self.manager_ids = self.get_manager_groups()
        with mysql_sc() as sc:
            ugis = sc.query(UserGroupInfo).filter(UserGroupInfo.user_id == user_id).all()
            if not ugis:
                if not self.current_user.get('is_superuser', False):
                    return False
                else:
                    user_one = sc.query(Users).filter(Users.id == user_id).first()
            else:
                user_one = ugis[0].user_obj
            self.user_detail = user_one.to_customer()
            self.user_detail['social_credit_code'] = self.__class__.get_social_credit_code(user_one)
            if self.current_user.get('is_superuser', False):
                self.user_detail['groups'] = [
                    grp.user_group_obj.to_dict() for grp in ugis
                ]
            else:
                self.user_detail['groups'] = [
                    grp.user_group_obj.to_dict() for grp in ugis if grp.user_group_id in self.manager_ids
                ]
        if self.user_detail.get('groups', False) or self.current_user.get('is_superuser', False):
            return True
        return False

    def permission_deny(self):
        self.write({
            'code': NegErrCode.PERMISSION_DENY,
            'error': '没有权限'
        })

    @staticmethod
    def set_credential(sc, user_id, key, value):
        # TODO: replace 1 to value key
        if sc.query(UserCredential).filter(UserCredential.user_id == user_id,
                                           UserCredential.credential_type_id == 2).all():

            sc.query(UserCredential) \
                .filter(UserCredential.user_id == user_id, UserCredential.credential_type_id == 2) \
                .update({'credential_content': value})
        else:
            uc = UserCredential(user_id=user_id, credential_type_id=2, credential_content=value)
            sc.add(uc)

    def get(self, *args, **kwargs):
        user_id = kwargs['id']
        self.get_current_user()
        if not self.is_user_manage(user_id):
            self.permission_deny()
            return
        logger.debug("return data %s", self.user_detail)
        self.write({
            'code': 0,
            'data': self.user_detail
        })

    def put(self, *args, **kwargs):
        user_id = kwargs['id']
        self.get_current_user()
        if not self.is_user_manage(user_id):
            self.permission_deny()
            return
        payload = self.get_payload()
        user_info = {}
        for key in ['name', 'description', 'address', 'linkman', 'telephone', 'email']:
            if key in payload:
                user_info[key] = payload[key]
        try:
            with mysql_sc() as sc:
                if user_info:
                    if user_id != self.current_user['id']:
                        user_info['chg_password'] = True
                    sc.query(Users).filter(Users.id == user_id).update(user_info)
                ret_info = sc.query(Users).filter(Users.id == user_id).first().to_customer()
                if 'social_credit_code' in payload and payload['social_credit_code']:
                    self.__class__.set_credential(sc, user_id, 'social_credit_code', payload['social_credit_code'])
                ret_info['social_credit_code'] = payload.get('social_credit_code', '')
                if 'group' in payload:
                    if not isinstance(payload['group'], list):
                        payload['group'] = [payload['group']]
                    for grp in payload['group']:
                        if grp not in self.manager_ids:
                            self.write({
                                'code': NegErrCode.ARGUMENT_NOT_VALID,
                                'error': '%s not valid' % grp
                            })
                            return
                    sc.query(UserGroupInfo).filter(UserGroupInfo.user_id == user_id).delete()
                    for group_id in payload['group']:
                        ugi = UserGroupInfo(user_id=user_id, user_group_id=group_id)
                        sc.add(ugi)
                ret_info['group'] = [grp.user_group_id
                                     for grp in sc.query(UserGroupInfo).filter(UserGroupInfo.user_id == user_id).all()]
            self.write({
                'code': NegErrCode.API_SUCCESS,
                'data': ret_info
            })
        except Exception as err:
            logger.error("rewrite user information failed %s", err)
            self.write({
                'code': NegErrCode.UPDATE_FAILED,
                'error': '更新失败'
            })

    def delete(self, *args, **kwargs):
        user_id = kwargs['id']
        self.get_current_user()
        if not self.is_user_manage(user_id):
            self.permission_deny()
            return
        try:
            with mysql_sc() as sc:
                # not delete the user's account information, it is not necessary!!!
                # delete user_credential
                sc.query(UserCredential).filter(UserCredential.user_id == user_id).delete()
                # delete user_group_info
                sc.query(UserGroupInfo).filter(UserGroupInfo.user_id == user_id).delete()
                # delete user_type_info
                sc.query(UserTypeInfo).filter(UserTypeInfo.user_id == user_id).delete()
                # delete user
                sc.query(Users).filter(Users.id == user_id).delete()
            self.write({
                'code': NegErrCode.API_SUCCESS,
                'data': '删除成功'
            })
        except Exception as err:
            logger.error("delete company user failed %s", err)
            self.write({
                'code': NegErrCode.DELETE_FAILED,
                'error': '删除失败'
            })


class ActiveHandle(JsonPayloadMixin, RequestHandler):

    def get(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                o = sc.query(Users).filter_by(id=kwargs['id']).first()
                active_code = self.get_argument('active_code', '')
                if o and active_code and (o.active_code == active_code):
                    self.write(json.dumps({
                        'code': 0,
                        'data': {},
                    }))
                else:
                    self.write(json.dumps({
                        'code': 400,
                        'data': 'can not found user id=%s' % kwargs['id'],
                    }))
        except Exception as e:
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))
            self.finish()


class AccountsHandle(JsonPayloadMixin, CurrentUserMixin, RequestHandler):

    def prepare(self):
        self.get_current_user()

    def is_stock_page(self):
        if self.get_argument('type', '') == 'stock':
            return True
        if 'type=stock' in self.request.headers.get('referer'):
            return True
        return False

    def is_future_page(self):
        if self.get_argument('type', '') == 'future':
            return True
        if 'type=future' in self.request.headers.get('referer'):
            return True
        return False

    def get(self, *args, **kwargs):
        get_all = self.get_argument('all', False)
        res = []
        with mysql_sc() as sc:
            if get_all:
                lines = sc.query(Accounts).all()
            else:
                r_create_user_ids = [self.current_user['id']]
                if self.is_stock_page():
                    r_create_user_ids.append(494)
                if self.is_future_page():
                    r_create_user_ids.append(495)
                lines = sc.query(Accounts).filter(
                    Accounts.user_id.in_(r_create_user_ids)
                ).all()
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        payload = self.get_payload()
        try:
            with mysql_sc() as sc:
                data = {
                    'r_create_user_id': self.current_user['id'],
                    'r_update_user_id': self.current_user['id'],
                    'name': payload['name'],
                    'password': Accounts.encrypt(payload['password']),
                    'fund_total': float(payload['fund_total']),
                    'fund_occupied': float(payload.get('fund_occupied', 0)),
                    'broker_id': int(payload['broker_id']),
                    'user_id': int(self.current_user['id']),
                    'valid': True,
                }
                accounts = sc.query(Accounts).filter_by(
                    name=payload['name'],
                    user_id=int(self.current_user['id'])
                ).first()
                if accounts:
                    self.write(json.dumps({
                        'code': 1013,
                        'error': 'accounts already exists',
                    }))
                    return
                o = Accounts(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class AccountsDetailHandle(JsonPayloadMixin, CurrentUserMixin, RequestHandler):

    def prepare(self):
        self.model = Accounts
        self.get_current_user()

    def post(self, *args, **kwargs):
        try:
            payload = self.get_payload()
            with mysql_sc() as sc:
                o = sc.query(Accounts).filter_by(id=kwargs['id'], user_id=self.current_user['id']).first()
                if o:
                    if 'password' in payload:
                        payload['password'] = Accounts.encrypt(payload['password'])
                    for k in ['name', 'password', 'fund_total', 'fund_occupied', 'broker_id', 'user_id', 'valid']:
                        if k in payload:
                            setattr(o, k, payload[k])
                    o.r_update_user_id = self.current_user['id']
                    sc.commit()
                    self.write(json.dumps({
                        'code': 0,
                        'data': o.to_dict(),
                    }))
                else:
                    self.write(json.dumps({
                        'code': 400,
                        'data': 'can not find accounts id=%s' % kwargs['id'],
                    }))
        except Exception as e:
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                sc.query(self.model).filter_by(id=kwargs['id'], user_id=self.current_user['id']).delete()
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': '删除成功'
                }))
        except Exception as e:
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class RoleAndCredentialHandle(RegisterHandle):
    def data_received(self, chunk):
        pass

    def get(self, *args, **kwargs):
        try:
            role, credential = [], []
            with mysql_sc() as sc:
                lines = sc.query(UserType).all()
                for line in lines:
                    role.append(line.to_dict())
                lines = sc.query(CredentialType).all()
                for line in lines:
                    credential.append(line.to_dict())
            res = {
                'code': 0,
                'data': {
                    'role': role,
                    'credential': credential,
                }
            }
            self.write(json.dumps(res))
        except Exception as err:
            logger.error("get role and credential failed %s", err)
            self.write(json.dumps({'code': 2000, 'error': err}))


class OptionalAuthHandler(JsonPayloadMixin, RequestHandler):
    def __write_redis(self):
        connect_rds()
        pre_cache = session_rds.get('optionalauth:code:%s' % self.user_json["id"])
        epoch_now = (datetime.datetime.now() - datetime.datetime(1970, 1, 1)).total_seconds()
        if pre_cache:
            if isinstance(pre_cache, bytes):
                pre_cache = pre_cache.decode()
            cache_msg = json.loads(pre_cache)
            if cache_msg['launch_time'] + 60 >= epoch_now:
                print(cache_msg['launch_time'], epoch_now)
                return False
        cache_msg = json.dumps({'code': self.random_code, 'launch_time': epoch_now})
        # keep random the code valid in 8 hours
        session_rds.setex('optionalauth:code:%s' % self.user_json["id"], cache_msg, 28800)
        return True

    def __check_submit_code(self, code):
        connect_rds()
        pre_cache = session_rds.get('optionalauth:code:%s' % self.user_json["id"])
        if pre_cache:
            if isinstance(pre_cache, bytes):
                pre_cache = pre_cache.decode()
            cache_msg = json.loads(pre_cache)
            if cache_msg['code'] == code:
                return 0, "验证通过"
            else:
                return 212, "验证码错误"
        return 213, "验证码过期"

    def __query_user(self, username):
        with mysql_sc() as sc:
            o = sc.query(Users).filter_by(name=username).first()
            if o:
                self.user_json = o.to_dict()
            else:
                self.user_json = None

    def __generate_random_code(self):
        self.random_code = random.randint(100000, 999999)

    def __construct_message(self, type, code):
        return "[茂源资本] 您的%s验证码是 %s ，8小时内有效。若非本人发送，请忽略此信息。本信息免费。" % (type, code)

    @gen.coroutine
    def __send_email(self):
        message = self.__construct_message("邮箱", self.random_code)
        if self.user_json["email"]:
            return async_celery_call(tasks.notify_email, [self.user_json["email"]], message)
        return False

    @gen.coroutine
    def __send_sms(self):
        message = self.__construct_message("短信", self.random_code)
        if self.user_json["mobile_num"]:
            return async_celery_call(tasks.notify_sms, [self.user_json["mobile_num"]], message)
        return False

    @gen.coroutine
    def __send_wx(self):
        message = self.__construct_message("微信", self.random_code)
        print(self.user_json)
        if self.user_json["wechat"]:
            return async_celery_call(tasks.notify_wechat, [self.user_json["wechat"]], message)
        return False

    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        :param args:
        :param kwargs: {"username": "abc", "type": "email|sms|wechat"}
        :return: return failed if username not exist or success code
        """
        username = self.get_argument("username", "")
        notify_type = self.get_argument("type", "wechat")
        exec_func = {
            "email": self.__send_email,
            "sms": self.__send_sms,
            "wechat": self.__send_wx,
        }
        self.__query_user(username)
        if not self.user_json:
            # user not found
            self.finish(json.dumps({
                'code': 211,
                'error': '用户名未找到'
            }))
            return
        self.__generate_random_code()
        if not self.__write_redis():
            self.finish(json.dumps({
                'code': 500,
                'error': '请求过频，请一分钟后再尝试!!!'
            }))
            return
        status = yield exec_func[notify_type]()
        if not status:
            self.write(json.dumps({
                'code': 500,
                'error': "发送消息失败"
            }))
        else:
            self.write(json.dumps({
                'code': 0,
                'data': '通知成功'
            }))

    def post(self, *args, **kwargs):
        """
        :param args:
        :param kwargs:
        :return: if valid return success or return failed
        """
        payload = self.get_payload()
        username = payload.get('username', None)
        code = payload.get('code', None)
        if username and code:
            self.__query_user(username)
            code, error = self.__check_submit_code(code)
            if code == 0:
                self.write(json.dumps({
                    'code': 0,
                    'data': 'code is valid'
                }))
            else:
                self.write(json.dumps({
                    'code': code,
                    'error': error
                }))
        else:
            self.write(json.dumps({
                'code': 500,
                'error': 'username or code is empty'
            }))


class UserPermissionHandler(CurrentUserMixin, RequestHandler):

    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            self.write(json.dumps({
                'code': 0,
                'data': {
                    'permission': False
                }
            }))
        with mysql_sc() as sc:
            sql = text("""select ugp.id from user_group_permission ugp, user_group_info ugi
            where ugi.user_group_id = ugp.user_group_id and ugi.user_id= :user_id and ugp.group_permission=:group_permission
            """)

            p = sc.execute(
                sql, {'user_id': self.current_user['id'], 'group_permission': kwargs['id']}
            ).fetchone()
            self.write(json.dumps({
                'code': 0,
                'data': {
                    'permission': bool(p)
                }
            }))


class AdminGroupsMenuHandler(JsonPayloadMixin, CurrentUserMixin, RequestHandler):
    # we may need to create post method
    def data_received(self, chunk):
        pass

    def get(self, *args, **kwargs):
        """
        :param args:
        :param kwargs:
        :return: [{
            "group_ids": [1,2,3],
            "group_names": ["name1", "name2", "name3"],
            "description": "none",
            "users": [{
                "id": 1, "name": "root"
            }]
            "menu":[
                {
                    "id": 1,
                    "name": "bb",
                    "submenu": [
                        {"id": 2, "name": "aa", "url": "/index.html"}
                    ]
                }
            ]
        }]
        """
        if not self.get_current_user():
            return
        if not self.current_user.get('is_superuser', False):
            self.write({
                'code': NegErrCode.PERMISSION_DENY,
                'error': '权限错误'
            })
            return
        map_comb = GroupsMenuOrder.get_all_comb_grp()
        ret_msg = []
        for k, v in map_comb.items():
            ret = GroupsMenuOrder.fetch(k)
            ret.update(v)
            ret_msg.append(ret)
        self.write({
            'code': 0,
            'data': ret_msg
        })

    def put(self, *args, **kwargs):
        """
        {
            "group_ids": [1,2,3],
            "group_names": ["name1", "name2", "name3"],
            "description": "none",
            "users": [{
                "id": 1, "name": "root"
            }]
            "menu":[
                {
                    "id": 1,
                    "name": "bb",
                    "submenu": [
                        {"id": 2, "name": "aa", "url": "/index.html"}
                    ]
                }
            ]
        }
        :param args:
        :param kwargs:
        :return:
        """
        ids = self.get_my_key("groupid")
        if not isinstance(ids, list) or len(ids) < 2:
            self.write({
                'code': NegErrCode.ARGUMENT_NOT_VALID,
                'error': 'group_ids %s not valid' % ids
            })
            return
        # desc = self.get_my_key("description")
        desc = ''
        menu = self.get_my_key("menu")
        # groups = self.get_my_key("group_names")
        # users = self.get_my_key("users")
        ret = GroupsMenuOrder.update(ids, desc, menu)
        if ret == 0:
            self.write({
                'code': 0,
                'data': {
                    'groupid': ids,
                    # 'group_names': groups,
                    # 'users': users,
                    'description': desc,
                    'menu': menu,
                }
            })
        else:
            self.write({
                'code': NegErrCode.SERVER_INTERNAL_ERROR,
                'error': "服务器内部错误"
            })

# GET  /api/v1/companies
# POST /api/v1/companies

# GET  /api/v1/company/users
# POST /api/v1/company/users

# GET /api/v1/company/user/<id>
# PUT /api/v1/company/user/<id>
# DELETE /api/v1/company/user/<id>

# GET /api/v1/auth/usertype
# POST /api/v1/auth/usertype
# DELETE /api/v1/auth/usertype/<usertype_id>

# GET /api/v1/auth/credentialtype
# POST /api/v1/auth/credentialtype
# DELETE /api/v1/auth/credentialtype/<credentialtype_id>

# GET /api/v1/auth/user
# POST /api/v1/auth/user/register
# POST /api/v1/auth/user/audit/<user_id>
# GET /api/v1/auth/user/active/<user_id>

# POST /api/vi/auth/user/<user_id>
# POST /api/vi/auth/user/changepasswd/<user_id>
# POST /api/vi/auth/session
# DELETE /api/vi/auth/session

# GET /api/v1/auth/accounts
# POST /api/v1/auth/accounts
# POST /api/v1/auth/accounts/<account_id>
# DELETE /api/v1/auth/accounts/<account_id>

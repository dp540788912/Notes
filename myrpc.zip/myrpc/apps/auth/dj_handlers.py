# -*- coding: utf-8 -*-
# @Time    : 2018/5/22 2:39 PM
# @Author  : Colin
# @File    : dj_handlers.py.py
# @Email   : zhouchaolin@mycapital.net

import functools
import hashlib
import json
import os
import random
import string
import uuid

import tornado.web
from sqlalchemy import or_
from tornado import gen

from celery_task import client
from celery_task.auth import tasks
from celery_task.tools import async_celery_call
from myrpc.apps.auth.auth_crypto import check_password, generate_xsrf_key, encode_session, decode_session, \
    make_password, PBKDF2PasswordHasher
from myrpc.apps.auth.common import CurrentUserMixin, JsonPayloadMixin, NegErrCode, MyHost, clear_wx_cache
from myrpc.apps.auth.config import logger, redis_conn, SESSION_TIMEOUT, DEFAULT_PASSWORD, config, \
    OTC_REGISTER_USER_AUTH_REASON, OTC_SAMPLE_USER_AUTH_REASON
from myrpc.apps.auth.db import session_context as mysql_sc
from myrpc.apps.auth.models import Users, UserGroup, GroupMenu, UserGroupInfo, Menu, Company, GroupsMenuOrder, \
    OTCWxUserInfo
from myrpc.apps.auth.tracker import for_all_req_methods, api_tracker

GUOXINADMIN_IDS = [543]
GUOXIN_USERS = [543, 521]
GUOXIN_GROUP_IDS = [34]
GUOXIN_MENU_IDS = [4, 31, 40, 51, 52, 53, 54]


class RedisBackend:
    def __init__(self):
        self.conn = redis_conn

    def __getitem__(self, key):
        return self.conn.get(key)

    def __setitem__(self, key, value, timeout=SESSION_TIMEOUT):
        return self.conn.setex(key, value, timeout)

    def __delitem__(self, key):
        self.conn.delete(key)

    def set_kv(self, key, value):
        return self.conn.set(key, value)

    def setex(self, key, value, timeout):
        return self.conn.setex(key, value, timeout)

    def get_k(self, key):
        return self.conn.get(key)

    def del_k(self, key):
        return self.conn.delete(key)


class SessionData(dict):
    def __init__(self, *args, **kwargs):
        super(SessionData, self).__init__(*args, **kwargs)

    def __getitem__(self, key):
        return super(SessionData, self).__getitem__(key)

    def __setitem__(self, key, value):
        return super(SessionData, self).__setitem__(key, value)

    def __delete__(self, key):
        return super(SessionData, self).__delete__(key)

    def update(self, e=None, **f):
        return super(SessionData, self).update(e, **f)

    def clear(self):
        return super(SessionData, self).clear()


def redis_session(request):
    @functools.wraps(request)
    def process(self, *args, **kwargs):
        # session store in the redis
        sessionid = self.get_cookie('sessionid', '')
        self.session_id = 'session:%s' % sessionid
        item = None
        if sessionid:
            item = self.application.backend.__getitem__(self.session_id)

        # wx login, try to get session info from openid
        if not item:
            openid = self.get_cookie('openid', '')
            if openid:
                self.openid = 'openid:%s' % openid
                item = self.application.backend.__getitem__(self.openid)

        if item:
            parse_item = decode_session(item)
            data = SessionData()
            data.update(parse_item)
        else:
            data = SessionData()

        # load the data into handler.session
        self.session = data
        # print("before", self.session, id(self.session))
        # if possible, update date the data in handler.session
        request(self, *args, **kwargs)
        # print("after", self.session, id(self.session))

    return process


class MyBaseHandler(tornado.web.RequestHandler):

    def __init__(self, *args, **kwargs):
        super(MyBaseHandler, self).__init__(*args, **kwargs)
        self.session = {}
        self.session_id = None

    def data_received(self, chunk):
        pass

    def initialize(self):
        self.application.backend = RedisBackend()

    def check_xsrf_cookie(self):
        pass

    def permission_deny(self):
        self.write_return({
            'code': NegErrCode.PERMISSION_DENY,
            'error': '用户无权限'
        })
        self.finish()

    def execute_success(self):
        self.write_return({
            'code': NegErrCode.API_SUCCESS,
            'data': 'operate success',
        })
        self.finish()

    def request_not_valid(self, error=None):
        self.write_return({
            'code': NegErrCode.REQ_NOT_VALID,
            'error': '请求不合法' if not error else error
        })

    def update_session(self, data):
        if not isinstance(data, dict):
            return
        valid_data = False
        for key, value in data.items():
            if key in self.session:
                valid_data = True
                self.session[key] = value
        if not self.get_cookie('sessionid'):
            return
        if valid_data:
            data = encode_session(self.session)
            key = 'session:%s' % self.get_cookie('sessionid')
            self.application.backup.__setitem__(key, data)

    def write_return(self, json_msg):
        try:
            self.write(json.dumps(json_msg))
        except TypeError as err:
            logger.error("json %s encode error %s", json_msg, err)
            self.write({
                'code': NegErrCode.SERVER_INTERNAL_ERROR,
                'error': '服务器内部错误'
            })
        finally:
            self.finish()

    def is_guoxin_admin(self):
        return self.current_user and self.current_user.get('id') in GUOXINADMIN_IDS


class CSRFHandler(MyBaseHandler):
    """
    Write some CSRF token into the cookie
    """

    def get(self):
        xsrf_key = generate_xsrf_key()
        self.set_cookie('csrftoken', xsrf_key)
        self.write_return({
            'code': NegErrCode.API_SUCCESS,
            'data': xsrf_key
        })


@for_all_req_methods(api_tracker)
class LoginHandler(MyHost, JsonPayloadMixin, MyBaseHandler):
    """
    Process user login and logout
    """

    def enterprise_auth_check(self, sc, user):
        # if it is an enterprise user then need the recheck the
        # TODO, make mycapital as an company store in database
        if config.DEBUG:
            return True
        if user.user_groups:
            company_id = user.user_groups[0].user_group_obj.company_id
            if company_id != -1:
                company = sc.query(Company).filter(Company.id == company_id).first()
                self.fetch_domain()
                if self.domain != company.domain:
                    self.write_return({
                        'code': NegErrCode.REQ_DOMAIN_ERROR,
                        'error': '访问域名错误'
                    })
                    return False
        return True

    @redis_session
    def post(self, *args, **kwargs):
        """ login """
        username = self.get_my_key('username')
        if not username:
            self.request_not_valid()
            return

        xsrf = self.get_cookie('csrftoken')
        if not xsrf:
            self.request_not_valid('xsrf 错误')
            return

        xsrf = xsrf if isinstance(xsrf, str) else xsrf.decode('utf-8')

        # sessionid check exist, then load the session directly
        if '_auth_user_id' in self.session:
            session_ok = True
            for key in ['admin', 'type', 'chg_password', 'company_id']:
                if key not in self.session:
                    session_ok = False
                    break
            if session_ok:
                self.write_return({
                    'code': NegErrCode.API_SUCCESS,
                    'data': {
                        'id': int(self.session['_auth_user_id']),
                        'username': self.session['_auth_user_name'],
                        'nickname': self.session['_auth_user_nickname'],
                        'csrf': xsrf,
                        'admin': self.session['admin'],
                        'type': self.session['type'],
                        'chg_password': self.session['chg_password'],
                        'company_id': self.session['company_id'],
                        'auto_uid': self.session['auto_uid'],
                        'groups': self.session['groups'],
                    }
                })
                return
            else:
                # if session not valid then force to login again
                self.session_id = 'session:%s' % self.get_cookie('sessionid')
                self.session.clear()
                self.application.backend.del_k(self.session_id)
        # session not exist or not correct
        with mysql_sc() as sc:
            find_user = sc.query(Users).filter(or_(Users.name == username,
                                                   Users.email == username,
                                                   Users.auto_uid == username)).first()
            if find_user:
                if not find_user.is_active:
                    self.write_return({
                        'code': NegErrCode.NEED_TO_ACTIVATE,
                        'error': '账户未激活，请查阅邮件激活账户或耐心等待审核',
                    })
                    return
            else:
                self.request_not_valid('账户不存在')
                return

            # TODO: enterprise check
            # if not self.enterprise_auth_check(sc, find_user):
            #     return

            password = self.get_my_key('password')
            if check_password(password, find_user.password):
                # write session data to self session attribute
                self.session['_auth_user_id'] = find_user.id
                self.session['_auth_user_name'] = find_user.name
                self.session['_auth_user_nickname'] = find_user.nickname
                self.session['chg_password'] = find_user.chg_password
                self.session['admin'] = find_user.is_superuser
                self.session['auto_uid'] = find_user.auto_uid

                if find_user.name == 'root':
                    self.session['type'] = 'superuser'
                    self.session['company_id'] = -1
                elif find_user.user_groups:
                    # self.session['company_id'] = find_user.user_groups[0].user_group_obj.company_id
                    # self.session['type'] = find_user.user_groups[0].user_group_obj.type
                    company_id = -1
                    user_type = None
                    for item in find_user.user_groups:
                        if item.user_group_obj.company_id != -1:
                            company_id = item.user_group_obj.company_id
                            user_type = item.user_group_obj.type
                            break
                    self.session['company_id'] = company_id
                    self.session['type'] = user_type
                else:
                    self.session['company_id'] = -1
                    self.session['type'] = 'default'

                self.session['groups'] = [
                    {
                        'id': g.user_group_obj.id,
                        'name': g.user_group_obj.name
                    } for g in
                    sc.query(UserGroupInfo).filter(UserGroupInfo.user_id == find_user.id).order_by(
                        UserGroupInfo.id.desc())
                ]

                sessionid = str(uuid.uuid1())
                if config.DEBUG:
                    self.set_cookie("sessionid", sessionid)
                else:
                    self.set_cookie("sessionid", sessionid, domain='mycapital.net')
                openid = self.get_cookie('openid')
                if openid:
                    # logger.info('login, openid: %s, user_id: %d, name: %s', openid, find_user.id, find_user.name)
                    self.openid = 'openid:%s' % openid
                    self.application.backend.__setitem__(self.openid, encode_session(self.session))
                    OTCWxUserInfo.save_user_id(openid, find_user.id)

                # session update to redis
                self.session_id = 'session:%s' % sessionid
                self.application.backend.__setitem__(self.session_id, encode_session(self.session))

                self.write_return({
                    'code': NegErrCode.API_SUCCESS,
                    'data': {
                        'id': find_user.id,
                        'username': find_user.name,
                        'nickname': find_user.nickname,
                        'csrf': xsrf,
                        'admin': find_user.is_superuser,
                        'type': self.session['type'],
                        'chg_password': self.session['chg_password'],
                        'auto_uid': self.session['auto_uid'],
                        'groups': self.session['groups'],
                    }
                })
            else:
                self.write_return({
                    'code': NegErrCode.NAME_OR_PASSWORD_ERROR,
                    'error': '用户名或密码错误'
                })

    @redis_session
    def delete(self, *args, **kwargs):
        """ logout """
        # clear cookie
        # print("the session is ", self.session)
        if '_auth_user_id' in self.session:
            # for api tracker
            self.current_user = {'id': self.session['_auth_user_id']}
            self.session_id = 'session:%s' % self.get_cookie('sessionid')
            self.application.backend.del_k(self.session_id)

            openid = self.get_cookie('openid')
            if openid:
                # logger.info('logout, openid: %s, user_id: %d, name: %s', openid, self.session['_auth_user_id'],
                #             self.session['_auth_user_name'])
                self.openid = 'openid:%s' % openid
                self.application.backend.del_k(self.openid)
                OTCWxUserInfo.del_user_id(openid)

            self.session.clear()
            # print("after clear", self.session)
            self.clear_cookie("csrftoken")
            self.clear_cookie("sessionid")
            self.write_return({
                'code': NegErrCode.API_SUCCESS,
                'data': '退出成功'
            })
        else:
            self.write({
                'code': NegErrCode.NOT_LOGIN,
                'error': '用户没有登录'
            })


class HomepageHandler(CurrentUserMixin, JsonPayloadMixin, MyBaseHandler):
    """
    Manage the role home page(only the root or manage can visit)
    """

    def get(self, *args, **kwargs):
        """ [{
            'id': g.id,
            'name': g.name,
            'home': home_page
        }]
        """
        if not self.get_current_user():
            return
        with mysql_sc() as sc:
            data = {}
            all_grp = sc.query(UserGroupInfo).filter(UserGroupInfo.user_id == self.current_user['id']).all()
            for ugi in all_grp:
                data[ugi.user_group_obj.id] = {
                    'id': ugi.user_group_obj.id,
                    'name': ugi.user_group_obj.name,
                    'home_page': ''
                }
            if data:
                for grp in sc.query(UserGroup).filter(UserGroup.id.in_(list(data.keys()))).all():
                    # data[grp.id]['home_page'] = grp.home_page
                    data[grp.id]['home_page'] = '/user/home.html' if not grp.home_page else grp.home_page
        return self.write_return({
            'code': NegErrCode.API_SUCCESS,
            'data': sorted(data.values(), key=lambda _x: _x['id'], reverse=True)
        })

    def post(self, *args, **kwargs):
        """
        change the group's main page, this need group_id and new home_page message
        """
        if not self.get_current_user():
            return
        if not self.current_user.get('is_superuser', False):
            self.permission_deny()
            return
        group_id = self.get_my_key('group_id')
        home_page = self.get_my_key('home_page')

        try:
            with mysql_sc() as sc:
                sc.query(UserGroup).filter(UserGroup.id == group_id).update({"home_page": home_page})
                self.write_return({
                    'code': NegErrCode.API_SUCCESS,
                    'data': '设置主页成功'
                })
        except Exception as err:
            logger.error("home page post error %s", err, exc_info=True)
            self.write_return({
                'code': NegErrCode.REQ_NOT_VALID,
                'data': '修改或创建主页失败'
            })


class AdminUserHandler(CurrentUserMixin, JsonPayloadMixin, MyBaseHandler):
    """
    django original user management api, get, put, post, delete, this api only provided for superuser
    """

    def get(self, *args, **kwargs):
        if not self.get_current_user():
            return
        # all_groups = self.get_argument('show_groups', None)
        if self.current_user.get('is_superuser', False) or self.is_guoxin_admin():
            ul = []
            with mysql_sc() as sc:
                if self.is_guoxin_admin():
                    all_u = sc.query(Users).filter(
                        or_(
                            Users.id.in_(GUOXIN_USERS),
                            Users.r_create_user_id.in_(GUOXINADMIN_IDS),
                        )
                    ).all()
                else:
                    all_u = sc.query(Users).all()
                for u in all_u:
                    groups = [g.user_group_obj.name for g in u.user_groups]
                    groups_id = [g.user_group_obj.id for g in u.user_groups]
                    ul.append({
                        'id': u.id,
                        'username': u.name,
                        'email': u.email,
                        'group': groups if groups else [],
                        'groupid': groups_id if groups_id else [],
                        'mobile_num': u.mobile_num,
                        'wechat': u.wechat,
                        'experience': u.experience,
                        'advantage': u.advantage,
                        'organization': u.organization,
                        'department': u.department,
                        'position': u.position,
                        'enable_notebook': u.enable_notebook,
                    })
            return self.write({
                'code': NegErrCode.API_SUCCESS,
                'data': ul
            })
        else:
            self.permission_deny()

    def post(self, *args, **kwargs):
        if not self.get_current_user():
            return
        if self.current_user.get('is_superuser', False) or self.is_guoxin_admin():
            try:
                with mysql_sc() as sc:
                    name = self.get_my_key('username')
                    email = self.get_my_key('email')
                    password = self.get_my_key('password', DEFAULT_PASSWORD)
                    user = sc.query(Users).filter(or_(Users.name == name, Users.email == email)).first()
                    if user:
                        self.write_return({
                            'code': NegErrCode.USER_ALREADY_EXIST,
                            'error': '用户名或邮箱已存在'
                        })
                        return
                    mobile = self.get_my_key('mobile', '')
                    if mobile:
                        user = sc.query(Users).filter(Users.mobile_num == mobile).first()
                        if user:
                            self.write_return({
                                'code': NegErrCode.CUSTOM_ERROR,
                                'error': '手机号已存在',
                            })
                            return
                    enable_notebook = self.get_my_key('enable_notebook', False)
                    logger.debug("received enable_notebook is %s", enable_notebook)
                    if enable_notebook not in (True, False):
                        enable_notebook = False
                    u = Users(name=name, email=email, password=make_password(password),
                              chg_password=True, is_active=True,
                              enable_notebook=enable_notebook)
                    sc.add(u)
                    # make u.id accessible
                    sc.flush()
                    group_id = self.get_my_key('group', None)
                    if enable_notebook:
                        # copy the notebook directory
                        target = os.path.join(config.NOTEBOOK_HOME, '%s_%s' % (u.id, name))
                        source = os.path.join(config.NOTEBOOK_HOME, "user_template")
                        vm_id = Users.get_max_vmid(u.id)
                        tasks.prepare_notebook_env.delay(source, target, vm_id, name)
                    if group_id:
                        if isinstance(group_id, str):
                            group_id = group_id.split(',')
                        if not isinstance(group_id, list):
                            group_id = [group_id]
                        for gid in set(group_id):
                            ug = UserGroupInfo(user_id=u.id, user_group_id=int(gid))
                            sc.add(ug)
                    self.write({
                        'code': NegErrCode.API_SUCCESS,
                        'data': '创建用户成功'
                    })
            except Exception as err:
                logger.error("admin new user failed %s", err, exc_info=True)
                self.write({
                    'code': NegErrCode.CREATE_FAILED,
                    'error': '新建用户失败'
                })
        else:
            self.permission_deny()

    def delete(self, *args, **kwargs):
        if not self.get_current_user():
            return
        if self.current_user.get('is_superuser', False) or self.is_guoxin_admin():
            try:
                user_id = int(kwargs['id'])
                if user_id == self.current_user.get('id'):
                    self.write({
                        'code': NegErrCode.ARGUMENT_NOT_VALID,
                        'error': '不能删除管理员'
                    })
                    return
                with mysql_sc() as sc:
                    u = sc.query(Users).filter(Users.id == user_id).first()
                    if not u:
                        self.write({
                            'code': NegErrCode.USER_NOT_FOUND,
                            'error': '用户未找到'
                        })
                        return
                    if u.email.endswith('@mycapital.net'):
                        self.write({
                            'code': NegErrCode.CUSTOM_ERROR,
                            'error': '内部用户删除请联系技术部'
                        })
                        return
                    for ug in u.user_groups:
                        sc.delete(ug)
                    for ut in u.user_types:
                        sc.delete(ut)
                    for uc in u.user_credentials:
                        sc.delete(uc)
                    sc.delete(u)
                self.write({
                    'code': NegErrCode.API_SUCCESS,
                    'data': '删除用户成功'
                })
            except Exception as err:
                logger.error("delete user failed %s", err, exc_info=True)
                self.write({
                    'code': NegErrCode.DELETE_FAILED,
                    'error': '删除失败'
                })
        else:
            self.permission_deny()

    def put(self, *args, **kwargs):
        if not self.get_current_user():
            return

        if self.current_user.get('is_superuser', False) or self.is_guoxin_admin():
            try:
                user_id = int(kwargs['id'])
                with mysql_sc() as sc:
                    user = sc.query(Users).filter(Users.id == user_id).first()
                    if not user:
                        self.write({
                            'code': NegErrCode.USER_NOT_FOUND,
                            'error': '用户未找到'
                        })
                        return
                    username = self.get_my_key('username')
                    email = self.get_my_key('email')
                    group_id = self.get_my_key('group')
                    enable_notebook = self.get_my_key('enable_notebook', None)
                    if enable_notebook is not None:
                        user.enable_notebook = enable_notebook
                        if enable_notebook:
                            target = os.path.join(config.NOTEBOOK_HOME, '%s_%s' % (user_id, username))
                            source = os.path.join(config.NOTEBOOK_HOME, "user_template")
                            vm_id = Users.get_max_vmid(user_id)
                            tasks.prepare_notebook_env.delay(source, target, vm_id, username)
                    user.name = username
                    user.email = email
                    sc.query(UserGroupInfo).filter(UserGroupInfo.user_id == user_id).delete()
                    if group_id is not None:
                        if not isinstance(group_id, list):
                            group_id = [group_id]
                        for g_id in group_id:
                            try:
                                one_id = int(g_id)
                                ug = UserGroupInfo(user_id=user_id, user_group_id=one_id)
                                sc.merge(ug)
                            except:
                                pass
                self.write({
                    'code': NegErrCode.API_SUCCESS,
                    'data': '修改成功'
                })
            except tornado.web.MissingArgumentError as err:
                self.write({
                    'code': NegErrCode.ARGUMENT_PARSE_ERROR,
                    'data': "输入参数错误 %s" % str(err)
                })
            except Exception as err:
                logger.error("admin edit user failed %s", err, exc_info=True)
                self.write({
                    'code': NegErrCode.UPDATE_FAILED,
                    'error': '修改失败'
                })
        else:
            self.permission_deny()


class GroupHandler(CurrentUserMixin, JsonPayloadMixin, MyBaseHandler):
    """
    1. view all the groups(only the the authorized people can do this)
    2. put and delete specified group
    """

    def __init__(self, *args, **kwargs):
        super(GroupHandler, self).__init__(*args, **kwargs)
        self.group_id = None

    def argument_valid(self, **kwargs):
        self.group_id = kwargs.get('id', None)
        if self.group_id is None:
            self.write_return({
                'code': NegErrCode.REQ_NOT_VALID,
                'error': 'group id not valid'
            })
            return False
        return True

    def get(self, *args, **kwargs):
        if not self.get_current_user():
            return
        data = {}
        if self.current_user.get('is_superuser', False) or self.is_guoxin_admin():
            # all group information
            with mysql_sc() as sc:

                if self.is_guoxin_admin():
                    all_group = sc.query(UserGroup).filter(
                        or_(
                            UserGroup.id.in_(GUOXIN_GROUP_IDS),
                            UserGroup.r_create_user_id.in_(GUOXINADMIN_IDS),
                        )
                    ).all()
                else:
                    all_group = sc.query(UserGroup).all()

                for row in all_group:
                    data[row.id] = {
                        'id': row.id,
                        'name': row.name,
                        'menu': [menu.menu_id for menu in sc.query(GroupMenu).filter_by(user_group_id=row.id)],
                        'home_page': row.home_page
                    }
        else:
            # all manager group information
            user_id = self.current_user.get('user_id')
            with mysql_sc() as sc:
                user = sc.query(Users).filter(Users.id == user_id).first()
                for grp in user.user_groups:
                    if grp.type == "manager":
                        data[grp.id] = {
                            'id': grp.id,
                            'name': grp.name,
                            'menu': [menu.id for menu in sc.query(GroupMenu).filter(GroupMenu.group_id == grp.id)],
                            'home_page': grp.home_page
                        }
                        nor_groups = sc.query(UserGroup).filter(UserGroup.company_id == grp.id,
                                                                UserGroup.id != grp.id).all()
                        for nor_group in nor_groups:
                            data[nor_group.id] = {
                                'id': nor_group.id,
                                'name': nor_group.name,
                                'menu': [m.id for m in sc.query(GroupMenu).filter(GroupMenu.group_id == nor_group.id)],
                                'home_page': nor_group.home_page
                            }
        self.write({
            'code': NegErrCode.API_SUCCESS,
            'data': list(data.values())
        })

    def delete(self, *args, **kwargs):
        if not self.get_current_user():
            return
        if not self.argument_valid(**kwargs):
            return
        group_id = int(self.group_id)
        # only allow root to delete group
        if self.current_user.get('is_superuser', False):
            try:
                with mysql_sc() as sc:
                    sc.query(UserGroupInfo).filter(UserGroupInfo.user_group_id == group_id).delete()
                    sc.query(GroupMenu).filter(GroupMenu.user_group_id == group_id).delete()
                    sc.query(UserGroup).filter(UserGroup.id == group_id).delete()
                self.write_return({
                    'code': NegErrCode.API_SUCCESS,
                    'data': '删除组成功',
                })
            except Exception as err:
                logger.error("delete the group failed %s", err, exc_info=True)
                self.write_return({
                    'code': NegErrCode.DELETE_FAILED,
                    'error': '删除失败'
                })
        else:
            self.permission_deny()

    def manager_put(self):
        try:
            group_id = int(self.group_id)
            user_id = self.current_user['id']
            payload = self.get_payload()
            group_name = payload.get('group', '')
            home_page = payload.get('home_page', '')
            permission_ids = payload.get('permissions')
            with mysql_sc() as sc:
                ugi = sc.query(UserGroupInfo).filter(UserGroupInfo.user_group_obj.type == "manager",
                                                     UserGroupInfo.user_id == user_id,
                                                     UserGroupInfo.user_group_id == group_id).first()
                if not ugi:
                    self.permission_deny()
                    return
                else:
                    group = sc.query(UserGroup).filter(UserGroup.id == group_id).first()
                    if not group:
                        self.request_not_valid("找不到group_id %s" % group_id)
                        return
                    sc.query(GroupMenu).filter(GroupMenu.user_group_id == group_id).delete()
                    for perm in permission_ids:
                        group_menu = GroupMenu(user_group_id=group_id, menu_id=perm)
                        sc.merge(group_menu)
                    if group.name != group_name:
                        group.name = group_name
                    if group.home_page != home_page:
                        group.home_page = home_page
            self.write_return({
                'code': NegErrCode.API_SUCCESS,
                'data': {
                    'id': group_id,
                    'name': group_name,
                    'permissions': permission_ids
                }
            })
        except Exception as err:
            logger.error("manager put error %s", err, exc_info=True)
            self.write_return({
                'code': NegErrCode.UPDATE_FAILED,
                'error': '修改组失败'
            })

    def root_put(self):
        try:
            group_id = int(self.group_id)
            payload = self.get_payload()
            group_name = payload.get('group', '')
            home_page = payload.get('home_page', '')
            permission_ids = payload.get('permissions')
            with mysql_sc() as sc:
                group = sc.query(UserGroup).filter(UserGroup.id == group_id).first()
                if not group:
                    self.request_not_valid("找不到group_id %s" % group_id)
                    return
                else:
                    sc.query(GroupMenu).filter(GroupMenu.user_group_id == group_id).delete()
                    for perm in permission_ids:
                        group_menu = GroupMenu(user_group_id=group_id, menu_id=perm)
                        sc.merge(group_menu)
                if group.name != group_name or group.home_page != home_page:
                    sc.query(UserGroup).filter(UserGroup.id == group_id).update({
                        'name': group_name,
                        'home_page': home_page
                    })
            self.write_return({
                'code': NegErrCode.API_SUCCESS,
                'data': {
                    'id': group_id,
                    'menu': permission_ids,
                    'home_page': home_page,
                    'name': group_name
                }
            })
        except Exception as err:
            logger.error("put the group failed %s", err, exc_info=True)
            self.write_return({
                'code': NegErrCode.UPDATE_FAILED,
                'error': '更新失败'
            })

    def put(self, *args, **kwargs):
        if not self.get_current_user():
            return
        if not self.argument_valid(**kwargs):
            return
        if self.current_user.get('is_superuser', False) or self.is_guoxin_admin():
            self.root_put()
        else:
            self.manager_put()

    def post(self, *args, **kwargs):
        """
        Create group with default roles and menus
        """
        if not self.get_current_user():
            return
        if self.current_user.get('is_superuser', False) or self.is_guoxin_admin():
            try:
                group_name = self.get_my_key("group", "")
                # data is menu id now
                home_page = self.get_my_key("home_page", "")
                permission_ids = [int(v) for v in self.get_my_keys("permissions", [])]
                with mysql_sc() as sc:
                    new_group = UserGroup(name=group_name, home_page=home_page, description=group_name)
                    sc.add(new_group)
                    sc.flush()
                    new_id = new_group.id
                    for perm in permission_ids:
                        group_menu = GroupMenu(user_group_id=new_group.id, menu_id=perm)
                        sc.add(group_menu)
                self.write_return({
                    'code': NegErrCode.API_SUCCESS,
                    'data': {
                        'id': new_id,
                        'name': group_name,
                        'menu': permission_ids,
                        'home_page': home_page
                    }
                })
            except Exception as err:
                logger.error("new a group failed %s", err, exc_info=True)
                self.write_return({
                    'code': NegErrCode.CREATE_FAILED,
                    'error': '创建失败'
                })
        else:
            self.permission_deny()


class GroupMemberHandler(CurrentUserMixin, MyBaseHandler):
    def get(self, *args, **kwargs):
        if not self.get_current_user():
            return
        if self.current_user.get('is_superuser', False):
            data = []
            with mysql_sc() as sc:
                user = sc.query(Users).filter(Users.id == self.current_user['id']).first()
                for grpi in user.user_groups:
                    ugis = sc.query(UserGroupInfo).filter_by(user_group_id=grpi.user_group_id).all()
                    users = []
                    for ugi in ugis:
                        u = ugi.user_obj
                        users.append({
                            'id': u.id,
                            'name': u.name,
                            'email': u.email
                        })
                    data.append({
                        'id': grpi.user_group_obj.id,
                        'name': grpi.user_group_obj.name,
                        'users': users
                    })
            self.write_return({
                'code': NegErrCode.API_SUCCESS,
                'data': data
            })
        else:
            self.permission_deny()


class ViewUserHandler(MyHost, CurrentUserMixin, JsonPayloadMixin, MyBaseHandler):
    def _get_user_menu(self, sc):
        try:
            menu_data = {}
            user_id = self.current_user.get('id')
            results = sc.query(UserGroupInfo).filter(UserGroupInfo.user_id == user_id).all()
            grp_ids = []
            for row in results:
                grp_ids.append(row.user_group_id)
            if len(grp_ids) > 1:
                return GroupsMenuOrder.fetch(grp_ids)['menu']
            menus = sc.query(GroupMenu).filter(GroupMenu.user_group_id.in_(grp_ids)).order_by(GroupMenu.id)
            for menu in menus:
                menu_obj = menu.menu_obj
                if menu_obj.father == -1:
                    level1_menu = {
                        "id": menu_obj.id,
                        "name": menu_obj.name,
                        "rank": menu.id,
                    }
                    if menu_obj.url:
                        level1_menu['url'] = menu_obj.url
                    menu_data[menu_obj.id] = level1_menu
            menus = sc.query(GroupMenu).filter(GroupMenu.user_group_id.in_(grp_ids)).order_by(GroupMenu.id)
            exist_menu = set()
            for menu in menus:
                menu_obj = menu.menu_obj
                if menu_obj.father != -1 and not (menu_obj.father, menu_obj.id) in exist_menu:
                    exist_menu.add((menu_obj.father, menu_obj.id))
                    if menu_obj.father not in menu_data:
                        continue
                    submenu = menu_data[menu_obj.father].setdefault("submenu", [])
                    submenu.append({
                        "id": menu_obj.id,
                        "name": menu_obj.name,
                        "url": menu_obj.url,
                        "rank": menu.id
                    })
            sc.commit()
        except Exception as err:
            logger.error("get current menu error %s", err, exc_info=True)
            raise
        return sorted(list(menu_data.values()), key=lambda x: x['rank'])

    @staticmethod
    @gen.coroutine
    def send_otc_reg_email(data):
        subject = "新用户注册审核"
        message = "有新用户加入，请审核<br/> 用户名: %s <br/> 邮箱: %s <br/>" % (data['name'], data['email'])
        logger.debug("send_otc_reg_email message: %s", message)
        # notify_email([config.OTC_EMAIL], message, subject)
        yield async_celery_call(tasks.notify_email, config.OTC_EMAIL, message, subject)

    @staticmethod
    @gen.coroutine
    def send_quant_reg_email(data):
        subject = "新用户注册审核"
        message = """
            有新用户加入，请审核<br/> 注册平台: %s <br/> 用户名: %s <br/> 邮箱: %s <br/> 手机号: %s <br/> 量化经验: %s
            擅长策略: %s <br/> 微信: %s <br/> 了解渠道: %s <br/> 推荐人: %s <br/>""" % \
                  ('', data['name'], data['email'], data['mobile_num'], data['experience'], data['advantage'],
                   data['wechat'], data['channel'], data['referer'])
        logger.debug("send_quant_reg_email message: %s", message)
        # notify_email([config.ADMIN_EMAIL], message, subject)
        yield async_celery_call(tasks.notify_email, [config.ADMIN_EMAIL], message, subject)

    def get(self, *args, **kwargs):
        if not self.get_current_user():
            return
        user_id = self.current_user.get('id')
        try:
            logger.debug("user info %s", self.current_user)
            with mysql_sc() as sc:
                self.write_return({
                    'code': NegErrCode.API_SUCCESS,
                    'data': {
                        'id': self.current_user.get('id'),
                        'username': self.current_user.get('username'),
                        'nickname': self.current_user.get('nickname'),
                        'avatar': '',
                        'csrf': self.get_cookie('csrftoken'),
                        'type': self.current_user.get('type'),
                        'chg_password': self.current_user.get('chg_password'),
                        'admin': self.current_user.get('is_superuser'),
                        'menu': self._get_user_menu(sc),
                        'groups': [
                            {
                                'id': g.user_group_obj.id,
                                'name': g.user_group_obj.name
                            } for g in sc.query(UserGroupInfo)
                                .filter(UserGroupInfo.user_id == user_id)
                                .order_by(UserGroupInfo.id.desc())
                        ],
                        'auto_uid': self.current_user.get('auto_uid'),
                    }
                })
        except Exception as err:
            logger.error("get user information error %s", err, exc_info=True)
            self.write_return({
                'code': NegErrCode.SERVER_INTERNAL_ERROR,
                'error': '服务器出错'
            })

    @gen.coroutine
    def post(self, *args, **kwargs):
        try:
            self.fetch_domain()
            with mysql_sc() as sc:
                username = self.get_my_key('username')
                email = self.get_my_key('email')
                enable_notebook = self.get_my_key('enable_notebook', False)
                user = sc.query(Users).filter(or_(Users.name == username, Users.email == email)).first()
                if user:
                    self.write_return({
                        'code': NegErrCode.USER_ALREADY_EXIST,
                        'error': 'username or email exists'
                    })
                    return
                mobile = self.get_my_key('mobile', '')
                if mobile:
                    user = sc.query(Users).filter(Users.mobile_num == mobile).first()
                    if user:
                        self.write_return({
                            'code': NegErrCode.CUSTOM_ERROR,
                            'error': '手机号已存在',
                        })
                        return
                add_user = Users(name=username, email=email)
                add_user.password = make_password(self.get_my_key('password', DEFAULT_PASSWORD))
                add_user.is_active = False
                add_user.is_audit = False
                add_user.nickname = self.get_my_key('nickname', username)
                add_user.firstname = self.get_my_key('firstname', username)
                add_user.lastname = self.get_my_key('lastname', username)
                if enable_notebook not in (True, False):
                    enable_notebook = False
                add_user.enable_notebook = enable_notebook
                if mobile:
                    add_user.mobile_num = mobile
                add_user.channel = self.get_my_key('channel', '')
                add_user.referer = self.get_my_key('referer', '')
                add_user.experience = self.get_my_key('experience', '')
                add_user.advantage = self.get_my_key('advantage', '')
                add_user.wechat = self.get_my_key('wechat', '')
                # register user need't change password
                add_user.chg_password = False
                sc.add(add_user)
            with mysql_sc() as sc:
                # print("the domain is ", self.domain)
                au = sc.query(Users).filter(Users.email == email).first()
                if enable_notebook and au:
                    vm_id = Users.get_max_vmid(au.id)
                    # copy the notebook directory
                    target = os.path.join(config.NOTEBOOK_HOME, '%s_%s' % (au.id, au.name))
                    source = os.path.join(config.NOTEBOOK_HOME, "user_template")
                    logger.debug("source: %s, target: %s, vm_id: %s, name: %s",
                                 source, target, vm_id, au.name)
                    tasks.prepare_notebook_env.delay(source, target, vm_id, au.name)
                au_json = au.to_dict()
                if self.domain == "otc.mycapital.net":
                    grp = sc.query(UserGroup).filter(UserGroup.name == 'broker').first()
                    if grp:
                        ugi = UserGroupInfo(user_id=au.id, user_group_id=grp.id)
                        sc.add(ugi)
            # never make do time consuming task in an transaction
            if self.domain == "otc.mycapital.net":
                yield ViewUserHandler.send_otc_reg_email(au_json)
            else:
                logger.debug("send_quote_reg_email")
                yield ViewUserHandler.send_quant_reg_email(au_json)
            self.write_return({
                'code': NegErrCode.API_SUCCESS,
                'data': 'register success'
            })
        except Exception as err:
            logger.error("register error %s", err, exc_info=True)
            self.write_return({
                'code': NegErrCode.CREATE_FAILED,
                'error': '创建失败'
            })


class RegisterOTCHandle(ViewUserHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        try:
            logger.info(self.get_payload())
            with mysql_sc() as sc:
                username = self.get_my_key('username')
                if sc.query(Users).filter(Users.name == username).first():
                    self.write({
                        'code': 2100,
                        'error': '用户名已被注册'
                    })
                    return
                email = self.get_my_key('email')
                if sc.query(Users).filter(Users.email == email).first():
                    self.write({
                        'code': 2100,
                        'error': '邮箱已被注册'
                    })
                    return
                mobile = self.get_my_key('mobile', '')
                if mobile:
                    if sc.query(Users).filter(Users.mobile_num == mobile).first():
                        self.write(json.dumps({
                            'code': 2100,
                            'error': '电话号码已被注册.',
                        }))
                        return

                add_user = Users(name=username, email=email)
                add_user.password = make_password(self.get_my_key('password', DEFAULT_PASSWORD))
                add_user.nickname = username
                add_user.firstname = username
                add_user.lastname = username
                add_user.mobile_num = mobile
                add_user.organization = self.get_my_key('organization', '')
                add_user.department = self.get_my_key('department', '')
                add_user.position = self.get_my_key('position', '')
                add_user.wechat = self.get_my_key('wechat', '')
                add_user.channel = ''
                add_user.referer = ''
                add_user.experience = ''
                add_user.advantage = ''
                # register user need't change password
                add_user.chg_password = False
                # otc user can use risk manage system after register
                add_user.is_audit = True
                add_user.audit_result = True
                add_user.reason = OTC_REGISTER_USER_AUTH_REASON
                add_user.is_active = True
                sc.add(add_user)
                sc.flush()

                grps = sc.query(UserGroup).filter(UserGroup.name.in_(['broker', 'RMSS_manager'])).all()
                for grp in grps:
                    ugi = UserGroupInfo(user_id=add_user.id, user_group_id=grp.id)
                    sc.add(ugi)
                    sc.flush()
                sc.commit()
                yield ViewUserHandler.send_otc_reg_email(add_user.to_dict())
                self.write_return({
                    'code': NegErrCode.API_SUCCESS,
                    'data': 'register success'
                })
        except Exception as err:
            logger.error("register error %s", err, exc_info=True)
            self.write_return({
                'code': NegErrCode.CREATE_FAILED,
                'error': '创建失败'
            })


class OTCSampleUserHandle(ViewUserHandler):

    def post(self, *args, **kwargs):
        try:
            logger.info(self.get_payload())
            with mysql_sc() as sc:
                username = self.get_my_key('username')
                if sc.query(Users).filter(Users.name == username).first():
                    self.write({
                        'code': 2100,
                        'error': '用户名已被注册'
                    })
                    return
                email = 'rmsample_%s@rmsample.com' % username

                add_user = Users(name=username, email=email)
                add_user.password = make_password(self.get_my_key('password', DEFAULT_PASSWORD))

                add_user.nickname = username
                add_user.firstname = username
                add_user.lastname = username

                add_user.organization = self.get_my_key('organization', '')
                add_user.department = self.get_my_key('department', '')
                add_user.position = self.get_my_key('position', '')
                add_user.wechat = self.get_my_key('wechat', '')
                add_user.channel = ''
                add_user.referer = ''
                add_user.experience = ''
                add_user.advantage = ''
                # register user need't change password
                add_user.chg_password = False
                # otc sample user need't audit and activate account
                add_user.is_audit = True
                add_user.audit_result = True
                add_user.reason = OTC_SAMPLE_USER_AUTH_REASON
                add_user.is_active = True
                sc.add(add_user)
                sc.flush()
                add_user.auto_uid = '200' + str(add_user.id).zfill(6)

                grps = sc.query(UserGroup).filter(UserGroup.name.in_(['broker', 'RMSS_manager'])).all()
                for grp in grps:
                    ugi = UserGroupInfo(user_id=add_user.id, user_group_id=grp.id)
                    sc.add(ugi)
                    sc.flush()
                self.write_return({
                    'code': NegErrCode.API_SUCCESS,
                    'data': {
                        'id': add_user.id,
                        'username': add_user.name,
                        'organization': add_user.organization,
                    }
                })
        except Exception as err:
            logger.error("register error %s", err, exc_info=True)
            self.write_return({
                'code': NegErrCode.CREATE_FAILED,
                'error': '创建失败'
            })

    def get(self, *args, **kwargs):
        try:
            data = []
            with mysql_sc() as sc:
                users = sc.query(Users).filter(Users.email.like('rmsample_%@rmsample.com')).all()
                for u in users:
                    data.append({
                        'id': u.id,
                        'username': u.name,
                        'organization': u.organization,
                    })
            self.write_return({
                'code': NegErrCode.API_SUCCESS,
                'data': data
            })
        except Exception as err:
            logger.error("register error %s", err, exc_info=True)
            self.write_return({
                'code': NegErrCode.FETCH_FAILED,
                'error': '查询失败'
            })

    def put(self, *args, **kwargs):
        try:
            logger.info(self.get_payload())
            with mysql_sc() as sc:
                id = self.get_my_key('id')
                username = self.get_my_key('username')
                if sc.query(Users).filter(Users.name == username, Users.id != id).first():
                    self.write({
                        'code': 2100,
                        'error': '用户名已被注册'
                    })
                    return
                update_user = sc.query(Users).filter(Users.id == id).first()
                if update_user.name != username:
                    update_user.name = username
                    update_user.nickname = username
                    update_user.firstname = username
                    update_user.lastname = username
                    update_user.email = 'rmsample_%s@rmsample.com' % username
                update_user.password = make_password(self.get_my_key('password', DEFAULT_PASSWORD))
                update_user.organization = self.get_my_key('organization', '')
                sc.flush()
                self.write_return({
                    'code': NegErrCode.API_SUCCESS,
                    'data': {
                        'id': update_user.id,
                        'username': update_user.name,
                        'organization': update_user.organization,
                    }
                })
        except Exception as err:
            logger.error("register error %s", err, exc_info=True)
            self.write_return({
                'code': NegErrCode.UPDATE_FAILED,
                'error': '修改失败'
            })


class UserRolesHandler(CurrentUserMixin, JsonPayloadMixin, MyBaseHandler):
    def get(self, *args, **kwargs):
        self.write({
            'code': 0,
            'data': ['internal', 'broker', 'enterprise', 'sale', 'private_placement']
        })

    @staticmethod
    def parse_role(role):
        map_role = {
            'internal': None,
            'broker': '100',
            'enterprise': '200',
            'sale': '300',
            'private_placement': '400',
        }
        if role not in map_role:
            return None
        else:
            return map_role[role]

    def post(self, *args, **kwargs):
        if not self.get_current_user():
            return
        if not self.current_user['is_superuser']:
            self.permission_deny()
            return
        payload = self.get_payload()
        user_id = payload.get('user_id')
        role = payload.get('role', 'internal')
        role_i = UserRolesHandler.parse_role(role)
        with mysql_sc() as sc:
            u = sc.query(Users).filter_by(id=user_id).first()
            if not u:
                self.write({
                    'code': NegErrCode.CUSTOM_ERROR,
                    'data': "用户 %s 不存在" % user_id
                })
                return
            if role_i is None:
                u.auto_uid = None
            else:
                u.auto_uid = role_i + str(u.id).zfill(6)
        self.write({
            'code': 0,
            'data': "修改成功"
        })


class AuditHandler(MyHost, CurrentUserMixin, JsonPayloadMixin, MyBaseHandler):
    def get(self, *args, **kwargs):
        try:
            user_id = kwargs['user_id']
            active_code = self.get_argument('active_code')
            with mysql_sc() as sc:
                o = sc.query(Users).filter_by(id=user_id).first()
                if o:
                    if active_code and (o.active_code == active_code):
                        o.is_active = True
                        self.write_return({
                            'code': NegErrCode.API_SUCCESS,
                            'data': 'active success'
                        })
                    else:
                        self.write_return({
                            'code': NegErrCode.REQ_NOT_VALID,
                            'error': '授权码错误: %s' % active_code
                        })
                else:
                    self.write({
                        'code': NegErrCode.REQ_NOT_VALID,
                        'error': '用户不存在'
                    })
        except Exception as err:
            client.captureException()
            self.write_return({
                'code': NegErrCode.REQ_NOT_VALID,
                'data': '授权执行出错: %s' % err
            })

    @gen.coroutine
    def post(self, *args, **kwargs):
        try:
            if not self.get_current_user():
                # processed in previous function
                return
            if not self.current_user['is_superuser'] and self.current_user['username'] != 'dvt':
                self.permission_deny()
                return
            payload = self.get_payload()
            data = {
                'audit_result': payload['audit_result'],
                'reason': payload.get('reason', ''),
                'user_id': kwargs['user_id'],
                'role': payload.get('role', ''),
            }
            with mysql_sc() as sc:
                u = sc.query(Users).filter(Users.id == data['user_id']).first()
                if data['role']:
                    role = UserRolesHandler.parse_role(data['role'])
                    if role is None:
                        u.auto_uid = None
                    else:
                        u.auto_uid = role + str(u.id).zfill(6)
                user_email = u.email
                if u.is_active:
                    self.write_return({
                        'code': NegErrCode.API_SUCCESS,
                        'data': 'user audited already'
                    })
                    return
                u.audit_result = data['audit_result']
                data['name'] = u.name
                if data['audit_result']:
                    # generate a random activate code
                    u.auditor = self.current_user['id']
                    u.reason = data['reason']
                    md5 = hashlib.md5()
                    md5.update(uuid.uuid4().hex.encode('utf8'))
                    active_code = md5.hexdigest()
                    u.active_code = active_code
                    u.is_audit = True
                    data['active_code'] = active_code

                    # construct the auditor url
                    file_path = 'activate-user.html'
                    query = 'user_id=%s&active_code=%s' % (data['user_id'], data['active_code'])
                    protocol = 'http' if config.DEBUG else 'https'
                    self.fetch_domain()
                    base_url = '%s://%s' % (protocol, self.domain)
                    active_url = '%s/%s?%s' % (base_url, file_path, query)
                    logger.debug("audit debug %s", active_url)
                    message = "您的注册申请已审核通过，请点击以下链接激活账户: <br/>%s" % active_url

                    # if the register user has group then need do nothing, else add to guest as default group
                    if len(u.user_groups) == 0:
                        dg = sc.query(UserGroup).filter(UserGroup.name == 'guest').first()
                        if not dg:
                            self.write_return({
                                'code': NegErrCode.API_SUCCESS,
                                'data': '请先登录 root 并创建 guest group'
                            })
                        new_rel = UserGroupInfo(user_id=data['user_id'], user_group_id=dg.id)
                        sc.add(new_rel)
                else:
                    message = "您的注册申请已被拒绝，原因: %s" % data['reason']
                ret = yield async_celery_call(tasks.notify_email, [user_email], message, title="审核通知")
                if ret:
                    self.write_return({
                        'code': NegErrCode.API_SUCCESS,
                        'data': '操作完成'
                    })
                else:
                    self.write_return({
                        'code': NegErrCode.SEND_EMAIL_FAILED,
                        'error': '发送邮件失败，请重试！'
                    })
        except Exception as err:
            client.captureException()
            self.write_return({
                'code': NegErrCode.AUDIT_FAILED,
                'data': '授权内部执行错误: %s' % err
            })


class VerifyCodeHandler(CurrentUserMixin, JsonPayloadMixin, MyBaseHandler):
    @gen.coroutine
    def post(self, *args, **kwargs):
        payload = self.get_payload()
        account = payload.get('account', '')
        if not account:
            self.write_return({
                'code': NegErrCode.ARGUMENT_EMPTY_ERROR,
                'error': '用户名或邮箱为空'
            })
        with mysql_sc() as sc:
            user = sc.query(Users).filter(or_(Users.name == account, Users.email == account)).first()
            if not user:
                self.write_return({
                    'code': NegErrCode.USER_NOT_FOUND,
                    'error': '用户名或邮箱不存在'
                })
                return
            logger.info(user.to_dict())
            code = ''.join(random.sample(string.ascii_letters + string.digits, 6))
            subject = '重置密码通知'
            message = "您好，%s, 本次重置密码的验证码为: %s, 请在30分钟内输入验证码，非本人操作，请忽略此邮件" % (user.name, code)
            try:
                self.application.backend.setex('password:verifycode:%s' % user.id, code, 1800)
                yield async_celery_call(tasks.notify_email, [user.email], message, subject)
                self.write_return({
                    'code': NegErrCode.API_SUCCESS,
                    'data': '验证码已发送到邮箱'
                })
            except Exception as err:
                logger.error("verify code error %s", err, exc_info=True)
                self.write_return({
                    'code': NegErrCode.SEND_EMAIL_FAILED,
                    'error': '用户名或邮箱错误，发送邮件失败'
                })


class ForgetPasswordHandler(CurrentUserMixin, JsonPayloadMixin, MyBaseHandler):
    def put(self, *args, **kwargs):
        payload = self.get_payload()
        account = payload.get('account', '')
        verify_code = payload.get('verify_code', '')
        new_password = payload.get('new_password', '')
        if not (account and verify_code and new_password):
            self.write_return({
                'code': NegErrCode.REQ_NOT_VALID,
                'error': '账户或验证码错误'
            })
            return
        with mysql_sc() as sc:
            user = sc.query(Users).filter(or_(Users.name == account, Users.email == account)).first()
            if not user:
                self.write_return({
                    'code': NegErrCode.USER_NOT_FOUND,
                    'error': '用户名或邮箱不存在'
                })
                return
            code = self.application.backend.get_k('password:verifycode:%s' % user.id)
            if isinstance(code, bytes):
                code = code.decode('utf-8')
            if not code:
                self.write_return({
                    'code': NegErrCode.VERIFY_CODE_EXPIRE,
                    'error': '验证码已过期'
                })
                return
            if verify_code != code:
                self.application.backend.del_k('password:verifycode:%s' % user.id)
                self.write_return({
                    'code': NegErrCode.CUSTOM_ERROR,
                    'error': '验证码错误，重新获取'
                })
                return
            user.password = make_password(new_password)
            user.chg_password = False
            sc.commit()
            self.write_return({
                'code': NegErrCode.API_SUCCESS,
                'data': '更新密码成功'
            })


class ChangePasswordHandler(CurrentUserMixin, JsonPayloadMixin, MyBaseHandler):
    @staticmethod
    def password_valid(user_id, password):
        # logger.debug("userid %s, password %s", user_id, password)
        if not password or not isinstance(password, str):
            return False
        hf = PBKDF2PasswordHasher()
        with mysql_sc() as sc:
            item = sc.query(Users).filter_by(id=user_id).first()
            # logger.debug("item.password %s", item.password)
            if not item:
                return False
            return hf.verify(password, item.password)

    def post(self, *args, **kwargs):
        try:
            if not self.get_current_user():
                return

            old_password = self.get_my_key('old_password', '')
            new_password = self.get_my_key('new_password', '')

            # if request is supervisor, try to read from request firstly
            if self.current_user.get('is_superuser', False) and 'id' in kwargs:
                user_id = kwargs['id']
            else:
                user_id = self.current_user['id']
                # not the first time to change password
                if not self.password_valid(user_id, old_password):
                    self.write({
                        'code': NegErrCode.CUSTOM_ERROR,
                        'data': '旧密码输入错误',
                    })
                    return
            if not new_password or len(new_password) < 6:
                self.write({
                    'code': NegErrCode.REQ_NOT_VALID,
                    'error': '密码不符合规范(not null, length > 6)'
                })
                return
            with mysql_sc() as sc:
                encode_pwd = make_password(new_password)
                sc.query(Users).filter_by(id=user_id).update({'password': encode_pwd,
                                                              'chg_password': False})
            self.update_session({'chg_password': False})
            openid_list = clear_wx_cache(user_id)
            logger.info('clear wx cache of userid = %d', user_id)
            if openid_list:
                logger.info('del user_if of %s', openid_list)
                OTCWxUserInfo.del_user_id_batch(openid_list)
            self.write_return({
                'code': NegErrCode.API_SUCCESS,
                'data': '更新密码成功'
            })
        except Exception as err:
            logger.error("change password failed %s", err, exc_info=True)
            self.write_return({
                'code': NegErrCode.UPDATE_FAILED,
                'error': '更新密码失败'
            })

    @staticmethod
    def has_perm(manager_id, customer_id):
        with mysql_sc() as sc:
            ugi = sc.query(UserGroupInfo).filter(UserGroupInfo.user_id == manager_id,
                                                 UserGroupInfo.user_group_obj.type == "manager").first()
            if not ugi:
                return False
            company_id = ugi.user_group_obj.company_id
            ugi = sc.query(UserGroupInfo).filter(UserGroupInfo.user_id == customer_id,
                                                 UserGroupInfo.user_group_obj.company_id == company_id).first()
            if ugi:
                return True
            return False

    def put(self, *args, **kwargs):
        try:
            if not self.get_current_user():
                return
            opt_user_id = self.current_user['id']
            user_id = kwargs['id']
            if not self.current_user.get('is_superuser', False) and not self.__class__.has_perm(opt_user_id, user_id):
                self.permission_deny()
                return
            payload = self.get_payload()
            new_password = payload.get('new_password', DEFAULT_PASSWORD)
            with mysql_sc() as sc:
                encode_password = make_password(new_password)
                # need to update password
                sc.query(Users).filter_by(id=user_id).update({'password': encode_password,
                                                              'chg_password': True})
            openid_list = clear_wx_cache(user_id)
            logger.info('clear wx cache of userid = %d', user_id)
            if openid_list:
                logger.info('del user_if of %s', openid_list)
                OTCWxUserInfo.del_user_id_batch(openid_list)
            self.write({
                'code': NegErrCode.API_SUCCESS,
                'data': '管理员重置密码成功'
            })
        except Exception as err:
            logger.error("reset password failed %s", err, exc_info=True)
            self.write({
                'code': NegErrCode.UPDATE_FAILED,
                'data': '管理员重置密码失败'
            })


class AdminMenuHandler(CurrentUserMixin, JsonPayloadMixin, MyBaseHandler):
    def get(self, *args, **kwargs):
        if not self.get_current_user():
            return
        if not (self.current_user.get('is_superuser', False) or self.is_guoxin_admin()):
            self.permission_deny()
            return
        try:
            with mysql_sc() as sc:
                if self.is_guoxin_admin():
                    menus = sc.query(Menu).filter(
                        Menu.id.in_(GUOXIN_MENU_IDS)
                    ).all()
                else:
                    menus = sc.query(Menu).all()
                data = {}
                for menu in menus:
                    if len(menu.url) != 0:
                        url_item = {
                            'name': menu.name,
                            'url': menu.url,
                        }
                        data[menu.id] = url_item
                    else:
                        data[menu.id] = {'name': menu.name}
                    if menu.father != -1:
                        data[menu.id]['father'] = menu.father
                self.write_return({
                    'code': NegErrCode.API_SUCCESS,
                    'data': data
                })
        except Exception as err:
            logger.error("get menu error %s", err, exc_info=True)
            self.write_return({
                'code': NegErrCode.FETCH_FAILED,
                'error': '获取失败'
            })

    def post(self, *args, **kwargs):
        if not self.get_current_user():
            return
        if not (self.current_user.get('is_superuser', False) or self.is_guoxin_admin()):
            self.permission_deny()
            return
        try:
            payload = self.get_payload()
            name = payload.get('name')
            url = payload.get('url')
            father_id = int(payload.get('father', -1))
            if name is None:
                name = self.get_my_key('name')
                url = self.get_my_key('url')
                father_id = int(self.get_my_key('father', -1))
            with mysql_sc() as sc:
                new_menu = Menu(name=name)
                new_menu.url = url
                new_menu.father = father_id
                sc.add(new_menu)
                sc.flush()
                new_id = new_menu.id
            ret_data = {
                'id': new_id,
                'name': name,
                'url': url,
            }
            if father_id != -1:
                ret_data['father'] = father_id
            self.write_return({
                'code': NegErrCode.API_SUCCESS,
                'data': ret_data
            })
        except Exception as err:
            logger.error("post menu error %s", err, exc_info=True)
            self.write_return({
                'code': NegErrCode.CREATE_FAILED,
                'error': '添加失败'
            })

    @staticmethod
    def _update_menu():
        """ update group's menu while menu update context information
        :return:
        """
        # delete single father menu
        # if father not belong to group the add it
        group_menu = {}
        father_child = {}
        child_father = {}
        with mysql_sc() as sc:
            items = sc.query(Menu).all()
            for a in items:
                if a.father == -1:
                    father_child.setdefault(a.id, [])
                    continue
                else:
                    child_father[a.id] = a.father
                if a.father in father_child:
                    father_child[a.father].append(a.id)
                else:
                    father_child[a.father] = [a.id]
            items = sc.query(GroupMenu).all()
            for a in items:
                group_menu.setdefault(a.user_group_id, [])
                group_menu[a.user_group_id].append(a.menu_id)
        for k, v in group_menu.items():
            for i in v:
                if i in father_child:
                    if not (set(father_child[i]) & set(v)):
                        # delete single father menu
                        # with mysql_sc() as sc:
                        #     sc.query(GroupMenu)\
                        #         .filter(GroupMenu.menu_id == i,
                        #                 GroupMenu.user_group_id == k)\
                        #         .delete()
                        pass
                if i in child_father and child_father[i] not in v:
                    # add father as well
                    with mysql_sc() as sc:
                        gm = GroupMenu(menu_id=child_father[i], user_group_id=k)
                        sc.add(gm)

    def delete(self, *args, **kwargs):
        if not self.get_current_user():
            return
        if not self.current_user.get('is_superuser', False):
            self.permission_deny()
            return
        try:
            menu_id = kwargs['id']
            with mysql_sc() as sc:
                fa = sc.query(Menu).filter(Menu.father == menu_id).all()
                if fa:
                    self.write_return({
                        'code': NegErrCode.DELETE_FAILED,
                        'error': '删除失败，请先删除子目录',
                    })
                    return
                else:
                    sc.query(Menu).filter(Menu.id == menu_id).delete()
                    self.write_return({
                        'code': NegErrCode.API_SUCCESS,
                        'data': '删除成功'
                    })
        except Exception as err:
            logger.error("delete the menu failed %s", err, exc_info=True)
            self.write_return({
                'code': NegErrCode.SERVER_INTERNAL_ERROR,
                'error': '删除失败'
            })

    def put(self, *args, **kwargs):
        if not self.get_current_user():
            return
        if not (self.current_user.get('is_superuser', False) or self.is_guoxin_admin()):
            self.permission_deny()
            return
        try:
            menu_id = kwargs['id']
            name = self.get_my_key('name')
            url = self.get_my_key('url')
            father = int(self.get_my_key('father', -1))
            with mysql_sc() as sc:
                menu = sc.query(Menu).filter(Menu.id == int(menu_id)).first()
                menu.name = name
                menu.url = url
                if father != -1:
                    if sc.query(Menu).filter(Menu.id == int(father)):
                        menu.father = father
                    else:
                        self.write_return({
                            'code': NegErrCode.REQ_NOT_VALID,
                            'error': 'father not found'
                        })
                        return
                sc.commit()
                ret_data = {
                    'id': int(menu_id),
                    'name': name,
                    'url': url
                }
                if father != -1:
                    ret_data['father'] = father
            self._update_menu()
            self.write({
                'code': NegErrCode.API_SUCCESS,
                'data': ret_data
            })
        except Exception as err:
            logger.error("put the menu error %s", err, exc_info=True)
            self.write_return({
                'code': NegErrCode.UPDATE_FAILED,
                'error': '更新 menu 失败'
            })

# -*- coding:utf-8 -*-

import logging
import netifaces
import os
import re
import sys
from logging.handlers import RotatingFileHandler

import redis


class CommonConfig(object):
    NOTEBOOK_HOME = '/home/rss/userworkspace'
    renv = '/home/rss/bss_server/site/media/renv'
    DEFAULT_PASSWORD = '123456'
    ADMIN_EMAIL = None
    OTC_EMAIL = None
    PORT = 18889
    DEBUG = False
    web_host = 'quant.mycapital.net'


class ProductionConfig(CommonConfig):
    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }

    session_cache = {
        'host': '127.0.0.1',
        'port': 6379,
        'db': 0
    }

    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql
    web_host = 'uat.mycapital.net'
    ADMIN_EMAIL = 'dto@mycapital.net'
    OTC_EMAIL = 'dvt@mycapital.net'


class DebugConfig(CommonConfig):
    mysql = {
        'host': '192.168.1.14',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }

    session_cache = {
        'host': '192.168.1.14',
        'port': 6379,
        'db': 0
    }

    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql
    ADMIN_EMAIL = 'zhouchaolin@mycapital.net'
    OTC_EMAIL = ['zhouchaolin@yeah.net', 'alyssa.cui@mycapital.net']
    PORT = 18999
    DEBUG = True


class ProductionIDCConfig(CommonConfig):
    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }

    session_cache = {
        'host': '127.0.0.1',
        'port': 6379,
        'db': 0
    }

    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql
    NOTEBOOK_HOME = '/home/rss/jupyter_userworkspace'
    ADMIN_EMAIL = 'dto@mycapital.net'
    OTC_EMAIL = ['dvt@mycapital.net', 'dvs@mycapital.net']


class ProductionIDCVIPConfig(ProductionIDCConfig):
    mysql = {
        'host': '192.168.10.80',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }

    session_cache = {
        'host': '192.168.10.99',
        'port': 6379,
        'db': 0
    }

    mysql['db_uri'] = 'mysql+pymysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql


iplist = [netifaces.ifaddresses(i).get(netifaces.AF_INET)[0]['addr']
          for i in netifaces.interfaces() if netifaces.ifaddresses(i).get(netifaces.AF_INET)]

debug_iplist = ['192.168.1.14']

product_list = ['192.168.10.109']

product_idc_list = ['192.168.10.100', '172.18.202.37']

product_vip_list = ['192.168.10.119']

if any([i in iplist for i in product_idc_list]):
    config = ProductionIDCConfig()
elif any([i in iplist for i in debug_iplist]):
    config = DebugConfig()
elif any([i in iplist for i in product_list]):
    config = ProductionConfig()
elif any([i in iplist for i in product_vip_list]):
    Debug = False
    config = ProductionIDCVIPConfig()
else:
    config = DebugConfig()

internal_ip = [i for i in iplist if i.startswith("192.168")]

# auth logger
ROTATE_LOG_SIZE = 1024 * 1024 * 50
LOG_BACKUP_COUNT = 10
logger = logging.getLogger()
if config.DEBUG:
    logger.setLevel(logging.DEBUG)
else:
    logger.setLevel(logging.DEBUG)
log_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "auth.log")
handler = RotatingFileHandler(log_file, maxBytes=ROTATE_LOG_SIZE, backupCount=LOG_BACKUP_COUNT)
formatter = logging.Formatter(fmt='%(asctime)s - %(pathname)s[line:%(lineno)d] - %(levelname)s: %(message)s')
handler.setFormatter(formatter)
logger.handlers.clear()
logger.addHandler(handler)

# auth redis connection
pool = redis.ConnectionPool(**config.session_cache)
redis_conn = redis.Redis(connection_pool=pool)

# default password for manager/root create user
DEFAULT_PASSWORD = '123456'

# session timeout 30 days
SESSION_TIMEOUT = 30 * 24 * 60 * 60

# include celery directory
PRO_DIRECTORY = re.findall('(.*bss_server)', os.path.abspath(__file__))[0]
sys.path.append(PRO_DIRECTORY)

OTC_REGISTER_USER_AUTH_REASON = 'OTC register user authorized by system'
OTC_SAMPLE_USER_AUTH_REASON = 'OTC sample user authorized by system'

from redis import Redis
# -*- coding:utf-8 -*-

import base64
import datetime

from Crypto.Cipher import AES
from sqlalchemy import Column, ForeignKey
from sqlalchemy.dialects.mysql import BIGINT, VARCHAR, BOOLEAN, DATETIME, INTEGER, DOUBLE, TEXT
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from myrpc.apps.auth.db import ModelBase, session_context


class UserType(ModelBase):

    __tablename__ = 'user_type'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)
    description = Column(VARCHAR(255), nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
        }


class CredentialType(ModelBase):

    __tablename__ = 'credential_type'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
        }


class Company(ModelBase):
    __tablename__ = 'company'
    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(255), nullable=False, unique=True)
    description = Column(TEXT, nullable=True)
    domain = Column(VARCHAR(255), nullable=True, unique=True)
    logo = Column(VARCHAR(255), nullable=True)
    favicon = Column(VARCHAR(255), nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'domain': self.domain,
            'logo': self.logo,
            'favicon': self.favicon,
        }


class UserGroup(ModelBase):

    __tablename__ = 'user_group'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)
    type = Column(VARCHAR(64), nullable=True)
    company_id = Column(INTEGER, nullable=True, default=-1)
    description = Column(VARCHAR(255), nullable=False)
    home_page = Column(VARCHAR(255), nullable=True)

    menu_ref_obj = relationship('GroupMenu')
    user_type_ref_obj = relationship('UserTypeInfo')
    user_group_ref_obj = relationship('UserGroupInfo')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'type': self.type,
            'company_id': self.company_id,
            'description': self.description,
        }


class Menu(ModelBase):

    __tablename__ = 'menu'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(255), nullable=False, default=None)
    url = Column(VARCHAR(255), nullable=True)
    father = Column(INTEGER, default=-1)    # point to group_menu item

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'url': self.url,
            'father': self.father
        }


class GroupMenu(ModelBase):

    __tablename__ = 'group_menu'

    id = Column(BIGINT(unsigned=True), primary_key=True, autoincrement=True)
    menu_id = Column(ForeignKey('menu.id', ondelete='CASCADE'))
    user_group_id = Column(ForeignKey('user_group.id', ondelete='CASCADE'))

    menu_obj = relationship('Menu', passive_deletes=True)
    group_obj = relationship('UserGroup', passive_deletes=True)

    def to_dict(self):
        return {
            'id': self.id,
            'menu_name': self.menu_obj.name,
            'group_name': self.group_obj.name
        }


class Users(ModelBase):

    __tablename__ = 'users'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=True)
    name = Column(VARCHAR(128), nullable=False, unique=True)
    linkman = Column(VARCHAR(255), nullable=True)
    description = Column(VARCHAR(512), nullable=True)   # company description or similar things
    password = Column(VARCHAR(255), nullable=False)
    nickname = Column(VARCHAR(32), nullable=True)
    firstname = Column(VARCHAR(32), nullable=True)
    lastname = Column(VARCHAR(32), nullable=True)
    email = Column(VARCHAR(128), nullable=True, unique=True)
    mobile_num = Column(VARCHAR(128), nullable=True, unique=True)
    tel_num = Column(VARCHAR(128), nullable=True, unique=True)
    address = Column(VARCHAR(255), nullable=True)
    is_audit = Column(BOOLEAN, nullable=True)
    auditor = Column(INTEGER, nullable=True)
    active_code = Column(VARCHAR(128), nullable=True)
    is_active = Column(BOOLEAN, nullable=True)
    audit_result = Column(BOOLEAN, nullable=True)
    reason = Column(VARCHAR(255), nullable=True)
    channel = Column(VARCHAR(128), nullable=True)
    referer = Column(VARCHAR(128), nullable=True)
    experience = Column(VARCHAR(128), nullable=True)
    advantage = Column(VARCHAR(512), nullable=True)
    telephone = Column(VARCHAR(128), nullable=True)
    wechat = Column(VARCHAR(128), nullable=True)
    is_superuser = Column(BOOLEAN, default=False)         # check the user is superuser or not
    chg_password = Column(BOOLEAN, default=True)          # identify whether need to update password
    auto_uid = Column(VARCHAR(32), nullable=True)         # identify which otc type user belong to
    """
    null      internal user
    100 + xxx brokers
    200 + xxx enterprise
    300 + xxx personal
    400 + xxx private placement
    500 + xxx sales
    """
    user_credentials = relationship('UserCredential', backref='user', passive_deletes=True)
    user_types = relationship('UserTypeInfo', backref='user', passive_deletes=True)
    user_groups = relationship('UserGroupInfo', backref='user', passive_deletes=True)
    # for OTC
    organization = Column(VARCHAR(64))
    department = Column(VARCHAR(32))
    position = Column(VARCHAR(32))
    enable_notebook = Column(BOOLEAN, default=False)       # enable copy the notebook template
    vm_uid = Column(INTEGER, default=-1)                   # virtual machine user id

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'password': self.password,
            'nickname': self.nickname or self.name,
            'email': self.email,
            'mobile_num': self.mobile_num,
            'credentials': [uc.brief() for uc in self.user_credentials],
            'user_types': [ut.brief() for ut in self.user_types],
            'user_groups': [ug.brief() for ug in self.user_groups],
            'is_audit': self.is_audit or False,
            'audit_result': self.audit_result,
            'reason': self.reason,
            'is_active': self.is_active or False,
            'active_code': self.active_code or '',
            'create_date': self.r_create_time.strftime('%Y%m%d') if self.r_create_time else None,
            'experience': self.experience or '',
            'advantage': self.advantage or '',
            'wechat': self.wechat or '',
            'auto_uid': self.auto_uid or '',
            'organization': self.organization,
            'department': self.department,
            'position': self.position,
            'channel': self.channel,
            'referer': self.referer,
            'enable_notebook': self.enable_notebook,
        }

    def brief(self):
        return {
            'id': self.id,
            'name': self.name,
            'password': self.password,
            'nickname': self.nickname or self.name,
            'email': self.email,
            'mobile_num': self.mobile_num,
        }

    def to_customer(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'address': self.address,
            'linkman': self.linkman,
            'telephone': self.telephone,
            'email': self.email
        }

    @staticmethod
    def get_max_vmid(user_id):
        # concurrency is ignored (this will update the vm user_id)
        with session_context() as sc:
            out = sc.query(Users).filter(Users.id == user_id).first()
            if out and out.vm_uid != -1:
                return out.vm_uid
            db_max_id = sc.query(func.max(Users.vm_uid)).first()
            if db_max_id:
                vm_id = db_max_id[0] + 1
            else:
                vm_id = 0
            default_vm_id = 10028
            if vm_id < default_vm_id:
                vm_id = default_vm_id
            if out:
                out.vm_uid = vm_id
            return vm_id


class UserCredential(ModelBase):

    __tablename__ = 'user_credential'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    user_id = Column(ForeignKey('users.id'))
    credential_type_id = Column(ForeignKey('credential_type.id'))
    credential_content = Column(VARCHAR(512), nullable=False, unique=True)
    default = Column(BOOLEAN, nullable=True)

    credential_type_obj = relationship('CredentialType')
    # user = relationship('Users')

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            # 'user_name': self.user.name,
            'credential_type_id': self.credential_type_id,
            'credential_type_name': self.credential_type_obj.name,
            'credential_content': self.credential_content,
            'default': self.default or False,
        }

    def brief(self):
        return {
            'credential_type_id': self.credential_type_id,
            'credential_type_name': self.credential_type_obj.name,
            'credential_content': self.credential_content,
            'default': self.default or False,
        }


class UserTypeInfo(ModelBase):

    __tablename__ = 'user_type_info'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=True)

    user_id = Column(ForeignKey('users.id'))
    user_group_id = Column(ForeignKey('user_group.id'))
    user_type_id = Column(ForeignKey('user_type.id'))

    user_type_obj = relationship('UserType')

    def brief(self):
        return {
            'user_type_id': self.user_type_id,
            'user_type_name': self.user_type_obj.name,
        }


# class Permission(ModelBase):
#
#     __tablename__ = 'permission'
#
#     id = Column(BIGINT(unsigned=True), primary_key=True)
#     r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
#     r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
#     r_create_user_id = Column(INTEGER, nullable=True)
#     r_update_user_id = Column(INTEGER, nullable=True)
#
#     name = Column(VARCHAR(255), nullable=False)
#     description = Column(TEXT, nullable=True)
#
#     def brief(self):
#         return {
#             'permission_id': self.id,
#             'permission_name': self.name
#         }
#
#
# class RolePermission(ModelBase):
#
#     __tablename__ = 'role_permission'
#
#     id = Column(BIGINT(unsigned=True), primary_key=True)
#     user_type_id = Column(ForeignKey('user_type.id'))
#     permission_id = Column(ForeignKey('permission.id'))
#
#     permission_obj = relationship('Permission')
#
#     def brief(self):
#         return {
#             'user_type_id': self.user_type_id,
#             'permission_id': self.permission_id,
#             'permission_name': self.permission_obj.name
#         }


class UserGroupInfo(ModelBase):

    __tablename__ = 'user_group_info'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=True)
    user_id = Column(ForeignKey('users.id'))
    user_group_id = Column(ForeignKey('user_group.id'))

    user_group_obj = relationship('UserGroup')
    user_obj = relationship('Users')

    def brief(self):
        return {
            'user_group_id': self.user_group_id,
            'user_group_name': self.user_group_obj.name,
        }


class Brokers(ModelBase):

    __tablename__ = 'brokers'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
        }


class Accounts(ModelBase):

    __tablename__ = 'accounts'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False)
    password = Column(VARCHAR(128), nullable=False)
    fund_total = Column(DOUBLE, nullable=False)
    fund_occupied = Column(DOUBLE, nullable=False)
    broker_id = Column(ForeignKey('brokers.id'))
    user_id = Column(ForeignKey('users.id'))
    valid = Column(BOOLEAN, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=True)

    broker_obj = relationship('Brokers')
    user_obj = relationship('Users')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'password': self.password,
            'fund_total': float(self.fund_total),
            'fund_occupied': float(self.fund_occupied),
            'broker': {
                'id': self.broker_obj.id,
                'name': self.broker_obj.name,
            },
            'user': {
                'id': self.user_obj.id,
                'name': self.user_obj.name,
            },
            'valid': self.valid,
        }

    @staticmethod
    def encrypt(text):
        if len(text) > 16:
            return text
        key = b'\x02\x0c!W@\xad\te\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        cipher = AES.new(key, AES.MODE_ECB)
        if isinstance(text, str):
            text = text[:16].encode('utf-8')
        elif isinstance(text, bytes):
            text = text[:16]
        else:
            raise ValueError('text type error: %s' % text)
        text = text + b'\x00' * (16 - len(text)) + b'\t\x8b*UqU\xdc\xbd\x02\xab\xcf`\xd7\x80\xe8\xe5' * 3
        return str(base64.b64encode(cipher.encrypt(text)), 'utf-8')


class GroupsMenuOrder(ModelBase):
    __tablename__ = 'groups_menu_order'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=True)

    description = Column(VARCHAR(256), nullable=True)
    groups_str = Column(VARCHAR(256), nullable=False)
    menu_id = Column(ForeignKey('menu.id', ondelete='CASCADE'))
    menu_obj = relationship('Menu', passive_deletes=True)
    rank = Column(INTEGER, nullable=False)

    @staticmethod
    def check_valid(groups, menu_ids):
        """
        :param groups: list of group id
        :param menu_ids: list of menu id
        :return: true if valid or false
        """
        exist_items = set()
        with session_context() as sc:
            sql = "select menu_id from group_menu where user_group_id in :groups"
            items = sc.execute(sql, {"groups": groups}).fetchall()
            for item in items:
                exist_items.add(item[0])
        return set(menu_ids) == exist_items

    @staticmethod
    def get_all_ids(menus):
        """
        :param menus: organized menu information
        :return:
        """
        all_ids = set()
        for item in menus:
            all_ids.add(item['id'])
            submenu = item.get('submenu')
            if isinstance(submenu, list):
                for smenu in submenu:
                    all_ids.add(smenu['id'])
        return all_ids

    @staticmethod
    def create(groups, description, menus):
        """
        :param groups: a list of group id
        :param description: description the name of multiple-group
        :param menus:  a list of organized menu items
        :return: true if success else false
        """
        # check menus exist in integrate group menu
        # create items according to arguments shows
        all_ids = GroupsMenuOrder.get_all_ids(menus)
        if not GroupsMenuOrder.check_valid(groups, all_ids):
            return
        GroupsMenuOrder.delete(groups)
        with session_context() as sc:
            group_str = str(sorted(groups))
            rank = 0
            exist_menu = set()
            for menu in menus:
                if menu['id'] in exist_menu:
                    continue
                else:
                    exist_menu.add(menu['id'])
                a = GroupsMenuOrder(description=description, groups_str=group_str, menu_id=menu['id'], rank=rank)
                sc.add(a)
                rank += 1
                submenu = menu.get('submenu')
                if isinstance(submenu, list):
                    for smenu in submenu:
                        if smenu['id'] in exist_menu:
                            continue
                        else:
                            exist_menu.add(smenu['id'])
                        a = GroupsMenuOrder(description=description, groups_str=group_str,
                                            menu_id=smenu['id'], rank=rank)
                        sc.add(a)
                        rank += 1
        return 0

    @staticmethod
    def update(groups, description, menus):
        return GroupsMenuOrder.create(groups, description, menus)

    @staticmethod
    def delete(groups):
        short_desc = str(sorted(groups))
        with session_context() as sc:
            sc.query(GroupsMenuOrder).filter(GroupsMenuOrder.groups_str == short_desc).delete()

    @staticmethod
    def _to_format(list_items):
        menu_data = {}
        for item in list_items:
            # id, name, url, father, rank
            if item[3] == -1:
                level1_menu = {
                    'id': item[0],
                    'name': item[1],
                    'rank': item[-1],
                }
                if item[2]:
                    level1_menu['url'] = item[2]
                menu_data[item[0]] = level1_menu
        for item in list_items:
            # print(item[3], menu_data.keys(), item[1])
            if item[3] in menu_data:
                submenu = menu_data[item[3]].setdefault('submenu', [])
                submenu.append({
                    'id': item[0],
                    'name': item[1],
                    'url': item[2],
                    'rank': item[-1],
                })
        for key in menu_data:
            submenu = menu_data[key].get('submenu', [])
            if len(submenu) > 0:
                menu_data[key]['submenu'] = sorted(menu_data[key]['submenu'], key=lambda x: x['rank'])
        return sorted(list(menu_data.values()), key=lambda x: x['rank'])

    @staticmethod
    def fetch(groups):
        """
        get groups's menu_id and detail information
        :param groups: list of group id
        :return: dictionary to present the {
            "groups": "1,3,4",
            "description": "top_manage",
            "menu": [{
                "id": 10,
                "name": "策略研究",
                "rank": 1,
                "submenu": [
                    {"url": "/index.html", "rank": 2, "name": "策略创建", "id": 12},
                ]
            }]
        """
        with session_context() as sc:
            sql = """select b.id,b.name,b.url,b.father, a.id as rank from menu as b right join group_menu as a 
            on a.menu_id=b.id where user_group_id in :groups"""
            menu_items = sc.execute(sql, {"groups": groups}).fetchall()
            exist_item = set()
            tmp_menus = []
            for menu in menu_items:
                if menu['id'] in exist_item:
                    continue
                else:
                    exist_item.add(menu['id'])
                    tmp_menus.append(menu)
            menu_items = tmp_menus
            groups_str = str(sorted(groups))
            sql = """select description, menu_id, rank from groups_menu_order 
            where groups_str=:groups_str"""
            details = sc.execute(sql, {"groups_str": groups_str}).fetchall()
            desc = ''
            if details:
                map_detail = {}
                for one in details:
                    map_detail[one[1]] = one[2]
                    if not desc:
                        desc = one[0]
                pre_rank = -1
                for idx, menu in enumerate(menu_items):
                    real_menu = list(menu)
                    # update the menu rank
                    real_menu[-1] = map_detail.get(menu[0], pre_rank)
                    menu_items[idx] = real_menu
                    pre_rank = real_menu[-1]
            menu = GroupsMenuOrder._to_format(menu_items)
            return {
                'description': desc,
                'menu': menu
            }

    @staticmethod
    def get_all_comb_grp():
        with session_context() as sc:
            sql = """select user_id, user_group_id, users.name, user_group.name from user_group_info left join users 
            on users.id=user_group_info.user_id left join user_group
            on user_group_info.user_group_id=user_group.id order by user_group_id"""
            items = sc.execute(sql).fetchall()
            map_user = {}
            user_detail = {}
            for item in items:
                map_user.setdefault(item[0], [])
                map_user[item[0]].append(item[1])
                user_detail.setdefault(item[0], {})
                user_detail[item[0]]['name'] = item[2]
                user_detail[item[0]].setdefault('groupid', [])
                user_detail[item[0]].setdefault('group', [])
                user_detail[item[0]]['groupid'].append(item[1])
                user_detail[item[0]]['group'].append(item[3])
            map_user = dict((k, tuple(sorted(v))) for k, v in map_user.items() if len(v) > 1)
            ret_msg = {}
            for k, v in map_user.items():
                ret_msg.setdefault(v, {})
                ret_msg[v].setdefault('users', [])
                ret_msg[v]['users'].append({
                    'id': k,
                    'name': user_detail[k]['name'],
                })
                ret_msg[v]['groupid'] = user_detail[k]['groupid']
                ret_msg[v]['group'] = user_detail[k]['group']
            return ret_msg


class APIRequestTrack(ModelBase):
    __tablename__ = 'api_tracker'

    id = Column(BIGINT, primary_key=True, autoincrement=True)
    user_id = Column(BIGINT, nullable=True)                       # user or None for anon
    requested_at = Column(DATETIME, index=True)                   # timestamp of request arrive at
    response_ms = Column(INTEGER, default=0)                      # number of milliseconds to respond
    path = Column(VARCHAR(200), index=True)                       # request path
    class_nm = Column(VARCHAR(200), index=True)                   # handler class name
    remote_address = Column(VARCHAR(200))                         # remote IP address of request
    host = Column(VARCHAR(200))                                   # originating host of request
    method = Column(VARCHAR(10))                                  # HTTP method (GET,PUT,POST)
    query_params = Column(TEXT, nullable=True)                    # query params
    data = Column(TEXT, nullable=True)                            # POST body data
    response = Column(TEXT, nullable=True)                        # response
    errors = Column(TEXT, nullable=True)                          # error traceback
    status_code = Column(INTEGER)                                 # status code
    wx_openid = Column(VARCHAR(128))

    @staticmethod
    def add_record(path, class_name, remote_address, host, method,
                   query_params, data):
        return APIRequestTrack(**{
            'path': path,
            'requested_at': datetime.datetime.now(),
            'class_nm': class_name,
            'remote_address': remote_address,
            'host': host,
            'method': method,
            'query_params': query_params,
            'data': data
        })

    @staticmethod
    def update_record(item, user_id, response, errors, status_code):
        item.user_id = user_id
        item.response = response
        item.errors = errors
        item.status_code = status_code

    @staticmethod
    def save_record(item):
        with session_context() as sc:
            sc.add(item)

# class UserGroupPermission(ModelBase):
#
#     __tablename__ = 'user_group_permission'
#
#     id = Column(BIGINT, primary_key=True, autoincrement=True)
#     user_group_id = Column(INTEGER, nullable=False)
#     group_permission = Column(VARCHAR(64), nullable=False, index=True)


class OTCWxUserInfo(ModelBase):
    __tablename__ = 'otc_wx_user_info'

    id = Column(BIGINT, autoincrement=True, primary_key=True)
    openid = Column(VARCHAR(128), nullable=False)
    access_token = Column(VARCHAR(128))
    refresh_token = Column(VARCHAR(128))
    #high/middle/low
    nickname = Column(VARCHAR(128))
    province = Column(VARCHAR(32))
    city = Column(VARCHAR(32))
    unionid = Column(VARCHAR(128))
    headimgurl = Column(VARCHAR(256))
    user_id = Column(BIGINT)
    create_time = Column(DATETIME, nullable=False, server_default=func.now())

    @staticmethod
    def save_user_id(openid, user_id):
        with session_context() as sc:
            item = sc.query(OTCWxUserInfo).filter_by(openid=openid).first()
            if item:
                item.user_id = user_id
            sc.commit()

    @staticmethod
    def del_user_id(openid):
        with session_context() as sc:
            item = sc.query(OTCWxUserInfo).filter_by(openid=openid).first()
            if item:
                item.user_id = None
            sc.commit()

    @staticmethod
    def del_user_id_batch(openid_list):
        with session_context() as sc:
            items = sc.query(OTCWxUserInfo).filter(OTCWxUserInfo.openid.in_(openid_list)).all()
            for item in items:
                item.user_id = None
            sc.commit()


if __name__ == '__main__':
    from myrpc.apps.auth.db import engine
    from sqlalchemy_utils import database_exists, create_database

    if not database_exists(engine.url):
        create_database(engine.url)
    ModelBase.metadata.create_all(engine)

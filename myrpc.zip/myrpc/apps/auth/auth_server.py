# -*- coding: utf-8 -*-

import tornado.ioloop
import tornado.web
from tornado import autoreload

from myrpc.apps.auth.config import config
from myrpc.apps.auth.dj_handlers import CSRFHandler, LoginHandler, \
    HomepageHandler, ViewUserHandler, \
    AdminUserHandler, AuditHandler, RegisterOTCHandle,\
    ChangePasswordHandler, VerifyCodeHandler, \
    ForgetPasswordHandler, GroupHandler, \
    GroupMemberHandler, AdminMenuHandler, \
    UserRolesHandler, OTCSampleUserHandle
from myrpc.apps.auth.handlers import UserListHandle, AccountsHandle, AccountsDetailHandle, \
    RoleAndCredentialHandle, CompanyHandler, \
    CompanyUserListHandler, CompanyUserItemHandler, \
    UserTypeHandler, UserTypeDetailHandle, \
    CredentialTypeHandler, CredentialTypeDetailHandle, \
    RegisterHandle, AuditHandle, \
    ActiveHandle, OptionalAuthHandler, LogoHandler, UserPermissionHandler, \
    AdminGroupsMenuHandler

urls = [
    # migrate from django-auth
    (r"/api/v1/csrf", CSRFHandler),                                     # csrf
    (r"/api/v1/session", LoginHandler),                                 # login and logout
    (r"/api/v1/homepage", HomepageHandler),                             # group homepage
    (r"/api/v1/user", ViewUserHandler),                                 # user detail information
    (r"/api/v1/users", AdminUserHandler),                               # original user management
    (r"/api/v1/admin/user", AdminUserHandler),                          # support add user
    (r"/api/v1/user/(?P<id>\d+)$", AdminUserHandler),                   # put or delete specify user_id
    (r"/api/v1/user/register_otc$", RegisterOTCHandle),
    (r"/api/v1/user/otc_sample_user$", OTCSampleUserHandle),
    (r"/api/v1/user/audit$", UserListHandle),                           # query audit information
    (r"/api/v1/user/audit/(?P<user_id>\d+)$", AuditHandler),            # audit post operation
    (r"/api/v1/user/active/(?P<user_id>\d+)$", AuditHandler),           # active handler
    (r"/api/v1/user/accounts$", AccountsHandle),                        # query the accounts (-> handler)
    (r"/api/v1/user/accounts/(?P<id>\d+)$", AccountsDetailHandle),      # accounts management
    (r"/api/v1/user/types$", RoleAndCredentialHandle),                  # credential editor
    (r"/api/v1/user/passwd$", ChangePasswordHandler),                   # change the password of specified user
    (r"/api/v1/user/passwd/(?P<id>\d+)$", ChangePasswordHandler),       # superuser change anyone's password
    (r"/api/v1/verify-code/email$", VerifyCodeHandler),                 # email change password
    (r"/api/v1/password", ForgetPasswordHandler),                       # password editor
    (r"/api/v1/groups", GroupHandler),                                  # g group viewer
    (r"/api/v1/group", GroupHandler),                                   # new group handler
    (r"/api/v1/group/(?P<id>\d+)$", GroupHandler),                      # edit and delete group handler
    (r"/api/v1/members", GroupMemberHandler),                           # query user's group
    (r"/api/v1/menus", AdminMenuHandler),                               # g menus viewer
    (r"/api/v1/menu/(?P<id>\d+)$", AdminMenuHandler),                   # edit menu handler
    (r"/api/v1/menu", AdminMenuHandler),                                # new menu
    (r"/api/v1/user/role", UserRolesHandler),                           # provide api to bind roles
    (r"/api/v1/groupsmenu", AdminGroupsMenuHandler),                    # manage user's menu of multiple group

    # (r"/api/v1/third_auth", ThirdAuthHandler),                        # thread party auth

    # later auth from tornado
    (r"/api/v1/logo", LogoHandler),
    (r"/api/v1/companies", CompanyHandler),                             # view and create company
    (r"/api/v1/companies/(?P<id>\d+)$", CompanyHandler),                # edit and delete company
    (r"/api/v1/company/users$", CompanyUserListHandler),
    (r"/api/v1/company/users/(?P<id>\d+)$", CompanyUserItemHandler),    # maybe this is not elegant
    (r"/api/v1/ssoauth/usertype$", UserTypeHandler),
    (r"/api/v1/ssoauth/usertype/(?P<id>\d+)$", UserTypeDetailHandle),
    (r"/api/v1/ssoauth/credentialtype$", CredentialTypeHandler),
    (r"/api/v1/ssoauth/credentialtype/(?P<id>\d+)$", CredentialTypeDetailHandle),
    (r"/api/v1/ssoauth/user$", UserListHandle),
    (r"/api/v1/ssoauth/user/register$", RegisterHandle),
    (r"/api/v1/ssoauth/user/register/meta", RoleAndCredentialHandle),
    (r"/api/v1/ssoauth/user/audit/(?P<id>\d+)$", AuditHandle),
    (r"/api/v1/ssoauth/user/active/(?P<id>\d+)$", ActiveHandle),
    (r"/api/v1/ssoauth/accounts$", AccountsHandle),
    (r"/api/v1/ssoauth/accounts/(?P<id>\d+)$", AccountsDetailHandle),
    (r"/api/v1/ssoauth/optionalauth", OptionalAuthHandler),
    (r"/api/v1/user/permission/(?P<id>\w+)$", UserPermissionHandler),
]


def make_app():
    return tornado.web.Application(
        urls, settings={'debug': config.DEBUG},
        cookie_secret='83f38a41df087d2f069b0d5f6bcbce5eaab472fd'
    )


if __name__ == "__main__":
    app = make_app()
    app.listen(config.PORT)
    if config.DEBUG:
        autoreload.start()
        autoreload.watch('dj_handlers.py')
        autoreload.watch('handlers.py')
        autoreload.watch('models.py')
        autoreload.watch('common.py')
    tornado.ioloop.IOLoop.current().start()

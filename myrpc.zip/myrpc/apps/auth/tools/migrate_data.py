# -*- coding: utf-8 -*-
# @Time    : 2018/5/23 12:48 AM
# @Author  : Colin
# @File    : migrate_data.py.py
# @Email   : zhouchaolin@mycapital.net


from sqlalchemy import create_engine
from auth.models import Users, UserGroup, Menu, GroupMenu, UserGroupInfo
from auth.db import session


source = {
    'host': '127.0.0.1',
    'port': 3306,
    'user': 'root',
    'passwd': '123456',
    'db': 'rss'
}

source_engine = create_engine('mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s?charset=utf8' % source)

source = {
    'host': '127.0.0.1',
    'port': 3306,
    'user': 'root',
    'passwd': '123456',
    'db': 'datahub'
}

target_engine = create_engine('mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s?charset=utf8' % source)


s = session()


def update_user_table():
    exec_sqls = [
        "alter table users add tel_num varchar(128) null after mobile_num",
        "alter table users add description varchar(255) null after name",
        "alter table users add telephone varchar (128) null after advantage",
        "alter table users add address varchar (255) null after telephone",
        "alter table users add chg_password bool default 0 after is_superuser",
        "alter table users add linkman varchar(255) null after name",
        "alter table users add is_superuser bool default false after wechat",
        "alter table users add telephone varchar (128) null after advantage",
        "alter table users change email email varchar(128) null unique",
        "alter table users change description description varchar(512) null",
        "alter table users change chg_password chg_password bool default true",
        "alter table users change auditer auditor integer",
        "update users set is_superuser=0",
        "update users set is_superuser=1 where name='root'",
        # user_group
        "alter table user_group add home_page varchar(255) null after description",
        # company
        "alter table company add domain varchar(255) null description",
    ]
    for sql in exec_sqls:
        try:
            target_engine.execute(sql)
        except:
            pass


def migrate_user():
    result = source_engine.execute("select * from auth_user")
    for row in result:
        dict_data = dict(row)
        dict_data['chg_password'] = 0
        dict_data['is_audit'] = dict_data['is_active']
        # only update the password, is_audit chg_password
        s.query(Users.id == dict_data['id']).update({
                'password': dict_data['password'],
                'is_audit': dict_data['is_active'],
        })


def migrate_group():
    result = source_engine.execute("select * from auth_group")
    for row in result:
        dict_data = dict(row)
        dict_data['description'] = dict_data['name']
        dict_data['r_create_user_id'] = 0
        dict_data['r_update_user_id'] = 0
        t = UserGroup(**dict_data)
        s.merge(t)
    s.commit()
    target_engine.execute("update user_group set type=null,company_id=-1")
    # add four groups
    for company_name in ['jiahe', 'guanzhou']:
        ug = UserGroup(name='%s_manager' % company_name,
                       description='the %s manager' % company_name,
                       r_update_user_id=0,
                       r_create_user_id=0,
                       type="manager")
        s.add(ug)
        ug = UserGroup(name='%s_customer' % company_name,
                       description='the %s customer' % company_name,
                       r_update_user_id=0,
                       r_create_user_id=0,
                       type="customer")
        s.add(ug)
        s.commit()


def migrate_menu():
    result = source_engine.execute("select * from bss_menu")
    for row in result:
        dict_data = dict(row)
        print(dict_data)
        del dict_data['permission_id']
        t = Menu(**dict_data)
        s.merge(t)
    s.commit()


def migrate_group_menu():
    sql = """
    SELECT b.id as menu_id, c.group_id as user_group_id FROM bss_menu b
    inner join auth_permission a
    inner join auth_group_permissions c
    on b.permission_id = a.id and c.permission_id = b.permission_id
    """
    result = source_engine.execute(sql)
    for row in result:
        dict_data = dict(row)
        t = GroupMenu(**dict_data)
        s.merge(t)
    s.commit()


def migrate_user_vs_group():
    sql = "select group_id as user_group_id, user_id from auth_user_groups"
    result = source_engine.execute(sql)
    for row in result:
        dict_data = dict(row)
        dict_data['r_create_user_id'] = 0
        dict_data['r_update_user_id'] = 0
        if dict_data['user_id'] != 69:
            t = UserGroupInfo(**dict_data)
            s.add(t)
            s.commit()


def create_company():
    sql = "insert company(name, description, domain) values('%s', '%s', '%s')" % \
          ("嘉禾", "jiahe company", "jiahe.mycapital.net")
    target_engine.execute(sql)
    sql = "insert company(name, description, domain) values('%s', '%s', '%s')" % \
          ("冠洲", "guanzhou company", "guanzhou.mycapital.net")
    target_engine.execute(sql)


def bind_group_company():
    sql = "update user_group set company_id=1 where name like '%%jiahe%%'"
    target_engine.execute(sql)
    sql = "update user_group set company_id=2 where name like '%%guanzhou%%'"
    target_engine.execute(sql)


def create_credential():
    fmt = """
        insert credential_type(id, name, r_create_user_id, r_update_user_id)
        values(%d, '%s', 0, 0)
    """
    idx = 1
    for credential in ['id_number', 'social_credit_code']:
        sql = fmt % (idx, credential)
        target_engine.execute(sql)
        idx += 1


def start():
    update_user_table()
    migrate_user()
    migrate_group()
    migrate_menu()
    create_company()
    migrate_group_menu()
    migrate_user_vs_group()
    create_credential()
    bind_group_company()

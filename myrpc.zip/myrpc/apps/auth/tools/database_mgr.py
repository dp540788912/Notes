# -*- coding: utf-8 -*-
# @Time    : 2018/5/22 2:11 PM
# @Author  : Colin
# @File    : db_ops.py.py
# @Email   : zhouchaolin@mycapital.net


from auth.models import *
from auth.db import ModelBase, engine


def create_db():
    from sqlalchemy_utils import database_exists, create_database
    if not database_exists(engine.url):
        create_database(engine.url)
    print("The data base exist or not?", database_exists(engine.url))


def create_tb():
    ModelBase.metadata.create_all(engine)


def delete_tb():
    ModelBase.metadata.drop_all(engine)


def backup_db():
    pass


def recreate():
    delete_tb()
    create_tb()


def get_class_by_tablename(tablename):
    for c in ModelBase._decl_class_registry.values():
        if hasattr(c, '__tablename__') and c.__tablename__ == tablename:
            return c


def create_if_not_exist(target):
    """
    check if the table exist or not, if not exist then create the table
    :return:
    """
    print(engine.url)
    all_tables = ModelBase.metadata.tables.keys()
    for tab in all_tables:
        print("original", tab)
        out = target.execute("show tables like '%s'" % tab)
        exist = False
        tb_name = None
        for row in out:
            if len(row) != 0:
                print("finded", row)
                tb_name = row[0]
                exist = True
                break
        if not exist:
            print(tb_name, "not exist, try to create")
            classname = get_class_by_tablename(tab)
            classname.__table__.create(engine)
        else:
            print(tb_name, "table alreadly exist")


if __name__ == "__main__":
    # recreate()
    create_tb()

# -*- coding: utf-8 -*-

"""
import vm_uid and enable_notebook message
"""

import sys
from contextlib import contextmanager

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker


udefs = """
10000  dongbo        19_peter
10002  jinyudong     177_jinyudong 
10003  zhanglong     34_zhanglong
10004  huajian       295_huajian 
10005  mjiang        71_Mjiang
10006  luoyang       38_luoyang  
10007  huangchunchun 407_captainhcc
10008  alex.yao      29_alex
10009  weizhenyu     21_weizhenyu
10010  zengyi        76_zengyi
10011  joe           83_joe
10012  xuxx          25_laurence_xu
10013  zijun         28_zijun
10014  hewenguan     47_hewenguan
10015  zhangqi       487_qz2169
10016  findle        303_findle   
10017  xiechunlin    455_chunlin.xie  
10018  douwen        46_douwen 
10019  wangguo       607_wangguo
10020  tianhao       609_tianhao
10021  tangbin       612_tangbin  
10022  zhouchaolin   12_zhouchaolin
10023  rice          17_rice
10024  qianghao
10025  hulizhen
10026  ray           15_ray
10027  panyihui      698_panyihui
"""

sys.path.append("../")

from models import Users

# add two columns to users if not exist
mysql = 'mysql://%s:%s@%s:%s/%s' % ('root', '123456', '192.168.1.14', 3306, 'datahub')
ModelBase = declarative_base()
engine = create_engine(mysql + '?charset=utf8', encoding='utf-8', pool_recycle=3600, echo=False)
Session = sessionmaker(bind=engine)


@contextmanager
def session_context():
    session = Session()
    try:
        yield session
        session.commit()
    except:
        session.rollback()
        raise
    finally:
        session.close()


with session_context() as sc:
    ret = sc.execute('desc users')
    fields = []
    for row in ret:
        fields.append(row[0])
    if 'vm_uid' not in fields:
        sc.execute('alter table users add column vm_uid int default -1')
    else:
        print("vm_uid already exist")
    if 'enable_notebook' not in fields:
        sc.execute('alter table users add column enable_notebook bool default false')
    else:
        print("enable_notebook already exist")

# insert the history definition to db
with session_context() as sc:
    for udef in udefs.split('\n'):
        if udef:
            items = [x for x in udef.split(' ') if x]
            if len(items) == 3 and '_' in items[2]:
                vm_uid = int(items[0])
                user_id, user_name = items[2].split('_', 1)
                u = sc.query(Users).filter(Users.id == int(user_id)).first()
                if u:
                    u.vm_uid = vm_uid
                    u.enable_notebook = True

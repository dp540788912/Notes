update users set is_superuser=1 where name='root';
update users set is_superuser=0;

alter table users change auditer auditor integer;
alter table users change is_superuser is_superuser bool default false;
alter table users change chg_password chg_password bool default true;

ALTER TABLE Persons AUTO_INCREMENT=100;
# -*- coding: utf-8 -*-
# @Time    : 2018/5/23 8:30 PM
# @Author  : Colin
# @File    : common.py.py
# @Email   : zhouchaolin@mycapital.net

import base64
import json
import re
import redis
from myrpc.apps.auth.config import logger
from myrpc.apps.auth.config import config, internal_ip, logger
from myrpc.apps.auth.db import session_context as mysql_sc

session_rds = None


def connect_rds():
    global session_rds
    if not session_rds:
        session_rds = redis.Redis(config.session_cache['host'], config.session_cache['port'])


def check_session(session_id):
    connect_rds()
    s = session_rds.get('session:%s' % session_id)
    if s:
        data = json.loads(str(base64.b64decode(s), 'utf-8').split(':', 1)[-1])
        if '_auth_user_id' in data:
            res = {
                'id': int(data['_auth_user_id']),
                'username': data.get('_auth_user_name', ''),
                'nickname': data.get('_auth_user_nickname', ''),
                'type': data.get('type', ''),
                'chg_password': data.get('chg_password', ''),
                'auto_uid': data.get('auto_uid', ''),
                'groups': data.get('groups', []),
            }
            if res['username'] == 'root':
                res['is_superuser'] = True
            else:
                res['is_superuser'] = False
            return res
    return {}


def clear_wx_cache(user_id):
    key_to_del = []
    openid_list = []
    connect_rds()

    keys = session_rds.keys('session:*')
    for k in keys:
        s = session_rds.get(k)
        if s:
            data = json.loads(str(base64.b64decode(s), 'utf-8').split(':', 1)[-1])
            if '_auth_user_id' in data and data['_auth_user_id'] == user_id:
                key_to_del.append(k)

    keys = session_rds.keys('openid:*')
    for k in keys:
        s = session_rds.get(k)
        if s:
            data = json.loads(str(base64.b64decode(s), 'utf-8').split(':', 1)[-1])
            if '_auth_user_id' in data and data['_auth_user_id'] == user_id:
                key_to_del.append(k)
                openid_list.append(str(k, 'utf-8').split(':')[-1])

    for k in key_to_del:
        logger.info('clear redis cache: %s', k)
        session_rds.delete(k)
    return openid_list


class CurrentUserMixin(object):

    def get_current_user(self):
        sessionid = self.get_cookie('sessionid')
        if not sessionid:
            self.write(json.dumps({
                'code': 401,
                'error': 'Sessionid not found.'
            }))
            self.finish()
            return False
        sessionid = self.get_cookie('sessionid')
        res = check_session(sessionid)
        if not res:
            self.write(json.dumps({
                'code': 401,
                'error': 'User not login.',
            }))
            self.finish()
            return False
        self.current_user = res
        return True


class JsonPayloadMixin(object):

    def get_payload(self):
        if self.request.headers['content-type'].lower().startswith("application/json"):
            return json.loads(str(self.request.body, 'utf-8'))
        return {}

    _EMPTY_OBJECT = object()

    def get_my_key(self, key, default=_EMPTY_OBJECT):
        if not hasattr(self, '_payload_'):
            setattr(self, '_payload_', self.get_payload())
        payload = getattr(self, '_payload_')
        tmp_data = payload.get(key)
        if tmp_data is not None:
            return tmp_data
        if default is self._EMPTY_OBJECT:
            return self.get_body_argument(key)
        else:
            return self.get_body_argument(key, default)

    def get_my_keys(self, key, default=_EMPTY_OBJECT):
        if not hasattr(self, '_payload_'):
            setattr(self, '_payload_', self.get_payload())
        payload = getattr(self, '_payload_')
        tmp_data = payload.get(key)
        if tmp_data is not None:
            return tmp_data
        if default is self._EMPTY_OBJECT:
            return self.get_body_arguments(key)
        return self.get_body_arguments(key, default)


class ListMixin(object):
    def get(self, *args, **kwargs):
        res = []
        with mysql_sc() as sc:
            lines = sc.query(self.model).all()
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))


class DetailMixin(object):

    def get(self, *args, **kwargs):
        with mysql_sc() as sc:
            o = sc.query(self.model).filter_by(id=kwargs['id']).first()
            if o:
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
            else:
                self.write(json.dumps({
                    'code': 404,
                    'error': 'Data not found.',
                }))


class DeleteMixin(object):
    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                sc.query(self.model).filter_by(id=kwargs['id']).delete()
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                }))
        except Exception as e:
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class CreateMixin(object):
    def post(self, *args, **kwargs):
        payload = self.get_payload()
        try:
            data = {}
            for k, v in self.fields.items():
                data[k] = payload[v]
            with mysql_sc() as sc:
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class MyHost(object):
    def fetch_domain(self):
        visit_url = self.request.headers.get('referer')
        authority = self.request.headers.get(':authority')
        if visit_url:
            domain = re.findall(r'([\w]*\.mycapital\.net)', visit_url)
            if isinstance(domain, list) and len(domain) > 0:
                self.domain = domain[0]
            else:
                self.domain = None
        if not visit_url or self.domain is None:
            if authority:
                self.domain = authority
            elif not config.DEBUG:
                self.domain = config.web_host
            elif len(internal_ip) > 0:
                self.domain = internal_ip[0]
            else:
                self.domain = '127.0.0.1'
        logger.info("visit_url: %s, authority: %s, internal_ip: %s, domain: %s",
                    visit_url, authority, internal_ip, self.domain)


class NegErrCode:
    API_SUCCESS = 0
    NAME_OR_PASSWORD_ERROR = 201
    USER_ALREADY_EXIST = 210
    USER_NOT_FOUND = 211
    VERIFY_CODE_ERROR = 212
    VERIFY_CODE_EXPIRE = 213
    NOT_LOGIN = 401
    SERVER_INTERNAL_ERROR = 500
    CREATE_FAILED = 1001
    UPDATE_FAILED = 1002
    DELETE_FAILED = 1003
    PERMISSION_DENY = 1004
    TARGET_NOT_EXIST = 1005
    FETCH_FAILED = 1006
    ARGUMENT_EMPTY_ERROR = 1007
    ARGUMENT_NOT_VALID = 1008
    REQ_TOO_FREQUENT = 1009
    QUOTE_NOT_FOUND = 1010
    NEED_TO_ACTIVATE = 1015
    REQ_NOT_VALID = 2000
    REQ_DOMAIN_ERROR = 2001
    SEND_EMAIL_FAILED = 2002
    AUDIT_FAILED = 2003
    NOT_FINISH_ERROR = 2004
    ARGUMENT_PARSE_ERROR = 2005
    CUSTOM_ERROR = 2006

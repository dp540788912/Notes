# -*- coding:utf-8 -*-

import traceback
from datetime import datetime
from functools import wraps

from myrpc.apps.auth.models import APIRequestTrack


def post_process(self):
    response_timedelta = datetime.now() - self.req_log.requested_at
    response_ms = int(response_timedelta.total_seconds() * 1000)
    self.req_log.response_ms = response_ms
    self.req_log.status_code = self.get_status()
    # if self._write_buffer:
    #     self.req_log.response = self._write_buffer[0]
    if self.current_user:
        self.req_log.user_id = self.current_user['id']
    elif hasattr(self, 'session') and self.session.get('_auth_user_id'):
        self.req_log.user_id = self.session.get('_auth_user_id')
    wx_openid = self.get_cookie('openid')
    if wx_openid:
        self.req_log.wx_openid = wx_openid
    APIRequestTrack.save_record(self.req_log)


def pre_process(self):
    host = self.request.host
    x_real_ip = self.request.headers.get("X-Real-IP")
    remote_address = x_real_ip or self.request.remote_ip
    class_name = self.__class__.__name__
    path = self.request.uri
    method = self.request.method
    if method in ['get', 'GET']:
        query_params = str(self.request.arguments)
        data = ''
    else:
        query_params = ''
        data = self.request.body
    self.req_log = APIRequestTrack.add_record(path, class_name, remote_address, host, method, query_params, data)


def api_tracker(hdl_f):
    @wraps(hdl_f)
    def wrapper(self, *args, **kwargs):
        try:
            pre_process(self)
            hdl_f(self, *args, **kwargs)
        except:
            if hasattr(self, 'req_log'):
                self.req_log.errors = traceback.format_exc()
            raise
        finally:
            if hasattr(self, 'req_log'):
                post_process(self)
    return wrapper


def for_all_req_methods(real_dec):
    def decorator(cls):
        for attr in cls.__dict__:
            if attr in ['get', 'post', 'put', 'delete']:
                setattr(cls, attr, real_dec(getattr(cls, attr)))
        return cls
    return decorator

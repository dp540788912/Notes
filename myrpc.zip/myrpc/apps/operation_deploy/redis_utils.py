"""Redis Utilities
"""
import redis
import pickle
import json
from config import config
from log import logger


def singleton(cls):
    instances = {}

    def _singleton(*args, **kw):
        if cls not in instances:
            instances[cls] = cls(*args, **kw)
        return instances[cls]

    return _singleton


@singleton
class RedisHelper(object):
    def __init__(self):
        self.pool = redis.ConnectionPool(host=config.redis['host'], port=config.redis['port'])
        self.rds = redis.Redis(connection_pool=self.pool)
        self.config = config.redis

    def conn(self):
        if not self.rds:
            self.rds = redis.Redis(connection_pool=self.pool)
        return self.rds

    def set_hash_cache(self, redis_key, key, value):
        try:
            rds = self.conn()
            target_value = pickle.dumps(value)
            rds.hset(redis_key, key, target_value)
        except Exception as err:
            logger.error("set redis cache error: %s", err, exc_info=True)

    def get_hash_cache(self, redis_key, key):
        try:
            rds = self.conn()
            target_value = rds.hget(redis_key, key)
            if target_value is None:
                return target_value
            return pickle.loads(target_value)
        except Exception as err:
            logger.error("get redis cache error: %s", err, exc_info=True)

    def set_cache(self, redis_key, data, expire_seconds):
        try:
            rds = self.conn()
            if expire_seconds:
                return rds.setex(redis_key, json.dumps(data), int(expire_seconds))
            return rds.set(redis_key, data)
        except Exception as err:
            logger.error("set redis cache error: %s", err, exc_info=True)

    def get_cache(self, redis_key):
        try:
            rds = self.conn()
            data = rds.get(redis_key)
            return data and json.loads(str(data, 'utf-8'))
        except Exception as err:
            logger.error("set redis cache error: %s", err, exc_info=True)

    def rpush_redis_cmd(self, iphost, cmd):
        try:
            rds = self.conn()
            r_queue = self.config['cmd_key'] + iphost
            rds.rpush(r_queue, cmd)
            # logger.info('rpush redis=[%s]: cmd=[%s]' % (r_queue, cmd))
        except Exception as e:
            logger.error(str(e))
            raise e
            return False
        return True

    def query_redis_iphost(self, host):
        iphost = ''
        try:
            rds = self.conn()
            hosts = rds.smembers('a:oss:hosts')
            for h in hosts:
                h = str(h, 'utf-8')
                if h == host:
                    iphost = h
        except Exception as e:
            logger.error(str(e))
            raise e
            return ''
        return iphost

    def lpop_redis_cmd(self, iphost, seq):
        data = None
        try:
            rds = self.conn()
            r_queue = self.config['rsp_key'] + iphost
            for d in rds.lrange(r_queue, 0, -1):
                if json.loads(str(d, 'utf-8'))['seq'] == seq:
                    data = d
                    break
            if data:
                rds.lrem(r_queue, data, 0)
                logger.info('lpop redis=[%s], seq=[%d]: data=[%s]' % (r_queue, seq, data))
            return data
        except Exception as e:
            logger.error(str(e))
            raise e
            return None

    def query_agent_online(self, host):
        """

        query agent from hash a:oss:monitor:processes

        Args:
            host: str

        Returns:
            int

        """
        online = 2
        try:
            rds = self.conn()
            d = rds.hget('oss:monitor:overview:host_status', host)
            if d:
                data = json.loads(str(d, 'utf-8'))
                online = 2 if data.get('agent_status', -2) == -2 else 0
        except Exception as e:
            logger.error(str(e))
            raise e
        finally:
            return online

    def query_process_online(self, host):
        """

        query process from hash a:oss:monitor:processes

        Args:
            host: str

        Returns:
            dict[Str:Any]:

        """
        res = {}
        try:
            rds = self.conn()
            d = rds.hget('a:oss:monitor:processes', host)
            if d:
                data = json.loads(str(d, 'utf-8'))
                process_list = data.get('process', [])
                for process in process_list:
                    process_id = process.get('process_id', 0)
                    if process.get('status', -1) == -1:
                        res[process_id] = 2
                    else:
                        if process.get('is_running', 0) == 1:
                            res[process_id] = 0
                        else:
                            res[process_id] = 2
        except Exception as e:
            logger.error(str(e))
            raise e
        finally:
            return res

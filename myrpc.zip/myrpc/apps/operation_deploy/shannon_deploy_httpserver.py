#-*- coding: utf-8 -*-

import tornado.ioloop
import tornado.web
from tornado.options import define, options

from config import Debug
from log import logger
from handlers import ExchangesListHandler, ExchangesDetailHandler, BrokersListHandler, BrokersDetailHandler, \
    CountersListHandler, CountersDetailHandler, AccountsListHandler, AccountsDetailHandler, ServersListHandler, \
    PathsListHandler, ServersDetailHandler, PathsDetailHandler, UsersListHandler, UsersDetailHandler, \
    PreQuoteConfsListHandler, PreQuoteConfsDetailHandler, PreTunnelConfsListHandler, PreTunnelConfsDetailHandler, \
    PreTraderConfsListHandler, PreTraderConfsDetailHandler, PreAgentConfsListHandler, PreAgentConfsDetailHandler, \
    PreStrategyConfsListHandler, PreStrategyConfsDetailHandler, PreStrategyReConfsListHandler, \
    PreForwarderConfsListHandler, PreForwarderConfsDetailHandler, CounterSeatsListHandler, OnlineRequestListHandler, \
    OnlineRequestDetailHandler, ProgramTypesListHandler, ProgramTypesDetailHandler, ApiTypesListHandler, \
    ApiTypesDetailHandler, ConfigTemplatesListHandler, ConfigTemplatesDetailHandler, ProgramsListHandler, \
    ProgramsDetailHandler, AccountInitCashListHandler, AccountInitCashListHandler, VStrategyLogsListHandler, \
    AccountLogsListHandler, InTradingPositionsHandler, DeployProgramsListHandler, DeployProgramsDetailHandler, \
    DeployStrategiesList, DeployStrategiesDetailHandler, DeployProgramConfsListHandler, DeployStrategyConfsListHandler,\
    DeployConfsListHandler, DeployEvListHandler, VStrategyConfigsListHandler, StrategyNecessariesHandler, \
    AccountServersListHandler, QuoteAppIdHandler, RiskManageListHandler, LiveTradeLogsHandler, \
    DigitalCashOnlineRequestListHandler, DigitalCashServersListHandler, DigitalCashDeployStrategiesHandler, \
    DigitalCashDeleteDeployInfoHandler, DigitalCashStrategyProcessesHandler, DigitalCashEvHandler, \
    DigitalCashStrategyPositionsHandler, DigitalCashStrategyLogHandler, KeplerShmConfHandler, StraIsPlaceOrderInPreMarkerTrading, \
    DeployProcessesOffIDHandler, TrackingHandler, ShannonLiveAccountsHandler, \
    OperateProcessesHandler, OperateUploadStrategiesHandler, OperateDeployedProcessesHandler, PreMergeStrategyListHandler, \
    DeplyConfsInfoHandler,CommandResultHandler,KeplerShmConfControlHandler



urls = [
    (r"/api/v1/shannon/common/exchanges$", ExchangesListHandler),
    (r"/api/v1/shannon/common/exchanges/(?P<id>\d+)$", ExchangesDetailHandler),
    (r"/api/v1/shannon/common/brokers$", BrokersListHandler),
    (r"/api/v1/shannon/common/brokers/(?P<id>\d+)$", BrokersDetailHandler),
    (r"/api/v1/shannon/common/counters$", CountersListHandler),
    (r"/api/v1/shannon/common/counters/(?P<id>\d+)$", CountersDetailHandler),
    (r"/api/v1/shannon/common/accounts$", AccountsListHandler),
    (r"/api/v1/shannon/common/accounts/(?P<id>\d+)$", AccountsDetailHandler),
    (r"/api/v1/shannon/common/servers$", ServersListHandler),
    (r"/api/v1/shannon/common/servers/(?P<id>\d+)$", ServersDetailHandler),
    (r"/api/v1/shannon/common/paths$", PathsListHandler),
    (r"/api/v1/shannon/common/paths/(?P<id>\d+)$", PathsDetailHandler),
    (r"/api/v1/shannon/common/users$", UsersListHandler),
    (r"/api/v1/shannon/common/users/(?P<id>\d+)$", UsersDetailHandler),

    (r"/api/v1/shannon/common/pre_quote_confs$", PreQuoteConfsListHandler),
    (r"/api/v1/shannon/common/pre_quote_confs/(?P<id>\d+)$", PreQuoteConfsDetailHandler),
    (r"/api/v1/shannon/common/pre_tunnel_confs$", PreTunnelConfsListHandler),
    (r"/api/v1/shannon/common/pre_tunnel_confs/(?P<id>\d+)$", PreTunnelConfsDetailHandler),
    (r"/api/v1/shannon/common/pre_trader_confs$", PreTraderConfsListHandler),
    (r"/api/v1/shannon/common/pre_trader_confs/(?P<id>\d+)$", PreTraderConfsDetailHandler),
    (r"/api/v1/shannon/common/pre_agent_confs$", PreAgentConfsListHandler),
    (r"/api/v1/shannon/common/pre_agent_confs/(?P<id>\d+)$", PreAgentConfsDetailHandler),
    (r"/api/v1/shannon/common/pre_strategy_confs$", PreStrategyConfsListHandler),
    (r"/api/v1/shannon/common/pre_strategy_confs/(?P<id>\d+)$", PreStrategyConfsDetailHandler),
    (r"/api/v1/shannon/common/pre_strategy_reconfs$", PreStrategyReConfsListHandler),
    (r"/api/v1/shannon/common/pre_platform_confs$", PreForwarderConfsListHandler),
    (r"/api/v1/shannon/common/pre_platform_confs/(?P<id>\d+)$", PreForwarderConfsDetailHandler),
    (r"/api/v1/shannon/common/counter_seats$", CounterSeatsListHandler),
    (r"/api/v1/shannon/common/pre_merge_strategies$", PreMergeStrategyListHandler),

    (r"/api/v1/shannon/platform/online_request$", OnlineRequestListHandler),
    (r"/api/v1/shannon/platform/online_request/(?P<id>\d+)$", OnlineRequestDetailHandler),

    (r"/api/v1/shannon/trader/program_types$", ProgramTypesListHandler),
    (r"/api/v1/shannon/trader/program_types/(?P<id>\d+)$", ProgramTypesDetailHandler),
    (r"/api/v1/shannon/trader/api_types$", ApiTypesListHandler),
    (r"/api/v1/shannon/trader/api_types/(?P<id>\d+)$", ApiTypesDetailHandler),
    (r"/api/v1/shannon/trader/config_templates$", ConfigTemplatesListHandler),
    (r"/api/v1/shannon/trader/config_templates/(?P<id>\d+)$", ConfigTemplatesDetailHandler),
    (r"/api/v1/shannon/trader/programs$", ProgramsListHandler),
    (r"/api/v1/shannon/trader/programs/(?P<id>\d+)$", ProgramsDetailHandler),
    (r"/api/v1/shannon/vstrategy/account_cash$", AccountInitCashListHandler),
    (r"/api/v1/shannon/trader/st_tradelog$", VStrategyLogsListHandler),
    (r"/api/v1/shannon/trader/account_tradelog$", AccountLogsListHandler),
    (r"/api/v1/shannon/trader/in_trading_position$", InTradingPositionsHandler),

    (r"/api/v1/shannon/operation/deploy_programs$", DeployProgramsListHandler),
    (r"/api/v1/shannon/operation/deploy_programs/(?P<id>\d+)$", DeployProgramsDetailHandler),
    (r"/api/v1/shannon/operation/deploy_strategies$", DeployStrategiesList),
    (r"/api/v1/shannon/operation/deploy_strategies/(?P<id>\d+)$", DeployStrategiesDetailHandler),
    (r"/api/v1/shannon/operation/deploy_confs/programs$", DeployProgramConfsListHandler),
    (r"/api/v1/shannon/operation/deploy_confs/strategies$", DeployStrategyConfsListHandler),
    (r"/api/v1/shannon/operation/processes$", DeployConfsListHandler),
    (r"/api/v1/shannon/operation/deploy_confs_info$", DeplyConfsInfoHandler),
    (r"/api/v1/shannon/operation/deploy_evs$", DeployEvListHandler),
    # (r"/api/v1/shannon/operation/deploy_evs_per_machine$", DeployEvListPreMachineHandler),
    (r"/api/v1/shannon/operation/strategy_xmls$", VStrategyConfigsListHandler),
    (r"/api/v1/shannon/operation/strategy_necessaries$", StrategyNecessariesHandler),
    (r"/api/v1/shannon/operation/account_servers$", AccountServersListHandler),
    (r"/api/v1/shannon/operation/quote_app_id", QuoteAppIdHandler),
    (r"/api/v1/shannon/operation/stra_is_placeorder", StraIsPlaceOrderInPreMarkerTrading),
    (r"/api/v1/shannon/operation/deploy_offline/(?P<vst_id>\d+)$", DeployProcessesOffIDHandler),

    (r"/api/v1/shannon/risk_manage$", RiskManageListHandler),
    (r"/api/v1/shannon/platform/livelogs$", LiveTradeLogsHandler),

    (r"/api/v1/shannon/digital_cash/online_request$", DigitalCashOnlineRequestListHandler),
    (r"/api/v1/shannon/digital_cash/servers$", DigitalCashServersListHandler),
    (r"/api/v1/shannon/digital_cash/deploy_strategies$", DigitalCashDeployStrategiesHandler),
    (r"/api/v1/shannon/digital_cash/delete_deploy_info$", DigitalCashDeleteDeployInfoHandler),
    (r"/api/v1/shannon/digital_cash/strategy/processes$", DigitalCashStrategyProcessesHandler),
    (r"/api/v1/shannon/digital_cash/ev/(?P<id>\d+)$", DigitalCashEvHandler),
    (r"/api/v1/shannon/digital_cash/strategy/positions/(?P<id>\d+)$", DigitalCashStrategyPositionsHandler),
    (r"/api/v1/shannon/digital_cash/strategy/log/(?P<id>\d+)$", DigitalCashStrategyLogHandler),

    (r"/api/v1/shannon/kepler/shm_conf$", KeplerShmConfHandler),
    (r"/api/v1/shannon/kepler/shm_conf_control$", KeplerShmConfControlHandler),

    (r"/api/v1/shannon/track/detail$", TrackingHandler),
    (r'/api/v1/shannon/track/accounts$', ShannonLiveAccountsHandler),

    (r'/api/v1/shannon/operate/processes$', OperateProcessesHandler),
    (r'/api/v1/shannon/operate/upload/strategies$', OperateUploadStrategiesHandler),
    (r'/api/v1/shannon/operate/deployed/processes$', OperateDeployedProcessesHandler),

    (r'/api/v1/shannon/operate/command_result$', CommandResultHandler),
]


class Application(tornado.web.Application):
    def __init__(self, handlers):
        #self.logger = logger
        #self.cfg = config
        settings = dict(
            debug=Debug,
        )
        tornado.web.Application.__init__(self, handlers, **settings)


def make_app():
    return Application(urls)


if __name__ == "__main__":
    define("port", default=18888, help="run on the given port", type=int)
    options.parse_command_line()
    app = make_app()
    app.listen(options.port)
    logger.info("operation deploy server started!!!")
    tornado.ioloop.IOLoop.current().start()


# -*- coding: utf-8 -*-

"""
Notify message to specified users
TODO: 重复的模块。
"""

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import requests


def notify_email(recipients, message, title='MyCapital Notification'):
    sender = 'rss@mycapital.net'
    smtp_server = 'smtp.qiye.163.com'
    username = sender
    password = 'Mycapital0427'
    email_entity = MIMEMultipart('alternative')
    email_entity['From'] = sender
    email_entity['To'] = ','.join(recipients)
    email_entity['Subject'] = title
    body = '<p>%s</p>' % message
    html_text = MIMEText(body, 'html')
    email_entity.attach(html_text)
    try:
        smtp = smtplib.SMTP()
        smtp.connect(smtp_server)
        smtp.login(username, password)
        smtp.sendmail(sender, recipients, email_entity.as_string())
        return True
    except Exception as e:
        raise RuntimeError("发送邮件失败 %s" % e)


# 去掉该函数 
def notify_sms(recipients, message):
    recipients = [str(recipient) for recipient in recipients]
    str_recipients = ','.join(recipients)
    payload = {
        'to': str_recipients,
        'do': 'sms',
        'msg': str(message)
    }
    response = requests.post('http://192.168.1.11:54321', json=payload)
    if response.status_code == 200 and not response.content:
        return True
    raise RuntimeError("发送短信失败")


def notify_wechat(recipients, message):
    #agentid = 1000002
    #secret = 'cmr4XaRxsSbVJBIOGjLlraty6Uw-kwd_zd4Qixq-VQE'
    agentid = 1000003
    secret = 'EIXZMCl-lX4jsyJRTjfYOmQksySB3UeZkJiczOh5Ulo'
    corpid = 'ww7c9916c2f31d5aa4'
    token_url = 'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=%s&corpsecret=%s' % (corpid, secret)
    msg_url = 'https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=%s'
    try:
        response = requests.get(token_url)
        if response.status_code == 200:
            token = response.json()['access_token']
            msg_url = msg_url % token
            payload = {
                "touser": "|".join(recipients),
                "toparty": "",
                "msgtype": "text",
                "agentid": agentid,
                "text": {
                    "content": message
                },
                "safe": "0"
            }
            response = requests.post(msg_url, json=payload)
            json_data = response.json()
            if json_data['errcode'] == 0:
                return True
            raise RuntimeError("发送微信失败: %s" % json_data['errmsg'])
        else:
            raise RuntimeError("无法连接微信服务器")
    except Exception as e:
        raise RuntimeError("发送微信异常: %s" % e)



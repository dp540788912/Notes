#-*-coding:utf-8-*-

import requests
import os
import datetime
import shutil

from sqlalchemy.sql import func, or_
from sqlalchemy.orm import relationship
from sqlalchemy import Column, ForeignKey, PrimaryKeyConstraint
from sqlalchemy.dialects.mysql import BIGINT, DATETIME, DATE, TIME, INTEGER, VARCHAR, TEXT, LONGTEXT, FLOAT, DOUBLE, BOOLEAN, JSON, ENUM, SMALLINT

from db import ModelBase, session, session_context as mysql_sc
from config import config
from utils import is_python_strategy
from log import logger

import time

# TODO: Model定义请使用 strategy_upload中的定义，这里有重复的地方请去掉。

class Exchanges(ModelBase):

    __tablename__ = 'exchanges'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(10), nullable=False, unique=True)
    code = Column(VARCHAR(32), nullable=False, unique=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'code': self.code,
        }


class Brokers(ModelBase):

    __tablename__ = 'brokers'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
        }


class Counters(ModelBase):

    __tablename__ = 'counters'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(36), nullable=False)
    exchange_id = Column(ForeignKey('exchanges.id'))
    broker_id = Column(ForeignKey('brokers.id'))
    broker_no = Column(VARCHAR(32), nullable=True)
    quote_forwarder_addr = Column(VARCHAR(256), nullable=True)
    counter_forwarder_addr = Column(VARCHAR(256), nullable=True)
    query_addr = Column(VARCHAR(256), nullable=True)

    exchange_obj = relationship('Exchanges')
    broker_obj = relationship('Brokers')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'exchange': {
                'id': self.exchange_obj.id,
                'name': self.exchange_obj.name,
            },
            'broker': {
                'id': self.broker_obj.id,
                'name': self.broker_obj.name,
            },
            'broker_no': self.broker_no,
            'quote_forwarder_addr': self.quote_forwarder_addr,
            'counter_forwarder_addr': self.counter_forwarder_addr,
            'query_addr': self.query_addr,
        }


class Accounts(ModelBase):

    __tablename__ = 'accounts'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)
    password = Column(VARCHAR(128), nullable=False)
    fund_total = Column(FLOAT, nullable=True, default=0)
    fund_occupied = Column(FLOAT, nullable=True, default=0)
    broker_id = Column(ForeignKey('brokers.id'))
    user_id = Column(ForeignKey('users.id'))
    valid = Column(BOOLEAN, nullable=False)
    use_turing = Column(BOOLEAN, nullable=True)
    seat = Column(VARCHAR(256), nullable=True, default='CTP主席')
    rsp_pwd = Column(VARCHAR(128), nullable=True)
    client_name = Column(VARCHAR(32), nullable=True)
    need_query = Column(BOOLEAN, nullable=True)
    account_name = Column(VARCHAR(256), nullable=True)
    fund_ratio = Column(VARCHAR(32), nullable=True)
    use_for = Column(VARCHAR(64), nullable=True)
    market = Column(VARCHAR(256), nullable=True)
    counter_seat = Column(VARCHAR(256), nullable=True)
    query_passwd = Column(VARCHAR(256), nullable=True)
    query_broker = Column(VARCHAR(32), nullable=True)
    check_pos = Column(BOOLEAN, nullable=False, default=False)
    product_info = Column(VARCHAR(256), nullable=True)
    auth_code = Column(VARCHAR(256), nullable=True)
    account_prop = Column(VARCHAR(255), nullable=True)

    broker_obj = relationship('Brokers')
    user_obj = relationship('Users')

    def brief(self):
        return {
            'id': self.id,
            'name': self.name,
            'password': self.password,
            'fund_total': self.fund_total,
            'fund_occupied': self.fund_occupied,
            'valid': self.valid,
            'use_turing': self.use_turing,
            'seat': self.seat,
            'rsp_pwd': self.rsp_pwd or '',
            'client_name': self.client_name or '',
            'product_info': self.product_info,
            'auth_code': self.auth_code,
            'account_prop': self.account_prop or '',
        }

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'password': self.password,
            'fund_total': self.fund_total,
            'fund_occupied': self.fund_occupied,
            'broker': {
                'id': self.broker_obj.id,
                'name': self.broker_obj.name,
            },
            'user': {
                'id': self.user_obj.id,
                'name': self.user_obj.name,
            },
            'valid': self.valid,
            'use_turing': self.use_turing or False,
            'seat': self.seat,
            'rsp_pwd': self.rsp_pwd or '',
            'client_name': self.client_name or '',
            'need_query': self.need_query,
            'account_name': self.account_name,
            'fund_ratio': self.fund_ratio,
            'use_for': self.use_for,
            'market': self.market,
            'counter_seat': self.counter_seat,
            'query_passwd': self.query_passwd,
            'query_broker': self.query_broker,
            'check_pos': self.check_pos,
            'product_info': self.product_info,
            'auth_code': self.auth_code,
            'account_prop': self.account_prop or '',
        }


class Servers(ModelBase):

    __tablename__ = 'servers'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    ip = Column(VARCHAR(45), nullable=False, unique=True)
    broker_id = Column(ForeignKey('brokers.id'))
    # 0:shannon  1:digital cash
    use_for = Column(SMALLINT, default=0)

    broker_obj = relationship('Brokers')

    def brief(self):
        return {
            'id': self.id,
            'ip': self.ip,
        }

    def to_dict(self):
        return {
            'id': self.id,
            'ip': self.ip,
            'broker': {
                'id': self.broker_obj.id,
                'name': self.broker_obj.name,
            },
        }


class Paths(ModelBase):

    __tablename__ = 'path'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(256), nullable=False, unique=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
        }


class Users(ModelBase):

    __tablename__ = 'users'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False)
    password = Column(VARCHAR(255), nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'password': self.password,
        }
    

class Strategies(ModelBase):

    __tablename__ = 'strategies'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(256), nullable=False)
    user_id = Column(ForeignKey('users.id'))
    model_id = Column(VARCHAR(8), nullable=True)
    filepath = Column(VARCHAR(256), nullable=False)
    status = Column(INTEGER, nullable=False)
    ev_file = Column(JSON, nullable=False)
    st_idle_seconds = Column(INTEGER, nullable=False, default=60)

    user_obj = relationship('Users')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'user': {
                'id': self.user_obj.id,
                'name': self.user_obj.name,
            },
            'model_id': self.model_id,
            'filepath': self.filepath,
            'status': self.status,
            'description': self.description,
            'ev_file': self.ev_file,
        }


class Strategy(ModelBase):

    __tablename__ = 'strategy'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column('id_no', VARCHAR(256))
    node = Column(VARCHAR(32), nullable=False)
    detail = Column(JSON, nullable=False)
    strategy_upload_file_id = Column(INTEGER, nullable=False)
    r_create_user_id = Column(INTEGER, nullable=False)
    username = Column(VARCHAR(32), nullable=False)
    execution_id = Column(INTEGER, default=-1)
    dependency = Column(JSON)
    strategy_type = Column(VARCHAR(4), nullable=True)
    strategy_name = Column('name', VARCHAR(256))


class StrategyPortfolio(ModelBase):

    __tablename__ = 'strategy_portfolio'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(128), nullable=False)
    fund = Column(FLOAT, nullable=True)
    description = Column(VARCHAR(255), nullable=True)
    status = Column(INTEGER, nullable=False)
    source = Column(VARCHAR(32), nullable=True)
    r_create_user_id = Column(INTEGER, nullable=False)
    username = Column(VARCHAR(32), nullable=False)

    vstrategy_obj = relationship('VStrategies', backref ='strategy_portfolio', passive_deletes=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'fund': self.fund,
            'description': self.description,
            'status': self.status,
            'strategy': [vst.brief() for vst in self.vstrategy_obj],
        }

    def to_dict_v2(self):
        return {
            'id': self.id,
            'name': self.name,
            'fund': self.fund,
            'description': self.description,
            'status': self.status,
            'strategy': [vst.brief_v2() for vst in self.vstrategy_obj],
        }


class StrategyUploadFile(ModelBase):

    __tablename__ = 'strategy_upload_file'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    filename = Column(VARCHAR(255), nullable=False)
    relative_path = Column(VARCHAR(255), nullable=False)
    file_type = Column(VARCHAR(8), nullable=False)


class VStrategies(ModelBase):

    __tablename__ = 'vstrategies'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    status = Column(INTEGER, default=11)
    portfolio_id = Column(ForeignKey('strategy_portfolio.id', ondelete='CASCADE'))
    strategy_id = Column(INTEGER, nullable=False)
    strategy_weight = Column(FLOAT, nullable=True, default=0)
    symbols_accounts = Column(JSON, nullable=True)
    source = Column(VARCHAR(32), nullable=True)
    name = Column(VARCHAR(128), nullable=True)
    closing_out = Column(INTEGER, nullable=True)

    @classmethod
    def get_transaction_quote(cls, vid):
        with mysql_sc() as sc:
            s = sc.query(
                Strategy.detail
            ).join(
                VStrategies, VStrategies.strategy_id == Strategy.id
            ).filter(
                VStrategies.id == vid
            ).first()
            if s:
                detail = s.detail
                if 'transaction_quote' in detail and detail['transaction_quote']:
                    return detail['transaction_quote']
            return []

    @property
    def strategy_obj(self):
        with mysql_sc() as sc:
            is_python_so = False
            execution_id = -1
            necessary = {
                'kdb': False,
                'input': False,
                'output': [],
                'quote': 0,
            }
            transaction_quote = []
            if self.source == 'platform':
                o = sc.query(Strategy).filter(Strategy.id == self.strategy_id).first()
                strat_id = o.id
                strat_name = o.name + '.so'
                origin_strat_name = o.strategy_name + '.so'
                model_id = -1
                strategy_type = o.node
                ev_file = None
                st_idle_seconds = float(o.detail.get('time_interval', 0))
                if st_idle_seconds == 0:
                    st_idle_seconds = 60
                if o.strategy_upload_file_id > 0:
                    f = sc.query(StrategyUploadFile).filter(StrategyUploadFile.id == o.strategy_upload_file_id).first()
                    save_full_path = os.path.join(config.platform['media'], f.relative_path)
                    is_python_so = is_python_strategy(save_full_path)
                if o.execution_id and o.execution_id > 0:
                    execution_id = o.execution_id
                necessary = {
                    'kdb': o.detail.get('kdb', False),
                    'input': True if o.dependency else False,
                    'output': o.detail.get('output', []),
                    'quote': o.detail.get('quote_deepth', 0),
                }
                transaction_quote = o.detail.get('transaction_quote', [])
                st_type = o.strategy_type
            else:
                o = sc.query(Strategies).filter(Strategies.id == self.strategy_id).first()
                strat_id = o.id
                strat_name = o.name
                origin_strat_name = o.name
                model_id = o.model_id
                strategy_type = 'back_test'
                #ev_file = [os.path.join('./st_ev', os.path.basename(ev)) for ev in o.ev_file]
                ev_file = [os.path.join('/home/mycapitaltrade/st_ev', os.path.basename(ev)) for ev in o.ev_file]
                st_idle_seconds = o.st_idle_seconds

            o = sc.query(StrategyPortfolio).filter_by(id=self.portfolio_id).first()
            portfolio_name = o.name
            res = {
                'id': strat_id,
                'name': strat_name,
                'origin_strat_name': origin_strat_name,
                'model_id': model_id,
                'strategy_type': strategy_type,
                'ev_file': ev_file,
                'portfolio_name': portfolio_name,
                'st_idle_seconds': st_idle_seconds,
                'is_python_so': is_python_so,
                'execution_id': execution_id,
                'necessary': necessary,
                'transaction_quote': transaction_quote,
                'st_type': st_type,
            }
            return res

    def get_platform_data(self, trading_date, day_night):
        if self.strategy_obj.get('st_type') in ('02', '15', '16', '17', '18', '26', '27', '28', '33', '34'):
            day_night = 0
        params = {
            'trading_date': trading_date,
            'day_night': day_night,
        }
        try:
            res = requests.get(config.platform['st_url']+str(self.id), params=params).json()
            if 0 != res['code']:
                logger.error("[get_platform_data]: %s" % res['data'])
                return None
            return res['data']
        except Exception as e:
            return None

    def get_strategy_ev(self, trading_date, day_night):
        """
        TODO： 去掉代码中的datetime.datetime.now,不做本地时间判断，如果是拷贝到部署目录，请使用明确的日期作为参数。
        """ 
        try:
            ev_dir = os.path.join(config.platform['media'], 'strategy_ev',
                    '%s_%s' % (self.id, datetime.datetime.now().strftime('%Y%m%d')))
            if not os.path.exists(ev_dir):
                os.makedirs(ev_dir)

            if self.source == 'platform':
                d = self.get_platform_data(trading_date, day_night)
                ev_files = [os.path.join(config.platform['media'], f) for f in d['ev_files']]
            else:
                ev_files = self.strategy_obj.ev_file
            for ev_file in ev_files:
                shutil.copyfile(ev_file, os.path.join(ev_dir, os.path.basename(ev_file)))
            return ev_dir + '/' if ev_files else ''
        except Exception as e:
            return ''

    def get_platform_data_per_machine(self):        
        url = "http://127.0.0.1/api/v1/strategy_upload/strategy/deploy/ev/{}".format(self.id)
        logger.info("get ev from "+url)
        try:
            res = requests.get(url).json()['data']
            return res
        except Exception as e:
            return None

    def get_strategy_ev_per_machine(self):        
        try:
            ev_files = []
            if self.source == 'platform':
                d = self.get_platform_data_per_machine()
                if d is None:
                    return None
                ev_files = [os.path.join(config.platform['media'], f) for f in d['ev_files']]
            return ev_files
        except Exception as e:
            return None

    def get_strategy_detail(self, trading_date, day_night, source=1):
        try:
            s_obj = self.strategy_obj
            logger.info('get strategy_obj, %s', s_obj)
            ev_file = ''
            symbols_accounts_day = self.symbols_accounts.get('day', [])
            symbols_accounts_night = self.symbols_accounts.get('night', [])
            if source == 1:
                if self.source == 'platform':
                    d = self.get_platform_data(trading_date, day_night)
                    logger.info('get platform data, %s', d)
                    s_obj['reserve_type'] = d['reserve_type']
                    s_obj['portfolio_opt_version'] = d['portfolio_opt_version']
                    s_obj['smart_execution_so_version'] = d['smart_execution_so_version']
                    #s_obj['portfolio_opt_ev_path'] = d['portfolio_opt_ev_path']
                    s_obj['portfolio_opt_ev_path'] = "/home/mycapitaltrade/st_ev/"
                    #s_obj['smart_execution_ev_path'] = d['smart_execution_ev_path']
                    s_obj['smart_execution_ev_path'] = d['smart_execution_ev_path'].replace("./st_ev/", "/home/mycapitaltrade/st_ev/")
                    s_obj['smart_execution_so_path'] = d['smart_execution_so_path']
                    s_obj['smart_execution_so_symbols'] = d['smart_execution_so_symbols']
                    s_obj['is_t0_strategy'] = d.get('is_t0_strategy', False)
                    s_obj['factor_book'] = d.get('factor_book', '')
                    s_obj['is_factor_generate'] = d.get('is_factor_generate', False)
                    s_obj['se_cash'] = d.get('se_cash', 0)
                    s_obj['income_attribution'] = d.get('income_attribution', [])
                    s_obj['extra_rsp'] = d.get('extra_rsp', {})

                    ev = d['ev_files']
                    if s_obj['strategy_type'] == 'order_list' or d['strategy_type'] == 'clear_position':
                        if 'strategy_upload/volume_profile.csv' in ev:
                            profile_idx = ev.index('strategy_upload/volume_profile.csv')
                            ev = ev[:profile_idx]
                        symbols_accounts_day = d['symbols_accounts']['day']
                        symbols_accounts_night = d['symbols_accounts']['night']
                    #ev_file = '|'.join([os.path.join('./st_ev/', os.path.basename(f)) for f in ev])
                    ev_file = '|'.join([os.path.join('/home/mycapitaltrade/st_ev/', os.path.basename(f)) for f in ev])
                else:
                    #ev_file = '|'.join([os.path.join('./st_ev/', os.path.basename(f)) for f in s_obj.ev_file])
                    ev_file = '|'.join([os.path.join('/home/mycapitaltrade/st_ev/', os.path.basename(f)) for f in s_obj.ev_file])
            strategy_name = s_obj['name'].replace('.so', '')

            if s_obj['strategy_type'] == 'order_list' or s_obj['is_python_so']:
                serial_strategy = './st_so/%s/st.so,./st_so/smart_execution.so,./st_so/risk_mgnt.so' % strategy_name
            elif s_obj['execution_id'] > 0:
                serial_strategy = './st_so/%s,./st_so/smart_execution.so,./st_so/risk_mgnt.so' % s_obj['name']
            else:
                serial_strategy = './st_so/%s,./st_so/risk_mgnt.so' % s_obj['name']

            if s_obj['st_type'] == '31': # merge strategy
                serial_strategy = './st_so/%s/st.so,./st_so/smart_execution.so' % strategy_name

            name = s_obj['name']
            if source == 1:
                if d['strategy_type'] == 'clear_position':
                    if d['business'] == 'stock':
                        serial_strategy = './st_so/clear_stock/st.so,./st_so/smart_execution.so,./st_so/risk_mgnt.so'
                        name = 'clear_stock.so'
                    elif d['business'] == 'future':
                        serial_strategy = './st_so/clear_future/st.so,./st_so/smart_execution.so,./st_so/risk_mgnt.so'
                        name = 'clear_future.so'

            if s_obj['execution_id'] == 2: # add if,ic,ih
                if symbols_accounts_day:
                    s_account = symbols_accounts_day[0]["account"]
                    symbols_accounts_day.append(
                        {
                            "currency": "CNY",
                            "product": "if",
                            "rank": "1",
                            "amount": 0,
                            "account": s_account,
                            "max_vol": "",
                            "exchange": "CFFEX"
                        }
                    )
                    symbols_accounts_day.append(
                        {
                            "currency": "CNY",
                            "product": "ic",
                            "rank": "1",
                            "amount": 0,
                            "account": s_account,
                            "max_vol": "",
                            "exchange": "CFFEX"
                        }
                    )
                    symbols_accounts_day.append(
                        {
                            "currency": "CNY",
                            "product": "ih",
                            "rank": "1",
                            "amount": 0,
                            "account": s_account,
                            "max_vol": "",
                            "exchange": "CFFEX"
                        }
                    )
            reserve_type = s_obj.get('reserve_type', 1)
            portfolio_opt_version = s_obj.get('portfolio_opt_version', '')
            portfolio_opt_ev_path = s_obj.get('portfolio_opt_ev_path', '')
            smart_execution_ev_path = s_obj.get('smart_execution_ev_path', '')
            factor_book = s_obj.get('factor_book', '')
            is_factor_generate = s_obj.get('is_factor_generate', False)
            se_cash = s_obj.get('se_cash', 0)
            income_attribution = s_obj.get('income_attribution', [])
            smart_execution_so_version = s_obj.get('smart_execution_so_version', '')
            extra_rsp = s_obj.get('extra_rsp', {})
            # TODO: 对不同策略类型请抽象成一个检查函数，避免过程式的写在这里。
            if s_obj.get('smart_execution_so_version') and s_obj['smart_execution_so_version'] != 'vwap_classic' and s_obj.get('smart_execution_so_path'):
                serial_strategy = serial_strategy.replace('./st_so/smart_execution.so', s_obj.get('smart_execution_so_path'))

            if s_obj.get('is_t0_strategy'):
                serial_strategy = serial_strategy.replace('./st_so/risk_mgnt.so', '').rstrip(',')

            if s_obj.get('smart_execution_so_symbols') and symbols_accounts_day:
                for _p in s_obj['smart_execution_so_symbols']:
                    _p['account'] = symbols_accounts_day[0]['account']
                    symbols_accounts_day.append(_p)
            model_id = s_obj['model_id']
            if is_factor_generate:
                model_id = self.strategy_id
            return {
                'st_brief': {
                    'vstrategy_id': self.id,
                    'name': name,
                    'origin_strat_name': s_obj['origin_strat_name'],
                    'model_id': model_id,
                    'strategy_type': s_obj['strategy_type'],
                    'portfolio': s_obj['portfolio_name'],
                    'st_idle_seconds': s_obj['st_idle_seconds'],
                    'ev_file': ev_file,
                    'serial_strategy': serial_strategy,
                    'strategy_name': strategy_name,
                    'strategy_outpath': '/home/mycapitaltrade/output/%s_%s/' % (strategy_name, self.id),
                    'quote_type': ''.join([str(_q) for _q in s_obj['transaction_quote']]),
                    'reserve_type': reserve_type,
                    'portfolio_opt_version': portfolio_opt_version,
                    'portfolio_opt_ev_path': portfolio_opt_ev_path,
                    'smart_execution_ev_path': smart_execution_ev_path,
                    'factor_book': factor_book,
                    'is_factor_generate': is_factor_generate,
                    'se_cash': se_cash,
                    'income_attribution': income_attribution,
                    'smart_execution_so_version': smart_execution_so_version,
                    'extra_rsp': extra_rsp,
                },
                'day_conf': symbols_accounts_day,
                'night_conf': symbols_accounts_night,
            }
        except Exception as e:
            return None

    def brief(self):
        s_obj = self.strategy_obj
        return {
            'vstrategy_id': self.id,
            'id': s_obj['id'],
            'name': s_obj['name'],
            'origin_strat_name': s_obj['origin_strat_name'],
            'weight': self.strategy_weight,
            'symbols_accounts': self.symbols_accounts if self.symbols_accounts else {},
            'status': self.status,
            'necessary': s_obj.get('necessary', ''),
            'quote_type': ''.join([str(_q) for _q in s_obj['transaction_quote']]),
        }

    @property
    def strategy_obj_v2(self):
        with mysql_sc() as sc:
            necessary = {
                'kdb': False,
                'input': False,
                'output': [],
                'quote': 0,
            }
            transaction_quote = []
            if self.source == 'platform':
                o = sc.query(Strategy).filter(Strategy.id == self.strategy_id).first()
                strat_id = o.id
                strat_name = o.name + '.so'
                origin_strat_name = o.strategy_name + '.so'
                necessary = {
                    'kdb': o.detail.get('kdb', False),
                    # 'input': True if o.dependency else False,
                    'input': bool(o.dependency),
                    'output': o.detail.get('output', []),
                    'quote': o.detail.get('quote_deepth', 0),
                }
                transaction_quote = o.detail.get('transaction_quote', [])
            else:
                o = sc.query(Strategies).filter(Strategies.id == self.strategy_id).first()
                strat_id = o.id
                strat_name = o.name
                origin_strat_name = o.name

            res = {
                'id': strat_id,
                'name': strat_name,
                'origin_strat_name': origin_strat_name,
                'necessary': necessary,
                'transaction_quote': transaction_quote,
            }
            return res

    def acc_symbols_accounts(self):
        res_day = {}
        res_night = {}
        data = {"day":[], "night":[]}
        symbols_accounts = self.symbols_accounts if self.symbols_accounts else {}
        for sa in symbols_accounts.get("day"):
            account = sa.get("account", "")
            currency = sa.get("currency", "")
            if (account, currency) not in res_day:
                res_day[(account, currency)] = sa.get("amount", 0)
            else:
                res_day[(account, currency)] += sa.get("amount", 0)
        for sa in symbols_accounts.get("night"):
            account = sa.get("account", "")
            currency = sa.get("currency", "")
            if (account, currency) not in res_night:
                res_night[(account, currency)] = sa.get("amount", 0)
            else:
                res_night[(account, currency)] += sa.get("amount", 0)
        for k, v in res_day.items():
            data["day"].append({"account": k[0], "currency": k[1], "amount": v})
        for k, v in res_night.items():
            data["night"].append({"account": k[0], "currency": k[1], "amount": v})
        return data

    def brief_v2(self):
        s_obj = self.strategy_obj_v2
        return {
            'vstrategy_id': self.id,
            'id': s_obj['id'],
            'name': s_obj['name'],
            'origin_strat_name': s_obj['origin_strat_name'],
            'weight': self.strategy_weight,
            'symbols_accounts': self.symbols_accounts if self.symbols_accounts else {},
            'status': self.status,
            'necessary': s_obj.get('necessary', ''),
            'quote_type': ''.join([str(_q) for _q in s_obj['transaction_quote']]),
            'acc_symbols_accounts': self.acc_symbols_accounts(),
        }


class OnlineRequest(ModelBase):

    __tablename__ = 'online_request'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    portfolio_id = Column(ForeignKey('strategy_portfolio.id'))
    # 0：待审批，1：批准，2：拒绝
    status = Column(INTEGER, default=0)
    action = Column(INTEGER, nullable=False)
    audit_time = Column(DATETIME(fsp=6), nullable=True, server_default=func.now(6), onupdate=func.now(6))
    audit_user = Column(VARCHAR(64), nullable=True)
    audit_comment = Column(VARCHAR(256), nullable=True)
    r_create_user = Column(VARCHAR(64), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())

    portfolio_obj = relationship('StrategyPortfolio')

    def to_dict(self):
        return {
            'id': self.id,
            'portfolio': self.portfolio_obj.to_dict_v2(),
            'status': self.status,
            #'action': self.action,
            'audit_time': str(self.audit_time),
            'audit_user': self.audit_user,
            'audit_comment': self.audit_comment,
            'request_user': self.r_create_user,
            'request_time': str(self.r_create_time),
        }


class ProgramTypes(ModelBase):

    __tablename__ = 'program_types'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
        }


class ApiTypes(ModelBase):

    __tablename__ = 'api_types'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)
    api_id = Column(INTEGER, nullable=False)
    program_type_id = Column(ForeignKey('program_types.id'))
    exchange_id = Column(ForeignKey('exchanges.id'))

    program_type_obj = relationship('ProgramTypes')
    exchange_obj = relationship('Exchanges')

    def brief(self):
        return {
            'id': self.id,
            'name': self.name,
            'api_id': self.api_id,
            'exchange_code': self.exchange_obj.code,
        }

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'api_id': self.api_id,
            'program_type': {
                'id': self.program_type_obj.id,
                'name': self.program_type_obj.name,
            },
            'exchange': {
                'id': self.exchange_obj.id,
                'name': self.exchange_obj.name,
                'code': self.exchange_obj.code,
            },
        }


class QuoteSrcTypes(ModelBase):

    __tablename__ = 'quote_src_types'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)
    api_id = Column(INTEGER, nullable=False)
    program_type_id = Column(ForeignKey('program_types.id'))

    program_type_obj = relationship('ProgramTypes')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'api_id': self.api_id,
            'program_type': {
                'id': self.program_type_obj.id,
                'name': self.program_type_obj.name,
            },
        }


class TunnelTypes(ModelBase):

    __tablename__ = 'tunnel_types'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)
    api_id = Column(INTEGER, nullable=False)
    program_type_id = Column(ForeignKey('program_types.id'))

    program_type_obj = relationship('ProgramTypes')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'api_id': self.api_id,
            'program_type': {
                'id': self.program_type_obj.id,
                'name': self.program_type_obj.name,
            },
        }


class ConfigTemplates(ModelBase):

    __tablename__ = 'config_templates'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(128), nullable=False)
    content = Column(LONGTEXT, nullable=False)
    api_type_id = Column(ForeignKey('api_types.id'), nullable=True)
    program_type_id = Column(ForeignKey('program_types.id'))

    api_type_obj = relationship('ApiTypes')
    program_type_obj = relationship('ProgramTypes')

    def brief(self):
        return {
            'id': self.id,
            'name': self.name,
            'content': self.content,
            'api_id': self.api_type_obj.api_id,
            'exchange_code': self.api_type_obj.exchange_obj.code,
        }

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'content': self.content,
            'api_type': self.api_type_obj.brief() if self.api_type_id else {},
            'program_type': {
                'id': self.program_type_obj.id,
                'name': self.program_type_obj.name,
            },
        }


class Programs(ModelBase):

    __tablename__ = 'programs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(128), nullable=False)
    type_id = Column(ForeignKey('program_types.id'))
    filepath = Column(VARCHAR(256), nullable=False)
    version = Column(VARCHAR(32), nullable=False)

    program_type_obj = relationship('ProgramTypes')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'type': {
                'id': self.program_type_obj.id,
                'name': self.program_type_obj.name,
            },
            'filepath': self.filepath,
            'version': self.version,
        }


class DeployPrograms(ModelBase):

    __tablename__ = 'deploy_programs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    host = Column(VARCHAR(45), nullable=False)
    deploy_path = Column(VARCHAR(256), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    program_id = Column(ForeignKey('programs.id'))
    result = Column(INTEGER, default=0)

    program_obj = relationship('Programs')

    def to_dict(self):
        return {
            'id': self.id,
            'result': self.result,
        }


class DeployStrategies(ModelBase):

    __tablename__ = 'deploy_strategies'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    host = Column(VARCHAR(45), nullable=False)
    deploy_path = Column(VARCHAR(256), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    vstrategy_id = Column(ForeignKey('vstrategies.id'))
    result = Column(INTEGER, default=0)
    task_id = Column(BIGINT(unsigned=True), nullable=True)

    vstrategy_obj = relationship('VStrategies')

    def to_dict(self):
        return {
            'id': self.id,
            'result': self.result,
        }


class DeployConfs(ModelBase):

    __tablename__ = 'deploy_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(256), nullable=True)
    host = Column(VARCHAR(45), nullable=False)
    deploy_path = Column(VARCHAR(256), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    program_type_id = Column(ForeignKey('program_types.id'), nullable=True)
    vstrategy_id = Column(ForeignKey('vstrategies.id'), nullable=True)
    content = Column(LONGTEXT, nullable=True)
    result = Column(INTEGER, default=0)
    status = Column(INTEGER, default=1)
    program_id = Column(ForeignKey('programs.id'), nullable=True)
    request_id = Column(ForeignKey('online_request.id'), nullable=True)
    valid = Column(BOOLEAN, default=True, nullable=True)

    program_type_obj = relationship('ProgramTypes')
    program_obj = relationship('Programs')
    request_obj = relationship('OnlineRequest')
    vstrategy_obj = relationship('VStrategies')

    def get_strategy_ev(self, trading_date, day_night):
        if not self.vstrategy_id:
            return ''
        else:
            return self.vstrategy_obj.get_strategy_ev(trading_date, day_night)

    def get_program_version(self):
        try:
            with mysql_sc() as sc:
                p = sc.query(Programs).join(
                    DeployPrograms, Programs.id == DeployPrograms.program_id,
                ).filter(
                    DeployPrograms.host == self.host,
                    DeployPrograms.deploy_path == self.deploy_path,
                    DeployPrograms.day_night == self.day_night,
                ).order_by(DeployPrograms.id.desc()).first()
                if not p:
                    return ''
                return p.version
        except Exception as e:
            return ''

    def to_dict(self):
        return {
            'id': self.id,
            'process_id': self.id,
            'host': self.host,
            'deploy_path': self.deploy_path,
            'day_night': self.day_night,
            'result': self.result,
            'status': self.status,
            'process_type': self.program_type_obj.name if self.program_type_id else '',
            'valid': self.valid,
            'vstrategy_id': self.vstrategy_id if self.vstrategy_id else '',
            'version': self.get_program_version(),
        }

    @staticmethod
    def get_process_by_id(id):
        with mysql_sc() as sc:
            process = sc.query(
                DeployConfs
            ).filter(
                DeployConfs.id == id,
            ).first()
            if process:
                return {
                    'process_id': process.id,
                    'host': process.host,
                    'deploy_path': process.deploy_path,
                    'day_night': process.day_night,
                    'process_type': process.program_type_obj.name if process.program_type_id else '',
                    'vstrategy_id': process.vstrategy_id if process.vstrategy_id else '',
                    'version': process.get_program_version(),
                }
            else:
                return None

    @staticmethod
    def get_process_by_path_and_vstrategyid(ip, deploy_path, vstrategy_id):
        with mysql_sc() as sc:
            process = sc.query(
                DeployConfs
            ).join(
                VStrategies, VStrategies.id == DeployConfs.vstrategy_id
            ).filter(
                DeployConfs.host == ip,
                DeployConfs.deploy_path == deploy_path,
                DeployConfs.vstrategy_id == vstrategy_id,
                DeployConfs.valid == True,
                ~VStrategies.status.in_([-1, 16])
            ).first()
            if process:
                return {
                    'process_id': process.id,
                    'host': process.host,
                    'deploy_path': process.deploy_path,
                    'day_night': process.day_night,
                    'process_type': process.program_type_obj.name if process.program_type_id else '',
                    'vstrategy_id': process.vstrategy_id if process.vstrategy_id else '',
                    'version': process.get_program_version(),
                }
            else:
                return None


class PreQuoteConfs(ModelBase):

    __tablename__ = 'pre_quote_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(64), nullable=True)
    deploy_path = Column(VARCHAR(256), nullable=False)
    ip_addr = Column(VARCHAR(16), nullable=False)
    port = Column(INTEGER, nullable=False)
    forwarder = Column(VARCHAR(32), nullable=True)
    valid = Column(BOOLEAN, nullable=False)
    server_id = Column(ForeignKey('servers.id'))
    config_template_id = Column(ForeignKey('config_templates.id'))
    account_id  = Column(ForeignKey('accounts.id'), nullable=True)

    server_obj = relationship('Servers')
    config_template_obj = relationship('ConfigTemplates')
    account_obj = relationship('Accounts')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'deploy_path': self.deploy_path,
            'ip_addr': self.ip_addr,
            'port': self.port,
            'valid': self.valid,
            'server': self.server_obj.brief(),
            'config_template': self.config_template_obj.brief(),
            'account': self.account_obj.brief() if self.account_id else {},
            'forwarder': self.forwarder,
        }

    @staticmethod
    def get_conf_by_path(host, deploy_path):
        outdata = []
        with mysql_sc() as sc:
            confs = sc.query(
                PreQuoteConfs
            ).join(
                Servers, Servers.id == PreQuoteConfs.server_id
            ).filter(
                Servers.ip == host,
                PreQuoteConfs.deploy_path==deploy_path
            ).all()
            for conf in confs:
                outdata.append(conf.to_dict())
            return outdata

    @staticmethod
    def get_fake_quote_conf_by_listen_socket(host, port):
        outdata = []
        with mysql_sc() as sc:
            confs = sc.query(
                PreQuoteConfs
            ).filter(
                PreQuoteConfs.ip_addr == host,
                PreQuoteConfs.port == port
            ).all()
            for conf in confs:
                outdata.append(conf.to_dict())

        return outdata


class PreTunnelConfs(ModelBase):

    __tablename__ = 'pre_tunnel_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(64), nullable=True)
    deploy_path = Column(VARCHAR(256), nullable=False)
    ip_addr = Column(VARCHAR(16), nullable=False)
    port = Column(INTEGER, nullable=False)
    forwarder = Column(VARCHAR(32), nullable=True)
    valid = Column(BOOLEAN, nullable=False)
    server_id = Column(ForeignKey('servers.id'))
    config_template_id = Column(ForeignKey('config_templates.id'))
    account_id  = Column(ForeignKey('accounts.id'), nullable=True)

    server_obj = relationship('Servers')
    config_template_obj = relationship('ConfigTemplates')
    account_obj = relationship('Accounts')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'deploy_path': self.deploy_path,
            'ip_addr': self.ip_addr,
            'port': self.port,
            'valid': self.valid,
            'server': self.server_obj.brief(),
            'config_template': self.config_template_obj.brief(),
            'account': self.account_obj.brief() if self.account_id else {},
            'forwarder': self.forwarder,
        }


class PreTraderConfs(ModelBase):

    __tablename__ = 'pre_trader_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(64), nullable=True)
    deploy_path = Column(VARCHAR(256), nullable=False)
    valid = Column(BOOLEAN, nullable=False)
    server_id = Column(ForeignKey('servers.id'))

    server_obj = relationship('Servers')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'deploy_path': self.deploy_path,
            'valid': self.valid,
            'server': self.server_obj.brief(),
        }


class PreAgentConfs(ModelBase):

    __tablename__ = 'pre_agent_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(64), nullable=True)
    deploy_path = Column(VARCHAR(256), nullable=False)
    valid = Column(BOOLEAN, nullable=False)
    server_id = Column(ForeignKey('servers.id'))

    server_obj = relationship('Servers')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'deploy_path': self.deploy_path,
            'valid': self.valid,
            'server': self.server_obj.brief(),
        }


class PreStrategyConfs(ModelBase):

    __tablename__ = 'pre_strategy_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(64), nullable=True)
    server_id = Column(ForeignKey('servers.id'))
    day_quote_conf = Column(VARCHAR(256), nullable=False)
    day_tunnel_conf = Column(VARCHAR(256), nullable=False)
    day_trader_conf = Column(VARCHAR(256), nullable=False)
    night_quote_conf = Column(VARCHAR(256), nullable=False)
    night_tunnel_conf = Column(VARCHAR(256), nullable=False)
    night_trader_conf = Column(VARCHAR(256), nullable=False)
    vstrategy_id = Column(ForeignKey('vstrategies.id'))
    process_num = Column(INTEGER)
    merge_vstrategy_id = Column(BIGINT)
    tcp_conf = Column(VARCHAR(256), default=None)

    server_obj = relationship('Servers')
    vstrategy_obj = relationship('VStrategies')

    @property
    def merge_vstrategy_obj(self):
        with mysql_sc() as sc:
            o = sc.query(VStrategies).filter(
                VStrategies.id == self.merge_vstrategy_id,
            ).first()
            if o:
                return o.brief_v2()
            else:
                return {}

    def is_merge_strategy(self):
        return self.vstrategy_obj.strategy_obj.get("st_type", -1) == '31'

    def acc_symbols_accounts(self, symbols_accounts):
        res = {}
        data = []
        for sa in symbols_accounts:
            account = sa.get("account", "")
            currency = sa.get("currency", "")
            if (account, currency) not in res:
                res[(account, currency)] = sa.get("amount", 0)
            else:
                res[(account, currency)] += sa.get("amount", 0)
        for k, v in res.items():
            data.append({"account": k[0], "currency": k[1], "amount": v})
        return data

    def to_dict(self, trading_date, day_night, source=0):
        if self.vstrategy_obj.status in [-1, 16]:
            logger.error('vstrategy %d, status=%d(已下架)', self.vstrategy_id, self.vstrategy_obj.status)
            return {'err_msg': '策略已下架'}
        logger.info('get strategy detail of vstrategy_id %d, status=%d', self.vstrategy_id, self.vstrategy_obj.status)
        strategy_detail = self.vstrategy_obj.get_strategy_detail(trading_date, day_night, source=source)
        if not strategy_detail:
            logger.error('vstrategy %d, cannon get strategy detail from platform', self.vstrategy_id)
            return {'err_msg': '从平台获取策略信息失败'}

        merge_vs_obj = self.merge_vstrategy_obj
        merge_vs_dict = {}
        if merge_vs_obj:
            merge_vs_dict = {
                "vstrategy_id": merge_vs_obj["vstrategy_id"],
                "name": merge_vs_obj["name"],
            }
        return {
            'id': self.id,
            'name': self.name,
            'server': self.server_obj.brief(),
            'vstrategy': strategy_detail['st_brief'],
            'conf': {
                'day': {
                    'symbols_accounts': strategy_detail['day_conf'],
                    'quote_conf': self.day_quote_conf,
                    'tunnel_conf': self.day_tunnel_conf,
                    'trader_conf': self.day_trader_conf,
                    "acc_symbols_accounts": self.acc_symbols_accounts(strategy_detail['day_conf']),
                },
                'night': {
                    'symbols_accounts': strategy_detail['night_conf'],
                    'quote_conf': self.night_quote_conf,
                    'tunnel_conf': self.night_tunnel_conf,
                    'trader_conf': self.night_trader_conf,
                    "acc_symbols_accounts": self.acc_symbols_accounts(strategy_detail['night_conf']),
                }
            },
            'process_num': self.process_num,
            'merge_vstrategy': merge_vs_dict,
            'is_merge': self.is_merge_strategy(),
            'tcp_conf': self.tcp_conf
        }

    @staticmethod
    def quote_to_stra(host, deploy_path):
        vstra_data = {}
        path = '%{}%'.format(deploy_path)
        with mysql_sc() as sc:
            stra_confs = sc.query(
                PreStrategyConfs
            ).join(
                Servers, Servers.id == PreStrategyConfs.server_id
            ).filter(
                Servers.ip == host,
                or_(
                    PreStrategyConfs.day_quote_conf.like(path),
                    PreStrategyConfs.night_quote_conf.like(path),
                )
            ).order_by(
                PreStrategyConfs.id
            ).all()
            for conf in stra_confs:
                if conf.vstrategy_id not in vstra_data.keys():
                    vstra_data[conf.vstrategy_id] = {
                        'vstrategy_id': conf.vstrategy_id,
                        'day_trader_conf': conf.day_trader_conf,
                        'night_trader_conf': conf.night_trader_conf,
                    }
            return vstra_data


class PreForwarderConfs(ModelBase):

    __tablename__ = 'pre_forwarder_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(64), nullable=False)
    deploy_path = Column(VARCHAR(256), nullable=False)
    valid = Column(BOOLEAN, nullable=False)
    server_id = Column(ForeignKey('servers.id'))

    server_obj = relationship('Servers')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'deploy_path': self.deploy_path,
            'valid': self.valid,
            'server': self.server_obj.brief(),
        }

class TradeLogs(ModelBase):

    __tablename__ = 'trade_logs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    trading_date = Column(DATE, nullable=False)
    calendar_time = Column(TIME, nullable=False)
    calendar_microsec = Column(INTEGER, nullable=True)
    exchange_time = Column(TIME, nullable=True)
    exchange_microsec = Column(INTEGER, nullable=True)
    internal_date = Column(DATE, nullable=False)
    calendar_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    server = Column(VARCHAR(45), nullable=False)
    account = Column(VARCHAR(32), nullable=False)
    log_type = Column(VARCHAR(1), nullable=False)
    vstrategy_id = Column(BIGINT(unsigned=True), nullable=False)
    serial_no = Column(VARCHAR(32), nullable=False)
    cancel_serial_no = Column(VARCHAR(32), nullable=False)
    symbol = Column(VARCHAR(32), nullable=False)
    direction = Column(INTEGER, nullable=False)
    open_close = Column(INTEGER, nullable=False)
    order_price = Column(DOUBLE, nullable=False)
    order_vol = Column(INTEGER, nullable=False)
    entrust_no = Column(BIGINT(unsigned=True), nullable=False)
    entrust_status = Column(VARCHAR(1), nullable=False)
    trade_price = Column(DOUBLE, nullable=False)
    trade_vol = Column(INTEGER, nullable=False)
    remain_vol = Column(INTEGER, nullable=False)
    trade_no = Column(BIGINT, nullable=False)
    speculator = Column(INTEGER, nullable=False)
    order_price_type = Column(INTEGER, nullable=False)
    order_type = Column(INTEGER, nullable=False)
    error_no = Column(INTEGER, nullable=False)
    quote_trigger = Column(VARCHAR(16), nullable=True)
    cp_open_vol_remain = Column(INTEGER, nullable=False)
    cp_cancel_vol_remain = Column(INTEGER, nullable=False)
    rdtsc = Column(BIGINT(unsigned=True), nullable=True)


class TuringTradeLogs(ModelBase):

    __tablename__ = 'turing_trade_logs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    trading_date = Column(DATE, nullable=False)
    calendar_time = Column(TIME, nullable=False)
    calendar_microsec = Column(INTEGER, nullable=True)
    exchange_time = Column(TIME, nullable=True)
    exchange_microsec = Column(INTEGER, nullable=True)
    internal_date = Column(DATE, nullable=False)
    calendar_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    server = Column(VARCHAR(45), nullable=False)
    account = Column(VARCHAR(32), nullable=False)
    log_type = Column(VARCHAR(1), nullable=False)
    vstrategy_id = Column(BIGINT(unsigned=True), nullable=False)
    serial_no = Column(VARCHAR(32), nullable=False)
    cancel_serial_no = Column(VARCHAR(32), nullable=False)
    symbol = Column(VARCHAR(32), nullable=False)
    direction = Column(INTEGER, nullable=False)
    open_close = Column(INTEGER, nullable=False)
    order_price = Column(DOUBLE, nullable=False)
    order_vol = Column(INTEGER, nullable=False)
    entrust_no = Column(BIGINT(unsigned=True), nullable=False)
    entrust_status = Column(VARCHAR(1), nullable=False)
    trade_price = Column(DOUBLE, nullable=False)
    trade_vol = Column(INTEGER, nullable=False)
    remain_vol = Column(INTEGER, nullable=False)
    trade_no = Column(BIGINT, nullable=False)
    speculator = Column(INTEGER, nullable=False)
    order_price_type = Column(INTEGER, nullable=False)
    order_type = Column(INTEGER, nullable=False)
    error_no = Column(INTEGER, nullable=False)
    quote_trigger = Column(VARCHAR(16), nullable=True)
    cp_open_vol_remain = Column(INTEGER, nullable=False)
    cp_cancel_vol_remain = Column(INTEGER, nullable=False)
    rdtsc = Column(BIGINT(unsigned=True), nullable=True)


class StrategyPerfInput(ModelBase):

    __tablename__ = 'strategy_perf_input'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vstrategy_id = Column(BIGINT(unsigned=True), nullable=False)
    trade_date = Column(DATE, nullable=False)
    account = Column(VARCHAR(32), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    symbol = Column(VARCHAR(128), nullable=False)
    exchange = Column(VARCHAR(10), nullable=True)
    cash = Column(DOUBLE, nullable=True)
    today_max_pos = Column(INTEGER, nullable=False)
    yest_long_pos = Column(INTEGER, nullable=False)
    yest_long_avg_price = Column(DOUBLE, nullable=False)
    yest_short_pos = Column(INTEGER, nullable=False)
    yest_short_avg_price = Column(DOUBLE, nullable=False)
    today_long_pos = Column(INTEGER, nullable=False)
    today_long_avg_price = Column(DOUBLE, nullable=False)
    today_short_pos = Column(INTEGER, nullable=False)
    today_short_avg_price = Column(DOUBLE, nullable=False)
    currency = Column(VARCHAR(8), nullable=False, default='CNY')

    def to_dict(self):
        return {
            'vstrategy_id': self.vstrategy_id,
            'trade_date': str(self.trade_date),
            'day_night': self.day_night,
            'symbol': self.symbol,
            'account': self.account,
            'exchange': self.exchange,
            'cash': float(self.cash),
            'today_max_pos': self.today_max_pos,
            'yd_long_pos': self.yest_long_pos,
            'yd_long_avg_price': float(self.yest_long_avg_price),
            'yd_short_pos': self.yest_short_pos,
            'yd_short_avg_price': float(self.yest_short_avg_price),
            'td_long_pos': self.today_long_pos,
            'td_long_avg_price': float(self.today_long_avg_price),
            'td_short_pos': self.today_short_pos,
            'td_short_avg_price': float(self.today_short_avg_price),
            'currency': self.currency,
        }


class ParentOrder(ModelBase):

    __tablename__ = 'parent_orders'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    parent_order_id = Column(VARCHAR(64), nullable=False)
    vstrategy_id = Column(BIGINT, nullable=False)
    symbol = Column(VARCHAR(128), nullable=False)
    parent_order_size = Column(INTEGER, nullable=False)
    limit_price = Column(DOUBLE, nullable=False)
    algorithm = Column(INTEGER, nullable=False)   # algorithm: 1-DMA; 2-VWAP; 3-TWAP;
    side = Column(INTEGER, nullable=False)    #方向 1-buy, 2-sell
    start_time = Column(TIME, nullable=False)
    start_time_ms = Column(INTEGER, nullable=False)
    end_time = Column(TIME, nullable=False)
    end_time_ms = Column(INTEGER, nullable=False)
    timestamp = Column(TIME, nullable=False)
    timestamp_ms = Column(INTEGER, nullable=False)
    internal_date = Column(DATE, nullable=False)
    calendar_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    trading_date = Column(DATE, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())


class ChildrenOrder(ModelBase):

    __tablename__ = 'child_orders'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    child_order_id = Column(VARCHAR(64), nullable=False)
    vstrategy_id = Column(BIGINT, nullable=False)
    parent_order_id = Column(VARCHAR(64), nullable=False)
    child_order_size = Column(INTEGER, nullable=False)
    execution_price = Column(DOUBLE, nullable=False)
    order_type = Column(INTEGER, nullable=False)   # order_type: 1：PASSIVE; 2:AGGRESSIVE;
    indicator = Column(FLOAT, nullable=False)
    timestamp = Column(TIME, nullable=False)
    timestamp_ms = Column(INTEGER, nullable=False)
    internal_date = Column(DATE, nullable=False)
    calendar_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    trading_date = Column(DATE, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())


class VSPositions(ModelBase):

    __tablename__ = 'vs_positions'

    __table_args__ = (
        PrimaryKeyConstraint('vstrategy_id', 'symbol', 'settle_date', 'daynight'),
    )

    vstrategy_id = Column(BIGINT, nullable=False)
    symbol = Column(VARCHAR(128), nullable=False)
    settle_date = Column(DATE, nullable=False)
    account = Column(VARCHAR(32), nullable=False)
    yest_long_pos = Column(INTEGER, nullable=False)
    yest_long_avg_price = Column(VARCHAR(20), nullable=False)
    yest_short_pos = Column(INTEGER, nullable=False)
    yest_short_avg_price = Column(VARCHAR(20), nullable=False)
    today_long_pos = Column(INTEGER, nullable=False)
    today_long_avg_price = Column(VARCHAR(20), nullable=False)
    today_short_pos = Column(INTEGER, nullable=False)
    today_short_avg_price = Column(VARCHAR(20), nullable=False)
    today_settle_price = Column(VARCHAR(20), nullable=False)
    today_max_pos = Column(INTEGER, nullable=False)
    daynight = Column(ENUM('Unknown','DAY','NIGHT'), nullable=False)
    exchange = Column(VARCHAR(16), nullable=False)
    symbol_type = Column(VARCHAR(16), nullable=False)
    ctime = Column(DATETIME, nullable=False)
    utime = Column(DATETIME, nullable=False)

    def to_dict(self):
        return {
            'vstrategy_id': self.vstrategy_id,
            'symbol': self.symbol,
            'account': self.account,
            'yd_long_pos': self.yest_long_pos,
            'yd_long_avg_price': self.yest_long_avg_price,
            'yd_short_pos': self.yest_short_pos,
            'yd_short_avg_price': self.yest_short_avg_price,
            'td_long_pos': self.today_long_pos,
            'td_long_avg_price': self.today_long_avg_price,
            'td_short_pos': self.today_short_pos,
            'td_short_avg_price': self.today_short_avg_price,
            'today_settle_price': self.today_settle_price,
            'today_max_pos': self.today_max_pos,
            'exchange': self.exchange,
            'symbol_type': self.symbol_type,
        }


class VSAccounts(ModelBase):

    __tablename__ = 'vs_accounts'

    __table_args__ = (
        PrimaryKeyConstraint('vstrategy_id', 'account', 'settle_date', 'daynight'),
    )

    vstrategy_id = Column(BIGINT, nullable=False)
    account = Column(VARCHAR(256), nullable=False)
    settle_date = Column(DATE, nullable=False)
    cash = Column(VARCHAR(20), nullable=False)
    accumulated_pnl = Column(VARCHAR(20), nullable=False)
    daynight = Column(ENUM('Unknown','DAY','NIGHT'), nullable=False)
    ctime = Column(DATETIME, nullable=False)
    utime = Column(DATETIME, nullable=False)
    available_cash = Column(VARCHAR(20), nullable=False)
    asset_cash = Column(VARCHAR(20), nullable=False)
    position_cash = Column(DOUBLE, nullable=True)
    forex_rate = Column(DOUBLE, nullable=True)


class VSBase(ModelBase):

    __tablename__ = 'vs_base'

    __table_args__ = (
        PrimaryKeyConstraint('vstrategy_id', 'settle_date', 'daynight'),
    )

    vstrategy_id = Column(BIGINT(unsigned=True), nullable=False)
    cash = Column(VARCHAR(20), nullable=False)
    accumulated_pnl = Column(VARCHAR(20), nullable=False)
    settle_date = Column(DATE, nullable=False)
    daynight = Column(ENUM('Unknown','DAY','NIGHT'), nullable=False)
    ctime = Column(DATETIME, nullable=False)
    utime = Column(DATETIME, nullable=False)
    available_cash = Column(VARCHAR(20), nullable=False)
    asset_cash = Column(VARCHAR(20), nullable=False)


class RiskManagement(ModelBase):

    __tablename__ = 'risk_management'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    sse_max_declaration = Column(INTEGER, nullable=False)
    szse_max_declaration = Column(INTEGER, nullable=False)
    day_max_delegate = Column(INTEGER, nullable=False)
    max_count = Column(INTEGER, nullable=False)
    cancellation_radio = Column(FLOAT, nullable=False)
    discarded_radio = Column(FLOAT, nullable=False)
    turnover_radio = Column(FLOAT, nullable=False)
    day_max_buy = Column(FLOAT, nullable=False)
    account_id = Column(INTEGER, nullable=False)

    def to_dict(self):
        return {
            'shse_max_declaration': self.sse_max_declaration,
            'szse_max_declaration': self.szse_max_declaration,
            'day_max_delegate': self.day_max_delegate,
            'max_count': self.max_count,
            'cancellation_radio': self.cancellation_radio,
            'discarded_radio': self.discarded_radio,
            'turnover_radio': self.turnover_radio,
            'day_max_buy': self.day_max_buy,
            'account_id': self.account_id,
        }


class StrategyLiveRunRecords(ModelBase):

    __tablename__ = 'strategy_live_run_records'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(BIGINT(unsigned=True), nullable=False)
    vstrategy_id = Column(BIGINT(unsigned=True), nullable=False)
    host = Column(VARCHAR(64), nullable=False)
    deploy_path = Column(VARCHAR(256), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    xml = Column(LONGTEXT, nullable=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())


class StrategyOrdersRejected(ModelBase):

    __tablename__ = 'strategy_orders_rejected'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    calendar_date = Column(DATE, nullable=False)
    calendar_time = Column(TIME, nullable=False)
    calendar_microsec = Column(INTEGER, nullable=True)
    trading_date = Column(DATE, nullable=False)
    internal_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    vstrategy_id = Column(BIGINT(unsigned=True), nullable=False)
    serial_no = Column(VARCHAR(32), nullable=False)
    cancel_serial_no = Column(VARCHAR(32), nullable=False)
    exchange = Column(VARCHAR(10), nullable=False)
    symbol = Column(VARCHAR(32), nullable=False)
    # 0:buy 1:sell
    direction = Column(INTEGER, nullable=False)
    # 0:open 1:close 2:close_today 3:close_yesterday
    open_close = Column(INTEGER, nullable=False)
    price = Column(DOUBLE, nullable=False)
    volume = Column(INTEGER, nullable=False)
    # 0:Limit Order  1:Market Order
    order_type = Column(INTEGER, nullable=False)
    # 0:SPECULATOR  1:EDGER  2:ARBITRAGEURS
    investor_type = Column(INTEGER, nullable=False)
    # 0:norma 1:FAK 2:IOC 3:FOK 4:GTD 5:GTC
    time_in_force = Column(INTEGER, nullable=False)
    error_no = Column(INTEGER, nullable=False)
    error_msg = Column(VARCHAR(512), nullable=True)


class DigitalCashStrategyPositions(ModelBase):

    __tablename__ = 'digital_cash_strategy_positions'

    id = Column(BIGINT, primary_key=True)
    vstrategy_id = Column(BIGINT(unsigned=True), nullable=False)
    symbol = Column(VARCHAR(128), nullable=False)
    long_pos = Column(INTEGER, nullable=False)
    short_pos = Column(INTEGER, nullable=False)
    create_user_id = Column(BIGINT(unsigned=True))
    update_user_id = Column(BIGINT(unsigned=True))
    create_time = Column(DATETIME, nullable=False, server_default=func.now())
    update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())


class CrontabTasks(ModelBase):

    __tablename__ = 'crontab_tasks'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(128), nullable=False, unique=True)             # crontab name
    scheduler = Column(VARCHAR(128), nullable=True)                      # format like linux crontab: m h dom mon dow
    enable = Column(INTEGER, nullable=True)
    description = Column(VARCHAR(256), nullable=True)                    # comments for crontab
    host = Column(VARCHAR(256), nullable=True)
    next_time = Column(VARCHAR(64), nullable=True, default='0')
    notify_method = Column(INTEGER, nullable=True)
    notify_users = Column(JSON, nullable=True)
    script = Column(VARCHAR(256), nullable=True)
    para = Column(VARCHAR(256), nullable=True)
    timeout = Column(INTEGER, default=120)


class VStrategyAccountDetail(ModelBase):

    __tablename__ = 'vstrategy_account_detail'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vstrategy_id = Column(INTEGER, nullable=False)
    portfolio_id = Column(INTEGER, nullable=False)
    account = Column(VARCHAR(128), nullable=False)
    amount = Column(DOUBLE, nullable=False, default=0)
    actual_amount = Column(DOUBLE, nullable=False, default=0)
    annual_rate = Column(DOUBLE, nullable=False, default=0)
    exchange = Column(VARCHAR(32), nullable=False)
    trading_date = Column(DATE, nullable=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=True)
    start_time = Column(INTEGER, nullable=False, default=0)
    end_time = Column(INTEGER, nullable=False, default=0)


class ShannonLiveAccounts(ModelBase):

    __tablename__ = 'shannon_live_accounts'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)
    exchange = Column(VARCHAR(255), nullable=True)
    description = Column(VARCHAR(255), nullable=True)
    create_user_id = Column(BIGINT(unsigned=True))
    update_user_id = Column(BIGINT(unsigned=True))
    create_time = Column(DATETIME, nullable=False, server_default=func.now())
    update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())


if __name__ == '__main__':
    from db import engine
    ModelBase.metadata.create_all(engine)

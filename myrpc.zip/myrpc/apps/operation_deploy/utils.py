# -*- coding:utf-8 -*-

import os
import redis
import base64
import json
import datetime
import requests
import tornado.httpclient
import pickle
import zlib
from config import config
from log import logger

from time import time, sleep
from functools import partial, wraps


def time_it(function, save=print):
    @wraps(function)
    def _wrapper(*args, **kwargs):
        start = time()
        r = function(*args, **kwargs)
        duration = round((time() - start) * 1000, 6)
        save("the duration of {name} is {duration} ms".format(name=function.__name__, duration=duration))
        return r

    return _wrapper


time_it_logger = partial(time_it, save=logger.info)


def get_ev_info(trading_date, day_night, vstrategy_id, strategy_type):
    result = ""
    try:
        # get data from platform
        params = {
            'trading_date': trading_date,
            'day_night': day_night,
        }
        # TODO: 循环中进行requests阻塞取数据，可能成为新的瓶颈
        raw = requests.get(config.platform['st_url'] + str(vstrategy_id), params=params)
        # if platform error
        if not raw.ok:
            logger.error("[get_platform_data]: %s" % str(raw.content))
            return result
        res = raw.json()
        if 0 != res['code']:
            logger.error("[get_platform_data]: %s" % res['data'])
            return result
        logger.info('get strategy ev info of vstrategy_id %d', vstrategy_id)

        ev = res['data']['ev_files']
        if strategy_type == 'order_list' or res['data']['strategy_type'] == 'clear_position':
            if 'strategy_upload/volume_profile.csv' in ev:
                profile_idx = ev.index('strategy_upload/volume_profile.csv')
                ev = ev[:profile_idx]
        result = '|'.join([os.path.join('/home/mycapitaltrade/st_ev/', os.path.basename(f)) for f in ev])
    except Exception as e:
        logger.error(str(e))
    finally:
        return result



def save_file(path, filelikeobj):
    logger.info('save %s to %s' % (filelikeobj.filename, path))
    if not os.path.exists(path):
        os.mkdir(path)
    data_fd = None
    try:
        with open(os.path.join(path, filelikeobj.filename), 'wb') as f:
            f.write(filelikeobj.body)
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def check_redis_session(redis_config, session):
    rds = redis.Redis(redis_config['host'], redis_config['port'])
    s = rds.get('session:%s' % session)
    if s:
        data = json.loads(str(base64.b64decode(s), 'utf-8').split(':', 1)[-1])
        if ('_auth_user_id' in data):
            res = {
                'id': data.get('_auth_user_id'),
                'username': data.get('_auth_user_name', ''),
                'nickname': data.get('_auth_user_nickname', ''),
            }
            return res
    return {}


def query_redis_iphost(redis_config, host):
    iphost = ''
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        hosts = rds.smembers('a:oss:hosts')
        for h in hosts:
            h = str(h, 'utf-8')
            if h == host:
                iphost = h
    except Exception as e:
        logger.error(str(e))
        raise e
        return ''
    return iphost


def query_agent_online(redis_config, host):
    online = 2
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        d = rds.hget('oss:monitor:overview:host_status', host)
        if d:
            data = json.loads(str(d, 'utf-8'))
            online = 2 if data.get('agent_status', -2) == -2 else 0
    except Exception as e:
        logger.error(str(e))
        raise e
    finally:
        return online


def set_agent_open_close(redis_config, host, open_close):
    '''
    :param redis_config: 
    :param host: 
    :param open_close: agent open or close, 0: open, 2: close
    :return: 
    '''
    try:
        redis_key = 'oss:monitor:overview:host_status'
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        d = rds.hget(redis_key, host)
        if d:
            data = json.loads(str(d, 'utf-8'))
            data['agent_open_close'] = open_close
            data['update_time'] = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H:%M:%S.%f') + ' CST'
        else:
            data = {
                'agent_status': -2,
                'agent_open_close': open_close,
                'disk_problem': 0,
                'cpu_problem': 0,
                'ram_problem': 0,
                'swap_problem': 0,
                'process_total': 0,
                'process_problem': 0,
                'alert_problem': 0,
                'device_total': 0,
                'device_problem': 0,
                'clock_diff': 0,
                'clock_diff_status': 0,
                'update_time': datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H:%M:%S.%f') + ' CST'
            }
        rds.hset(redis_key, host, json.dumps(data))
    except Exception as e:
        logger.error(str(e))
        raise e


def query_process_online(redis_config, host):
    res = {}
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        d = rds.hget('a:oss:monitor:processes', host)
        # l = rds.hgetall('oss:deploy:monitor:processes:%s' % host)
        if d:
            data = json.loads(str(d, 'utf-8'))
            process_list = data.get('process', [])
            for process in process_list:
                process_id = process.get('process_id', 0)
                if process.get('status', -1) == -1:
                    res[process_id] = 2
                else:
                    if process.get('is_running', 0) == 1:
                        res[process_id] = 0
                        # ld = l.get(process_id.encode('utf-8'), None)
                        # if ld:
                        #    ld = json.loads(str(ld, 'utf-8'))
                        #    if ld.get('launch_status', 0) == -1:
                        #        res[process_id] = 2
                    else:
                        res[process_id] = 2
    except Exception as e:
        logger.error(str(e))
        raise e
    finally:
        return res


def rpush_redis_cmd(redis_config, iphost, cmd):
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        r_queue = redis_config['cmd_key'] + iphost
        rds.rpush(r_queue, cmd)
        # logger.info('rpush redis=[%s]: cmd=[%s]' % (r_queue, cmd))
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def lpop_redis_cmd(redis_config, iphost, seq):
    data = None
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        r_queue = redis_config['rsp_key'] + iphost
        for d in rds.lrange(r_queue, 0, -1):
            if json.loads(str(d, 'utf-8'))['seq'] == seq:
                data = d
                break
        rds.lrem(r_queue, data, 0)
        logger.info('lpop redis=[%s], seq=[%d]: data=[%s]' % (r_queue, seq, data))
        return data
    except Exception as e:
        logger.error(str(e))
        raise e
        return None


def update_redis_process(redis_config, iphost, path, running, process_id):
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        r_hash = 'oss:deploy:monitor:processes:%s' % iphost
        data = json.dumps({
            'path': path,
            'is_running': running,
            'process_id': process_id,
            'clock': time(),
            'monitor_progress': 0,
            'launch_status': 0,
        })
        rds.hset(r_hash, process_id, data)
        logger.info('update: hset redis=[%s], process_id=[%s], data=[%s]' % (r_hash, process_id, data))
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def delete_redis_process(redis_config, iphost, process_id):
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        r_hash = 'oss:deploy:monitor:processes:%s' % iphost
        if not rds.hexists(r_hash, process_id):
            return False
        rds.hdel(r_hash, process_id)
        logger.info('delete: hdel redis=[%s], process_id=[%s]' % (r_hash, process_id))
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def set_process_status_reported_by_agent(redis_config, iphost, status):
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        r_hash = 'a:oss:monitor:processes'
        if not rds.hexists(r_hash, iphost):
            logger.info('No found process info of %s in %s' % (iphost, r_hash))
            return True
        data = rds.hget(r_hash, iphost)
        data = json.loads(str(data, 'utf-8'))
        logger.debug('Read %s from a:oss:monitor:processes, get %s' % (iphost, data))
        process_info = data['process']
        for p in process_info:
            p['status'] = status
        t = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
        data['update_time'] = '%s CST' % t[:-3]
        rds.hset(r_hash, iphost, json.dumps(data))
        logger.info('update: hset redis=[%s], host=[%s], data=[%s]' % (r_hash, iphost, data))
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def reset_stra_placeorder_status(redis_config, vstrategy_id):
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        r_hash = 'oss:monitor:stra_place_order:in_premarket_trading'
        data = {
            'is_place_order': 0,  # 1:有报单; 0:无报单
            'time': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')  # 策略启动时间
        }
        rds.hset(r_hash, vstrategy_id, json.dumps(data))
        logger.info('hset redis=[%s], vstrategy_id=[%s], data=[%s]' % (r_hash, vstrategy_id, data))
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def del_process_status_reported_by_agent(redis_config, iphost):
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        r_hash = 'a:oss:monitor:processes'
        if not rds.hexists(r_hash, iphost):
            logger.info('No found process info of %s in %s' % (iphost, r_hash))
            return True
        rds.hdel(r_hash, iphost)
        logger.info('del process status: hdel redis=[%s], host=[%s]' % (r_hash, iphost))
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def clear_history_launch_msg(redis_config, iphost, process_id):
    key = 'a:oss:launch'
    items_to_del = []

    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        for d in rds.lrange(key, 0, -1):
            j_data = json.loads(str(d, 'utf-8', 'ignore'))
            if j_data.get('ip', '') == iphost and j_data.get('process_id', -1) == process_id:
                items_to_del.append(d)
        for d in items_to_del:
            rds.lrem(key, d, 0)
            logger.info('del history launch msg: {}'.format(d))
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def compress_package(l_path, l_package, bfiles):
    os.chdir(l_path)
    cmd = 'tar -czf %s %s' % (l_package, ' '.join(bfiles))
    try:
        res = os.system(cmd)
        logger.info('exec cmd: %s' % cmd)
        if res != 0:
            logger.info('cmd error: %s' % cmd)
            return False
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def extract_package(s_host, s_path, bfile, type):
    if type == 0 or type == 3 or type == 5:
        cmd = 'tar -xf %s --strip-components 1 -C %s' % (os.path.join(s_path, os.path.basename(bfile)), s_path)
    else:
        cmd = 'tar -xf %s -C %s' % (os.path.join(s_path, os.path.basename(bfile)), s_path)
    scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
    try:
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def compress_conf(conf):
    # 1. str-->bytes
    byte_conf = conf.encode('utf-8')
    # 2. compress
    bytes_com = zlib.compress(byte_conf)
    logger.debug('compress rate: %f', round(len(bytes_com) / len(conf), 2))
    # 3. 使用base64编码
    bytes_base64 = base64.b64encode(bytes_com)
    logger.debug('b64encode rate: %f', round(len(bytes_base64) / len(conf), 2))
    # 4. bytes --> str
    conf_str = bytes_base64.decode('utf-8')
    logger.debug('finish rate: %f', round(len(conf_str) / len(conf), 2))
    return conf_str


def make_dirs(s_host, s_path):
    cmd = 'mkdir -p %s' % s_path
    scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
    try:
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def backup_bfile(s_host, s_path, now):
    if not make_dirs(s_host, os.path.join(os.path.dirname(s_path), 'bak')):
        return False
    cmd = 'mv %s %s/bak/%s_%s' % (s_path, os.path.dirname(s_path),
                                  os.path.basename(s_path), datetime.datetime.strftime(now, '%Y%m%d%H%M%S'))
    scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
    try:
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def recovery_st(s_host, s_path, now):
    try:
        cmd = 'mkdir -p %s/st_so' % s_path
        scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False

        cmd = 'mv %s/bak/%s_%s/st_so/* %s/st_so' % (os.path.dirname(s_path), os.path.basename(s_path),
                                                    datetime.datetime.strftime(now, '%Y%m%d%H%M%S'), s_path)
        scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False

        cmd = 'mkdir -p %s/st_ev' % s_path
        scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False

        cmd = 'mv %s/bak/%s_%s/st_ev/* %s/st_ev' % (os.path.dirname(s_path), os.path.basename(s_path),
                                                    datetime.datetime.strftime(now, '%Y%m%d%H%M%S'), s_path)
        scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False

        cmd = 'mkdir -p %s/st_log' % s_path
        scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False

        cmd = 'mv %s/bak/%s_%s/st_log/* %s/st_log' % (os.path.dirname(s_path), os.path.basename(s_path),
                                                      datetime.datetime.strftime(now, '%Y%m%d%H%M%S'), s_path)
        scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False

    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


def upload_bfile(l_user, l_host, s_host, s_path, bfile, type=0, p_dpl=False, st_dpl=False):
    # type: 1: strategy so, 2: ev, 0: trading file
    now = datetime.datetime.now()
    if type == 1 or type == 4:
        s_path = os.path.join(s_path, 'st_so')
    elif type == 2:
        s_path = os.path.join(s_path, 'st_ev')
    cmd = 'rsync -az %s@%s:%s %s' % (l_user, l_host, bfile, s_path)
    scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
    try:
        if type == 0 or type == 3:
            if p_dpl:
                backup_bfile(s_host, s_path, now)
        if not make_dirs(s_host, s_path):
            return False
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False
        if not extract_package(s_host, s_path, bfile, type):
            return False
        if type == 3 and st_dpl:
            recovery_st(s_host, s_path, now)
    except Exception as e:
        logger.error(str(e))
        return False
    return True


def is_python_strategy(file_path):
    if os.path.isfile(file_path):
        cmd = 'nm -gC "%s" | grep "PyInit_st"' % file_path
        ret = os.system(cmd)
        return ret == 0
    return False


def upload_python_strategy(l_user, l_host, s_host, s_path, bfile, vid=None):
    try:
        # rsync file
        strategy_name = os.path.basename(bfile).replace('.so', '')
        s_path = os.path.join(s_path, 'st_so')
        cmd = 'mkdir -p %s' % os.path.join(s_path, strategy_name)
        cmd += ';rsync -az %s@%s:%s %s' % (l_user, l_host, bfile, s_path)
        # scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
        # res = os.system(scmd)
        # logger.info('exec cmd: %s' % scmd)
        # if res != 0:
        #    logger.info('cmd error: %s' % scmd)
        #    return False

        # mkdir, link
        cmd += ';ln -sf %s/%s.so %s/%s/st.so' % (s_path, strategy_name, s_path, strategy_name)
        if vid is None:
            cmd += ';mkdir -p %s' % os.path.join('/home/mycapitaltrade/output', strategy_name)
        else:
            cmd += ';mkdir -p %s' % '/home/mycapitaltrade/output/%s_%s' % (strategy_name, vid)
        scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False

    except Exception as e:
        logger.error(str(e))
        return False
    return True


# def upload_python_strategy(l_user, l_host, s_host, s_path, bfile, vid=None):
#    strategy_name = os.path.basename(bfile).replace('.so', '')
#    s_path = os.path.join(s_path, 'st_so')
#    cmd = 'rsync -az %s@%s:%s %s' % (l_user, l_host, bfile, s_path)
#    scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
#    try:
#        if vid is None:
#            if not make_dirs(s_host, os.path.join('/home/mycapitaltrade/output', strategy_name)):
#                return False
#        else:
#            if not make_dirs(s_host, '/home/mycapitaltrade/output/%s_%s' % (strategy_name, vid)):
#                return False
#        if not make_dirs(s_host, s_path):
#            return False
#        res = os.system(scmd)
#        logger.info('exec cmd: %s' % scmd)
#        if res != 0:
#            logger.info('cmd error: %s' % scmd)
#            return False
#        if not link_python_strategy(s_host, s_path, strategy_name):
#            return False
#    except Exception as e:
#        logger.error(str(e))
#        return False
#    return True


def link_python_strategy(s_host, s_path, strategy_name):
    try:
        if not make_dirs(s_host, os.path.join(s_path, strategy_name)):
            return False
        cmd = 'ln -sf %s/%s.so %s/%s/st.so' % (s_path, strategy_name, s_path, strategy_name)
        scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False
    except Exception as e:
        logger.error(str(e))
        return False
    return True


def run_agent_process(s_host, s_path, opt_type):
    if opt_type == 0:
        cmd = 'sh %s/run.sh' % s_path
    elif opt_type == 2:
        cmd = 'sh %s/task_kill.sh' % s_path
    else:
        return False
    scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (s_host, cmd)
    try:
        res = os.system(scmd)
        logger.info('exec cmd: %s' % scmd)
        if res != 0:
            logger.info('cmd error: %s' % scmd)
            return False
        # set_process_status_reported_by_agent(config.redis, s_host, -1)
        if opt_type == 2:
            del_process_status_reported_by_agent(config.redis, s_host)
    except Exception as e:
        logger.error(str(e))
        return False
    return True


def register_process_event(host, process_id):
    headers = {
        'content-type': 'application/json',
        'whitelist': 'operater',
    }
    data = {
        'type': 'process',
        'host': host,
        'process_id': process_id,
    }
    req_url = 'http://127.0.0.1/api/v1/event_handle/deploy_reg_handle'
    http_client = tornado.httpclient.HTTPClient()
    response = http_client.fetch(
        req_url,
        method='POST',
        headers=headers,
        body=json.dumps(data),
    )
    return response.body


def notify_monitor_module(redis_config, type):
    try:
        rds = redis.Redis(redis_config['host'], redis_config['port'])
        r_queue = "oss:monitor:event_handle:update_conf"
        data = json.dumps({
            "update": type,
            "clock": datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
        })
        rds.rpush(r_queue, data)
        logger.info('rpush redis=[%s]: payload=[%s]' % (r_queue, data))
    except Exception as e:
        logger.error(str(e))
        raise e
        return False
    return True


class RedisCache:

    """
    :TODO： 使用新的redis_utils中的封装，该类去掉
    """
    def __init__(self, *args, **kwargs):
        self.rds = redis.Redis(config.redis['host'], config.redis['port'], *args, **kwargs)

    def conn(self, *args, **kwargs):
        if not self.rds:
            self.rds = redis.Redis(config.redis['host'], config.redis['port'], *args, **kwargs)
        return self.rds

    def set_hash_cache(self, redis_key, key, value):
        try:
            rds = self.conn()
            target_value = pickle.dumps(value)
            rds.hset(redis_key, key, target_value)
        except Exception as err:
            logger.error("set redis cache error: %s", err, exc_info=True)

    def get_hash_cache(self, redis_key, key):
        try:
            rds = self.conn()
            target_value = rds.hget(redis_key, key)
            if target_value is None:
                return target_value
            return pickle.loads(target_value)
        except Exception as err:
            logger.error("get redis cache error: %s", err, exc_info=True)

    def get_all_hash_cache(self, redis_key):
        try:
            rds = self.conn(decode_responses=True)
            target_value = rds.hgetall(redis_key)
            if target_value is None:
                return target_value
            if isinstance(target_value, bytes):
                return pickle.loads(target_value)
            else:
                return target_value

        except Exception as err:
            logger.error("get redis cache error: %s", err, exc_info=True)

    def set_cache(self, redis_key, data, expire_seconds):
        try:
            rds = self.conn()
            if expire_seconds:
                return rds.setex(redis_key, json.dumps(data), int(expire_seconds))
            return rds.set(redis_key, data)
        except Exception as err:
            logger.error("set redis cache error: %s", err, exc_info=True)

    def get_cache(self, redis_key):
        try:
            rds = self.conn()
            data = rds.get(redis_key)
            return data and json.loads(str(data, 'utf-8'))
        except Exception as err:
            logger.error("set redis cache error: %s", err, exc_info=True)

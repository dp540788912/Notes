#-*-coding:utf-8-*-

import time
import json
import datetime
import math
import numpy as np
import pandas as pd
from qpython import qconnection
from config import config


def transform_date(int_days):
    begin = datetime.datetime(2000, 1, 1)
    return (begin + datetime.timedelta(days=int_days)).strftime('%Y%m%d')


def transform_date_v2(int_days):
    begin = datetime.datetime(2000, 1, 1)
    return (begin + datetime.timedelta(days=int_days)).strftime('%Y-%m-%d')


class KdbQuery(object):
    def __init__(self, host=config.kdb['host'], port=config.kdb['port'],
                 username=config.kdb['user'], password=config.kdb['passwd']):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.connect()

    def __del__(self):
        self.release()

    def reconnect(self):
        try:
            self.release()
        finally:
            return self.connect()

    def release(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def connect(self):
        try:
            self.conn = qconnection.QConnection(host=self.host, port=self.port,
                                                username=self.username, password=self.password)
            self.conn.open()
            return self.conn.is_connected()
        except Exception as err:
            return False

    def check(self):
        if self.conn.is_connected():
            return True
        else:
            return False

    def sync_query(self, q_sql):
        data = None
        if self.check():
            data = self.conn.sync(str(q_sql))
        return data

    def async_query(self, q_sql, **kwargs):
        data = None
        if self.check():
            self.conn.async(str(q_sql))
            data = self.conn.receive(**kwargs)
        return data

    def get_trading_date_now(self, hour=20, calendar_date=None, calendar_hour=None):
        now = datetime.datetime.now()
        if not calendar_date:
            calendar_date = now.strftime('%Y-%m-%d')
        now_hour = now.hour
        if calendar_hour:
            now_hour = int(calendar_hour)
        q_sql = """.gw.asyncexec["select TRADE_DT from Calendar where EXCHANGE=`SSE, TRADE_DT>=2017.01.01";`FuturesBasicInfo]"""
        ret = self.async_query(q_sql)
        dates = [r[0] for r in ret]
        for d in sorted(dates):
            d = transform_date_v2(int(d))
            if now_hour >= hour:
                if d > calendar_date:
                    return d
            else:
                if d >= calendar_date:
                    return d
        raise ValueError('get trading date error')

    def get_trading_date(self, calendar_date, period):
        """
        @calendar_date: 2000-01-01
        @period: 0:[00:00:00-04:59:59], 1:[17:00:00-23:59:59]
        """
        _d = datetime.datetime.strptime(calendar_date, '%Y-%m-%d')
        kdb_calendar_date = datetime.datetime.strftime(_d, '%Y.%m.%d')
        calendar = datetime.datetime.strftime(_d, '%Y%m%d')
        q_sql = """.gw.asyncexec["select TRADE_DT from Calendar where EXCHANGE=`SSE, TRADE_DT>=2016.01.01";`FuturesBasicInfo]"""
        ret = self.async_query(q_sql)
        dates = [r[0] for r in ret]
        for d in sorted(dates):
            d = transform_date(int(d))
            if period == 1:
                if d > calendar:
                    return d
            elif period == 0:
                if d >= calendar:
                    return d
        raise ValueError('get trading date error')



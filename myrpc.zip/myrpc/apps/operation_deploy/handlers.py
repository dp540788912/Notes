# -*- coding: utf-8 -*-

import json
import os
import requests
import csv
import shutil
import time
import datetime
import subprocess
import tornado.ioloop
import tornado.web
import tornado.httpclient
import const
import xml.etree.ElementTree as ET
import copy
import redis
import hashlib
import glob
from sqlalchemy.sql import func, or_, and_
from sqlalchemy import distinct
from sqlalchemy.dialects.mysql import BIGINT, DATETIME, DATE, TIME, INTEGER, VARCHAR, TEXT, LONGTEXT, FLOAT, DOUBLE, \
    BOOLEAN, JSON, ENUM, SMALLINT
from tornado import gen
from tornado.concurrent import run_on_executor
from concurrent.futures import ThreadPoolExecutor
from db import session, session_context as mysql_sc
from config import config
from kdb_query import KdbQuery
from my.data import basic_func
from log import logger
from utils import save_file, check_redis_session, query_redis_iphost, query_agent_online, set_agent_open_close, \
    query_process_online, rpush_redis_cmd, lpop_redis_cmd, update_redis_process, delete_redis_process, \
    set_process_status_reported_by_agent, del_process_status_reported_by_agent, clear_history_launch_msg, \
    compress_package, extract_package, compress_conf, make_dirs, backup_bfile, recovery_st, upload_bfile, \
    is_python_strategy, upload_python_strategy, link_python_strategy, run_agent_process, register_process_event, \
    notify_monitor_module, RedisCache, reset_stra_placeorder_status
from models import Exchanges, Brokers, Counters, Accounts, Servers, Paths, Users, Strategies, Strategy, \
    StrategyPortfolio, StrategyUploadFile, VStrategies, OnlineRequest, ProgramTypes, ApiTypes, QuoteSrcTypes, \
    TunnelTypes, ConfigTemplates, Programs, DeployPrograms, DeployStrategies, DeployConfs, PreQuoteConfs, \
    PreTunnelConfs, PreTraderConfs, PreAgentConfs, PreStrategyConfs, PreForwarderConfs, TradeLogs, TuringTradeLogs, \
    StrategyPerfInput, ParentOrder, ChildrenOrder, VSPositions, VSAccounts, VSBase, RiskManagement, \
    StrategyLiveRunRecords, StrategyOrdersRejected, DigitalCashStrategyPositions, CrontabTasks, VStrategyAccountDetail, \
    ShannonLiveAccounts
from redis_utils import RedisHelper
from const import APIResponseCode


class BaseHandler(tornado.web.RequestHandler):

    def initialize(self, *args, **kwargs):
        self.model = None
        self.fields = {}  # key: model-key, value: payload-key
        self.no_login = []

    def prepare(self, *args, **kwargs):
        if hasattr(self, 'no_login') and self.request.method.lower() in self.no_login:
            self.current_user = {}
            return
        if self.request.headers.get('whitelist'):
            self.current_user = {
                'id': 999999,
                'username': self.request.headers['whitelist'],
                'nickname': self.request.headers['whitelist'],
            }
        else:
            sessionid = self.get_cookie('sessionid')
            if not sessionid:
                self.write(json.dumps({
                    'code': 401,
                    'error': 'Sessionid not found.'
                }))
                self.finish()
                return
            res = check_redis_session(config.redis, sessionid)
            if not res:
                self.write(json.dumps({
                    'code': 401,
                    'error': 'User not login.',
                }))
                self.finish()
                return
            self.current_user = res

    def get(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def post(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def put(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def delete(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))


class ListHandler(BaseHandler):

    def get(self, *args, **kwargs):
        res = []
        with mysql_sc() as sc:
            if hasattr(self,'order_by'):
                lines = sc.query(self.model).order_by(self.order_by).all()
            else:
                lines = sc.query(self.model).all()
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if sorted(payload.keys()) != sorted(self.fields.values()):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            data = {}
            for k, v in self.fields.items():
                data[k] = payload[v]
            with mysql_sc() as sc:
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

class IDHandler(BaseHandler):

    def get(self, *args, **kwargs):
        with mysql_sc() as sc:
            o = sc.query(self.model).filter_by(id=kwargs['id']).first()
            if o:
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
            else:
                self.write(json.dumps({
                    'code': 404,
                    'error': 'Data not found.',
                }))

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    for k, v in self.fields.items():
                        if v in payload:
                            setattr(o, k, payload[v])
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                sc.query(self.model).filter_by(id=kwargs['id']).delete()
                self.write(json.dumps({
                    'code': 0,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class ExchangesListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = Exchanges
        self.fields = {
            'name': 'name',
            'code': 'code',
        }


class ExchangesDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = Exchanges
        self.fields = {
            'name': 'name',
            'code': 'code',
        }


class BrokersListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = Brokers
        self.fields = {
            'name': 'name',
        }
        self.no_login = ['get']


class BrokersDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = Brokers
        self.fields = {
            'name': 'name',
        }


class CountersListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = Counters
        self.fields = {
            'name': 'name',
            'exchange_id': 'exchange_id',
            'broker_id': 'broker_id',
            'broker_no': 'broker_no',
            'quote_forwarder_addr': 'quote_forwarder_addr',
            'counter_forwarder_addr': 'counter_forwarder_addr',
            'query_addr': 'query_addr',
        }


class CountersDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = Counters
        self.fields = {
            'name': 'name',
            'exchange_id': 'exchange_id',
            'broker_id': 'broker_id',
            'broker_no': 'broker_no',
            'quote_forwarder_addr': 'quote_forwarder_addr',
            'counter_forwarder_addr': 'counter_forwarder_addr',
            'query_addr': 'query_addr',
        }


class AccountsListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.order_by = "name desc"
        self.model = Accounts
        self.fields = {
            'name': 'name',
            'password': 'password',
            # 'fund_total': 'fund_total',
            # 'fund_occupied': 'fund_occupied',
            'broker_id': 'broker_id',
            'user_id': 'user_id',
            'valid': 'valid',
            'use_turing': 'use_turing',
            'seat': 'seat',
            'rsp_pwd': 'rsp_pwd',
            'client_name': 'client_name',
            'need_query': 'need_query',
            'account_name': 'account_name',
            'fund_ratio': 'fund_ratio',
            'use_for': 'use_for',
            'market': 'market',
            'counter_seat': 'counter_seat',
            'query_passwd': 'query_passwd',
            'query_broker': 'query_broker',
            'check_pos': 'check_pos',
            'product_info': 'product_info',
            'auth_code': 'auth_code',
            'account_prop': 'account_prop',
        }


class AccountsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = Accounts
        self.fields = {
            'name': 'name',
            'password': 'password',
            # 'fund_total': 'fund_total',
            # 'fund_occupied': 'fund_occupied',
            'broker_id': 'broker_id',
            'user_id': 'user_id',
            'valid': 'valid',
            'use_turing': 'use_turing',
            'seat': 'seat',
            'rsp_pwd': 'rsp_pwd',
            'client_name': 'client_name',
            'need_query': 'need_query',
            'account_name': 'account_name',
            'fund_ratio': 'fund_ratio',
            'use_for': 'use_for',
            'market': 'market',
            'counter_seat': 'counter_seat',
            'query_passwd': 'query_passwd',
            'query_broker': 'query_broker',
            'check_pos': 'check_pos',
            'product_info': 'product_info',
            'auth_code': 'auth_code',
            'account_prop': 'account_prop',
        }


class ServersListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = Servers
        self.fields = {
            'ip': 'ip',
            'broker_id': 'broker_id',
        }

    def get(self, *args, **kwargs):
        serverip = self.get_argument('ip', None)
        try:
            with mysql_sc() as sc:
                if serverip:
                    line = sc.query(self.model).filter_by(ip=serverip).first()
                    res = line.to_dict()
                else:
                    res = []
                    lines = sc.query(self.model).all()
                    for line in lines:
                        res.append(line.to_dict())
            self.write(json.dumps({
                'code': 0,
                'data': res
            }))
        except Exception as err:
            logger.error("serverip=%s', error: %s", serverip, err, exc_info=True)
            self.write({
                'code': 500,
                'error': str(err)
            })


class ServersDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = Servers
        self.fields = {
            'ip': 'ip',
            'broker_id': 'broker_id',
        }


class PathsListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = Paths
        self.fields = {
            'name': 'name',
        }


class PathsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = Paths
        self.fields = {
            'name': 'name',
        }


class UsersListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = Users
        self.fields = {
            'name': 'name',
            'password': 'password',
        }


class UsersDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = Users
        self.fields = {
            'name': 'name',
            'password': 'password',
        }


class ProgramTypesListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = ProgramTypes
        self.fields = {
            'name': 'name',
        }


class ProgramTypesDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = ProgramTypes
        self.fields = {
            'name': 'name',
        }


class ApiTypesListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = ApiTypes
        self.fields = {
            'name': 'name',
            'api_id': 'api_id',
            'program_type_id': 'program_type_id',
            'exchange_id': 'exchange_id',
        }


class ApiTypesDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = ApiTypes
        self.fields = {
            'name': 'name',
            'api_id': 'api_id',
            'program_type_id': 'program_type_id',
            'exchange_id': 'exchange_id',
        }


class QuoteSrcTypesListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = QuoteSrcTypes
        self.fields = {
            'name': 'name',
            'api_id': 'api_id',
            'program_type_id': 'program_type_id',
        }


class QuoteSrcTypesDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = QuoteSrcTypes
        self.fields = {
            'name': 'name',
            'api_id': 'api_id',
            'program_type_id': 'program_type_id',
        }


class TunnelTypesListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = TunnelTypes
        self.fields = {
            'name': 'name',
            'api_id': 'api_id',
            'program_type_id': 'program_type_id',
        }


class TunnelTypesDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = TunnelTypes
        self.fields = {
            'name': 'name',
            'api_id': 'api_id',
            'program_type_id': 'program_type_id',
        }


class ConfigTemplatesListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.order_by = 'name desc'
        self.model = ConfigTemplates
        self.fields = {
            'name': 'name',
            'content': 'content',
            'program_type_id': 'program_type_id',
            'api_type_id': 'api_type_id',
        }

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            data = {}
            for k, v in self.fields.items():
                if v in payload:
                    data[k] = payload[v]
            with mysql_sc() as sc:
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class ConfigTemplatesDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = ConfigTemplates
        self.fields = {
            'name': 'name',
            'content': 'content',
            'program_type_id': 'program_type_id',
            'api_type_id': 'api_type_id',
        }


class ProgramsListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = Programs
        self.fields = {
            'name': 'name',
            'type_id': 'type_id',
            'version': 'version',
        }

    def post(self, *args, **kwargs):
        self.upload_path = 'files'
        self.trader_file = self.request.files['trader'][0]
        if not save_file(os.path.join(os.path.dirname(os.path.realpath(__file__)), self.upload_path),
                         self.trader_file):
            self.write(json.dumps({
                'code': 501,
                'error': 'upload files error.',
            }))
            return
        try:
            data = {}
            for k, v in self.fields.items():
                data[k] = self.get_argument(v)
            data['filepath'] = os.path.join(
                os.path.dirname(os.path.realpath(__file__)),
                self.upload_path,
                self.trader_file.filename
            )
            with mysql_sc() as sc:
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                program_type = sc.query(ProgramTypes).filter(ProgramTypes.id == data['type_id']).first().name
                if program_type in ('volume_params', 'volume_profile'):
                    dest = "/home/rss/{program_type}/".format(program_type=program_type)
                    if not os.path.exists(dest):
                        os.makedirs(dest)
                    dest_file = os.path.join(dest, self.trader_file.filename + time.strftime('.%Y%m%d%H%M%S'))
                    cmd = """cp "{src}" "{dest}" """.format(
                        src=data['filepath'],
                        dest=dest_file
                    )
                    os.system(cmd)
                    if program_type == 'volume_profile':
                        dest_file2 = "/home/rss/volume_profile/volume_profile.py"
                    elif program_type == 'volume_params':
                        dest_file2 = "/home/rss/volume_params/MultiFactorEverydayTraining.py"
                    else:
                        dest_file2 = ''
                    if dest_file2:
                        cmd2 = """cp "{src}" "{dest}" """.format(
                            src=dest_file,
                            dest=dest_file2
                        )
                        os.system(cmd2)
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class ProgramsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = Programs
        self.fields = {
            'name': 'name',
            'type_id': 'type_id',
            'version': 'version',
        }

    def post(self, *args, **kwargs):
        self.upload_path = 'files'
        if self.request.files.get('trader'):
            self.trader_file = self.request.files['trader'][0]
            if not save_file(os.path.join(os.path.dirname(os.path.realpath(__file__)), self.upload_path),
                             self.trader_file):
                self.write(json.dumps({
                    'code': 501,
                    'error': 'upload files error.',
                }))
                return
        try:
            with mysql_sc() as sc:
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    for k, v in self.fields.items():
                        setattr(o, k, self.get_argument(v))
                    setattr(
                        o, 'filepath',
                        os.path.join(
                            os.path.dirname(os.path.realpath(__file__)),
                            self.upload_path,
                            self.trader_file.filename
                        )
                    )
                sc.commit()

                program_type = sc.query(ProgramTypes).filter(ProgramTypes.id == o.type_id).first().name
                if program_type in ('volume_params', 'volume_profile'):
                    dest = "/home/rss/{program_type}/".format(program_type=program_type)
                    if not os.path.exists(dest):
                        os.makedirs(dest)
                    dest_file = os.path.join(dest, self.trader_file.filename + time.strftime('.%Y%m%d%H%M%S'))
                    cmd = """cp "{src}" "{dest}" """.format(
                        src=o.filepath,
                        dest=dest_file
                    )
                    os.system(cmd)
                    if program_type == 'volume_profile':
                        dest_file2 = "/home/rss/volume_profile/volume_profile.py"
                    elif program_type == 'volume_params':
                        dest_file2 = "/home/rss/volume_params/MultiFactorEverydayTraining.py"
                    else:
                        dest_file2 = ''
                    if dest_file2:
                        cmd2 = """cp "{src}" "{dest}" """.format(
                            src=dest_file,
                            dest=dest_file2
                        )
                        os.system(cmd2)

                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class OnlineRequestListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = OnlineRequest

    def get(self, *args, **kwargs):
        res = []
        status = int(self.get_argument('status', '-1'))
        config = int(self.get_argument('config', '-1'))
        with mysql_sc() as sc:
            if status == 0:
                lines = sc.query(self.model).filter_by(status=0).order_by(self.model.id.desc())
            elif status == 1:
                lines = sc.query(self.model).filter(self.model.status != 0).order_by(self.model.id.desc())
            else:
                lines = sc.query(self.model).order_by(self.model.id.desc()).all()
            if config == 1:
                lines = lines.join(
                    StrategyPortfolio, StrategyPortfolio.id == self.model.portfolio_id
                ).join(
                    VStrategies, VStrategies.portfolio_id == StrategyPortfolio.id,
                ).filter(
                    VStrategies.status == 12,  # this vstrategy need to be config
                )
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res,
        }))


class OnlineRequestDetailHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.request_fields = {
            'portfolio_id': 'portfolio_id',
            'status': 'status',
            'action': 'action',
            'audit_time': 'audit_time',
            'audit_user': 'audit_user',
            'audit_comment': 'audit_comment',
        }
        self.vstrategy_fields = {
            'vstrategy_id': 'vstrategy_id',
            'strategy_weight': 'strategy_weight',
            'symbols_accounts': 'symbols_accounts',
        }

    @gen.coroutine
    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if 'status' not in payload or \
                'strategy' not in payload:
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            status = int(payload['status'])
            with mysql_sc() as sc:
                o = sc.query(OnlineRequest).filter_by(id=kwargs['id']).first()
                if o and o.status != 0:
                    self.write(json.dumps({
                        'code': 404,
                        'error': 'Request approved already.'
                    }))
                    return
                if status == 1:
                    for st in payload['strategy']:
                        vs = sc.query(VStrategies).filter_by(id=st['vstrategy_id']).first()
                        if not vs:
                            self.write(json.dumps({
                                'code': 404,
                                'error': 'VStrategy not found.',
                            }))
                            return
                        for item in (st['symbols_accounts'].get('day', []) + st['symbols_accounts'].get('night', [])):
                            if not item['account']:
                                self.write(json.dumps({
                                    'code': 400,
                                    'error': 'Account cannot be null.'
                                }))
                                return
                        for k, v in self.vstrategy_fields.items():
                            if v in st:
                                setattr(vs, k, st[v])
                        vs.status = 12
                elif status == 2:
                    if not payload['audit_comment']:
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Comment cannot be null.',
                        }))
                        return
                else:
                    self.write(json.dumps({
                        'code': 500,
                        'error': 'Operation error.',
                    }))
                    return
                o.audit_user = self.current_user['username']
                for k, v in self.request_fields.items():
                    if v in payload:
                        setattr(o, k, payload[v])
                sc.commit()

                # if status == 1:
                #    headers = {
                #        'content-type': 'application/json',
                #        'Cookie': 'sessionid=%s' % self.get_cookie('sessionid'),
                #    }
                #    req_url = config.platform['settle_url'] + '/strategy-initial-with-empty-positions'
                #    for st in payload['strategy']:
                #        r_data = {
                #            'vstrategy_id': st['vstrategy_id'],
                #            'accounts': {},
                #        }
                #        day_tmp = {}
                #        night_tmp = {}
                #        r = sc.query(VStrategies).filter_by(id=st['vstrategy_id']).first()
                #        if r:
                #            symbols_accounts = r.symbols_accounts
                #            for item in symbols_accounts.get('day', []):
                #                account = item['account']
                #                amount = float(item['amount'])
                #                if account not in day_tmp:
                #                    day_tmp[account] = amount
                #                else:
                #                    day_tmp[account] += amount
                #            for item in symbols_accounts.get('night', []):
                #                account = item['account']
                #                amount = float(item['amount'])
                #                if account not in night_tmp:
                #                    night_tmp[account] = amount
                #                else:
                #                    night_tmp[account] += amount
                #            for k, v in day_tmp.items():
                #                r_data['accounts'].setdefault(k, v)
                #            for k, v in night_tmp.items():
                #                r_data['accounts'].setdefault(k, v)

                #        http_client = tornado.httpclient.AsyncHTTPClient()
                #        response = yield gen.Task(
                #            http_client.fetch,
                #            req_url,
                #            method='POST',
                #            headers=headers,
                #            body=json.dumps(r_data),
                #        )
                #        logger.info('Settle process: resp=%s' % response.body)

                self.write(json.dumps({
                    'code': 0,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class DeployProgramsListHandler(ListHandler):
    executor = ThreadPoolExecutor(2)

    def initialize(self, *args, **kwargs):
        self.model = DeployPrograms

    @gen.coroutine
    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if ('server' not in payload) or \
                ('program_type' not in payload) or \
                ('program_version' not in payload) or \
                ('deploy_path' not in payload) or \
                ('day_night' not in payload):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            with mysql_sc() as sc:
                if payload['program_type'] == 'bss_agent':
                    day_night = -1
                else:
                    if 'day_night' not in payload:
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Payload data error.',
                        }))
                        return
                    day_night = 0 if payload['day_night'] == 'day' else 1
                p = sc.query(Programs).join(ProgramTypes).filter(
                    Programs.version == payload['program_version'],
                    ProgramTypes.name == payload['program_type']
                ).first()
                if not p:
                    self.write(json.dumps({
                        'code': 400,
                        'error': 'Program version not found.',
                    }))
                    return
                program_id = p.id
                host = payload['server']
                deploy_path = payload['deploy_path']
                if payload['program_type'] == 'shannon_quote':
                    if not sc.query(PreQuoteConfs).join(Servers).filter(
                            Servers.ip == host,
                            PreQuoteConfs.deploy_path == deploy_path,
                            PreQuoteConfs.valid == True,
                    ).first():
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Deploy path not pre-config.'
                        }))
                        return
                elif payload['program_type'] == 'shannon_tunnel':
                    if not sc.query(PreTunnelConfs).join(Servers).filter(
                            Servers.ip == host,
                            PreTunnelConfs.deploy_path == deploy_path,
                            PreTunnelConfs.valid == True,
                    ).first():
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Deploy path not pre-config.'
                        }))
                        return
                elif payload['program_type'] == 'bss_agent':
                    if not sc.query(PreAgentConfs).join(Servers).filter(
                            Servers.ip == host,
                            PreAgentConfs.deploy_path == deploy_path,
                            PreAgentConfs.valid == True,
                    ).first():
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Deploy path not pre-config.'
                        }))
                        return
                elif payload['program_type'] == 'platform_quote_server':
                    if not sc.query(PreForwarderConfs).join(Servers).filter(
                            Servers.ip == host,
                            PreForwarderConfs.valid == True,
                            PreForwarderConfs.deploy_path == deploy_path,
                    ).first():
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Deploy path not pre-config.'
                        }))
                        return
                else:
                    if not sc.query(PreTraderConfs).join(Servers).filter(
                            Servers.ip == host,
                            PreTraderConfs.deploy_path == deploy_path,
                            PreTraderConfs.valid == True,
                    ).first():
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Deploy path not pre-config.'
                        }))
                        return

                data = {
                    'host': host,
                    'deploy_path': deploy_path,
                    'program_id': program_id,
                    'day_night': day_night,
                }
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
                tornado.ioloop.IOLoop.instance().add_callback(
                    self.async_upload_bfile,
                    host=host,
                    deploy_path=deploy_path,
                    program_id=program_id,
                    day_night=day_night,
                )
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    @run_on_executor
    def async_upload_bfile(self, host, deploy_path, program_id, day_night):
        l_user = config.local['user']
        if host.rsplit('.', 1)[0] == '192.168.30':
            l_host = config.local['vpn']
        elif host.rsplit('.', 1)[0] == '10.10.40':
            l_host = config.local['tun']
        elif host.rsplit('.', 1)[0] == '192.168.40':
            l_host = config.local['szvpn']
        else:
            l_host = config.local['host']
        try:
            with mysql_sc() as sc:
                p = sc.query(Programs).filter_by(id=program_id).first()
                pt = sc.query(ProgramTypes).filter_by(id=p.type_id).first()
                _type = 0
                p_dpl = False
                st_dpl = False
                if pt.name == 'shannon_trader':
                    _type = 3
                elif pt.name == 'shannon_tools':
                    _type = 4
                elif pt.name == 'shannon_quote':
                    _type = 5
                if sc.query(self.model).filter(
                        self.model.host == host,
                        self.model.deploy_path == deploy_path,
                ).first():
                    p_dpl = True
                if sc.query(DeployStrategies).filter(
                        DeployStrategies.host == host,
                        DeployStrategies.deploy_path == deploy_path,
                ).first():
                    st_dpl = True
                res = upload_bfile(l_user, l_host, host, deploy_path, p.filepath,
                                   type=_type, p_dpl=p_dpl, st_dpl=st_dpl)

                if _type == 4 and p.name.startswith("shannon_tools"):  # tools upload trade list so
                    ol_obj = sc.query(Programs).join(ProgramTypes).filter(
                        ProgramTypes.name == 'trade_list',
                    ).order_by(Programs.id.desc()).first()
                    if not ol_obj:
                        res = False
                    else:
                        so_file = ol_obj.filepath
                        so_name = 'clear_stock.so'
                        os.system('cp -f %s %s' % (os.path.join(config.platform['media'], so_file),
                                                   os.path.join(os.path.dirname(os.path.realpath(__file__)), 'files',
                                                                so_name)))
                        so_fullpath = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'files', so_name)
                        res = upload_python_strategy(l_user, l_host, host, deploy_path, so_fullpath)

                    cf_obj = sc.query(Programs).join(ProgramTypes).filter(
                        ProgramTypes.name == 'clear_future',
                    ).order_by(Programs.id.desc()).first()
                    if not cf_obj:
                        res = False
                    else:
                        so_file = cf_obj.filepath
                        so_name = 'clear_future.so'
                        os.system('cp -f %s %s' % (os.path.join(config.platform['media'], so_file),
                                                   os.path.join(os.path.dirname(os.path.realpath(__file__)), 'files',
                                                                so_name)))
                        so_fullpath = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'files', so_name)
                        res = upload_python_strategy(l_user, l_host, host, deploy_path, so_fullpath)

                o = sc.query(self.model).filter(
                    self.model.host == host,
                    self.model.deploy_path == deploy_path,
                    self.model.program_id == program_id,
                ).order_by(self.model.id.desc()).first()
                o.result = 1 if res else 2
                if res:
                    if pt.name == 'bss_agent':
                        querys = sc.query(DeployConfs).filter(
                            DeployConfs.host == host,
                            DeployConfs.deploy_path == deploy_path,
                            DeployConfs.program_type_id == pt.id,
                            DeployConfs.day_night == 1,
                        )
                        if querys.first():
                            o = querys.first()
                            o.result = 1
                            o.valid = True
                        else:
                            data = {
                                'host': host,
                                'deploy_path': deploy_path,
                                'result': 1,
                                'status': 2,
                                'program_type_id': pt.id,
                                'day_night': -1,
                                'valid': True,
                            }
                            o = DeployConfs(**data)
                            sc.add(o)
                        self.register_agent_event(host)
                    elif pt.name == 'shannon_quote' or pt.name == 'shannon_tunnel' or pt.name == 'platform_quote_server':
                        querys = sc.query(DeployConfs).filter(
                            DeployConfs.host == host,
                            DeployConfs.deploy_path == deploy_path,
                            DeployConfs.program_type_id == pt.id,
                            DeployConfs.day_night == day_night,
                        )
                        if querys.first():
                            o = querys.first()
                        else:
                            data = {
                                'host': host,
                                'deploy_path': deploy_path,
                                'program_type_id': pt.id,
                                'day_night': day_night,
                                'valid': True if pt.name == 'platform_quote_server' else False,
                            }
                            o = DeployConfs(**data)
                            sc.add(o)
                        sc.commit()
                        self.register_process_event(host, o.id)

        except Exception as e:
            logger.error(str(e))
            raise e

    def register_agent_event(self, host):
        headers = {
            'content-type': 'application/json',
            'whitelist': 'operater',
        }
        data = {
            'type': 'host',
            'host': host,
        }
        req_url = 'http://127.0.0.1/api/v1/event_handle/deploy_reg_handle'
        http_client = tornado.httpclient.HTTPClient()
        response = http_client.fetch(
            req_url,
            method='POST',
            headers=headers,
            body=json.dumps(data),
        )
        logger.info('Register agent: resp=%s' % response.body)

    def register_process_event(self, host, process_id):
        headers = {
            'content-type': 'application/json',
            'whitelist': 'operater',
        }
        data = {
            'type': 'process',
            'host': host,
            'process_id': process_id,
        }
        req_url = 'http://127.0.0.1/api/v1/event_handle/deploy_reg_handle'
        http_client = tornado.httpclient.HTTPClient()
        response = http_client.fetch(
            req_url,
            method='POST',
            headers=headers,
            body=json.dumps(data),
        )
        logger.info('Register process: resp=%s' % response.body)


class DeployProgramsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = DeployPrograms

    def put(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def delete(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))


class DeployStrategiesList(ListHandler):
    executor = ThreadPoolExecutor(2)

    def initialize(self, *args, **kwargs):
        self.model = DeployStrategies

    @gen.coroutine
    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if ('server' not in payload) or \
                ('vstrategy_id' not in payload) or \
                ('deploy_path' not in payload) or \
                ('day_night' not in payload):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        logger.info(
            "DeployStrategiesList... strategies:[%s], day_night:[%s]" % (payload['vstrategy_id'], payload['day_night']))
        try:
            task_id = -1
            day_night = 0 if payload['day_night'] == 'day' else 1
            for vstrategy_id in payload['vstrategy_id']:
                with mysql_sc() as sc:
                    if not sc.query(PreTraderConfs).join(Servers).filter(
                            Servers.ip == payload['server'],
                            PreTraderConfs.deploy_path == payload['deploy_path'],
                            PreTraderConfs.valid == True,
                    ).first():
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Deploy path not pre-config.'
                        }))
                        return
                    data = {
                        'host': payload['server'],
                        'deploy_path': payload['deploy_path'],
                        'vstrategy_id': vstrategy_id,
                        'day_night': day_night,
                    }
                    o = self.model(**data)
                    sc.add(o)
                    sc.commit()
                    if task_id == -1:
                        task_id = o.id
                    o.task_id = task_id
            if task_id == -1:
                self.write(json.dumps({
                    'code': 500,
                    'error': 'Payload vstrategy_id cannot be null.',
                }))
                return
            self.write(json.dumps({
                'code': 0,
                'data': {
                    'id': task_id,
                    'result': 0,
                },
            }))
            tornado.ioloop.IOLoop.instance().add_callback(
                self.async_upload_bfile,
                host=payload['server'],
                deploy_path=payload['deploy_path'],
                vstrategy_ids=payload['vstrategy_id'],
                day_night=day_night,
                task_id=task_id,
            )
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    @run_on_executor
    def async_upload_bfile(self, host, deploy_path, vstrategy_ids, day_night, task_id):
        l_user = config.local['user']
        if host.rsplit('.', 1)[0] == '192.168.30':
            l_host = config.local['vpn']
        elif host.rsplit('.', 1)[0] == '10.10.40':
            l_host = config.local['tun']
        elif host.rsplit('.', 1)[0] == '192.168.40':
            l_host = config.local['szvpn']
        else:
            l_host = config.local['host']
        result = 1
        temp_dir = "temp_files"
        try:
            with mysql_sc() as sc:
                so_list = []
                ev_list = []
                for vstrategy_id in vstrategy_ids:
                    p = sc.query(VStrategies).filter_by(id=vstrategy_id).first()
                    if p.source == 'dim':
                        s = sc.query(Strategies).filter_by(id=p.strategy_id).first()
                        so_list.append(os.path.basename(s.filepath))
                        ev_list.extend(os.path.basename(s.ev_file))
                    elif p.source == 'platform':
                        trading_date = KdbQuery().get_trading_date_now().replace('-', '')
                        d = p.get_platform_data(trading_date, day_night)
                        if not d:
                            result = 2
                            continue
                        if d['strategy_type'] == 'order_list':
                            ol_obj = sc.query(Programs).join(ProgramTypes).filter(
                                ProgramTypes.name == 'trade_list',
                            ).order_by(Programs.id.desc()).first()
                            so_file = ol_obj.filepath
                        else:
                            so_file = d['so_file']
                        so_name = d['name'] + '.so'
                        ev_files = d['ev_files']
                        ret = os.system('cp "%s" "%s"' % (os.path.join(config.platform['media'], so_file),
                                                          os.path.join(os.path.dirname(os.path.realpath(__file__)),
                                                                       temp_dir, so_name)))
                        if ret != 0:
                            result = 2
                            continue
                        so_fullpath = os.path.join(os.path.dirname(os.path.realpath(__file__)), temp_dir, so_name)
                        if is_python_strategy(so_fullpath) or d['strategy_type'] == 'order_list':
                            if not upload_python_strategy(l_user, l_host, host, deploy_path, so_fullpath,
                                                          vid=vstrategy_id):
                                result = 2
                        else:
                            so_list.append(so_name)
                        # for ev_file in ev_files:
                        #    ev_file = ev_file.replace('/home/rss/bss_server/site/media/', '')
                        #    ret = os.system('cp "%s" "%s"' % (os.path.join(config.platform['media'], ev_file),
                        #                                      os.path.join(os.path.dirname(os.path.realpath(__file__)),
                        #                                                   temp_dir)))
                        #    if ret != 0:
                        #        result = 2
                        #        continue
                        #    ev_list.append(os.path.basename(ev_file))

                if so_list and result == 1:
                    if not compress_package(
                            os.path.join(os.path.dirname(os.path.realpath(__file__)), temp_dir),
                            'so_%s.tar.gz' % task_id, so_list
                    ):
                        result = 2
                    if not upload_bfile(
                            l_user, l_host, host, deploy_path,
                            os.path.join(os.path.dirname(os.path.realpath(__file__)),
                                         temp_dir, 'so_%s.tar.gz' % task_id), type=1
                    ):
                        result = 2
                # if ev_list and result == 1:
                #    if not compress_package(
                #            os.path.join(os.path.dirname(os.path.realpath(__file__)), temp_dir),
                #            'ev_%s.tar.gz' % task_id, ev_list
                #    ):
                #        result = 2
                #    if not upload_bfile(
                #            l_user, l_host, host, "/home/mycapitaltrade",
                #            os.path.join(os.path.dirname(os.path.realpath(__file__)),
                #                         temp_dir, 'ev_%s.tar.gz' % task_id), type=2
                #    ):
                #        result = 2

                pt = sc.query(ProgramTypes).filter_by(name='shannon_trader').first()
                for vstrategy_id in vstrategy_ids:
                    o = sc.query(self.model).filter(
                        self.model.host == host,
                        self.model.deploy_path == deploy_path,
                        self.model.vstrategy_id == vstrategy_id,
                    ).order_by(self.model.id.desc()).first()
                    o.result = result
                    querys = sc.query(DeployConfs).filter(
                        DeployConfs.host == host,
                        DeployConfs.deploy_path == deploy_path,
                        DeployConfs.vstrategy_id == vstrategy_id,
                        DeployConfs.day_night == day_night,
                        DeployConfs.program_type_id == pt.id,
                    )
                    if querys.first():
                        o = querys.first()
                    else:
                        data = {
                            'host': host,
                            'deploy_path': deploy_path,
                            'day_night': day_night,
                            'vstrategy_id': vstrategy_id,
                            'program_type_id': pt.id,
                            'valid': True,
                        }
                        o = DeployConfs(**data)
                        sc.add(o)
                    sc.commit()
                    rsp = register_process_event(host, o.id)
                    logger.info('Register process: resp=%s' % rsp)

        except Exception as e:
            logger.error(str(e))
            raise e


class DeployStrategiesDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = DeployStrategies

    def put(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def delete(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))


class DeployProgramConfsListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = DeployConfs

    @gen.coroutine
    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if ('server' not in payload) or (not payload['server']) or \
                ('program_type' not in payload) or (not payload['program_type']) or \
                ('xml' not in payload) or (not payload['xml']) or \
                ('day_night' not in payload) or (not payload['day_night']) or \
                ('deploy_path' not in payload) or (not payload['deploy_path']):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            host = payload['server']
            deploy_path = payload['deploy_path']
            content = payload['xml']
            day_night = 0 if payload['day_night'] == 'day' else 1
            program_type = payload['program_type']
            with mysql_sc() as sc:
                '''
                if not sc.query(DeployPrograms).filter(
                    DeployPrograms.host == host,
                    DeployPrograms.deploy_path == deploy_path,
                    DeployPrograms.day_night == day_night,
                ).first():
                    self.write(json.dumps({
                        'code': 500,
                        'error': 'Process not deployed.'
                    }))
                    return
                pt = sc.query(ProgramTypes).filter_by(name=program_type).first()
                o = sc.query(self.model).filter(
                    self.model.host == host,
                    self.model.deploy_path == deploy_path,
                    self.model.program_type_id == pt.id,
                    self.model.day_night == day_night,
                ).first()
                '''
                o = sc.query(
                    self.model
                ).join(
                    ProgramTypes, ProgramTypes.id == self.model.program_type_id
                ).filter(
                    self.model.host == host,
                    self.model.deploy_path == deploy_path,
                    self.model.day_night == day_night,
                    ProgramTypes.name == program_type,
                ).first()
                if not o:
                    self.write(json.dumps({
                        'code': 500,
                        'error': 'Process not deployed.'
                    }))
                    return
                else:
                    o.content = content
                    o.result = 1
                    o.status = 1
                    o.valid = True
                    sc.commit()
                    self.write(json.dumps({
                        'code': 0,
                        'data': o.to_dict(),
                    }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class DeployStrategyConfsListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = DeployConfs

    @gen.coroutine
    def post(self, *args, **kwargs):
        start_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if ('server' not in payload) or (not payload['server']) or \
                ('vstrategy_id' not in payload) or (not payload['vstrategy_id']) or \
                ('xml' not in payload) or (not payload['xml']) or \
                ('deploy_path' not in payload) or (not payload['deploy_path']) or \
                ('day_night' not in payload) or (not payload['day_night']):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        if len(payload['vstrategy_id']) != len(payload['xml']):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        logger.info('Rcv conf of vstrategy %s at %s', payload['vstrategy_id'], start_time)
        try:
            host = payload['server']
            deploy_path = payload['deploy_path']
            day_night = 0 if payload['day_night'] == 'day' else 1
            out_data = {
                'id': [],
                'vstrategy_id': [],
                'result': [],
            }
            with mysql_sc() as sc:
                '''
                if not sc.query(DeployPrograms).filter(
                    DeployPrograms.host == host,
                    DeployPrograms.deploy_path == deploy_path,
                    DeployPrograms.day_night == day_night,
                ).first():
                    logger.error('Not found a pre-deploy record that host=%s, deploy_path=%s, day_night=%d', host, deploy_path, day_night)
                    self.write(json.dumps({
                        'code': 500,
                        'error': 'Process not deployed.'
                    }))
                    return
                '''
                for vstrategy_id, content in zip(payload['vstrategy_id'], payload['xml']):
                    '''
                    pt = sc.query(ProgramTypes).filter_by(name='shannon_trader').first()
                    o = sc.query(self.model).filter(
                        self.model.host == host,
                        self.model.deploy_path == deploy_path,
                        self.model.vstrategy_id == vstrategy_id,
                        self.model.day_night == day_night,
                        self.model.program_type_id == pt.id,
                    ).first()
                    '''
                    o = sc.query(
                        self.model
                    ).join(
                        ProgramTypes, ProgramTypes.id == self.model.program_type_id
                    ).filter(
                        self.model.host == host,
                        self.model.deploy_path == deploy_path,
                        self.model.vstrategy_id == vstrategy_id,
                        self.model.day_night == day_night,
                        ProgramTypes.name == 'shannon_trader',
                    ).first()
                    if not o:
                        logger.error('Not found deploy info of vstrategy_id %d', vstrategy_id)
                        self.write(json.dumps({
                            'code': 500,
                            'error': 'Process not deployed.'
                        }))
                        return
                    else:
                        o.content = content
                        o.result = 1
                        o.status = 1
                        o.valid = True

                        vstrategy = sc.query(VStrategies).filter(VStrategies.id == vstrategy_id).first()
                        if not vstrategy:
                            self.write(json.dumps({
                                'code': 500,
                                'error': 'Not found vstrategy %d.' % vstrategy_id
                            }))
                            return

                        strategy_id = vstrategy.strategy_id
                        if vstrategy.status != 16:
                            if vstrategy.status != 15:
                                from notify import notify_wechat
                                strategy = sc.query(Strategy).filter(Strategy.id == strategy_id).first()
                                send_msg = "策略上线通知: 策略{name}(vs_id={vs_id}) host:{host}已上线".format(vs_id=vstrategy.id,
                                                                                                   name=strategy.name,
                                                                                                   host=o.host)
                                users = ["rice", "LiZhiBingsandy", "HuBo", "LiShaoFeng", "Feng"]
                                try:
                                    notify_wechat(users, send_msg)
                                except Exception as e:
                                    logger.error(e)
                                else:
                                    logger.info(send_msg)

                            vstrategy.status = 15
                            portfolio_id = vstrategy.portfolio_id
                            sc.query(StrategyPortfolio).filter(
                                StrategyPortfolio.id == portfolio_id,
                            ).update(
                                {StrategyPortfolio.status: 15}
                            )
                        sc.commit()
                        logger.info('update conf of process %d, vstrategy_id %d', o.id, o.vstrategy_id)

                        out_data['id'].append(o.id)
                        out_data['vstrategy_id'].append(o.vstrategy_id)
                        out_data['result'].append(o.result)

                        RedisCache().set_hash_cache(config.redis['conf_update_timestamp'], o.id,
                                                    datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f'))
                        logger.info('set conf cache of process %d', o.id)

                self.write(json.dumps({
                    'code': 0,
                    'data': out_data,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class DeplyConfsInfoHandler(BaseHandler):
    """
    
    """
    executor = ThreadPoolExecutor(8)

    def initialize(self, *args, **kwargs):
        self.model = DeployConfs

    def get(self, *args, **kwargs):
        try:
            res = []
            host = self.get_argument('server', '')
            processid = self.get_argument('processid', None)
            logger.info('host=%s, processid=%s', host, processid)
            redis_helper = RedisHelper()
            agent_online = redis_helper.query_agent_online(host)
            processes_online = redis_helper.query_process_online(host)
            if host:
                logger.info('online status, %s agent:%s', host, agent_online)
            elif processid:
                logger.info('online status, process %s:%s', processid, processes_online.get(processid, 2))

            with mysql_sc() as sc:
                if host:
                    no_trader = sc.query(
                        DeployConfs.id, DeployConfs.host, DeployConfs.deploy_path,
                        DeployConfs.day_night, DeployConfs.result, DeployConfs.valid,
                        DeployConfs.vstrategy_id, DeployConfs.program_type_id,
                        ProgramTypes.name
                    ).join(
                        ProgramTypes, ProgramTypes.id == DeployConfs.program_type_id
                    ).filter(
                        DeployConfs.host == host,
                        DeployConfs.valid == True,
                        ProgramTypes.name != 'shannon_trader'
                    )
                    trader_data = sc.query(
                        DeployConfs.id, DeployConfs.host, DeployConfs.deploy_path,
                        DeployConfs.day_night, DeployConfs.result, DeployConfs.valid,
                        DeployConfs.vstrategy_id, DeployConfs.program_type_id,
                        ProgramTypes.name, Strategy.name.label("strategy_name"), Strategy.id.label(
                            'strategy_id'), VStrategies.status.label("vs_status"),
                        Strategy.strategy_type.label('strategy_type')
                    ).join(
                        ProgramTypes, ProgramTypes.id == DeployConfs.program_type_id
                    ).join(
                        VStrategies, VStrategies.id == DeployConfs.vstrategy_id
                    ).join(
                        Strategy, Strategy.id == VStrategies.strategy_id
                    ).filter(
                        DeployConfs.host == host,
                        DeployConfs.valid == True,
                        ProgramTypes.name == 'shannon_trader'
                    )
                elif processid:
                    no_trader = sc.query(
                        DeployConfs.id, DeployConfs.host, DeployConfs.deploy_path,
                        DeployConfs.day_night, DeployConfs.result, DeployConfs.valid,
                        DeployConfs.vstrategy_id, DeployConfs.program_type_id,
                        ProgramTypes.name
                    ).join(
                        ProgramTypes, ProgramTypes.id == DeployConfs.program_type_id
                    ).filter(
                        DeployConfs.id == int(processid),
                        DeployConfs.valid == True,
                        ProgramTypes.name != 'shannon_trader'
                    )
                    trader_data = sc.query(
                        DeployConfs.id, DeployConfs.host, DeployConfs.deploy_path,
                        DeployConfs.day_night, DeployConfs.result, DeployConfs.valid,
                        DeployConfs.vstrategy_id, DeployConfs.program_type_id,
                        ProgramTypes.name, Strategy.name.label("strategy_name"), Strategy.id.label('strategy_id'),
                        VStrategies.status.label("vs_status"), Strategy.strategy_type.label('strategy_type')
                    ).join(
                        ProgramTypes, ProgramTypes.id == DeployConfs.program_type_id
                    ).join(
                        VStrategies, VStrategies.id == DeployConfs.vstrategy_id
                    ).join(
                        Strategy, Strategy.id == VStrategies.strategy_id
                    ).filter(
                        DeployConfs.id == int(processid),
                        DeployConfs.valid == True,
                        ProgramTypes.name == 'shannon_trader'
                    )
                else:
                    # filter nothing get it all
                    no_trader = sc.query(
                        DeployConfs.id, DeployConfs.host, DeployConfs.deploy_path,
                        DeployConfs.day_night, DeployConfs.result, DeployConfs.valid,
                        DeployConfs.vstrategy_id, DeployConfs.program_type_id,
                        ProgramTypes.name
                    ).join(
                        ProgramTypes, ProgramTypes.id == DeployConfs.program_type_id
                    ).filter(
                        DeployConfs.valid == True,
                        ProgramTypes.name != 'shannon_trader'
                    )
                    trader_data = sc.query(
                        DeployConfs.id, DeployConfs.host, DeployConfs.deploy_path,
                        DeployConfs.day_night, DeployConfs.result, DeployConfs.valid,
                        DeployConfs.vstrategy_id, DeployConfs.program_type_id,
                        ProgramTypes.name, Strategy.name.label("strategy_name"), Strategy.id.label(
                            'strategy_id'), VStrategies.status.label("vs_status"),
                        Strategy.strategy_type.label('strategy_type')
                    ).join(
                        ProgramTypes, ProgramTypes.id == DeployConfs.program_type_id
                    ).join(
                        VStrategies, VStrategies.id == DeployConfs.vstrategy_id
                    ).join(
                        Strategy, Strategy.id == VStrategies.strategy_id
                    ).filter(
                        DeployConfs.valid == True,
                        ProgramTypes.name == 'shannon_trader'
                    )

                res += self.serialize_dc_data(sc, trader_data, "shannon_trader", agent_online, processes_online)
                res += self.serialize_dc_data(sc, no_trader, "no_trader", agent_online, processes_online)

            logger.info("total size of this deploy_confs query is {}".format(len(res)))
            if processid:
                logger.info(res)
            self.write(json.dumps({
                'code': 0,
                'data': res
            }))
        except Exception as err:
            self.write({
                'code': 500,
                'error': str(err)
            })
            logger.error("get process info of host=%s, processid=%s', error: %s",
                         host, processid, err, exc_info=True)

    def serialize_dc_data(self, sc, lines, data_type, agent_online, processes_online):
        results = []
        for line in lines:
            version = self.get_program_version(sc, line)
            data = {
                'id': line.id,
                'process_id': line.id,
                'host': line.host,
                'deploy_path': line.deploy_path,
                'day_night': line.day_night,
                'result': line.result,
                'valid': line.valid,
                'vstrategy_id': line.vstrategy_id if data_type == "shannon_trader" else '',
                'version': version,
                'process_type': line.name,  # process_type,
                'name': line.strategy_name if data_type == "shannon_trader" else '',
                'status': agent_online if line.name == 'bss_agent' else processes_online.get(line.id, 2)
            }
            results.append(data)
        return results

    def get_program_version(self, sc, line):
        _o = sc.query(Programs.version).join(
            DeployPrograms, Programs.id == DeployPrograms.program_id,
        ).filter(
            DeployPrograms.host == line.host,
            DeployPrograms.deploy_path == line.deploy_path,
            DeployPrograms.day_night == line.day_night,
        ).order_by(DeployPrograms.id.desc()).first()
        if not _o:
            version = ''
        else:
            version = _o.version
        return version


class DeployConfsListHandler(BaseHandler):
    """
    - 20200703
        To be deprecated.
    """
    executor = ThreadPoolExecutor(2)

    def initialize(self, *args, **kwargs):
        self.model = DeployConfs

    def get(self, *args, **kwargs):
        try:
            res = []
            host = self.get_argument('server', '')
            processid = self.get_argument('processid', None)
            logger.info('host=%s, processid=%s', host, processid)
            redis_helper = RedisHelper()
            agent_online = redis_helper.query_agent_online(host)
            processes_online = redis_helper.query_process_online(host)
            if host:
                logger.info('online status, %s agent:%s', host, agent_online)
            elif processid:
                logger.info('online status, process %s:%s', processid, processes_online.get(processid, 2))

            with mysql_sc() as sc:
                if host:
                    lines = sc.query(
                        DeployConfs.id, DeployConfs.host, DeployConfs.deploy_path,
                        DeployConfs.day_night, DeployConfs.result, DeployConfs.valid,
                        DeployConfs.vstrategy_id, DeployConfs.program_type_id,
                        ProgramTypes.name
                    ).join(
                        ProgramTypes, ProgramTypes.id == DeployConfs.program_type_id
                    ).filter(
                        DeployConfs.host == host,
                        DeployConfs.valid == True,
                    )
                elif processid:
                    lines = sc.query(
                        DeployConfs.id, DeployConfs.host, DeployConfs.deploy_path,
                        DeployConfs.day_night, DeployConfs.result, DeployConfs.valid,
                        DeployConfs.vstrategy_id, DeployConfs.program_type_id,
                        ProgramTypes.name
                    ).join(
                        ProgramTypes, ProgramTypes.id == DeployConfs.program_type_id
                    ).filter(
                        DeployConfs.id == int(processid),
                        DeployConfs.valid == True,
                    )
                else:
                    # filter nothing get it all
                    lines = sc.query(
                        DeployConfs.id, DeployConfs.host, DeployConfs.deploy_path,
                        DeployConfs.day_night, DeployConfs.result, DeployConfs.valid,
                        DeployConfs.vstrategy_id, DeployConfs.program_type_id,
                        ProgramTypes.name
                    ).join(
                        ProgramTypes, ProgramTypes.id == DeployConfs.program_type_id
                    ).filter(
                        DeployConfs.valid == True,
                    )

                vstra_id_list = []
                for line in lines:
                    _o = sc.query(Programs.version).join(
                        DeployPrograms, Programs.id == DeployPrograms.program_id,
                    ).filter(
                        DeployPrograms.host == line.host,
                        DeployPrograms.deploy_path == line.deploy_path,
                        DeployPrograms.day_night == line.day_night,
                    ).order_by(DeployPrograms.id.desc()).first()
                    if not _o:
                        version = ''
                    else:
                        version = _o.version

                    data = {
                        'id': line.id,
                        'process_id': line.id,
                        'host': line.host,
                        'deploy_path': line.deploy_path,
                        'day_night': line.day_night,
                        'result': line.result,
                        'valid': line.valid,
                        'vstrategy_id': line.vstrategy_id if line.vstrategy_id else '',
                        'version': version,
                        'process_type': line.name,  # process_type,
                    }

                    if data['process_type'] != 'bss_agent':
                        data['status'] = processes_online.get(data['process_id'], 2)
                    else:
                        data['status'] = agent_online
                    res.append(data)

                    if data['process_type'] == 'shannon_trader':
                        vstra_id_list.append(data['vstrategy_id'])

                logger.info('get strategy process info, vstra_id = %s', vstra_id_list)
                vstra_pre_conf_dict = {}
                pre_stra_confs = sc.query(
                    PreStrategyConfs
                ).filter(
                    PreStrategyConfs.vstrategy_id.in_(vstra_id_list)
                ).all()
                trading_date = KdbQuery().get_trading_date_now().replace('-', '')
                now_hour = datetime.datetime.now().hour
                if 6 <= now_hour < 19:
                    day_night = 0
                else:
                    day_night = 1
                for c in pre_stra_confs:
                    conf = c.to_dict(trading_date, day_night, source=1)
                    if 'err_msg' in conf.keys():
                        continue
                    else:
                        vstra_pre_conf_dict[conf['vstrategy']['vstrategy_id']] = {
                            'name': conf['vstrategy']['name'],
                            'ev_file': conf['vstrategy']['ev_file']
                        }
                for d in res:
                    if d['process_type'] == 'shannon_trader':
                        if d['vstrategy_id'] in vstra_pre_conf_dict:
                            d['name'] = vstra_pre_conf_dict[d['vstrategy_id']]['name']
                            d['ev_file'] = vstra_pre_conf_dict[d['vstrategy_id']]['ev_file']
                        else:
                            d['name'] = ''
                            d['ev_file'] = ''
            if processid:
                logger.info(res)
            self.write(json.dumps({
                'code': 0,
                'data': res
            }))
        except Exception as err:
            logger.error("get process info of host=%s, processid=%s', error: %s",
                         host, processid, err, exc_info=True)
            self.write({
                'code': 500,
                'error': str(err)
            })

    def is_digital_cash_strategy(self, sc, vstrategy_id):
        stra_info = sc.query(
            Strategy
        ).join(
            VStrategies, VStrategies.strategy_id == Strategy.id
        ).filter(
            VStrategies.id == vstrategy_id
        ).first()
        if stra_info and stra_info.strategy_type == '22':
            return True

        return False

    def __check_digital_currency(self, sc, vstrategy_id):
        v_obj = sc.query(VStrategies).filter(VStrategies.id == vstrategy_id).first()
        if v_obj:
            symbols_accounts = v_obj.symbols_accounts
            for item in symbols_accounts.get('day', []):
                exchange = item['exchange']
                if exchange in const.DIGICCY_EXCHANGE:
                    return True
            for item in symbols_accounts.get('night', []):
                exchange = item['exchange']
                if exchange in const.DIGICCY_EXCHANGE:
                    return True
        return False

    @gen.coroutine
    def post(self, *args, **kwargs):
        start_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        logger.info('Rcv request: %s at %s', payload, start_time)
        if ('cmd' not in payload) or \
                ('process_ids' not in payload):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        process_ids = payload['process_ids']
        is_agent = False
        try:
            tmp_list = []
            run_success = []
            config_success = []
            with mysql_sc() as sc:
                code = 0
                querys = sc.query(self.model).filter(self.model.id.in_(process_ids))
                for i, o in enumerate(querys.all()):
                    if payload['cmd'] == 0:
                        if o.valid == False:
                            logger.error('Process %d is invalid !', o.id)
                            code = 500
                            continue
                    logger.info('Process %d is valid !', o.id)
                    pt = sc.query(ProgramTypes).filter_by(id=o.program_type_id).first()
                    logger.info('Process %d is %s !', o.id, pt.name)
                    if pt.name == 'bss_agent':
                        o.status = payload['cmd']
                        host = o.host
                        deploy_path = o.deploy_path
                        tornado.ioloop.IOLoop.instance().add_callback(
                            self.async_run_agent,
                            host=host,
                            deploy_path=deploy_path,
                            cmd=payload['cmd'],
                        )
                        logger.info('Async run agent %d', o.id)
                        set_agent_open_close(config.redis, host, payload['cmd'])
                        is_agent = True
                        continue
                    _now = datetime.datetime.now()
                    seq = int(str(_now.second) + str(_now.microsecond))
                    # start process
                    if payload['cmd'] == 0:
                        if pt.name == 'shannon_trader':
                            if not self.is_digital_cash_strategy(sc, o.vstrategy_id):
                                if o.day_night == 0:
                                    config_start_time = datetime.datetime.now().strftime('%Y-%m-%d 06:00:00')
                                else:
                                    config_start_time = datetime.datetime.now().strftime('%Y-%m-%d 18:00:00')

                                config_record = RedisCache().get_hash_cache(config.redis['conf_update_timestamp'], o.id)
                                if not config_record:
                                    logger.error('Not found config of process %d', o.id)
                                    code = 501
                                    continue
                                if datetime.datetime.strptime(config_record, '%Y-%m-%d %H:%M:%S.%f') < \
                                        datetime.datetime.strptime(config_start_time, '%Y-%m-%d %H:%M:%S'):
                                    logger.error('The Config of process %d did not update', o.id)
                                    code = 502
                                    continue
                                logger.info('The config of process %d update at %s', o.id, config_record)
                        cmd = json.dumps({
                            'type': 1,
                            'data': {
                                'opt_type': payload['cmd'],
                                'process_id': o.id,
                                'path': os.path.join(o.deploy_path, 'run.sh'),
                            },
                            'seq': seq,
                        })
                    # stop process
                    elif payload['cmd'] == 2:
                        cmd = json.dumps({
                            'type': 1,
                            'data': {
                                'opt_type': payload['cmd'],
                                'process_id': o.id,
                            },
                            'seq': seq,
                        })
                    # 4 : pause a strategy; 5: cancel all pending orders of a strategy
                    elif payload['cmd'] == 4 or payload['cmd'] == 5:
                        if not o.vstrategy_id:
                            code = 503
                            logger.error('process %d is not a strategy.', o.id)
                            continue
                        pre_strategy_conf = sc.query(PreStrategyConfs).filter(
                            PreStrategyConfs.vstrategy_id == o.vstrategy_id,
                        ).order_by(PreStrategyConfs.id.desc()).first()
                        if not pre_strategy_conf:
                            code = 504
                            logger.error('Not found pre-strategy-config of process %d', o.id)
                            continue
                        if o.day_night == 0:
                            tunnel_path = pre_strategy_conf.day_tunnel_conf
                        elif o.day_night == 1:
                            tunnel_path = pre_strategy_conf.night_tunnel_conf
                        else:
                            code = 505
                            logger.error('Error day_night(%d) of process %d', o.day_night, o.id)
                            continue
                        tunnel_conf = sc.query(DeployConfs).join(
                            ProgramTypes, ProgramTypes.id == DeployConfs.program_type_id,
                        ).filter(
                            ProgramTypes.name == 'shannon_tunnel',
                            DeployConfs.host == o.host,
                            DeployConfs.deploy_path == tunnel_path,
                        ).order_by(DeployConfs.id.desc()).first()
                        if not tunnel_conf:
                            code = 506
                            logger.error('Not found tunnel deploy-config of strategy process %d', o.id)
                            continue
                        cmd = json.dumps({
                            'type': 1,
                            'data': {
                                'opt_type': payload['cmd'],
                                'process_id': tunnel_conf.id,
                                'v_st_id': o.vstrategy_id,
                            },
                            'seq': seq,
                        })
                    logger.info(cmd)
                    iphost = query_redis_iphost(config.redis, o.host)
                    if not iphost:
                        code = 507
                        logger.error('Not found host %s', o.host)
                        continue
                    if payload['cmd'] == 0:
                        clear_history_launch_msg(config.redis, iphost, o.id)
                        if pt.name == 'shannon_trader':
                            reset_stra_placeorder_status(config.redis, o.vstrategy_id)
                    if not rpush_redis_cmd(config.redis, iphost, cmd):
                        code = 508
                        logger.error('Failed to push cmd of process %d to redis', o.id)
                        continue
                    logger.info('Push cmd of process %d to redis', o.id)
                    tmp_list.append([i, seq, iphost, pt.name])
                    if payload['cmd'] == 0 and pt.name != 'bss_agent':
                        update_redis_process(config.redis, o.host, os.path.join(o.deploy_path, 'run.sh'), 1, o.id)
                    elif payload['cmd'] == 2 and pt.name != 'bss_agent':
                        update_redis_process(config.redis, o.host, os.path.join(o.deploy_path, 'run.sh'), 0, o.id)

            for _ in range(30):
                if len(tmp_list) == 0:
                    if is_agent:
                        code = 0
                    else:
                        code = 509
                    break
                if len(run_success) == len(tmp_list):
                    code = 0
                    break
                yield gen.sleep(1)
                with mysql_sc() as sc:
                    querys = sc.query(self.model).filter(self.model.id.in_(process_ids))
                    for tmp in tmp_list:
                        if tmp in run_success:
                            continue
                        o = querys.all()[tmp[0]]
                        seq = tmp[1]
                        iphost = tmp[2]
                        process_type = tmp[3]
                        rsp = lpop_redis_cmd(config.redis, iphost, seq)
                        if not rsp:
                            code = 510
                            continue
                        elif json.loads(str(rsp, 'utf-8'))['data']['return'] != 0:
                            code = 511
                            logger.error('Failed to exe the cmd of process %d', o.id)
                            continue
                        else:
                            code = 0
                            run_success.append(tmp)
                            logger.info('Succeed to exe the cmd of process %d', o.id)
                            if payload['cmd'] == 4 or payload['cmd'] == 5:
                                continue
                            o.status = payload['cmd']
                            sc.commit()
                            '''
                            pt = sc.query(ProgramTypes).filter(
                                ProgramTypes.id == o.program_type_id,
                            ).first()
                            '''
                            if payload['cmd'] == 0 and process_type != 'platform_quote_server':
                                _now = datetime.datetime.now()
                                seq = int(str(_now.second) + str(_now.microsecond))
                                tmp[1] = seq
                                # if iphost in ['192.168.10.120', '192.168.10.106', '192.168.10.108', '192.168.10.114',
                                #              '192.168.30.54', '10.10.40.1', '192.168.30.60', '192.168.30.61',
                                #              '192.168.40.59']:
                                conf = compress_conf(o.content)
                                cmd = json.dumps({
                                    'type': 1,
                                    'data': {
                                        'opt_type': 6,
                                        'process_id': o.id,
                                        'conf': conf,
                                    },
                                    'seq': seq,
                                })
                                # else:
                                #    cmd = json.dumps({
                                #        'type': 1,
                                #        'data': {
                                #            'opt_type': 1,
                                #            'process_id': o.id,
                                #            'conf': o.content,
                                #        },
                                #        'seq': seq,
                                #    })

                                if not rpush_redis_cmd(config.redis, iphost, cmd):
                                    logger.error('Failed to send the config of process %d', o.id)
                                    code = 512
                                    o.result = 2
                                    sc.commit()
                                else:
                                    logger.info('Send the config of process %d, seq: %d', o.id, seq)
            if payload['cmd'] == 0:
                for _ in range(15):
                    if len(tmp_list) == 0:
                        if is_agent:
                            code = 0
                        else:
                            code = 513
                        break
                    if len(config_success) == len(tmp_list):
                        code = 0
                        break
                    yield gen.sleep(1)
                    with mysql_sc() as sc:
                        querys = sc.query(self.model).filter(self.model.id.in_(process_ids))
                        for tmp in tmp_list:
                            if tmp in config_success:
                                continue
                            o = querys.all()[tmp[0]]
                            seq = tmp[1]
                            iphost = tmp[2]
                            process_type = tmp[3]
                            '''
                            pt = sc.query(ProgramTypes).filter(
                                ProgramTypes.id == o.program_type_id,
                            ).first()
                            '''
                            if process_type == 'platform_quote_server':
                                continue
                            rsp = lpop_redis_cmd(config.redis, iphost, seq)
                            if not rsp:
                                code = 514
                                o.result = 2
                                sc.commit()
                            elif json.loads(str(rsp, 'utf-8'))['data']['return'] != 0:
                                logger.error('Failed to start process %d', o.id)
                                code = 515
                                o.result = 2
                                sc.commit()
                            else:
                                logger.info('Succeed to start process %d', o.id)
                                config_success.append(tmp)
                                code = 0
                                o.result = 1
                                sc.commit()

                            if process_type == 'shannon_trader':
                                s = sc.query(VStrategies).filter(VStrategies.id == o.vstrategy_id).first()
                                if not s:
                                    logger.error("Not found vstrategy obj, vstrategy_id=%s", o.vstrategy_id)
                                else:
                                    record = {
                                        'strategy_id': s.strategy_id,
                                        'vstrategy_id': o.vstrategy_id,
                                        'host': o.host,
                                        'deploy_path': o.deploy_path,
                                        'day_night': o.day_night,
                                        'xml': '',
                                    }
                                    sc.add(StrategyLiveRunRecords(**record))
                                    sc.commit()

                            # pt = sc.query(ProgramTypes).filter_by(id=o.program_type_id).first()
                            if process_type == 'shannon_tunnel':
                                ptc_lists = sc.query(PreTunnelConfs).join(
                                    Servers, Servers.id == PreTunnelConfs.server_id,
                                ).filter(
                                    Servers.ip == o.host,
                                    PreTunnelConfs.deploy_path == o.deploy_path,
                                )
                                for ptc in ptc_lists:
                                    a_o = sc.query(Accounts).filter(
                                        Accounts.id == ptc.account_id,
                                    ).first()
                                    if not a_o:
                                        logger.error('Not found an account record that id = %d used by process %d',
                                                     ptc.account_id, o.id)
                                        continue
                                    account = a_o.name
                                    e_o = sc.query(Exchanges).join(
                                        ApiTypes, ApiTypes.exchange_id == Exchanges.id,
                                    ).join(
                                        ConfigTemplates, ConfigTemplates.api_type_id == ApiTypes.id,
                                    ).filter(
                                        ConfigTemplates.id == ptc.config_template_id,
                                    ).first()
                                    if not e_o:
                                        logger.error(
                                            'Not found a exchange record that config template id = %d used by process %d',
                                            ptc.config_template_id, o.id)
                                        continue

                                    pre_clear_url = 'http://127.0.0.1:13333/api/v1/speedquote/accountclear'
                                    logger.info('Clear history info of account %s used by process %d', account, o.id)
                                    ret_info = requests.post(pre_clear_url, data=json.dumps(
                                        {'account': account, 'operation': 'del', 'data_type': 'all'}))
                                    if ret_info.status_code == requests.codes.ok:
                                        logger.info('Succeed to post for process %d', o.id)
                                    else:
                                        logger.error('Failed to post for processs %d, status_code = %d', o.id,
                                                     ret_info.status_code)

                                    exchange_code = str(e_o.code)[0]
                                    exchg = {
                                        'A': 'SHFE',
                                        'B': 'DCE',
                                        'C': 'CZCE',
                                        'G': 'CFFEX',
                                        'D': 'SGE',
                                        '0': 'SSE',
                                        '1': 'SSE',
                                    }
                                    _now = datetime.datetime.now()
                                    seq = int(str(_now.second) + str(_now.microsecond))
                                    cmd = {
                                        'type': 2,
                                        'data': {
                                            "data_type": 0,
                                            "api_type": 0,
                                            "process_id": o.id,
                                            "exchg_code": exchg.get(str(exchange_code), 'SSE'),
                                            "account": account,
                                        },
                                        'seq': seq,
                                    }
                                    cmd['data']['data_type'] = 0  # funds
                                    logger.info('Send the cmd of querying the funds of account to process %d, seq: %d.',
                                                o.id, seq)
                                    rpush_redis_cmd(config.redis, iphost, json.dumps(cmd))

                                    cmd['data']['data_type'] = 1  # positions
                                    _now = datetime.datetime.now()
                                    seq = int(str(_now.second) + str(_now.microsecond))
                                    cmd['seq'] = seq
                                    logger.info(
                                        'Send the cmd of querying the positions of account to process %d, seq: %d.',
                                        o.id, seq)
                                    rpush_redis_cmd(config.redis, iphost, json.dumps(cmd))

            elif payload['cmd'] == 2:
                if len(run_success) != len(tmp_list):
                    for tmp in tmp_list:
                        if tmp in run_success:
                            continue
                        with mysql_sc() as sc:
                            querys = sc.query(self.model).filter(self.model.id.in_(process_ids))
                            o = querys.all()[tmp[0]]
                            seq = tmp[1]
                            iphost = tmp[2]
                            _now = datetime.datetime.now()
                            seq = int(str(_now.second) + str(_now.microsecond))
                            cmd = json.dumps({
                                'type': 1,
                                'data': {
                                    'opt_type': 3,
                                    'process_id': o.id,
                                    'path': os.path.join(o.deploy_path, 'task_kill.sh'),
                                },
                                'seq': seq,
                            })
                            if not rpush_redis_cmd(config.redis, iphost, cmd):
                                logger.error('Failed to send the cmd of killing the process %d by force.', o.id)
                                code = 516
                                continue
                            logger.info('Send the cmd of killing the process %d by force, seq: %d.', o.id, seq)
                            code = 0
                            o.status = 2
                            sc.commit()

            with mysql_sc() as sc:
                querys = sc.query(self.model).filter(self.model.id.in_(process_ids))
                out_data = [o.to_dict() for o in querys.all()]
                ret_data = {
                    'code': code,
                    'data': out_data,
                }
                logger.info(ret_data)
                self.write(json.dumps(ret_data))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    @run_on_executor
    def async_run_agent(self, host, deploy_path, cmd):
        run_agent_process(host, deploy_path, cmd)


class PreQuoteConfsListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.order_by = 'name desc'
        self.model = PreQuoteConfs
        self.fields = {
            'name': 'name',
            'deploy_path': 'deploy_path',
            'ip_addr': 'ip_addr',
            'port': 'port',
            'forwarder': 'forwarder',
            'valid': 'valid',
            'server_id': 'server_id',
            'config_template_id': 'config_template_id',
            'account_id': 'account_id',
        }

    def get(self, *args, **kwargs):
        res = []
        server_id = int(self.get_argument('server_id', '0'))
        with mysql_sc() as sc:
            if server_id:
                lines = sc.query(self.model).filter_by(server_id=server_id).order_by(self.order_by)
            else:
                lines = sc.query(self.model).order_by(self.order_by).all()
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            data = {}
            for k, v in self.fields.items():
                if v in payload:
                    data[k] = payload[v]
            with mysql_sc() as sc:
                # Any operation will set DeployConfs' valid flag to False
                server_host = sc.query(Servers).filter_by(id=payload['server_id']).first().ip
                rs = sc.query(DeployConfs).filter(
                    DeployConfs.host == server_host,
                    DeployConfs.deploy_path == payload['deploy_path'],
                )
                for r in rs:
                    r.valid = False
                    delete_redis_process(config.redis, r.host, r.id)
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class PreQuoteConfsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = PreQuoteConfs
        self.fields = {
            'name': 'name',
            'deploy_path': 'deploy_path',
            'ip_addr': 'ip_addr',
            'port': 'port',
            'forwarder': 'forwarder',
            'valid': 'valid',
            'server_id': 'server_id',
            'config_template_id': 'config_template_id',
            'account_id': 'account_id',
        }

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    for k, v in self.fields.items():
                        if v in payload:
                            if v == 'name' or getattr(o, k) == payload[v]:
                                continue
                            # Except name, any other field updating will set DeployConfs' valid to False
                            server_host = sc.query(Servers).filter_by(id=o.server_id).first().ip
                            rs = sc.query(DeployConfs).filter(
                                DeployConfs.host == server_host,
                                DeployConfs.deploy_path == o.deploy_path,
                            )
                            # TODO:检查下这个循环是否可以往上一层。
                            for r in rs:
                                r.valid = False
                                delete_redis_process(config.redis, r.host, r.id)
                            break
                    for k, v in self.fields.items():
                        if v in payload:
                            setattr(o, k, payload[v])
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                d = sc.query(self.model).filter_by(id=kwargs['id'])
                deploy_path = d.first().deploy_path
                if len(sc.query(self.model).filter_by(deploy_path=deploy_path).all()) == 1 and \
                        sc.query(PreStrategyConfs).filter(or_(
                            PreStrategyConfs.day_quote_conf == deploy_path,
                            PreStrategyConfs.night_quote_conf == deploy_path,
                            PreStrategyConfs.day_quote_conf.like(str(deploy_path) + ",%"),
                            PreStrategyConfs.day_quote_conf.like("%," + str(deploy_path)),
                            PreStrategyConfs.day_quote_conf.like("%," + str(deploy_path) + ",%"),
                            PreStrategyConfs.night_quote_conf.like(str(deploy_path) + ",%"),
                            PreStrategyConfs.night_quote_conf.like("%," + str(deploy_path)),
                            PreStrategyConfs.night_quote_conf.like("%," + str(deploy_path) + ",%"),
                        )).all():
                    self.write(json.dumps({
                        'code': 409,
                        'error': 'Cannot delete data',
                    }))
                    return
                # Set DeployConfs' valid False
                server_host = sc.query(Servers).filter_by(id=d.first().server_id).first().ip
                rs = sc.query(DeployConfs).filter(
                    DeployConfs.host == server_host,
                    DeployConfs.deploy_path == deploy_path,
                )
                for r in rs:
                    r.valid = False
                    delete_redis_process(config.redis, r.host, r.id)
                d.delete()
                self.write(json.dumps({
                    'code': 0,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class PreTunnelConfsListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = PreTunnelConfs
        self.fields = {
            'name': 'name',
            'deploy_path': 'deploy_path',
            'ip_addr': 'ip_addr',
            'port': 'port',
            'forwarder': 'forwarder',
            'valid': 'valid',
            'server_id': 'server_id',
            'config_template_id': 'config_template_id',
            'account_id': 'account_id',
        }

    def get(self, *args, **kwargs):
        res = []
        server_id = int(self.get_argument('server_id', '0'))
        with mysql_sc() as sc:
            if server_id:
                lines = sc.query(self.model).filter_by(server_id=server_id)
            else:
                lines = sc.query(self.model).all()
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            data = {}
            for k, v in self.fields.items():
                if v in payload:
                    data[k] = payload[v]
            with mysql_sc() as sc:
                # Any operation will set DeployConfs' valid False
                server_host = sc.query(Servers).filter_by(id=payload['server_id']).first().ip
                rs = sc.query(DeployConfs).filter(
                    DeployConfs.host == server_host,
                    DeployConfs.deploy_path == payload['deploy_path'],
                )
                for r in rs:
                    r.valid = False
                    delete_redis_process(config.redis, r.host, r.id)
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class PreTunnelConfsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = PreTunnelConfs
        self.fields = {
            'name': 'name',
            'deploy_path': 'deploy_path',
            'ip_addr': 'ip_addr',
            'port': 'port',
            'forwarder': 'forwarder',
            'valid': 'valid',
            'server_id': 'server_id',
            'config_template_id': 'config_template_id',
            'account_id': 'account_id',
        }

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    for k, v in self.fields.items():
                        if v in payload:
                            if v == 'name' or getattr(o, k) == payload[v]:
                                continue
                            # Except name, any field updated will set DeployConfs' valid False
                            server_host = sc.query(Servers).filter_by(id=o.server_id).first().ip
                            rs = sc.query(DeployConfs).filter(
                                DeployConfs.host == server_host,
                                DeployConfs.deploy_path == o.deploy_path,
                            )
                            for r in rs:
                                r.valid = False
                                delete_redis_process(config.redis, r.host, r.id)
                            break
                    for k, v in self.fields.items():
                        if v in payload:
                            setattr(o, k, payload[v])
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                d = sc.query(self.model).filter_by(id=kwargs['id'])
                deploy_path = d.first().deploy_path
                if len(sc.query(self.model).filter_by(deploy_path=deploy_path).all()) == 1 and \
                        sc.query(PreStrategyConfs).filter(or_(
                            PreStrategyConfs.day_tunnel_conf == deploy_path,
                            PreStrategyConfs.night_tunnel_conf == deploy_path
                        )).all():
                    self.write(json.dumps({
                        'code': 409,
                        'error': 'Cannot delete data',
                    }))
                    return
                # Set DeployConfs' valid False
                server_host = sc.query(Servers).filter_by(id=d.first().server_id).first().ip
                rs = sc.query(DeployConfs).filter(
                    DeployConfs.host == server_host,
                    DeployConfs.deploy_path == deploy_path,
                )
                for r in rs:
                    r.valid = False
                    delete_redis_process(config.redis, r.host, r.id)
                d.delete()
                self.write(json.dumps({
                    'code': 0,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class PreTraderConfsListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = PreTraderConfs
        self.fields = {
            'name': 'name',
            'deploy_path': 'deploy_path',
            'valid': 'valid',
            'server_id': 'server_id',
        }

    def get(self, *args, **kwargs):
        res = []
        server_id = int(self.get_argument('server_id', '0'))
        with mysql_sc() as sc:
            if server_id:
                lines = sc.query(self.model).filter_by(server_id=server_id)
            else:
                lines = sc.query(self.model).all()
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            data = {}
            for k, v in self.fields.items():
                if v in payload:
                    data[k] = payload[v]
            with mysql_sc() as sc:
                # Any operation will set DeployConfs' valid False
                server_host = sc.query(Servers).filter_by(id=payload['server_id']).first().ip
                rs = sc.query(DeployConfs).filter(
                    DeployConfs.host == server_host,
                    DeployConfs.deploy_path == payload['deploy_path'],
                )
                for r in rs:
                    r.valid = False
                    delete_redis_process(config.redis, r.host, r.id)
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class PreTraderConfsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = PreTraderConfs
        self.fields = {
            'name': 'name',
            'deploy_path': 'deploy_path',
            'valid': 'valid',
            'server_id': 'server_id',
        }

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    for k, v in self.fields.items():
                        if v in payload:
                            if v == 'name' or getattr(o, k) == payload[v]:
                                continue
                            # Except name, any field updated will set DeployConfs' valid False
                            server_host = sc.query(Servers).filter_by(id=o.server_id).first().ip
                            rs = sc.query(DeployConfs).filter(
                                DeployConfs.host == server_host,
                                DeployConfs.deploy_path == o.deploy_path,
                            )
                            for r in rs:
                                r.valid = False
                                delete_redis_process(config.redis, r.host, r.id)
                            break
                    for k, v in self.fields.items():
                        if v in payload:
                            setattr(o, k, payload[v])
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                d = sc.query(self.model).filter_by(id=kwargs['id'])
                deploy_path = d.first().deploy_path
                if len(sc.query(self.model).filter_by(deploy_path=deploy_path).all()) == 1 and \
                        sc.query(PreStrategyConfs).filter(or_(
                            PreStrategyConfs.day_trader_conf == deploy_path,
                            PreStrategyConfs.night_trader_conf == deploy_path
                        )).all():
                    self.write(json.dumps({
                        'code': 409,
                        'error': 'Cannot delete data',
                    }))
                    return
                # Set DeployConfs' valid False
                server_host = sc.query(Servers).filter_by(id=d.first().server_id).first().ip
                rs = sc.query(DeployConfs).filter(
                    DeployConfs.host == server_host,
                    DeployConfs.deploy_path == deploy_path,
                )
                for r in rs:
                    r.valid = False
                    delete_redis_process(config.redis, r.host, r.id)
                d.delete()
                self.write(json.dumps({
                    'code': 0,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class PreAgentConfsListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = PreAgentConfs
        self.fields = {
            'name': 'name',
            'deploy_path': 'deploy_path',
            'valid': 'valid',
            'server_id': 'server_id',
        }

    def get(self, *args, **kwargs):
        res = []
        server_id = int(self.get_argument('server_id', '0'))
        with mysql_sc() as sc:
            if server_id:
                lines = sc.query(self.model).filter_by(server_id=server_id)
            else:
                lines = sc.query(self.model).all()
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if sorted(payload.keys()) != sorted(self.fields.values()):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            data = {}
            for k, v in self.fields.items():
                data[k] = payload[v]
            with mysql_sc() as sc:
                if payload['valid'] == True:
                    if sc.query(self.model).filter(
                            self.model.server_id == payload['server_id'],
                            self.model.valid == True,
                    ).first():
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Only one available agent.'
                        }))
                        return
                # Any operation will set DeployConfs' valid False
                server_host = sc.query(Servers).filter_by(id=payload['server_id']).first().ip
                sc.query(DeployConfs).filter(
                    DeployConfs.host == server_host,
                    DeployConfs.deploy_path == payload['deploy_path'],
                ).update(
                    {DeployConfs.valid: False}
                )
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class PreAgentConfsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = PreAgentConfs
        self.fields = {
            'name': 'name',
            'deploy_path': 'deploy_path',
            'valid': 'valid',
            'server_id': 'server_id',
        }

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                if payload.get('valid', False) == True:
                    if sc.query(self.model).filter(
                            self.model.id != kwargs['id'],
                            self.model.server_id == payload['server_id'],
                            self.model.valid == True
                    ).first():
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Only one available agent.'
                        }))
                        return
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    for k, v in self.fields.items():
                        if v in payload:
                            if v == 'name' or getattr(o, k) == payload[v]:
                                continue
                            # Except name, any field updated will set DeployConfs' valid False
                            server_host = sc.query(Servers).filter_by(id=o.server_id).first().ip
                            sc.query(DeployConfs).filter(
                                DeployConfs.host == server_host,
                                DeployConfs.deploy_path == o.deploy_path,
                            ).update(
                                {DeployConfs.valid: False}
                            )
                            notify_monitor_module(config.redis, "host")
                            break
                    for k, v in self.fields.items():
                        if v in payload:
                            setattr(o, k, payload[v])
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                d = sc.query(self.model).filter_by(id=kwargs['id'])
                deploy_path = d.first().deploy_path
                server_host = sc.query(Servers).filter_by(id=d.first().server_id).first().ip
                sc.query(DeployConfs).filter(
                    DeployConfs.host == server_host,
                    DeployConfs.deploy_path == deploy_path,
                ).update(
                    {DeployConfs.valid: False}
                )
                d.delete()
                notify_monitor_module(config.redis, "host")
                self.write(json.dumps({
                    'code': 0,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class PreStrategyReConfsListHandler(BaseHandler):

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if 'ids' not in payload:
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        ids = payload['ids']
        try:
            with mysql_sc() as sc:
                for m_id in ids:
                    d = sc.query(PreStrategyConfs).filter_by(id=m_id)
                    if not d.first():
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Data not found.',
                        }))
                        return
                    vstrategy_id = d.first().vstrategy_id
                    server_host = sc.query(Servers).filter_by(id=d.first().server_id).first().ip
                    rs = sc.query(DeployConfs).filter(
                        or_(DeployConfs.deploy_path == d.first().day_trader_conf,
                            DeployConfs.deploy_path == d.first().night_trader_conf),
                        DeployConfs.host == server_host,
                        DeployConfs.vstrategy_id == vstrategy_id,
                    )
                    for r in rs:
                        r.valid = False
                        delete_redis_process(config.redis, r.host, r.id)
                    sc.query(VStrategies).filter(
                        VStrategies.id == vstrategy_id
                    ).update(
                        {VStrategies.status: 12}
                    )
                    d.delete()
                self.write(json.dumps({
                    'code': 0,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class PreStrategyConfsListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = PreStrategyConfs
        self.fields = {
            'server_id': 'server_id',
            'day_quote_conf': 'day_quote_conf',
            'day_tunnel_conf': 'day_tunnel_conf',
            'day_trader_conf': 'day_trader_conf',
            'night_quote_conf': 'night_quote_conf',
            'night_tunnel_conf': 'night_tunnel_conf',
            'night_trader_conf': 'night_trader_conf',
            'vstrategy_id': 'vstrategy_id',
            'process_num': 'process_num',
            'tcp_conf': 'tcp_conf'
        }

    def get(self, *args, **kwargs):
        try:
            res = []
            server_id = int(self.get_argument('server_id', '0'))
            source = int(self.get_argument('source', '1'))
            vstrategy_id = int(self.get_argument('vstrategy_id', 0))
            page = int(self.get_argument('page', 0))
            size = int(self.get_argument('size', 0))
            trading_date = self.get_argument('trading_date', None)
            daynight = self.get_argument('day_night', None)
            logger.info(
                'get PreStrategyConfsListHandler server_id=%s, source=%s, vstrategy_id=%d, trading_date=%s, day_night=%s',
                server_id, source, vstrategy_id, trading_date, daynight)
            if trading_date is None:
                trading_date = KdbQuery().get_trading_date_now().replace('-', '')
            # TODO:去掉这段内部判断的逻辑，如果daynigth is None,返回错误。
            if daynight is None:
                now_hour = datetime.datetime.now().hour
                if 6 <= now_hour < 19:
                    day_night = 0
                else:
                    day_night = 1
            else:
                day_night = int(daynight)
            with mysql_sc() as sc:
                lines = sc.query(self.model).join(
                    VStrategies, VStrategies.id == self.model.vstrategy_id,
                ).filter(
                    VStrategies.status != -1,
                    VStrategies.status != 16,
                )
                if server_id:
                    lines = lines.filter(self.model.server_id == server_id)
                if vstrategy_id:
                    lines = lines.filter(self.model.vstrategy_id == vstrategy_id)
                lines = lines.order_by(self.model.id.desc())
                total = lines.count()
                if size > 0:
                    lines = lines.offset(page * size).limit(size)
                for line in lines:
                    data = line.to_dict(trading_date, day_night, source=source)
                    if vstrategy_id == 0:
                        if 'err_msg' in data.keys():
                            continue
                        else:
                            res.append(data)
                    else:
                        if 'err_msg' in data.keys():
                            self.write({
                                'code': 500,
                                'error': data['err_msg']
                            })
                            return
                        else:
                            res.append(data)
            if vstrategy_id != 0:
                logger.info(res)
            self.write(json.dumps({
                'code': 0,
                'data': res,
                'total': total,
            }))
        except Exception as err:
            logger.error("get pre_strategy_conf of server_id=%s and vstrategy_id=%d, error: %s",
                         server_id, vstrategy_id, err, exc_info=True)
            self.write({
                'code': 500,
                'error': str(err)
            })

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        process_num = payload.get('process_num', 1)
        merge_vid = payload.get("merge_vstrategy", {}).get("vstrategy_id", None)
        tcp_conf = payload.get('tcp_conf', None)

        trading_date = KdbQuery().get_trading_date_now().replace('-', '')
        now_hour = datetime.datetime.now().hour
        if 6 <= now_hour < 19:
            day_night = 0
        else:
            day_night = 1

        try:
            with mysql_sc() as sc:
                day_quote_conf = payload['conf']['day']['quote_conf']
                day_tunnel_conf = payload['conf']['day']['tunnel_conf']
                day_trader_conf = payload['conf']['day']['trader_conf']
                night_quote_conf = payload['conf']['night']['quote_conf']
                night_tunnel_conf = payload['conf']['night']['tunnel_conf']
                night_trader_conf = payload['conf']['night']['trader_conf']
                # TODO: 简化判断逻辑
                if ((day_quote_conf or day_tunnel_conf or day_trader_conf) and \
                    not (day_quote_conf and day_tunnel_conf and day_trader_conf)) and \
                        ((night_quote_conf or night_tunnel_conf or night_trader_conf) and \
                         not (night_quote_conf and night_tunnel_conf and night_trader_conf)):
                    self.write(json.dumps({
                        'code': 417,
                        'error': 'Configuration cannot be null.',
                    }))
                    return
                # single create or update
                if 'vstrategy_id' in payload:
                    data = {
                        'server_id': payload['server_id'],
                        'vstrategy_id': payload['vstrategy_id'],
                        'day_quote_conf': day_quote_conf,
                        'day_tunnel_conf': day_tunnel_conf,
                        'day_trader_conf': day_trader_conf,
                        'night_quote_conf': night_quote_conf,
                        'night_tunnel_conf': night_tunnel_conf,
                        'night_trader_conf': night_trader_conf,
                        'process_num': process_num,
                    }
                    if tcp_conf is not None:
                        data['tcp_conf'] = tcp_conf
                    if merge_vid is not None:
                        data["merge_vstrategy_id"] = merge_vid
                    o = self.model(**data)
                    sc.add(o)
                    sc.commit()
                    sc.query(VStrategies).filter(
                        VStrategies.id == payload['vstrategy_id']
                    ).update(
                        {VStrategies.status: 13}
                    )
                    self.write(json.dumps({
                        'code': 0,
                        'data': o.to_dict(trading_date, day_night),
                    }))
                # Bulk create or update
                else:
                    objs = []
                    vstrategy_ids = payload.get('vstrategy_ids', [])
                    for vstrategy_id in vstrategy_ids:
                        o = sc.query(self.model).filter(
                            self.model.server_id == payload['server_id'],
                            self.model.vstrategy_id == vstrategy_id,
                        ).first()
                        if o:
                            # Set day or night DeployConfs' valid False
                            if o.day_quote_conf != day_quote_conf or \
                                    o.day_tunnel_conf != day_tunnel_conf or \
                                    o.day_trader_conf != day_trader_conf:
                                server_host = sc.query(Servers).filter_by(id=o.server_id).first().ip
                                rs = sc.query(DeployConfs).filter(
                                    DeployConfs.host == server_host,
                                    DeployConfs.vstrategy_id == vstrategy_id,
                                    DeployConfs.day_night == 0,
                                )
                                for r in rs:
                                    r.valid = False
                                    delete_redis_process(config.redis, r.host, r.id)
                            if o.night_quote_conf != night_quote_conf or \
                                    o.night_tunnel_conf != night_tunnel_conf or \
                                    o.night_trader_conf != night_trader_conf:
                                server_host = sc.query(Servers).filter_by(id=o.server_id).first().ip
                                rs = sc.query(DeployConfs).filter(
                                    DeployConfs.host == server_host,
                                    DeployConfs.vstrategy_id == vstrategy_id,
                                    DeployConfs.day_night == 1,
                                )
                                for r in rs:
                                    r.valid = False
                                    delete_redis_process(config.redis, r.host, r.id)
                            o.day_quote_conf = day_quote_conf
                            o.day_tunnel_conf = day_tunnel_conf
                            o.day_trader_conf = day_trader_conf
                            o.night_quote_conf = night_quote_conf
                            o.night_tunnel_conf = night_tunnel_conf
                            o.night_trader_conf = night_trader_conf
                            o.process_num = process_num
                            if tcp_conf is not None:
                                o.tcp_conf = tcp_conf
                            if merge_vid is not None:
                                o.merge_vstrategy_id = merge_vid
                            objs.append(o)
                        else:
                            data = {
                                'server_id': payload['server_id'],
                                'vstrategy_id': vstrategy_id,
                                'day_quote_conf': day_quote_conf,
                                'day_tunnel_conf': day_tunnel_conf,
                                'day_trader_conf': day_trader_conf,
                                'night_quote_conf': night_quote_conf,
                                'night_tunnel_conf': night_tunnel_conf,
                                'night_trader_conf': night_trader_conf,
                                'process_num': process_num,
                            }
                            if tcp_conf is not None:
                                data['tcp_conf'] = tcp_conf
                            if merge_vid is not None:
                                data["merge_vstrategy_id"] = merge_vid
                            r = self.model(**data)
                            sc.add(r)
                            sc.query(VStrategies).filter(
                                VStrategies.id == vstrategy_id
                            ).update(
                                {VStrategies.status: 13}
                            )
                            objs.append(r)
                        sc.commit()
                    self.write(json.dumps({
                        'code': 0,
                        'data': [o.to_dict(trading_date, day_night) for o in objs],
                    }))

        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        ids = payload.get('ids', [])
        if not ids:
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            with mysql_sc() as sc:
                for m_id in ids:
                    d = sc.query(self.model).filter_by(id=m_id)
                    vstrategy_id = d.first().vstrategy_id
                    server_host = sc.query(Servers).filter_by(id=d.first().server_id).first().ip
                    rs = sc.query(DeployConfs).filter(
                        or_(DeployConfs.deploy_path == d.first().day_trader_conf,
                            DeployConfs.deploy_path == d.first().night_trader_conf),
                        DeployConfs.host == server_host,
                        DeployConfs.vstrategy_id == vstrategy_id,
                    )
                    for r in rs:
                        r.valid = False
                        delete_redis_process(config.redis, r.host, r.id)
                    vstrategy = sc.query(VStrategies).filter(VStrategies.id == vstrategy_id).first()
                    if vstrategy:
                        vstrategy.status = 16
                        portfolio_id = vstrategy.portfolio_id
                        vstrategy_list = sc.query(VStrategies).filter(
                            VStrategies.portfolio_id == portfolio_id
                        )
                        if all([_v.status == 16 for _v in vstrategy_list]):
                            sc.query(StrategyPortfolio).filter(
                                StrategyPortfolio.id == portfolio_id,
                            ).update(
                                {StrategyPortfolio.status: 16}
                            )
                    d.delete()
                self.write(json.dumps({
                    'code': 0,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class PreStrategyConfsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = PreStrategyConfs
        self.fields = {
            'server_id': 'server_id',
            'day_quote_conf': 'day_quote_conf',
            'day_tunnel_conf': 'day_tunnel_conf',
            'day_trader_conf': 'day_trader_conf',
            'night_quote_conf': 'night_quote_conf',
            'night_tunnel_conf': 'night_tunnel_conf',
            'night_trader_conf': 'night_trader_conf',
            'process_num': 'process_num',
            'tcp_conf': 'tcp_conf'
        }

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        process_num = payload.get('process_num', 1)
        merge_vid = payload.get("merge_vstrategy", {}).get("vstrategy_id", None)
        tcp_conf = payload.get('tcp_conf', None)

        trading_date = KdbQuery().get_trading_date_now().replace('-', '')
        now_hour = datetime.datetime.now().hour
        if 6 <= now_hour < 19:
            day_night = 0
        else:
            day_night = 1

        try:
            with mysql_sc() as sc:
                day_quote_conf = payload['conf']['day']['quote_conf']
                day_tunnel_conf = payload['conf']['day']['tunnel_conf']
                day_trader_conf = payload['conf']['day']['trader_conf']
                night_quote_conf = payload['conf']['night']['quote_conf']
                night_tunnel_conf = payload['conf']['night']['tunnel_conf']
                night_trader_conf = payload['conf']['night']['trader_conf']

                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    if day_quote_conf and day_tunnel_conf and day_trader_conf and \
                            (o.day_quote_conf != day_quote_conf) or \
                            (o.day_tunnel_conf != day_tunnel_conf) or \
                            (o.day_trader_conf != day_trader_conf):
                        server_host = sc.query(Servers).filter_by(id=o.server_id).first().ip
                        rs = sc.query(DeployConfs).filter(
                            DeployConfs.host == server_host,
                            DeployConfs.vstrategy_id == payload['vstrategy_id'],
                            DeployConfs.deploy_path == o.day_trader_conf,
                            DeployConfs.day_night == 0,
                        )
                        for r in rs:
                            r.valid = False
                            delete_redis_process(config.redis, r.host, r.id)
                    elif night_quote_conf and night_tunnel_conf and night_trader_conf and \
                            (o.night_quote_conf != night_quote_conf) or \
                            (o.night_tunnel_conf != night_tunnel_conf) or \
                            (o.night_trader_conf != night_trader_conf):
                        server_host = sc.query(Servers).filter_by(id=o.server_id).first().ip
                        rs = sc.query(DeployConfs).filter(
                            DeployConfs.host == server_host,
                            DeployConfs.vstrategy_id == payload['vstrategy_id'],
                            DeployConfs.deploy_path == o.night_trader_conf,
                            DeployConfs.day_night == 1,
                        )
                        for r in rs:
                            r.valid = False
                            delete_redis_process(config.redis, r.host, r.id)
                    o.day_quote_conf = day_quote_conf
                    o.day_tunnel_conf = day_tunnel_conf
                    o.day_trader_conf = day_trader_conf
                    o.night_quote_conf = night_quote_conf
                    o.night_tunnel_conf = night_tunnel_conf
                    o.night_trader_conf = night_trader_conf
                    o.process_num = process_num
                    if tcp_conf is not None:
                        o.tcp_conf = tcp_conf
                    if merge_vid is not None:
                        o.merge_vstrategy_id = merge_vid
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(trading_date, day_night),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                d = sc.query(self.model).filter_by(id=kwargs['id'])
                vstrategy_id = d.first().vstrategy_id
                server_host = sc.query(Servers).filter_by(id=d.first().server_id).first().ip
                rs = sc.query(DeployConfs).filter(
                    or_(DeployConfs.deploy_path == d.first().day_trader_conf,
                        DeployConfs.deploy_path == d.first().night_trader_conf),
                    DeployConfs.host == server_host,
                    DeployConfs.vstrategy_id == vstrategy_id,
                )
                for r in rs:
                    r.valid = False
                    delete_redis_process(config.redis, r.host, r.id)
                vstrategy = sc.query(VStrategies).filter(VStrategies.id == vstrategy_id).first()
                if vstrategy:
                    vstrategy.status = 16
                    portfolio_id = vstrategy.portfolio_id
                    vstrategy_list = sc.query(VStrategies).filter(
                        VStrategies.portfolio_id == portfolio_id
                    )
                    if all([_v.status == 16 for _v in vstrategy_list]):
                        sc.query(StrategyPortfolio).filter(
                            StrategyPortfolio.id == portfolio_id,
                        ).update(
                            {StrategyPortfolio.status: 16}
                        )
                d.delete()
                self.write(json.dumps({
                    'code': 0,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class PreForwarderConfsListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = PreForwarderConfs
        self.fields = {
            'name': 'name',
            'deploy_path': 'deploy_path',
            'valid': 'valid',
            'server_id': 'server_id',
        }

    def get(self, *args, **kwargs):
        res = []
        server_id = int(self.get_argument('server_id', '0'))
        with mysql_sc() as sc:
            if server_id > 0:
                lines = sc.query(self.model).filter(self.model.server_id == server_id)
            else:
                lines = sc.query(self.model)
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if sorted(payload.keys()) != sorted(self.fields.values()):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            data = {}
            for k, v in self.fields.items():
                data[k] = payload[v]
            with mysql_sc() as sc:
                if payload['valid']:
                    if sc.query(self.model).filter(
                            self.model.server_id == payload['server_id'],
                            self.model.valid == True,
                    ).first():
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Only one available agent.'
                        }))
                        return
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class PreForwarderConfsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = PreForwarderConfs
        self.fields = {
            'name': 'name',
            'deploy_path': 'deploy_path',
            'valid': 'valid',
            'server_id': 'server_id',
        }

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                if payload['valid']:
                    if sc.query(self.model).filter(
                            self.model.id != kwargs['id'],
                            self.model.server_id == payload['server_id'],
                            self.model.valid == True,
                    ).first():
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Only one available agent.'
                        }))
                        return
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    if payload['valid'] == False or \
                            payload['server_id'] != o.server_id or \
                            payload['deploy_path'] != o.deploy_path:
                        q = sc.query(DeployConfs).join(
                            Servers, Servers.ip == DeployConfs.host,
                        ).filter(
                            DeployConfs.deploy_path == o.deploy_path,
                            Servers.id == o.server_id,
                        ).first()
                        if q:
                            q.valid = False
                    for k, v in self.fields.items():
                        if v in payload:
                            setattr(o, k, payload[v])
                    sc.commit()
                    self.write(json.dumps({
                        'code': 0,
                        'data': o.to_dict(),
                    }))
                else:
                    self.write(json.dumps({
                        'code': 404,
                        'error': 'Data not found.',
                    }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                o = sc.query(DeployConfs).join(
                    Servers, Servers.ip == DeployConfs.host,
                ).join(self.model,
                       self.model.deploy_path == DeployConfs.deploy_path,
                       ).filter(
                    self.model.server_id == Servers.id,
                    self.model.id == kwargs['id'],
                ).order_by(self.model.id.desc()).first()
                if o:
                    o.valid = False
                sc.query(self.model).filter_by(id=kwargs['id']).delete()
                self.write(json.dumps({
                    'code': 0,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class QuoteAppIdHandler(BaseHandler):

    def get(self, *args, **kwargs):
        try:
            process_id = self.get_argument('process_id', None)
            if process_id is None:
                self.write(json.dumps({
                    'code': 1500,
                    'error': 'No param of process_id',
                }))
                return

            process_id = int(process_id)
            process = DeployConfs.get_process_by_id(process_id)
            if process is None:
                self.write(json.dumps({
                    'code': 1501,
                    'error': 'No found process_id {}'.format(process_id),
                }))
                return
            quote_conf = PreQuoteConfs.get_conf_by_path(process['host'], process['deploy_path'])
            if not quote_conf:
                self.write(json.dumps({
                    'code': 1502,
                    'error': 'No found pre-quote-conf of process_id {}'.format(process_id),
                }))
                return
            quote_app_id = [conf['config_template']['api_id'] for conf in quote_conf]
            stra_process_id, stra_transaction_quote = self.get_stra_process_id_by_quote(process['host'],
                                                                                        process['deploy_path'])
            logger.info(stra_transaction_quote)

            fake_quote_conf = PreQuoteConfs.get_fake_quote_conf_by_listen_socket(process['host'], quote_conf[0]['port'])
            for fake_quote in fake_quote_conf:
                fake_stra_process_id, fake_stra_transaction_quote = self.get_stra_process_id_by_quote(
                    fake_quote['server']['ip'], fake_quote['deploy_path'])
                logger.info(fake_stra_transaction_quote)
                stra_process_id.extend(fake_stra_process_id)
                stra_transaction_quote = {**stra_transaction_quote, **fake_stra_transaction_quote}

            self.write(json.dumps({
                'code': 0,
                'data': {
                    'quote_app_id': quote_app_id,
                    'stra_process_id': stra_process_id,
                    'tick_data': stra_transaction_quote
                }
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def get_stra_process_id_by_quote(self, host, deploy_path):
        stra_process_id = []
        stra_transaction_quote = {}
        stra_dict = PreStrategyConfs.quote_to_stra(host, deploy_path)
        for vid, stra in stra_dict.items():
            tq = VStrategies.get_transaction_quote(vid)

            if stra['day_trader_conf']:
                stra_process = DeployConfs.get_process_by_path_and_vstrategyid(host, stra['day_trader_conf'], vid)
                if stra_process:
                    stra_process_id.append(stra_process['process_id'])
                    if tq:
                        stra_transaction_quote[stra_process['process_id']] = tq
            if stra['night_trader_conf'] and stra['night_trader_conf'] != stra['day_trader_conf']:
                stra_process = DeployConfs.get_process_by_path_and_vstrategyid(host, stra['night_trader_conf'], vid)
                if stra_process:
                    stra_process_id.append(stra_process['process_id'])
                    if tq:
                        stra_transaction_quote[stra_process['process_id']] = tq

        return stra_process_id, stra_transaction_quote


class AccountInitCashListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = VStrategies
        self.no_login = ['get']

    def get(self, *args, **kwargs):
        data = {}
        vstrategy_ids = self.get_argument('vstrategy_ids').split(',')
        with mysql_sc() as sc:
            for vstrategy_id in vstrategy_ids:
                data[vstrategy_id] = []
                day_tmp = {}
                night_tmp = {}
                o = sc.query(self.model).filter_by(id=vstrategy_id).first()
                if o:
                    symbols_accounts = o.symbols_accounts
                    for item in symbols_accounts.get('day', []):
                        account = item['account']
                        amount = float(item['amount'])
                        if account not in day_tmp:
                            day_tmp[account] = amount
                        else:
                            day_tmp[account] += amount
                    for item in symbols_accounts.get('night', []):
                        account = item['account']
                        amount = float(item['amount'])
                        if account not in night_tmp:
                            night_tmp[account] = amount
                        else:
                            night_tmp[account] += amount
                    for k, v in day_tmp.items():
                        d = {
                            'account': k,
                            'cash': v,
                        }
                        data[vstrategy_id].append(d)
                    for k, v in night_tmp.items():
                        d = {
                            'account': k,
                            'cash': v,
                        }
                        if d not in data[vstrategy_id]:
                            data[vstrategy_id].append(d)

        self.write(json.dumps({
            'code': 0,
            'data': data,
        }))


class VStrategyLogsListHandler(BaseHandler):
    executor = ThreadPoolExecutor(4)

    @gen.coroutine
    def get(self, *args, **kwargs):
        vstrategy_id = int(self.get_argument('vstrategy_id'))
        day_night = int(self.get_argument('day_night'))
        logger.info('start to handle over strategy %d', vstrategy_id)
        try:
            close_status = False
            symbols_accounts = None
            with mysql_sc() as sc:
                vstrategy = sc.query(VStrategies).filter(VStrategies.id == vstrategy_id).first()
                if not vstrategy:
                    logger.error('Not found vstrategy %d', vstrategy_id)
                    self.write(json.dumps({
                        'code': 1404,
                        'error': 'Not found vstrategy {}'.format(vstrategy_id),
                    }))
                    return

                close_status = (vstrategy.closing_out == 17)
                symbols_accounts = vstrategy.symbols_accounts

            logger.info('get details of strategy %d', vstrategy_id)
            vstrategy_detail = yield self.query_settle_db(vstrategy_id)

            # query position
            logger.info('compute positions of strategy %d', vstrategy_id)
            position_data = {}
            for symbol, v in vstrategy_detail.get('data', {}).items():
                yd_long_pos = v['yest_long_pos']
                yd_long_avg_price = v['yest_long_avg_price']
                yd_short_pos = v['yest_short_pos']
                yd_short_avg_price = v['yest_short_avg_price']
                td_long_pos = v['today_long_pos']
                td_long_avg_price = v['today_long_avg_price']
                td_short_pos = v['today_short_pos']
                td_short_avg_price = v['today_short_avg_price']
                if td_long_pos == 0 and td_short_pos == 0:
                    continue
                if day_night == 0:
                    position_data[symbol] = {
                        'yd_long_pos': yd_long_pos,
                        'yd_long_avg_price': yd_long_avg_price,
                        'yd_short_pos': yd_short_pos,
                        'yd_short_avg_price': yd_short_avg_price,
                        'td_long_pos': td_long_pos - yd_long_pos,
                        'td_long_avg_price': td_long_avg_price,
                        'td_short_pos': td_short_pos - yd_short_pos,
                        'td_short_avg_price': td_short_avg_price,
                        'account': v['account'],
                        'exchange': v['exchange'],
                        'symbol_type': v['symbol_type'],
                    }
                else:
                    position_data[symbol] = {
                        'yd_long_pos': td_long_pos,
                        'yd_long_avg_price': td_long_avg_price,
                        'yd_short_pos': td_short_pos,
                        'yd_short_avg_price': td_short_avg_price,
                        'td_long_pos': 0,
                        'td_long_avg_price': 0,
                        'td_short_pos': 0,
                        'td_short_avg_price': 0,
                        'account': v['account'],
                        'exchange': v['exchange'],
                        'symbol_type': v['symbol_type'],
                    }

            # query account cash
            cash_data = {}
            cash_asset_data = {}
            rate_data = {}
            if day_night == 0:
                for item in symbols_accounts.get('day', []):
                    account = item['account']
                    amount = float(item['amount'])
                    if account not in cash_data:
                        cash_data[account] = amount
                        cash_asset_data[account] = amount
                        rate_data[account] = item.get('rate', 1)
                    else:
                        cash_data[account] += amount
                        cash_asset_data[account] += amount
            else:
                for item in symbols_accounts.get('night', []):
                    account = item['account']
                    amount = float(item['amount'])
                    if account not in cash_data:
                        cash_data[account] = amount
                        cash_asset_data[account] = amount
                        rate_data[account] = item.get('rate', 1)
                    else:
                        cash_data[account] += amount
                        cash_asset_data[account] += amount
            for account, v in vstrategy_detail.get('accounts', {}).items():
                rate_data[account] = v['forex_rate']
                if close_status:
                    cash_data[account] = -float(v['position_cash']) / float(v['forex_rate'])
                    cash_asset_data[account] = 0
                else:
                    cash_data[account] = float(v['cash']) / float(v['forex_rate'])
                    cash_asset_data[account] = float(v['asset_cash']) / float(v['forex_rate'])

            # query max order id
            if day_night == 0:
                max_order_id = 1000001
            elif day_night == 1:
                max_order_id = 1
            # logger.info('query max order id of strategy %d', vstrategy_id)
            # max_order_id = yield self.query_max_order_id(vstrategy_id, day_night)
            logger.info('max order id of strategy %d: %d', vstrategy_id, max_order_id)

            self.write(json.dumps({
                'code': 0,
                'data': {
                    'max_order_id': max_order_id,
                    'positions': position_data,
                    'cash': cash_data,
                    'cash_asset': cash_asset_data,
                    'rate': rate_data,
                }
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    @run_on_executor
    def query_max_order_id(self, vstrategy_id, day_night):
        max_order_id = 0
        trading_date = KdbQuery().get_trading_date_now().replace('-', '')
        with mysql_sc() as sc:
            o = sc.query(func.max(func.cast(TradeLogs.serial_no, BIGINT)).label('serial_no'),
                         func.max(func.cast(TradeLogs.cancel_serial_no, BIGINT)).label('cancel_serial_no')).filter(
                TradeLogs.vstrategy_id == vstrategy_id,
                TradeLogs.trading_date == trading_date,
            ).first()
            if o.serial_no:
                max_order_id = max([max_order_id, o.serial_no // (10 ** 10)])
            if o.cancel_serial_no:
                max_order_id = max([max_order_id, o.cancel_serial_no // (10 ** 10)])
        max_order_id += 1
        return max_order_id

    @run_on_executor
    def query_settle_db(self, vstrategy_id):
        res = {}
        with mysql_sc() as sc:
            o = sc.query(VSBase).filter(
                VSBase.vstrategy_id == vstrategy_id,
            ).order_by(
                VSBase.settle_date.desc(),
                VSBase.daynight.asc(),
            ).first()
            if o:
                settle_date = o.settle_date
                daynight = o.daynight
                res = {
                    'settle_date': settle_date.strftime('%Y-%m-%d'),
                    'daynight': daynight,
                    'cumulative_pnl': o.accumulated_pnl,
                    'cash': o.cash,
                    'available_cash': o.available_cash,
                    'asset_cash': o.asset_cash,
                    'data': {},
                    'accounts': {},
                }
                rows = sc.query(VSPositions).filter(
                    VSPositions.vstrategy_id == vstrategy_id,
                    VSPositions.settle_date == settle_date,
                    VSPositions.daynight == daynight,
                )
                for row in rows:
                    res['data'][row.symbol] = {
                        'yest_long_pos': row.yest_long_pos,
                        'yest_long_avg_price': row.yest_long_avg_price,
                        'yest_short_pos': row.yest_short_pos,
                        'yest_short_avg_price': row.yest_short_avg_price,
                        'today_long_pos': row.today_long_pos,
                        'today_long_avg_price': row.today_long_avg_price,
                        'today_short_pos': row.today_short_pos,
                        'today_short_avg_price': row.today_short_avg_price,
                        'account': row.account,
                        'exchange': row.exchange,
                        'symbol_type': row.symbol_type,
                    }
                rows = sc.query(VSAccounts).filter(
                    VSAccounts.vstrategy_id == vstrategy_id,
                    VSAccounts.settle_date == settle_date,
                    VSAccounts.daynight == daynight,
                )
                for row in rows:
                    res['accounts'][row.account] = {
                        'cash': float(row.cash),
                        'cumulative_pnl': float(row.accumulated_pnl),
                        'available_cash': float(row.available_cash),
                        'asset_cash': float(row.asset_cash),
                        'position_cash': float(row.position_cash),
                        'forex_rate': float(row.forex_rate),
                    }
        return res


class AccountLogsListHandler(BaseHandler):

    def get(self, *args, **kwargs):
        res = {
            'positions': {},
            'cash': {},
            'cumulative_pnl': {},
            'settle_date': '',
            'settle_daynight': '',
            'sum_cash': 0,
            'sum_cumulative_pnl': 0,
            'create_time': '',
        }
        account = self.get_argument('account', '')
        if not account:
            self.write(json.dumps({
                'code': 0,
                'data': {},
            }))
            return
        with mysql_sc() as sc:
            o = sc.query(VSAccounts.settle_date, VSAccounts.daynight, VSAccounts.ctime).filter(
                VSAccounts.account == account,
            ).order_by(
                VSAccounts.settle_date.desc(),
                VSAccounts.daynight.asc(),
            ).first()
            settle_date = o.settle_date
            daynight = o.daynight
            res['create_time'] = o.ctime.strftime('%Y-%m-%d %H:%M:%S')
            res['settle_date'] = settle_date.strftime('%Y-%m-%d')
            res['settle_daynight'] = daynight
            rows = sc.query(VSAccounts.cash, VSAccounts.accumulated_pnl, VSAccounts.vstrategy_id).filter(
                VSAccounts.account == account,
                VSAccounts.settle_date == settle_date,
                VSAccounts.daynight == daynight,
            )
            for row in rows:
                res['cash'][row.vstrategy_id] = row.cash
                res['cumulative_pnl'][row.vstrategy_id] = row.accumulated_pnl
                res['sum_cash'] += float(row.cash)
                res['sum_cumulative_pnl'] += float(row.accumulated_pnl)

            rows = sc.query(
                VSPositions.vstrategy_id, VSPositions.symbol, VSPositions.account,
                VSPositions.yest_long_pos, VSPositions.yest_long_avg_price,
                VSPositions.yest_short_pos, VSPositions.yest_short_avg_price,
                VSPositions.today_long_pos, VSPositions.today_long_avg_price,
                VSPositions.today_short_pos, VSPositions.today_short_avg_price,
            ).filter(
                VSPositions.account == account,
                VSPositions.settle_date == settle_date,
                VSPositions.daynight == daynight,
            )
            for row in rows:
                res['positions'].setdefault(row.vstrategy_id, {})
                res['positions'][row.vstrategy_id][row.symbol] = {
                    'yest_long_pos': row.yest_long_pos,
                    'yest_long_avg_price': row.yest_long_avg_price,
                    'yest_short_pos': row.yest_short_pos,
                    'yest_short_avg_price': row.yest_short_avg_price,
                    'today_long_pos': row.today_long_pos,
                    'today_long_avg_price': row.today_long_avg_price,
                    'today_short_pos': row.today_short_pos,
                    'today_short_avg_price': row.today_short_avg_price,
                    'account': row.account,
                }
        self.write(json.dumps({
            'code': 0,
            'data': res,
        }))


class DeployEvListHandler(BaseHandler):

    def get(self, *args, **kwargs):
        process_id = int(self.get_argument('process_id', '-1'))
        if process_id == -1:
            self.write(json.dumps({
                'code': 0,
                'data': '',
            }))
            return
        data = ''

        with mysql_sc() as sc:
            o = sc.query(
                DeployConfs.vstrategy_id,
            ).filter(
                DeployConfs.id == process_id,
            ).first()
            if not o:
                self.write(json.dumps({
                    'code': 0,
                    'data': '',
                }))
                return

            if o.vstrategy_id:
                vstrategy_obj = sc.query(VStrategies).filter(VStrategies.id == o.vstrategy_id).first()
                if vstrategy_obj:
                    trading_date = KdbQuery().get_trading_date_now().replace('-', '')
                    now_hour = datetime.datetime.now().hour
                    if 6 <= now_hour < 19:
                        day_night = 0
                    else:
                        day_night = 1
                    data = vstrategy_obj.get_strategy_ev(trading_date, day_night)

            self.write(json.dumps({
                'code': 0,
                # 'data': o.get_strategy_ev(),
                'data': data,
            }))


class DeployEvListPreMachineHandler(BaseHandler):

    def get(self, *args, **kwargs):
        start_all = time.time()
        host = self.get_argument('host', None)
        if host is None:
            self.write(json.dumps({
                'code': 404,
                'data': 'payload error',
            }))
            return

        with mysql_sc() as sc:
            # 查询 host 的所有 vstrategy_id
            o_list = sc.query(
                DeployConfs.vstrategy_id,
            ).join(
                VStrategies, VStrategies.id == DeployConfs.vstrategy_id,
            ).filter(
                DeployConfs.host == host,
                VStrategies.status == 15,  # vstrategy.status == 15 means the strategy is being used.
                DeployConfs.valid == 1  # valid == 1 means the strategy can be used.
            ).all()
            if len(o_list) == 0:
                self.write(json.dumps({
                    'code': 404,
                    'data': 'strategy not found',
                }))
                return

            # 创建保存 ev 的文件夹
            ev_dir = os.path.join(config.platform['media'], 'strategy_ev',
                                  '%s_%s' % (host, datetime.datetime.now().strftime('%Y%m%d')))
            if not os.path.exists(ev_dir):
                os.makedirs(ev_dir)

            fail_deploy_ev = []  # 记录上传失败的 ev 对应的 vstrategy_id, 以供告警使用
            ev_files_set = set()
            for o in o_list:
                if o.vstrategy_id:
                    vstrategy_obj = sc.query(VStrategies).filter(VStrategies.id == o.vstrategy_id).first()
                    if vstrategy_obj:
                        ev_files = vstrategy_obj.get_strategy_ev_per_machine()
                        if ev_files is None:
                            fail_deploy_ev.append(o.vstrategy_id)  # 记录失败的 vstrategy_id
                        else:
                            for ev_file in ev_files:
                                ev_files_set.add(ev_file)

            start = time.time()
            for ev_file in ev_files_set:
                target_path = os.path.join(ev_dir, os.path.basename(ev_file))
                logger.info("ev copy from " + ev_file + " to " + target_path)
                shutil.copyfile(ev_file, target_path)
            # logger.info("other ev copy cost: " + str(time.time() - start))

            # 拷贝龙哥的ev
            start = time.time()
            ev_file = '/home/rss/volume_profile/volume_profile.csv'
            shutil.copy(ev_file, ev_dir)
            ev_file = '/home/rss/volume_params7/volume_params.csv'
            shutil.copy(ev_file, ev_dir)
            ev_files = '/home/rss/jupyter_userworkspace/media/strategy_upload/common_ev/*'
            for ev_file in glob.glob(ev_files):
                shutil.copy(ev_file, ev_dir)
            # logger.info("long ev copy cost: " + str(time.time() - start))
            logger.info("ev copy finish.")
            logger.info("fail num:" + str(len(fail_deploy_ev)))

            # 把上传失败的名单发送微信
            from notify import notify_wechat
            if len(fail_deploy_ev) > 0:
                send_msg = ', '.join([str(vstid) for vstid in fail_deploy_ev])
                send_msg = "上传ev失败名单：\n时间：{}\n名单：{}".format(datetime.datetime.now().strftime("%Y-%m-%d"), send_msg)
                # users = ['oupei']
                users = ["rice", "LiZhiBingsandy", "HuBo", "oupei"]
                notify_wechat(users, send_msg)  # 这个企业微信id在客户端貌似是看不到的，需要问sandy拿一份excel表格
                logger.error(send_msg)

            self.write(json.dumps({
                'code': 0,
                'data': ev_dir + "/" if ev_dir else '',
            }))

    def compare_file_md5(self, path_1, path_2):
        # start = time.time()
        with open(path_1, 'rb') as f1, open(path_2, 'rb') as f2:
            m1 = self.get_hash(f1)
            m2 = self.get_hash(f2)
        # logger.info("time cost_md5:" + str(time.time() - start))
        return m1 == m2

    def get_hash(self, f):
        md5_hash = hashlib.md5()
        while True:
            content = f.read(1024)
            if not content:
                break
            md5_hash.update(content)
        return md5_hash.hexdigest()


class VStrategyConfigsListHandler(BaseHandler):

    def get(self, *args, **kwargs):
        res = {}
        vsids = self.get_argument('vsids', '')
        if not vsids:
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        vsid_list = vsids.split(',')
        with mysql_sc() as sc:
            for vstrategy_id in vsid_list:
                o = sc.query(DeployConfs).filter(
                    DeployConfs.vstrategy_id == vstrategy_id,
                ).order_by(DeployConfs.id.desc()).first()
                if not o:
                    continue
                res[vstrategy_id] = o.content
        if not res:
            self.write(json.dumps({
                'code': 404,
                'error': 'Xml data not found.',
            }))
            return
        self.write(json.dumps({
            'code': 0,
            'data': res,
        }))


class RiskManageListHandler(BaseHandler):

    def get(self, *args, **kwargs):
        account_id = self.current_user['id']
        # if account_id <= 0:
        #    self.write(json.dumps({
        #        'code': 400,
        #        'error': 'payload data error.',
        #    }))
        #    return
        data = {}
        try:
            with mysql_sc() as sc:
                o = sc.query(RiskManagement).filter(
                    RiskManagement.account_id == account_id,
                ).order_by(RiskManagement.id.desc()).first()
                if o:
                    data = o.to_dict()
                else:
                    data = {
                        'shse_max_declaration': 300,
                        'szse_max_declaration': 300,
                        'day_max_delegate': 8000,
                        'max_count': 800,
                        'cancellation_radio': 40.0,
                        'discarded_radio': 20.0,
                        'turnover_radio': 20.0,
                        'day_max_buy': 10000000.0,
                        'account_id': account_id,
                    }
            self.write(json.dumps({
                'code': 0,
                'data': data,
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        data = {
            'sse_max_declaration': payload['shse_max_declaration'],
            'szse_max_declaration': payload['szse_max_declaration'],
            'day_max_delegate': payload['day_max_delegate'],
            'max_count': payload['max_count'],
            'cancellation_radio': payload['cancellation_radio'],
            'discarded_radio': payload['discarded_radio'],
            'turnover_radio': payload['turnover_radio'],
            'day_max_buy': payload['day_max_buy'],
            'account_id': self.current_user['id'],
        }
        try:
            with mysql_sc() as sc:
                o = RiskManagement(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class LiveTradeLogsHandler(BaseHandler):

    def get(self, *args, **kwargs):
        try:
            ret = []
            day_night = int(self.get_argument('day_night', -1))
            with mysql_sc() as sc:
                deployconfs = sc.query(DeployConfs).filter(
                    DeployConfs.valid == 1,
                    DeployConfs.vstrategy_id > 0,
                    DeployConfs.day_night == day_night,
                    DeployConfs.content.isnot(None),
                )
                for conf in deployconfs:
                    host = conf.host
                    vstrategy_id = conf.vstrategy_id
                    deploy_path = conf.deploy_path
                    strategy = sc.query(Strategy).join(
                        VStrategies, VStrategies.strategy_id == Strategy.id,
                    ).filter(
                        VStrategies.id == vstrategy_id,
                    ).first()
                    if strategy:
                        user_id = strategy.r_create_user_id
                        username = strategy.username
                        strategy_idno = strategy.name
                        data = {
                            'ip': host,
                            'log_path': os.path.join(deploy_path, 'st_log'),
                            'strategy_idno': strategy_idno,
                            'strategy_creator': '%s_%s' % (user_id, username),
                        }
                        ret.append(data)
            self.write(json.dumps({
                'code': 0,
                'data': ret,
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class InTradingPositionsHandler(BaseHandler):

    def get(self, *args, **kwargs):
        try:
            import sys
            if config.platform['settle_path'] not in sys.path:
                sys.path.append(config.platform['settle_path'])
            from new_settlement import live_settle
            kdb_config = {
                'host': config.kdb['host'],
                'port': config.kdb['port'],
                'username': config.kdb['user'],
                'password': config.kdb['passwd'],
            }
            vstrategy_id = int(self.get_argument('vstrategy_id'))
            day_night = int(self.get_argument('day_night'))
            trading_date = KdbQuery().get_trading_date_now().replace('-', '')

            close_status = False
            with mysql_sc() as sc:
                vstrategy = sc.query(VStrategies).filter(VStrategies.id == vstrategy_id).first()
                close_status = (vstrategy.closing_out == 17)
                strategy_type = sc.query(Strategy).filter(Strategy.id == vstrategy.strategy_id).first().strategy_type

            settle_data = live_settle(config.mysql, kdb_config, vstrategy_id, trading_date, day_night,
                                      init_pos={}, set_position=False, in_trading=True, strategy_type=strategy_type)

            # query position
            position_data = {}
            for symbol, v in settle_data.get('symbols', {}).items():
                yd_long_pos = v['yest_long_pos']
                yd_long_avg_price = v['yest_long_avg_price']
                yd_short_pos = v['yest_short_pos']
                yd_short_avg_price = v['yest_short_avg_price']
                td_long_pos = v['today_long_pos']
                td_long_avg_price = v['today_long_avg_price']
                td_short_pos = v['today_short_pos']
                td_short_avg_price = v['today_short_avg_price']
                if td_long_pos == 0 and td_short_pos == 0:
                    continue
                position_data[symbol] = {
                    'yd_long_pos': yd_long_pos,
                    'yd_long_avg_price': yd_long_avg_price,
                    'yd_short_pos': yd_short_pos,
                    'yd_short_avg_price': yd_short_avg_price,
                    'td_long_pos': td_long_pos - yd_long_pos,
                    'td_long_avg_price': td_long_avg_price,
                    'td_short_pos': td_short_pos - yd_short_pos,
                    'td_short_avg_price': td_short_avg_price,
                    'account': v['account'],
                    'exchange': v['exchange'],
                    'symbol_type': v['symbol_type'],
                }

            # query account cash
            cash_data = {}
            cash_asset_data = {}
            rate_data = {}
            with mysql_sc() as sc:
                o = sc.query(VStrategies).filter_by(id=vstrategy_id).first()
                if o:
                    symbols_accounts = o.symbols_accounts
                    if day_night == 0:
                        for item in symbols_accounts.get('day', []):
                            account = item['account']
                            amount = float(item['amount'])
                            if account not in cash_data:
                                cash_data[account] = amount
                                cash_asset_data[account] = amount
                                rate_data[account] = item.get('rate', 1)
                            else:
                                cash_data[account] += amount
                                cash_asset_data[account] += amount
                    else:
                        for item in symbols_accounts.get('night', []):
                            account = item['account']
                            amount = float(item['amount'])
                            if account not in cash_data:
                                cash_data[account] = amount
                                cash_asset_data[account] = amount
                                rate_data[account] = item.get('rate', 1)
                            else:
                                cash_data[account] += amount
                                cash_asset_data[account] += amount
            for account, v in settle_data.get('accounts', {}).items():
                forex_rate = float(v.get('forex_rate', 1))
                rate_data[account] = forex_rate
                if close_status:
                    cash_data[account] = -float(v['position_cash']) / forex_rate
                    cash_asset_data[account] = 0
                else:
                    cash_data[account] = float(v['available_cash']) / forex_rate
                    cash_asset_data[account] = float(v['asset_cash']) / forex_rate

            # query max order id
            max_order_id = 0
            with mysql_sc() as sc:
                o = sc.query(func.max(func.cast(TradeLogs.serial_no, BIGINT)).label('serial_no'),
                             func.max(func.cast(TradeLogs.cancel_serial_no, BIGINT)).label('cancel_serial_no')).filter(
                    TradeLogs.vstrategy_id == vstrategy_id,
                    TradeLogs.day_night == day_night,
                    TradeLogs.calendar_date == datetime.datetime.now().strftime('%Y-%m-%d'),
                ).first()
                if o.serial_no:
                    max_order_id = max([max_order_id, o.serial_no // (10 ** 10)])
                if o.cancel_serial_no:
                    max_order_id = max([max_order_id, o.cancel_serial_no // (10 ** 10)])
            max_order_id += 1

            self.write(json.dumps({
                'code': 0,
                'data': {
                    'max_order_id': max_order_id,
                    'positions': position_data,
                    'cash': cash_data,
                    'cash_asset': cash_asset_data,
                    'rate': rate_data,
                }
            }))

        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class StrategyNecessariesHandler(BaseHandler):

    def get(self, *args, **kwargs):
        try:
            process_id = int(self.get_argument('process_id', -1))
            if process_id == -1:
                self.write(json.dumps({
                    'code': 400,
                    'error': 'payload data error',
                }))
                return
            with mysql_sc() as sc:
                o = sc.query(DeployConfs.vstrategy_id).filter(
                    DeployConfs.id == process_id,
                ).first()
                if not o:
                    self.write(json.dumps({
                        'code': 404,
                        'error': 'no process',
                    }))
                    return
                if not o.vstrategy_id:
                    self.write(json.dumps({
                        'code': 404,
                        'error': 'not strategy process',
                    }))
                    return
                vstrategy_id = o.vstrategy_id
                v = sc.query(VStrategies).filter(
                    VStrategies.id == vstrategy_id,
                ).first()
                v_brief_data = v.brief()
                necessary = v_brief_data.get('necessary', '')
                necessary['input_files'] = []
                try:
                    trading_date = KdbQuery().get_trading_date_now().replace('-', '')
                    now_hour = datetime.datetime.now().hour
                    if 6 <= now_hour < 19:
                        day_night = 0
                    else:
                        day_night = 1
                    deploy_data = v.get_platform_data(trading_date, day_night)
                    necessary['input_files'] = [os.path.basename(_f) for _f in deploy_data['ev_files']]
                except Exception as e:
                    pass
                data = {
                    'vstrategy_id': vstrategy_id,
                    'strategy_id': v_brief_data.get('id', ''),
                    'strategy_name': v_brief_data.get('name', ''),
                    'necessary': necessary,
                }
                self.write(json.dumps({
                    'code': 0,
                    'data': data,
                }))

        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class CounterSeatsListHandler(BaseHandler):

    def get(self, *args, **kwargs):
        try:
            broker_id = int(self.get_argument('broker_id', -1))
            if broker_id == -1:
                self.write(json.dumps({
                    'code': 400,
                    'error': 'payload data error',
                }))
                return
            with mysql_sc() as sc:
                counters = sc.query(Counters).filter(
                    Counters.broker_id == broker_id,
                )
                data = [c.name for c in counters]
                self.write(json.dumps({
                    'code': 0,
                    'data': data,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class AccountServersListHandler(BaseHandler):

    def post(self, *args, **kwargs):
        try:
            payload = json.loads(str(self.request.body, 'utf-8'))
            if not isinstance(payload, list):
                self.write(json.dumps({
                    'code': 400,
                    'error': 'payload data error',
                }))
                return
            data = {}
            with mysql_sc() as sc:
                rows = sc.query(Servers.ip.label('host'), Accounts.name.label('account')).join(
                    PreTunnelConfs, PreTunnelConfs.server_id == Servers.id,
                ).join(
                    Accounts, Accounts.id == PreTunnelConfs.account_id,
                ).filter(
                    Accounts.name.in_(payload),
                )
                for r in rows:
                    account = r.account
                    host = r.host
                    if account not in data:
                        data[account] = [host]
                    else:
                        data[account].append(host)
                self.write(json.dumps({
                    'code': 0,
                    'data': data,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class DigitalCashOnlineRequestListHandler(BaseHandler):

    def get(self, *args, **kwargs):
        res = []
        status = int(self.get_argument('status', '-1'))
        try:
            with mysql_sc() as sc:
                lines = sc.query(OnlineRequest).join(
                    VStrategies, OnlineRequest.portfolio_id == VStrategies.portfolio_id).join(
                    Strategy, Strategy.id == VStrategies.strategy_id).filter(
                    Strategy.strategy_type == '22')

                if status == 0:
                    lines = lines.filter(OnlineRequest.status == 0).order_by(OnlineRequest.id.desc())
                    for line in lines:
                        res.append(line.to_dict())
                elif status == 1:
                    lines = lines.filter(OnlineRequest.status != 0).order_by(OnlineRequest.id.desc())
                    for line in lines:
                        portfolio_data = line.to_dict()
                        stra_data = portfolio_data['portfolio']['strategy']
                        for stra in stra_data:
                            conf = sc.query(
                                PreStrategyConfs.day_quote_conf,
                                PreStrategyConfs.day_tunnel_conf,
                                PreStrategyConfs.day_trader_conf,
                                Servers.ip
                            ).join(
                                Servers, Servers.id == PreStrategyConfs.server_id
                            ).filter(
                                PreStrategyConfs.vstrategy_id == stra['vstrategy_id']
                            ).first()
                            if not conf:
                                stra['deploy'] = {}
                            else:
                                stra['deploy'] = {
                                    'server': conf.ip,
                                    'quote_conf': conf.day_quote_conf,
                                    'tunnel_conf': conf.day_tunnel_conf,
                                    'trader_conf': conf.day_trader_conf,
                                }

                            deploy_result = sc.query(
                                DeployStrategies.result
                            ).filter(
                                DeployStrategies.vstrategy_id == stra['vstrategy_id']
                            ).order_by(DeployStrategies.id.desc()).first()
                            if not deploy_result:
                                stra['deploy']['result'] = ''
                            else:
                                stra['deploy']['result'] = deploy_result.result

                        res.append(portfolio_data)

            self.write(json.dumps({
                'code': 0,
                'data': res,
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class DigitalCashDeleteDeployInfoHandler(BaseHandler):

    def post(self, *args, **kwargs):
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                for vid in payload['vstrategy_id']:
                    sc.query(DeployConfs).filter_by(vstrategy_id=vid).delete()
                    sc.query(DeployStrategies).filter_by(vstrategy_id=vid).delete()
                    sc.query(PreStrategyConfs).filter_by(vstrategy_id=vid).delete()
                sc.query(OnlineRequest).filter_by(id=payload['request_id']).delete()
                sc.query(StrategyPortfolio).filter_by(id=payload['portfolio_id']).delete()

            self.write(json.dumps({
                'code': 0,
                'data': 'succ',
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class DigitalCashServersListHandler(BaseHandler):

    def get(self, *args, **kwargs):
        res = []
        try:
            with mysql_sc() as sc:
                lines = sc.query(Servers).filter(Servers.use_for == 1).all()
                for line in lines:
                    res.append(line.to_dict())
            self.write(json.dumps({
                'code': 0,
                'data': res,
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class DigitalCashDeployStrategiesHandler(BaseHandler):
    executor = ThreadPoolExecutor(2)

    @gen.coroutine
    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return

        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                # 更新实盘申请状态
                if len(payload['request_ids']) == 0:
                    self.write(json.dumps({
                        'code': 415,
                        'error': 'request_ids is None.',
                    }))
                    return
                self.update_online_request(payload['request_ids'], payload['user'], sc)

                # 查询待部署服务器的trader路径
                server_ip = payload['server_ip']
                server_id = sc.query(Servers).filter_by(ip=server_ip).first().id
                day_quote_conf = payload['conf']['day']['quote_conf']
                day_tunnel_conf = payload['conf']['day']['tunnel_conf']
                day_trader_conf = self.get_trader_path(sc, server_id)
                if not day_trader_conf:
                    logger.error('No found shannon trader in server %s' % server_ip)
                    self.write(json.dumps({
                        'code': 1400,
                        'error': 'No found shannon trader.',
                    }))
                    return

                # 为部署策略生成配置信息
                vstrategy_ids = payload.get('vstrategy_ids', [])
                objs = self.pre_conf_strategies(server_ip, server_id, vstrategy_ids, day_quote_conf, day_tunnel_conf,
                                                day_trader_conf, sc)

                # 执行部署策略
                task_id = self.deploy_strategies(objs, server_ip, sc)

                self.write(json.dumps({
                    'code': 0,
                    'data': {
                        'request_ids': payload['request_ids'],
                        'id': task_id,
                        'result': 0,
                    },
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def update_online_request(self, request_ids, user, sc):
        for request_id in request_ids:
            r = sc.query(OnlineRequest).filter_by(id=request_id).first()
            if not r:
                logger.error('No found online request %d' % request_id)
                continue

            r.status = 1
            r.action = 0
            r.audit_user = user
            r.audit_time = datetime.datetime.now()
            logger.info('Update online request %d, status=%d' % (request_id, r.status))
            sc.flush()

    def deploy_strategies(self, stra_conf_args, host, sc):
        task_id = -1
        vstrategy_ids = []
        for conf_args in stra_conf_args:
            data = {
                'host': host,
                'deploy_path': conf_args.day_trader_conf,
                'vstrategy_id': conf_args.vstrategy_id,
                'day_night': 0,
            }
            o = DeployStrategies(**data)
            sc.add(o)
            sc.flush()
            if task_id == -1:
                task_id = o.id
            o.task_id = task_id
            vstrategy_ids.append(conf_args.vstrategy_id)
        sc.flush()

        tornado.ioloop.IOLoop.instance().add_callback(
            self.async_upload_bfile,
            host=data['host'],
            deploy_path=data['deploy_path'],
            vstrategy_ids=vstrategy_ids,
            day_night=data['day_night'],
            task_id=task_id,
        )

        return task_id

    def pre_conf_strategies(self, server_host, server_id, vstrategy_ids, day_quote_conf, day_tunnel_conf,
                            day_trader_conf, sc):
        night_quote_conf = ''
        night_tunnel_conf = ''
        night_trader_conf = ''
        objs = []

        for vstrategy_id in vstrategy_ids:
            o = sc.query(PreStrategyConfs).filter(
                PreStrategyConfs.server_id == server_id,
                PreStrategyConfs.vstrategy_id == vstrategy_id,
            ).first()
            if o:
                # Set day or night DeployConfs' valid False
                if o.day_quote_conf != day_quote_conf or \
                        o.day_tunnel_conf != day_tunnel_conf or \
                        o.day_trader_conf != day_trader_conf:
                    rs = sc.query(DeployConfs).filter(
                        DeployConfs.host == server_host,
                        DeployConfs.vstrategy_id == vstrategy_id,
                        DeployConfs.day_night == 0,
                    )
                    for r in rs:
                        r.valid = False
                        delete_redis_process(config.redis, r.host, r.id)

                o.day_quote_conf = day_quote_conf
                o.day_tunnel_conf = day_tunnel_conf
                o.day_trader_conf = day_trader_conf
                o.night_quote_conf = night_quote_conf
                o.night_tunnel_conf = night_tunnel_conf
                o.night_trader_conf = night_trader_conf
                objs.append(o)
            else:
                data = {
                    'server_id': server_id,
                    'vstrategy_id': vstrategy_id,
                    'day_quote_conf': day_quote_conf,
                    'day_tunnel_conf': day_tunnel_conf,
                    'day_trader_conf': day_trader_conf,
                    'night_quote_conf': night_quote_conf,
                    'night_tunnel_conf': night_tunnel_conf,
                    'night_trader_conf': night_trader_conf,
                }
                r = PreStrategyConfs(**data)
                sc.add(r)
                sc.query(VStrategies).filter(
                    VStrategies.id == vstrategy_id
                ).update(
                    {VStrategies.status: 13}
                )
                objs.append(r)
            sc.flush()
        return objs

    def get_trader_path(self, sc, server_id):
        trader = sc.query(PreTraderConfs).filter_by(
            valid=1,
            server_id=server_id,
        ).order_by(
            PreTraderConfs.id.desc()
        ).first()
        if not trader:
            return None
        else:
            return trader.deploy_path

    @run_on_executor
    def async_upload_bfile(self, host, deploy_path, vstrategy_ids, day_night, task_id):
        l_user = config.local['user']
        if host.rsplit('.', 1)[0] == '192.168.30':
            l_host = config.local['vpn']
        elif host.rsplit('.', 1)[0] == '10.10.40':
            l_host = config.local['tun']
        elif host.rsplit('.', 1)[0] == '192.168.40':
            l_host = config.local['szvpn']
        else:
            l_host = config.local['host']
        result = 1
        try:
            with mysql_sc() as sc:
                so_list = []
                ev_list = []
                for vstrategy_id in vstrategy_ids:
                    p = sc.query(VStrategies).filter_by(id=vstrategy_id).first()
                    if p.source == 'dim':
                        s = sc.query(Strategies).filter_by(id=p.strategy_id).first()
                        so_list.append(os.path.basename(s.filepath))
                        ev_list.extend(os.path.basename(s.ev_file))
                    elif p.source == 'platform':
                        trading_date = KdbQuery().get_trading_date_now().replace('-', '')
                        d = p.get_platform_data(trading_date, day_night)
                        if not d:
                            result = 2
                            continue
                        if d['strategy_type'] == 'order_list':
                            ol_obj = sc.query(Programs).join(ProgramTypes).filter(
                                ProgramTypes.name == 'trade_list',
                            ).order_by(Programs.id.desc()).first()
                            so_file = ol_obj.filepath
                        else:
                            so_file = d['so_file']
                        so_name = d['name'] + '.so'
                        ev_files = d['ev_files']
                        os.system('cp %s %s' % (os.path.join(config.platform['media'], so_file),
                                                os.path.join(os.path.dirname(os.path.realpath(__file__)),
                                                             'files', so_name)))
                        so_fullpath = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'files', so_name)
                        if is_python_strategy(so_fullpath) or d['strategy_type'] == 'order_list':
                            if not upload_python_strategy(l_user, l_host, host, deploy_path, so_fullpath,
                                                          vid=vstrategy_id):
                                result = 2
                        else:
                            so_list.append(so_name)
                        for ev_file in ev_files:
                            ev_file = ev_file.replace('/home/rss/bss_server/site/media/', '')
                            os.system('cp %s %s' % (os.path.join(config.platform['media'], ev_file),
                                                    os.path.join(os.path.dirname(os.path.realpath(__file__)), 'files')))
                            ev_list.append(os.path.basename(ev_file))

                if so_list and result == 1:
                    if not compress_package(
                            os.path.join(os.path.dirname(os.path.realpath(__file__)), 'files'),
                            'so_%s.tar.gz' % task_id, so_list
                    ):
                        result = 2
                    if not upload_bfile(
                            l_user, l_host, host, deploy_path,
                            os.path.join(os.path.dirname(os.path.realpath(__file__)),
                                         'files', 'so_%s.tar.gz' % task_id), type=1
                    ):
                        result = 2
                if ev_list and result == 1:
                    if not compress_package(
                            os.path.join(os.path.dirname(os.path.realpath(__file__)), 'files'),
                            'ev_%s.tar.gz' % task_id, ev_list
                    ):
                        result = 2
                    if not upload_bfile(
                            l_user, l_host, host, deploy_path,
                            os.path.join(os.path.dirname(os.path.realpath(__file__)),
                                         'files', 'ev_%s.tar.gz' % task_id), type=2
                    ):
                        result = 2

                pt = sc.query(ProgramTypes).filter_by(name='shannon_trader').first()
                for vstrategy_id in vstrategy_ids:
                    o = sc.query(DeployStrategies).filter(
                        DeployStrategies.host == host,
                        DeployStrategies.deploy_path == deploy_path,
                        DeployStrategies.vstrategy_id == vstrategy_id,
                    ).order_by(DeployStrategies.id.desc()).first()
                    o.result = result
                    querys = sc.query(DeployConfs).filter(
                        DeployConfs.host == host,
                        DeployConfs.deploy_path == deploy_path,
                        DeployConfs.vstrategy_id == vstrategy_id,
                        DeployConfs.day_night == day_night,
                        DeployConfs.program_type_id == pt.id,
                    )
                    if querys.first():
                        o = querys.first()
                    else:
                        data = {
                            'host': host,
                            'deploy_path': deploy_path,
                            'day_night': day_night,
                            'vstrategy_id': vstrategy_id,
                            'program_type_id': pt.id,
                            'valid': True,
                        }
                        o = DeployConfs(**data)
                        sc.add(o)
                    sc.commit()
                    rsp = register_process_event(host, o.id)
                    logger.info('Register process: resp=%s' % rsp)

        except Exception as e:
            logger.error(str(e))
            raise e


class DigitalCashStrategyProcessesHandler(BaseHandler):

    def get(self, *args, **kwargs):
        res = []
        host = self.get_argument('server', '')
        processes_online = query_process_online(config.redis, host)
        with mysql_sc() as sc:
            if host:
                lines = sc.query(DeployConfs).join(
                    ProgramTypes, ProgramTypes.id == DeployConfs.program_type_id
                ).filter(
                    DeployConfs.valid == 1,
                    DeployConfs.host == host,
                    ProgramTypes.name == 'shannon_trader'
                )
            else:
                servers = sc.query(Servers).filter(Servers.use_for == 1).all()
                hosts = [server.ip for server in servers]
                lines = sc.query(DeployConfs).join(
                    ProgramTypes, ProgramTypes.id == DeployConfs.program_type_id
                ).filter(
                    DeployConfs.valid == 1,
                    DeployConfs.host.in_(hosts),
                    ProgramTypes.name == 'shannon_trader'
                )
            for line in lines:
                data = line.to_dict()
                data['status'] = processes_online.get(data['process_id'], 2)
                stra_portfolio = sc.query(
                    StrategyPortfolio.name
                ).join(
                    VStrategies, VStrategies.portfolio_id == StrategyPortfolio.id
                ).filter(
                    VStrategies.id == data['vstrategy_id']
                ).first()
                if not stra_portfolio:
                    logger.error('Not found strategy portfolio of vstrategy %d' % data['vstrategy_id'])

                stra_info = sc.query(
                    Strategy
                ).join(
                    VStrategies, VStrategies.strategy_id == Strategy.id
                ).filter(
                    VStrategies.id == data['vstrategy_id']
                ).first()
                if not stra_info:
                    logger.error('Not found strategy of vstrategy %d' % data['vstrategy_id'])

                data['strategy_name'] = '%s:%s' % (stra_portfolio.name, stra_info.strategy_name)
                data['strategy_id'] = stra_info.name

                deploy_info = sc.query(
                    PreStrategyConfs
                ).filter(
                    PreStrategyConfs.vstrategy_id == data['vstrategy_id']
                ).order_by(
                    PreStrategyConfs.id.desc()
                ).first()
                if deploy_info:
                    data['quote'] = deploy_info.day_quote_conf.split('/')[-1]
                    data['tunnel'] = deploy_info.day_tunnel_conf.split('/')[-1]
                else:
                    data['quote'] = ''
                    data['tunnel'] = ''
                res.append(data)
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))


class DigitalCashEvHandler(BaseHandler):

    def get(self, *args, **kwargs):
        user_name = self.current_user['username']
        user_id = self.current_user['id']

        vstrategy_id = int(kwargs['id'])
        try:
            with mysql_sc() as sc:
                stra_info = sc.query(
                    Strategy
                ).join(
                    VStrategies, VStrategies.strategy_id == Strategy.id
                ).filter(
                    VStrategies.id == vstrategy_id
                ).first()
                if not stra_info:
                    self.write(json.dumps({
                        'code': 1401,
                        'error': 'No found strategy !',
                    }))
                    return

                if vstrategy_id > const.STRA_NAME_CUT_OFF_RULE:
                    ev_name = 'ev_%s_%d.csv' % (stra_info.name, vstrategy_id)
                else:
                    ev_name = 'ev_%s.csv' % stra_info.name

                file_path = '%s/%d_%s/%s/%s/%s' % (
                    config.ev_conf['base_path'], user_id, user_name, config.ev_conf['sub_path'], stra_info.name,
                    ev_name)
                content = ''
                ev_dir = ''
                try:
                    f = open(file_path, 'r')
                    content = f.read()
                    f.close()

                    deploy_info = sc.query(DeployConfs.deploy_path).filter_by(vstrategy_id=vstrategy_id).first()
                    if deploy_info:
                        ev_dir = '%s/st_ev/%s' % (deploy_info.deploy_path, ev_name)
                except FileNotFoundError:
                    logger.error('No found file:%s' % file_path)
                except Exception as e:
                    logger.error(str(e))
                    self.write(json.dumps({
                        'code': 500,
                        'error': str(e),
                    }))
                    return

                self.write(json.dumps({
                    'code': 0,
                    'data': {
                        'ev_dir': ev_dir,
                        'content': content,
                    }
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def post(self, *args, **kwargs):
        user_name = self.current_user['username']
        user_id = self.current_user['id']

        vstrategy_id = int(kwargs['id'])
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                stra_info = sc.query(
                    Strategy
                ).join(
                    VStrategies, VStrategies.strategy_id == Strategy.id
                ).filter(
                    VStrategies.id == vstrategy_id
                ).first()
                if not stra_info:
                    self.write(json.dumps({
                        'code': 1401,
                        'error': 'No found strategy !',
                    }))
                    return

                ev_dir = '%s/%d_%s/%s/%s' % (
                    config.ev_conf['base_path'], user_id, user_name, config.ev_conf['sub_path'], stra_info.name)
                if not os.path.exists(ev_dir):
                    os.makedirs(ev_dir)

                time_str = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
                if vstrategy_id > const.STRA_NAME_CUT_OFF_RULE:
                    ev_name = 'ev_%s_%d.csv' % (stra_info.name, vstrategy_id)
                    back_name = 'ev_%s_%d_%s.csv' % (stra_info.name, vstrategy_id, time_str)
                else:
                    ev_name = 'ev_%s.csv' % stra_info.name
                    back_name = 'ev_%s_%s.csv' % (stra_info.name, time_str)

                file_path = '%s/%s' % (ev_dir, ev_name)
                back_path = '%s/%s' % (ev_dir, back_name)

                f = open(back_path, 'w')
                f.write(payload['ev_content'])
                f.close()

                f = open(file_path, 'w')
                f.write(payload['ev_content'])
                f.close()

                ret = self.upload_ev_file(vstrategy_id, file_path)
                if ret:
                    self.write(json.dumps({
                        'code': 0,
                        'data': 'success'
                    }))
                else:
                    self.write(json.dumps({
                        'code': 1300,
                        'error': 'Failed to upload ev file !',
                    }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def upload_ev_file(self, vstrategy_id, local_path):

        with mysql_sc() as sc:
            info = sc.query(
                DeployConfs
            ).filter_by(
                vstrategy_id=vstrategy_id
            ).first()
            if not info:
                logger.error('No found record of vstrategy %d in deploy_confs' % vstrategy_id)
                return False

            server_ip = info.host
            server_path = '%s/st_ev' % info.deploy_path
            local_ip = 'rss@%s' % config.local['vpn']
            cmd = 'rsync -az %s:%s %s' % (local_ip, local_path, server_path)
            logger.info('cmd: %s' % cmd)
            scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (server_ip, cmd)
            res = os.system(scmd)
            if res != 0:
                return False
            return True


class DigitalCashStrategyPositionsHandler(BaseHandler):

    def get(self, *args, **kwargs):
        try:
            out_data = []
            with mysql_sc() as sc:
                pos = sc.query(DigitalCashStrategyPositions).filter_by(vstrategy_id=kwargs['id']).all()
                for p in pos:
                    out_data.append({
                        'symbol': p.symbol,
                        'long_pos': p.long_pos,
                        'short_pos': p.short_pos
                    })
            self.write(json.dumps({
                'code': 0,
                'data': out_data
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    @gen.coroutine
    def post(self, *args, **kwargs):
        user_id = self.current_user['id']
        payload = json.loads(str(self.request.body, 'utf-8'))
        vstrategy_id = int(kwargs['id'])
        try:
            out_data = []
            with mysql_sc() as sc:
                sc.query(
                    DigitalCashStrategyPositions
                ).filter_by(
                    vstrategy_id=vstrategy_id,
                ).delete()

                for p in payload:
                    pos = DigitalCashStrategyPositions(
                        vstrategy_id=vstrategy_id,
                        symbol=p['symbol'],
                        long_pos=p['long_pos'],
                        short_pos=p['short_pos'],
                        create_user_id=user_id,
                    )
                    sc.add(pos)
                    out_data.append({
                        'symbol': pos.symbol,
                        'long_pos': pos.long_pos,
                        'short_pos': pos.short_pos
                    })

            self.generate_strategy_conf(vstrategy_id)
            self.write(json.dumps({
                'code': 0,
                'data': out_data
            }))

        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def generate_strategy_conf(self, vstrategy_id):
        with mysql_sc() as sc:
            conf_template = '/home/rss/bss_server/myrpc/apps/operation_deploy/digital_cash_strategy_tmpl.xml'
            tree = ET.parse(conf_template)
            root = tree.getroot()

            # 修改quote节点
            quote_conf = sc.query(
                PreQuoteConfs
            ).join(
                PreStrategyConfs, PreStrategyConfs.day_quote_conf == PreQuoteConfs.deploy_path
            ).filter(
                PreStrategyConfs.vstrategy_id == vstrategy_id,
            ).order_by(
                PreQuoteConfs.id.desc()
            ).first()
            if not quote_conf:
                logger.error('No found quote config of vstrategy %d' % vstrategy_id)
                return False
            quote = root.find('quote')
            quoteip = quote.find('ip')
            quoteport = quote.find('port')
            quoteip.text = str(quote_conf.ip_addr)
            quoteport.text = str(quote_conf.port)

            # 修改tunnel节点
            tunnel_conf = sc.query(
                PreTunnelConfs.ip_addr,
                PreTunnelConfs.port,
                DeployConfs.valid
            ).join(
                PreStrategyConfs, PreStrategyConfs.day_tunnel_conf == PreTunnelConfs.deploy_path
            ).filter(
                PreStrategyConfs.vstrategy_id == vstrategy_id,
            ).order_by(
                PreTunnelConfs.id.desc()
            ).first()
            if not tunnel_conf:
                logger.error('No found tunnel config of vstrategy %d' % vstrategy_id)
                return False
            tunnel = root.find("tunnel")
            tunnelip = tunnel.find("ip")
            tunnelport = tunnel.find("port")
            tunnelip.text = str(tunnel_conf.ip_addr)
            tunnelport.text = str(tunnel_conf.port)

            # 修改strategy节点
            stra_info = sc.query(
                Strategy
            ).join(
                VStrategies, VStrategies.strategy_id == Strategy.id
            ).filter(
                VStrategies.id == vstrategy_id
            ).first()
            if not stra_info:
                logger.error('No found strategy %d in table strategy' % vstrategy_id)
                return False

            deploy_info = sc.query(
                DeployConfs
            ).filter_by(
                vstrategy_id=vstrategy_id
            ).order_by(
                DeployConfs.id.desc()
            ).first()
            if not deploy_info:
                logger.error('No found strategy %d in table deploy_confs' % vstrategy_id)
                return False

            strategy = root.find("strategy")
            strategy_so = strategy.find("strategy_so")
            strategy_so.text = './st_so/%s.so' % stra_info.name

            if vstrategy_id > const.STRA_NAME_CUT_OFF_RULE:
                ev_name = 'ev_%s_%d.csv' % (stra_info.name, vstrategy_id)
                log_name = '%s_%d.log' % (stra_info.name, vstrategy_id)
                output_name = '%s_%d' % (stra_info.name, vstrategy_id)
            else:
                ev_name = 'ev_%s.csv' % stra_info.name
                log_name = '%s.log' % stra_info.name
                output_name = '%s' % stra_info.name

            strategy_ev_file = strategy.find("strategy_ev_file")
            strategy_ev_file.text = './st_ev/%s' % ev_name

            strategy_log_path = strategy.find("strategy_log_path")
            strategy_log_path.text = './st_log/%s' % log_name

            v_strategy_id = strategy.find("v_strategy_id")
            v_strategy_id.text = str(vstrategy_id)

            serial_strategy = strategy.find("serial_strategy")
            serial_strategy.text = './st_so/%s/st.so' % stra_info.name

            strategy_name = strategy.find("strategy_name")
            strategy_name.text = stra_info.name

            strategy_outpath = strategy.find("strategy_outpath")
            strategy_outpath.text = '/home/mycapitaltrade/output/%s/' % output_name

            # 修改仓位
            pos = sc.query(DigitalCashStrategyPositions).filter_by(vstrategy_id=vstrategy_id)
            num = pos.count()
            if num == 0:
                logger.error('No position of strategy %d .' % vstrategy_id)
                return False

            symbol = strategy.find("symbol")
            for j in range(num - 1):
                strategy.append(copy.deepcopy(symbol))

            allsymbol = strategy.findall("symbol")
            for k in range(len(allsymbol)):
                name = allsymbol[k].find("name")
                name.text = pos[k].symbol

                exchange = allsymbol[k].find("exchange")
                exchange.text = const.symbol_exchg[pos[k].symbol.split('.')[-1]]

                td_short_pos = allsymbol[k].find("td_short_pos")
                td_short_pos.text = str(pos[k].short_pos)

                td_long_pos = allsymbol[k].find("td_long_pos")
                td_long_pos.text = str(pos[k].long_pos)

            self.indent(root)
            xml = ET.tostring(root, encoding="utf-8")
            logger.info(xml)
            deploy_info.content = xml
            sc.commit()
            return True

    def indent(self, elem, level=0):
        '''
        indent xml file for more beautifull
        '''
        i = "\n" + level * "  "
        if len(elem):
            if not elem.text or not elem.text.strip():
                elem.text = i + "  "
            if not elem.tail or not elem.tail.strip():
                elem.tail = i
            for elem in elem:
                self.indent(elem, level + 1)
            if not elem.tail or not elem.tail.strip():
                elem.tail = i
        else:
            if level and (not elem.tail or not elem.tail.strip()):
                elem.tail = i


class CommandResultHandler(BaseHandler):
    def initialize(self, *args, **kwargs):
        self.model = DeployConfs

    def get(self, *args, **kwargs):
        """

        Generic Command Result Check

        Args:
            host: server host of this command is running
            seq: the sequence number of this command

        """
        try:
            host = self.get_argument('host', None)
            seq = self.get_argument('seq', None)
            if not host or not seq:
                self.write(json.dumps({
                    'code': 400,
                    'error': 'reqeust data error.',
                }))
                return

            redis_helper = RedisHelper()
            rsp = redis_helper.lpop_redis_cmd(host, int(seq))

            if not rsp:
                self.write(json.dumps({
                    'code': 1404,
                    'error': '指令seq-{}:还未收到agent的回复'.format(seq),
                }))
            elif json.loads(str(rsp, 'utf-8'))['data']['return'] != 0:
                logger.error('Failed to run command seq-{seq} on host:{host}'.format(seq=seq, host=host))
                self.write(json.dumps({
                    'code': 1403,
                    'error': '指令seq-{}:下发失败'.format(seq),
                }))
                return
            else:
                logger.info('Succeed to send command seq-{seq} on host:{host}'.format(seq=seq, host=host))
                self.write(json.dumps({
                    'code': 0,
                    'error': '指令seq-{}:下发成功'.format(seq),
                }))
                return
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class KeplerShmConfControlHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = DeployConfs

    def post(self, *args, **kwargs):
        """

        send command handler check the result of command with get method

        Returns:

            sever: which server to run cmd
            xml: cmd content

        """
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if not payload.get('server') or not payload.get('xml'):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return

        try:
            redis_helper = RedisHelper()
            host = payload['server']
            content = payload['xml']
            _now = datetime.datetime.now()
            seq = int(str(_now.second) + str(_now.microsecond))
            cmd = json.dumps({
                'type': 0,
                'data': content,
                'seq': seq,
            })
            logger.info(cmd)
            iphost = redis_helper.query_redis_iphost(host)
            if not iphost:
                logger.error('Not found host %s', host)
                self.write(json.dumps({
                    'code': 1401,
                    'error': '{}未注册'.format(host),
                }))
                return
            if not redis_helper.rpush_redis_cmd(iphost, cmd):
                logger.error('Failed to push kepler shm conf of {} to redis', host)
                self.write(json.dumps({
                    'code': 1402,
                    'error': '向redis写数据失败',
                }))
                return
            logger.info('Push kepler shm conf of {} to redis'.format(host))
            self.write(
                json.dumps({
                    'code': 0,
                    'error': 'success',
                    'data': {
                        'host': iphost,
                        'seq': seq
                    }
                })
            )
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class DigitalCashStrategyLogHandler(BaseHandler):

    def get(self, *args, **kwargs):
        try:
            out_data = []
            with mysql_sc() as sc:
                vstrategy_id = int(kwargs['id'])
                stra_info = sc.query(
                    Strategy
                ).join(
                    VStrategies, VStrategies.strategy_id == Strategy.id
                ).filter(
                    VStrategies.id == vstrategy_id
                ).first()
                if not stra_info:
                    self.write(json.dumps({
                        'code': 1401,
                        'error': 'No found strategy !',
                    }))
                    return

                if vstrategy_id > const.STRA_NAME_CUT_OFF_RULE:
                    log_name = '%s_%d.log' % (stra_info.name, vstrategy_id)
                else:
                    log_name = '%s.log' % stra_info.name

                deploy_info = sc.query(DeployConfs).filter_by(vstrategy_id=vstrategy_id).first()
                if not deploy_info:
                    logger.error('No found record of vstrategy %d in deploy_confs' % vstrategy_id)
                    self.write(json.dumps({
                        'code': 1402,
                        'error': 'No found record of vstrategy %d in deploy_confs' % vstrategy_id,
                    }))
                    return

                now = datetime.datetime.now()
                hour = int(now.strftime('%H'))
                if hour < 16:
                    day = (now - datetime.timedelta(days=1)).strftime('%Y%m%d')
                else:
                    day = now.strftime('%Y%m%d')
                log_file = '%s/st_log/%s_*_%s' % (deploy_info.deploy_path, day, log_name)

                server_ip = deploy_info.host
                cmd = 'tail -n 200 %s' % log_file
                scmd = 'salt-ssh -i "%s" cmd.run "%s"' % (server_ip, cmd)
                logger.info('scmd: %s' % scmd)
                out_bytes = subprocess.check_output(scmd, shell=True)
                out_text = out_bytes.decode('utf-8')
                self.write(json.dumps({
                    'code': 0,
                    'data': out_text
                }))
        except subprocess.CalledProcessError as exc:
            err_str = exc.output.decode('utf-8')
            logger.error(err_str)
            self.write(json.dumps({
                'code': 0,
                'data': err_str
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class KeplerShmConfHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = DeployConfs

    @gen.coroutine
    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if not payload.get('server') or not payload.get('xml'):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return

        try:
            redis_helper = RedisHelper()
            host = payload['server']
            content = payload['xml']
            _now = datetime.datetime.now()
            seq = int(str(_now.second) + str(_now.microsecond))
            cmd = json.dumps({
                'type': 0,
                'data': content,
                'seq': seq,
            })
            logger.info(cmd)
            iphost = redis_helper.query_redis_iphost(host)
            if not iphost:
                logger.error('Not found host %s', host)
                self.write(json.dumps({
                    'code': 1401,
                    'error': '{}未注册'.format(host),
                }))
                return
            if not redis_helper.rpush_redis_cmd(iphost, cmd):
                logger.error('Failed to push kepler shm conf of {} to redis', host)
                self.write(json.dumps({
                    'code': 1402,
                    'error': '向redis写数据失败',
                }))
                return
            logger.info('Push kepler shm conf of {} to redis'.format(host))
            for _ in range(55):
                rsp = redis_helper.lpop_redis_cmd(iphost, seq)
                if not rsp:
                    yield gen.sleep(1)
                    continue
                elif json.loads(str(rsp, 'utf-8'))['data']['return'] != 0:
                    logger.error('Failed to send kepler shm conf of {}'.format(host))
                    self.write(json.dumps({
                        'code': 1403,
                        'error': '下发kepler共享内存失败',
                    }))
                    return
                else:
                    logger.info('Successed to send kepler shm conf of {}'.format(host))
                    self.write(json.dumps({
                        'code': 0,
                        'error': 'success',
                    }))
                    return
            logger.error('Timeout to recv rsp of kepler shm conf {}'.format(host))
            self.write(json.dumps({
                'code': 1404,
                'error': '超时未收到agent的回复',
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class StraIsPlaceOrderInPreMarkerTrading(ListHandler):

    def post(self, *args, **kwargs):
        try:
            process_ids = json.loads(str(self.request.body, 'utf-8'))
            logger.info('query stra process: %s', process_ids)
            pid2vid = {}
            vstra_ids = []
            with mysql_sc() as sc:
                querys = sc.query(
                    DeployConfs.id,
                    DeployConfs.vstrategy_id
                ).filter(
                    DeployConfs.id.in_(process_ids)
                ).all()
                for q in querys:
                    if q.vstrategy_id:
                        pid2vid[q.id] = q.vstrategy_id
                        vstra_ids.append(q.vstrategy_id)
                    else:
                        pid2vid[q.id] = 0
            # vstra_ids = [pid2vid[p] if p in pid2vid else 0 for p in process_ids ]
            logger.info('pid2vid: %s', pid2vid)

            placeorder_status = []
            rds = redis.Redis(config.redis['host'], config.redis['port'])
            r_hash = 'oss:monitor:stra_place_order:in_premarket_trading'
            data = rds.hgetall(r_hash)
            logger.info('stra place order: %s', data)
            stra_status = {}
            for k, v in data.items():
                vid = int(json.loads(str(k, 'utf-8')))
                if vid not in vstra_ids:
                    continue
                vstra_info = json.loads(str(v, 'utf-8'))
                stra_status[vid] = vstra_info['is_place_order']
            for p in process_ids:
                vid = pid2vid[p]
                if vid != 0:
                    if vid in stra_status:
                        status = stra_status[vid]
                    else:
                        status = 0
                else:
                    status = -1
                placeorder_status.append(status)
            self.write(json.dumps({
                'code': 0,
                'data': placeorder_status,
            }))
        except Exception as e:
            logger.error(e, exc_info=True)
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class DeployProcessesOffIDHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = None
        self.fields = {}  # key: model-key, value: payload-key
        self.no_login = ['put']

    def put(self, *args, **kwargs):
        vst_id = kwargs.get('vst_id', None)
        if vst_id is None:
            self.write(json.dumps({
                'code': 400,
                'data': 1,
            }))
            return

        with mysql_sc() as sc:
            objs = sc.query(DeployConfs).filter(
                # DeployConfs.valid == 1,
                DeployConfs.vstrategy_id == vst_id,
            )
            for o in objs:
                o.valid = 0
                process_id = o.id
                sc.query(CrontabTasks).filter(CrontabTasks.name == "startday_%s" % process_id).delete()
                sc.query(CrontabTasks).filter(CrontabTasks.name == "stopday_%s" % process_id).delete()
                sc.query(CrontabTasks).filter(CrontabTasks.name == "startnight_%s" % process_id).delete()
                sc.query(CrontabTasks).filter(CrontabTasks.name == "stopnight_%s" % process_id).delete()
                sc.query(CrontabTasks).filter(CrontabTasks.name == "uploadev_%s" % process_id).delete()
        self.write(json.dumps({
            'code': 0,
            'data': 1,
        }))


class TrackingService(object):

    def __init__(self, trade_date, day_night):
        self.sc = session()
        self.trade_date = trade_date
        self.day_night = day_night

    def __del__(self):
        self.sc.close()

    def get_trade_logs(self, account_list):
        trade_logs = self.sc.query(
            TradeLogs.account,
            TradeLogs.symbol,
            TradeLogs.open_close,
            TradeLogs.direction,
            func.sum(TradeLogs.trade_vol).label("trade_vol"),
            func.sum(TradeLogs.trade_vol * TradeLogs.trade_price).label("trade_amount"),
        ).filter(
            TradeLogs.trading_date == self.trade_date,
            # TradeLogs.day_night == self.day_night,
            TradeLogs.log_type == '3',
            TradeLogs.account.in_(account_list),
        ).group_by(
            TradeLogs.account,
            TradeLogs.symbol,
            TradeLogs.open_close,
            TradeLogs.direction,
        )
        return trade_logs

    def get_trade_accounts(self, category):
        """
            获取实盘交易账户
        :return:  account list

        """
        objs = self.sc.query(
            distinct(VStrategyAccountDetail.account)
        ).join(
            VStrategies, VStrategies.id == VStrategyAccountDetail.vstrategy_id
        ).filter(
            VStrategies.status == 15,
        )

        trade_accounts = [o[0] for o in objs]

        category_accounts = []
        if category == "stock":
            objs = self.sc.query(
                distinct(Accounts.name)
            ).filter(
                Accounts.user_id == 494,
            )
            category_accounts = [o[0] for o in objs]
        elif category == "future":
            objs = self.sc.query(
                distinct(Accounts.name)
            ).filter(
                Accounts.user_id == 495,
            )
            category_accounts = [o[0] for o in objs]

        return list(set(trade_accounts).intersection(set(category_accounts)))

    def _calc_trade_vol_v2(self, extra_source: dict, _type: int, ori_data: dict):
        """
        extra_source, supplement from other sources, format
        {
            account_id: {
                instrument_id: [{}, {}, {}]
            }
        }
        _type, 1 or 2, stand for
        [level1-> account, level2-> symbol]
        [level1-> symbol, level2-> account]
        only 1 is supported now

        ori_data, original data, similar format as extra_source
        @return, dict
        """

        if not extra_source:
            return ori_data

        # register useful function
        deliver_days = self.get_deliver_days()

        # loads raw json data to dict
        for i in extra_source:
            extra_source[i] = json.loads(extra_source[i])

        # rephrase data according to type
        if _type == 1:
            # stay the same
            level1 = "account"
            level2 = "symbol"
        elif _type == 2:
            level1 = "symbol"
            level2 = "account"
            # reconstruct extra_source
            union = {}
            for k1 in extra_source:
                for k2 in extra_source[k1]:
                    value = extra_source[k1][k2]
                    for v in value:
                        union.setdefault(v["instrument_id"], {}).setdefault(v["investor_id"], []).append(v)
            extra_source = union

        else:
            logger.warning("unsupported type {}".format(_type))
            return ori_data

        # fields in data
        global_long_vol = 0
        global_short_vol = 0
        global_trade_vol = 0

        """
        [mapping]:
        
        cur_pos:        净持仓量
        short_vol:      空仓 (多仓和空仓的译法并不准确，这里是为了与旧版本兼容)
        long_vol:       多仓 
        trade_vol:      成交量
        open_vol:       开仓量
        close_vol:      平仓量
        
        [calculation formula]:
    
        trade_vol = open_vol + close_vol
        long_vol += pos if pos_direction = 50 
        short_vol += pos if pos_direction = 51
        cur_pos = long_vol - short_vol
        """

        for acc_id, acc_info in extra_source.items():
            acc_data = {level1: acc_id, level2 + "s": []}

            # append "account data" directly, if there are duplicates, consider merging
            if not level1 + "s" in ori_data:
                ori_data[level1 + 's'] = []
            ori_data[level1 + 's'].append(acc_data)

            acc_long_vol = 0
            acc_short_vol = 0
            acc_trade_vol = 0
            for ins_id, ins_arr in acc_info.items():
                # ins_id, instrument_id
                # ins_arr, instrument_array, consisting of trade records for certain instrument
                ins_data = {level2: ins_id}
                acc_data[level2 + 's'].append(ins_data)
                ins_trade_vol = 0
                ins_long_vol = 0
                ins_short_vol = 0

                for record in ins_arr:
                    if record["pos_direction"] == 50:
                        ins_long_vol += record['pos']
                    elif record["pos_direction"] == 51:
                        ins_short_vol += record['pos']
                    ins_trade_vol += record["open_vol"] + record["close_vol"]

                if _type == 1:
                    ins_data["deliver_day"] = deliver_days.get(ins_id, -1)

                ins_data["trade_vol"] = round(ins_trade_vol)
                ins_data["long_vol"] = round(ins_long_vol)
                ins_data["short_vol"] = round(ins_short_vol)
                ins_data["cur_pos"] = round(ins_long_vol - ins_short_vol)

                acc_long_vol += ins_long_vol
                acc_short_vol += ins_short_vol
                acc_trade_vol += ins_trade_vol

            acc_data["trade_vol"] = round(acc_trade_vol)
            acc_data["long_vol"] = round(acc_long_vol)
            acc_data["short_vol"] = round(acc_short_vol)
            acc_data["cur_pos"] = round(acc_long_vol - acc_short_vol)

            global_long_vol += acc_long_vol
            global_short_vol += acc_short_vol
            global_trade_vol += acc_trade_vol

        ori_data["trade_vol"] = ori_data.get("trade_vol", 0) + round(global_trade_vol)
        ori_data["long_vol"] = ori_data.get("long_vol", 0) + round(global_long_vol)
        ori_data["short_vol"] = ori_data.get("short_vol", 0) + round(global_short_vol)
        ori_data["cur_pos"] = ori_data.get("cur_pos", 0) + round(global_long_vol - global_short_vol)

        return ori_data

    def calc_trade_vol(self, type_, category, query=None, append=None, use_log=True):
        """
        type_: either 1 or 2
        append: data from other source except trade log
        use_log: use data from log
        """
        if use_log:
            temp = {}
            temp_lev1 = []
            trade_accounts = self.get_trade_accounts(category)
            trade_logs = self.get_trade_logs(trade_accounts)
            if type_ == 1:
                lev1 = "account"
                lev2 = "symbol"
                lev1_all = trade_accounts
                deliver_days = self.get_deliver_days()
                # TODO: 这里的两层for循环可以简化，逻辑也可以简化。
                # TODO: 对比下用pandas的速度差异
                for o in trade_logs:
                    if query is not None:
                        match = False
                        for q in query:
                            if q in o.account:
                                match = True
                                break
                        if not match:
                            continue
                    temp.setdefault(o.account, {})
                    temp[o.account].setdefault(o.symbol, [])
                    temp[o.account][o.symbol].append(o)
            elif type_ == 2:
                lev1 = "symbol"
                lev2 = "account"
                lev1_all = []
                # TODO: 这里同样
                for o in trade_logs:
                    if query is not None:
                        match = False
                        for q in query:
                            if q in o.symbol:
                                match = True
                                break
                        if not match:
                            continue
                    temp.setdefault(o.symbol, {})
                    temp[o.symbol].setdefault(o.account, [])
                    temp[o.symbol][o.account].append(o)
            else:
                return {}

            # if len(temp) == 0:
            if not temp:
                return {}

            data = {"%ss" % lev1: []}
            total_vol = 0
            long_vol = 0
            short_vol = 0

            for k1, d in temp.items():
                temp_lev1.append(k1)
                lev1_detail = {"%s" % lev1: k1, "%ss" % lev2: []}
                lev1_total_vol = 0
                lev1_long_vol = 0
                lev1_short_vol = 0

                for k2, l in d.items():
                    lev2_detail = {"%s" % lev2: k2}
                    lev2_total_vol = 0
                    b_o_vol = 0
                    b_c_vol = 0
                    s_o_vol = 0
                    s_c_vol = 0
                    for o in l:
                        if o.open_close == 0 and o.direction == 0:
                            b_o_vol += o.trade_vol
                        elif o.open_close == 1 and o.direction == 0:
                            b_c_vol += o.trade_vol
                        elif o.open_close == 0 and o.direction == 1:
                            s_o_vol += o.trade_vol
                        else:  # elif o.open_close == 1 and o.direction == 1:
                            s_c_vol += o.trade_vol
                        lev2_total_vol += o.trade_vol
                    lev2_long_vol = b_o_vol - s_c_vol
                    lev2_short_vol = s_o_vol - b_o_vol
                    # 距离交割日期还剩几天
                    if type_ == 1:
                        lev2_detail["deliver_day"] = deliver_days.get(k2, -1)
                    lev2_detail["trade_vol"] = round(lev2_total_vol)
                    lev2_detail["long_vol"] = round(lev2_long_vol)
                    lev2_detail["short_vol"] = round(lev2_short_vol)
                    lev2_detail["cur_pos"] = round(lev2_long_vol - lev2_short_vol)
                    lev1_detail["%ss" % lev2].append(lev2_detail)
                    lev1_total_vol += lev2_total_vol
                    lev1_long_vol += lev2_long_vol
                    lev1_short_vol += lev2_short_vol

                lev1_detail["%ss" % lev2].sort(key=lambda _x: _x["%s" % lev2])
                lev1_detail["trade_vol"] = round(lev1_total_vol)
                lev1_detail["long_vol"] = round(lev1_long_vol)
                lev1_detail["short_vol"] = round(lev1_short_vol)
                lev1_detail["cur_pos"] = round(lev1_long_vol - lev1_short_vol)
                data["%ss" % lev1].append(lev1_detail)
                total_vol += lev1_total_vol
                long_vol += lev1_long_vol
                short_vol += lev1_short_vol

            data["%ss" % lev1].sort(key=lambda _x: _x["%s" % lev1])
            data["trade_vol"] = round(total_vol)
            data["long_vol"] = round(long_vol)
            data["short_vol"] = round(short_vol)
            data["cur_pos"] = round(long_vol - short_vol)

            if query is None:
                for k in lev1_all:
                    if k in temp_lev1:
                        continue
                    data["%ss" % lev1].append(
                        {
                            "%s" % lev1: k,
                            "trade_vol": 0,
                            "long_vol": 0,
                            "short_vol": 0,
                            "cur_pos": 0,
                            "%ss" % lev2: [],
                        }
                    )
        else:
            data = {}

        if append:
            data = self._calc_trade_vol_v2(append, type_, data)

        return data

    @staticmethod
    def get_deliver_days():
        # df = basic_func.DelistDateMY()
        # df["SYMBOL"] = df["SYMBOL"].str.decode("utf-8")
        # df = df.set_index("SYMBOL")
        # df = df[["DAYS"]]
        # data = df.to_dict()
        # return data["DAYS"]
        return {}


class TrackingHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.no_login = ["get"]

    def get(self, *args, **kwargs):
        """ 
        :TODO: 这个接口的耗时也相当大，同时调用的频率很高，需要优化。
        """
        type = int(self.get_argument("type", -1))
        if type != 1 and type != 2:
            self.write(json.dumps({
                "code": 404,
                "data": 0,
                "error": "Payload data error.",
            }))
            return
        if 'type=stock' in self.request.headers.get('referer', '') or \
                'type%3Dstock' in self.request.headers.get('referer', ''):
            category = "stock"
        elif 'type=future' in self.request.headers.get('referer', '') or \
                'type%3Dfuture' in self.request.headers.get('referer', ''):
            category = "future"
        else:
            self.write(json.dumps({
                "code": 404,
                "data": 0,
                "error": "Referer data error.",
            }))
            return
        trade_date = self.get_argument("trade_date", None)
        day_night = int(self.get_argument("day_night", -1))
        query = self.get_argument("query", None)

        if trade_date is None:
            trade_date = KdbQuery().get_trading_date_now(hour=21).replace('-', '')
        if query is not None:
            query = query.split(',')
            query_add = []
            # query_del = []
            with mysql_sc() as sc:
                accounts_info = sc.query(ShannonLiveAccounts).all()
                for r in query:
                    for o in accounts_info:
                        if o.description and r in o.description:
                            query_add.append(o.name)
                            # query_del.append(r)
            query.extend(query_add)
            # query = list(set(query) - set(query_del))
        tracking = TrackingService(trade_date, day_night)

        # get extradata from redis
        addition = RedisCache(decode_responses=True).get_all_hash_cache(const.RedisKeyConstant.redis_account_key.value)

        data = tracking.calc_trade_vol(type, category, query=query, append=addition, use_log=False)
        self.write(json.dumps({
            "code": APIResponseCode.OK.value,
            "data": data,
        }))


class ShannonLiveAccountsHandler(BaseHandler):

    def get(self, *args, **kwargs):
        data = {}
        try:
            sc = session()
            accounts_info = sc.query(ShannonLiveAccounts).all()
            for r in accounts_info:
                data[r.name] = r.description
            self.write(json.dumps({
                'code': 0,
                'data': data
            }))
        except Exception as e:
            logger.error(e)
            self.write(json.dumps({
                'code': 2203,
                'error': 'get live-account data error'
            }))
        finally:
            sc.close()

    def post(self, *args, **kwargs):
        user_id = self.current_user['id']
        payload = json.loads(str(self.request.body, 'utf-8'))
        account = payload.get('account', None)
        if not account:
            self.write(json.dumps({
                'code': 2203,
                'error': 'payload error',
            }))
            return
        description = payload.get('description', '')
        try:
            sc = session()
            accounts_info = sc.query(ShannonLiveAccounts).filter_by(
                name=account,
            ).first()
            if accounts_info:
                accounts_info.description = description
            else:
                accounts_info = ShannonLiveAccounts(
                    name=account,
                    description=description,
                    create_user_id=user_id,
                )
                sc.add(accounts_info)
            sc.commit()
            self.write(json.dumps({
                'code': 0,
                'data': {
                    account: description,
                },
            }))
        except Exception as e:
            logger.error(e)
            self.write(json.dumps({
                'code': 2204,
                'error': 'update live-account data error'
            }))
        finally:
            sc.close()


class OperateProcessesHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = None
        self.fields = {}  # key: model-key, value: payload-key
        self.no_login = ["get"]

    def get(self, *args, **kwargs):
        data = []
        host = self.get_argument("host", None)
        type = self.get_argument("type", None)
        day_night = self.get_argument("day_night", None)

        if host is None:
            self.write(json.dumps({
                'code': -1,
                'error': 'payload error: host'
            }))
            return

        if type == "0":
            p_type = "agent"
        elif type == "1":
            p_type = "quote"
        elif type == "2":
            p_type = "tunnel"
        elif type == "3":
            p_type = "trader"
            if day_night is None:
                self.write(json.dumps({
                    'code': -1,
                    'error': 'payload error: day_night'
                }))
                return
            day_night = int(day_night)
        else:
            self.write(json.dumps({
                'code': -1,
                'error': 'payload error: type'
            }))
            return

        logger.info("OperateProcessesHandler payload: type %s, host %s, day_night %s" % (type, host, day_night))

        with mysql_sc() as sc:
            processes = sc.query(
                DeployConfs.id, DeployConfs.deploy_path, DeployConfs.day_night, DeployConfs.host,
                DeployConfs.vstrategy_id,
                ProgramTypes.name.label("type_name"),
            ).join(
                ProgramTypes, ProgramTypes.id == DeployConfs.program_type_id,
            ).filter(
                DeployConfs.valid == 1,
                DeployConfs.host == host,
                ProgramTypes.name.like("%_" + str(p_type)),
            )

            if day_night is not None:
                processes = processes.filter(DeployConfs.day_night == day_night)

            if type == "0":
                p = processes.order_by(DeployConfs.id.desc()).first()
                o = sc.query(Programs.version).join(
                    DeployPrograms, Programs.id == DeployPrograms.program_id,
                ).filter(
                    DeployPrograms.host == p.host,
                    DeployPrograms.deploy_path == p.deploy_path,
                    DeployPrograms.day_night == p.day_night,
                ).order_by(DeployPrograms.id.desc()).first()
                version = o.version if o else ''
                online = query_agent_online(config.redis, host)

                line = {
                    "process_id": p.id,
                    "version": version,
                    "status": online,
                }
                data.append(line)

            else:
                for p in processes:
                    o = sc.query(Programs.version).join(
                        DeployPrograms, Programs.id == DeployPrograms.program_id,
                    ).filter(
                        DeployPrograms.host == p.host,
                        DeployPrograms.deploy_path == p.deploy_path,
                        DeployPrograms.day_night == p.day_night,
                    ).order_by(DeployPrograms.id.desc()).first()
                    version = o.version if o else ''

                    online = query_process_online(config.redis, host).get(p.id, 2)

                    if type == "1" or type == "2":
                        os = sc.query(CrontabTasks.scheduler).filter(
                            CrontabTasks.enable == 1,
                            or_(
                                CrontabTasks.name == "startday_" + str(p.id),
                                CrontabTasks.name == "startnight_" + str(p.id),
                            )
                        )
                        scheduler = "|".join([o.scheduler for o in os])

                        line = {
                            "process_id": p.id,
                            "program_type": p.type_name,
                            "version": version,
                            "deploy_path": p.deploy_path,
                            "scheduler": scheduler,
                            "status": online,
                        }
                    else:
                        strategy_detail = []
                        strategy_name = ""
                        vstrategy_id = ""
                        if p.vstrategy_id:
                            vstrategy_id = p.vstrategy_id
                            s = sc.query(VStrategies.symbols_accounts, VStrategies.closing_out, Strategy.name,
                                         Strategy.strategy_type).join(
                                Strategy, Strategy.id == VStrategies.strategy_id,
                            ).filter(
                                VStrategies.id == p.vstrategy_id,
                            ).first()
                            if s:
                                if s.closing_out == 17:
                                    if s.strategy_type in ['01', '03', '04', '05', '06', '11', '12', '13', '14', '23']:
                                        strategy_name = "clear_future.so"
                                    elif s.strategy_type in ['02', '15', '16', '17', '18', '20', '24', '25', '26', '27',
                                                             '28', '30', '31', '32', '33']:
                                        strategy_name = "clear_stock.so"
                                    else:
                                        strategy_name = "clear_position.so"
                                else:
                                    strategy_name = "%s.so" % s.name
                                if day_night == 0:
                                    os = sc.query(CrontabTasks.scheduler).filter(
                                        CrontabTasks.enable == 1,
                                        CrontabTasks.name == "startday_" + str(p.id),
                                    )
                                    scheduler = "|".join([o.scheduler for o in os])
                                    symbols_accounts = s.symbols_accounts.get("day", [])
                                else:
                                    os = sc.query(CrontabTasks.scheduler).filter(
                                        CrontabTasks.enable == 1,
                                        CrontabTasks.name == "startnight_" + str(p.id),
                                    )
                                    scheduler = "|".join([o.scheduler for o in os])
                                    symbols_accounts = s.symbols_accounts.get("night", [])
                                for it in symbols_accounts:
                                    strategy_detail.append(
                                        [it.get("account", ""), it.get("product", ""), it.get("max_vol", "")])
                        line = {
                            "process_id": p.id,
                            "vstrategy_id": vstrategy_id,
                            "strategy_name": strategy_name,
                            "strategy_detail": strategy_detail,
                            "deploy_path": p.deploy_path,
                            "scheduler": scheduler,
                            "status": online,
                        }

                    data.append(line)

        self.write(json.dumps({
            'code': 0,
            'data': data
        }))


class OperateUploadStrategiesHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = None
        self.fields = {}  # key: model-key, value: payload-key
        self.no_login = ["get"]

    def get(self, *args, **kwargs):
        data = []
        host = self.get_argument("host", None)
        deploy_path = self.get_argument("deploy_path", None)

        if host is None or deploy_path is None:
            self.write(json.dumps({
                'code': -1,
                'error': 'payload error: host, deploy_path'
            }))
            return

        logger.info("OperateUploadStrategiesHandler payload: host %s, deploy_path %s" % (host, deploy_path))

        with mysql_sc() as sc:
            vs_confs = sc.query(PreStrategyConfs.vstrategy_id).join(
                Servers, Servers.id == PreStrategyConfs.server_id,
            ).filter(
                Servers.ip == host,
                or_(
                    PreStrategyConfs.day_trader_conf == deploy_path,
                    PreStrategyConfs.night_trader_conf == deploy_path,
                )
            )

            for vso in vs_confs:
                o = sc.query(VStrategies.status, Strategy.name.label("strategy_name"),
                             StrategyPortfolio.name.label("portfolio_name")).join(
                    Strategy, Strategy.id == VStrategies.strategy_id,
                ).join(
                    StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id,
                ).filter(
                    VStrategies.id == vso.vstrategy_id,
                ).first()
                if o.status in [-1, 16]:
                    continue
                data.append({
                    "vstrategy_id": vso.vstrategy_id,
                    "strategy_name": o.strategy_name,
                    "portfolio_name": o.portfolio_name,
                    "deploy_path": deploy_path
                })

        self.write(json.dumps({
            'code': 0,
            'data': data,
        }))


class OperateDeployedProcessesHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = None
        self.fields = {}  # key: model-key, value: payload-key
        self.no_login = ["get"]

    def get(self, *args, **kwargs):
        data = []

        host = self.get_argument("host", None)
        if host is None:
            self.write(json.dumps({
                'code': -1,
                'error': 'payload error: host'
            }))
            return

        with mysql_sc() as sc:
            processes = sc.query(DeployConfs.id, DeployConfs.day_night, ProgramTypes.name.label("program_type"),
                                 DeployConfs.deploy_path).join(
                ProgramTypes, ProgramTypes.id == DeployConfs.program_type_id,
            ).filter(
                DeployConfs.valid == 1,
                DeployConfs.host == host,
                and_(
                    ProgramTypes.name != "bss_agent",
                    ProgramTypes.name != "shannon_trader",
                )
            )
            vs_processes = sc.query(DeployConfs.id, DeployConfs.day_night, ProgramTypes.name.label("program_type"),
                                    DeployConfs.deploy_path).join(
                ProgramTypes, ProgramTypes.id == DeployConfs.program_type_id,
            ).join(
                VStrategies, VStrategies.id == DeployConfs.vstrategy_id,
            ).filter(
                DeployConfs.valid == 1,
                DeployConfs.host == host,
                ProgramTypes.name == "shannon_trader",
                VStrategies.status == 15,
            )

            for p in processes:
                data.append({"process_id": p.id, "day_night": p.day_night, "program_type": p.program_type,
                             "deploy_path": p.deploy_path})
            for p in vs_processes:
                data.append({"process_id": p.id, "day_night": p.day_night, "program_type": p.program_type,
                             "deploy_path": p.deploy_path})

        self.write(json.dumps({
            'code': 0,
            'data': data,
        }))


class PreMergeStrategyListHandler(BaseHandler):

    def get(self, *args, **kwargs):
        data = []

        server_id = self.get_argument("server_id", None)
        if server_id is None:
            self.write(json.dumps({
                'code': -1,
                'error': 'payload error: server_id'
            }))
            return
        try:
            server_id = int(server_id)

            with mysql_sc() as sc:
                lines = sc.query(
                    Strategy.name, VStrategies.id, VStrategies.symbols_accounts, PreStrategyConfs.server_id,
                    PreStrategyConfs.tcp_conf, Servers.ip
                ).join(
                    VStrategies, VStrategies.strategy_id == Strategy.id,
                ).join(
                    PreStrategyConfs, PreStrategyConfs.vstrategy_id == VStrategies.id,
                ).join(
                    Servers, Servers.id == PreStrategyConfs.server_id
                ).filter(
                    PreStrategyConfs.server_id == server_id,
                    Strategy.strategy_type == "31",
                    VStrategies.status != -1,
                    VStrategies.status != 16,
                )

                for o in lines:

                    tcp_conf = ""
                    if o.tcp_conf and len(o.tcp_conf.split(",")):
                        tcp_conf = "client,{server_ip},{tcp_conf}".format(
                            server_ip=o.ip,
                            tcp_conf=o.tcp_conf.split(",")[-1]
                        )

                    account = ""
                    if o.symbols_accounts:
                        if o.symbols_accounts.get("day", []):
                            account = o.symbols_accounts.get("day")[0]["account"]
                        elif o.symbols_accounts.get("night", []):
                            account = o.symbols_accounts.get("night")[0]["account"]

                    data.append({"so_name": "%s.so" % o.name, "vstrategy_id": o.id, "account": account,
                                 "server_id": o.server_id, "tcp_conf": tcp_conf})

            self.write(json.dumps({
                'code': 0,
                'data': data,
            }))

        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': -1,
                'error': str(e)
            }))

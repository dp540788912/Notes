#-*-coding:utf-8-*-

import netifaces


class CommonConfig(object):
    Debug = True
    kdb = {
        'host': '192.168.1.41',
        'port': 9000,
        'user': 'superuser1',
        'passwd': 'password',
    }
    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql
    redis = {
        'host': '127.0.0.1',
        'port': '6379',
        'cmd_key': 'oss:a:cmd:',
        'rsp_key': 'a:oss:rsp:',
        'conf_update_timestamp': 'oss:process:conf:update:timestamp'
    }
    local = {
        'host': '127.0.0.1',
        'user': 'rss',
        'vpn': '127.0.0.1',
        'tun': '127.0.0.1',
        'szvpn': '127.0.0.1',
    }
    platform = {
        'st_url': 'http://127.0.0.1/api/v1/strategy_upload/strategy/deploy/',
        'media': '/home/rss/bss_server/site/media',
        'settle_url': 'http://192.168.4.206:7000',
        'settle_path': '/home/rss/bss_server/new_settlement',
    }

    ev_conf = {
        'base_path': '/home/rss/jupyter_userworkspace',
        'sub_path': 'strategy/ev'
    }


class ProductionConfig_180(CommonConfig):
    Debug = False
    mysql = {
        'host': '192.168.1.175',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql
    redis = {
        'host': '192.168.1.180',
        'port': '6379',
        'cmd_key': 'oss:a:cmd:',
        'rsp_key': 'a:oss:rsp:',
        'conf_update_timestamp': 'oss:process:conf:update:timestamp'
    }
    local = {
        'host': '192.168.1.180',
        'user': 'rss',
        'vpn': '192.168.30.154',
        'tun': '192.168.30.154',
        'szvpn': '192.168.30.154',
    }
    platform = {
        'st_url': 'http://192.168.1.14/api/v1/strategy_upload/strategy/deploy/',
        'media': '/home/rss/platform_strat',
        'settle_url': 'http://192.168.1.14:7000',
        'settle_path': '/home/rss/bss_server/new_settlement',
    }


class ProductionConfig_IDC(CommonConfig):
    Debug = False
    kdb = {
        'host': '192.168.10.102',
        'port': 9000,
        'user': 'superuser1',
        'passwd': 'password',
    }
    mysql = {
        'host': '192.168.10.80',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql
    local = {
        'host': '192.168.10.100',
        'user': 'rss',
        'vpn': '192.168.30.100',
        'tun': '10.10.40.6',
        'szvpn': '192.168.40.100',
    }
    platform = {
        'st_url': 'http://127.0.0.1/api/v1/strategy_upload/strategy/deploy/',
        'media': '/home/rss/media',
        'settle_url': 'http://192.168.10.101:7000',
        'settle_path': '/home/rss/bss_server/new_settlement',
    }
    ev_conf = {
        'base_path': '/home/rss/jupyter_userworkspace',
        'sub_path': 'strategy/ev'
    }


class DebugConfig_170(CommonConfig):
    mysql = {
        'host': '192.168.1.214',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql
    local = {
        'host': '192.168.1.170',
        'user': 'rss',
        'vpn': '192.168.30.170',
        'tun': '192.168.30.170',
        'szvpn': '192.168.40.100',
    }
    platform = {
        'st_url': 'http://192.168.1.214/api/v1/strategy_upload/strategy/deploy/',
        'media': '/home/rss/platform_strat_214',
        'settle_url': 'http://192.168.1.214:7000',
        'settle_path': '/home/rss/bss_server/new_settlement',
    }


class DebugConfig_13(CommonConfig):
    local = {
        'host': '192.168.1.13',
        'user': 'rss',
        'vpn': '192.168.30.13',
        'tun': '192.168.30.13',
        'szvpn': '192.168.30.13',
    }


class DebugConfig_14(CommonConfig):
    local = {
        'host': '192.168.1.14',
        'user': 'rss',
        'vpn': '192.168.30.14',
        'tun': '192.168.30.14',
        'szvpn': '192.168.30.14',
    }


class DebugConfig_27(CommonConfig):
    # use mysql connector driver, otherwise segment fault always pop up
    CommonConfig.mysql['db_uri'] = 'mysql+mysqlconnector://dev2:admin123@192.168.30.100:3306/datahub'

class DebugConfig_128(CommonConfig):
    mysql = {
        'host': '192.168.30.100',
        'port': 3306,
        'db': 'datahub',
        'user': 'dev2',
        'passwd': 'admin123',
    }
    # use mysql connector driver, otherwise segment fault always pop up
    mysql['db_uri'] = 'mysql+mysqlconnector://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql
    platform = {
        'st_url': 'http://192.168.30.100/api/v1/strategy_upload/strategy/deploy/',
        'media': '/home/rss/bss_server/site/media',
        'settle_url': 'http://192.168.4.206:7000',
        'settle_path': '/home/rss/bss_server/new_settlement',
    }

iplist = [netifaces.ifaddresses(i).get(netifaces.AF_INET)[0]['addr']
          for i in netifaces.interfaces() if netifaces.ifaddresses(i).get(netifaces.AF_INET)]

product_idc_list = ['192.168.10.100']
debug_170_iplist = ['192.168.1.170']
debug_13_iplist = ['192.168.1.13']
debug_14_iplist = ['192.168.1.14']
debug_128_iplist = ['192.168.88.128']


if any([i in iplist for i in product_idc_list]):
    Debug = False
    config = ProductionConfig_IDC()
elif any([i in iplist for i in debug_170_iplist]):
    Debug = True
    config = DebugConfig_170()
elif any([i in iplist for i in debug_13_iplist]):
    Debug = True
    config = DebugConfig_13()
elif any([i in iplist for i in debug_14_iplist]):
    Debug = True
    config = DebugConfig_14()
elif any([i in iplist for i in debug_128_iplist]):
    Debug = True
    config = DebugConfig_128()
else:
    Debug = True
    config = CommonConfig()

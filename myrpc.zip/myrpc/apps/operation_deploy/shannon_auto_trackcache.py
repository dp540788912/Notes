# encoding: utf-8 

# TODO: 该模块有单点风险
import time
import datetime
import subprocess
import const
import copy 
import redis
import hashlib
import glob 
from config import config
from kdb_query import KdbQuery
from utils import RedisCache
from handlers import TrackingService



def auto_calc_trade_vol():

    try:
        cache_key_1 = "tradingtrack_1_stock__"
        cache_key_2 = "tradingtrack_1_future__"
        cache_key_3 = "tradingtrack_2_stock__"
        cache_key_4 = "tradingtrack_2_future__"

        c = RedisCache()
        trade_date = KdbQuery().get_trading_date_now(hour=21)
        day_night = -1
        tracking = TrackingService(trade_date, day_night)

        data = tracking.calc_trade_vol(1, "stock")
        c.set_cache(cache_key_1, data, 30)

        data = tracking.calc_trade_vol(1, "future")
        c.set_cache(cache_key_2, data, 30)

        data = tracking.calc_trade_vol(2, "stock")
        c.set_cache(cache_key_3, data, 30)

        data = tracking.calc_trade_vol(2, "future")
        c.set_cache(cache_key_4, data, 30)

    except Exception as e:
        print(e)


if __name__ == '__main__':

    while True:
        auto_calc_trade_vol()
        time.sleep(10)


# -*- coding:utf-8 -*-

import time
import datetime
import json
import redis

from db import session_context as mysql_sc, engine
from models import *
from kdb_query import KdbQuery
from notify import notify_wechat

from log import logger


g_on_off = 0

conf = {
    'ip': '127.0.0.1',
    'port': '6379',
    'namespace': 'a:oss:trade'
}
unify_value = {
    0: 0,
    1: 1,
    2: 2,
    3: 3,
    4: 4,
    48: 0,
    49: 1,
    50: 2,
    51: 3,
    52: 4
}

exch_value = {
    48: "SZSE",
    49: "SSE",
    65: "SHFE",
    66: "DCE",
    67: "CZCE",
    71: "CFFEX",
    50: "HKEx",
    68: "SGE",
    83: "SGX",
}

rds = redis.Redis(conf['ip'], conf['port'])


def parse_timestamp(time_stamp, k_obj):
    localtime = time.localtime(time_stamp)
    calendar_date = time.strftime('%Y-%m-%d', localtime)
    calendar_time = time.strftime('%H:%M:%S', localtime)
    if '07:00:00' < calendar_time < '19:00:00':
        day_night = 0
        internal_date = calendar_date
        trading_date = calendar_date
    else:
        day_night = 1
        d = datetime.datetime.strptime(calendar_date, '%Y-%m-%d')
        if '00:00:00' <= calendar_time < '07:00:00':
            internal_date = datetime.datetime.strftime(d - datetime.timedelta(days=1), '%Y-%m-%d')
            try:
                trading_date = k_obj.get_trading_date(calendar_date, 0)
            except Exception as e:
                if d.weekday() == 5:
                    trading_date = datetime.datetime.strftime(d + datetime.timedelta(days=2), '%Y-%m-%d')
                else:
                    trading_date = datetime.datetime.strftime(d, '%Y-%m-%d')
        else:
            internal_date = datetime.datetime.strftime(d, '%Y-%m-%d')
            try:
                trading_date = k_obj.get_trading_date(calendar_date, 1)
            except Exception as e:
                if d.weekday() == 4:
                    trading_date = datetime.datetime.strftime(d + datetime.timedelta(days=3), '%Y-%m-%d')
                else:
                    trading_date = datetime.datetime.strftime(d + datetime.timedelta(days=1), '%Y-%m-%d')
    return trading_date, calendar_time, day_night, internal_date, calendar_date


def parse_trigger(trigger):
    try:
        if trigger == '-1':
            return None
        trigger = trigger.zfill(9)
        trigger = str(int(trigger[:2]) % 24) + trigger[2:]
        trigger = trigger.zfill(9)
        t = datetime.datetime.strptime(trigger, '%H%M%S%f')
        return datetime.datetime.strftime(t, '%H:%M:%S.%f')
    except Exception as e:
        return None

def check_trading_time(n):
    #n = datetime.datetime.now().strftime("%H:%M:%S")
    if (n >= "06:00:00" and n < "08:50:00"):
        return False
    elif (n >= "15:35:00" and n < "20:30:00"):
        return False
    else:
        return True

def check_test_strategy(vstrategy_id):
    with mysql_sc() as sc:
        vss = sc.query(VStrategies.id).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id,
        ).filter(
            VStrategies.status == 15,
            StrategyPortfolio.r_create_user_id == 26,
        )
        test_vss = [o.id for o in vss]
        return vstrategy_id in test_vss


def parse_trade_time(trade_time):
    try:
        t_sec = trade_time[-9:-3]
        t_microsec = int(trade_time[-3:]) * 1000
        t_time = "%s:%s:%s" % (t_sec[:2], t_sec[2:4], t_sec[4:])
        return t_time, t_microsec
    except Exception as e:
        return "", 0


def write_logs(k_obj, host):
    tradelog_lists = []
    turingtradelog_lists = []
    if host == '192.168.30.13':
        return

    rq = ':'.join([conf['namespace'], host])
    for i in range(10000):
        d = rds.lpop(rq)
        if not d:
            # TODO：改成批量写数据库的方法。
            if tradelog_lists:
                with mysql_sc() as sc:
                    sc.execute(TradeLogs.__table__.insert(), tradelog_lists)
                    sc.commit()
            if turingtradelog_lists:
                with mysql_sc() as sc:
                    sc.execute(TuringTradeLogs.__table__.insert(), turingtradelog_lists)
                    sc.commit()
            return
        try:
            # TODO：可以提前确定的语句，请移到循环外面
            dtorq = 'a:dto:trade_log'
            rds.rpush(dtorq, d)

            data = json.loads(str(d, 'utf-8'))
            time_stamp = data['time_stamp']
            time_sec = data['time_stamp']/(10**9)
            time_microsec = data['time_stamp']%(10**9)/(10**3)
            trading_date, calendar_time, day_night, internal_date, calendar_date = parse_timestamp(time_sec, k_obj)
            if not check_trading_time(calendar_time):
                continue
            if check_test_strategy(data['strategy_id']):
                continue
            if g_on_off == 1:
                if data['account'] in ['80030010', '006571'] and data['msg_type'] != '3':
                    continue

            quote_trigger = parse_trigger(str(data.get('trigger', -1)))
            account = data['account']
            if account == 'myyh02&91010602':
                account = 'myyh02&91010602-000'
            elif account in ('p5938', 'P5938'):
                account = '5938'

            if int(data['strategy_id']) > 500:
                record = {
                    'trading_date': trading_date,
                    'calendar_time': calendar_time,
                    'calendar_microsec': time_microsec,
                    'internal_date': internal_date,
                    'calendar_date': calendar_date,
                    'day_night': day_night,
                    'server': data['server'],
                    'account': account,
                    'log_type': data['msg_type'],
                    'vstrategy_id': data['strategy_id'],
                    'serial_no': str(data['serial_no']).zfill(20),
                    'cancel_serial_no': str(data['cancel_serial_no']).zfill(20),
                    'symbol': data['symbol'],
                    'direction': int(chr(data['direction'])),
                    'open_close': int(chr(data['open_close'])),
                    'order_price': data['price'],
                    'order_vol': data['volume'],
                    'entrust_no': data['entrust_no'],
                    'entrust_status': chr(data['entrust_status']),
                    'trade_price': data['trade_price'],
                    'trade_vol': data['trade_vol'] if data['trade_vol'] < 1000000 else 0,
                    'remain_vol': data['vol_remain'] if data['vol_remain'] < 1000000 else 0,
                    'trade_no': data['trade_no'],
                    'speculator': int(chr(data['speculator'])),
                    'order_price_type': int(chr(data['order_price_type'])),
                    'order_type': int(chr(data['order_type'])),
                    'error_no': data['error_no'],
                    'cp_open_vol_remain': data['open_vol_remain'],
                    'cp_cancel_vol_remain': data['n_cancel_remain'],
                }
                if quote_trigger is not None:
                    record['quote_trigger'] = quote_trigger
                if data.get('rdtsc_timestamp', None) is not None:
                    record['rdtsc'] = data['rdtsc_timestamp']
                if "exchange_type" in data:
                    record['server'] = exch_value.get(data["exchange_type"], "")
                if data.get("trade_time", ""):
                    t_time, t_microsec = parse_trade_time(data["trade_time"])
                    if t_time:
                        record["exchange_time"] = t_time
                        record["exchange_microsec"] = t_microsec
                tradelog_lists.append(record)
            else:
                try:
                    speculator = 8 if int(chr(data['speculator'])) == 8 else 0
                except Exception as e:
                    speculator = 0

                record = {
                    'trading_date': trading_date,
                    'calendar_time': calendar_time,
                    'calendar_microsec': time_microsec,
                    'internal_date': internal_date,
                    'calendar_date': calendar_date,
                    'day_night': day_night,
                    'server': data['server'],
                    'account': account,
                    'log_type': data['msg_type'],
                    'vstrategy_id': data['strategy_id'],
                    'serial_no': str(data['serial_no']).zfill(20),
                    'cancel_serial_no': str(data['cancel_serial_no']).zfill(20),
                    'symbol': data['symbol'],
                    'direction': int(chr(data['direction'])),
                    'open_close': int(chr(data['open_close'])),
                    'order_price': data['price'],
                    'order_vol': data['volume'],
                    'entrust_no': data['entrust_no'],
                    'entrust_status': chr(data['entrust_status']),
                    'trade_price': data['trade_price'],
                    'trade_vol': data['trade_vol'] if data['trade_vol'] < 1000000 else 0,
                    'remain_vol': data['vol_remain'] if data['vol_remain'] < 1000000 else 0,
                    'trade_no': data['trade_no'],
                    'speculator': speculator,
                    'order_price_type': int(chr(data['order_price_type'])),
                    'order_type': int(chr(data['order_type'])),
                    'error_no': data['error_no'],
                    'cp_open_vol_remain': data['open_vol_remain'],
                    'cp_cancel_vol_remain': data['n_cancel_remain'],
                }
                if quote_trigger is not None:
                    record['quote_trigger'] = quote_trigger
                if data.get('rdtsc_timestamp', None) is not None:
                    record['rdtsc'] = data['rdtsc_timestamp']
                turingtradelog_lists.append(record)

            if i == 9999:
                if tradelog_lists:
                    with mysql_sc() as sc:
                        sc.execute(TradeLogs.__table__.insert(), tradelog_lists)
                        sc.commit()
                if turingtradelog_lists:
                    with mysql_sc() as sc:
                        sc.execute(TuringTradeLogs.__table__.insert(), turingtradelog_lists)
                        sc.commit()
        except Exception as e:
            notify_users = [
                'LiZhiBingsandy',
                'LiShaoFeng',
                'HuBo',
            ]
            message = '[TradeLogs Error] error= %s, data= %s' % (str(e), d)
            notify_wechat(notify_users, message)


def write_internal_cancel_orders(k_obj, host):
    if host == '192.168.30.13':
        return
    reject_lists = []
    rq = ':'.join(['a:oss:internal_cancel_orders', host])
    for i in range(10000):
        try:
            d = rds.lpop(rq)
            if not d:
                if reject_lists:
                    with mysql_sc() as sc:
                        sc.execute(StrategyOrdersRejected.__table__.insert(), reject_lists)
                        sc.commit()
                return

            data = json.loads(str(d, 'utf-8', 'ignore'))
            time_sec = data['clock']
            time_microsec = data['ms']
            trading_date, calendar_time, day_night, internal_date, calendar_date = parse_timestamp(time_sec, k_obj)
            if not check_trading_time(calendar_time):
                continue
            if check_test_strategy(data['st_id']):
                continue

            record = {
                'calendar_date': calendar_date,
                'calendar_time': calendar_time,
                'calendar_microsec': time_microsec,
                'trading_date': trading_date,
                'internal_date': internal_date,
                'day_night': day_night,
                'vstrategy_id': data['st_id'],
                'serial_no': str(data['order_id']).zfill(20),
                'cancel_serial_no': str(data['org_ord_id']).zfill(20),
                'exchange': str(data['exch']),
                'symbol': data['symbol'],
                'direction': unify_value[int(data['direction'])],
                'open_close': unify_value[int(data['open_close'])],
                'price': data['price'],
                'volume': data['volume'],
                'order_type': int(data['order_type']),
                'investor_type': int(data['investor_type']),
                'time_in_force': int(data['time_in_force']),
                'error_no': int(data['err_code']),
                'error_msg': data['err_msg'],
            }
            reject_lists.append(record)
            if i == 9999:
                if reject_lists:
                    with mysql_sc() as sc:
                        sc.execute(StrategyOrdersRejected.__table__.insert(), reject_lists)
                        sc.commit()
        except Exception as e:
            logger.error(str(e))
            logger.error('above exception was cause by %s' % data)


def get_tradelog_switch():
    rq = 'switch:trade_logs'
    try:
        d = rds.lpop(rq)
        if not d:
            return
        data = json.loads(str(d, 'utf-8', 'ignore'))
        g_on_off = data["on_off"]
    except Exception as e:
        logger.error(str(e))


if __name__ == '__main__':
    k_obj = KdbQuery()
    while True:
        try:
            get_tradelog_switch()

            if not k_obj.check():
                k_obj.reconnect()
            hosts = rds.smembers('a:oss:hosts')
            for h in hosts:
                host = str(h, 'utf-8')

                write_logs(k_obj, host)
                write_internal_cancel_orders(k_obj, host)
        except Exception as e:
            raise e
            logger.error(str(e))

        time.sleep(0.1)

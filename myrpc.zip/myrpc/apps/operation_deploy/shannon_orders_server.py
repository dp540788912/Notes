# -*- coding:utf-8 -*-

import math
import time
import datetime
import json
import redis

from db import session_context as mysql_sc
from models import *
from kdb_query import KdbQuery

from log import logger


conf = {
    'ip': '127.0.0.1',
    'port': '6379',
    'namespace': 'a:oss:parent_child_orders'
}


rds = redis.Redis(conf['ip'], conf['port'])


def parse_timestamp(time_stamp, k_obj):
    localtime = time.localtime(time_stamp)
    calendar_date = time.strftime('%Y-%m-%d', localtime)
    calendar_time = time.strftime('%H:%M:%S', localtime)
    if '05:00:00' < calendar_time < '17:00:00':
        day_night = 0
        internal_date = calendar_date
        trading_date = calendar_date
    else:
        day_night = 1
        d = datetime.datetime.strptime(calendar_date, '%Y-%m-%d')
        if '00:00:00' <= calendar_time < '05:00:00':
            internal_date = datetime.datetime.strftime(d - datetime.timedelta(days=1), '%Y-%m-%d')
            try:
                trading_date = k_obj.get_trading_date(calendar_date, 0)
            except Exception as e:
                if d.weekday() == 5:
                    trading_date = datetime.datetime.strftime(d + datetime.timedelta(days=2), '%Y-%m-%d')
                else:
                    trading_date = datetime.datetime.strftime(d, '%Y-%m-%d')
        else:
            internal_date = datetime.datetime.strftime(d, '%Y-%m-%d')
            try:
                trading_date = k_obj.get_trading_date(calendar_date, 1)
            except Exception as e:
                if d.weekday() == 4:
                    trading_date = datetime.datetime.strftime(d + datetime.timedelta(days=3), '%Y-%m-%d')
                else:
                    trading_date = datetime.datetime.strftime(d + datetime.timedelta(days=1), '%Y-%m-%d')
    return trading_date, calendar_time, day_night, internal_date, calendar_date


def format_mstime(mstime):
    t = str(mstime).zfill(9)
    s = t[:2] + ':' + t[2:4] + ':' + t[4:6]
    ms = int(t[6:9])
    return s, ms


def parse_trigger(trigger):
    if trigger == '-1':
        return None
    trigger = trigger.zfill(9)
    t = datetime.datetime.strptime(trigger, '%H%M%S%f')
    return datetime.datetime.strftime(t, '%H:%M:%S.%f')


def check_trading_time(n):
    #n = datetime.datetime.now().strftime("%H:%M:%S")
    if (n >= "06:00:00" and n < "08:50:00"): 
        return False
    elif (n >= "15:35:00" and n < "20:30:00"):
        return False
    else:
        return True


def write_orders():
    k_obj = KdbQuery()
    while True:
        try:
            if not k_obj.check():
                k_obj.reconnect()
            for i in range(100):
                rq = conf['namespace']
                d = rds.lpop(rq)
                if not d:
                    break
                msg = json.loads(str(d, 'utf-8'))
                data = msg['data']
                # TODO: Move the next sentence outside of the loop.
                trading_date, calendar_time, day_night, internal_date, calendar_date = parse_timestamp(data['clock'], k_obj)
                if not check_trading_time(calendar_time):
                    continue
                with mysql_sc() as sc:
                    # parent order
                    if msg['type'] == 1:
                        start_time, start_time_ms = format_mstime(data['start_time'])
                        end_time, end_time_ms = format_mstime(data['end_time'])
                        record = {
                            'parent_order_id': str(data['parent_order_id']).zfill(20),
                            'vstrategy_id': data['st_id'] if 'st_id' in data else data['parent_order_id'] % (10**6),
                            'symbol': data['symbol'],
                            'parent_order_size': data['parent_order_size'],
                            'limit_price': data['limit_price'],
                            'algorithm': data['algorithm'],   # algorithm: 1-DMA; 2-VWAP; 3-TWAP;
                            'side': data['side'],    #direction 1-buy, 2-sell
                            'start_time': start_time,
                            'start_time_ms': start_time_ms,
                            'end_time': end_time,
                            'end_time_ms': end_time_ms,
                            'timestamp': calendar_time,
                            'timestamp_ms': data['ms'],
                            'internal_date': internal_date,
                            'calendar_date': calendar_date,
                            'day_night': day_night,
                            'trading_date': trading_date,

                        }
                        o = ParentOrder(**record)
                        sc.add(o)
                    # children order
                    elif msg['type'] == 2:
                        record = {
                            'child_order_id': str(data['child_order_id']).zfill(20),
                            'vstrategy_id': data['st_id'] if 'st_id' in data else data['child_order_id'] % (10**6),
                            'parent_order_id': str(data['parent_order_id']).zfill(20),
                            'child_order_size': data['child_order_size'],
                            'execution_price': data['execution_price'],
                            'order_type': data['order_type'],   # order_type: 1：PASSIVE; 2:AGGRESSIVE;
                            'indicator': -999999 if math.isinf(data['indicator']) and data['indicator'] < 0 else data['indicator'],
                            'timestamp': calendar_time,
                            'timestamp_ms': data['ms'],
                            'internal_date': internal_date,
                            'calendar_date': calendar_date,
                            'day_night': day_night,
                            'trading_date': trading_date,
                        }
                        o = ChildrenOrder(**record)
                        sc.add(o)
                    else:
                        logger.error("parent order orders' type error.")
            time.sleep(1)
        except Exception as e:
            logger.error(str(e))


if __name__ == '__main__':
    write_orders()

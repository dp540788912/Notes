# -*-coding:utf-8-*-
from enum import Enum
# DIGICCY
DIGICCY_EXCHANGE = [
    'BINANCE', 'BITFINEX', 'BITMEX', 'BITSTAMP', 'BITTREX',
    'HUOBI', 'KRAKEN', 'GDAX', 'GATECOIN', 'BTCC', 'OKCOIN',
    'POLONIEX', 'QUOINE', 'HITBTC', 'FCOIN'
]

symbol_exchg = {
    'gemini': 'GEMINI',
    'zb': 'ZB',
    'bx': 'BX',
    'coinw': 'COINW',
    'gdax': 'GDAX',
    'bitmex': 'BITMEX',
    'bitfinex': 'BITFINEX',
    'bitstamp': 'BITSTAMP',
    'kraken': 'KRAKEN',
    'binance': 'BINANCE',
    'okcoin': 'OKEX',
    'huobi': 'HUOBI',
    'hitbtc': 'HITBTC',
    'fcoin': 'FCOIN'
}


# API Response Code
class APIResponseCode(Enum):
    OK = 0
    DefaultError = -1


class RedisKeyConstant(Enum):
    redis_account_key = "a:oss:turing:position_complete"


# 策略ev和log命名规则分割线
STRA_NAME_CUT_OFF_RULE = 1234



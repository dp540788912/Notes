#-*- coding: utf-8 -*-

import json
import tornado.ioloop
import tornado.web

from sqlalchemy.sql import func
from db import Session, session_context as mysql_sc
from models import *


class DeployResultHandler(tornado.web.RequestHandler):

    def initialize(self, *args, **kwargs):
        self.model = DeployResult

    def get(self, *args, **kwargs):
        res = []
        with mysql_sc() as sc:
            lines = sc.query(
                self.model.server,
                self.model.trader_deploy_path,
                func.max(self.model.version),
            ).group_by(
                self.model.server,
                self.model.trader_deploy_path,
            ).all()
            for line in lines:
                server = line[0]
                trader_deploy_path = line[1]
                version = line[2]
                rows = sc.query(self.model).filter(
                    self.model.server==server,
                    self.model.trader_deploy_path==trader_deploy_path,
                    self.model.version==version,
                ).all()
                for row in rows:
                    res.append(row.to_dict())
                
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def put(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def delete(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))



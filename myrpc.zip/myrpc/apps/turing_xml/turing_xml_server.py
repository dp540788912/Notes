#-*- coding: utf-8 -*-

import tornado.ioloop
import tornado.web

from handlers import *

urls = [
    (r"/api/v1/turing/trader/xml$", DeployResultHandler),
]

def make_app():
    return tornado.web.Application(urls)


if __name__ == "__main__":
    app = make_app()
    app.listen(18886)
    tornado.ioloop.IOLoop.current().start()


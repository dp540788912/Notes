#-*-coding:utf-8-*-


class CommonConfig(object):
    pass


class ProductionConfig(CommonConfig):

    mysql = {
        'host': '192.168.1.175',
        'port': 3306,
        'db': 'rss',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql


class DebugConfig(CommonConfig):

    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'rss',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql


Debug = False

if Debug:
    config = DebugConfig()
else:
    config = ProductionConfig()

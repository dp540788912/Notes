#-*-coding:utf-8-*-

from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from sqlalchemy import Column, ForeignKey
from sqlalchemy.dialects.mysql import BIGINT, DATETIME, DATE, TIME, INTEGER, VARCHAR, TEXT, LONGTEXT, FLOAT, DOUBLE, BOOLEAN, JSON

from db import ModelBase, session_context as mysql_sc


class DeployResult(ModelBase):

    __tablename__ = 'deploy_result'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    create_time = Column(DATETIME, nullable=True, server_default=func.now())
    update_time = Column(DATETIME, nullable=True, server_default=func.now(), onupdate=func.now())
    create_user = Column(VARCHAR(32), nullable=True)
    update_user = Column(VARCHAR(32), nullable=True)
    server = Column(VARCHAR(45))
    exchange = Column(VARCHAR(10))
    account = Column(VARCHAR(32))
    trader_deploy_path = Column(VARCHAR(128))
    trader_file_version = Column(VARCHAR(64))
    trader_template_name = Column(VARCHAR(128))
    product = Column(VARCHAR(10))
    symbol = Column(VARCHAR(10))
    so_name = Column(VARCHAR(45))
    so_file_version = Column(VARCHAR(128))
    product_max_size = Column(INTEGER)
    st_max_size = Column(INTEGER)
    day_night = Column(INTEGER)
    ev_version = Column(VARCHAR(64))
    model_setting_version = Column(VARCHAR(64))
    version = Column(VARCHAR(64))
    cpu_id = Column(VARCHAR(16))

    def to_dict(self):
        return {
            'account': self.account,
            'symbol': self.symbol,
            'so_name': self.so_name,
        }


if __name__ == '__main__':
    from db import engine
    ModelBase.metadata.create_all(engine)

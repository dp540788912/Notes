#-*-coding:utf-8-*-

import sys
rpcpath = sys.path.append('/home/yinsong/workspace/myrpc')


from apps.log_report.models import PostTradeSimLogTmp
from sqlalchemy.sql import func
from db import session_context as mysql_sc

symnol = 'jd1705'
trading_date = '20170320'
#
# with mysql_sc() as sc:
#     lines = sc.query(
#         PostTradeSimLogTmp.direction,
#         PostTradeSimLogTmp.open_close,
#         func.sum(PostTradeSimLogTmp.trade_vol).label('sum_trade_vol')
#     ).filter(
#         PostTradeSimLogTmp.day_night==0,
#         PostTradeSimLogTmp.symbol==symnol.lower(),
#         PostTradeSimLogTmp.trading_date==trading_date,
#     ).group_by(PostTradeSimLogTmp.direction, PostTradeSimLogTmp.open_close).all()
#     for l in lines:
#         print(l)


def get_logs(data):
    trading_date = data['date']
    day_night = int(data['day_night'])
    symbol = data['symbol'].upper()
    model_id = int(data['strategy_id']) + 10000
    query_filter = [
        PostTradeSimLogTmp.model_id == model_id,
        PostTradeSimLogTmp.day_night == day_night,
        PostTradeSimLogTmp.symbol == symbol.lower(),
        PostTradeSimLogTmp.trading_date == trading_date,
    ]
    return PostTradeSimLogTmp.logs(query_filter)


data = {
    'date': '2017-04-14',
    'day_night': 0,
    'symbol': 'zn1706',
    'strategy_id': -91,
}

from pprint import pprint

pprint(get_logs(data))

#-*-coding:utf-8-*-

import sys
rpcpath = sys.path.append('/home/yinsong/workspace/myrpc')



from rpc import Client

service = 'log_report'


c = Client(service=service, host='192.168.3.39', port=8768)

data = "Test log 11111111111111"

res = c.write(data)

print(res)

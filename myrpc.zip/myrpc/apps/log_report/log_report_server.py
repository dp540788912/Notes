#-*-coding:utf-8-*-

import os
import sys

rpcpath = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
if rpcpath not in sys.path:
    sys.path.append(rpcpath)


from rpc import Server, Router
from apps.log_report.models import PostTradeSimLogTmp
from db import session_context as mysql_sc
from config import Debug

log_report = Router('log_report')


@log_report.register()
def write(data):
    line = data['message']
    filename = data['path'].rsplit('/')[-1]
    names = filename.split('_')
    trading_date = names[1]
    day_night = int(names[2])
    line = line.strip('\r\n').strip('\n')
    values = line.split(';')
    res = {
        'trading_date': trading_date,
        'day_night': day_night,
    }
    keys = [
        'msgtype', 'symbol', 'model_id', 'direction', 'open_close', 'trade_vol',
        'serial_no', 'cancel_serial_no', 'entrust_no', 'entrust_status'
            ]
    for i, v in enumerate(values):
        if i == 0:
            res['log_time'] = v.split(' - ')[0]
            res['msgtype'] = v[v.index('[') + 1: v.index(']')]
        v = v.strip(' ').split(': ')
        if v[0] in keys:
            res[v[0]] = v[1]
    # if int(res['model_id']) < 10000:
    #     return {
    #         'code': 1000
    #     }
    with mysql_sc() as sc:
        log_line = PostTradeSimLogTmp(
            log_time=res['log_time'],
            trading_date=res['trading_date'],
            day_night=res['day_night'],
            model_id=int(res['model_id']),
            msg_type=res['msgtype'],
            symbol=res['symbol'],
            direction=res['direction'],
            open_close=res['open_close'],
            trade_vol=float(res['trade_vol']),
            serial_no=int(res['serial_no']),
            cancel_serial_no=int(res['cancel_serial_no']),
            entrust_no=int(res['entrust_no']),
            entrust_status=res['entrust_status'],
            filename=data['path'],
        )
        sc.add(log_line)
    return {
        'code': 0
    }

@log_report.register()
def get_logs(data):
    trading_date = data['date']
    #day_night = int(data['day_night'])
    #symbol = data['symbol'].upper()
    model_id = int(data['strategy_id']) + 10000
    query_filter = [
        PostTradeSimLogTmp.model_id == model_id,
        #PostTradeSimLogTmp.day_night == day_night,
        #PostTradeSimLogTmp.symbol == symbol.lower(),
        PostTradeSimLogTmp.trading_date == trading_date,
        PostTradeSimLogTmp.msg_type == 'TradeReturn',
    ]
    return {
        'code': 0,
        'data': PostTradeSimLogTmp.logs(query_filter)
    }


if __name__ == '__main__':
    s = Server('log_report', debug=Debug)
    s.register(log_report.handlers)
    s.listenandstart(8768)

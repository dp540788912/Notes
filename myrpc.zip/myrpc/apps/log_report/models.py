#-*-coding:utf-8-*-

import json
from sqlalchemy.sql import func
from sqlalchemy import Column, Index, text
from sqlalchemy.dialects.mysql import BIGINT, DATETIME, DATE, INTEGER, VARCHAR, TEXT, FLOAT, MEDIUMINT, DOUBLE, TIME

from db import ModelBase, session_context as mysql_sc


class PostTradeSimLogTmp(ModelBase):

    __tablename__ = 't_posttradesimlog_tmp'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    created_time = Column(DATETIME, nullable=False, server_default=func.now())
    updated_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    log_time = Column(DATETIME(fsp=6), nullable=False, server_default=func.now(6), onupdate=func.now(6))
    trading_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    model_id = Column(BIGINT, nullable=False)
    msg_type = Column(VARCHAR(32), nullable=False)
    symbol = Column(VARCHAR(11), nullable=False)
    direction = Column(VARCHAR(2), nullable=False)
    open_close = Column(VARCHAR(2), nullable=False)
    trade_vol = Column(DOUBLE, nullable=False)
    serial_no = Column(BIGINT, nullable=False)
    cancel_serial_no = Column(BIGINT, nullable=False)
    entrust_no = Column(BIGINT, nullable=False)
    entrust_status = Column(VARCHAR(2), nullable=False)
    filename = Column(VARCHAR(256), nullable=True)

    def to_dict(self):
        return {
            'trading_date': self.trading_date,
            'day_night': self.day_night,
            'model_id': self.model_id,
            'msg_type': self.msg_type,
            'symbol': self.symbol,
            'direction': self.direction,
            'open_close': self.open_close,
            'trade_vol': self.trade_vol,
            'serial_no': self.serial_no,
            'cancel_serial_no': self.cancel_serial_no,
            'entrust_no': self.entrust_no,
            'entrust_status': self.entrust_status,
            'filename': self.filename,
        }

    @staticmethod
    def logs(query_filter):
        keys = [
            'trading_date', 'day_night', 'model_id', 'msg_type', 'symbol', 'direction',
            'open_close', 'trade_vol', 'serial_no', 'cancel_serial_no', 'entrust_no', 'entrust_status'
        ]
        res = []
        with mysql_sc() as sc:
            lines = sc.query(PostTradeSimLogTmp).filter(*query_filter).order_by(PostTradeSimLogTmp.log_time)
            for l in lines:
                res.append(
                    [
                        str(l.trading_date), l.day_night, l.model_id, l.msg_type, l.symbol, l.direction,
                        l.open_close, float(l.trade_vol), l.serial_no, l.cancel_serial_no, l.entrust_no, l.entrust_status,
                    ]
                )
        return {
            'columns': keys,
            'values': res,
        }


# class PostTradeSimLog(ModelBase):
#     created_time = Column(DATETIME, nullable=False, server_default=func.now())
#     updated_time = Column(DATETIME, nullable=False, onupdate=func.now())
#     calendar_date = Column(DATE, nullable=False)
#     calendar_time = Column(TIME, nullable=False)
#     trading_date = Column(DATE, nullable=False)
#     day_night = Column(INTEGER, nullable=False)
#     micro_sec = Column(MEDIUMINT, nullable=False)
#     server = Column(VARCHAR(45), nullable=False)
#     account = Column(VARCHAR(32), nullable=False)
#     model_id = Column(BIGINT, nullable=False)
#     msg_type = Column(VARCHAR(2), nullable=False)
#     serial_no = Column(BIGINT, nullable=False)
#     cancel_serial_no = Column(BIGINT, nullable=False)
#     symbol = Column(VARCHAR(11), nullable=False)
#     direction = Column(VARCHAR(2), nullable=False)
#     open_close = Column(VARCHAR(2), nullable=False)
#     order_price = Column(DOUBLE, nullable=False)
#     order_vol = Column(INTEGER, nullable=False)
#     entrust_no = Column(BIGINT, nullable=False)
#     entrust_status = Column(VARCHAR(2), nullable=False)
#     trade_price = Column(DOUBLE, nullable=False)
#     trade_vol = Column(DOUBLE, nullable=False)
#     vol_remain = Column(INTEGER, nullable=False)
#     trade_no = Column(BIGINT, nullable=False)
#     speculator = Column(VARCHAR(2), nullable=False)
#     order_price_type = Column(VARCHAR(2), nullable=False)
#     order_type = Column(VARCHAR(2), nullable=False)
#     error_no = Column(VARCHAR(2), nullable=False)
#     quote_trigger = Column(TIME, nullable=False)
#     open_vol_remain = Column(INTEGER, nullable=False)
#     n_cancel_remain = Column(INTEGER, nullable=False)
#
#     def to_dict(self):
#         keys = []
#         return {}



# -- 通道日志
# CREATE TABLE IF NOT EXISTS trade_logs(
#   id int not null primary key auto_increment,
#   create_date date not null,
#   internal_date date not null,
#   calendar_date date not null,
#   day_night char(1) not null,
#   create_time time not null,
#   micro_sec mediumint not null,
#   server varchar(45) not null,
#   account varchar(32) not null,
#   model_id bigint not null,
#   msg_type char(1) not null,
#   serial_no bigint  not null,
#   cancel_serial_no bigint  not null,
#   symbol varchar(11) not null,
#   direction char(1) not null,  -- TODO: NEED CHECK
#   open_close char(1) not null, -- TODO: NEED CHECK
#   order_price double not null,
#   order_vol int not null,
#   entrust_no bigint not null,
#   entrust_status char(1) not null,
#   trade_price double not null,
#   trade_vol double not null,
#   vol_remain int not null,
#   trade_no bigint not null,
#   speculator char(1) not null,
#   order_price_type char(1) not null,
#   order_type char(1) not null,
#   error_no int not null,
#   quote_trigger time not null, -- trigger is a keyword in mysql.
#   open_vol_remain int not null,
#   n_cancel_remain int not null,
#   r_create_user_id int not null,
#   r_update_user_id int,
#   r_create_time datetime not null,
#   r_update_time datetime,
#   foreign key (msg_type) references trader_log_type(msg_type),
#   foreign key (entrust_status) references _order_status(status),
#   foreign key (speculator) references _speculator_type(speculator),
#   foreign key (order_price_type) references _order_price_type(price_type),
#   foreign key (order_type) references _order_type(order_type),
#   foreign key (direction) references _direction_type(direction),
#   foreign key (open_close) references _open_close_type(open_close),
#   foreign key (server) references servers(ip),
#   foreign key (account) references accounts(account)
# );


if __name__ == '__main__':
    from db import engine
    ModelBase.metadata.create_all(engine)

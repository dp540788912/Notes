#-*-coding:utf-8-*-

import netifaces

class CommonConfig(object):
    pass


class ProductionConfig(CommonConfig):

    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'simtradelog',
        'user': 'root',
        'passwd': '123456',
        #'db_uri': 'mysql://root:123456@127.0.0.1:3306/rss'
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql


class DebugConfig(CommonConfig):

    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'simtradelog',
        'user': 'root',
        'passwd': '123456',
        #'db_uri': 'mysql://root:123456@127.0.0.1:3306/rss'
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql

class ProductionIDCConfig(CommonConfig):

    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'simtradelog',
        'user': 'root',
        'passwd': '123456',
        #'db_uri': 'mysql://root:123456@127.0.0.1:3306/rss'
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql

iplist = [netifaces.ifaddresses(i).get(netifaces.AF_INET)[0]['addr']
          for i in netifaces.interfaces() if netifaces.ifaddresses(i).get(netifaces.AF_INET)]

debug_iplist = ['192.168.1.14']

product_list = ['192.168.1.214']

product_idc_list = ['192.168.10.100']

if any([i in iplist for i in product_idc_list]):
    Debug = False
    config = ProductionIDCConfig()
elif any([i in iplist for i in debug_iplist]):
    Debug = True
    config = DebugConfig()
elif any([i in iplist for i in product_list]):
    Debug = False
    config = ProductionConfig()
else:
    Debug = True
    config = DebugConfig()

# encoding: utf-8

import os
import copy
import json
import requests
import datetime
import time
import tornado.httpclient
from tornado import gen
#from dateutil.parser import parse
from tornado import gen
from log import logger
from redis_api import RedisConnector, MessageSet, MessageHashMap, MessageList, Singleton
from utils import *
from models import *
from config import *
from kdb_query import KdbQuery


global max_id
max_id = 0

@Singleton
class AlertsMng(object):

    def __init__(self):
        self.event_alerts = {}
        self.fault_alerts = {}
        self.history_alerts = {}
        self.overview_alerts = []
        self.shannon_overview_alerts = []
        self.turing_overview_alerts = []
        self.last_event_alerts = {}
        self.last_fault_alerts = {}
        self.last_history_alerts = {}
        self.shannon_last_overview_alerts = []
        self.turing_last_overview_alerts = []
        self.fault_alerts_filtered = []
        self.oss_alerts = []
        self.keys_cmp_msg = ['101', '102', '103', '107', '201', '202', '301', '302', '303', '1301', '1302', '1303', '1304', '1305', '1306', '1307', '1308', '1309']

    def host_is_exist(self, host):
        if host not in self.event_alerts.keys():
            return False
        return True

    def init_host_context(self, host):
        self.event_alerts[host] = []
        self.last_event_alerts[host] = []

        self.fault_alerts[host] = []
        self.last_fault_alerts[host] = []

        self.history_alerts[host] = []
        self.last_history_alerts[host] = []

    def clear_alerts(self, host, key):
        # 清除当前事件告警
        event_alert_list = self.event_alerts[host]
        num = len(event_alert_list) - 1
        if num > -1:
            i = num
            for i in range(num, -1, -1):
                if event_alert_list[i]['alert_id'] == key and event_alert_list[i]['host'] == host:
                    event_alert_list.pop(i)

        # 清除当前故障告警
        fault_alert_list = self.fault_alerts[host]
        num = len(fault_alert_list) - 1
        if num > -1:
            i = num
            for i in range(num, -1, -1):
                if fault_alert_list[i]['alert_id'] == key and fault_alert_list[i]['host'] == host:
                    fault_alert_list.pop(i)

        # 清除当前overview页面告警
        overview_alerts = []
        if host in MonitorMySQLSentry().shannon_hosts:
            overview_alerts = self.shannon_overview_alerts
        elif host in MonitorMySQLSentry().turing_hosts:
            overview_alerts = self.turing_overview_alerts
        else:
            logger.error("[Alert]%s is not an host monitored, can not clear overview alerts !" % host)
            return

        num = len(overview_alerts) - 1
        if num > -1:
            i = num
            for i in range(num, -1, -1):
                if host == overview_alerts[i]['host'] and overview_alerts[i]['alert_id'] == key:
                    overview_alerts.pop(i)

        # 清除非告警时间段过滤的故障告警
        num = len(self.fault_alerts_filtered) - 1
        for i in range(num, -1, -1):
            if self.fault_alerts_filtered[i]['process_id'] == key and \
                            self.fault_alerts_filtered[i]['host'] == host:
                logger.debug('[fault_alerts_filtered]-- %s' % self.fault_alerts_filtered[i])
                self.fault_alerts_filtered.pop(i)

    def clear_process_alerts(self, host, process_id):
        # 清除当前事件告警
        event_alert_list = self.event_alerts[host]
        num = len(event_alert_list) - 1
        if num > -1:
            i = num
            for i in range(num, -1, -1):
                if event_alert_list[i]['process_id'] == process_id:
                    event_alert_list.pop(i)

        # 清除当前故障告警
        fault_alert_list = self.fault_alerts[host]
        num = len(fault_alert_list) - 1
        if num > -1:
            i = num
            for i in range(num, -1, -1):
                if fault_alert_list[i]['process_id'] == process_id:
                    fault_alert_list.pop(i)

        # 清除当前overview页面告警
        overview_alerts = []
        if host in MonitorMySQLSentry().shannon_hosts:
            overview_alerts = self.shannon_overview_alerts
        elif host in MonitorMySQLSentry().turing_hosts:
            overview_alerts = self.turing_overview_alerts
        else:
            logger.error("[Alert]%s is not an host monitored, can not clear overview alerts !" % host)
            return

        num = len(overview_alerts) - 1
        if num > -1:
            i = num
            for i in range(num, -1, -1):
                if host == overview_alerts[i]['host'] and overview_alerts[i]['process_id'] == process_id:
                    overview_alerts.pop(i)

        # 清除非告警时间段过滤的故障告警
        num = len(self.fault_alerts_filtered) - 1
        for i in range(num, -1, -1):
            if self.fault_alerts_filtered[i]['process_id'] == process_id and \
                            self.fault_alerts_filtered[i]['host'] == host:
                logger.debug('[fault_alerts_filtered]-- %s' % self.fault_alerts_filtered[i])
                self.fault_alerts_filtered.pop(i)

    def clear_host_all_alerts(self, host_type, host):
        # 清除当前事件告警
        self.event_alerts[host] = []

        # 清除当前故障告警
        self.fault_alerts[host] = []

        # 清除当前overview页面告警
        overview_alerts = []
        if host_type == 'shannon':
            overview_alerts = self.shannon_overview_alerts
        elif host_type == 'turing':
            overview_alerts = self.turing_overview_alerts
        else:
            logger.error("[Alert]%s is not an host monitored, can not clear overview alerts !" % host)
            return

        num = len(overview_alerts) - 1
        if num > -1:
            i = num
            for i in range(num, -1, -1):
                if host == overview_alerts[i]['host']:
                    overview_alerts.pop(i)

        # 清除非告警时间段过滤的故障告警
        num = len(self.fault_alerts_filtered) - 1
        for i in range(num, -1, -1):
            if self.fault_alerts_filtered[i]['host'] == host:
                logger.debug('[fault_alerts_filtered]-- %s' % self.fault_alerts_filtered[i])
                self.fault_alerts_filtered.pop(i)

    def update_detail_event_alerts(self, alert, event_show_expire):
        host = alert['host']
        event_alert_list = self.event_alerts[host]
        num = len(event_alert_list) - 1
        if num == -1:
            event_alert_list.append(alert)
        else:
            i = num
            for i in range(num, -1, -1):
                if event_alert_list[i]['process_id'] == alert['process_id'] and \
                                event_alert_list[i]['alert_id'] == alert['alert_id']:
                    event_alert_list.pop(i)
                    event_alert_list.insert(0, alert)
                    break
                elif datetime.datetime.strptime(event_alert_list[i]['clock'], "%Y-%m-%d %H:%M:%S.%f") < \
                                datetime.datetime.now() - datetime.timedelta(minutes=event_show_expire):
                    event_alert_list.pop(i)
                    break

                if i == 0:
                    event_alert_list.insert(0, alert)

    def update_detail_fault_alerts(self, alert):
        host = alert['host']
        fault_alert_list = self.fault_alerts[host]
        if -1 == alert['status']:
            fault_alert_list.insert(0, alert)
            return

        num = len(fault_alert_list) - 1
        isfound = False
        new_msg = alert['msg'].split(']')[-1]
        key_type = alert['alert_id'].split('.')[0]
        if key_type in self.keys_cmp_msg:
            for i in range(num, -1, -1):
                old_msg = fault_alert_list[i]['msg'].split(']')[-1]
                if fault_alert_list[i]['process_id'] == alert['process_id'] and \
                    fault_alert_list[i]['alert_id'] == alert['alert_id'] and \
                    old_msg == new_msg and alert['status'] == 0:
                    fault_alert_list.pop(i)
                    isfound = True
                    continue
        else:
            for i in range(num, -1, -1):
                old_msg = fault_alert_list[i]['msg'].split(']')[-1]
                if fault_alert_list[i]['process_id'] == alert['process_id'] and \
                    fault_alert_list[i]['alert_id'] == alert['alert_id'] and \
                    alert['status'] == 0:
                    fault_alert_list.pop(i)
                    isfound = True
                    continue
        if not isfound:
            logger.error("[Alert]rcv a recovery, but no corresponding cause. %s" % alert)

        return

    def update_fault_alerts_filtered(self, alert):
        if -1 == alert['status']:
            self.fault_alerts_filtered.insert(0, alert)
            logger.debug('[fault_alerts_filtered]++%s' % alert)
            return

        num = len(self.fault_alerts_filtered) - 1
        isfound = False
        new_msg = alert['msg'].split(']')[-1]
        key_type = alert['alert_id'].split('.')[0]
        if key_type in self.keys_cmp_msg:
            for i in range(num, -1, -1):
                old_msg = self.fault_alerts_filtered[i]['msg'].split(']')[-1]
                if self.fault_alerts_filtered[i]['process_id'] == alert['process_id'] and \
                                self.fault_alerts_filtered[i]['alert_id'] == alert['alert_id'] and \
                                old_msg == new_msg and alert['status'] == 0:
                    logger.debug('[fault_alerts_filtered]-- %s' % self.fault_alerts_filtered[i])
                    self.fault_alerts_filtered.pop(i)
                    isfound = True
                    continue
        else:
            for i in range(num, -1, -1):
                old_msg = self.fault_alerts_filtered[i]['msg'].split(']')[-1]
                if self.fault_alerts_filtered[i]['process_id'] == alert['process_id'] and \
                                self.fault_alerts_filtered[i]['alert_id'] == alert['alert_id'] and \
                                alert['status'] == 0:
                    logger.debug('[fault_alerts_filtered]-- %s' % self.fault_alerts_filtered[i])
                    self.fault_alerts_filtered.pop(i)
                    isfound = True
                    continue
        if not isfound:
            logger.error("[fault_alerts_filtered]rcv a recovery, but no corresponding cause. %s" % alert)

        return

    def update_detail_history_alerts(self, alert):
        host = alert['host']
        history_alerts = self.history_alerts[host]
        num = len(history_alerts) - 1
        new_alert = {
            "process_id": alert['process_id'],
            "alert_id": alert['alert_id'],
            "msg": alert['msg'],
            "severity": alert['severity'],
            "status": alert['status'],
            "category": alert['category'],
            "color": alert['color'],
            "clock": alert['clock'],
            "host": alert['host'],
            "alert_type": alert['alert_type'],
            "num": 1
        }
        if num == -1:
            new_alert['num'] = 1
            history_alerts.append(new_alert)
        else:
            i = num
            for i in range(num, -1, -1):
                if new_alert['process_id'] == history_alerts[i]['process_id'] and \
                        new_alert['alert_id'] == history_alerts[i]['alert_id'] and \
                        new_alert['alert_type'] == 1:
                    # event alert
                    new_alert['num'] = history_alerts[i]['num'] + 1
                    new_alert['msg'] = "(%s)%s" % (new_alert['num'], new_alert['msg'])
                    history_alerts.pop(i)
                    history_alerts.insert(0, new_alert)
                    break

                if i == 0:
                    new_alert['num'] = 1
                    history_alerts.insert(0, new_alert)

    def update_overview_alerts(self, new_alert, host_type, event_show_expire=5):
        host = new_alert['host']
        alerttype = new_alert['alert_type']
        overview_alerts = []
        if "shannon" == host_type:
            overview_alerts = self.shannon_overview_alerts
        elif "turing" == host_type:
            overview_alerts = self.turing_overview_alerts

        num = len(overview_alerts) - 1
        if num == -1:
            if 0 == new_alert['status']:
                logger.error("[Alert]rcv a recovery, but no corresponding cause. %s" % new_alert)
                return
            overview_alerts.append(new_alert)
        else:
            isfound = False
            i = num
            new_msg = new_alert['msg'].split(']')[-1]
            key_type = new_alert['alert_id'].split('.')[0]
            for i in range(num, -1, -1):
                if host == overview_alerts[i]['host'] and \
                                alerttype == overview_alerts[i]['alert_type'] and \
                                overview_alerts[i]['process_id'] == new_alert['process_id'] and \
                                overview_alerts[i]['alert_id'] == new_alert['alert_id']:
                    old_msg = overview_alerts[i]['msg'].split(']')[-1]
                    if alerttype == 1:
                        overview_alerts.pop(i)
                        overview_alerts.insert(0, new_alert)
                        isfound = True
                        break
                    elif alerttype == 2:
                        if key_type in self.keys_cmp_msg:
                            if overview_alerts[i]['status'] == -1 and new_alert['status'] == 0 and old_msg == new_msg:
                                overview_alerts.pop(i)
                                isfound = True
                        else:
                            if overview_alerts[i]['status'] == -1 and new_alert['status'] == 0:
                                overview_alerts.pop(i)
                                isfound = True

                elif datetime.datetime.strptime(overview_alerts[i]['clock'], "%Y-%m-%d %H:%M:%S.%f") < \
                                datetime.datetime.now() - datetime.timedelta(minutes=event_show_expire) and \
                                overview_alerts[i]['alert_type'] == 1:
                    overview_alerts.pop(i)

            if not isfound:
                if 0 == new_alert['status']:
                    logger.error("[Alert]rcv a recovery, but no corresponding cause. %s" % new_alert)
                    return
                overview_alerts.insert(0, new_alert)

    def update_start_process_alerts(self, alert, alert_set_type):
        if "shannon" == alert_set_type:
            fault_alert_list = self.shannon_overview_alerts
        elif "turing" == alert_set_type:
            fault_alert_list = self.turing_overview_alerts
        elif "detail" == alert_set_type:
            host = alert['host']
            fault_alert_list = self.fault_alerts[host]
        elif "filtered" == alert_set_type:
            fault_alert_list = self.fault_alerts_filtered
        else:
            logger.error('No defined alert_set_type: %s', alert_set_type)
            return

        num = len(fault_alert_list) - 1
        for i in range(num, -1, -1):
            if fault_alert_list[i]['alert_id'] == alert['alert_id']:
                if alert['status'] == 0:
                    fault_alert_list.pop(i)
                elif alert['status'] == -1:
                    fault_alert_list[i]['msg'] = alert['msg']
                return

        if -1 == alert['status']:
            fault_alert_list.insert(0, alert)
        elif 0 == alert['status']:
            logger.error("[Alert]rcv a recovery, but no corresponding cause. %s" % alert)

    def del_detail_event_alerts_expired(self, host, timeout_min):
        if host not in self.event_alerts.keys():
            self.init_host_context(host)
            return

        event_alert_list = self.event_alerts[host]
        num = len(event_alert_list) - 1
        for i in range(num, -1, -1):
            if datetime.datetime.strptime(event_alert_list[i]['clock'], "%Y-%m-%d %H:%M:%S.%f") < \
                            datetime.datetime.now() - datetime.timedelta(minutes=timeout_min):
                event_alert_list.pop(i)

    def del_overview_event_alerts_expired(self, timeout_min):
        num = len(self.shannon_overview_alerts) - 1
        for i in range(num, -1, -1):
            if 1 == self.shannon_overview_alerts[i]['alert_type'] and \
                            datetime.datetime.strptime(self.shannon_overview_alerts[i]['clock'],
                                                       "%Y-%m-%d %H:%M:%S.%f") < \
                                    datetime.datetime.now() - datetime.timedelta(minutes=timeout_min):
                self.shannon_overview_alerts.pop(i)

        num = len(self.turing_overview_alerts) - 1
        for i in range(num, -1, -1):
            if 1 == self.turing_overview_alerts[i]['alert_type'] and \
                            datetime.datetime.strptime(self.turing_overview_alerts[i]['clock'],
                                                       "%Y-%m-%d %H:%M:%S.%f") < \
                                    datetime.datetime.now() - datetime.timedelta(minutes=timeout_min):
                self.turing_overview_alerts.pop(i)

    def get_fault_alerts_filtered_to_send(self, event_show_expire):
        bulk_events = []
        num = len(self.fault_alerts_filtered) - 1
        for i in range(num, -1, -1):
            front_alert = self.fault_alerts_filtered[i]
            host = front_alert['host']
            query_key = host + '_' + str(front_alert['alert_id'])
            if query_key not in MonitorMySQLSentry().alerts_define.keys():
                logger.error("[Alert]No defined alert: %s" % query_key)
                continue
            alerts_define = MonitorMySQLSentry().alerts_define[query_key]
            for i in range(len(alerts_define)):
                if not alerts_define[i]['enabled']:
                    continue
                if not MonitorMySQLSentry().in_alert_time(alerts_define[i]['monitor_time']):
                    continue

                self.fault_alerts_filtered.pop(i)
                logger.debug('[fault_alerts_filtered]=%s' % self.fault_alerts_filtered)

                # fault alert
                self.update_detail_fault_alerts(front_alert)

                # overview alert
                if host in MonitorMySQLSentry().shannon_hosts:
                    self.update_overview_alerts(front_alert, "shannon", event_show_expire)
                elif host in MonitorMySQLSentry().turing_hosts:
                    self.update_overview_alerts(front_alert, "turing", event_show_expire)

                # history alert
                self.update_detail_history_alerts(front_alert)

                event = {
                    'key': front_alert['alert_id'],
                    'host': front_alert['host'],
                    'process_id': front_alert['process_id'],
                    'operator': alerts_define[i]['operator'],
                    'threshold': alerts_define[i]['threshold'],
                    'msg': front_alert['msg'],
                    'status': front_alert['status'],
                    'clock': front_alert['clock']
                }
                if event['process_id'] == 0:
                    event['msg'] = "%s (%s)" % (event['msg'], host)
                else:
                    event['msg'] = "[%s (%s, process %s)" % (event['msg'], host, event['process_id'])
                bulk_events.append(event)
        return bulk_events

    def get_shannon_overview_alerts(self):
        return self.shannon_overview_alerts

    def get_turing_overview_alerts(self):
        return self.turing_overview_alerts

    def get_host_event_alerts(self, host):
        return self.event_alerts[host]

    def get_host_last_event_alerts(self, host):
        return self.last_event_alerts[host]

    def get_host_fault_alerts(self, host):
        return self.fault_alerts[host]

    def get_host_last_fault_alerts(self, host):
        return self.last_fault_alerts[host]

    def get_host_history_alerts(self, host):
        return self.history_alerts[host]

    def get_host_last_history_alerts(self, host):
        return self.last_history_alerts[host]

    def update_host_last_event_alerts(self, host):
        if self.last_event_alerts[host] != self.event_alerts[host]:
            self.last_event_alerts[host] = copy.deepcopy(self.event_alerts[host])
            return True
        return False

    def update_host_last_fault_alerts(self, host):
        if self.last_fault_alerts[host] != self.fault_alerts[host]:
            self.last_fault_alerts[host] = copy.deepcopy(self.fault_alerts[host])
            return True
        return False

    def update_host_last_history_alerts(self, host):
        if self.last_history_alerts[host] != self.history_alerts[host]:
            self.last_history_alerts[host] = copy.deepcopy(self.history_alerts[host])
            return True
        return False

    def update_shannon_last_overview_alerts(self):
        if self.shannon_last_overview_alerts != self.shannon_overview_alerts:
            self.shannon_last_overview_alerts = copy.deepcopy(self.shannon_overview_alerts)
            return True
        return False

    def update_turing_last_overview_alerts(self):
        if self.turing_last_overview_alerts != self.turing_overview_alerts:
            self.turing_last_overview_alerts = copy.deepcopy(self.turing_overview_alerts)
            return True
        return False

    def update_host_history_alerts_at_close(self, host):
        reserved_category = ['cpu', 'memory', 'swap', 'disk', 'dev', 'agent', 'clock']
        history_alerts = self.history_alerts[host]
        num = len(history_alerts) - 1
        if num == -1:
            return
        else:
            for i in range(num, -1, -1):
                if history_alerts[i]['category'] in reserved_category:
                    continue
                else:
                    history_alerts.pop(i)

    def alert_ring_update(self):
        redis_key = "oss:event_handle:monitor:ring_mng"
        try:
            msgs = MessageList(redis_key).pop_all_msg()
        except Exception as e:
            logger.error("[MySQL]Read %s, but catch exception: %s" % (redis_key, str(e)))
            return

        if not msgs:
            return
        logger.info("[MySQL][%s]Read %s" % (redis_key, msgs))
        id2ring = {}
        for msg in msgs:
            msg = json.loads(str(msg, 'utf-8'))
            id2ring[msg['id']] = msg['is_ring']
        # detail fault alerts
        for host, alerts in self.fault_alerts.items():
            for alert in alerts:
                if alert['id'] in id2ring.keys():
                    alert['is_ring'] = id2ring[alert['id']]
        # shannon overview alerts
        for alert in self.shannon_overview_alerts:
            if alert['id'] in id2ring.keys():
                alert['is_ring'] = id2ring[alert['id']]


class BaseSentry(object):

    def __init__(self, seconds=0.1):
        self.seconds = seconds

    @gen.coroutine
    def work_process(self):
        pass

    @gen.coroutine
    def run(self):
        while True:
            nxt = gen.sleep(self.seconds)
            yield self.work_process()
            yield nxt


@Singleton
class MonitorMySQLSentry(BaseSentry):

    def __init__(self, seconds=0.1):
        self.severity_define = {}
        self.alerts_define = {}
        self.is_trading_day = True
        self.shannon_hosts = []
        self.turing_hosts = []
        self.hosts_monitored = []
        self.seconds = 1
        self.flag_query = False

        #super(MonitorMySQLSentry, self).__init__(seconds=self.run_period)
        self.today_is_trading_day()
        self.query_mysql()

    def get_hosts_from_mysql(self):
        last_shannon_hosts = self.shannon_hosts
        last_turing_hosts = self.turing_hosts
        self.shannon_hosts = []
        self.turing_hosts = []
        with mysql_sc() as sc:
            lines = sc.query(ShannonDeployConfs).join(
                ShannonProgramTypes
            ).join(
                ShannonServers,
                ShannonServers.ip == ShannonDeployConfs.host
            ).filter(
                ShannonProgramTypes.name == 'bss_agent',
                ShannonDeployConfs.valid == True,
                ShannonServers.monitor_status == 1
            ).all()
            for line in lines:
                if line.host not in self.shannon_hosts:
                    self.shannon_hosts.append(line.host)
            logger.debug("[MySQL]shannon host: %s" % self.shannon_hosts)

            lines = sc.query(TuringDeployConfs).join(
                TuringPrograms,
                TuringPrograms.id == TuringDeployConfs.program_id
            ).join(
                TuringProgramTypes,
                TuringPrograms.type_id == TuringProgramTypes.id
            ).join(
                TuringServers,
                TuringServers.ip == TuringDeployConfs.host
            ).filter(
                TuringProgramTypes.name == 'bss_agent',
                TuringDeployConfs.valid == True,
                TuringServers.monitor_status == 1
            ).all()
            for line in lines:
                if line.host not in self.turing_hosts:
                    self.turing_hosts.append(line.host)
            logger.debug("[MySQL]turing host: %s" % self.turing_hosts)

            self.hosts_monitored = self.shannon_hosts + self.turing_hosts
            logger.debug("[MySQL]Hosts monitored: %s" % self.hosts_monitored)

        for host in last_shannon_hosts:
            if host not in self.shannon_hosts:
                AlertsMng().clear_host_all_alerts('shannon', host)
                logger.info('%s is no longer monitored, so clear host alerts.', host)
        for host in last_turing_hosts:
            if host not in self.turing_hosts:
                AlertsMng().clear_host_all_alerts('shannon', host)
                logger.info('%s is no longer monitored, so clear host alerts.', host)

    def get_alerts_define_from_mysql(self):
        version = "%s" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        headers = {
            'content-type': 'application/json',
            'whitelist': 'operater',
        }
        url = get_url("/api/v1/event_handle/custom_alert", svr_port=80)
        try:
            r = requests.get(url, None, headers=headers)
            rsp = r.json()
        except Exception as e:
            logger.error("[MySQL]get alerts define, but catch exception %s" % str(e))
            return -1
        if 'data' not in rsp.keys():
            logger.error("[MySQL]Query alert define,but return %s" % rsp)
            return

        l_alert = rsp['data']
        for alert in l_alert:
            #print(alert)
            key = alert['host'] + '_' + alert['key']
            if key not in self.alerts_define.keys():
                self.alerts_define[key] = []
                v = {
                    "id": alert['id'],
                    "key_cn": alert['key_cn'],
                    "operator": alert['operator'],
                    "threshold": alert['threshold'],
                    "category": alert['category'],
                    "alert_type": alert['alert_type'],
                    "severity": alert['severity'],
                    "enabled": alert['enabled'],
                    "status": 0,
                    "monitor_time": alert_time_to_list(alert['monitor_time']),
                    "version": version
                }
                self.alerts_define[key].append(v)
            else:
                num = len(self.alerts_define[key])
                i = -1
                for i in range(num):
                    if self.alerts_define[key][i]['id'] == alert['id']:
                        self.alerts_define[key][i]['key_cn'] = alert['key_cn']
                        self.alerts_define[key][i]['operator'] = alert['operator']
                        self.alerts_define[key][i]['threshold'] = alert['threshold']
                        self.alerts_define[key][i]['alert_type'] = alert['alert_type']
                        self.alerts_define[key][i]['severity'] = alert['severity']
                        self.alerts_define[key][i]['category'] = alert['category']
                        self.alerts_define[key][i]['monitor_time'] = alert_time_to_list(alert['monitor_time'])
                        self.alerts_define[key][i]['version'] = version

                        if self.alerts_define[key][i]['enabled'] == 1 and alert['enabled'] == 0:
                            logger.info('Alert item was set disabled.  %s', alert)
                            AlertsMng().clear_alerts(alert['host'], alert['key'])
                        self.alerts_define[key][i]['enabled'] = alert['enabled']
                        break

                    if i == num - 1:
                        v = {
                            "id": alert['id'],
                            "key_cn": alert['key_cn'],
                            "operator": alert['operator'],
                            "threshold": alert['threshold'],
                            "category": alert['category'],
                            "alert_type": alert['alert_type'],
                            "severity": alert['severity'],
                            "enabled": alert['enabled'],
                            "status": 0,
                            "monitor_time": alert_time_to_list(alert['monitor_time']),
                            "version": version
                        }
                        self.alerts_define[key].append(v)

        for key in self.alerts_define.keys():
            num = len(self.alerts_define[key])
            for i in range(num):
                if self.alerts_define[key][i]['version'] != version:
                    self.alerts_define[key][i]['enabled'] = False

    def get_severity_define_from_mysql(self):
        url = get_url("/api/v1/event_handle/severity_setting", svr_port=80)
        headers = {
            'content-type': 'application/json',
            'whitelist': 'operater',
        }
        try:
            r = requests.get(url, headers=headers)
        except Exception as e:
            logger.error("[MySQL]catch exception %s" % str(e))
            return
        rsp = r.json()
        l_severity = rsp['data']
        self.severity_define = {}
        for severity in l_severity:
            self.severity_define[severity['name']] = severity

    def update_conf(self):
        redis_key = "oss:monitor:event_handle:update_conf"
        try:
            confs = MessageList(redis_key).pop_all_msg()
        except Exception as e:
            logger.error("[MySQL]Read %s, but catch exception: %s" % (redis_key, str(e)))
            return
        if not confs:
            return
        #confs = json.loads(str(confs, 'utf-8'))
        logger.info("[MySQL][oss:monitor:event_handle:update_conf]Read %s" % confs)
        for conf in confs:
            conf = json.loads(str(conf, 'utf-8'))
            if conf['update'] == 'host':
                self.get_hosts_from_mysql()
                logger.info("[MySQL]Update host.")
            elif conf['update'] == 'severity':
                self.get_severity_define_from_mysql()
                logger.info("[MySQL]Update severity define.")
            elif conf['update'] == 'alert':
                self.get_alerts_define_from_mysql()
                logger.info("[MySQL]Update alerts define.")
            else:
                logger.error("[MySQL]Undefined conf type: %s" % conf['update'])

    def query_mysql(self):
        self.get_severity_define_from_mysql()
        self.get_alerts_define_from_mysql()
        self.get_hosts_from_mysql()

    def today_is_trading_day(self):
        now = datetime.datetime.now()
        hour = int(now.strftime('%H'))
        if hour >= 0 and hour < 3:
            day = (now - datetime.timedelta(days=1)).strftime('%Y.%m.%d')
        else:
            day = now.strftime('%Y.%m.%d')

        if hour >= 3 and hour < 16:
            self.is_trading_day = KdbQuery().check_day_monitor(day)
        else:
            self.is_trading_day = KdbQuery().check_night_monitor(day)

        if True == self.is_trading_day:
            logger.info("[KDB]%s is trading day, so should alarm." % day)
        else:
            logger.info("[KDB]%s is not trading day, so would not alarm." % day)

    def in_alert_time(self, time_list):
        try:
            if not self.is_trading_day:
                logger.debug("Today is not trading day. ")
                return False
            if not time_list:
                return True
            now = datetime.datetime.now()
            now_time = datetime.time(now.hour, now.minute)
            for ran_item in time_list:
                if now_time <= ran_item["end"] and now_time >= ran_item["start"]:
                    return True
            return False
        except Exception as e:
            logger.error("[Base]catch exception %s, input para %s" % (str(e), time_list))
            return True

    @gen.coroutine
    def work_process(self):
        self.update_conf()

        now = datetime.datetime.now()
        now_time = datetime.time(now.hour, now.minute)
        day_query_time = datetime.time(6, 0)
        night_query_time = datetime.time(18, 0)
        if now_time == day_query_time or now_time == night_query_time:
            if not self.flag_query:
                self.today_is_trading_day()
                self.flag_query = True
        else:
            self.flag_query = False


class MonitorBaseSentry(BaseSentry):

    def __init__(self, seconds=0.1):
        self.hash_msg = MessageHashMap()
        self.set_msg = MessageSet('a:oss:hosts')
        self.ws_data = {}
        self.last_ws_data = {}
        self.hash_sockid = {}
        self.hosts_reg = []
        self.hosts_need_monitored = []
        self.agent_open_close = {}
        self.run_period = seconds
        self.interval_query_mysql = 2  # unit: minute
        self.process_start_timeout = 120  # unit: second   #just for test
        self.overview_stat_tmpl = {
            "agent_status": -2,
            "disk_problem": 0,
            "cpu_problem": 0,
            "ram_problem": 0,
            "swap_problem": 0,
            "process_total": 0,
            "process_problem": 0,
            "alert_problem": 0,
            "device_total": 0,
            "device_problem": 0,
            "clock_diff": 0,
            "clock_diff_status": 0,
            "update_time": 0
        }
        super(MonitorBaseSentry, self).__init__(seconds=self.run_period)
        self.alerts_mng = AlertsMng()

    def get_websocket_data(self, host):
        return None

    def get_data_from_redis(self, host):
        return None

    def update_overview(self, host):
        return None

    def update_detail_and_socketid(self, host):
        return None

    def send_websocket_data(self, host, clientid, msg_type):
        return None

    def get_hosts_reg(self):
        hosts_orig = list(self.set_msg.get_msg())
        self.hosts_reg = []
        for host in hosts_orig:
            host = str(host, 'utf-8')
            self.hosts_reg.append(host)

    def get_hosts_monitored(self):
        self.hosts_need_monitored = []
        hosts_orig = list(self.set_msg.get_msg())
        for host in hosts_orig:
            host = str(host, 'utf-8')
            if host not in MonitorMySQLSentry().hosts_monitored:
                logger.debug("[Base]%s not in monitor list !" % host)
                continue
            self.hosts_need_monitored.append(host)

        redis_key = 'oss:monitor:overview:host_status'
        agents = self.hash_msg.get_key_all(redis_key)
        if agents:
            for host, info in agents.items():
                agent_info = json.loads(str(info, 'utf-8'))
                if 'agent_open_close' in agent_info.keys():
                    self.agent_open_close[host] = agent_info['agent_open_close']
                else:
                    self.agent_open_close[host] = 0 # agent run

    def check_healthy_and_process_alert(self, host, processid, item_key, value, err_detail=''):
        healthy = 0            # 0:healthy -1:unhealthy
        is_switched = False    # 监控项状态是否变化

        query_key = str(host) + "_" + item_key
        if query_key not in MonitorMySQLSentry().alerts_define.keys():
            logger.error("[Base]No found alert define for %s" % query_key)
            return healthy, is_switched

        alerts_define = MonitorMySQLSentry().alerts_define[query_key]
        num = len(alerts_define)
        for i in range(num):
            if alerts_define[i]['enabled'] == False:
                logger.debug("The define of alert(%s) is disabled. " % query_key)
                continue

            ret = check_healthy(alerts_define[i]['operator'], alerts_define[i]['threshold'], value)
            if -1 == ret:
                healthy = -1
            if ret != alerts_define[i]['status']:
                alerts_define[i]['status'] = ret
                is_switched = True

                dt = datetime.datetime.now()
                key_cn = alerts_define[i]['key_cn']
                status_cn = ""
                if "agent.conn" == item_key:
                    if value == 0:
                        status_cn = "恢复连接，目前无告警"
                    elif value == -1:
                        status_cn = "恢复连接，目前仍存在告警"
                    elif value == -2:
                        status_cn = "离线"
                else:
                    status_cn = "恢复" if ret == 0 else "异常"

                severity = alerts_define[i]['severity']
                color = MonitorMySQLSentry().severity_define[severity]['color']
                oss_alert = {
                    "key": item_key,
                    "host": host,
                    "process_id": processid,
                    "operator": alerts_define[i]['operator'],
                    "threshold": alerts_define[i]['threshold'],
                    "msg": "[%s%s]" % (key_cn, status_cn),
                    "status": ret,
                    "severity": severity,
                    "category": alerts_define[i]['category'],
                    "alert_type": 2,  # 故障告警
                    "color": color,
                    "ring_type": MonitorMySQLSentry().severity_define[severity]['ring_type'],
                    "is_ring": True,
                    "monitor_time": alerts_define[i]['monitor_time'],
                    "clock": str(dt),
                }
                if 0 != len(err_detail):
                    oss_alert['msg'] = "%s%s" % (oss_alert['msg'], err_detail)

                self.alerts_mng.oss_alerts.append(oss_alert)

        return healthy, is_switched

    def push_detail(self, host_type):
        agent_type = '%s_detail' % host_type
        hostname = '%s_hostname' % host_type
        agents = get_type_agent(agent_type)
        for agent in agents:
            if agent['oss_detail'].get(hostname):
                host = agent['oss_detail'][hostname]
                self.send_websocket_data(host, agent['socket_id'], agent_type)

    @gen.coroutine
    def work_process(self):
        try:
            self.get_hosts_reg()
            for host in self.hosts_reg:
                if host not in MonitorMySQLSentry().hosts_monitored:
                    logger.debug("[Base]%s not in monitor list !" % host)
                    continue

                self.get_data_from_redis(host)
                self.update_overview(host)
                self.update_detail_and_socketid(host)

            self.push_detail("shannon")
            self.push_detail("turing")
        except Exception as e:
            logger.error("[Base]Catch exception: %s" % str(e))


class MonitorClockDiffSentry(MonitorBaseSentry):
    def __init__(self):
        self.last_update_time = {}
        self.last_ws_data = {}
        self.ws_data = {}
        self.hash_overview_last = {}
        self.run_period = 1
        super(MonitorClockDiffSentry, self).__init__(seconds=self.run_period)

    def init_host_context(self, host):
        self.hash_sockid[host] = []
        self.ws_data[host] = {}
        self.last_ws_data[host] = {
            'clock': 99999,
            'status': -1,
        }
        self.last_update_time[host] = ""

    def get_data_from_redis(self, host):
        if host not in self.last_update_time:
            self.init_host_context(host)

        clock_diff, status = 0, 0
        monitor_data = self.hash_msg.get_key_msg('a:oss:monitor:resource', host)
        if monitor_data:
            monitor_data = json.loads(str(monitor_data, 'utf-8'))
            update_time = monitor_data.get('update_time', '')
            if update_time == self.last_update_time[host]:
                return

            self.last_update_time[host] = update_time
            update_time = update_time[0:-4]
            now_time = datetime.datetime.now()
            clock_diff = (now_time - datetime.datetime.strptime(update_time, "%Y-%m-%d %H:%M:%S.%f")).total_seconds()
            logger.debug("[Clock]%s update clock: %s, local clock: %s, diff: %s" %
                         (host, update_time, now_time.strftime("%Y-%m-%d %H:%S:%M.%f"), clock_diff))
            status = self.check_clock_healthy(host, clock_diff)
        else:
            logger.error("[Clock]No clock in a:oss:monitor:resource for host %s" % host)
            clock_diff = 99999
            status = -1

        self.ws_data[host] = {
            'clock': clock_diff,
            'status': status,
        }

    def update_overview(self, host):
        if self.last_ws_data[host]['clock'] == self.ws_data[host]['clock']:
            return

        overview_redis = self.hash_msg.get_key_msg('oss:monitor:overview:host_status', host)
        if overview_redis:
            overview_redis = json.loads(str(overview_redis, 'utf-8'))
        else:
            overview_redis = self.overview_stat_tmpl
        overview_redis['clock_diff'] = self.ws_data[host]['clock']
        overview_redis['clock_diff_status'] = self.ws_data[host]['status']
        self.hash_msg.put_key_msg('oss:monitor:overview:host_status', host, json.dumps(overview_redis))
        logger.debug("[Clock]Update overview clock diff %s." % host)

    def update_detail_and_socketid(self, host):
        if self.last_ws_data[host]['clock'] == self.ws_data[host]['clock']:
            return
        else:
            self.last_ws_data[host]['clock'] = self.ws_data[host]['clock']
            self.last_ws_data[host]['status'] = self.ws_data[host]['status']
            self.hash_sockid[host] = []

    def send_websocket_data(self, host, clientid, msg_type):
        if clientid in self.hash_sockid[host]:
            return

        data = {
            'category': 'clockdiff',
            'info': {},
            'time': '',
        }
        data['info'] = self.ws_data[host]
        data['time'] = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H:%M:%S.%f') + ' CST'
        send_websoket(msg_type, data, socket_id=clientid)
        self.hash_sockid[host].append(clientid)
        logger.debug("[Clock]Send clock diff of %s to client %s" % (host, clientid))

    def check_clock_healthy(self, host, clock_diff):
        clock_diff = round(clock_diff, 2)
        err_msg = ''
        if clock_diff > 0:
            err_msg = "时间慢了%.2f秒" % clock_diff
        elif clock_diff < 0:
            err_msg = "时间快了%.2f秒" % clock_diff

        healthy, is_switched = self.check_healthy_and_process_alert(host, 0, "clock.diff", abs(clock_diff), err_msg)
        if healthy == -1:
            if is_switched:
                logger.info("[Clock]clock diff of %s is abnormal, is %f !" % (host, clock_diff))
            return -1
        elif healthy == 0:
            if is_switched:
                logger.info("[Clock]clock diff of %s is recovered, is %f !" % (host, clock_diff))
            return 0


class MonitorDeviceSentry(MonitorBaseSentry):

    def __init__(self):
        self.dev_problem = 0
        self.hash_dev_problem_last = {}
        self.run_period = 2
        super(MonitorDeviceSentry, self).__init__(seconds=self.run_period)

    def init_host_context(self, host):
        self.ws_data[host] = {}
        self.last_ws_data[host] = {}
        self.hash_dev_problem_last[host] = 0
        self.hash_sockid[host] = []

    def get_data_from_redis(self, host):
        ret_data = {
            'category': 'device',
            'info': [],
            'time': '',
        }

        if host not in self.ws_data.keys():
            self.init_host_context(host)

        monitor_data = self.hash_msg.get_key_msg('a:oss:monitor:device', host)
        if monitor_data:
            device_data = json.loads(str(monitor_data, 'utf-8')).get('devices', [])
            for item in device_data:
                data = {
                    'count': item['count'],
                    'name': item['name'],
                    'status': 0,
                }
                ret_data['info'].append(data)
        else:
            logger.info("[Device]No data in a:oss:monitor:device for host %s" % host)

        self.ws_data[host] = ret_data

    def update_overview(self, host):
        if self.dev_problem == self.hash_dev_problem_last[host]:
            return

        overview_redis = self.hash_msg.get_key_msg('oss:monitor:overview:host_status', host)
        if overview_redis:
            overview_redis = json.loads(str(overview_redis, 'utf-8'))
        else:
            overview_redis = self.overview_stat_tmpl
        overview_redis['device_problem'] = self.hash_dev_problem_last[host]
        overview_redis['update_time'] = time.time()
        self.hash_msg.put_key_msg('oss:monitor:overview:host_status', host, json.dumps(overview_redis))

    def update_detail_and_socketid(self, host):
        if self.last_ws_data[host] == self.ws_data[host]:
            return
        else:
            self.last_ws_data[host] = copy.deepcopy(self.ws_data[host])
            self.hash_sockid[host] = []

    def send_websocket_data(self, host, clientid, msg_type):
        if clientid in self.hash_sockid[host]:
            return

        data = self.ws_data[host]
        data['time'] = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H:%M:%S.%f') + ' CST'
        send_websoket(msg_type, data, socket_id=clientid)
        self.hash_sockid[host].append(clientid)


class MonitorProcessSentry(MonitorBaseSentry):
    def __init__(self):
        self.hash_msg = MessageHashMap()
        self.last_ws_data = {}
        self.hash_overview_last = {}
        self.hash_overview = {}
        self.hash_sockid = {}
        self.last_update_time = {}
        self.run_period = 1

        super(MonitorProcessSentry, self).__init__(seconds=self.run_period)

    def init_host_context(self, host):
        self.hash_overview[host] = {
            "process_total": 0,
            "process_problem": 0
        }
        self.hash_overview_last[host] = {
            "process_total": -1,
            "process_problem": -1
        }
        self.hash_sockid[host] = []
        self.ws_data[host] = {}
        self.last_ws_data[host] = {}
        self.last_update_time[host] = ""

    def is_process_start_or_stop(self, process_info):
        if time.time() - process_info['clock'] > self.process_start_timeout:
            return False
        else:
            return True

    def get_data_from_redis(self, host):
        process_total, process_problem = 0, 0
        ret_data = {
            'category': 'process',
            'info': [],
            'clock': '',
        }
        if host not in self.hash_overview.keys():
            self.init_host_context(host)

        redis_hash_name = "oss:deploy:monitor:processes:%s" % host
        oss_data = self.hash_msg.get_key_all(redis_hash_name)
        if not oss_data:
            return

        monitor_data = self.hash_msg.get_key_msg('a:oss:monitor:processes', host)
        agent_data = []
        if monitor_data:
            logger.debug("[Process]Read %s from a:oss:monitor:processes, get %s" % (host, monitor_data))
            monitor_data = json.loads(str(monitor_data, 'utf-8'))

            update_time = monitor_data.get('update_time', '')
            if update_time == self.last_update_time[host]:
                return
            self.last_update_time[host] = update_time
            agent_data = monitor_data['process']
        for p_id, p in oss_data.items():
            p = json.loads(str(p, 'utf-8'))
            process_total += 1
            data = {}
            num = len(agent_data)
            i = -1
            err_msg = ''
            for i in range(num):
                if p['process_id'] == agent_data[i]['process_id']:
                    if p['is_running'] == agent_data[i]['is_running']:
                        data = {
                            'name': os.path.basename(agent_data[i]['path'].replace('/run.sh', '')),
                            'path': agent_data[i]['path'].replace('/run.sh', ''),
                            'process_id': agent_data[i]['process_id'],
                            'pid': agent_data[i]['pid'],
                            'is_running': agent_data[i]['is_running'],
                            'status': agent_data[i]['status'],
                        }
                        if p['is_running'] == 1 and data['status'] == 0 and p.get('launch_status', 0) != 0:
                            data['status'] = -1
                            err_msg = "进程%d启动过程中异常" % p['process_id']
                        ret_data['info'].append(data)
                        agent_data.pop(i)
                        if -1 == data['status']:
                            err_msg = "agent上报进程%d异常" % p['process_id']
                        break
                    else:
                        data = {
                            'name': os.path.basename(agent_data[i]['path'].replace('/run.sh', '')),
                            'path': agent_data[i]['path'].replace('/run.sh', ''),
                            'process_id': p['process_id'],
                            'pid': agent_data[i]['pid'],
                            'is_running': p['is_running'],
                            'status': -2 if self.is_process_start_or_stop(p) else -1,
                        }
                        err_msg = "is_running错误，期望是%s，实际是%s" % (p['is_running'], agent_data[i]['is_running'])

                        ret_data['info'].append(data)
                        agent_data.pop(i)
                        break

                i += 1

            if -1 == i or i == num:
                # no found process in agent_data
                if p['is_running'] == 1:
                    data = {
                        'name': os.path.basename(p['path'].replace('/run.sh', '')),
                        'path': p['path'].replace('/run.sh', ''),
                        'process_id': p['process_id'],
                        'pid': 0,
                        'is_running': p['is_running'],
                        'status': -2 if self.is_process_start_or_stop(p) else -1
                    }
                    err_msg = "agent没有上报进程%d的信息" % p['process_id']
                else:
                    data = {
                        'name': os.path.basename(p['path'].replace('/run.sh', '')),
                        'path': p['path'].replace('/run.sh', ''),
                        'process_id': p['process_id'],
                        'pid': 0,
                        'is_running': p['is_running'],
                        'status': 0
                    }
                ret_data['info'].append(data)

            if -2 != data['status']:
                healthy, is_switched = self.check_healthy_and_process_alert(host, data['process_id'], \
                                        "process.run_status." + str(data['process_id']), data['status'], err_msg)
                if -1 == data['status']:
                    process_problem += 1
                    if is_switched:
                        logger.info("%s in host %s" % (err_msg, host))
                elif 0 == data['status']:
                    if is_switched:
                        logger.info("process %d recovered in host %s" % (data['process_id'], host))

        if monitor_data:
            ret_data['clock'] = monitor_data.get('update_time', '').replace(' CST', '')
        else:
            ret_data['clock'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
        self.ws_data[host] = ret_data

        self.hash_overview[host]['process_total'] = process_total
        self.hash_overview[host]['process_problem'] = process_problem

    def update_overview(self, host):
        if self.hash_overview[host] == self.hash_overview_last[host]:
            return

        self.hash_overview_last[host]["process_total"] = self.hash_overview[host]["process_total"]
        self.hash_overview_last[host]["process_problem"] = self.hash_overview[host]["process_problem"]

        overview_redis = self.hash_msg.get_key_msg('oss:monitor:overview:host_status', host)
        if overview_redis:
            overview_redis = json.loads(str(overview_redis, 'utf-8'))
        else:
            overview_redis = self.overview_stat_tmpl

        overview_redis['process_total'] = self.hash_overview[host]["process_total"]
        overview_redis['process_problem'] = self.hash_overview[host]["process_problem"]
        overview_redis['update_time'] = time.time()
        self.hash_msg.put_key_msg('oss:monitor:overview:host_status', host, json.dumps(overview_redis))

    def update_detail_and_socketid(self, host):
        if 'clock' not in self.ws_data[host]:
            return
        tmp_clock = self.ws_data[host]['clock']
        self.ws_data[host]['clock'] = ''
        self.ws_data[host]['time'] = ''
        if self.last_ws_data[host] == self.ws_data[host]:
            self.ws_data[host]['clock'] = tmp_clock
            return
        else:
            self.last_ws_data[host] = copy.deepcopy(self.ws_data[host])
            self.ws_data[host]['clock'] = tmp_clock
            self.hash_sockid[host] = []

    def send_websocket_data(self, host, clientid, msg_type):
        if clientid in self.hash_sockid[host]:
            return

        data = self.ws_data[host]
        data['time'] = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H:%M:%S.%f') + ' CST'
        send_websoket(msg_type, data, socket_id=clientid)
        self.hash_sockid[host].append(clientid)


class MonitorResourceSentry(MonitorBaseSentry):

    def __init__(self):
        self.hash_msg = MessageHashMap()
        self.hash_overview_last = {}
        self.ws_data = {}
        self.last_ws_data = {}
        self.hash_sockid = {}
        self.disk_problem = 0
        self.cpu_problem = 0
        self.ram_problem = 0
        self.swap_problem = 0
        self.disk_ws_data = {
            'category': 'disk',
            'info': [],
            'time': '',
        }
        self.cpu_ws_data = {
            'category': 'cpu',
            'info': {},
            'time': '',
        }
        self.mem_ws_data = {
            'category': 'memory',
            'info': {},
            'time': '',
        }
        self.sys_ws_data = {
            'category': 'system',
            'info': {},
            'time': '',
        }
        self.flag_unchanged = 0b0
        self.flag_disk_change = 0b1000  # overview of disk changed
        self.flag_cpu_change = 0b100  # overview of cpu changed
        self.flag_ram_change = 0b10  # overview of ram changed
        self.flag_swap_change = 0b1  # overview of swap changed

        self.run_period = 2
        super(MonitorResourceSentry, self).__init__(seconds=self.run_period)

    def check_disk_healthy(self, host, partition, free, utilization):
        item_key_1 = "disk." + str(partition) + ".free"
        item_key_2 = "disk." + str(partition) + ".util"
        err_msg_1 = "%s分区空闲空间为%.2f" % (partition, free)
        err_msg_2 = "%s分区空间使用率为%.2f%%" % (partition, utilization)
        healthy1, is_switched1 = self.check_healthy_and_process_alert(host, 0, item_key_1, free, err_msg_1)
        healthy2, is_switched2 = self.check_healthy_and_process_alert(host, 0, item_key_2, utilization, err_msg_2)
        if healthy1 == -1 or healthy2 == -1:
            return -1
        return 0

    def check_cpu_healthy(self, host, cpu_data):
        err_msg_1 = "前1分钟内系统负载为%.2f" % cpu_data['l1']
        err_msg_2 = "前5分钟内系统负载为%.2f" % cpu_data['l5']
        err_msg_3 = "前15分钟内系统负载为%.2f" % cpu_data['l15']
        err_msg_4 = "CPU使用率为%.2f%%" % cpu_data['utilization']
        healthy1, is_switched1 = self.check_healthy_and_process_alert(host, 0, 'cpu.l1', cpu_data['l1'], err_msg_1)
        healthy2, is_switched2 = self.check_healthy_and_process_alert(host, 0, 'cpu.l5', cpu_data['l5'], err_msg_2)
        healthy3, is_switched3 = self.check_healthy_and_process_alert(host, 0, 'cpu.l15', cpu_data['l15'], err_msg_3)
        healthy4, is_switched4 = self.check_healthy_and_process_alert(host, 0, 'cpu.util', cpu_data['utilization'], err_msg_4)
        if healthy1 == -1 or healthy2 == -1 or healthy3 == -1 or healthy4 == -1:
            return -1
        return 0

    def check_ram_healthy(self, host, free, total):
        util = (1 - free / total)*100
        err_msg_1 = "内存空间为%.2f" % total
        err_msg_2 = "内存空闲空间为%.2f" % free
        err_msg_3 = "内存使用率为%.2f%%" % util
        healthy1, is_switched1 = self.check_healthy_and_process_alert(host, 0, "ram.total", total, err_msg_1)
        healthy2, is_switched2 = self.check_healthy_and_process_alert(host, 0, "ram.free", free, err_msg_2)
        healthy3, is_switched3 = self.check_healthy_and_process_alert(host, 0, "ram.util", util, err_msg_3)
        if healthy1 == -1 or healthy2 == -1 or healthy3 == -1:
            return -1
        return 0

    def check_swap_healthy(self, host, free, total):
        if total == 0:
            return 0
        used = total - free
        util = (1 - free / total) * 100
        err_msg_1 = "SWAP空间已使用%.2f" % used
        err_msg_2 = "SWAP使用率为%.2f%%" % util
        healthy1, is_switched1 = self.check_healthy_and_process_alert(host, 0, "swap.used", used, err_msg_1)
        healthy2, is_switched2 = self.check_healthy_and_process_alert(host, 0, "swap.util", util, err_msg_2)
        if healthy1 == -1 or healthy2 == -1:
            return -1
        return 0

    def init_host_context(self, host):
        self.ws_data[host] = {}
        self.ws_data[host]['disk'] = {}
        self.ws_data[host]['cpu'] = {}
        self.ws_data[host]['mem'] = {}
        self.ws_data[host]['sys'] = {}

        self.last_ws_data[host] = {}
        self.last_ws_data[host]['disk'] = {}
        self.last_ws_data[host]['cpu'] = {}
        self.last_ws_data[host]['mem'] = {}
        self.last_ws_data[host]['sys'] = {}

        self.hash_sockid[host] = {}
        self.hash_sockid[host]['disk'] = []
        self.hash_sockid[host]['cpu'] = []
        self.hash_sockid[host]['mem'] = []
        self.hash_sockid[host]['sys'] = []

        self.hash_overview_last[host] = {
            "disk_problem_last": -1,
            "cpu_problem_last": -1,
            "ram_problem_last": -1,
            "swap_problem_last": -1,
        }

    def get_data_from_redis(self, host):
        disk_ws_data = {
            'category': 'disk',
            'info': [],
            'time': '',
        }
        cpu_ws_data = {
            'category': 'cpu',
            'info': {},
            'time': '',
        }
        mem_ws_data = {
            'category': 'memory',
            'info': {},
            'time': '',
        }
        sys_ws_data = {
            'category': 'system',
            'info': {},
            'time': '',
        }

        if host not in self.ws_data.keys():
            self.init_host_context(host)
        monitor_data = self.hash_msg.get_key_msg('a:oss:monitor:resource', host)
        if monitor_data:
            monitor_data = json.loads(str(monitor_data, 'utf-8'))

            """ process disk info """
            disk_data = monitor_data['disks']
            #print("disk_data = %s" % disk_data)
            self.disk_problem = 0
            for item in disk_data:
                status = self.check_disk_healthy(host, item['partition'], item['free'], item['used_percent'])
                self.disk_problem += abs(status)
                data = {
                    'free': item['free'],
                    'partition': item['partition'],
                    'total': item['total'],
                    'utilization': item['used_percent'],
                    'status': status,
                }

                disk_ws_data['info'].append(data)

            self.ws_data[host]['disk'] = disk_ws_data

            """ process cpu info """
            cpu_data = monitor_data['load']
            healthy_l1, is_switched_l1 = self.check_healthy_and_process_alert(host, 0, 'cpu.l1', cpu_data['l1'])
            healthy_l5, is_switched_l5 = self.check_healthy_and_process_alert(host, 0, 'cpu.l5', cpu_data['l5'])
            healthy_l15, is_switched_l15 = self.check_healthy_and_process_alert(host, 0, 'cpu.l15', cpu_data['l15'])
            healthy_util, is_switched_util = self.check_healthy_and_process_alert(host, 0, 'cpu.util', cpu_data['utilization'])
            cpu_ws_data['info'] = {
                'l1': {
                    'used': cpu_data['l1'],
                    'status': healthy_l1,
                },
                'l5': {
                    'used': cpu_data['l5'],
                    'status': healthy_l5,
                },
                'l15': {
                    'used': cpu_data['l15'],
                    'status': healthy_l15,
                },
                'utilization': cpu_data['utilization'] * 100,
                'status': healthy_util,
            }

            self.cpu_problem = abs(self.check_cpu_healthy(host, cpu_data))
            self.ws_data[host]['cpu'] = cpu_ws_data

            """ process memory info """
            ram_data = monitor_data['ram']
            status = self.check_ram_healthy(host, ram_data['free'], ram_data['total'])
            self.ram_problem = abs(status)
            mem_ws_data['info']['ram'] = {
                'free': ram_data['free'],
                'status': status,
                'total': ram_data['total'],
                'utilization': (ram_data['total'] - ram_data['free']) / ram_data['total'] * 100,
            }

            swap_data = monitor_data['swap']
            status = self.check_swap_healthy(host, swap_data['free'], swap_data['total'])
            self.swap_problem = abs(status)
            mem_ws_data['info']['swap'] = {
                'free': swap_data['free'],
                'status': status,
                'total': swap_data['total'],
                'utilization': (swap_data['total'] - swap_data['free']) / swap_data['total'] * 100 if swap_data['total'] != 0 else 0,
            }
            self.ws_data[host]['mem'] = mem_ws_data

            """ process system info """
            id_data = self.hash_msg.get_key_msg('a:oss:monitor:id', host)
            if id_data:
                id_data = json.loads(str(id_data, 'utf-8'))
                sys_ws_data['info'] = {
                    'hostname': id_data['name'],
                    'os': id_data['release'],
                    'kernel': id_data['version'],
                    'ip': id_data['ip'],
                    'uptime': monitor_data.get('uptime', 0)
                }
            self.ws_data[host]['sys'] = sys_ws_data

    def update_overview(self, host):
        overview_last = self.hash_overview_last[host]
        flag_change = self.flag_unchanged
        if self.disk_problem != overview_last["disk_problem_last"]:
            flag_change = flag_change | self.flag_disk_change

        if self.cpu_problem != overview_last["cpu_problem_last"]:
            flag_change = flag_change | self.flag_cpu_change

        if self.ram_problem != overview_last["ram_problem_last"]:
            flag_change = flag_change | self.flag_ram_change

        if self.swap_problem != overview_last["swap_problem_last"]:
            flag_change = flag_change | self.flag_swap_change

        if flag_change == self.flag_unchanged:
            return

        overview_redis = self.hash_msg.get_key_msg('oss:monitor:overview:host_status', host)
        if overview_redis:
            overview_redis = json.loads(str(overview_redis, 'utf-8'))
        else:
            overview_redis = self.overview_stat_tmpl

        if flag_change & self.flag_disk_change == self.flag_disk_change:
            overview_redis['disk_problem'] = self.disk_problem
            self.hash_overview_last[host]["disk_problem_last"] = self.disk_problem

        if flag_change & self.flag_cpu_change == self.flag_cpu_change:
            overview_redis['cpu_problem'] = self.cpu_problem
            self.hash_overview_last[host]["cpu_problem_last"] = self.cpu_problem

        if flag_change & self.flag_ram_change == self.flag_ram_change:

            overview_redis['ram_problem'] = self.ram_problem
            self.hash_overview_last[host]["ram_problem_last"] = self.ram_problem

        if flag_change & self.flag_swap_change == self.flag_swap_change:
            overview_redis['swap_problem'] = self.swap_problem
            self.hash_overview_last[host]["swap_problem_last"] = self.swap_problem

        overview_redis['update_time'] = time.time()

        self.hash_msg.put_key_msg('oss:monitor:overview:host_status', host, json.dumps(overview_redis))

    def update_detail_and_socketid(self, host):
        if self.last_ws_data[host]['disk'] != self.ws_data[host]['disk']:
            self.last_ws_data[host]['disk'] = copy.deepcopy(self.ws_data[host]['disk'])
            self.hash_sockid[host]['disk'] = []

        if self.last_ws_data[host]['cpu'] != self.ws_data[host]['cpu']:
            self.last_ws_data[host]['cpu'] = copy.deepcopy(self.ws_data[host]['cpu'])
            self.hash_sockid[host]['cpu'] = []

        if self.last_ws_data[host]['mem'] != self.ws_data[host]['mem']:
            self.last_ws_data[host]['mem'] = copy.deepcopy(self.ws_data[host]['mem'])
            self.hash_sockid[host]['mem'] = []

        if self.last_ws_data[host]['sys'] != self.ws_data[host]['sys']:
            self.last_ws_data[host]['sys'] = copy.deepcopy(self.ws_data[host]['sys'])
            self.hash_sockid[host]['sys'] = []

    def send_websocket_data(self, host, clientid, msg_type):
        if host not in self.hash_sockid:
            logger.error("[Resource]%s not in hash_sockid" % host)
            return
        if clientid not in self.hash_sockid[host]['disk']:
            data = self.ws_data[host]['disk']
            data['time'] = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H:%M:%S.%f') + ' CST'
            send_websoket(msg_type, data, socket_id=clientid)
            self.hash_sockid[host]['disk'].append(clientid)

        if clientid not in self.hash_sockid[host]['cpu']:
            data = self.ws_data[host]['cpu']
            data['time'] = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H:%M:%S.%f') + ' CST'
            send_websoket(msg_type, data, socket_id=clientid)
            self.hash_sockid[host]['cpu'].append(clientid)

        if clientid not in self.hash_sockid[host]['mem']:
            data = self.ws_data[host]['mem']
            data['time'] = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H:%M:%S.%f') + ' CST'
            send_websoket(msg_type, data, socket_id=clientid)
            self.hash_sockid[host]['mem'].append(clientid)

        if clientid not in self.hash_sockid[host]['sys']:
            data = self.ws_data[host]['sys']
            data['time'] = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H:%M:%S.%f') + ' CST'
            send_websoket(msg_type, data, socket_id=clientid)
            self.hash_sockid[host]['sys'].append(clientid)


class MonitorOverviewSentry(MonitorBaseSentry):

    def __init__(self):
        self.shannon_back_data = {}
        self.turing_back_data = {}
        self.hash_msg = MessageHashMap()
        self.last_update_time = {}
        self.hash_timestamp = {}
        self.agent_timeout = 300  # unit: sec
        self.flag_check = False
        self.hash_overview_sockid = {
            'shannon': [],
            'turing': []
        }
        super(MonitorOverviewSentry, self).__init__(seconds=1)

    def back_agent_status(self, host, status):
        redis_key = "oss:monitor:overview:host_status"
        data = self.hash_msg.get_key_msg(redis_key, host)
        if not data:
            data = self.overview_stat_tmpl
        else:
            data = json.loads(str(data, 'utf-8'))

        data['agent_status'] = status
        data['update_time'] = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H:%M:%S.%f') + ' CST'
        self.hash_msg.put_key_msg(redis_key, host, json.dumps(data))

    def get_websocket_data(self, host_type):
        agent_offline = {
            'status': -2,
            'device': '0/0',
            'process': '0/0',
            'resource': '0/0',
            'alert': '0/0',
            'clock_diff': '0/0'
        }
        ret_data = {
            'host': 0,
            'info': {},
        }
        all_hosts = []
        if "shannon" == host_type:
            all_hosts = MonitorMySQLSentry().shannon_hosts
        elif "turing" == host_type:
            all_hosts = MonitorMySQLSentry().turing_hosts
        ret_data['host'] = len(all_hosts)

        for host in all_hosts:
            if host not in self.hosts_reg:
                ret_data['info'][host] = agent_offline
                err_msg = "agent未注册"
                healthy, is_switched = self.check_healthy_and_process_alert(host, 0, "agent.conn", -2, err_msg)
                if is_switched and -1 == healthy:
                    logger.info("[Overview]host %s not register. Have registered %s" % (host, self.hosts_reg))
                self.back_agent_status(host, -2)
                continue

            """利用上报的监控资源数据判断主机是否离线"""
            monitor_data = self.hash_msg.get_key_msg('a:oss:monitor:resource', host)
            if not monitor_data:
                ret_data['info'][host] = agent_offline
                err_msg = "agent已注册，但未上报资源数据"
                healthy, is_switched = self.check_healthy_and_process_alert(host, 0, "agent.conn", -2, err_msg)
                if is_switched and -1 == healthy:
                    logger.info("[Overview]host %s had register, but no report resource data." % host)
                self.back_agent_status(host, -2)
                continue

            update_time = json.loads(str(monitor_data, 'utf-8')).get('update_time', '')
            update_time = update_time[0:-4]
            if host in self.last_update_time.keys():
                if update_time == self.last_update_time[host]:
                    if datetime.datetime.now() - self.hash_timestamp[host] > datetime.timedelta(seconds=self.agent_timeout):
                        ret_data['info'][host] = agent_offline
                        err_msg = "agent已%d分钟未上报资源数据，最后一次时间戳%s" % (self.agent_timeout/60, update_time)
                        healthy, is_switched = self.check_healthy_and_process_alert(host, 0, "agent.conn", -2, err_msg)
                        if is_switched and -1 == healthy:
                            logger.info("[Overview]%s not update timestamp(%s) over last %d seconds." \
                                     % (host, update_time, self.agent_timeout))
                        self.back_agent_status(host, -2)
                        continue
                else:
                    self.last_update_time[host] = update_time
                    self.hash_timestamp[host] = datetime.datetime.now()
                    logger.debug("[Overview]%s update timestamp(%s) at %s" % (host, self.last_update_time[host], self.hash_timestamp[host]))
            else:
                self.last_update_time[host] = update_time
                self.hash_timestamp[host] = datetime.datetime.now()
                logger.info("[Overview]Get the first timestamp(%s) of %s at %s" % \
                            (self.last_update_time[host], host, self.hash_timestamp[host]))

            overview_redis = self.hash_msg.get_key_msg('oss:monitor:overview:host_status', host)
            if not overview_redis:
                ret_data['info'][host] = agent_offline
                err_msg = "host %s is not in oss:monitor:overview:host_status" % host
                healthy, is_switched = self.check_healthy_and_process_alert(host, 0, "agent.conn", -2, err_msg)
                if is_switched and -1 == healthy:
                    logger.error('[Overview]host %s is not in oss:monitor:overview:host_status' % (host))
                self.back_agent_status(host, -2)
                continue

            ret_data['info'][host] = {}
            overview_redis = json.loads(str(overview_redis, 'utf-8'))
            status, problem = 0, 0
            problem = overview_redis['disk_problem'] + overview_redis['cpu_problem'] + overview_redis['ram_problem'] + overview_redis['swap_problem']
            if problem > 0:
                status = -1
            ret_data['info'][host]['resource'] = '%s/6' % (problem)

            if overview_redis['device_problem'] > 0:
                status = -1
            ret_data['info'][host]['device'] = '%s/%s' % (overview_redis['device_problem'], overview_redis['device_total'])

            if overview_redis['process_problem'] > 0:
                status = -1
            ret_data['info'][host]['process'] = '%s/%s' % (overview_redis['process_problem'], overview_redis['process_total'])

            if overview_redis['alert_problem'] > 0:
                status = -1
            ret_data['info'][host]['alert'] = '%s/0' % (overview_redis['alert_problem'])

            if overview_redis['clock_diff_status'] == -1:
                status = -1
            ret_data['info'][host]['clock_diff'] = '%.2f/%s' % (overview_redis['clock_diff'], overview_redis['clock_diff_status'])

            ret_data['info'][host]['status'] = status

            self.back_agent_status(host, status)
            healthy, is_switched = self.check_healthy_and_process_alert(host, 0, "agent.conn", status)

        return ret_data

    def update_overview_and_socketid(self, host_type, data):
        if 'shannon' == host_type:
            if self.shannon_back_data == data:
                return
            self.shannon_back_data = copy.deepcopy(data)
            self.hash_overview_sockid['shannon'] = []
        elif 'turing' == host_type:
            if self.turing_back_data == data:
                return
            self.turing_back_data = copy.deepcopy(data)
            self.hash_overview_sockid['turing'] = []

    def get_and_push_overview(self, host_type):
        data = self.get_websocket_data(host_type)
        self.update_overview_and_socketid(host_type, data)
        data['time'] = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H:%M:%S.%f') + ' CST'

        overview_sockid = self.hash_overview_sockid[host_type]
        msg_type = "%s_overview" % host_type
        agents = get_type_agent(msg_type)
        for agent in agents:
            if agent['socket_id'] not in overview_sockid:
                send_websoket(msg_type, data, socket_id=agent['socket_id'])
                overview_sockid.append(agent['socket_id'])

    def check_agent_online(self):
        if not MonitorMySQLSentry().is_trading_day:
            return

        for host in MonitorMySQLSentry().hosts_monitored:
            query_key = host + "_" + "agent.conn"
            if query_key not in MonitorMySQLSentry().alerts_define.keys():
                logger.error("[overview]No found alert define for %s" % query_key)
                continue

            alerts_define = MonitorMySQLSentry().alerts_define[query_key]
            num = len(alerts_define)
            for i in range(num):
                if -1 == alerts_define[i]['status']:
                    severity = alerts_define[i]['severity']
                    color = MonitorMySQLSentry().severity_define[severity]['color']
                    oss_alert = {
                        "key": "agent.conn",
                        "host": host,
                        "process_id": 0,
                        "operator": alerts_define[i]['operator'],
                        "threshold": alerts_define[i]['threshold'],
                        "msg": "[agent离线]定时扫描发现%s离线" % host,
                        "status": -1,
                        "severity": severity,
                        "ring_type": MonitorMySQLSentry().severity_define[severity]['ring_type'],
                        "is_ring": True,
                        "category": alerts_define[i]['category'],
                        "alert_type": 2,  # 故障告警
                        "color": color,
                        "monitor_time": alerts_define[i]['monitor_time'],
                        "clock": str(datetime.datetime.now())
                    }
                    self.alerts_mng.oss_alerts.append(oss_alert)

    @gen.coroutine
    def work_process(self):
        try:
            self.get_hosts_reg()

            self.get_and_push_overview("shannon")
            self.get_and_push_overview("turing")

            now = datetime.datetime.now()
            now_time = datetime.time(now.hour, now.minute)
            day_check_time = datetime.time(8, 30)
            night_check_time = datetime.time(20, 30)
            if now_time == day_check_time or now_time == night_check_time:
                if not self.flag_check:
                    self.check_agent_online()
                    self.flag_check = True
            else:
                self.flag_check = False
        except Exception as e:
            logger.error("[Overview]Catch exception: %s" % str(e))


class MonitorAlertsSentry(MonitorBaseSentry):

    def __init__(self):
        self.launch_queue = MessageList('a:oss:launch')
        self.hash_msg = MessageHashMap()

        self.overview_host_stat_last = {}
        self.overview_host_stat = {}
        self.event_sockid = {}
        self.fault_sockid = {}
        self.history_sockid = {}
        self.shannon_overview_sockid = []
        self.turing_overview_sockid = []

        self.event_show_expire = 5  # unit: min   #just for test
        self.flag_clear_history_alerts = True
        self.day_clear_time = datetime.time(6, 0)
        self.night_clear_time = datetime.time(18, 0)
        self.reserved_category = ['cpu', 'memory', 'swap', 'disk', 'dev', 'agent', 'clock']

        self.run_period = 1
        super(MonitorAlertsSentry, self).__init__(seconds=self.run_period)

    def init_host_context(self, host):
        self.alerts_mng.init_host_context(host)
        self.event_sockid[host] = []
        self.fault_sockid[host] = []
        self.history_sockid[host] = []

        self.overview_host_stat[host] = 0
        self.overview_host_stat_last[host] = -1

    def clear_history_alerts_at_close(self):
        now = datetime.datetime.now()
        now_time = datetime.time(now.hour, now.minute)

        if now_time != self.day_clear_time and now_time != self.night_clear_time:
            self.flag_clear_history_alerts = False
            return

        if not self.flag_clear_history_alerts:
            for host in self.hosts_reg:
                if host not in MonitorMySQLSentry().hosts_monitored:
                    logger.debug("[Alert]%s not in monitor list !" % host)
                    continue

                #if host not in self.history_alerts.keys():
                if self.alerts_mng.host_is_exist(host):
                    self.init_host_context(host)
                    continue

                self.alerts_mng.update_host_history_alerts_at_close(host)

            self.flag_clear_history_alerts = True

    def process_launch_alert(self, host, process_id, status, msg, event_time):
        item_key = 'process.start_status.' + str(process_id)
        query_key = host + '_' + item_key
        if query_key not in MonitorMySQLSentry().alerts_define.keys():
            logger.error("[Alert]No defined of %s" % query_key)
            return
        alerts_define = MonitorMySQLSentry().alerts_define[query_key]
        for i in range(len(alerts_define)):
            if not alerts_define[i]['enabled']:
                continue

            severity = alerts_define[i]['severity']
            key_cn = alerts_define[i]['key_cn']
            global max_id
            max_id += 1
            new_alert = {
                "id": max_id,
                "process_id": int(process_id),
                "alert_id": item_key,
                "msg": msg,
                "severity": severity,
                "status": status,
                "category": alerts_define[i]['category'],
                "color": MonitorMySQLSentry().severity_define[severity]['color'],
                "ring_type": MonitorMySQLSentry().severity_define[severity]['ring_type'],
                "is_ring": True,
                "clock": event_time,
                "host": host,
                "alert_type": 2
            }

            if not MonitorMySQLSentry().in_alert_time(alerts_define[i]['monitor_time']):
                logger.debug("[Alert]The alert is no in alert time. %s" % new_alert)
                self.alerts_mng.update_start_process_alerts(new_alert, 'filtered')
                continue

            self.alerts_mng.update_start_process_alerts(new_alert, 'detail')
            self.alerts_mng.update_detail_history_alerts(new_alert)
            if host in MonitorMySQLSentry().shannon_hosts:
                self.alerts_mng.update_start_process_alerts(new_alert, "shannon")
            elif host in MonitorMySQLSentry().turing_hosts:
                self.alerts_mng.update_start_process_alerts(new_alert, "turing")
            else:
                logger.error("[Alert]rcv alert from %s, but is not found in mysql" % host)

            #  产生事件
            event = {
                "key": 'process.start_status.' + str(process_id),
                "host": host,
                "process_id": int(process_id),
                "operator": "=",
                "threshold": -1,
                "msg": "%s (%s, process %s)" % (msg, host, process_id),
                "status": status,
                "clock": event_time,
            }
            post_trigger_event(event)

    def monitor_start_process(self):
        for host in self.hosts_need_monitored:
            if not self.alerts_mng.host_is_exist(host):
                self.init_host_context(host)
            # 从自动化部署服务获取进程的信息
            redis_key = "oss:deploy:monitor:processes:%s" % host
            processes = self.hash_msg.get_key_all(redis_key)
            if not processes:
                continue
            for p_id, p in processes.items():
                process_info = json.loads(str(p, 'utf-8'))
                process_id = process_info['process_id']

                # 0:待处理  1：正在处理  2：阻塞  3：完成处理
                if 3 == process_info['monitor_progress']:
                    continue
                elif 0 == process_info['monitor_progress']:
                    if 0 == process_info['is_running']:
                        logger.info("[Alert:launch]%s, stop process %s, so clear it's last alerts." % (host, process_id))
                        self.alerts_mng.clear_process_alerts(host, process_id)
                        process_info['monitor_progress'] = 3
                        self.hash_msg.put_key_msg(redis_key, process_id, json.dumps(process_info))
                        continue
                    elif 1 == process_info['is_running']:
                        logger.info("[Alert:launch]%s, start process %s, so clear it's last alerts." % (host, process_id))
                        self.alerts_mng.clear_process_alerts(host, process_id)
                        process_info['monitor_progress'] = 1

                # 查询agent是否上报了进程的启动信息
                start_info = self.launch_queue.pop_host_pid_msg(host, process_id)
                if start_info:
                    data = json.loads(str(start_info, 'utf-8', 'ignore'))
                    logger.info("[launch]read %s from a:oss:launch" % data)
                    if 1 == process_info['is_running'] and 0 == data['status'] and 100 == data['stage']:
                        if process_info['launch_status'] == -1:
                            event_time = data.get('update_time', '')
                            event_time = event_time[:-4]
                            msg = '[进程启动恢复]'
                            self.process_launch_alert(host, process_id, 0, msg, event_time)
                            logger.info('%s, process %s start recovery', host, process_id)
                        process_info['monitor_progress'] = 3
                        process_info['launch_status'] = 0
                        #self.hash_msg.put_key_msg(redis_key, process_id, json.dumps(process_info))
                    elif -1 == data['status']:
                        msg = '[进程启动失败]stage %s, error: %s' % (data['stage'], data['desc'])
                        logger.error("[launch]%s, %s, process %s" % (msg, host, process_id))

                        event_time = data.get('update_time', '')
                        event_time = event_time[:-4]
                        self.process_launch_alert(host, process_id, -1, msg, event_time)
                        process_info['launch_status'] = -1
                else:
                    now_time = time.time()
                    start_time = process_info['clock']
                    time_diff = now_time - start_time
                    if time_diff >= self.process_start_timeout and process_info['monitor_progress'] != 2:
                        msg = '[进程启动被阻塞]'
                        logger.error("[launch]%s, %s, process %s. start time: %s, now: %s, timeout: %s" %
                                     (msg, host, process_id, start_time, now_time, time_diff))
                        event_time = str(datetime.datetime.now())
                        self.process_launch_alert(host, process_id, -1, msg, event_time)
                        process_info['monitor_progress'] = 2
                        process_info['launch_status'] = -1

                self.hash_msg.put_key_msg(redis_key, process_id, json.dumps(process_info))

    def check_event_alerts_show_expire(self):
        #print("check_event_alerts_show_expire")
        for host in self.hosts_need_monitored:
            self.alerts_mng.del_detail_event_alerts_expired(host, self.event_show_expire)

        '''overview alert'''
        self.alerts_mng.del_overview_event_alerts_expired(self.event_show_expire)

    def process_oss_fault_alerts(self):
        if 0 == len(self.alerts_mng.oss_alerts):
            return

        oss_alert = self.alerts_mng.oss_alerts.pop(0)
        host = oss_alert['host']
        # agent are close
        if host in self.agent_open_close.keys() and self.agent_open_close[host] == 2:
            logger.info('{} was close, so discard the alert: {}'.format(host, oss_alert))
            return
        logger.info("[Alert]get oss alert: %s" % oss_alert)

        global max_id
        max_id += 1
        front_alert = {
            'id': max_id,
            'host': oss_alert['host'],
            'process_id': oss_alert['process_id'],
            'alert_id': oss_alert['key'],
            'msg': oss_alert['msg'],
            'severity': oss_alert['severity'],
            'status': oss_alert['status'],
            'category': oss_alert['category'],
            'alert_type': oss_alert['alert_type'],
            'color': oss_alert['color'],
            'clock': oss_alert['clock'],
            'ring_type': oss_alert['ring_type'],
            "is_ring": True,
        }

        if not self.alerts_mng.host_is_exist(host):
            self.init_host_context(host)

        # 非告警时间，暂不通知告警产生；如果是告警恢复，需同步到前端
        is_in_alert_time = MonitorMySQLSentry().in_alert_time(oss_alert['monitor_time'])
        if not is_in_alert_time:
            '''更新被过滤的故障告警'''
            self.alerts_mng.update_fault_alerts_filtered(front_alert)
            if oss_alert['status'] == -1:
                logger.info("The oss alert is no in alert time, so no send alert(%s)." % (oss_alert))
                return

        '''fault alert'''
        self.alerts_mng.update_detail_fault_alerts(front_alert)

        '''告警时间，如果被过滤的故障告警非空，收到恢复告警时检查是否有匹配的产生告警'''
        #if 0 != len(self.fault_alerts_filtered) and 0 == front_alert['status']:
        if 0 == front_alert['status']:
            self.alerts_mng.update_fault_alerts_filtered(front_alert)

        '''overview alert'''
        if host in MonitorMySQLSentry().shannon_hosts:
            self.alerts_mng.update_overview_alerts(front_alert, "shannon", self.event_show_expire)
        elif host in MonitorMySQLSentry().turing_hosts:
            self.alerts_mng.update_overview_alerts(front_alert, "turing", self.event_show_expire)

        '''history alert'''
        self.alerts_mng.update_detail_history_alerts(front_alert)

        '''非监控时段不发送告警'''
        if not is_in_alert_time:
            return
        event = {
            'key': oss_alert['key'],
            'host': oss_alert['host'],
            'process_id': oss_alert['process_id'],
            'operator': oss_alert['operator'],
            'threshold': oss_alert['threshold'],
            'msg': oss_alert['msg'],
            'status': oss_alert['status'],
            'clock': oss_alert['clock']
        }
        if event['process_id'] == 0:
            event['msg'] = "%s (%s)" % (event['msg'], host)
        else:
            event['msg'] = "%s (%s, process %s)" % (event['msg'], host, event['process_id'])
        post_trigger_event(event)

    def monitor_agent_alerts(self):
        '''
        for host in self.hosts_reg:
            if host not in MonitorMySQLSentry().hosts_monitored:
                logger.debug("[Alert]%s not in monitor list !" % host)
                continue
            # if host not in self.event_alerts.keys():
        '''
        for host in self.hosts_need_monitored:
            if not self.alerts_mng.host_is_exist(host):
                self.init_host_context(host)
            self.process_agent_alerts(host)

    def process_agent_alerts(self, host):
        redis_key = "a:oss:alerts:%s" % host
        logger.debug("##########%s", redis_key)
        monitor_data = []
        bulk_events = []
        try:
            monitor_data = MessageList(redis_key).pop_all_msg(max_size=1000)
        except Exception as e:
            logger.error("[Alert]Read %s, but catch exception: %s" % (redis_key, str(e)))
            return

        if not monitor_data:
            return

        for alert_data in monitor_data:
            logger.info("[Alert][%s]read: %s" % (redis_key, alert_data))
            try:
                alert_data = json.loads(str(alert_data, 'utf-8'))
            except:
                alert_data = json.loads(str(alert_data, 'gb18030', 'ignore'))

            if alert_data['type'] == 2 and alert_data['data']['alert_id'] == 2101:
                self.stra_place_order_in_premarket_trading(alert_data)
                continue

            update_time = alert_data.get('update_time', '')
            update_time = update_time[: -4]
            alert_data['data']['alert_id'] = str(alert_data['data']['alert_id']) + '.' + str(alert_data['data']['process_id'])
            query_key = host + '_' + str(alert_data['data']['alert_id'])
            if query_key not in MonitorMySQLSentry().alerts_define.keys():
                logger.error("[Alert]No defined alert: %s" % query_key)
                continue
            alerts_define = MonitorMySQLSentry().alerts_define[query_key]
            for i in range(len(alerts_define)):
                if not alerts_define[i]['enabled']:
                    continue

                severity = alerts_define[i]['severity']
                key_cn = alerts_define[i]['key_cn']
                msg = ""
                if -1 == alert_data['data']['status']:
                    msg = "[%s异常]%s" % (key_cn, alert_data['data']['msg'])
                elif 0 == alert_data['data']['status']:
                    msg = "[%s恢复]%s" % (key_cn, alert_data['data']['msg'])
                else:
                    logger.error("[Alert]Undefined status(%s) of alert !" % alert_data['data']['status'])

                global max_id
                max_id += 1
                front_alert = {
                    "id": max_id,
                    "process_id": alert_data['data']['process_id'],
                    "alert_id": str(alert_data['data']['alert_id']),
                    "msg": msg,
                    "severity": severity,
                    "status": alert_data['data']['status'],
                    "category": alerts_define[i]['category'],
                    "color": MonitorMySQLSentry().severity_define[severity]['color'],
                    "ring_type": MonitorMySQLSentry().severity_define[severity]['ring_type'],
                    "is_ring": True,
                    "clock": update_time,
                    "host": host,
                    "alert_type": 0
                }
                if alert_data['type'] == 2:
                    '''event alert'''
                    front_alert['alert_type'] = 1
                elif alert_data['type'] == 3:
                    '''fault alert'''
                    front_alert['alert_type'] = 2
                else:
                    logger.error("[Alert]Undefined alerttype %d" % alert_data['type'])
                    continue

                if not MonitorMySQLSentry().in_alert_time(alerts_define[i]['monitor_time']):
                    if alert_data['type'] == 3:
                        self.alerts_mng.update_fault_alerts_filtered(front_alert)
                    logger.info("[Alert]The alert is no in alert time. %s" % front_alert)
                    continue

                if alert_data['type'] == 2:
                    self.alerts_mng.update_detail_event_alerts(front_alert, self.event_show_expire)
                elif alert_data['type'] == 3:
                    self.alerts_mng.update_detail_fault_alerts(front_alert)

                '''告警时间段，如果被过滤的故障告警非空，收到恢复告警时检查是否有匹配的产生告警'''
                #if 0 != len(self.fault_alerts_filtered) and 0 == front_alert['status']:
                if 0 == front_alert['status']:
                    self.alerts_mng.update_fault_alerts_filtered(front_alert)

                '''overview alert'''
                if host in MonitorMySQLSentry().shannon_hosts:
                    self.alerts_mng.update_overview_alerts(front_alert, "shannon")
                elif host in MonitorMySQLSentry().turing_hosts:
                    self.alerts_mng.update_overview_alerts(front_alert, "turing")
                else:
                    logger.warn("Recv an alert, but %s is not monitored. The alert is %s" % (host, front_alert))

                '''history alert'''
                self.alerts_mng.update_detail_history_alerts(front_alert)

                msg = ""
                if 0 == front_alert['process_id']:
                    msg = "%s (%s)" % (front_alert['msg'], host)
                else:
                    msg = "%s (%s, process %s)" % (front_alert['msg'], host, front_alert['process_id'])
                payload = {
                    "key": front_alert['alert_id'],
                    "host": host,
                    "process_id": front_alert['process_id'],
                    "operator": alerts_define[i]['operator'],
                    "threshold": alerts_define[i]['threshold'],
                    "msg": msg,
                    "status": front_alert['status'],
                    "clock": front_alert['clock'],
                }
                bulk_events.append(payload)

        if len(bulk_events) > 0:
            self.async_post_bulk_trigger_events(bulk_events)

    @gen.coroutine
    def async_post_bulk_trigger_events(self, events):
        url = get_url("/api/v1/event_handle/trigger_event/bulk_events", svr_port=80)
        try:
            http_client = tornado.httpclient.AsyncHTTPClient()
            response = yield gen.Task(
                http_client.fetch,
                url,
                method='POST',
                headers=headers,
                body=json.dumps(events),
            )
            #logger.info('async_post_bulk_trigger_events resp=%s' % response.body)

        except Exception as e:
            logger.error(str(e))
            return

    def send_host_alert(self, type, host, clientid, msg_type):
        data = {}
        if type == "event_alert":
            data = {
                "category": "event_alert",
                "info": self.alerts_mng.get_host_event_alerts(host)
            }
            #print("====event_alert==== %s" % self.event_alerts[host])
        elif type == "fault_alert":
            data = {
                "category": "fault_alert",
                "info": self.alerts_mng.get_host_fault_alerts(host)
            }
            #print("====fault_alerts==== %s" % self.fault_alerts[host])
        elif type == "history_alert":
            data = {
                "category": "alert_history",
                "info": self.alerts_mng.get_host_history_alerts(host)
            }
            #print("====history_alerts==== %s" % self.history_alerts[host])

        send_websoket(msg_type, data, socket_id=clientid)

    def send_overview_alerts(self, host_type):
        overview_alerts = []
        last_overview_alerts = []
        overview_sockid = []
        if "shannon" == host_type:
            if self.alerts_mng.update_shannon_last_overview_alerts():
                self.shannon_overview_sockid = []

            overview_alerts = self.alerts_mng.get_shannon_overview_alerts()
            overview_sockid = self.shannon_overview_sockid
        elif "turing" == host_type:
            if self.alerts_mng.update_turing_last_overview_alerts():
                self.turing_overview_sockid = []

            overview_alerts = self.alerts_mng.get_turing_overview_alerts()
            overview_sockid = self.turing_overview_sockid

        agent_type = "%s_overview" % host_type
        msg_type = "%s_alert" % host_type
        agents = get_type_agent(agent_type)
        for agent in agents:
            if agent['socket_id'] not in overview_sockid:
                send_websoket(msg_type, overview_alerts, socket_id=agent['socket_id'])
                overview_sockid.append(agent['socket_id'])

    def update_detail_sent_socketid(self):
        for host in self.hosts_reg:
            if host not in MonitorMySQLSentry().hosts_monitored:
                logger.debug("[Alert]%s not in monitor list !" % host)
                continue

            #if host not in self.event_alerts.keys():
            if not self.alerts_mng.host_is_exist(host):
                self.init_host_context(host)

            if self.alerts_mng.update_host_last_event_alerts(host):
                self.event_sockid[host] = []

            if self.alerts_mng.update_host_last_fault_alerts(host):
                self.fault_sockid[host] = []

            if self.alerts_mng.update_host_last_history_alerts(host):
                self.history_sockid[host] = []

    def send_detail_alerts(self, host_type):
        # print("send_detail_alerts")
        self.update_detail_sent_socketid()
        agent_type = "%s_detail" % host_type
        hostname = "%s_hostname" % host_type
        agents = get_type_agent(agent_type)
        for agent in agents:
            if agent['oss_detail'].get(hostname):
                host = agent['oss_detail'][hostname]
                if host in self.event_sockid.keys():
                    if agent['socket_id'] not in self.event_sockid[host]:
                        self.send_host_alert("event_alert", host, agent['socket_id'], agent_type)
                        self.event_sockid[host].append(agent['socket_id'])

                if host in self.fault_sockid.keys():
                    if agent['socket_id'] not in self.fault_sockid[host]:
                        self.send_host_alert("fault_alert", host, agent['socket_id'], agent_type)
                        self.fault_sockid[host].append(agent['socket_id'])

                if host in self.history_sockid.keys():
                    if agent['socket_id'] not in self.history_sockid[host]:
                        self.send_host_alert("history_alert", host, agent['socket_id'], agent_type)
                        self.history_sockid[host].append(agent['socket_id'])

    def check_fault_alerts_filtered(self):
        bulk_events = self.alerts_mng.get_fault_alerts_filtered_to_send(self.event_show_expire)
        if len(bulk_events) > 0:
            self.async_post_bulk_trigger_events(bulk_events)

    def update_overview_host_statistics(self):
        for host in self.hosts_need_monitored:
            self.overview_host_stat[host] = 0

        for alert in self.alerts_mng.get_shannon_overview_alerts():
            host = alert['host']
            self.overview_host_stat[host] += 1
        for alert in self.alerts_mng.get_turing_overview_alerts():
            host = alert['host']
            self.overview_host_stat[host] += 1

        for host in self.overview_host_stat.keys():
            if self.overview_host_stat_last[host] == self.overview_host_stat[host]:
                continue
            else:
                self.overview_host_stat_last[host] = self.overview_host_stat[host]

            overview_redis = self.hash_msg.get_key_msg('oss:monitor:overview:host_status', host)
            if overview_redis:
                overview_redis = json.loads(str(overview_redis, 'utf-8'))
            else:
                overview_redis = self.overview_stat_tmpl
            overview_redis['alert_problem'] = self.overview_host_stat[host]
            self.hash_msg.put_key_msg('oss:monitor:overview:host_status', host, json.dumps(overview_redis))

    def stra_place_order_in_premarket_trading(self, alert):
        stra_id = int(alert['data']['msg'].split('.')[-1])
        update_time = alert.get('update_time', '')
        if update_time:
            update_time = update_time[: -4]

        info = {
            'is_place_order': 1, # 1:有报单; 0:无报单
            'time': update_time  # 策略第一次报单时间
        }
        redis_key = 'oss:monitor:stra_place_order:in_premarket_trading'
        self.hash_msg.put_key_msg(redis_key, stra_id, json.dumps(info))
        logger.info('At %s, strategy %d place order in pre-market trading.', update_time, stra_id)

    @gen.coroutine
    def work_process(self):
        try:
            #self.get_hosts_reg()
            self.get_hosts_monitored()

            self.monitor_start_process()
            self.monitor_agent_alerts()
            self.process_oss_fault_alerts()
            self.check_fault_alerts_filtered()
            self.check_event_alerts_show_expire()
            self.update_overview_host_statistics()

            self.send_detail_alerts("shannon")
            self.send_overview_alerts("shannon")
            self.send_detail_alerts("turing")
            self.send_overview_alerts("turing")

            self.clear_history_alerts_at_close()
            self.alerts_mng.alert_ring_update()
        except Exception as e:
            logger.error("[Alert]Catch exception: %s" % str(e))


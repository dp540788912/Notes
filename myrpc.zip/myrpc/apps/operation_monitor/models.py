# encoding:utf-8

from sqlalchemy.orm import relationship
from sqlalchemy import BigInteger, Integer, Float, String, Date, DateTime, Boolean, Text, Column, ForeignKey
from db import ModelBase, session_context as mysql_sc


class ShannonProgramTypes(ModelBase):

    __tablename__ = 'program_types'

    id = Column(BigInteger, primary_key=True)
    name = Column(String(32), nullable=False, unique=True)

class ShannonDeployConfs(ModelBase):

    __tablename__ = 'deploy_confs'

    id = Column(BigInteger, primary_key=True)
    host = Column(String(45), nullable=False)
    program_type_id = Column(ForeignKey('program_types.id'), nullable=True)
    valid = Column(Boolean, default=True, nullable=True)
    program_type_obj = relationship('ShannonProgramTypes')


class TuringProgramTypes(ModelBase):

    __tablename__ = 'turing_program_types'

    id = Column(Integer, primary_key=True)
    name = Column(String(32), nullable=False, unique=True)

class TuringPrograms(ModelBase):

    __tablename__ = 'turing_programs'

    id = Column(BigInteger, primary_key=True)
    name = Column(String(32), nullable=False, unique=True)
    type_id = Column(Integer, nullable=False)
    filepath = Column(String(512), nullable=False)
    version = Column(String(32), nullable=False)

class TuringDeployConfs(ModelBase):

    __tablename__ = 'turing_deploy_confs'

    id = Column(BigInteger, primary_key=True)
    name = Column(String(256), nullable=True)
    host = Column(String(45), nullable=False)
    deploy_path = Column(String(256), nullable=False)
    day_night = Column(Integer, nullable=False)
    program_id = Column(BigInteger, nullable=True)
    content = Column(Text, nullable=True)
    result = Column(Integer, nullable=True, default=0)
    status = Column(Integer, nullable=True, default=1)
    valid = Column(Boolean, default=True, nullable=True)


class ShannonServers(ModelBase):

    __tablename__ = 'servers'

    id = Column(BigInteger, primary_key=True)
    ip = Column(String(45), nullable=False, unique=True)
    broker_id = Column(Integer, nullable=False)
    # 1: ��� 0:�����
    monitor_status = Column(Integer(), nullable=False)

class TuringServers(ModelBase):

    __tablename__ = 'turing_servers'

    id = Column(BigInteger, primary_key=True)
    ip = Column(String(45), nullable=False, unique=True)
    broker_id = Column(Integer, nullable=False)
    # 1: ��� 0:�����
    monitor_status = Column(Integer(), nullable=False)

if __name__ == '__main__':
    from db import engine
    ModelBase.metadata.create_all(engine)


# -*- coding:utf-8 -*-

import smtplib
from email.header import Header
from email.mime.text import MIMEText
from email.utils import parseaddr, formataddr


# email params
FROM_ADDR = "rss@mycapital.net"
PASSWORD = "Mycapital0427"
SMTP_SERVER = "smtp.qiye.163.com"
SMTP_SERVER_PORT = 25


def format_addr(address):
    name, addr = parseaddr(address)
    return formataddr((Header(name, 'utf-8').encode(), addr))


def send_email(title, content, to_addrs):
    email_title = title
    msg = MIMEText(content, "plain", "utf-8")
    msg["From"] = format_addr("<%s>" % FROM_ADDR)
    msg_to = ""
    for to_addr in to_addrs:
        msg_to += format_addr("<%s>" % to_addr) + ','
    msg["To"] = msg_to[:-1]
    msg["Subject"] = Header(email_title, "utf-8").encode()


    server = smtplib.SMTP(SMTP_SERVER, SMTP_SERVER_PORT)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login(FROM_ADDR, PASSWORD)
    server.sendmail(FROM_ADDR, to_addrs, msg.as_string())
    server.quit()


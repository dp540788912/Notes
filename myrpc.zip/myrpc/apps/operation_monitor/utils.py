# encoding: utf-8

import re
import json
import requests
import datetime
from redis_api import RedisConnector, MessageSet, MessageHashMap, MessageList
from config import *
from log import logger

headers = {
    'content-type': 'application/json',
    'whitelist': 'operater',
}

def send_websoket(msg_type, msg_data, user_id=None, socket_id=None):
    rds = RedisConnector.reuse()
    """
    data = {
        'msg_type': '1111',
        'msg_data': '22222',
        'user_id': 2,
    }
    """
    data = {
        'msg_type': msg_type,
        'msg_data': msg_data,
        'user_id': user_id,
        'socket_id': socket_id,
    }
    #print(data)
    #print("============")
    return rds.publish("websocketmessage", json.dumps(data))


def get_type_agent(agent_type):
    rds_map = MessageHashMap("a:rss:websocket")
    agents = []
    for _, v in rds_map.get_all().items():
        a = json.loads(str(v, 'utf-8'))
        if (a['msg_type'] == agent_type) or (agent_type == 'all'):
            agents.append(a)
    return agents


def check_healthy(operator,threshold,value):
    ret = 0
    if operator == '=':
        if value == threshold:
            ret = -1
    elif operator == '>':
        if value > threshold:
            ret = -1
    elif operator == '<':
        if value < threshold:
            ret = -1
    elif operator == '#':
        if value != threshold:
            ret = -1

    return ret


def get_url(url,svr_ip=config.mysql['host'],svr_port=config.mysql['port']):
    return "http://" + svr_ip + ":" + str(svr_port) + url


def post_trigger_event(trigger_event):
    url = get_url("/api/v1/event_handle/trigger_event/event", svr_port=80)
    try:
        r = requests.post(url, data=json.dumps(trigger_event), headers=headers)
        if r.status_code != requests.codes.ok:
            logger.error("Fail to post a trigger event: %s" % trigger_event)
            logger.error("url = %s, err_code = %s" % (url, r.status_code))
    except Exception as e:
        logger.error("Fail to post a trigger event: %s, Exception: %s !" % (trigger_event, str(e)))
        return


def convert_to_24hour(hour, minute, am_pm):
    if am_pm.strip() == "pm" and hour < 12:
        hour += 12
    if am_pm.strip() == "am" and hour == 12:
        hour -= 12
    return datetime.time(hour, minute)


def alert_time_to_list(str_time):
    try:
        if str_time == None:
            return None

        #time_re = re.compile(r'^(0[1-9]|[1-9]|1[0-2]):([0-5]\d)([apAP][mM])$')
        time_re = re.compile(r'^(0\d|\d|1[0-2]):([0-5]\d)([apAP][mM])$')
        time_list = str_time.split(',')
        ret_list = []
        for item_time in time_list:
            time_s_e = item_time.split('-')
            if not time_s_e or len(time_s_e) != 2:
                continue
            time_obj = {}
            start = time_re.match(time_s_e[0])
            end = time_re.match(time_s_e[1])
            if start and end:
                #print start.group(1), start.group(2), start.group(3)
                time_obj["start"] = convert_to_24hour(int(start.group(1)),
                                                      int(start.group(2)),
                                                      start.group(3))
                time_obj["end"] = convert_to_24hour(int(end.group(1)),
                                                    int(end.group(2)),
                                                    end.group(3))
            ret_list.append(time_obj)
        return ret_list
    except Exception as e:
        logger.error("[alert_time_to_list]catch exception %s, input para %s" % (str(e), str_time))
        return True
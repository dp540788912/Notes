# encoding: utf-8

import netifaces

class CommonConfig(object):
    KDB_HOST = '192.168.1.41'
    KDB_PORT = 9000
    KDB_USER = 'superuser1'
    KDB_PASSWD = 'password'


class ProductionConfig(CommonConfig):
    Debug = False

    port = 18886

    KDB_HOST = '192.168.10.102'
    KDB_PORT = 9000
    KDB_USER = 'superuser1'
    KDB_PASSWD = 'password'

    mysql = {
        'host': '192.168.10.80',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql

    redis = {
        'host': '127.0.0.1',
        'port': '6379',
    }


class DebugConfig(CommonConfig):
    Debug = True

    port = 18886

    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql

    redis = {
        'host': '127.0.0.1',
        'port': '6379',
    }



class Debug170Config(CommonConfig):
    Debug = True

    port = 18886

    mysql = {
        'host': '192.168.1.214',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql

    redis = {
        'host': '127.0.0.1',
        'port': '6379',
    }


iplist = [netifaces.ifaddresses(i).get(netifaces.AF_INET)[0]['addr']
          for i in netifaces.interfaces() if netifaces.ifaddresses(i).get(netifaces.AF_INET)]


debug_iplist = ['192.168.1.13', '192.168.1.14']

product_list = ['192.168.10.100']

debug170_iplist = ['192.168.1.170']

if any([i in iplist for i in product_list]):
    Debug = False
    config = ProductionConfig()
elif any([i in iplist for i in debug_iplist]):
    Debug = True
    config = DebugConfig()
elif any([i in iplist for i in debug170_iplist]):
    Debug = True
    config = Debug170Config()
else:
    raise ValueError('config error')


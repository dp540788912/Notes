# encoding: utf-8

from tornado import gen
from tornado.ioloop import IOLoop
from monitor_sentry import *


class BaseCoroutineServer(object):

    def __init__(self):
        self.logger = logger
        self.cfg = config

        self.load_handlers()
        self.start()

    def get_workers(self):
        raise NotImplementedError()

    def load_handlers(self):

        self.handlers = []
        for worker in self.get_workers():
            self.handlers.append(worker().run())

    @gen.coroutine
    def listen(self):
        if self.handlers:
            yield self.handlers

    def start(self):
        IOLoop.current().run_sync(self.listen)


class WebSocketCoroutineServer(BaseCoroutineServer):

    def get_workers(self):
        return [
            MonitorMySQLSentry,
            MonitorResourceSentry,
            MonitorProcessSentry,
            MonitorDeviceSentry,
            MonitorClockDiffSentry,
            MonitorOverviewSentry,
            MonitorAlertsSentry
        ]


if __name__ == "__main__":
    WebSocketCoroutineServer()

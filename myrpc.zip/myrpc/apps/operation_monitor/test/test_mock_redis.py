# encoding: utf-8

import time
import redis
import json


host_key = 'a:oss:hosts'                # set
websocket_key = 'a:rss:websocket'       # hash
resource_key = 'a:oss:monitor:resource' # hash
clockdiff_key = 'a:oss:monitor:clock'   # hash
device_key = 'a:oss:monitor:device'     # hash
system_key = 'a:oss:monitor:id'         # hash
process_key = 'a:oss:monitor:processes' # list
alert_key = 'a:oss:alerts'              # list


host = '192.168.30.79(localhost.localdomain)'


def mock_host_data(r):
    r.sadd(host_key, host)


def mock_resource_data(r):
    resource_data = json.dumps(
         {
            "disks" : [
                {
                    "free" : 43362,
                    "partition" : "/",
                    "status" : 0,
                    "total" : 50268,
                    "used_percent" : 10
                },
                {
                    "free" : 733902,
                    "partition" : "/home",
                    "status" : 0,
                    "total" : 789630,
                    "used_percent" : 3
                },
                {
                    "free" : 43362,
                    "partition" : "/var",
                    "status" : 0,
                    "total" : 50268,
                    "used_percent" : 10
                }
            ],
            "load" : {
                "l1" : 0.0013500000350177288,
                "l15" : 0.0050999997183680534,
                "l5" : 0.0017500000540167093,
                "status" : 0,
                "utilization" : 0.00073093175888061523
            },
            "ram" : {
                "free" : 110040,
                "status" : 0,
                "total" : 128650
            },
            "swap" : {
                "free" : 4095,
                "status" : 0,
                "total" : 4095
            },
            "uptime" : 263,
            "update_time" : "2017-03-06 16:33:31.703 CST",
        }
    )
    r.hset(resource_key, host, resource_data)


def mock_clock_data(r):
    clockdiff_data = json.dumps(
        {
            "clock":"1478089798269",
            "update_time" : "2017-05-05 14:35:18.690 CST"
        }
    )
    r.hset(clockdiff_key, host, clockdiff_data)


def mock_device_data(r):
    device_data = json.dumps(
        {
            "devices" : [
                {
                    "count" : 0,
                    "name" : "mycapital_fpga_nic"
                },
                {
                    "count" : 0,
                    "name" : "xele_nic"
                }   
            ],
            "update_time" : "2017-05-05 14:35:18.690 CST"
        }
    )
    r.hset(device_key, host, device_data)


def mock_system_data(r):
    system_data = json.dumps(
        {
            "ip" : "192.168.30.79",
            "name": "localhost.localdomain",
            "release": "#2 SMP Sun Dec 4 15:10:16 CST 2016",
            "version": "Linux 3.10.0-327.el7.x86_64",
            "update_time" : "2017-05-05 14:35:18.690 CST",
        }
    )
    r.hset(system_key, host, system_data)


def mock_websocket_data(r):
    websocket_data = json.dumps(
        {
            "user_id": 11, 
            "socket_id": 140325172688656, 
            "oss_detail": {"host_key": "192.168.30.79(localhost.localdomain)"},
            "msg_type": "shannon_detail"
        }
    )
    r.hset(websocket_key, host, websocket_data)


def mock_process_data(r):
    for _ in range(3):
        process_data = json.dumps(
            {
                "ip":"192.168.30.79",
                "process" : [
                    {
                        "path" : "/home/mycapitaltrade/quote_forwarder_czce/quote_forwarder_czce_level2",
                        "process_id":1,
                        "pid" : 0,
                        "status" : -1
                    },
                    {
                        "path" : "/home/mycapitaltrade/turing_czce_day_hi0all_2/turing_czce_day_hi0all_2",
                        "process_id":2,
                        "pid" : 462,
                        "status" : 1
                    }
                ],
                "update_time" : "2017-05-31 16:02:47.169 CST"
            }
        )
        r.rpush(process_key, process_data)
        time.sleep(1)


def mock_eventalert_data(r):
    for _ in range(3):
        event_alert_data = json.dumps(
            {
                "type":2,
                "data":
                {
                    "alert_id":1301,
                    "msg":"self trade",
                    "status":1,
                    "ip":"192.168.30.79",
                    "process_id":3,
                    "clock":int(time.time()),
                    "us":135402,
                },
                "update_time" : "2017-05-31 16:02:47.169 CST"
            }
        )
        r.rpush(alert_key, event_alert_data)
        time.sleep(1)


def mock_faultalert_data(r):
    for _ in range(3):
        fault_alert_data = json.dumps(
            {
                "type":3,
                "data":
                {
                    "alert_id":101,
                    "msg":"quote delay",
                    "status":1,
                    "ip":"192.168.30.79",
                    "process_id":3,
                    "clock":int(time.time()),
                    "us":135402,
                },
                "update_time" : "2017-05-31 16:02:47.169 CST"
            }
        )
        r.rpush(alert_key, fault_alert_data)
        time.sleep(1)


def test():
    pool = redis.ConnectionPool(host='127.0.0.1', port=6379) 
    r = redis.Redis(connection_pool=pool)

    #mock_host_data(r)
    #mock_websocket_data(r)
    #mock_resource_data(r)
    mock_clock_data(r)
    mock_device_data(r)
    mock_system_data(r)
    mock_process_data(r)
    #mock_eventalert_data(r)
    #mock_faultalert_data(r)


if __name__ == '__main__':
    test()


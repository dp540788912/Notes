#-*-coding:utf-8-*-


import time
import json
import datetime
import numpy
from dateutil.parser import parse
from qpython import qconnection

from config import config as cfg


def transform_date(int_days):
    begin = datetime.datetime(2000, 1, 1)
    return (begin + datetime.timedelta(days=int_days)).strftime('%Y%m%d')

class KdbQuery(object):
    def __init__(self, host=cfg.KDB_HOST, port=cfg.KDB_PORT,
                 username=cfg.KDB_USER, password=cfg.KDB_PASSWD):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.connect()

    def __del__(self):
        self.release()

    def reconnect(self):
        try:
            self.release()
        finally:
            return self.connect()

    def release(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def connect(self):
        try:
            self.conn = qconnection.QConnection(host=self.host, port=self.port,
                                                username=self.username, password=self.password)
            self.conn.open()
            return self.conn.is_connected()
        except Exception as err:
            return False

    def check(self):
        if self.conn.is_connected():
            return True
        else:
            return False

    def sync_query(self, q_sql):
        data = None
        if self.check():
            data = self.conn.sync(str(q_sql))
        return data

    def async_query(self, q_sql):
        data = None
        if self.check():
            self.conn.async(str(q_sql))
            data = self.conn.receive()
        return data

    def query_all_data(self, q_sql):
        data = None
        if self.check():
            self.conn.async(str(q_sql))
            data = self.conn.receive(data_only=False, raw=False)
        return data

    def internal_days_to_product_trading_days(self, product, is_night, start_date, end_date, is_level1):
        """

        :param product:
        :param is_night:
        :param start_date: YYYY.MM.DD
        :param end_date: YYYY.MM.DD
        :param is_level1:
        :return:
        """
        all_date = {}
        single_product = False
        if isinstance(product, (list, tuple)):
            product = '`'.join(product)
        else:
            single_product = True
        if is_level1:
            q_sql = ".gw.asyncexec[(`GetProductDate;`InternalDate;`TradeDate;`%s;(%s;`CTP);(%s;%s));`FuturesBasicInfo]" % \
                    (product, is_night, start_date, end_date)
        else:
            q_sql = ".gw.asyncexec[(`GetProductDate;`InternalDate;`TradeDate;`%s;%s;(%s;%s));`FuturesBasicInfo]" % \
                    (product, is_night, start_date, end_date)
        q_data = self.async_query(q_sql)
        all_date = json.loads(str(q_data, 'utf-8'))
        if single_product:
            return all_date.get(product, {})
        else:
            return all_date

    def product_price(self, date):
        q_sql = '.gw.asyncexec["select from CFuturesEODPrices where TRADE_DT=%s";`FuturesBasicInfo]' % date
        q_ret = self.async_query(q_sql)
        return q_ret

    def get_open_price(self, days, symbols):
        open_price = []
        open_price_index, symbol_index = -1, -1
        for d in days:
            ret = self.product_price(d)
            if (open_price_index < 0) or (symbol_index < 0):
                df = pd.DataFrame(ret)
                open_price_index = list(df.columns.values).index('OPENPRICE')
                symbol_index = list(df.columns.values).index('SYMBOL')
                open_price.append({str(r[symbol_index], 'utf-8'): r[open_price_index]
                                   for r in ret if (str(r[symbol_index], 'utf-8') in symbols)})
        return open_price


    def symbol_price(self, date, symbol):
        q_sql = '.gw.asyncexec["select from CFuturesEODPrices where TRADE_DT=%s, (lower SYMBOL)=`%s";`FuturesBasicInfo]' % (
            date, symbol)
        q_ret = self.async_query(q_sql)
        return q_ret

    def get_price(self, day, symbol, product):
        ret = self.symbol_price(day, symbol.lower())
        df = pd.DataFrame(ret)
        columns = list(df.columns.values)
        close_price_index = columns.index('CLOSEPRICE')
        open_price_index = columns.index('OPENPRICE')
        last_close_price_index = columns.index('PRELASTCLOSE')
        symbol_index = columns.index('SYMBOL')
        volume_index = columns.index('VOLUME')
        amount_index = columns.index('AMOUNT')
        for r in ret:
            if str(r[symbol_index], 'utf-8').lower() == symbol.lower():
                unit = self.get_product_unit(product)
                return {
                    'close_price': r[close_price_index],
                    'open_price': r[open_price_index],
                    'last_close_price': r[last_close_price_index],
                    'volume': r[volume_index],
                    'amount': r[amount_index],
                    'avg_price': (10000.00 / unit) * (float(r[amount_index]) / r[volume_index]),
                    'unit': unit,
                }
        return {}

    def get_product_unit(self, product):
        if product.lower().startswith(("sh", "dl", "zz")):
            product = product[2:]
        q_sql = '.gw.asyncexec[" select distinct S_INFO_CODE, S_INFO_PUNIT:N from CFuturescontpro ' \
                'where S_INFO_CODE=`%s";`FuturesBasicInfo]' % product.upper()
        q_ret = self.async_query(q_sql)
        return q_ret[0][1]

    def get_stock_price(self, date, symbol):
        q_sql = ".gw.asyncexec[\"select S_DQ_PRECLOSE, S_DQ_OPEN , S_DQ_CLOSE, S_DQ_AVGPRICE " \
                "from AShareEODPrices where TRADE_DT=%s, SYMBOL=`%s \"; `EquityFactor]" % (date, symbol)
        r = self.async_query(q_sql)[0]
        return {
            'last_close_price': r[0],
            'open_price': r[1],
            'close_price': r[2],
            'avg_price': r[3],
        }

    def get_spot_price(self, date, constituentcode):
        sql1 = """.gw.asyncexec["select S_DQ_OPEN, S_DQ_CLOSE, S_DQ_AVGPRICE, TRADE_DT from CGoldSpotEODPrices
                where TRADE_DT=%s, CONSTITUENTCODE=`$(\\"%s\\")";`FuturesBasicInfo]""" % (date, constituentcode)
        df1 = pd.DataFrame(self.async_query(sql1))
        if len(df1.values) <= 0:
            return {}
        row = df1.values[0]
        res = {
            'last_close_price': 0,
            'open_price': float(row[0]),
            'close_price': float(row[2]),
            'avg_price': float(row[2]),
        }

        sql2 = """.gw.asyncexec["select S_DQ_CLOSE, TRADE_DT from CGoldSpotEODPrices
                where TRADE_DT < %s, CONSTITUENTCODE=`$(\\"%s\\")";`FuturesBasicInfo]""" % (date, constituentcode)
        df2 = pd.DataFrame(self.async_query(sql2))
        res['last_close_price'] = float(df2.loc[[df2['TRADE_DT'].idxmax()]]['S_DQ_CLOSE'].values[0])
        return res

    def get_symbol_product(self, symbols):
        symbols = ';'.join(['\\"%s\\"' % s.lower() for s in symbols])
        q_sql = """.gw.asyncexec["select distinct SYMBOL, PRODUCT from CFuturesEODPrices
        where TRADE_DT>=2017.01.01, (lower SYMBOL) in `$(%s)";`FuturesBasicInfo]""" % symbols
        ret = self.async_query(q_sql)
        return {str(r[0], 'utf-8').lower(): str(r[1], 'utf-8').lower() for r in ret}

    def get_products_unit(self, symbols):
        symbols = ';'.join(['\\"%s\\"' % s.lower() for s in symbols])
        q_sql = """.gw.asyncexec["(select distinct S_INFO_CODE:CONSTITUENTCODE, S_INFO_PUNIT from CGoldSpotContpro
        where (lower CONSTITUENTCODE) in `$(%s)) union (
        select distinct S_INFO_CODE, S_INFO_PUNIT:N from CFuturescontpro where (lower S_INFO_CODE) in `$(%s)
        )";`FuturesBasicInfo]""" % (symbols, symbols)
        q_ret = self.async_query(q_sql)
        return {str(r[0], 'utf-8').lower(): r[1] for r in q_ret}

    def get_fee_data(self, date):
        q_sql = """.gw.asyncexec["select Product,`ByVol=FeeMode, MyIntraSimuFee, MyInterSimuFee
        from FeeRateV2 where date= %s"; `FeeRateDB]""" % date
        q_ret = self.async_query(q_sql)
        detail = {
            str(r[0], 'utf-8').lower(): {
                'FeeMode': bool(r[1]),
                'MyIntraSimuFee': float(r[2]),
                'MyInterSimuFee': float(r[3]),
            }
            for r in q_ret
        }
        return {
            date: detail
        }

    def get_symbol_exchange(self):
        q_sql = """.gw.asyncexec[\"raze {select EXCHANGE,PRODUCT,SYMBOL from x where date=last date}
        peach `MainCon`FMainCon \"; `FuturesBasicInfo]"""
        q_ret = self.async_query(q_sql)
        res = {}
        for r in q_ret:
            exch = str(r[0], 'utf-8').upper()
            res[str(r[1], 'utf-8')] = exch
            res[str(r[2], 'utf-8')] = exch
        return res

    def stock_symbols_price(self, begin_date, end_date, symbols):
        symbol_str = '`'.join([s.lower() for s in symbols])
        q_sql = ".gw.asyncexec[\"select SYMBOL, TRADE_DT, S_DQ_PRECLOSE, S_DQ_OPEN , S_DQ_CLOSE, S_DQ_AVGPRICE " \
                "from AShareEODPrices where TRADE_DT>=%s, TRADE_DT<=%s, (lower SYMBOL) in `%s \"; `EquityFactor]" % (
            begin_date, end_date, symbol_str
        )
        q_ret = self.async_query(q_sql)
        df = pd.DataFrame(q_ret)
        df['TRADE_DT'] = df['TRADE_DT'].apply(transform_date)
        df['SYMBOL'] = df['SYMBOL'].apply(lambda s: str(s, 'utf-8').split('.')[0].lower())
        columns = list(df.columns.values)
        last_close_price_index = columns.index('S_DQ_PRECLOSE')
        open_price_index = columns.index('S_DQ_OPEN')
        close_price_index = columns.index('S_DQ_CLOSE')
        avg_price_price_index = columns.index('S_DQ_AVGPRICE')
        price_details = {}
        for k, g in df.groupby(['SYMBOL', 'TRADE_DT']):
            key = '_'.join(k)
            for v in g.values:
                price_details[key] = {
                    'last_close_price': v[last_close_price_index],
                    'open_price': v[open_price_index],
                    'close_price': v[close_price_index],
                    'avg_price': v[avg_price_price_index],
                }
        return price_details

    def future_symbols_price(self, begin_date, end_date, symbols):
        symbol_str = '`'.join([s.lower() for s in symbols])
        q_sql = '.gw.asyncexec["select from CFuturesEODPrices where TRADE_DT>=%s, TRADE_DT<=%s, (lower SYMBOL) in `%s";`FuturesBasicInfo]' % (
            begin_date, end_date, symbol_str)
        q_ret = self.async_query(q_sql)
        df = pd.DataFrame(q_ret)
        df['TRADE_DT'] = df['TRADE_DT'].apply(transform_date)
        df['SYMBOL'] = df['SYMBOL'].apply(lambda s: str(s, 'utf-8').lower())
        df['PRODUCT'] = df['PRODUCT'].apply(lambda s: str(s, 'utf-8').lower())
        columns = list(df.columns.values)
        close_price_index = columns.index('CLOSEPRICE')
        open_price_index = columns.index('OPENPRICE')
        last_close_price_index = columns.index('PRELASTCLOSE')
        symbol_index = columns.index('SYMBOL')
        volume_index = columns.index('VOLUME')
        amount_index = columns.index('AMOUNT')
        product_index = columns.index('PRODUCT')
        products = list(set(df['PRODUCT'].values))
        units = self.get_products_unit(products)
        price_details = {}
        for k, g in df.groupby(['SYMBOL', 'TRADE_DT']):
            key = '_'.join(k)
            for v in g.values:
                if (units.get(v[product_index], 0) or 0) <= 0:
                    continue
                if (v[volume_index] == 0):
                    continue
                price_details[key] = {
                    'close_price': v[close_price_index],
                    'open_price': v[open_price_index],
                    'last_close_price': v[last_close_price_index],
                    'avg_price': (10000.00 / units[v[product_index]]) * (float(v[amount_index]) / v[volume_index]),
                }
        return price_details


    def spot_symbols_price(self, begin_date, end_date, symbols):
        begin_date = (parse(begin_date) - datetime.timedelta(days=100)).strftime('%Y.%m.%d')
        symbols_str = ';'.join(['\\"%s\\"' % s.lower() for s in symbols])
        sql = """.gw.asyncexec["select CONSTITUENTCODE, S_DQ_OPEN, S_DQ_CLOSE, S_DQ_AVGPRICE, TRADE_DT from CGoldSpotEODPrices
                where TRADE_DT>=%s, TRADE_DT<=%s, (lower CONSTITUENTCODE) in `$(%s)";`FuturesBasicInfo]""" % (
            begin_date, end_date, symbols_str
        )
        df = pd.DataFrame(self.async_query(sql))
        df['TRADE_DT'] = df['TRADE_DT'].apply(transform_date)
        df['SYMBOL'] = df['CONSTITUENTCODE'].apply(lambda s: str(s, 'utf-8').lower())
        columns = list(df.columns.values)
        close_price_index = columns.index('S_DQ_CLOSE')
        open_price_index = columns.index('S_DQ_OPEN')
        avg_price_price_index = columns.index('S_DQ_AVGPRICE')
        symbol_index = columns.index('SYMBOL')
        trade_date_index = columns.index('TRADE_DT')
        price_details = {}
        for k, g in df.groupby(['SYMBOL']):
            values = list(g.sort_values(['TRADE_DT']).values)
            for i, v in enumerate(values):
                key = '%s_%s' % (k, v[trade_date_index])
                price_details[key] = {
                    'close_price': v[close_price_index],
                    'open_price': v[open_price_index],
                    'avg_price': v[avg_price_price_index],
                }
                if i == 0:
                    price_details[key]['last_close_price'] = price_details[key]['open_price']
                else:
                    price_details[key]['last_close_price'] = values[i - 1][close_price_index]
        return price_details

    def get_trading_date(self, hour=18, calendar_date=None):
        now = datetime.datetime.now()
        kdb_trade_date = now.strftime('%Y.%m.%d')
        if not calendar_date:
            calendar_date = now.strftime('%Y%m%d')
        now_hour = now.hour
        q_sql = """.gw.asyncexec["select TRADE_DT from Calendar where EXCHANGE=`SSE, TRADE_DT>=%s";`FuturesBasicInfo]""" % kdb_trade_date
        ret = self.async_query(q_sql)
        dates = [r[0] for r in ret]
        for d in sorted(dates):
            d = transform_date(int(d))
            if now_hour >= hour:
                if d > calendar_date:
                    return d
            else:
                if d >= calendar_date:
                    return d
        raise ValueError('get trading date error')

    def check_day_monitor(self, calendar_date):
        """
        `calendar_date`: 2000.01.01
        """
        try:
            q_sql = """.gw.asyncexec["count select distinct TRADE_DT from Calendar where EXCHANGE in `DCE`SHFE`CZCE, TRADE_DT=%s, TRADE_DT<>0Nd";`FuturesBasicInfo]""" % calendar_date
            ret = self.async_query(q_sql)
            return False if ret == 0 else True
        except Exception as e:
            return True

    def check_night_monitor(self, calendar_date):
        """
        `calendar_date`: 2000.01.01
        """
        try:
            q_sql = """.gw.asyncexec["count select distinct NIGHT_INTERNAL_DATE from Calendar where EXCHANGE in `DCE`SHFE`CZCE, NIGHT_INTERNAL_DATE=%s, NIGHT_INTERNAL_DATE<>0Nd";`FuturesBasicInfo]""" % calendar_date
            ret = self.async_query(q_sql)
            return False if ret == 0 else True
        except Exception as e:
            return True


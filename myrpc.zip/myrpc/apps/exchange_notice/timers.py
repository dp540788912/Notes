import datetime

from multiprocessing.pool import ThreadPool
from crontab import CronTab

from crawler import task_notice_crawler, task_trading_calendar_crawler

task_worker = ThreadPool(2)


def task_notice_crawler_timer():
    now = datetime.datetime.now()
    cron = "10,40 * * * *"  # every hour at 10 and 40 min
    if not hasattr(task_notice_crawler_timer, 'next_time'):
        next_seconds = CronTab(cron).next(default_utc=False)
        task_notice_crawler_timer.next_time = now + datetime.timedelta(seconds=next_seconds)
    if now >= task_notice_crawler_timer.next_time:
        next_seconds = CronTab(cron).next(default_utc=False)
        task_notice_crawler_timer.next_time = now + datetime.timedelta(seconds=next_seconds)
        task_worker.apply_async(task_notice_crawler)


def task_trading_calendar_crawler_timer():
    now = datetime.datetime.now()
    cron = "30 6 * * *"  # every day at 6:30
    if not hasattr(task_trading_calendar_crawler_timer, 'next_time'):
        next_seconds = CronTab(cron).next(default_utc=False)
        task_trading_calendar_crawler_timer.next_time = now + datetime.timedelta(seconds=next_seconds)
    if now >= task_trading_calendar_crawler_timer.next_time:
        next_seconds = CronTab(cron).next(default_utc=False)
        task_trading_calendar_crawler_timer.next_time = now + datetime.timedelta(seconds=next_seconds)
        task_worker.apply_async(task_trading_calendar_crawler)


timers = [
    (task_notice_crawler_timer, 60 * 1000),  # check every 60s
    (task_trading_calendar_crawler_timer, 60 * 1000),  # check every 60s
]

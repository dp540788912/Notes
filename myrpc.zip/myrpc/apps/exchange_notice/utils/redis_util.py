import redis
import json
import base64

from config import Config
from utils.util import singleton


@singleton
class BaseConnectionPool(object):
    def __init__(self):
        self.pool = redis.ConnectionPool(host=Config.redis["host"], port=Config.redis["port"], db=Config.redis["db"])

    def create_rds(self):
        return redis.Redis(connection_pool=self.pool)


@singleton
class BaseConnector(object):
    def __init__(self):
        self.rds = None

    def instance(self):
        if self.rds is None:
            self.rds = BaseConnectionPool().create_rds()
        return self.rds

    @staticmethod
    def create():
        rds = BaseConnectionPool().create_rds()
        return rds


class RedisConnector(object):
    @staticmethod
    def reuse():
        return BaseConnector().instance()

    @staticmethod
    def new():
        return BaseConnector().create()


def check_user_session(session):
    rds = RedisConnector.reuse()
    key = "session:{}".format(session)
    s = rds.get(key)
    if s:
        data = json.loads(str(base64.b64decode(s), "utf-8").split(":", 1)[-1])
        if "_auth_user_id" in data:
            res = {
                "id": data["_auth_user_id"],
                "username": data.get("_auth_user_name", ""),
                "nickname": data.get("_auth_user_nickname", "")
            }
            return res
    return None

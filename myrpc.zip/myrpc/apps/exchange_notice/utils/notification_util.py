import smtplib
import requests

from email.header import Header
from email.mime.text import MIMEText
from email.utils import parseaddr, formataddr

from config import Config
from utils.log_util import logger


class MailBase:
    def __init__(self, app_config, title, content, to_addrs):
        self.FROM_ADDR = app_config["from_addr"]
        self.PASSWORD = app_config["password"]
        self.SMTP_SERVER = app_config["smtp_server"]
        self.SMTP_SERVER_PORT = app_config["smtp_server_port"]
        self.title = title
        self.content = content
        self.to_addrs = to_addrs

    @staticmethod
    def format_addr(address):
        name, addr = parseaddr(address)
        return formataddr((Header(name, 'utf-8').encode(), addr))

    def send(self):
        if not self.to_addrs:
            return
        msg = MIMEText(self.content, "plain", "utf-8")
        msg["From"] = self.format_addr("<{}>".format(self.FROM_ADDR))
        to_addrs = [self.format_addr("<{}>".format(a)) for a in self.to_addrs]
        msg["To"] = ",".join(to_addrs)
        msg["Subject"] = Header(self.title, "utf-8").encode()
        server = smtplib.SMTP(self.SMTP_SERVER, self.SMTP_SERVER_PORT)
        try:
            server.ehlo()
            server.starttls()
            server.ehlo()
            server.login(self.FROM_ADDR, self.PASSWORD)
            server.sendmail(self.FROM_ADDR, self.to_addrs, msg.as_string())
        except Exception as e:
            logger.error(str(e))
        finally:
            server.quit()


class MailNotice(MailBase):
    def __init__(self, title, content, to_addrs):
        app_config = Config.mail_app_notice_config
        super().__init__(app_config, title, content, to_addrs)


class WXMessageBase:
    TOKEN_URL = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={}&corpsecret={}"
    MSG_URL = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={}"

    def __init__(self, app_config, to_users=None, to_parties=None, to_tags=None):
        self.AGENT_ID = app_config["agent_id"]
        self.SECRET = app_config["secret"]
        self.CORP_ID = app_config["corp_id"]
        self.to_users = to_users
        self.to_parties = to_parties
        self.to_tags = to_tags

    def get_token_url(self):
        return self.TOKEN_URL.format(self.CORP_ID, self.SECRET)

    def get_msg_url(self, token):
        return self.MSG_URL.format(token)

    def get_format_receivers(self):
        touser = "|".join(self.to_users) if self.to_users else ""
        toparty = "|".join(self.to_parties) if self.to_parties else ""
        totag = "|".join(self.to_tags) if self.to_tags else ""
        return touser, toparty, totag

    def send_text(self, text):
        res = requests.get(self.get_token_url())
        if res.status_code == 200:
            token = res.json().get("access_token", None)
            if token:
                msg_url = self.get_msg_url(token)
                touser, toparty, totag = self.get_format_receivers()
                if touser or toparty or totag:
                    payload = {
                        "touser": touser,
                        "toparty": toparty,
                        "totag": totag,
                        "msgtype": "text",
                        "agentid": self.AGENT_ID,
                        "text": {
                            "content": text
                        },
                        "safe": "0"
                    }
                    response = requests.post(msg_url, json=payload)
                    if response.status_code == 200:
                        json_data = response.json()
                        if json_data['errcode'] == 0:
                            return True
        return False

    def send_article(self, title, url, desc="", pic_url=""):
        res = requests.get(self.get_token_url())
        if res.status_code == 200:
            token = res.json().get("access_token", None)
            if token:
                msg_url = self.get_msg_url(token)
                touser, toparty, totag = self.get_format_receivers()
                if touser or toparty or totag:
                    payload = {
                        "touser": touser,
                        "toparty": toparty,
                        "totag": totag,
                        "msgtype": "news",
                        "agentid": self.AGENT_ID,
                        "news": {
                            "articles": [
                                {
                                    "title": title,
                                    "description": desc,
                                    "url": url,
                                    "picurl": pic_url
                                }
                            ]
                        },
                        "safe": "0"
                    }
                    response = requests.post(msg_url, json=payload)
                    if response.status_code == 200:
                        json_data = response.json()
                        if json_data['errcode'] == 0:
                            return True
        return False


class WXMessageNotice(WXMessageBase):
    def __init__(self, to_users=None, to_parties=None, to_tags=None):
        app_config = Config.wx_app_notice_config
        super().__init__(app_config, to_users, to_parties, to_tags)


def test_wx():
    msg = WXMessageNotice(to_users=["jpmike"])
    print(msg.send_text(text="测试"))
    print(msg.send_article(title="关于发布国债期货合约TF2006、T2006和TS2006可交割国债的通知",
                           url="http://www.cffex.com.cn/jysgg/20190916/23985.html"))


def test_mail():
    mail = MailNotice(title="测试", content="测试一下", to_addrs=["maijianping@mycapital.net"])
    mail.send()


if __name__ == '__main__':
    # test_mail()
    # test_wx()
    pass

from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from contextlib import contextmanager

from config import Config

BaseModel = declarative_base()

engine = create_engine(
    Config.mysql["db_uri"],
    encoding="utf-8",
    pool_recycle=3600,
    echo=False
)

Session = sessionmaker(bind=engine)


@contextmanager
def session_context():
    session = Session()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()

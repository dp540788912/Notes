import os
import logging

from logging.handlers import RotatingFileHandler

from config import Config

ROTATE_LOG_SIZE = 1024 * 1024 * 2
LOG_BACKUP_COUNT = 1
log_file = os.path.join(os.path.abspath(os.path.dirname(__file__)), "log.log")
logger = logging.getLogger('log')
if Config.debug:
    logger.setLevel(logging.DEBUG)
else:
    logger.setLevel(logging.INFO)

handler = RotatingFileHandler(log_file,
                              maxBytes=ROTATE_LOG_SIZE,
                              backupCount=LOG_BACKUP_COUNT)
formatter = logging.Formatter(fmt='%(asctime)s - %(pathname)s[line:%(lineno)d] - %(levelname)s: %(message)s')
handler.setFormatter(formatter)
logger.handlers.clear()
logger.addHandler(handler)

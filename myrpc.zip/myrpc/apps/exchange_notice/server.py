import tornado.ioloop
import tornado.web

from config import Config
from handlers import TestHandler, NoticeReceiverHandler, NoticeFilterWordsHandler, NoticeHandler, \
    TradingCalendarHandler, TradingCalendarLabelHandler
from timers import timers

urls = [
    (r"/api/v1/exchange_notice/test", TestHandler),
    (r"/api/v1/exchange_notice/receivers", NoticeReceiverHandler),
    (r"/api/v1/exchange_notice/filter_words", NoticeFilterWordsHandler),
    (r"/api/v1/exchange_notice/notices", NoticeHandler),
    (r"/api/v1/exchange_notice/trading_calendar", TradingCalendarHandler),
    (r"/api/v1/exchange_notice/calendar_labels", TradingCalendarLabelHandler),
]


def make_app():
    return tornado.web.Application(urls)


if __name__ == "__main__":
    app = make_app()
    app.listen(Config.port)
    for timer in timers:
        tornado.ioloop.PeriodicCallback(*timer).start()
    tornado.ioloop.IOLoop.current().start()

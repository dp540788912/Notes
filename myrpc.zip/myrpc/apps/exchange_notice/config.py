import netifaces


class CommonConfig(object):
    wx_app_notice_config = {
        "corp_id": "ww7c9916c2f31d5aa4",
        "secret": "n4q1nyNyeJJJ_ukL5hgEpadnoBqwS3lS_ztIT0ov07Q",
        "agent_id": 1000013
    }
    mail_app_notice_config = {
        "from_addr": "notice@mycapital.net",
        "password": "Mycapital0427",
        "smtp_server": "smtp.qiye.163.com",
        "smtp_server_port": 25
    }


class ProductionConfig(CommonConfig):
    debug = False
    port = 18881
    redis = {
        "host": '192.168.10.99',
        "port": '6379',
        "db": 0,
    }
    mysql = {
        'host': '192.168.10.80',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s?charset=utf8' % mysql


class DebugConfig(CommonConfig):
    debug = True
    port = 18881
    redis = {
        "host": '127.0.0.1',
        "port": '6379',
        "db": 0,
    }
    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s?charset=utf8' % mysql


ip_list = [netifaces.ifaddresses(i).get(netifaces.AF_INET)[0]['addr']
           for i in netifaces.interfaces() if netifaces.ifaddresses(i).get(netifaces.AF_INET)]

debug_ip_list = ['192.168.1.13', '192.168.1.14']

product_list = ['192.168.10.100']

if any([i in ip_list for i in product_list]):
    Config = ProductionConfig()
elif any([i in ip_list for i in debug_ip_list]):
    Config = DebugConfig()
else:
    raise ValueError('config error')

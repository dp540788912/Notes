### Install

root=bss_server/myrpc/apps/exchange_notice

1. python3 -m venv venv

2. source env/bin/activate

3. pip install --upgrade pip 

4. pip install --upgrade setuptools

5. pip install -i https://pypi.doubanio.com/simple -r requirements.txt

### Supervisor config
1.14测试服参考配置：
```bash
/etc/supervisor.conf
```
import hashlib
import datetime

from sqlalchemy.dialects.mysql import VARCHAR, JSON, INTEGER, DATE, DATETIME
from sqlalchemy import Column
from sqlalchemy.sql import func, and_

from utils.mysql_util import BaseModel, session_context as mysql_sc


class ExchangeNotice(BaseModel):
    __tablename__ = "exchange_notice"

    id = Column(INTEGER(), primary_key=True)
    notice_id = Column(INTEGER(), nullable=False, index=True)
    exchange_name = Column(VARCHAR(16), nullable=False)
    title = Column(VARCHAR(64), nullable=False)
    link = Column(VARCHAR(512), nullable=False)
    date = Column(DATE(), nullable=False, index=True)

    def to_dict(self):
        return {
            "title": self.title,
            "link": self.link,
            "date": self.date.strftime("%Y-%m-%d")
        }

    @staticmethod
    def create(exchange_name, title, link, date_str):
        with mysql_sc() as db:
            notice_id = ExchangeNotice.generate_notice_id(link)
            date = datetime.datetime.strptime(date_str, "%Y-%m-%d")
            new_record = ExchangeNotice(exchange_name=exchange_name, title=title, link=link, date=date,
                                        notice_id=notice_id)
            db.add(new_record)

    @staticmethod
    def generate_notice_id(link):
        return int(hashlib.sha256(bytes(link, encoding="utf-8")).hexdigest(), 16) % (10 ** 8)


class ExchangeNoticeSetting(BaseModel):
    __tablename__ = "exchange_notice_setting"

    id = Column(INTEGER(), primary_key=True)
    name = Column(VARCHAR(16), nullable=False)
    info = Column(JSON())

    @staticmethod
    def get_setting(name):
        with mysql_sc() as db:
            record = db.query(ExchangeNoticeSetting).filter_by(name=name).first()
            if record:
                info = record.info
            else:
                info = {}
        return info

    @staticmethod
    def get_filter_words():
        info = ExchangeNoticeSetting.get_setting("filter_words")
        return info.get("words", [])

    @staticmethod
    def get_wx_users():
        info = ExchangeNoticeSetting.get_setting("wx")
        return info.get("users", [])

    @staticmethod
    def get_email_users():
        info = ExchangeNoticeSetting.get_setting("email")
        return info.get("users", [])


class ExchangeTradingCalendar(BaseModel):
    __tablename__ = "exchange_trading_calendar"

    id = Column(INTEGER(), primary_key=True)
    date = Column(DATE(), nullable=False, index=True, unique=True)
    update_at = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    calendar_info = Column(JSON())

    @staticmethod
    def create_or_update(date, calendar_info):
        with mysql_sc() as db:
            record = db.query(ExchangeTradingCalendar).filter_by(date=date).first()
            if record:
                record.calendar_info = calendar_info
            else:
                new_record = ExchangeTradingCalendar(date=date, calendar_info=calendar_info)
                db.add(new_record)

    @staticmethod
    def get_calendar_info(date):
        with mysql_sc() as db:
            record = db.query(ExchangeTradingCalendar).filter_by(date=date).first()
            if record:
                info = record.calendar_info
            else:
                info = None
        return info

    @staticmethod
    def get_calendar_label(start_date, end_date):
        rs = []
        with mysql_sc() as db:
            records = db.query(ExchangeTradingCalendar).filter(and_(ExchangeTradingCalendar.date >= start_date,
                                                                    ExchangeTradingCalendar.date < end_date)).all()
            for r in records:
                rs.append(int(r.date.strftime("%d")))
        return rs


if __name__ == '__main__':
    # from utils.mysql_util import engine
    # BaseModel.metadata.create_all(engine)
    pass

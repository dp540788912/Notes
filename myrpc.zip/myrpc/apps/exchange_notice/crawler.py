import requests
import re
import datetime
from urllib.parse import urlparse, urlencode
from bs4 import BeautifulSoup
from tornado.httpclient import AsyncHTTPClient, HTTPClient
from tornado.gen import multi

from constant import ExchangeInfo, HTTP_STATUS_CODE
from utils.log_util import logger
from utils.mysql_util import session_context as mysql_sc
from utils.notification_util import WXMessageNotice, MailNotice
from models import ExchangeNoticeSetting, ExchangeNotice, ExchangeTradingCalendar


class Notice:
    def __init__(self, title, link, date_str):
        self.title = title
        self.link = link
        self.date_str = date_str

    def should_save(self, filter_pattern=None):
        if filter_pattern and re.search(filter_pattern, self.title):
            return False
        return True


class NoticeCrawlerBase:
    def __init__(self, name):
        self.name = name
        self.link = ExchangeInfo[self.name]["notice_link"]
        url_parse = urlparse(self.link)
        self.host = "{}://{}".format(url_parse.scheme, url_parse.netloc)
        self.notices = []  # Notice instance

    def fetch(self, *args, **kwargs):
        raise NotImplementedError

    def save_to_mysql(self, filter_pattern=None, wx_users=None, email_users=None):
        if not self.notices:
            return
        for n in self.notices:
            if n.should_save(filter_pattern):
                nid = ExchangeNotice.generate_notice_id(n.link)
                with mysql_sc() as db:
                    record = db.query(ExchangeNotice).filter_by(exchange_name=self.name, notice_id=nid).first()
                if not record:
                    ExchangeNotice.create(exchange_name=self.name, title=n.title, link=n.link, date_str=n.date_str)
                    self.send_notification(title=n.title, link=n.link, wx_users=wx_users, email_users=email_users)
                else:
                    break

    def send_notification(self, title, link, wx_users=None, email_users=None):
        exchange_name_zh = ExchangeInfo[self.name]["name_zh"]
        title = "[{}]{}".format(exchange_name_zh, title)
        if wx_users:
            msg = WXMessageNotice(to_users=wx_users)
            try:
                msg.send_article(title=title, url=link)
            except Exception as e:
                logger.error(str(e))

        if email_users:
            mail = MailNotice(title="[交易所新公告通知]{}".format(title), content="原文链接: {}".format(link),
                              to_addrs=email_users)
            try:
                mail.send()
            except Exception as e:
                logger.error(str(e))

    def run(self, filter_pattern=None, wx_users=None, email_users=None):
        self.fetch()
        self.save_to_mysql(filter_pattern=filter_pattern, wx_users=wx_users, email_users=email_users)


class CzceNoticeCrawler(NoticeCrawlerBase):
    def __init__(self):
        super().__init__("czce")
        self.link = "http://app.czce.com.cn/cms/pub/search/searchdt.jsp"

    def fetch(self):
        res = requests.get(self.link)
        if res.status_code == HTTP_STATUS_CODE.OK:
            soup = BeautifulSoup(res.content, "lxml")
            div = soup.find("div", "xxgkbiaoge")
            tds = div.find_all("td", style="display:none")
            for td in tds:
                td_n1 = td.find_next("td")
                a = td_n1.find("a")
                td_n2 = td_n1.find_next("td")
                self.notices.append(Notice(title=a.text, link=a["href"], date_str=td_n2.text))


class DceNoticeCrawler(NoticeCrawlerBase):
    def __init__(self):
        super().__init__("dce")

    def fetch(self):
        res = requests.get(self.link)
        if res.status_code == HTTP_STATUS_CODE.OK:
            soup = BeautifulSoup(res.content, "lxml")
            ul = soup.find("ul", "list_tpye06")
            for li in ul.find_all("li"):
                a = li.find("a")
                span = li.find("span")
                self.notices.append(Notice(title=a["title"], link=self.host + a["href"], date_str=span.text))


class ShfeNoticeCrawler(NoticeCrawlerBase):
    def __init__(self):
        super().__init__("shfe")

    def fetch(self):
        res = requests.get(self.link)
        if res.status_code == HTTP_STATUS_CODE.OK:
            soup = BeautifulSoup(res.content, "lxml")
            div = soup.find("div", "p4 lawbox")
            ul = div.find("ul")
            for li in ul.find_all("li"):
                a = li.find("a")
                span = li.find("span")
                date_str = str(span.text).lstrip("[").rstrip("]")
                self.notices.append(Notice(title=a["title"], link=self.host + a["href"], date_str=date_str))


class CffexNoticeCrawler(NoticeCrawlerBase):
    def __init__(self):
        super().__init__("cffex")

    def fetch(self):
        res = requests.get(self.link)
        if res.status_code == HTTP_STATUS_CODE.OK:
            soup = BeautifulSoup(res.content, "lxml")
            ul = soup.find("ul", "clearFloat")
            for li in ul.find_all("li"):
                a_title = li.find("a", "list_a_text")
                a_time = li.find("a", "time comparetime")
                self.notices.append(
                    Notice(title=a_title["title"], link=self.host + a_title["href"], date_str=a_time.text))


class IneNoticeCrawler(NoticeCrawlerBase):
    def __init__(self):
        super().__init__("ine")

    def fetch(self):
        res = requests.get(self.link)
        if res.status_code == HTTP_STATUS_CODE.OK:
            soup = BeautifulSoup(res.content, "lxml")
            div = soup.find("div", "newslist")
            ul = div.find("ul")
            for li in ul.find_all("li"):
                a = li.find("a")
                span = li.find("span")
                self.notices.append(Notice(title=a.text, link=self.host + a["href"], date_str=span.text))


def task_notice_crawler():
    logger.info("Start task_notice_crawler")
    all_crawlers = [
        CzceNoticeCrawler(),
        ShfeNoticeCrawler(),
        CffexNoticeCrawler(),
        IneNoticeCrawler(),
        CzceNoticeCrawler()
    ]
    filter_words = ExchangeNoticeSetting.get_filter_words()
    if filter_words:
        w = "|".join(filter_words)
        pattern = re.compile(w)
    else:
        pattern = None
    wx_users = ExchangeNoticeSetting.get_wx_users()
    email_users = ExchangeNoticeSetting.get_email_users()
    for crawler in all_crawlers:
        try:
            crawler.run(filter_pattern=pattern, wx_users=wx_users, email_users=email_users)
        except Exception as e:
            logger.error(str(e))
            continue

    logger.info("Finish task_notice_crawler")


def test_notice_crawler():
    # task_notice_crawler()
    pass


class CalendarCrawlerBase:
    def __init__(self, name):
        self.name = name
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/77.0.3865.90 Safari/537.36",
            "Accept-Language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
            "Accept-Encoding": "gzip, deflate",
            "Accept": "*/*",
        }

    def fetch(self, *args, **kwargs):
        raise NotImplementedError


class ShfeCalendarCrawler(CalendarCrawlerBase):
    def __init__(self):
        super().__init__("shfe")
        self.link = ExchangeInfo[self.name]["calendar_link"] + "{}all.dat"
        self.res = None

    def handle_res(self):
        r = ""
        if self.res and self.res.code == HTTP_STATUS_CODE.OK:
            r = self.res.body.decode("utf-8")
        return r

    def fetch(self, date_str):
        c = HTTPClient()
        link = self.link.format(date_str.replace("-", ""))
        try:
            self.res = c.fetch(link)
        except Exception:
            pass
        return self.handle_res()

    async def fetch_async(self, date_str):
        c = AsyncHTTPClient()
        link = self.link.format(date_str.replace("-", ""))
        try:
            self.res = await c.fetch(link)
        except Exception:
            pass
        return self.handle_res()


class IneCalendarCrawler(CalendarCrawlerBase):
    def __init__(self):
        super().__init__("ine")
        self.link = ExchangeInfo[self.name]["calendar_link"] + "{}all.dat"
        self.res = None

    def handle_res(self):
        r = ""
        if self.res and self.res.code == HTTP_STATUS_CODE.OK:
            r = self.res.body.decode("utf-8")
        return r

    def fetch(self, date_str):
        c = HTTPClient()
        link = self.link.format(date_str.replace("-", ""))
        try:
            self.res = c.fetch(link)
        except Exception:
            pass
        return self.handle_res()

    async def fetch_async(self, date_str):
        c = AsyncHTTPClient()
        link = self.link.format(date_str.replace("-", ""))
        try:
            self.res = await c.fetch(link)
        except Exception:
            pass
        return self.handle_res()


class CffexCalendarCrawler(CalendarCrawlerBase):
    def __init__(self):
        super().__init__("cffex")
        self.link = "http://www.cffex.com.cn/sj/jyrl/index_6782.xml"
        self.res = None

    def handle_res(self, date_str):
        r = []
        if self.res and self.res.code == HTTP_STATUS_CODE.OK:
            soup = BeautifulSoup(self.res.body.decode("utf-8"), "xml")
            for doc in soup.find_all("doc"):
                pub_date = doc.find("pubdate")
                title = doc.find("title")
                if pub_date.text == date_str:
                    r.append(title.text)
        return r

    def fetch(self, date_str):
        c = HTTPClient()
        try:
            self.res = c.fetch(self.link)
        except Exception:
            pass
        return self.handle_res(date_str)

    async def fetch_async(self, date_str):
        c = AsyncHTTPClient()
        try:
            self.res = await c.fetch(self.link)
        except Exception:
            pass
        return self.handle_res(date_str)


class DceCalendarCrawler(CalendarCrawlerBase):
    def __init__(self):
        super().__init__("dce")
        self.link = "http://www.dce.com.cn/publicweb/trading/tradingCalendar.html"
        self.res = None

    def handle_res(self):
        r = []
        if self.res and self.res.code == HTTP_STATUS_CODE.OK:
            soup = BeautifulSoup(self.res.body.decode("utf-8"), "lxml")
            ul = soup.find("ul", "resultList")
            if ul:
                for li in ul.find_all("li"):
                    r.append(str(li))
        return "\n".join(r)

    def fetch_paras(self, date_str, trade_type):
        if trade_type == "future":
            trade_type = "0"
        elif trade_type == "option":
            trade_type = "1"
        date_str = date_str.replace("-", "")
        payload = {
            "trading.variety": "all",
            "trading.trade_type": trade_type,  # 0 for future, 1 for option
            "trading.calendar_date_begin": date_str,
            "trading.calendar_date_end": date_str
        }
        headers = self.headers
        headers.update({
            "Host": "www.dce.com.cn",
            "Origin": "http://www.dce.com.cn",
            "Referer": "http://www.dce.com.cn/publicweb/trading/tradingCalendar.html",
            "Content-Type": "application/x-www-form-urlencoded",
        })
        return payload, headers

    def fetch(self, date_str, trade_type):
        c = HTTPClient()
        payload, headers = self.fetch_paras(date_str, trade_type)
        try:
            self.res = c.fetch(self.link, method="POST", body=urlencode(payload), headers=headers)
        except Exception:
            pass
        return self.handle_res()

    async def fetch_async(self, date_str, trade_type):
        c = AsyncHTTPClient()
        payload, headers = self.fetch_paras(date_str, trade_type)
        try:
            self.res = await c.fetch(self.link, method="POST", body=urlencode(payload), headers=headers)
        except Exception:
            pass
        return self.handle_res()


class CzceCalendarCrawler(CalendarCrawlerBase):
    def __init__(self):
        super().__init__("czce")
        self.link = "http://app.czce.com.cn/cms/pub/search/searchjyyl.jsp"
        self.res = None

    def handle_res(self):
        rs = {
            "limit_positions_tip": "",
            "listed_contracts": "",
            "expired_contracts": "",
            "margins": ""
        }
        if self.res and self.res.code == HTTP_STATUS_CODE.OK:
            soup = BeautifulSoup(self.res.body.decode("utf-8"), "lxml")
            div = soup.find("div", "jyylbiaoge")
            table = div.find("table")
            tds = table.find_all("td")
            try:
                rs["limit_positions_tip"] = tds[7].text
                rs["listed_contracts"] = tds[8].text
                rs["expired_contracts"] = tds[9].text
                rs["margins"] = tds[10].text
            except Exception:
                pass
        return rs

    def fetch_paras(self, date_str, trade_type):
        payload = {
            "tradetype": trade_type,  # future|option
            "DtbeginDate": date_str,
            "DtendDate": date_str
        }
        return payload

    def fetch(self, date_str, trade_type):
        c = HTTPClient()
        payload = self.fetch_paras(date_str, trade_type)
        try:
            self.res = c.fetch(self.link, method="POST", body=urlencode(payload))
        except Exception:
            pass
        return self.handle_res()

    async def fetch_async(self, date_str, trade_type):
        c = AsyncHTTPClient()
        payload = self.fetch_paras(date_str, trade_type)
        try:
            self.res = await c.fetch(self.link, method="POST", body=urlencode(payload))
        except Exception:
            pass
        return self.handle_res()


async def get_and_store_trading_calendar_async(date):
    shfe = ShfeCalendarCrawler()
    ine = IneCalendarCrawler()
    cffex = CffexCalendarCrawler()
    dce = DceCalendarCrawler()
    czce = CzceCalendarCrawler()
    date_str = date.strftime("%Y-%m-%d")
    shfe_res, ine_res, cffex_res, dce_future_res, dce_option_res, czce_future_res, czce_option_res = await multi(
        [shfe.fetch_async(date_str),
         ine.fetch_async(date_str),
         cffex.fetch_async(date_str),
         dce.fetch_async(date_str, "future"),
         dce.fetch_async(date_str, "option"),
         czce.fetch_async(date_str, "future"),
         czce.fetch_async(date_str, "option"),
         ])
    rs = {
        "shfe": shfe_res,
        "ine": ine_res,
        "cffex": cffex_res,
        "dce": {
            "futures": dce_future_res,
            "options": dce_option_res
        },
        "czce": {
            "futures": czce_future_res,
            "options": czce_option_res
        }
    }
    rs_list = [shfe_res, ine_res, cffex_res, dce_future_res, dce_option_res]
    rs_list.extend(list(czce_future_res.values()))
    rs_list.extend(list(czce_option_res.values()))
    if any(rs_list):
        ExchangeTradingCalendar.create_or_update(date=date, calendar_info=rs)

    return rs


def get_and_store_trading_calendar(date):
    shfe = ShfeCalendarCrawler()
    ine = IneCalendarCrawler()
    cffex = CffexCalendarCrawler()
    dce = DceCalendarCrawler()
    czce = CzceCalendarCrawler()
    date_str = date.strftime("%Y-%m-%d")

    shfe_res = shfe.fetch(date_str)
    ine_res = ine.fetch(date_str)
    cffex_res = cffex.fetch(date_str)
    dce_future_res = dce.fetch(date_str, "future")
    dce_option_res = dce.fetch(date_str, "option")
    czce_future_res = czce.fetch(date_str, "future")
    czce_option_res = czce.fetch(date_str, "option")

    rs = {
        "shfe": shfe_res,
        "ine": ine_res,
        "cffex": cffex_res,
        "dce": {
            "futures": dce_future_res,
            "options": dce_option_res
        },
        "czce": {
            "futures": czce_future_res,
            "options": czce_option_res
        }
    }
    rs_list = [shfe_res, ine_res, cffex_res, dce_future_res, dce_option_res]
    rs_list.extend(list(czce_future_res.values()))
    rs_list.extend(list(czce_option_res.values()))
    if any(rs_list):
        ExchangeTradingCalendar.create_or_update(date=date, calendar_info=rs)

    return rs


def task_trading_calendar_crawler():
    logger.info("Start task_trading_calendar_crawler")
    today = datetime.date.today()
    for d in range(0, 31):
        date = today + datetime.timedelta(days=d)
        get_and_store_trading_calendar(date)
    logger.info("End task_trading_calendar_crawler")


def test_calendar_crawler():
    # task_trading_calendar_crawler()
    pass


if __name__ == '__main__':
    # test_notice_crawler()
    # test_calendar_crawler()
    pass

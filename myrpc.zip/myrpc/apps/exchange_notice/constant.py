class HTTP_STATUS_CODE:
    OK = 200


ExchangeInfo = {
    "czce": {
        "name_zh": "郑商所",
        "notice_link": "http://www.czce.com.cn/cn/gyjys/jysdt/ggytz/H77010301index_1.htm",
        "calendar_link": "http://www.czce.com.cn/cn/jysj/jyyl/H770313index_1.htm"
    },
    "dce": {
        "name_zh": "大商所",
        "notice_link": "http://www.dce.com.cn/dalianshangpin/yw/fw/jystz/ywtz/index.html",
        "calendar_link": "http://www.dce.com.cn/dalianshangpin/yw/fw/jyrl/index.html"
    },
    "shfe": {
        "name_zh": "上期所",
        "notice_link": "http://www.shfe.com.cn/news/notice/",
        "calendar_link": "http://www.shfe.com.cn/bourseService/businessdata/calendar/"
    },
    "cffex": {
        "name_zh": "中金所",
        "notice_link": "http://www.cffex.com.cn/jysgg/",
        "calendar_link": "http://www.cffex.com.cn/jyrl/"
    },
    "ine": {
        "name_zh": "能源交易所",
        "notice_link": "http://www.ine.cn/news/notice/",
        "calendar_link": "http://www.ine.com.cn/bourseService/businessdata/calendar/"
    }
}

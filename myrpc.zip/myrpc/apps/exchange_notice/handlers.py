import json
import datetime
import tornado.web

import tornado.ioloop
from copy import deepcopy
from abc import ABC
from dateutil.relativedelta import relativedelta

from utils.redis_util import RedisConnector, check_user_session
from utils.mysql_util import session_context as mysql_sc
from constant import ExchangeInfo
from crawler import get_and_store_trading_calendar_async
from models import ExchangeNotice, ExchangeNoticeSetting, ExchangeTradingCalendar


def res_success(data):
    return {
        "code": 0,
        "data": data
    }


def res_fail(code, error):
    return {
        "code": code,
        "error": error
    }


class BaseHandler(tornado.web.RequestHandler, ABC):
    def prepare(self):
        whitelist = self.request.headers.get("whitelist")
        if whitelist:
            self.current_user = {
                "id": 999999,
                "username": whitelist,
                "nickname": whitelist,
            }
        else:
            session_id = self.get_cookie("sessionid")
            if not session_id:
                self.write(res_fail(code=401, error="Session id not found."))
                self.finish()
                return
            res = check_user_session(session_id)
            if not res:
                self.write(res_fail(code=401, error="User not login."))
                self.finish()
                return
            self.current_user = res

    def get_payload(self):
        if not self.request.headers["content-type"].startswith("application/json"):
            self.write(res_fail(code=415, error="No json data."))
            return None
        return json.loads(str(self.request.body, 'utf-8'))

    def get(self, *args, **kwargs):
        self.write(res_fail(code=404, error="Method not found."))

    def post(self, *args, **kwargs):
        self.write(res_fail(code=404, error="Method not found."))

    def put(self, *args, **kwargs):
        self.write(res_fail(code=404, error="Method not found."))

    def delete(self, *args, **kwargs):
        self.write(res_fail(code=404, error="Method not found."))

    def patch(self, *args, **kwargs):
        self.write(res_fail(code=404, error="Method not found."))


class TestHandler(BaseHandler, ABC):
    def get(self):
        rds = RedisConnector.reuse()
        test_message = rds.get("test_message")
        if test_message:
            test_message = test_message.decode("utf-8")
        self.write(res_success(data="Hello, {}".format(test_message)))


class NoticeReceiverHandler(BaseHandler, ABC):
    def get(self):
        email_users = ExchangeNoticeSetting.get_email_users()
        wx_users = ExchangeNoticeSetting.get_wx_users()
        self.write(res_success(data={
            "email_users": email_users,
            "wx_users": wx_users
        }))

    def post(self):
        payload = self.get_payload()
        if not payload:
            return
        notify_method = payload["notify_method"]
        if notify_method not in ["wx", "email"]:
            self.write(res_fail(code=400, error="Payload data error."))
            return
        user = payload["user"]
        with mysql_sc() as db:
            record = db.query(ExchangeNoticeSetting).filter_by(name=notify_method).first()
            if record:
                info = deepcopy(record.info)
                if user not in info["users"]:
                    info["users"].append(user)
                record.info = info
            else:
                new_record = ExchangeNoticeSetting(name=notify_method, info={"users": [user]})
                db.add(new_record)

        self.write(res_success(data={}))

    def delete(self):
        notify_method = self.get_argument("notify_method", None)
        user = self.get_argument("user", None)
        if notify_method not in ["wx", "email"] or not user:
            self.write(res_fail(code=400, error="Payload data error."))
            return
        with mysql_sc() as db:
            record = db.query(ExchangeNoticeSetting).filter_by(name=notify_method).first()
            if record:
                info = deepcopy(record.info)
                if user in info["users"]:
                    info["users"].remove(user)
                record.info = info

        self.write(res_success(data={}))


class NoticeFilterWordsHandler(BaseHandler, ABC):
    def get(self):
        filter_words = ExchangeNoticeSetting.get_filter_words()
        self.write(res_success(data=filter_words))

    def post(self):
        payload = self.get_payload()
        if not payload:
            return
        word = payload["word"]
        with mysql_sc() as db:
            record = db.query(ExchangeNoticeSetting).filter_by(name="filter_words").first()
            if record:
                info = deepcopy(record.info)
                if word not in info["words"]:
                    info["words"].append(word)
                record.info = info
            else:
                new_record = ExchangeNoticeSetting(name="filter_words", info={"words": [word]})
                db.add(new_record)

        self.write(res_success(data={}))

    def delete(self):
        word = self.get_argument("word", None)
        if not word:
            self.write(res_fail(code=400, error="Payload data error."))
            return
        with mysql_sc() as db:
            record = db.query(ExchangeNoticeSetting).filter_by(name="filter_words").first()
            if record:
                info = deepcopy(record.info)
                if word in info["words"]:
                    info["words"].remove(word)
                record.info = info

        self.write(res_success(data={}))


class NoticeHandler(BaseHandler, ABC):
    def get(self):
        date_str = self.get_argument("date_str", None)
        if not date_str:
            date = datetime.datetime.today().date()
        else:
            date = datetime.datetime.strptime(date_str, "%Y-%m-%d")

        with mysql_sc() as db:
            records = db.query(ExchangeNotice).filter_by(date=date).all()
            notices = {}
            for k, v in ExchangeInfo.items():
                notices.update({k: {
                    "name_zh": v["name_zh"],
                    "more": v["notice_link"],
                    "notices": []
                }})
            for r in records:
                notices[r.exchange_name]["notices"].append(r.to_dict())

        self.write(res_success(data=notices))


class TradingCalendarHandler(BaseHandler, ABC):
    async def get(self, *args, **kwargs):
        date_str = self.get_argument("date", None)
        if not date_str:
            date = datetime.datetime.today()
        else:
            date = datetime.datetime.strptime(date_str, "%Y-%m-%d")
        data = ExchangeTradingCalendar.get_calendar_info(date)
        if not data:
            data = await get_and_store_trading_calendar_async(date)
        self.write(res_success(data=data))


class TradingCalendarLabelHandler(BaseHandler, ABC):
    def get(self, *args, **kwargs):
        date_str = self.get_argument("date", None)
        if not date_str:
            date = datetime.datetime.today()
        else:
            date = datetime.datetime.strptime(date_str, "%Y-%m")
        next_month_date = date + relativedelta(months=1)
        start_date = datetime.date(year=date.year, month=date.month, day=1)
        end_date = datetime.date(year=next_month_date.year, month=next_month_date.month, day=1)
        self.write(res_success(data=ExchangeTradingCalendar.get_calendar_label(start_date, end_date)))

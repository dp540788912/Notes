#-*- coding: utf-8 -*-

import tornado.ioloop
import tornado.web
from tornado.options import define, options

from handlers import *

urls = [
    (r"/api/v1/turing/alphamixer$", AlphaMixerListHandler),
    (r"/api/v1/turing/alphamixer/(?P<id>\d+)$", AlphaMixerDetailHandler),
    (r"/api/v1/turing/dim_online_diff$", DIMDiffListHandler),
    (r"/api/v1/turing/strategy_online_para$", DIMParasListHandler_V2),
    (r"/api/v1/turing/dim_online_request$", DimRequestListHandler_V2),
    (r"/api/v1/turing/dim_online_status$", DimOnlineStatusHandler),
    (r"/api/v1/turing/dim/evs$", TuringDIMEvsListHandler),
    (r"/api/v1/turing/dim/strategies$", TuringDIMStrategiesListHandler),

    (r"/api/v1/turing/common/exchanges$", ExchangesListHandler),
    (r"/api/v1/turing/common/exchanges/(?P<id>\d+)$", ExchangesDetailHandler),
    (r"/api/v1/turing/common/brokers$", BrokersListHandler),
    (r"/api/v1/turing/common/brokers/(?P<id>\d+)$", BrokersDetailHandler),
    (r"/api/v1/turing/common/counters$", CountersListHandler),
    (r"/api/v1/turing/common/counters/(?P<id>\d+)$", CountersDetailHandler),
    (r"/api/v1/turing/common/users$", UsersListHandler),
    (r"/api/v1/turing/common/users/(?P<id>\d+)$", UsersDetailHandler),
    (r"/api/v1/turing/common/accounts$", TuringAccountsListHandler),
    (r"/api/v1/turing/common/accounts/(?P<id>\d+)$", TuringAccountsDetailHandler),
    (r"/api/v1/turing/common/servers$", TuringServersListHandler),
    (r"/api/v1/turing/common/servers/(?P<id>\d+)$", TuringServersDetailHandler),
    (r"/api/v1/turing/common/paths$", TuringPathsListHandler),
    (r"/api/v1/turing/common/paths/(?P<id>\d+)$", TuringPathsDetailHandler),
    (r"/api/v1/turing/common/pre_agent_confs$", TuringPreAgentConfsListHandler),
    (r"/api/v1/turing/common/pre_agent_confs/(?P<id>\d+)$", TuringPreAgentConfsDetailHandler),
    (r"/api/v1/turing/common/pre_tool_confs$", TuringPreToolConfsListHandler),
    (r"/api/v1/turing/common/pre_tool_confs/(?P<id>\d+)$", TuringPreToolConfsDetailHandler),
    (r"/api/v1/turing/common/pre_trader_confs$", TuringPreTraderConfsListHandler),
    (r"/api/v1/turing/common/pre_trader_confs/(?P<id>\d+)$", TuringPreTraderConfsDetailHandler),
    (r"/api/v1/turing/common/pre_strategy_confs$", TuringPreStrategyConfsListHandler),
    (r"/api/v1/turing/common/pre_strategy_confs/(?P<id>\d+)$", TuringPreStrategyConfsDetailHandler),
    (r"/api/v1/turing/common/pre_conf_diff$", TuringPreConfDiffListHandler),
    (r"/api/v1/turing/common/pre_platform_confs$", TuringPreForwarderConfsListHandler),
    (r"/api/v1/turing/common/pre_platform_confs/(?P<id>\d+)$", TuringPreForwarderConfsDetailHandler),

    (r"/api/v1/turing/trader/program_types$", TuringProgramTypesListHandler),
    (r"/api/v1/turing/trader/program_types/(?P<id>\d+)$", TuringProgramTypesDetailHandler),
    (r"/api/v1/turing/trader/config_templates$", TuringConfigTemplatesListHandler),
    (r"/api/v1/turing/trader/config_templates/(?P<id>\d+)$", TuringConfigTemplatesDetailHandler),
    (r"/api/v1/turing/trader/programs$", TuringProgramsListHandler),
    (r"/api/v1/turing/trader/programs/(?P<id>\d+)$", TuringProgramsDetailHandler),

    (r"/api/v1/turing/operation/deploy_programs$", TuringDeployProgramsListHandler),
    (r"/api/v1/turing/operation/deploy_programs/(?P<id>\d+)$", TuringDeployProgramsDetailHandler),
    (r"/api/v1/turing/operation/deploy_evs$", TuringDeployEVsListHandler),
    (r"/api/v1/turing/operation/deploy_evs/(?P<id>\d+)$", TuringDeployEVsDetailHandler),
    (r"/api/v1/turing/operation/deploy_strategies$", TuringDeployStrategiesListHandler),
    (r"/api/v1/turing/operation/deploy_strategies/(?P<id>\d+)$", TuringDeployStrategiesDetailHandler),
    (r"/api/v1/turing/operation/generate_confs$", TuringGenerateConfsListHandler),
    (r"/api/v1/turing/operation/deploy_confs$", TuringDeployConfsListHandler),
    (r"/api/v1/turing/operation/bulk/deploy_confs$", TuringBulkDeployConfsListHandler),
    (r"/api/v1/turing/operation/processes$", TuringProcessListHandler),
    (r"/api/v1/turing/operation/update_xml$", TuringUpdateXmlSymbolHandler_V2),
    (r"/api/v1/turing/operation/modelsettings$", TuringModelSettingsHandler),

    (r"/api/v1/turing/post/configs$", TuringPostConfsListHandler),
    (r"/api/v1/turing/post/files$", TuringPostFilesListHandler),

    (r"/api/v1/turing/cmd/max_pos$", TuringDynamicModifyMaxPosHandler),
    (r"/api/v1/turing/cmd/symbol/max_pos$", TuringDynamicModifyMaxPosBySymbolHandler),
    (r"/api/v1/turing/rsp/max_pos$", TuringDynamicModifyMaxPosResponseHandler),
    (r"/api/v1/turing/operation/gen_quote_confs$", TuringGenQuoteConfsHandler),
    (r"/api/v1/turing/operation/update_quote_confs$", QuoteUpdateXmlSymbolHandler),

    (r"/api/v1/turing/daily/update_ctp_info$", TuringCtpInfoAutoUpdateHandler),

    # for galileo
    (r"/api/v1/turing/galileo/pre_trader_confs$", GalileoPreTraderConfsHandler),
    (r"/api/v1/turing/galileo/pre_trader_confs/(?P<id>\d+)$", GalileoPreTraderConfsDetailHandler),
    (r"/api/v1/turing/galileo/pre_strategy_confs$", GalileoPreStrategyConfsHandler),
    (r"/api/v1/turing/galileo/pre_strategy_confs/(?P<id>\d+)$", GalileoPreStrategyConfsDetailHandler),
    (r"/api/v1/turing/galileo/pre_confs$", GalileoPreConfsHandler),
    (r"/api/v1/turing/galileo/gen_galileo_confs$", GalileoGenConfsHandler),
    (r"/api/v1/turing/galileo/bulk/gen_galileo_confs$", GalileoBulkGenConfsHandler),
    (r"/api/v1/turing/galileo/update/galileo_process_ids$", GalileoDeployProcessIdsHandler),

    (r"/api/v1/turing/galileo/st_alerts$", GalileoGetStrategyAlertsHandler),
    (r"/api/v1/turing/galileo/total_alerts$", GalileoTotalStrategyAlertsHandler),
]


class Application(tornado.web.Application):
    def __init__(self, handlers):
        self.logger = logger
        self.cfg = config
        tornado.web.Application.__init__(self, handlers)


def make_app():
    return Application(urls)


if __name__ == "__main__":
    define("port", default=18890, help="run on the given port", type=int)
    options.parse_command_line()
    app = make_app()
    app.listen(options.port)
    tornado.ioloop.IOLoop.current().start()


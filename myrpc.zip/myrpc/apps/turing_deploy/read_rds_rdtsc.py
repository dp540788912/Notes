import time
import datetime
import json
import redis

from dateutil.parser import parse
from db import session_context as mysql_sc
from models import *


conf = {
    'ip': '127.0.0.1',
    'port': '6379',
    'rdtsc2': 'a:oss:galileo:tunnel_rdtsc',
}   

rds = redis.Redis(conf['ip'], conf['port'])


if __name__ == '__main__':

    n = datetime.datetime.now()
    if n.hour >=8 and n.hour < 20:
        start_time = n.strftime("%Y-%m-%d") + " 08:30:00"
        end_time = n.strftime("%Y-%m-%d") + " 15:30:00"
    else:
        start_time = (n - datetime.timedelta(days=1)).strftime("%Y-%m-%d") + " 20:30:00"
        end_time = n.strftime("%Y-%m-%d") + " 03:00:00"
    print(start_time, end_time)

    #while True:
    #    time.sleep(600)
    rdtsc2 = rds.lpop(conf['rdtsc2'])
    #if not rdtsc2:
    #    break

    if rdtsc2:
        try:
            data = json.loads(str(rdtsc2, 'utf-8'))
            host = data['host']
            bus_id = data['bus_id']
            send_rdtsc = data['send_rdtsc']
            send_end_rdtsc = data['send_end_rdtsc']
            send_to_send_end_rdtsc = send_end_rdtsc - send_rdtsc
            print(host, bus_id, send_rdtsc, send_end_rdtsc)
            with mysql_sc() as sc:
                lines = sc.query(GalileoRdtscLogs).filter(
                    GalileoRdtscLogs.host == host,
                    GalileoRdtscLogs.bus_id == bus_id,
                    GalileoRdtscLogs.r_create_time > start_time,
                    GalileoRdtscLogs.r_create_time < end_time,
                )
                for line in lines:
                    line.send_rdtsc = send_rdtsc
                    line.send_end_rdtsc = send_end_rdtsc
                    if send_rdtsc > line.place_rdtsc:
                        line.place_to_send_rdtsc = send_rdtsc - line.place_rdtsc
                    line.send_to_send_end_rdtsc = send_to_send_end_rdtsc
        except:
            pass


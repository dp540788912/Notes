# -*- coding:utf-8 -*-

import requests
import json
import os
import time


def main_loop():
    headers = { 
        'content-type': 'application/json',
        'whitelist': 'operater',
    }   

    ret = {}
    try:
        url = 'http://127.0.0.1/api/v1/platform/turing/track/auto/cache'
        requests.get(url, headers=headers)
        return True
    except Exception as e:
        return False


if __name__ == '__main__':

    while True:
        main_loop()
        time.sleep(5)


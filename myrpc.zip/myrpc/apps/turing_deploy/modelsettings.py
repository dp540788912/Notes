#!/usr/bin/python


import os
import glob
import csv
import xml.etree.ElementTree as et
from db import Session, session_context as mysql_sc
from config import config
from models import DIMFiles


st2id = {
    'hi5': 500, 'hi5a': 501, 'hi50': 503, 'hi50a': 504,
    'hi51': 510, 'hi51a': 511, 'hi52': 520, 'hi52a': 521,
    'hi53': 530, 'hi55': 550, 'hi55a': 551,
    'hi70': 70, 'hi71': 71, 'hi72': 72, 'hi73': 73,
    'hi74': 74, 'hi75': 75, 'hi76': 76,
    'hi80': 80, 'hi81': 81, 'hi82': 82, 'hi83': 83,
    'hi84': 84, 'hi85': 85, 'hi86': 86,
    'hi91': 91, 'hi92': 92, 'hi93': 93,
    'ip11': 1911, 'ip91': 1991, 'ip92': 1992, 'ip93': 1993,
    'ip94': 1994, 'ip95': 1995, 'ip96': 1996, 'ip97': 1997,
    'hi0': 8512,
    'hi05': 8500, 'hi05a': 8501, 'hi050': 8503, 'hi050a': 8504,
    'hi051': 8510, 'hi051a': 8511, 'hi052': 8520, 'hi052a': 8521,
    'hi055': 8550, 'hi055a': 8551,
    'hi071': 8071, 'hi072': 8072, 'hi073': 8073, 'hi074': 8074,
    'hi075': 8075, 'hi076': 8076,
    'lt91': 291,
    'hi05p2': 6500, 'hi05ap2': 6501, 'hi050p2': 6503, 'hi050ap2': 6504, 
    'hi051p2': 6510, 'hi051ap2': 6511, 'hi052p2': 6520, 'hi052ap2': 6521, 
    'hi055p2': 6550, 'hi055ap2': 6551, 'hi05p3': 7500, 'hi05ap3': 7501,
    'hi050p3': 7503, 'hi050ap3': 7504, 'hi051p3': 7510, 'hi051ap3': 7511, 
    'hi052p3': 7520, 'hi052ap3': 7521, 'hi055p3': 7550, 'hi055ap3': 7551, 
    'hi06': 8600, 'hi06a': 8601, 'hi060': 8603, 'hi060a': 8604, 
    'hi061': 8610, 'hi061a': 8611, 'hi062': 8620, 'hi062a': 8621, 
    'hi065': 8650, 'hi065a': 8651, 'hi06p2': 6600, 'hi06ap2': 6601, 
    'hi060p2': 6603, 'hi060ap2': 6604, 'hi061p2': 6610, 'hi061ap2': 6611, 
    'hi062p2': 6620, 'hi062ap2': 6621, 'hi065p2': 6650, 'hi065ap2': 6651,
    'hi06p3': 7600, 'hi06ap3': 7601, 'hi060p3': 7603, 'hi060ap3': 7604,
    'hi061p3': 7610, 'hi061ap3': 7611, 'hi062p3': 7620, 'hi062ap3': 7621,
    'hi065p3': 7650, 'hi065ap3': 7651,
}


class ModelUnit(object):

    def __init__(self):
        self.date = None
        self.day_night = None
        self.model_id = None
        self.model_name = None
        self.server = None
        self.account = None
        self.product = None
        self.symbol = None
        self.strategy = None
        self.limit_vol = None
        self.max_vol = None
        self.cancel_limit = None
        self.so_name = None
        self.trade_start_time = None
        self.trade_close_time = None
        self.open_end_time = None
        self.para1 = None
        self.para2 = None
        self.para3 = None
        self.fee_by_vol = None
        self.fee_by_amt = None
        self.fill_ratio = None
        self.origin_so = None

    def fill_field(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)

    def fill_ev_field(self, ev_file_basename):
        with mysql_sc() as sc:
            _o = sc.query(DIMFiles).filter(
                DIMFiles.file_name == ev_file_basename
            ).order_by(
                DIMFiles.id.desc()
            ).first()
            if not _o:
                return False
            ev_file = os.path.join(config.dim['mnt_path'], _o.file_path)
            with open(ev_file, 'r') as f:
                reader = csv.DictReader(f, delimiter='|')
                for row in reader:
                    if self.so_name == row.get('so_name', ''):
                        self.fill_field(**row)
                        return True
        return False

    def to_desc(self):
        return {
            'date': self.date,
            'day_night': self.day_night,
            'model_id': self.model_id,
            'model_name': self.model_name,
            'server': self.server,
            'account': self.account,
            'product': self.product,
            'symbol': self.symbol,
            'strategy': self.strategy,
            'limit_vol': self.limit_vol,
            'max_vol': self.max_vol,
            'cancel_limit': self.cancel_limit,
            'so_name': self.so_name,
            'trade_start_time': self.trade_start_time,
            'trade_close_time': self.trade_close_time,
            'open_end_time': self.open_end_time,
            'para1': self.para1,
            'para2': self.para2,
            'para3': self.para3,
            'fee_by_vol': self.fee_by_vol,
            'fee_by_amt': self.fee_by_amt,
            'fill_ratio': self.fill_ratio,
            'origin_so': self.origin_so,
        }


def generate_modelsettings(turing_xml_list):
    units = []
    for turing_xml in turing_xml_list:
        root = et.fromstring(turing_xml)

        trade_local_ip = root.find("trader_login/local_ip")
        quote_local_ip = root.find("quote_login/local_ip")
        if trade_local_ip is not None:
            server_str = trade_local_ip.text
        elif quote_local_ip is not None:
            server_str = quote_local_ip.text
        else:
            server_str = "0.0.0.0"

        account = root.find("tot_account_number/account")
        account_str = account.find('user_id').text

        strategies = account.findall("strategy")
        for strategy in strategies:
            symbol_str = strategy.find('symbol').text
            strategy_so_str = os.path.splitext(os.path.basename(strategy.find('strategy_so').text))[0]
            if len(strategy_so_str.split('_')) != 3:
                continue
            origin_so_str = strategy_so_str.split('_')[0]
            product_str = strategy_so_str.split('_')[1]
            day_night_str = strategy_so_str.split('_')[2]
            ev_file_str = os.path.basename(strategy.find('strategy_ev_file').text.split('|')[0])
            max_vol_str = strategy.find('strategy_max_pos').text
            if strategy.find('strategy_cancel_max') is not None:
                cancel_limit_str = strategy.find('strategy_cancel_max').text
            elif strategy.find('strategy_max_cancel_cnt') is not None:
                cancel_limit_str = strategy.find('strategy_max_cancel_cnt').text
            else:
                continue
            strategy_str = origin_so_str

            sub_strategies = strategy.findall("sub_strategy")
            if len(sub_strategies) == 0:
                model_id_str = strategy2modelid(strategy_str)
                model_name_str = '%s_%s_%s_%s' % (account_str, strategy_str, product_str, day_night_str)
                so_name_str = strategy2soname(strategy_str, product_str)
                unit = ModelUnit()
                _d = {
                    'day_night': day_night_str,
                    'model_id': model_id_str,
                    'model_name': model_name_str,
                    'server': server_str,
                    'account': account_str,
                    'product': product_str,
                    'symbol': symbol_str,
                    'strategy': strategy_str,
                    'limit_vol': max_vol_str,
                    'max_vol': max_vol_str,
                    'cancel_limit': cancel_limit_str,
                    'so_name': so_name_str,
                    'origin_so': origin_so_str,
                }
                unit.fill_field(**_d)
                unit.fill_ev_field(ev_file_str)
                units.append(unit)
            else:
                for sub_strategy in sub_strategies:
                    max_vol_str = sub_strategy.find('max_pos').text
                    strategy_str = sub_strategy.find('strat_name').text
                    if 'x1' in origin_so_str:
                        strategy_str += 'x1'
                    elif 'x3' in origin_so_str:
                        strategy_str += 'x3'
                    strategy_str += 'alpha'
                    model_id_str = strategy2modelid(strategy_str)
                    model_name_str = '%s_%s_%s_%s' % (account_str, strategy_str, product_str, day_night_str)
                    so_name_str = strategy2soname(strategy_str, product_str)
                    unit = ModelUnit()
                    _d = {
                        'day_night': day_night_str,
                        'model_id': model_id_str,
                        'model_name': model_name_str,
                        'server': server_str,
                        'account': account_str,
                        'product': product_str,
                        'symbol': symbol_str,
                        'strategy': strategy_str,
                        'limit_vol': max_vol_str,
                        'max_vol': max_vol_str,
                        'cancel_limit': cancel_limit_str,
                        'so_name': so_name_str,
                        'origin_so': origin_so_str,
                    }
                    unit.fill_field(**_d)
                    unit.fill_ev_field(ev_file_str)
                    units.append(unit)
    data = [_u.to_desc() for _u in units]
    res = {
        'header': [
            #{'title': 'date', 'prop': 'date'},
            {'title': 'day_night', 'prop': 'day_night'},
            {'title': 'model_id', 'prop': 'model_id'},
            {'title': 'model_name', 'prop': 'model_name'},
            {'title': 'server', 'prop': 'server'},
            {'title': 'account', 'prop': 'account'},
            {'title': 'product', 'prop': 'product'},
            {'title': 'symbol', 'prop': 'symbol'},
            {'title': 'strategy', 'prop': 'strategy'},
            {'title': 'limit_vol', 'prop': 'limit_vol'},
            {'title': 'max_vol', 'prop': 'max_vol'},
            {'title': 'cancel_limit', 'prop': 'cancel_limit'},
            {'title': 'so_name', 'prop': 'so_name'},
            {'title': 'trade_start_time', 'prop': 'trade_start_time'},
            {'title': 'trade_close_time', 'prop': 'trade_close_time'},
            {'title': 'open_end_time', 'prop': 'open_end_time'},
            {'title': 'para1', 'prop': 'para1'},
            {'title': 'para2', 'prop': 'para2'},
            {'title': 'para3', 'prop': 'para3'},
            {'title': 'fee_by_vol', 'prop': 'fee_by_vol'},
            {'title': 'fee_by_amt', 'prop': 'fee_by_amt'},
            {'title': 'fill_ratio', 'prop': 'fill_ratio'},
            {'title': 'origin_so', 'prop': 'origin_so'},
        ],
        'data': data,
    }
    return res


def strategy2modelid(strategy_str):
    strategy_str = strategy_str.replace('all', '').replace('alpha', '').replace('x1', '').replace('x3', '')
    model_id = st2id.get(strategy_str, -1)
    return model_id


def strategy2soname(strategy_str, product_str):
    strategy_str = strategy_str.replace('all', '').replace('alpha', '')
    return '%s_%s' % (strategy_str, product_str)


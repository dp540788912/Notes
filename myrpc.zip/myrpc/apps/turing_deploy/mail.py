# -*- coding:utf-8 -*-

import smtplib
import requests
from email.header import Header
from email.mime.text import MIMEText
from email.utils import parseaddr, formataddr
from config import config
from tornado.concurrent import run_on_executor
from concurrent.futures import ThreadPoolExecutor



class Notification(object):
    executor = ThreadPoolExecutor(2)

    def __init__(self):
        # email params
        self.FROM_ADDR = "rss@mycapital.net"
        self.PASSWORD = "Mycapital0427"
        self.SMTP_SERVER = "smtp.qiye.163.com"
        self.SMTP_SERVER_PORT = 25

    @run_on_executor
    def async_send_mail(self, subject, msg, email_list):
        self.send_email(subject, msg, email_list)

    @run_on_executor
    def async_send_sms(self, content, sms_list):
        self.send_sms(content, sms_list)

    def format_addr(self, address):
        name, addr = parseaddr(address)
        return formataddr((Header(name, 'utf-8').encode(), addr))

    def send_email(self, title, content, to_addrs):
        email_title = title
        msg = MIMEText(content, "plain", "utf-8")
        msg["From"] = self.format_addr("<%s>" % self.FROM_ADDR)
        msg_to = ""
        for to_addr in to_addrs:
            msg_to += self.format_addr("<%s>" % to_addr) + ','
        msg["To"] = msg_to[:-1]
        msg["Subject"] = Header(email_title, "utf-8").encode()

        server = smtplib.SMTP(self.SMTP_SERVER, self.SMTP_SERVER_PORT)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(self.FROM_ADDR, self.PASSWORD)
        server.sendmail(self.FROM_ADDR, to_addrs, msg.as_string())
        server.quit()

    def send_sms(self, content, sms_list):
        payload = {
            'to': ','.join(sms_list),
            'do': 'sms',
            'msg': content
        }

        try:
            r = requests.post(config.sms_url, data=payload)
        except Exception as e:
            return -1, str(e)

        if r.text.strip() == 'success':
            return 0, "success"
        else:
            err = "Http return %s" % r.text.strip()
            return -1, err



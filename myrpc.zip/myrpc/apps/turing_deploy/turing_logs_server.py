# -*- coding:utf-8 -*-

import time
import datetime
import json
import redis

from db import session_context as mysql_sc
from models import *
from kdb_api import KdbQuery
from dateutil.parser import parse


conf = {
    #'ip': '127.0.0.1',
    'ip': '192.168.10.99',
    'port': '6379',
    'rdtsc': 'a:oss:turing:rdtsc',
    'position': 'a:oss:turing:position',
    'execute': 'a:oss:cmd:execute',
    'alert': 'strategy:oss:alerts',
}

rds = redis.Redis(conf['ip'], conf['port'])


def get_exchange_name(exchg_id):
    if int(exchg_id) == 0:
        return "SHFE"
    elif int(exchg_id) == 1:
        return "CZCE"
    elif int(exchg_id) == 2:
        return "DCE"
    elif int(exchg_id) == 3:
        return "CFFEX"
    else:
        return ""


def get_enum_exchange(enum_exchg):
    if enum_exchg == '0':
        return 'SZSE'
    elif enum_exchg == '1':
        return 'SSE'
    elif enum_exchg == '2':
        return 'HKEX'
    elif enum_exchg == 'A':
        return 'SHFE'
    elif enum_exchg == 'G':
        return 'CFFEX'
    elif enum_exchg == 'B':
        return 'DCE'
    elif enum_exchg == 'C':
        return 'CZCE'
    elif enum_exchg == 'F':
        return 'FUT_EXCH'
    elif enum_exchg == 'S':
        return 'SGX'
    else:
        return ""


def parse_agent_time(update_time):
    k_obj = KdbQuery()
    t = parse(update_time)
    calendar_date = t.strftime('%Y-%m-%d')
    calendar_time = t.strftime('%H:%M:%S')
    if '07:00:00' < calendar_time < '19:00:00':
        day_night = 0
        trading_date = calendar_date
    else:
        day_night = 1
        d = datetime.datetime.strptime(calendar_date, '%Y-%m-%d')
        if '00:00:00' <= calendar_time < '07:00:00':
            try:
                trading_date = k_obj.get_trading_date(calendar_date, 0)
            except Exception as e:
                if d.weekday() == 5:
                    trading_date = datetime.datetime.strftime(d + datetime.timedelta(days=2), '%Y-%m-%d')
                else:
                    trading_date = datetime.datetime.strftime(d, '%Y-%m-%d')
        else:
            try:
                trading_date = k_obj.get_trading_date(calendar_date, 1)
            except Exception as e:
                if d.weekday() == 4:
                    trading_date = datetime.datetime.strftime(d + datetime.timedelta(days=3), '%Y-%m-%d')
                else:
                    trading_date = datetime.datetime.strftime(d + datetime.timedelta(days=1), '%Y-%m-%d')
    return trading_date, calendar_time, day_night

def fill_error_msg(alert_data):
    err_no = alert_data['err_no']

    if int(alert_data['alert_type']) == 1:
        enum_error = {
            90000001: '没有entrust回报或已撤单未撤掉',
            90000002: '行情缺少涨跌停',
            90000003: '两笔行情间成交量或金额为负',
            90000004: '深度行情异常',
            90000888: '账户接力',
        }
        if err_no in enum_error:
            alert_data['err_msg'] = enum_error[err_no]
    else:
        enum_error = {
            -90000001: '自成交',
            -90000002: '开仓上限',
            -90000003: '报单的合约无效',
            -90000004: '撤单上限',
            -90000005: '撤单号无效',
            -90000006: '被撤的订单已完结',
            -90000007: '撤单达到FAK阈值',
        }
        if err_no in enum_error:
            alert_data['err_msg'] = enum_error[err_no]

        if alert_data['exchange'] in ['SHFE', 'DCE', 'CFFEX']:
            if err_no == 11:
                alert_data['err_msg'] = '外部拒单异常'


if __name__ == '__main__':

    while True:
        for _ in range(100):

            rdtsc = rds.lpop(conf['rdtsc'])
            position = rds.lpop(conf['position'])
            execute = rds.lpop(conf['execute'])
            alert = rds.lpop(conf['alert'])
            if not rdtsc and not position and not execute and not alert:
                break

            if rdtsc:
                data = json.loads(str(rdtsc, 'utf-8'))
                if 'sub_order_id' not in data:
                    continue
                with mysql_sc() as sc:
                    record = {
                        'host': data['ip'],
                        'account': data['account'],
                        'symbol': data['symbol'],
                        'exchange': get_enum_exchange(chr(data['exchange'])),
                        'trigger': data['int_time'],
                        'sub_order_id': data['sub_order_id'],
                        'bus_id': data['bus_id'],
                        'front_id': data['front_id'],
                        'quote_rdtsc': data['quote_rdtsc'],
                        'feed_rdtsc': data['feed_rdtsc'],
                        'feed_end_rdtsc': data['feed_end_rdtsc'],
                        'place_rdtsc': data['place_rdtsc'],
                        'send_rdtsc': data['send_rdtsc'],
                        'send_end_rdtsc': data['send_end_rdtsc'],
                    }
                    if data['feed_rdtsc'] > data['quote_rdtsc']:
                        record['quote_to_feed_rdtsc'] = data['feed_rdtsc'] - data['quote_rdtsc']
                    if data['place_rdtsc'] > data['feed_rdtsc']:
                        record['feed_to_place_rdtsc'] = data['place_rdtsc'] - data['feed_rdtsc']
                    if data['feed_end_rdtsc'] > data['feed_rdtsc']:
                        record['feed_to_feed_end_rdtsc'] = data['feed_end_rdtsc'] - data['feed_rdtsc']
                    if data['send_rdtsc'] > data['place_rdtsc']:
                        record['place_to_send_rdtsc'] = data['send_rdtsc'] - data['place_rdtsc']
                    if data['send_end_rdtsc'] > data['send_rdtsc']:
                        record['send_to_send_end_rdtsc'] = data['send_end_rdtsc'] - data['send_rdtsc']

                    o = GalileoRdtscLogs(**record)
                    sc.add(o)

            if position:
                data = json.loads(str(position, 'utf-8'))
                with mysql_sc() as sc:
                    pos = {
                        'account': data['account'][:-2],
                        'vstrategy_id': int(data['account'][-2:]),
                        'symbol': data['symbol'],
                        'td_long_pos': data['td_long_pos'],
                        'td_long_avg_price': data['td_long_avg_price'],
                        'td_short_pos': data['td_short_pos'],
                        'td_short_avg_price': data['td_short_avg_price'],
                        'yd_long_pos': data['yd_long_pos'],
                        'yd_long_avg_price': data['yd_long_avg_price'],
                        'yd_short_pos': data['yd_short_pos'],
                        'yd_short_avg_price': data['yd_short_avg_price'],
                    }
                    o = TuringPositionLogs(**pos)
                    sc.add(o)

            if execute:
                data = json.loads(str(execute, 'utf-8'))
                with mysql_sc() as sc:
                    record = sc.query(TuringCommandLogs).filter(
                        TuringCommandLogs.seq == data['seq'],
                        TuringCommandLogs.type == data['type'],
                    ).first()
                    if record:
                        record.execute = data['execute']

            if alert:
                try:
                    data = json.loads(str(alert, 'utf-8'))
                except:
                    data = json.loads(str(alert, 'gb18030', 'ignore'))
                if 'sub_order_id' not in data:
                    continue
                with mysql_sc() as sc:
                    trading_date, trading_time, day_night = parse_agent_time(data['update_time'])
                    st_alert = {
                        'trading_date': trading_date,
                        'trading_time': trading_time,
                        'day_night': day_night,
                        'alert_type': data['type'],
                        'exchange': get_enum_exchange(chr(data['exchange'])),
                        'host': data['ip'],
                        'process_id': data['process_id'],
                        'account': data['account'],
                        'vstrategy_id': data['v_st_id'],
                        'symbol': data['symbol'],
                        'local_order_id': data['sub_order_id'],
                        'err_no': data['error_no'],
                        'err_msg': data['err_msg'],
                    }
                    fill_error_msg(st_alert)
                    o = TuringStAlertLogs(**st_alert)
                    sc.add(o)

        time.sleep(1)


#-*-coding:utf-8-*-

import requests
import os
import datetime, time

from sqlalchemy import distinct
from sqlalchemy.sql import func, or_, and_
from sqlalchemy.orm import relationship
from sqlalchemy import Column, ForeignKey, PrimaryKeyConstraint, UniqueConstraint
from sqlalchemy.dialects.mysql import BIGINT, DATETIME, DATE, TIME, INTEGER, VARCHAR, TEXT, LONGTEXT, FLOAT, DOUBLE, BOOLEAN, JSON, ENUM

from db import ModelBase, session, session_context as mysql_sc
from config import config


class Exchanges(ModelBase):

    __tablename__ = 'exchanges'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(10), nullable=False, unique=True)
    code = Column(VARCHAR(10), nullable=False, unique=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'code': self.code,
        }


class Brokers(ModelBase):

    __tablename__ = 'brokers'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
        }


class Counters(ModelBase):

    __tablename__ = 'counters'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(36), nullable=False)
    exchange_id = Column(ForeignKey('exchanges.id'))
    broker_id = Column(ForeignKey('brokers.id'))
    broker_no = Column(VARCHAR(32), nullable=True)
    quote_forwarder_addr = Column(VARCHAR(256), nullable=True)
    counter_forwarder_addr = Column(VARCHAR(256), nullable=True)
    query_addr = Column(VARCHAR(256), nullable=True)

    exchange_obj = relationship('Exchanges')
    broker_obj = relationship('Brokers')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'exchange': {
                'id': self.exchange_obj.id,
                'name': self.exchange_obj.name,
            },
            'broker': {
                'id': self.broker_obj.id,
                'name': self.broker_obj.name,
            },
        }


class Accounts(ModelBase):

    __tablename__ = 'accounts'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)
    password = Column(VARCHAR(128), nullable=False)
    fund_total = Column(FLOAT, nullable=True)
    fund_occupied = Column(FLOAT, nullable=True)
    broker_id = Column(ForeignKey('brokers.id'))
    user_id = Column(ForeignKey('users.id'))
    valid = Column(BOOLEAN, nullable=False)
    use_turing = Column(BOOLEAN, nullable=True)
    seat = Column(VARCHAR(256), nullable=True, default='CTP主席')
    rsp_pwd = Column(VARCHAR(128), nullable=True)
    client_name = Column(VARCHAR(32), nullable=True)
    need_query = Column(BOOLEAN, nullable=True)
    account_name = Column(VARCHAR(256), nullable=True)
    fund_ratio = Column(VARCHAR(32), nullable=True)
    use_for = Column(VARCHAR(64), nullable=True)
    market = Column(VARCHAR(256), nullable=True)
    counter_seat = Column(VARCHAR(256), nullable=True)
    query_passwd = Column(VARCHAR(256), nullable=True)
    query_broker = Column(VARCHAR(32), nullable=True)
    check_pos = Column(BOOLEAN, nullable=False, default=False)
    product_info = Column(VARCHAR(256), nullable=True)
    auth_code = Column(VARCHAR(256), nullable=True)

    broker_obj = relationship('Brokers')
    user_obj = relationship('Users')

    def brief(self):
        return {
            'id': self.id,
            'name': self.name,
            'password': self.password,
            'fund_total': self.fund_total,
            'fund_occupied': self.fund_occupied,
            'valid': self.valid,
            'rsp_pwd': self.rsp_pwd or '',
        }

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'password': self.password,
            'fund_total': self.fund_total,
            'fund_occupied': self.fund_occupied,
            'broker': {
                'id': self.broker_obj.id,
                'name': self.broker_obj.name,
            },
            'user': {
                'id': self.user_obj.id,
                'name': self.user_obj.name,
            },
            'valid': self.valid,
            'use_turing': self.use_turing or False,
            'seat': self.seat,
            'rsp_pwd': self.rsp_pwd or '',
        }


class Servers(ModelBase):

    __tablename__ = 'servers'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    ip = Column(VARCHAR(45), nullable=False, unique=True)
    broker_id = Column(ForeignKey('brokers.id'))

    broker_obj = relationship('Brokers')

    def brief(self):
        return {
            'id': self.id,
            'ip': self.ip,
        }

    def to_dict(self):
        return {
            'id': self.id,
            'ip': self.ip,
            'broker': {
                'id': self.broker_obj.id,
                'name': self.broker_obj.name,
            },
        }


class Users(ModelBase):

    __tablename__ = 'users'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False)
    password = Column(VARCHAR(255), nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'password': self.password,
        }


class AlphaMixer(ModelBase):

    __tablename__ = 'alphamixer'

    __table_args__ = (
        UniqueConstraint('strat', 'sub_strat', 'series'),
    )

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strat= Column(VARCHAR(32), nullable=False)
    sub_strat= Column(VARCHAR(32), nullable=False)
    series = Column(VARCHAR(128), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())

    def to_dict(self):
        return {
            'id': self.id,
            'strategy_name': self.strat,
            'sub_strategy_name': self.sub_strat,
            'series': self.series,
        }


class DIMFiles(ModelBase):

    __tablename__ = 'dim_files'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    file_type = Column(INTEGER, nullable=False)     # 1:so; 2:csv; 3:ev 11:test-so; 12:test-csv; 13:test-ev
    file_path = Column(VARCHAR(256), nullable=False)
    file_name = Column(VARCHAR(256), nullable=False)
    file_md5 = Column(VARCHAR(256), nullable=False)
    valid = Column(BOOLEAN, nullable=False, default=True)
    version = Column(VARCHAR(256), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())

    def to_dict(self):
        return {
            'id': self.id,
            'version': self.version,
            'file_name': self.file_name,
        }


class TuringServers(ModelBase):

    __tablename__ = 'turing_servers'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    ip = Column(VARCHAR(45), nullable=False, unique=True)
    broker_id = Column(ForeignKey('brokers.id'))

    broker_obj = relationship('Brokers')

    def brief(self):
        return {
            'id': self.id,
            'ip': self.ip,
        }

    def to_dict(self):
        return {
            'id': self.id,
            'ip': self.ip,
            'broker': {
                'id': self.broker_obj.id,
                'name': self.broker_obj.name,
            },
        }


class TuringPaths(ModelBase):

    __tablename__ = 'turing_paths'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(256), nullable=False, unique=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
        }


class TuringProgramTypes(ModelBase):

    __tablename__ = 'turing_program_types'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(128), nullable=False, unique=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
        }


class TuringApiTypes(ModelBase):

    __tablename__ = 'turing_api_types'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)
    api_id = Column(INTEGER, nullable=False)
    program_type_id = Column(ForeignKey('turing_program_types.id'))
    exchange_id = Column(ForeignKey('exchanges.id'))

    program_type_obj = relationship('TuringProgramTypes')
    exchange_obj = relationship('Exchanges')

    def brief(self):
        return {
            'id': self.id,
            'name': self.name,
            'api_id': self.api_id,
            'exchange_code': self.exchange_obj.code,
        }

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'api_id': self.api_id,
            'program_type': {
                'id': self.program_type_obj.id,
                'name': self.program_type_obj.name,
            },
            'exchange': {
                'id': self.exchange_obj.id,
                'name': self.exchange_obj.name,
                'code': self.exchange_obj.code,
            },
        }


class TuringConfigTemplates(ModelBase):

    __tablename__ = 'turing_config_templates'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(128), nullable=False)
    content = Column(LONGTEXT, nullable=False)
    program_type_id = Column(ForeignKey('turing_program_types.id'))

    program_type_obj = relationship('TuringProgramTypes')

    def brief(self):
        return {
            'id': self.id,
            'name': self.name,
            'content': self.content,
        }

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'content': self.content,
            'program_type': {
                'id': self.program_type_obj.id,
                'name': self.program_type_obj.name,
            },
        }


class TuringPrograms(ModelBase):

    __tablename__ = 'turing_programs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(128), nullable=False)
    type_id = Column(ForeignKey('turing_program_types.id'))
    filepath = Column(VARCHAR(256), nullable=False)
    version = Column(VARCHAR(32), nullable=False)

    program_type_obj = relationship('TuringProgramTypes')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'type': {
                'id': self.program_type_obj.id,
                'name': self.program_type_obj.name,
            },
            'filepath': self.filepath,
            'version': self.version,
        }


class TuringPreAgentConfs(ModelBase):

    __tablename__ = 'turing_pre_agent_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(64), nullable=False)
    deploy_path = Column(VARCHAR(256), nullable=False)
    valid = Column(BOOLEAN, nullable=False)
    server_id = Column(ForeignKey('turing_servers.id'))

    server_obj = relationship('TuringServers')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'deploy_path': self.deploy_path,
            'valid': self.valid,
            'server': self.server_obj.brief(),
        }


class TuringPreToolConfs(ModelBase):

    __tablename__ = 'turing_pre_tool_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(64), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    deploy_path = Column(VARCHAR(255), nullable=False)
    script_cpu_valid = Column(BOOLEAN, nullable=False)
    script_cpu_bind = Column(INTEGER, nullable=True)
    valid = Column(BOOLEAN, nullable=False)
    server_id = Column(ForeignKey('turing_servers.id'))
    config_template_id = Column(ForeignKey('turing_config_templates.id'))
    product_list = Column(JSON, nullable=True)

    server_obj = relationship('TuringServers')
    config_template_obj = relationship('TuringConfigTemplates')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'day_night': self.day_night,
            'deploy_path': self.deploy_path,
            'script_cpu_valid': self.script_cpu_valid,
            'script_cpu_bind': self.script_cpu_bind,
            'valid': self.valid,
            'server': self.server_obj.brief(),
            'product_list': self.product_list,
            'config_template': self.config_template_obj.brief(),
        }


class TuringPreTraderConfs(ModelBase):

    __tablename__ = 'turing_pre_trader_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(64), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    deploy_path = Column(VARCHAR(255), nullable=False)
    config_template_id = Column(ForeignKey('turing_config_templates.id'))
    script_cpu_valid = Column(BOOLEAN, nullable=False)
    script_cpu_bind = Column(INTEGER, nullable=True)
    config_cpu_valid = Column(BOOLEAN, nullable=False)
    config_cpu_bind = Column(JSON, nullable=True)
    local_ip = Column(VARCHAR(32), nullable=True)
    local_port = Column(VARCHAR(16), nullable=True)
    src_mac = Column(VARCHAR(64), nullable=True)
    nic = Column(VARCHAR(16), nullable=True)
    valid = Column(BOOLEAN, nullable=False)
    server_id = Column(ForeignKey('turing_servers.id'))
    #account_id  = Column(ForeignKey('accounts.id'))
    account_id = Column(VARCHAR(64), nullable=False)

    server_obj = relationship('TuringServers')
    config_template_obj = relationship('TuringConfigTemplates')
    #account_obj = relationship('Accounts')

    @property
    def account_obj(self):
        with mysql_sc() as sc:
            objs = sc.query(Accounts).filter(Accounts.id.in_(self.account_id.split(',')))
            return [o.brief() for o in objs]

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'day_night': self.day_night,
            'deploy_path': self.deploy_path,
            'server': self.server_obj.brief(),
            'config_template': self.config_template_obj.brief(),
            'account': self.account_obj,
            'script_cpu_valid': self.script_cpu_valid,
            'script_cpu_bind': self.script_cpu_bind,
            'config_cpu_valid': self.config_cpu_valid,
            'config_cpu_bind': self.config_cpu_bind,
            'local_ip': self.local_ip,
            'local_port': self.local_port,
            'src_mac': self.src_mac,
            'nic': self.nic,
            'valid': self.valid,
        }


class TuringDeployPrograms(ModelBase):

    __tablename__ = 'turing_deploy_programs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    host = Column(VARCHAR(45), nullable=False)
    deploy_path = Column(VARCHAR(256), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    program_id = Column(ForeignKey('turing_programs.id'))
    result = Column(INTEGER, default=0)

    program_obj = relationship('TuringPrograms')

    def to_dict(self):
        return {
            'id': self.id,
            'result': self.result,
        }


class TuringDeployDIMFiles(ModelBase):

    __tablename__ = 'turing_deploy_dim_files'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    host = Column(VARCHAR(45), nullable=False)
    deploy_path = Column(VARCHAR(256), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    dimfile_id = Column(ForeignKey('dim_files.id'))
    products = Column(JSON, nullable=True)
    result = Column(INTEGER, nullable=False, default=0)

    dimfile_obj = relationship('DIMFiles')

    def to_dict(self):
        return {
            'id': self.id,
            'result': self.result,
        }


class TuringDeployConfs(ModelBase):

    __tablename__ = 'turing_deploy_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(256), nullable=True)
    host = Column(VARCHAR(45), nullable=False)
    deploy_path = Column(VARCHAR(256), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    program_id = Column(BIGINT(unsigned=True), nullable=True)
    content = Column(LONGTEXT, nullable=True)
    result = Column(INTEGER, nullable=True, default=0)
    status = Column(INTEGER, nullable=True, default=1)
    valid = Column(BOOLEAN, default=True, nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'host': self.host,
            'deploy_path': self.deploy_path,
            'day_night': self.day_night,
            'program_id': self.program_id,
            'result': self.result,
            'status': self.status,
            'valid': self.valid,
        }


class DIMPreConfs(ModelBase):

    __tablename__ = 'dim_pre_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    type = Column(INTEGER, nullable=False, default=1)   #1:product 2:test
    internal_date = Column(VARCHAR(16), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    exchange = Column(VARCHAR(16), nullable=False)
    product = Column(VARCHAR(16), nullable=False)
    symbol = Column(VARCHAR(16), nullable=False)
    alphamixer = Column(VARCHAR(256), nullable=False)
    strategy = Column(VARCHAR(256), nullable=False)
    max_vol = Column(INTEGER, nullable=False)
    limit_vol = Column(INTEGER, nullable=False)
    single_max_vol = Column(INTEGER, nullable=False, default=0)
    ev_dim = Column(VARCHAR(256), nullable=False)
    ev_data = Column(VARCHAR(256), nullable=False)
    account = Column(VARCHAR(256), nullable=True)
    fixed = Column(BOOLEAN, nullable=False)
    uid = Column(VARCHAR(256), nullable=False)
    fake_account = Column(VARCHAR(256), nullable=True)
    account_id = Column(INTEGER, nullable=True)
    #tunnel_id = Column(INTEGER, nullable=True)
    quote_lv = Column(INTEGER, nullable=True)
    v_account_id = Column(INTEGER, nullable=True)
    status = Column(INTEGER, nullable=False, default=0)    # 0: standby; 1: in-live

    def to_dict(self):
        return {
            'id': self.id,
            'type': 'product' if self.type == 1 else 'test',
            'internal_date': self.internal_date,
            'day_night': self.day_night,
            'exchange': self.exchange,
            'product': self.product,
            'symbol': self.symbol,
            'alphamixer': self.alphamixer,
            'strategy': self.strategy,
            'max_vol': self.max_vol,
            'limit_vol': self.limit_vol,
            'single_max_vol': self.single_max_vol,
            'ev_dim': self.ev_dim,
            'ev_data': self.ev_data,
            'account': self.account,
            'uid': self.uid,
            'fake_account': self.fake_account,
            'account_id': self.account_id,
            #'tunnel_id': self.tunnel_id,
            'quote_lv': self.quote_lv,
            'v_account_id': self.v_account_id,
        }


class TuringPreForwarderConfs(ModelBase):

    __tablename__ = 'turing_pre_forwarder_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(64), nullable=False)
    deploy_path = Column(VARCHAR(256), nullable=False)
    valid = Column(BOOLEAN, nullable=False)
    server_id = Column(ForeignKey('turing_servers.id'))

    server_obj = relationship('TuringServers')

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'deploy_path': self.deploy_path,
            'valid': self.valid,
            'server': self.server_obj.brief(),
        }


class TuringRdtscLogs(ModelBase):

    __tablename__ = 'turing_rdtsc_logs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    host = Column(VARCHAR(32), nullable=False)
    exchange = Column(VARCHAR(16), nullable=False)
    account = Column(VARCHAR(64), nullable=False)
    quote_rdtsc = Column(BIGINT(unsigned=True), nullable=False)
    feed_rdtsc = Column(BIGINT(unsigned=True), nullable=False)
    feed_end_rdtsc = Column(BIGINT(unsigned=True), nullable=False)
    send_rdtsc = Column(BIGINT(unsigned=True), nullable=False)
    send_end_rdtsc = Column(BIGINT(unsigned=True), nullable=False)
    feed_quote_delta = Column(BIGINT(unsigned=True), nullable=False)
    send_feed_delta = Column(BIGINT(unsigned=True), nullable=False)
    send_delta = Column(BIGINT(unsigned=True), nullable=False)
    feed_delta = Column(BIGINT(unsigned=True), nullable=False)
    trigger = Column(VARCHAR(16), nullable=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())


class GalileoRdtscLogs(ModelBase):

    __tablename__ = 'galileo_rdtsc_logs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    host = Column(VARCHAR(32), nullable=False)
    account = Column(VARCHAR(64), nullable=False)
    symbol = Column(VARCHAR(64), nullable=False)
    exchange = Column(VARCHAR(16), nullable=False)
    trigger = Column(VARCHAR(16), nullable=True)
    sub_order_id = Column(BIGINT(unsigned=True), nullable=False)
    bus_id = Column(BIGINT(unsigned=True), nullable=False)
    front_id = Column(BIGINT(unsigned=True), nullable=False)
    quote_rdtsc = Column(BIGINT(unsigned=True), nullable=False)
    feed_rdtsc = Column(BIGINT(unsigned=True), nullable=False)
    feed_end_rdtsc = Column(BIGINT(unsigned=True), nullable=False)
    place_rdtsc = Column(BIGINT(unsigned=True), nullable=False)
    send_rdtsc = Column(BIGINT(unsigned=True), nullable=False)
    send_end_rdtsc = Column(BIGINT(unsigned=True), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    quote_to_feed_rdtsc = Column(BIGINT(unsigned=True), nullable=False, default=0)
    feed_to_place_rdtsc = Column(BIGINT(unsigned=True), nullable=False, default=0)
    feed_to_feed_end_rdtsc = Column(BIGINT(unsigned=True), nullable=False, default=0)
    place_to_send_rdtsc = Column(BIGINT(unsigned=True), nullable=False, default=0)
    send_to_send_end_rdtsc = Column(BIGINT(unsigned=True), nullable=False, default=0)


class TuringPositionLogs(ModelBase):

    __tablename__ = 'turing_position_logs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    account = Column(VARCHAR(64), nullable=False)
    vstrategy_id = Column(INTEGER, nullable=False, default=0)
    symbol = Column(VARCHAR(16), nullable=False)
    td_long_pos = Column(INTEGER, nullable=False)
    td_long_avg_price = Column(FLOAT, nullable=False)
    td_short_pos = Column(INTEGER, nullable=False)
    td_short_avg_price = Column(FLOAT, nullable=False)
    yd_long_pos = Column(INTEGER, nullable=False)
    yd_long_avg_price = Column(FLOAT, nullable=False)
    yd_short_pos = Column(INTEGER, nullable=False)
    yd_short_avg_price = Column(FLOAT, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())


class TuringCommandLogs(ModelBase):

    __tablename__ = 'turing_command_logs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    type = Column(INTEGER, nullable=False)
    seq = Column(BIGINT, nullable=False)
    cmd = Column(JSON, nullable=True)
    execute = Column(INTEGER, nullable=False)       #-1:failed, 0:success, 1:doing, 2:overtime
    err_msg = Column(VARCHAR(255), nullable=True)
    current_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=True)
    r_create_user = Column(VARCHAR(64), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())


class UserInfo(ModelBase):

    __tablename__ = 'user_info'

    user_id = Column(BIGINT, primary_key=True)
    user_passwd = Column(VARCHAR(255), nullable=False)
    server_ip = Column(VARCHAR(32), nullable=False)
    server_port = Column(INTEGER, nullable=False)
    broker_id = Column(INTEGER, nullable=False)
    request_cycle = Column(INTEGER, nullable=False)
    product_info = Column(VARCHAR(255), nullable=True)
    auth_code = Column(VARCHAR(255), nullable=True)


class SymbolList(ModelBase):

    __tablename__ = 'symbol_list'

    symbol_id = Column(BIGINT, primary_key=True)
    symbol = Column(VARCHAR(64), nullable=False)


class SymbolMargin(ModelBase):

    __tablename__ = 'symbol_margin'

    timestamp = Column(BIGINT, primary_key=True)
    symbol = Column(VARCHAR(64), primary_key=True)
    hedge_flag = Column(INTEGER, nullable=False)
    long_margin_ratio = Column(DOUBLE, nullable=False)
    short_margin_ratio = Column(DOUBLE, nullable=False)


class AccountInfo(ModelBase):

    __tablename__ = 'account_info'

    user_id = Column(BIGINT, nullable=False, primary_key=True)
    timestamp = Column(BIGINT, nullable=False, primary_key=True)
    PreDeposit = Column(DOUBLE, nullable=False)         # 上次存款额
    PreBalance = Column(DOUBLE, nullable=False)         # 上次结算准备金
    Deposit = Column(DOUBLE, nullable=False)            # 入金金额
    Withdraw = Column(DOUBLE, nullable=False)           # 出金金额
    FrozenMargin = Column(DOUBLE, nullable=False)       # 冻结的保证金
    FrozenCash = Column(DOUBLE, nullable=False)         # 冻结的资金
    FrozenCommission = Column(DOUBLE, nullable=False)   # 冻结的手续费
    CurrMargin = Column(DOUBLE, nullable=False)         # 当前保证金总额
    Balance = Column(DOUBLE, nullable=False)            # 期货结算准备金
    Available = Column(DOUBLE, nullable=False)          # 可用资金
    WithdrawQuota = Column(DOUBLE, nullable=False)      # 可取资金
    ExchangeMargin = Column(DOUBLE, nullable=False)     # 交易所保证金
    Commission = Column(DOUBLE, nullable=False)         # 手续费
    CloseProfit = Column(DOUBLE, nullable=False)        # 平仓盈亏
    PositionProfit = Column(DOUBLE, nullable=False)     # 持仓盈亏


class CtpAccountPos(ModelBase):

    __tablename__ = 'ctp_account_pos'

    user_id = Column(BIGINT, nullable=False, primary_key=True)
    timestamp = Column(BIGINT, nullable=False, primary_key=True)
    symbol = Column(VARCHAR(64), nullable=False, primary_key=True)
    type = Column(BOOLEAN, nullable=False, primary_key=True)
    position = Column(INTEGER, nullable=False)


class GalileoPreTraderConfs(ModelBase):

    __tablename__ = 'gelileo_pre_trader_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    server_id = Column(ForeignKey('turing_servers.id'))
    type = Column(INTEGER, nullable=False)      # 1:tunnel 2:strategy
    valid = Column(BOOLEAN, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    name = Column(VARCHAR(64), nullable=False)
    deploy_path = Column(VARCHAR(256), nullable=False)
    config_template_id = Column(ForeignKey('turing_config_templates.id'))
    script_cpu_valid = Column(BOOLEAN, nullable=False)
    script_cpu_bind = Column(INTEGER, nullable=True)
    account = Column(ForeignKey('accounts.id'))
    #tunnel_id = Column(VARCHAR(64), nullable=True)
    account_id = Column(INTEGER, nullable=True)

    server_obj = relationship('TuringServers')
    config_template_obj = relationship('TuringConfigTemplates')
    account_obj = relationship('Accounts')

    def to_dict(self):
        return {
            'id': self.id,
            'server': self.server_obj.brief(),
            'type': self.type,
            'valid': self.valid,
            'day_night': self.day_night,
            'name': self.name,
            'deploy_path': self.deploy_path,
            'config_template': self.config_template_obj.brief(),
            'script_cpu_valid': self.script_cpu_valid,
            'script_cpu_bind': self.script_cpu_bind,
            'account': self.account_obj.brief(),
            'account_id': self.account_obj.id,
            #'tunnel_id': self.tunnel_id,
            'v_account_id': self.account_id,
        }

class TuringStAlertLogs(ModelBase):

    __tablename__ = 'turing_st_alert_logs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    trading_date = Column(DATE, nullable=False)
    trading_time = Column(TIME, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    alert_type = Column(INTEGER, nullable=False)
    exchange = Column(VARCHAR(16), nullable=False)
    host = Column(VARCHAR(32), nullable=False)
    process_id = Column(INTEGER, nullable=False)
    account = Column(VARCHAR(64), nullable=False)
    vstrategy_id = Column(INTEGER, nullable=False)
    symbol = Column(VARCHAR(64), nullable=False)
    local_order_id = Column(BIGINT(unsigned=True), nullable=False)
    err_no = Column(INTEGER, nullable=False)
    err_msg = Column(VARCHAR(256), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())

    def to_desc(self):
        return {
            'type': '行情' if self.alert_type == 1 else '回报',
            'time': self.r_create_time.strftime("%Y-%m-%d %H:%M:%S"),
            'exchange': self.exchange,
            'account': '%s-%s' % (self.account, self.vstrategy_id),
            'symbol': self.symbol,
            'error': self.err_msg,
        }


if __name__ == '__main__':
    from db import engine
    ModelBase.metadata.create_all(engine)

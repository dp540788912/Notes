#-*-coding:utf-8-*-

import netifaces


class CommonConfig(object):
    Debug = True
    kdb = {
        'host': '192.168.1.41',
        'port': 9000,
        'user': 'superuser1',
        'passwd': 'password',
    }
    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql
    redis = {
        'host': '127.0.0.1',
        'port': '6379',
        'cmd_key': 'oss:a:cmd:',
        'rsp_key': 'a:oss:rsp:',
    }
    local = {
        'host': '127.0.0.1',
        'user': 'rss',
        'vpn': '127.0.0.1',
    }
    dim = {
        'mnt_path': '/mnt/DIM',
    }


class ProductionConfig_180(CommonConfig):
    Debug = False
    mysql = {
        'host': '192.168.1.175',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql
    redis = {
        'host': '192.168.1.180',
        'port': '6379',
        'cmd_key': 'oss:a:cmd:',
        'rsp_key': 'a:oss:rsp:',
    }
    local = {
        'host': '192.168.1.180',
        'user': 'rss',
        'vpn': '192.168.30.154',
    }


class ProductionConfig_IDC(CommonConfig):
    Debug = False
    kdb = {
        'host': '192.168.10.102',
        'port': 9000,
        'user': 'superuser1',
        'passwd': 'password',
    }
    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'datahub',
        'user': 'operation',
        'passwd': '432bfa0bec42bd232818460647b3767a8e1cd7fd',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql
    local = {
        'host': '192.168.10.100',
        'user': 'rss',
        'vpn': '192.168.30.100',
    }


class DebugConfig_13(CommonConfig):
    local = {
        'host': '192.168.1.13',
        'user': 'rss',
        'vpn': '192.168.30.13',
    }


class DebugConfig_170(CommonConfig):
    mysql = {
        'host': '192.168.1.214',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }
    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql
    local = {
        'host': '192.168.1.170',
        'user': 'rss',
        'vpn': '192.168.30.170',
    }


iplist = [netifaces.ifaddresses(i).get(netifaces.AF_INET)[0]['addr']
          for i in netifaces.interfaces() if netifaces.ifaddresses(i).get(netifaces.AF_INET)]

product_idc_list = ['192.168.10.100']
product_180_list = ['192.168.1.180']
debug_170_iplist = ['192.168.1.170']
debug_13_iplist = ['192.168.1.13']

if any([i in iplist for i in product_idc_list]):
    Debug = False
    config = ProductionConfig_IDC()
elif any([i in iplist for i in product_180_list]):
    Debug = False
    config = ProductionConfig_180()
elif any([i in iplist for i in debug_170_iplist]):
    Debug = True
    config = DebugConfig_170()
elif any([i in iplist for i in debug_13_iplist]):
    Debug = True
    config = DebugConfig_13()
else:
    Debug = True
    config = CommonConfig()

# -*- coding:utf-8 -*-

import datetime
from qpython import qconnection
from config import config

from log import logger


def transform_date(int_days):
    begin = datetime.datetime(2000, 1, 1)
    return (begin + datetime.timedelta(days=int_days)).strftime('%Y%m%d')


class KdbQuery(object):
    def __init__(self, host=config.kdb['host'], port=config.kdb['port'],
                 username=config.kdb['user'], password=config.kdb['passwd']):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.connect()

    def __del__(self):
        self.release()

    def reconnect(self):
        try:
            self.release()
        finally:
            return self.connect()

    def release(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def connect(self):
        try:
            self.conn = qconnection.QConnection(host=self.host, port=self.port,
                             username=self.username, password=self.password)
            self.conn.open()
            return self.conn.is_connected()
        except Exception as err:
            return False

    def check(self):
        if self.conn.is_connected():
            return True
        else:
            return False

    def sync_query(self, q_sql):
        data = None
        if self.check():
            data = self.conn.sync(str(q_sql))
        return data

    def async_query(self, q_sql, **kwargs):
        data = None
        if self.check():
            self.conn.async(str(q_sql))
            data = self.conn.receive(**kwargs)
        return data

    def get_main_code(self, date, product, rank=1):
        try:
            q_sql=".gw.asyncexec[(`GetMaincode;%s;`%s;%d); `FuturesBasicInfo]"%\
                   (date, product, rank)
            q_ret = self.async_query(q_sql)
            logger.info('kdb query, sql:%s, ret:%s' % (q_sql, q_ret))
            return str(q_ret[0][0], 'utf-8')
        except Exception as e:
            raise ValueError('query kdb main symbol error.')

    def get_symbol_rank(self, date, symbol):
        try:
            q_sql = """.gw.asyncexec["select first MAINLEVEL from `NEXTDATE  xasc select from MainCon where NEXTDATE>=%s,SYMBOL=`%s";`FuturesBasicInfo]""" % (date, symbol)
            print(q_sql)
            q_ret = self.async_query(q_sql)
            ret = int(q_ret[0][0])
            if ret <= 0:
                raise ValueError('query kdb symbol rank error.')
            return ret
        except Exception as e:
            raise ValueError('query kdb symbol rank error.')

    def get_fmain_code(self, date, product, rank=1):
        try:
            q_sql = """.gw.asyncexec["select from FMainCon30 where date=%s,MAINLEVEL=%s,PRODUCT in `%s";`FuturesBasicInfo]""" % (date, rank, product.upper())
            q_ret = self.async_query(q_sql, pandas=True)
            logger.info('kdb query, sql:%s, ret:%s' % (q_sql, q_ret))
            return str(q_ret['SYMBOL'][0], 'utf-8')
        except Exception as e:
            raise ValueError('query kdb fmain symbol error.')

    def get_all_opmain_code(self, date, product):
        try:
            #q_sql = """.gw.asyncexec["select distinct SYMBOL from OPMainCon where NEXTDATE>=%s,PRODUCT=`%s";`OptionBasicInfo]""" % (date, product.upper())
            if product.upper() == "CP300SZ":
                q_sql = """.gw.asyncexec["select distinct SYMBOL:S_INFO_CODE from ChinaOptionDescription where EXCHANGE in `SSE`SZSE,S_INFO_LASTTRADINGDATE>=%s,UNDERLYING=`159919";`OptionBasicInfo]""" % date
            elif product.upper() == "CP300SH":
                q_sql = """.gw.asyncexec["select distinct SYMBOL:S_INFO_CODE from ChinaOptionDescription where EXCHANGE in `SSE`SZSE,S_INFO_LASTTRADINGDATE>=%s,UNDERLYING=`510300";`OptionBasicInfo]""" % date
            elif product.upper() == "CP50ETF":
                q_sql = """.gw.asyncexec["select distinct SYMBOL:S_INFO_CODE from ChinaOptionDescription where EXCHANGE in `SSE`SZSE,S_INFO_LASTTRADINGDATE>=%s,UNDERLYING=`510050";`OptionBasicInfo]""" % date
            else:
                raise ValueError('query kdb opmain symbol error.')
            q_ret = self.async_query(q_sql, pandas=True)
            logger.info('kdb query, sql:%s, ret:%s' % (q_sql, q_ret))
            #return ['SH' + str(s, 'utf-8') for s in q_ret['SYMBOL']]
            return [str(s, 'utf-8') for s in q_ret['SYMBOL']]
        except Exception as e:
            raise ValueError('query kdb opmain symbol error.')

    def get_opmain_code(self, date, product, rank):
        try:
            q_sql = """.gw.asyncexec["select first SYMBOL from OPMainCon where NEXTDATE>=%s,MAINLEVEL=%s,PRODUCT=`%s";`OptionBasicInfo]""" % (date, rank, product.upper())
            q_ret = self.async_query(q_sql, pandas=True)
            logger.info('kdb query, sql:%s, ret:%s' % (q_sql, q_ret))
            return str(q_ret['SYMBOL'][0], 'utf-8')
        except Exception as e:
            raise ValueError('query kdb opmain symbol error.')

    def get_option_rank(self, date, symbol):
        try:
            q_sql = """.gw.asyncexec["select first MAINLEVEL from OPMainCon where NEXTDATE>=%s,SYMBOL=`%s";`OptionBasicInfo]""" % (date, symbol)
            q_ret = self.async_query(q_sql, pandas=True)
            ret = int(q_ret['MAINLEVEL'][0])
            if ret <= 0:
                raise ValueError('query kdb option symbol rank error.')
            return ret
        except Exception as e:
            raise ValueError('query kdb option symbol rank error.')

    def get_cb_rank(self, trading_date, symbol):
        trading_date = parse(trading_date).strftime('%Y.%m.%d')
        try:
            q_sql = """.gw.asyncexec["select first MAINLEVEL from EquityMainCon where NEXTDATE>=%s,SYMBOL=`%s";`EquityFactor]""" % (trading_date, symbol)
            q_ret = self.async_query(q_sql, pandas=True)
            ret = int(q_ret['MAINLEVEL'][0])
            if ret <= 0:
                raise ValueError('query kdb option symbol rank error.')
            return ret 
        except Exception as e:
            raise ValueError('query kdb option symbol rank error.')

    def get_cb_code(self, date, product, rank):
        try:
            q_sql = """.gw.asyncexec["select from EquityMainCon where NEXTDATE>=%s,MAINLEVEL=%s,PRODUCT=`%s";`EquityFactor]""" % (date, rank, product.upper())
            q_ret = self.async_query(q_sql, pandas=True)
            logger.info('kdb query, sql:%s, ret:%s' % (q_sql, q_ret))
            return str(q_ret['SYMBOL'][0], 'utf-8')
        except Exception as e:
            raise ValueError('query kdb opmain symbol error.')

    def get_symbol_sellteprice(self, date, symbol):
        q_sql = '.gw.asyncexec["select from CFuturesEODPrices where TRADE_DT=%s, (lower SYMBOL)=`%s";`FuturesBasicInfo]' % (
            date, symbol)
        q_ret = self.async_query(q_sql, pandas=True)
        return float(q_ret['SETTLEPRICE'])

    def get_trading_date(self, hour=18, calendar_date=None, calendar_hour=None):
        now = datetime.datetime.now()
        if not calendar_date:
            calendar_date = now.strftime('%Y%m%d')
        now_hour = now.hour
        if calendar_hour:
            now_hour = int(calendar_hour)
        q_sql = """.gw.asyncexec["select TRADE_DT from Calendar where EXCHANGE=`SSE, TRADE_DT>=2017.01.01";`FuturesBasicInfo]"""
        ret = self.async_query(q_sql)
        dates = [r[0] for r in ret]
        for d in sorted(dates):
            d = transform_date(int(d))
            if now_hour >= hour:
                if d > calendar_date:
                    return d
            else:
                if d >= calendar_date:
                    return d
        raise ValueError('get trading date error')

    def get_nebor_trading_date(self, trading_date):
        trading_date = parse(trading_date)
        begin_date = (trading_date - datetime.timedelta(days=100)).strftime('%Y.%m.%d')
        q_sql = """.gw.asyncexec["select TRADE_DT from Calendar where EXCHANGE=`SSE, TRADE_DT>=%s";`FuturesBasicInfo]""" % begin_date
        ret = self.async_query(q_sql)
        dates = sorted([r[0] for r in ret])
        for index, d in enumerate(dates):
            d = transform_date(int(d))
            if d == trading_date.strftime('%Y%m%d'):
                return {
                    'prev': transform_date(int(dates[index - 1])),
                    'next': transform_date(int(dates[index + 1]))
                }
        raise ValueError('get trading date error')

    def get_symbol_unit(self, symbol):
        symbol = symbol.upper()
        q_sql = '.gw.asyncexec["select from CFuturescontpro where SYMBOL=upper `%s";`FuturesBasicInfo]' % symbol
        q_ret = self.async_query(q_sql, pandas=True)
        return q_ret.iloc[0]

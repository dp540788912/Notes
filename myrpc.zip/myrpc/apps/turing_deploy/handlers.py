#-*- coding: utf-8 -*-

import json
import os
import requests
import csv
import time
import datetime
import glob
import uuid
import copy
import tornado.ioloop
import tornado.web
import tornado.httpclient
import xml.etree.ElementTree as et
from dateutil.parser import parse

from tornado import gen
from tornado.concurrent import run_on_executor
from concurrent.futures import ThreadPoolExecutor
from db import Session, session_context as mysql_sc
from kdb_api import KdbQuery
from models import *
from utils import *
from config import config
from mail import Notification
from modelsettings import generate_modelsettings


class BaseHandler(tornado.web.RequestHandler):

    def initialize(self, *args, **kwargs):
        self.model = None
        self.fields = {}    # key: model-key, value: payload-key
        self.no_login = []

    def prepare(self, *args, **kwargs):
        if hasattr(self, 'no_login') and self.request.method.lower() in self.no_login:
            self.current_user = {}
            return
        if self.request.headers.get('whitelist'):
            self.current_user = {
                'id': 999999,
                'username': self.request.headers['whitelist'],
                'nickname': self.request.headers['whitelist'],
            }
        else:
            sessionid = self.get_cookie('sessionid')
            if not sessionid:
                self.write(json.dumps({
                    'code': 401,
                    'error': 'Sessionid not found.'
                }))
                self.finish()
                return
            cookies = {
                'sessionid': sessionid,
            }
            res = check_redis_session(config.redis, sessionid)
            if not res:
                self.write(json.dumps({
                    'code': 401,
                    'error': 'User not login.',
                }))
                self.finish()
                return
            self.current_user = res

    def get(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def post(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def put(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def delete(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))


class ListHandler(BaseHandler):

    def get(self, *args, **kwargs):
        res = []
        with mysql_sc() as sc:
            lines = sc.query(self.model).all()
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if sorted(payload.keys()) != sorted(self.fields.values()):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            data = {}
            for k, v in self.fields.items():
                data[k] = payload[v]
            with mysql_sc() as sc:
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class IDHandler(BaseHandler):

    def get(self, *args, **kwargs):
        with mysql_sc() as sc:
            o = sc.query(self.model).filter_by(id=kwargs['id']).first()
            if o:
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
            else:
                self.write(json.dumps({
                    'code': 404,
                    'error': 'Data not found.',
                }))

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    for k, v in self.fields.items():
                        if v in payload:
                            setattr(o, k, payload[v])
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                sc.query(self.model).filter_by(id=kwargs['id']).delete()
                self.write(json.dumps({
                    'code': 0,
                    'data': 1,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class UsersListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = Users
        self.fields = {
            'name': 'name',
            'password': 'password',
        }


class UsersDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = Users
        self.fields = {
            'name': 'name',
            'password': 'password',
        }


class ExchangesListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = Exchanges
        self.fields = {
            'name': 'name',
            'code': 'code',
        }


class ExchangesDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = Exchanges
        self.fields = {
            'name': 'name',
            'code': 'code',
        }


class BrokersListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = Brokers
        self.fields = {
            'name': 'name',
        }
        self.no_login = ['get']


class BrokersDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = Brokers
        self.fields = {
            'name': 'name',
        }


class CountersListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = Counters
        self.fields = {
            'name': 'name',
            'exchange_id': 'exchange_id',
            'broker_id': 'broker_id',
        }


class CountersDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = Counters
        self.fields = {
            'name': 'name',
            'exchange_id': 'exchange_id',
            'broker_id': 'broker_id',
        }


class AlphaMixerListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = AlphaMixer
        self.fields = {
            'strat': 'strategy_name',
            'sub_strat': 'sub_strategy_name',
            'series': 'series',
        }
        self.no_login = ['get']

    def get(self, *args, **kwargs):
        res = []
        st_dict = {}
        with mysql_sc() as sc:
            lines = sc.query(self.model)
            for line in lines:
                strat = line.strat
                sub_strat = line.sub_strat
                series = line.series
                st_dict.setdefault(strat, {})
                st_dict[strat].setdefault(series, [])
                st_dict[strat][series].append({
                    'id': line.id,
                    'sub_strategy_name': line.sub_strat,
                })
        for strat, series_dict in st_dict.items():
            data = {
                'strategy_name': strat,
                'series': []
            }
            for series, sub_strat_list in series_dict.items():
                data['series'].append({
                    'series_name': series,
                    'sub_strategy': sub_strat_list,
                })
            res.append(data)
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if sorted(payload.keys()) != sorted(self.fields.values()):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            data = {}
            strategy_name = payload['strategy_name']
            series = payload['series']
            sub_strat_list = payload['sub_strategy_name'].split(',')
            for sub_strategy_name in sub_strat_list:
                data = {
                    'strat': strategy_name,
                    'sub_strat': sub_strategy_name,
                    'series': series,
                }
                with mysql_sc() as sc:
                    o = self.model(**data)
                    sc.add(o)
                    sc.commit()
            self.write(json.dumps({
                'code': 0,
                'data': {},
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class AlphaMixerDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = AlphaMixer
        self.fields = {
            'strat': 'strategy_name',
            'sub_strat': 'sub_strategy_name',
            'series': 'series',
        }
        self.no_login = ['get']


class DIMDiffListHandler(ListHandler):

    def get(self, *args, **kwargs):
        today = datetime.datetime.now().strftime('%Y%m%d')
        d = os.path.join(config.dim['mnt_path'], today)
        if not os.path.exists(d):
            self.write(json.dumps({
                'code': 0,
                'data': {},
            }))
            return
        data = {
            'product': {
                'day': [],
                'night': [],
            },
            'test': {
                'day': [],
                'night': [],
            }
        }
        self.fill_diff_data(data, d, 1, 0)
        self.fill_diff_data(data, d, 1, 1)
        self.fill_diff_data(data, d, 2, 0)
        self.fill_diff_data(data, d, 2, 1)

        self.write(json.dumps({
            'code': 0,
            'data': data,
        }))

    def fill_diff_data(self, data, d, category, day_night):
        if category == 1 and day_night == 0:
            dim_para_file_re = glob.glob(os.path.join(d, 'day_vol*.csv'))
            dist = 0
            _type = 'product'
            daynight = 'day'
        elif category == 1 and day_night == 1:
            dim_para_file_re = glob.glob(os.path.join(d, 'night_vol*.csv'))
            dist = 0
            _type = 'product'
            daynight = 'night'
        elif category == 2 and day_night == 0:
            dim_para_file_re = glob.glob(os.path.join(d, 'test', 'day_vol*.csv'))
            dist = 10
            _type = 'test'
            daynight = 'day'
        elif category == 2 and day_night == 1:
            dim_para_file_re = glob.glob(os.path.join(d, 'test', 'night_vol*.csv'))
            dist = 10
            _type = 'test'
            daynight = 'night'
        else:
            return False

        pre_details = {}
        with mysql_sc() as sc:
            o = sc.query(DIMPreConfs).filter(
                DIMPreConfs.type == category,
                DIMPreConfs.day_night == day_night,
            ).order_by(
                DIMPreConfs.id.desc()
            ).first()
            if o:
                lines = sc.query(DIMPreConfs).filter(
                    DIMPreConfs.type == category,
                    DIMPreConfs.day_night == day_night,
                    DIMPreConfs.uid == o.uid,
                ).order_by(
                    DIMPreConfs.alphamixer.asc(),
                )
                for line in lines:
                    pre_details.setdefault(line.alphamixer, [])
                    pre_details[line.alphamixer].append({
                        'strategy': line.strategy,
                        'product': line.product,
                        'symbol': line.symbol,
                        'max_vol': line.max_vol,
                        'limit_vol': line.limit_vol,
                        'single_max_vol': line.single_max_vol,
                        'ev_dim': line.ev_dim,
                        'ev_data': line.ev_data,
                    })

        cur_details = {}
        if len(dim_para_file_re) >= 1:
            for dim_para_file in dim_para_file_re:
                with open(dim_para_file, 'r') as f:
                    reader = csv.DictReader(f)
                    for line in reader:
                        if int(line['day_night']) != day_night:
                            continue
                        cur_details.setdefault(line['alphamixer'], [])
                        cur_details[line['alphamixer']].append({
                            'strategy': line['strategy'],
                            'product': line['product'],
                            'symbol': line.get('symbol', 'R1'),
                            'max_vol': line['max_vol'],
                            'limit_vol': line['limit_vol'],
                            'single_max_vol': line['single_max_vol'],
                            'ev_dim': line['ev_dim'],
                            'ev_data': line['ev_data'],
                        })
        else:
            if not pre_details:
                return False
            cur_details = pre_details

        res = {}
        for alphamixer, cur in cur_details.items():
            res.setdefault(alphamixer, {
                'strategy_name': alphamixer,
                'strategy_diff': -1,
                'para_diff': -1,
                'series': [],
            })
            if alphamixer not in pre_details:
                strategy_diff = 1
                para_diff = 1
            else:
                pre = pre_details[alphamixer]
                if cmp_details_list(cur, pre):
                    para_diff = 2
                else:
                    para_diff = 3
                if not os.path.exists(os.path.join(d, alphamixer + '.so')):
                    strategy_diff = 2
                else:
                    with mysql_sc() as sc:
                        o = sc.query(DIMFiles).filter(
                            DIMFiles.file_type == 1 + dist,
                            DIMFiles.file_name == alphamixer + '.so',
                        ).order_by(
                            DIMFiles.id.desc()
                        ).first()
                        if not o:
                            strategy_diff = 1
                        else:
                            if not os.path.exists(os.path.join(d, alphamixer + '.so')):
                                strategy_diff = 2
                            else:
                                if o.file_md5 == md5sum(os.path.join(d, alphamixer + '.so')):
                                    strategy_diff = 2
                                else:
                                    strategy_diff = 3
            res[alphamixer]['strategy_diff'] = strategy_diff
            res[alphamixer]['para_diff'] = para_diff
            series_details = {}
            for detail in cur:
                with mysql_sc() as sc:
                    o = sc.query(AlphaMixer).filter(
                        AlphaMixer.sub_strat == detail['strategy'],
                    ).first()
                    if not o:
                        continue
                    series_details.setdefault(o.series, {
                        'ev_dim': detail['ev_dim'],
                        'ev_data': detail['ev_data'],
                    })
            for series, ev_detail in series_details.items():
                evs = []
                if ev_detail.get('ev_dim', ''):
                    with mysql_sc() as sc:
                        o = sc.query(DIMFiles).filter(
                            DIMFiles.file_type == 3 + dist,
                            DIMFiles.file_name == ev_detail['ev_dim'],
                        ).order_by(
                            DIMFiles.id.desc()
                        ).first()
                        if not o:
                            ev_diff = 1
                        else:
                            if not os.path.exists(os.path.join(d, ev_detail['ev_dim'])):
                                ev_diff = 2
                            else:
                                if o.file_md5 == md5sum(os.path.join(d, ev_detail['ev_dim'])):
                                    ev_diff = 2
                                else:
                                    ev_diff = 3
                        evs.append({
                            'ev_name': ev_detail['ev_dim'],
                            'ev_diff': ev_diff,
                        })
                if ev_detail.get('ev_data', ''):
                    with mysql_sc() as sc:
                        o = sc.query(DIMFiles).filter(
                            DIMFiles.file_type == 3 + dist,
                            DIMFiles.file_name == ev_detail['ev_data'],
                        ).order_by(
                            DIMFiles.id.desc()
                        ).first()
                        if not o:
                            ev_diff = 1
                        else:
                            if not os.path.exists(os.path.join(d, ev_detail['ev_data'])):
                                ev_diff = 2
                            else:
                                if o.file_md5 == md5sum(os.path.join(d, ev_detail['ev_data'])):
                                    ev_diff = 2
                                else:
                                    ev_diff = 3
                        evs.append({
                            'ev_name': ev_detail['ev_data'],
                            'ev_diff': ev_diff,
                        })
                res[alphamixer]['series'].append({
                    'series_name': series,
                    'ev': evs,
                })
        for _, v in res.items():
            data[_type][daynight].append(v)


class TuringPreConfDiffListHandler(ListHandler):

    def get(self, *args, **kwargs):
        exchange = self.get_argument('exchange').upper()
        day_night = int(self.get_argument('day_night'))
        today = datetime.datetime.now().strftime('%Y%m%d')
        d = os.path.join(config.dim['mnt_path'], today)
        data = {
            'product': {
                'day': [],
                'night': [],
            },
            'test': {
                'day': [],
                'night': [],
            }
        }
        self.fill_diff_data(data, d, 1, day_night, exchange)
        self.fill_diff_data(data, d, 2, day_night, exchange)

        self.write(json.dumps({
            'code': 0,
            'data': data,
        }))

    def fill_diff_data(self, data, d, category, day_night, exchange):
        if category == 1 and day_night == 0:
            dim_para_file_re = glob.glob(os.path.join(d, 'day_vol*.csv'))
            dist = 0
            _type = 'product'
            daynight = 'day'
        elif category == 1 and day_night == 1:
            dim_para_file_re = glob.glob(os.path.join(d, 'night_vol*.csv'))
            dist = 0
            _type = 'product'
            daynight = 'night'
        elif category == 2 and day_night == 0:
            dim_para_file_re = glob.glob(os.path.join(d, 'test', 'day_vol*.csv'))
            dist = 10
            _type = 'test'
            daynight = 'day'
        elif category == 2 and day_night == 1:
            dim_para_file_re = glob.glob(os.path.join(d, 'test', 'night_vol*.csv'))
            dist = 10
            _type = 'test'
            daynight = 'night'
        else:
            return False

        pre_details = {}
        with mysql_sc() as sc:
            o = sc.query(DIMPreConfs).filter(
                DIMPreConfs.type == category,
                DIMPreConfs.day_night == day_night,
            ).order_by(
                DIMPreConfs.id.desc()
            ).first()
            if o:
                p = sc.query(DIMPreConfs).filter(
                    DIMPreConfs.type == category,
                    DIMPreConfs.day_night == day_night,
                    DIMPreConfs.uid != o.uid,
                ).order_by(
                    DIMPreConfs.id.desc()
                ).first()
                if p:
                    lines = sc.query(DIMPreConfs).filter(
                        DIMPreConfs.type == category,
                        DIMPreConfs.day_night == day_night,
                        DIMPreConfs.exchange == exchange,
                        DIMPreConfs.uid == p.uid,
                    ).order_by(
                        DIMPreConfs.alphamixer.asc(),
                    )
                    for line in lines:
                        pre_details.setdefault(line.alphamixer, [])
                        pre_details[line.alphamixer].append({
                            'strategy': line.strategy,
                            'product': line.product,
                            'symbol': line.symbol,
                            'max_vol': line.max_vol,
                            'limit_vol': line.limit_vol,
                            'single_max_vol': line.single_max_vol,
                            'ev_dim': line.ev_dim,
                            'ev_data': line.ev_data,
                        })

        if len(dim_para_file_re) >= 1:
            pre_details = {}
            with mysql_sc() as sc:
                o = sc.query(DIMPreConfs).filter(
                    DIMPreConfs.type == category,
                    DIMPreConfs.day_night == day_night,
                ).order_by(
                    DIMPreConfs.id.desc()
                ).first()
                if o:
                    p = sc.query(DIMPreConfs).filter(
                        DIMPreConfs.type == category,
                        DIMPreConfs.day_night == day_night,
                        DIMPreConfs.uid != o.uid,
                    ).order_by(
                        DIMPreConfs.id.desc()
                    ).first()
                    if p:
                        lines = sc.query(DIMPreConfs).filter(
                            DIMPreConfs.type == category,
                            DIMPreConfs.day_night == day_night,
                            DIMPreConfs.exchange == exchange,
                            DIMPreConfs.uid == p.uid,
                        ).order_by(
                            DIMPreConfs.alphamixer.asc(),
                        )
                        for line in lines:
                            pre_details.setdefault(line.alphamixer, [])
                            pre_details[line.alphamixer].append({
                                'strategy': line.strategy,
                                'product': line.product,
                                'symbol': line.symbol,
                                'max_vol': line.max_vol,
                                'limit_vol': line.limit_vol,
                                'single_max_vol': line.single_max_vol,
                                'ev_dim': line.ev_dim,
                                'ev_data': line.ev_data,
                            })
            cur_details = {}
            for dim_para_file in dim_para_file_re:
                with open(dim_para_file, 'r') as f:
                    reader = csv.DictReader(f)
                    for line in reader:
                        if int(line['day_night']) != day_night or line['exch'] != exchange:
                            continue
                        cur_details.setdefault(line['alphamixer'], [])
                        cur_details[line['alphamixer']].append({
                            'strategy': line['strategy'],
                            'product': line['product'],
                            'symbol': line.get('symbol', 'R1'),
                            'max_vol': line['max_vol'],
                            'limit_vol': line['limit_vol'],
                            'single_max_vol': line['single_max_vol'],
                            'ev_dim': line['ev_dim'],
                            'ev_data': line['ev_data'],
                        })
        else:
            pre_details = {}
            with mysql_sc() as sc:
                p = sc.query(DIMPreConfs).filter(
                    DIMPreConfs.type == category,
                    DIMPreConfs.day_night == day_night,
                ).order_by(
                    DIMPreConfs.id.desc()
                ).first()
                if p:
                    lines = sc.query(DIMPreConfs).filter(
                        DIMPreConfs.type == category,
                        DIMPreConfs.day_night == day_night,
                        DIMPreConfs.exchange == exchange,
                        DIMPreConfs.uid == p.uid,
                    ).order_by(
                        DIMPreConfs.alphamixer.asc(),
                    )
                    for line in lines:
                        pre_details.setdefault(line.alphamixer, [])
                        pre_details[line.alphamixer].append({
                            'strategy': line.strategy,
                            'product': line.product,
                            'symbol': line.symbol,
                            'max_vol': line.max_vol,
                            'limit_vol': line.limit_vol,
                            'single_max_vol': line.single_max_vol,
                            'ev_dim': line.ev_dim,
                            'ev_data': line.ev_data,
                        })
            if not pre_details:
                return False
            cur_details = pre_details

        res = {}
        for alphamixer, cur in cur_details.items():
            res.setdefault(alphamixer, {
                'strategy_name': alphamixer,
                'strategy_diff': -1,
                'para_diff': -1,
                'series': [],
            })
            if alphamixer not in pre_details:
                strategy_diff = 1
                para_diff = 1
            else:
                pre = pre_details[alphamixer]
                if cmp_details_list(cur, pre):
                    para_diff = 2
                else:
                    para_diff = 3
                if not os.path.exists(os.path.join(d, alphamixer + '.so')):
                    strategy_diff = 2
                else:
                    with mysql_sc() as sc:
                        objs = sc.query(DIMFiles).filter(
                            DIMFiles.file_type == 1 + dist,
                            DIMFiles.file_name == alphamixer + '.so',
                        ).order_by(
                            DIMFiles.id.desc()
                        ).all()
                        if len(objs) < 2:
                            strategy_diff = 1
                        else:
                            if not os.path.exists(os.path.join(d, alphamixer + '.so')):
                                strategy_diff = 2
                            else:
                                o = objs[1]
                                if o.file_md5 == md5sum(os.path.join(d, alphamixer + '.so')):
                                    strategy_diff = 2
                                else:
                                    strategy_diff = 3
            res[alphamixer]['strategy_diff'] = strategy_diff
            res[alphamixer]['para_diff'] = para_diff
            series_details = {}
            for detail in cur:
                with mysql_sc() as sc:
                    o = sc.query(AlphaMixer).filter(
                        AlphaMixer.sub_strat == detail['strategy'],
                    ).first()
                    if not o:
                        continue
                    series_details.setdefault(o.series, {
                        'ev_dim': detail['ev_dim'],
                        'ev_data': detail['ev_data'],
                    })
            for series, ev_detail in series_details.items():
                evs = []
                if ev_detail.get('ev_dim', ''):
                    with mysql_sc() as sc:
                        objs = sc.query(DIMFiles).filter(
                            DIMFiles.file_type == 3 + dist,
                            DIMFiles.file_name == ev_detail['ev_dim'],
                        ).order_by(
                            DIMFiles.id.desc()
                        ).all()
                        if len(objs) < 2:
                            ev_diff = 1
                        else:
                            if not os.path.exists(os.path.join(d, ev_detail['ev_dim'])):
                                ev_diff = 2
                            else:
                                o = objs[1]
                                if o.file_md5 == md5sum(os.path.join(d, ev_detail['ev_dim'])):
                                    ev_diff = 2
                                else:
                                    ev_diff = 3
                        evs.append({
                            'ev_name': ev_detail['ev_dim'],
                            'ev_diff': ev_diff,
                        })
                if ev_detail.get('ev_data', ''):
                    with mysql_sc() as sc:
                        objs = sc.query(DIMFiles).filter(
                            DIMFiles.file_type == 3 + dist,
                            DIMFiles.file_name == ev_detail['ev_data'],
                        ).order_by(
                            DIMFiles.id.desc()
                        ).all()
                        if len(objs) < 2:
                            ev_diff = 1
                        else:
                            if not os.path.exists(os.path.join(d, ev_detail['ev_data'])):
                                ev_diff = 2
                            else:
                                o = objs[1]
                                if o.file_md5 == md5sum(os.path.join(d, ev_detail['ev_data'])):
                                    ev_diff = 2
                                else:
                                    ev_diff = 3
                        evs.append({
                            'ev_name': ev_detail['ev_data'],
                            'ev_diff': ev_diff,
                        })
                res[alphamixer]['series'].append({
                    'series_name': series,
                    'ev': evs,
                })
        for _, v in res.items():
            data[_type][daynight].append(v)


class DIMFilesListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = DIMFiles

    def get(self, *args, **kwargs):
        res = {
            'product': {},
            'test': {},
        }
        file_diff = {
            'product': {},
            'test': {}
        }
        today = datetime.datetime.now().strftime('%Y%m%d')
        d = os.path.join(config.dim['mnt_path'], today)
        if not os.path.exists(d):
            self.write(json.dumps({
                'code': 0,
                'data': {},
            }))
            return

        self.check_files_md5(file_diff, d, 1)     # check product strategy file
        self.check_files_md5(file_diff, d, 2)     # check product config file
        self.check_files_md5(file_diff, d, 3)     # check product ev file
        self.check_files_md5(file_diff, d, 11)    # check test strategy file
        self.check_files_md5(file_diff, d, 12)    # check test config file
        self.check_files_md5(file_diff, d, 13)    # check test ev file

        if (len(glob.glob(os.path.join(d, 'day_vol*.csv'))) == 0) and \
           (len(glob.glob(os.path.join(d, 'night_vol*.csv')) == 0)) and \
           (len(glob.glob(os.path.join(d, 'test', 'day_vol*.csv')) == 0)) and \
           (len(glob.glob(os.path.join(d, 'test', 'night_vol*.csv')) == 0)):
            # para not changed
            self.fill_pre_diff_res(res, file_diff)

        else:
            self.fill_diff_res(res, file_diff, glob.glob(os.path.join(d, 'day_vol*.csv')), 'product')             # check product day config
            self.fill_diff_res(res, file_diff, glob.glob(os.path.join(d, 'night_vol*.csv')), 'product')           # check product night config
            self.fill_diff_res(res, file_diff, glob.glob(os.path.join(d, 'test', 'day_vol*.csv')), 'test')     # check test day config
            self.fill_diff_res(res, file_diff, glob.glob(os.path.join(d, 'test', 'night_vol*.csv')), 'test')   # check test night config

        self.write(json.dumps({
            'code': 0,
            'data': res,
        }))

    def fill_pre_diff_res(self, res, file_diff):
        res_dict = {}
        for t, diff_dict in file_diff.items():
            _type = 1 if t == 'product' else 2
            res_dict.setdefault(t, {})
            for file_name, diff in diff_dict.items():
                if file_name.endswith('.so'):
                    alphamixer = os.path.splitext(file_name)[0]
                    with mysql_sc() as sc:
                        p = sc.query(DIMPreConfs).filter(
                            DIMPreConfs.alphamixer == alphamixer,
                            DIMPreConfs.type == _type,
                        ).order_by(DIMPreConfs.id.desc()).first()
                        if not p:
                            continue
                        uid = p.uid
                        lines = sc.query(DIMPreConfs).filter(
                            DIMPreConfs.alphamixer == alphamixer,
                            DIMPreConfs.type == _type,
                            DIMPreConfs.uid == uid,
                        )
                        for line in lines:
                            strategy = line.strategy
                            ev_dim = line.ev_dim
                            ev_data = line.ev_data
                            day_night = 'day' if line.day_night == 0 else 'night'
                            o = sc.query(AlphaMixer).filter(
                                AlphaMixer.sub_strat == strategy,
                            ).first()
                            if not o:
                                continue
                            series = o.series
                            res_dict[t].setdefault(day_night, {})
                            res_dict[t][day_night].setdefault(alphamixer, {})
                            res_dict[t][day_night][alphamixer].setdefault(
                                '%s_%s' % (alphamixer, series),
                                {
                                    'strategy': strategy,
                                    'alphamixer': alphamixer,
                                    'ev_dim': ev_dim,
                                    'ev_data': ev_data,
                                }
                            )
                elif file_name.endswith('.txt'):
                    with mysql_sc() as sc:
                        p = sc.query(DIMPreConfs).filter(
                            or_(DIMPreConfs.ev_dim == file_name,
                                DIMPreConfs.ev_data == file_name),
                            DIMPreConfs.type == _type,
                        ).order_by(DIMPreConfs.id.desc()).first()
                        if not p:
                            continue
                        uid = p.uid
                        lines = sc.query(DIMPreConfs).filter(
                            or_(DIMPreConfs.ev_dim == file_name,
                                DIMPreConfs.ev_data == file_name),
                            DIMPreConfs.type == _type,
                            DIMPreConfs.uid == uid,
                        )
                        for line in lines:
                            alphamixer = line.alphamixer
                            strategy = line.strategy
                            ev_dim = line.ev_dim
                            ev_data = line.ev_data
                            day_night = 'day' if line.day_night == 0 else 'night'
                            o = sc.query(AlphaMixer).filter(
                                AlphaMixer.sub_strat == strategy,
                            ).first()
                            if not o:
                                continue
                            series = o.series
                            res_dict[t].setdefault(day_night, {})
                            res_dict[t][day_night].setdefault(alphamixer, {})
                            res_dict[t][day_night][alphamixer].setdefault(
                                '%s_%s' % (alphamixer, series),
                                {
                                    'strategy': strategy,
                                    'alphamixer': alphamixer,
                                    'ev_dim': ev_dim,
                                    'ev_data': ev_data,
                                }
                            )

        for _type, t_dict in res_dict.items():
            alpha_dict = t_dict.get(day_night, {})
            data_list = []
            for alphamixer, series_dict, in alpha_dict.items():
                data = {
                    'strategy_name': alphamixer,
                    'strategy_diff': file_diff[_type].get(alphamixer + '.so', 2),
                    'para_diff': 2,
                    'series': [],
                }
                for k, v in series_dict.items():
                    series = k.split('_')[-1]
                    ev = []
                    if v.get('ev_dim', ''):
                        ev.append({
                            'ev_name': v['ev_dim'],
                            'ev_diff': file_diff[_type].get(v['ev_dim'], 2),
                        })
                    if v.get('ev_data', ''):
                        ev.append({
                            'ev_name': v['ev_data'],
                            'ev_diff': file_diff[_type].get(v['ev_data'], 2),
                        })
                    data['series'].append({
                        'series_name': series,
                        'ev': ev,
                    })
                data_list.append(data)
            res[_type][day_night] = data_list
            if day_night == 'day':
                res[_type].setdefault('night', [])
            else:
                res[_type].setdefault('day', [])

    def fill_diff_res(self, res, file_diff, config_file_re, d_type):
        if len(config_file_re) == 0:
            return False

        alpha_dict = {}
        data_list = []
        for config_file in config_file_re:
            config_name = os.path.basename(config_file)

            with open(config_file, 'r') as f:
                reader = csv.DictReader(f)
                for line in reader:
                    alphamixer = line['alphamixer']
                    strategy = line['strategy']
                    ev_dim = line['ev_dim']
                    ev_data = line['ev_data']
                    with mysql_sc() as sc:
                        o = sc.query(AlphaMixer).filter(
                            AlphaMixer.strat == alphamixer,
                            AlphaMixer.sub_strat == strategy,
                        ).first()
                        if not o:
                            continue
                        series = o.series
                        alpha_dict.setdefault(alphamixer, {})
                        alpha_dict[alphamixer].setdefault(
                            '%s_%s' % (alphamixer, series),
                            {
                                'strategy': strategy,
                                'alphamixer': alphamixer,
                                'ev_dim': ev_dim,
                                'ev_data': ev_data,
                            }
                        )
        for alphamixer, series_dict, in alpha_dict.items():
            data = {
                'strategy_name': alphamixer,
                'strategy_diff': file_diff[d_type].get(alphamixer + '.so', 2),
                'para_diff': file_diff[d_type].get(config_name, 2),
                'series': [],
            }
            for k, v in series_dict.items():
                series = k.split('_')[-1]
                ev = []
                if v.get('ev_dim', ''):
                    ev.append({
                        'ev_name': v['ev_dim'],
                        'ev_diff': file_diff[d_type].get(v['ev_dim'], 2),
                    })
                if v.get('ev_data', ''):
                    ev.append({
                        'ev_name': v['ev_data'],
                        'ev_diff': file_diff[d_type].get(v['ev_data'], 2),
                    })
                data['series'].append({
                    'series_name': series,
                    'ev': ev,
                })
            data_list.append(data)

        if config_name.startswith('day_vol'):
            res[d_type]['day'] = data_list
        elif config_name.startswith('night_vol'):
            res[d_type]['night'] = data_list
        else:
            return False

    def check_files_md5(self, file_diff, d, file_type):
        if file_type == 1:
            file_list = glob.glob(os.path.join(d, '*.so'))
            _type = 'product'
        elif file_type == 2:
            file_list = glob.glob(os.path.join(d, '*.csv'))
            _type = 'product'
        elif file_type == 3:
            file_list = glob.glob(os.path.join(d, '*.txt'))
            _type = 'product'
        elif file_type == 11:
            file_list = glob.glob(os.path.join(d, 'test', '*.so'))
            _type = 'test'
        elif file_type == 12:
            file_list = glob.glob(os.path.join(d, 'test', '*.csv'))
            _type = 'test'
        elif file_type == 13:
            file_list = glob.glob(os.path.join(d, 'test', '*.txt'))
            _type = 'test'
        else:
            file_list = []
        for f in file_list:
            file_name = os.path.basename(f)
            file_md5 = md5sum(f)
            with mysql_sc() as sc:
                o = sc.query(self.model).filter(
                    self.model.valid == True,
                    self.model.file_type == file_type,
                    self.model.file_name == file_name,
                ).order_by(
                    self.model.id.desc()
                ).first()
                if not o:
                    diff = 1
                else:
                    if o.file_md5 == file_md5:
                        diff = 2
                    else:
                        diff = 3
                file_diff[_type][file_name] = diff


class DIMParasListHandler_V2(ListHandler):

    def get(self, *args, **kwargs):
        res = {
            'product': [],
            'test': [],
        }
        today = datetime.datetime.now().strftime('%Y%m%d')
        d = os.path.join(config.dim['mnt_path'], today)
        if not os.path.exists(d):
            self.write(json.dumps({
                'code': 0,
                'data': {},
            }))
            return

        self.fill_para_res(res, glob.glob(os.path.join(d, 'day_vol*.csv')), 0, 1)
        self.fill_para_res(res, glob.glob(os.path.join(d, 'night_vol*.csv')), 0, 1)
        self.fill_para_res(res, glob.glob(os.path.join(d, 'test', 'day_vol*.csv')), 1, 2)
        self.fill_para_res(res, glob.glob(os.path.join(d, 'test', 'night_vol*.csv')), 1, 2)

        self.write(json.dumps({
            'code': 0,
            'data': res,
        }))

    def fill_para_res(self, res, config_file_re, day_night, d_type):
        _type = 'product' if d_type == 1 else 'test'
        cur_para = {}
        for config_file in config_file_re:
            with open(config_file, 'r') as f:
                reader = csv.DictReader(f)
                for line in reader:
                    v = {
                        'internal_date': line['internal_date'],
                        'day_night': line['day_night'],
                        'exch': line['exch'],
                        'product': line['product'],
                        'symbol': line.get('symbol', 'R1'),
                        'alphamixer': line['alphamixer'],
                        'strategy': line['strategy'],
                        'max_vol': line['max_vol'],
                        'limit_vol': line['limit_vol'],
                        'single_max_vol': line['single_max_vol'],
                        'ev_dim': line['ev_dim'],
                        'ev_data': line['ev_data'],
                        'account': line['account'] or '',
                        'fake_account': line.get('fake_account', ''),
                        'account_id': line.get('account_id', ''),
                        #'tunnel_id': line.get('tunnel_id', ''),
                        'quote_lv': line.get('quote_lv', ''),
                    }
                    k = '%s_%s_%s_%s_%s_%s_%s' % (line['day_night'], line['exch'], line['product'],
                                                  line['symbol'], line['alphamixer'], line['strategy'],
                                                  line['account'] or '')
                    cur_para[k] = v

        pre_para = {}
        with mysql_sc() as sc:
            o = sc.query(DIMPreConfs).filter(
                DIMPreConfs.day_night == day_night,
                DIMPreConfs.type == d_type,
            ).order_by(DIMPreConfs.id.desc()).first()
            if o:
                lines = sc.query(DIMPreConfs).filter(
                    DIMPreConfs.uid == o.uid,
                    DIMPreConfs.day_night == day_night,
                    DIMPreConfs.type == d_type,
                )
                for line in lines:
                    v = {
                        'internal_date': line.internal_date,
                        'day_night': line.day_night,
                        'exch': line.exchange,
                        'product': line.product,
                        'symbol': line.symbol,
                        'alphamixer': line.alphamixer,
                        'strategy': line.strategy,
                        'max_vol': line.max_vol,
                        'limit_vol': line.limit_vol,
                        'single_max_vol': line.single_max_vol,
                        'ev_dim': line.ev_dim,
                        'ev_data': line.ev_data,
                        'account': line.account or '',
                        'fake_account': line.fake_account or '',
                        'account_id': '' if line.account_id is None else line.account_id,
                        #'tunnel_id': line.tunnel_id or '',
                        'quote_lv': '' if line.quote_lv is None else line.quote_lv,
                    }
                    k = '%s_%s_%s_%s_%s_%s_%s' % (line.day_night, line.exchange, line.product,
                                                  line.symbol, line.alphamixer, line.strategy,
                                                  line.account or '')
                    pre_para[k] = v

        for k, v in cur_para.items():
            if k not in pre_para:
                v['changed'] = {
                    'red': ['day_night', 'exch', 'product', 'symbol', 'alphamixer', 'strategy',
                            'max_vol', 'limit_vol', 'single_max_vol', 'ev_dim', 'ev_data', 'account',
                            'account_id', 'quote_lv'],
                }
            else:
                v['changed'] = {
                    'red': []
                }
                pre_v = pre_para[k]
                for _k, _v in v.items():
                    if _k == 'internal_date' or _k == 'changed':
                        continue
                    if str(_v) != str(pre_v[_k]):
                        v['changed']['red'].append(_k)
            res[_type].append(v)


class DimRequestListHandler_V2(ListHandler, Notification):

    def initialize(self, *args, **kwargs):
        self.no_login = ['post']

    @gen.coroutine
    def post(self, *args, **kwargs):
        uid = str(uuid.uuid1())
        today = datetime.datetime.now().strftime('%Y%m%d')
        d = os.path.join(config.dim['mnt_path'], today)
        if not os.path.exists(d):
            self.write(json.dumps({
                'code': 404,
                'error': 'No new data',
            }))
            return

        self.create_dim_models(os.path.join(d, '*.so'), 1, today)
        self.create_dim_models(os.path.join(d, '*.csv'), 2, today)
        self.create_dim_models(os.path.join(d, '*.txt'), 3, today)
        self.create_dim_models(os.path.join(d, 'test', '*.so'), 11, today)
        self.create_dim_models(os.path.join(d, 'test', '*.csv'), 12, today)
        self.create_dim_models(os.path.join(d, 'test', '*.txt'), 13, today)

        dupl = self.check_pre_confs(os.path.join(d, '*.csv'))
        if len(dupl) > 0:
            self.write(json.dumps({
                'code': -1,
                'error': 'data duplication: %s' % dupl,
            }))
            return
        dupl = self.check_pre_confs(os.path.join(d, 'test', '*.csv'))
        if len(dupl) > 0:
            self.write(json.dumps({
                'code': -1,
                'error': 'data duplication: %s' % dupl,
            }))
            return

        self.create_pre_confs(os.path.join(d, '*.csv'), 2, uid)
        self.create_pre_confs(os.path.join(d, 'test', '*.csv'), 12, uid)

        self.transfer_v_account_id(uid)

        header = ['day_night', 'exch', 'product', 'symbol', 'alphamixer', 'strategy', 'max_vol', 'single_max_vol', 'account', 'ev_dim', 'account_id', 'quote_lv']
        add_res, modify_res, del_res = [], [], []
        self.check_changed(add_res, modify_res, del_res, uid, 1, header)
        self.check_changed(add_res, modify_res, del_res, uid, 2, header)

        self.send_dim_email(header, add_res, modify_res, del_res)

        yield self.upload_business_event()
        self.write(json.dumps({
            'code': 0,
        }))

    def check_pre_confs(self, config_files):
        ret = []
        check_keys = {}
        kdb_obj = KdbQuery()
        now = datetime.datetime.now()
        if now.hour < 19:
            kdb_date = now.strftime('%Y.%m.%d')
        else:
            kdb_date = (now + datetime.timedelta(days=1)).strftime('%Y.%m.%d')

        for config_file in glob.glob(config_files):
            with open(config_file, 'r') as f:
                reader = csv.DictReader(f)
                for line in reader:
                    exchange = line['exch']
                    product = line['product']
                    if exchange.lower() == 'czce':
                        long_product = 'zz%s' % product.lower()
                    elif exchange.lower() == 'dce':
                        long_product = 'dl%s' % product.lower()
                    elif exchange.lower() == 'shfe':
                        long_product = 'sh%s' % product.lower()
                    else:
                        long_product = product.lower()

                    if line['symbol'] in ['R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9',
                            'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20']:
                        if long_product.upper() in ['CP50ETF', 'CP300ZJ', 'CP300SH', 'CP300SZ']:
                            symbol = kdb_obj.get_opmain_code(kdb_date, long_product, rank=int(line['symbol'].replace('R', '')))
                        elif long_product.upper() in ['CBSZ', 'CBSH']:
                            symbol = kdb_obj.get_cb_code(kdb_date, long_product, rank=int(line['symbol'].replace('R', '')))
                        else:
                            symbol = kdb_obj.get_main_code(kdb_date, long_product, rank=int(line['symbol'].replace('R', '')))
                    else:
                        symbol = line['symbol']
                    k = (line['account'], line.get('account_id', ''), symbol, line['day_night'])
                    if k not in check_keys:
                        check_keys[k] = line['alphamixer']
                    else:
                        if line['alphamixer'] != check_keys[k]:
                            ret.append(k[0])
        return ret

    def transfer_v_account_id(self, uid):
        account_id_set = {}
        account_id_set2 = {}
        with mysql_sc() as sc:
            lines = sc.query(DIMPreConfs).filter(
                DIMPreConfs.uid == uid,
            )
            for line in lines:
                if line.account_id is None or line.account_id == '':
                    continue
                account_id_set.setdefault((line.account, line.day_night), set())
                account_id_set[(line.account, line.day_night)].add(line.account_id)

            for k, v in account_id_set.items():
                account_id_set2[k] = sorted(v)

            for line in lines:
                if line.account_id is None or line.account_id == '':
                    continue
                line.v_account_id = account_id_set2[(line.account, line.day_night)].index(line.account_id)

    @gen.coroutine
    def send_dim_email(self, header, add_res, modify_res, del_res):
        msg = "较上次改动如下:\n\n"
        msg += "新增部分:\n"
        if add_res:
            msg += "|".join(header)
            msg += "\n"
            for l in add_res:
                msg += "|".join(l)
                msg += "\n"
        msg += "\n"
        msg += "修改部分:\n"
        if modify_res:
            msg += "|".join(header)
            msg += "\n"
            for l in modify_res:
                msg += "|".join(l)
                msg += "\n"
        msg += "\n"
        msg += "删除部分:\n"
        if del_res:
            msg += "|".join(header)
            msg += "\n"
            for l in del_res:
                msg += "|".join(l)
                msg += "\n"
        msg += "\n"

        logger.info('send dim email, turing config update.')
        tornado.ioloop.IOLoop.instance().add_callback(
            self.async_send_mail,
            subject=u'图灵实盘更新_%s' % datetime.datetime.now().strftime('%Y%m%d'),
            msg=msg,
            email_list=[
                'weizhenyu@mycapital.net',
                'luoyang@mycapital.net',
                'sandy@mycapital.net',
                'zifan.guo@mycapital.net',
                'wangdan@mycapital.net',
                'hewenguan@mycapital.net',
                'lishaofeng@mycapital.net',
            ],
        )

    def check_changed(self, add_res, modify_res, del_res, uid, d_type, header):
        pre_para = {}
        with mysql_sc() as sc:
            o = sc.query(DIMPreConfs).filter(
                DIMPreConfs.uid != uid,
            ).order_by(DIMPreConfs.id.desc()).first()
            if o:
                lines = sc.query(DIMPreConfs).filter(
                    DIMPreConfs.uid == o.uid,
                    DIMPreConfs.type == d_type,
                )
                for line in lines:
                    v = {
                        'internal_date': line.internal_date,
                        'day_night': line.day_night,
                        'exch': line.exchange,
                        'product': line.product,
                        'symbol': line.symbol,
                        'alphamixer': line.alphamixer,
                        'strategy': line.strategy,
                        'max_vol': line.max_vol,
                        'limit_vol': line.limit_vol,
                        'single_max_vol': line.single_max_vol,
                        'ev_dim': line.ev_dim,
                        'ev_data': line.ev_data,
                        'account': line.account or '',
                        'fake_account': line.fake_account or '',
                        'account_id': '' if line.account_id is None else line.account_id,
                        #'tunnel_id': line.tunnel_id or '',
                        'quote_lv': '' if line.quote_lv is None else line.quote_lv,
                    }
                    k = '%s_%s_%s_%s_%s_%s_%s' % (line.day_night, line.exchange, line.product,
                                                  line.symbol, line.alphamixer, line.strategy,
                                                  line.account or '')
                    pre_para[k] = v
        cur_para = {}
        with mysql_sc() as sc:
            lines = sc.query(DIMPreConfs).filter(
                DIMPreConfs.uid == uid,
                DIMPreConfs.type == d_type,
            )
            for line in lines:
                v = {
                    'internal_date': line.internal_date,
                    'day_night': line.day_night,
                    'exch': line.exchange,
                    'product': line.product,
                    'symbol': line.symbol,
                    'alphamixer': line.alphamixer,
                    'strategy': line.strategy,
                    'max_vol': line.max_vol,
                    'limit_vol': line.limit_vol,
                    'single_max_vol': line.single_max_vol,
                    'ev_dim': line.ev_dim,
                    'ev_data': line.ev_data,
                    'account': line.account or '',
                    'fake_account': line.fake_account or '',
                    'account_id': '' if line.account_id is None else line.account_id,
                    'quote_lv': '' if line.quote_lv is None else line.quote_lv,
                }
                k = '%s_%s_%s_%s_%s_%s_%s' % (line.day_night, line.exchange, line.product,
                                              line.symbol, line.alphamixer, line.strategy,
                                              line.account or '')
                cur_para[k] = v
        self.diff_dict(add_res, modify_res, del_res, pre_para, cur_para, header)

    def diff_dict(self, add_res, modify_res, del_res, pre_para, cur_para, header):
        k_union = dict(pre_para, **cur_para).keys()
        for k in k_union:
            if k in pre_para and k not in cur_para:
                del_res.append([str(pre_para[k][_k]) for _k in header])
            elif k not in pre_para and k in cur_para:
                add_res.append([str(cur_para[k][_k]) for _k in header])
            else:
                tmp = []
                changed = False
                pre_d = pre_para[k]
                cur_d = cur_para[k]
                for _k in header:
                    if pre_d[_k] == cur_d[_k]:
                        tmp.append(str(pre_d[_k]))
                    else:
                        tmp.append('%s->%s' % (pre_d[_k], cur_d[_k]))
                        changed = True
                if changed:
                    modify_res.append(tmp)
        return True


    @gen.coroutine
    def upload_business_event(self):
        headers = {
            'content-type': 'application/json',
            'whitelist': 'operater',
        }
        data = {
            'event_key': 'update_produce_para',
            'dep': 'dim',
            'clock': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f'),
        }
        try:
            req_url = 'http://127.0.0.1/api/v1/event_handle/business_event/event'
            http_client = tornado.httpclient.AsyncHTTPClient()
            response = yield gen.Task(
                http_client.fetch,
                req_url,
                method='POST',
                headers=headers,
                body=json.dumps(data),
            )
            logger.info('Upload business: resp=%s' % response.body)
        except Exception as e:
            logger.error('Upload business error: %s' % str(e))

    def create_dim_models(self, config_files, file_type, today):
        if file_type < 10:
            _type = 'release'
        else:
            _type = 'test'
        for f in glob.glob(config_files):
            file_name = os.path.basename(f)
            file_md5 = md5sum(f)
            with mysql_sc() as sc:
                data = {
                    'file_type': file_type,
                    'file_path': f.replace(config.dim['mnt_path'] + '/', ''),
                    'file_name': file_name,
                    'file_md5': file_md5,
                    'version': '%s_%s_%s' % (os.path.splitext(file_name)[0], today, _type),
                }
                sc.add(
                    DIMFiles(**data)
                )

    def create_pre_confs(self, config_files, file_type, uid):
        for config_file in glob.glob(config_files):
            with open(config_file, 'r') as f:
                reader = csv.DictReader(f)
                with mysql_sc() as sc:
                    for line in reader:
                        data = {
                            'type': 1 if file_type == 2 else 2,
                            'internal_date': line['internal_date'],
                            'day_night': line['day_night'],
                            'exchange': line['exch'].upper(),
                            'product': line['product'],
                            'symbol': line['symbol'],
                            'alphamixer': line['alphamixer'],
                            'strategy': line['strategy'],
                            'max_vol': line['max_vol'],
                            'limit_vol': line['limit_vol'],
                            'single_max_vol': line['single_max_vol'],
                            'ev_dim': line['ev_dim'],
                            'ev_data': line['ev_data'],
                            'account': line['account'],
                            'fixed': True if line['account'] else False,
                            'uid': uid,
                            'fake_account': line.get('fake_account', ''),
                        }
                        if line.get('account_id', ''):
                            data['account_id'] = line.get('account_id', '')
                        if line.get('quote_lv', ''):
                            data['quote_lv'] = line.get('quote_lv', '')
                        sc.add(
                            DIMPreConfs(**data)
                        )


class DimOnlineStatusHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = DIMFiles
        self.no_login = ['get']

    def get(self, *args, **kwargs):
        status = 0
        with mysql_sc() as sc:
            if sc.query(self.model).filter(
                self.model.r_create_time >= (datetime.datetime.now().strftime('%Y-%m-%d') + ' 00:00:00'),
                self.model.r_create_time <= (datetime.datetime.now().strftime('%Y-%m-%d') + ' 23:59:59'),
            ).all():
                status = 1
        self.write(json.dumps({
            'code': 0,
            'data': {
                'status': status,
            }
        }))


class TuringAccountsListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = Accounts

    def get(self, *args, **kwargs):
        res = []
        with mysql_sc() as sc:
            lines = sc.query(self.model).filter(
                self.model.use_turing == True,
            )
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))


class TuringAccountsDetailHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = Accounts

    def get(self, *args, **kwargs):
        with mysql_sc() as sc:
            o = sc.query(self.model).filter(
                self.model.use_turing == True,
                self.model.id == kwargs['id'],
            ).first()
            if o:
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
            else:
                self.write(json.dumps({
                    'code': 404,
                    'error': 'Data not found.',
                }))


class TuringServersListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringServers
        self.fields = {
            'ip': 'ip',
            'broker_id': 'broker_id',
        }


class TuringServersDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringServers
        self.fields = {
            'ip': 'ip',
            'broker_id': 'broker_id',
        }


class TuringPathsListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringPaths
        self.fields = {
            'name': 'name',
        }


class TuringPathsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringPaths
        self.fields = {
            'name': 'name',
        }


class TuringProgramTypesListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringProgramTypes
        self.fields = {
            'name': 'name',
        }

    def get(self, *args, **kwargs):
        _type = self.get_argument('type', '')
        res = []
        with mysql_sc() as sc:
            lines = []
            if _type == 'agent':
                lines = sc.query(self.model).filter(
                    self.model.name == 'bss_agent',
                )
            elif _type == 'turing':
                lines = sc.query(self.model).filter(
                    self.model.name.like('turing_%'),
                )
            elif _type == 'tool':
                lines = sc.query(self.model).filter(
                    self.model.name.like('quote_%'),
                )
            elif _type == 'platform':
                lines = sc.query(self.model).filter(
                    self.model.name.like('platform_%'),
                )
            elif _type == 'galileo':
                lines = sc.query(self.model).filter(
                    self.model.name.like('galileo_%'),
                )
            else:
                lines = sc.query(self.model)
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))


class TuringProgramTypesDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringProgramTypes
        self.fields = {
            'name': 'name',
        }


class TuringConfigTemplatesListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringConfigTemplates
        self.fields = {
            'name': 'name',
            'content': 'content',
            'program_type_id': 'program_type_id',
        }


class TuringConfigTemplatesDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringConfigTemplates
        self.fields = {
            'name': 'name',
            'content': 'content',
            'program_type_id': 'program_type_id',
        }


class TuringProgramsListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringPrograms
        self.fields = {
            'name': 'name',
            'type_id': 'type_id',
            'version': 'version',
        }

    def get(self, *args, **kwargs):
        program_type_id = int(self.get_argument('program_type_id', 0))
        res = []
        with mysql_sc() as sc:
            lines = []
            if program_type_id > 0:
                lines = sc.query(self.model).filter(
                    self.model.type_id == program_type_id,
                ).order_by(self.model.id.desc())
            else:
                lines = sc.query(self.model).order_by(self.model.id.desc())
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        #TODO: set file path
        self.upload_path = 'files'
        self.trader_file = self.request.files['trader'][0]
        filename = save_file(os.path.join(os.path.dirname(os.path.realpath(__file__)), self.upload_path), self.trader_file)
        if filename is None:
            self.write(json.dumps({
                'code': 501,
                'error': 'Upload files error.',
            }))
            return
        try:
            data = {
                'name': self.get_argument('name'),
                'type_id': self.get_argument('type_id'),
                'version': self.get_argument('version'),
                'filepath': os.path.join(
                    os.path.dirname(os.path.realpath(__file__)),
                    self.upload_path,
                    filename
                ),
            }
            with mysql_sc() as sc:
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class TuringProgramsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringPrograms
        self.fields = {
            'name': 'name',
            'type_id': 'type_id',
            'version': 'version',
        }

    def post(self, *args, **kwargs):
        self.upload_path = 'files'
        #self.trader_file = self.request.files['trader'][0]
        #filename = save_file(os.path.join(os.path.dirname(os.path.realpath(__file__)), self.upload_path), self.trader_file)
        #if filename is None:
        #    self.write(json.dumps({
        #        'code': 501,
        #        'error': 'upload files error.',
        #    }))
        #    return
        try:
            with mysql_sc() as sc:
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    o.name = self.get_argument('name')
                    o.type_id = self.get_argument('type_id')
                    o.version = self.get_argument('version')

                    self.trader_file = self.request.files['trader'][0]
                    filename = save_file(os.path.join(os.path.dirname(os.path.realpath(__file__)), self.upload_path), self.trader_file)
                    if filename is not None:
                        o.filepath = os.path.join(
                            os.path.dirname(os.path.realpath(__file__)),
                            self.upload_path,
                            filename
                        )

                    sc.commit()
                    self.write(json.dumps({
                        'code': 0,
                        'data': o.to_dict(),
                    }))
                else:
                    self.write(json.dumps({
                        'code': 404,
                        'error': 'Data not found,'
                    }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class TuringPreAgentConfsListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringPreAgentConfs
        self.fields = {
            'name': 'name',
            'deploy_path': 'deploy_path',
            'valid': 'valid',
            'server_id': 'server_id',
        }

    def get(self, *args, **kwargs):
        res = []
        server_id = int(self.get_argument('server_id', '0'))
        with mysql_sc() as sc:
            if server_id > 0:
                lines = sc.query(self.model).filter(self.model.server_id == server_id)
            else:
                lines = sc.query(self.model)
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if sorted(payload.keys()) != sorted(self.fields.values()):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            data = {}
            for k, v in self.fields.items():
                data[k] = payload[v]
            with mysql_sc() as sc:
                if payload['valid']:
                    if sc.query(self.model).filter(
                        self.model.server_id == payload['server_id'],
                        self.model.valid == True,
                    ).first():
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Only one available agent.'
                        }))
                        return
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class TuringPreAgentConfsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringPreAgentConfs
        self.fields = {
            'name': 'name',
            'deploy_path': 'deploy_path',
            'valid': 'valid',
            'server_id': 'server_id',
        }

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                if payload['valid']:
                    if sc.query(self.model).filter(
                        self.model.id != kwargs['id'],
                        self.model.server_id == payload['server_id'],
                        self.model.valid == True,
                    ).first():
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Only one available agent.'
                        }))
                        return
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    if payload['valid'] == False or \
                       payload['server_id'] != o.server_id or \
                       payload['deploy_path'] != o.deploy_path:
                        q = sc.query(TuringDeployConfs).join(
                            TuringServers, TuringServers.ip == TuringDeployConfs.host,
                        ).filter(
                            TuringDeployConfs.deploy_path == o.deploy_path,
                            TuringServers.id == o.server_id,
                        ).first()
                        if q:
                            q.valid = False
                        notify_monitor_module(config.redis, "host")
                    for k, v in self.fields.items():
                        if v in payload:
                            setattr(o, k, payload[v])
                    sc.commit()
                    self.write(json.dumps({
                        'code': 0,
                        'data': o.to_dict(),
                    }))
                else:
                    self.write(json.dumps({
                        'code': 404,
                        'error': 'Data not found.',
                    }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                o = sc.query(TuringDeployConfs).join(
                    TuringServers, TuringServers.ip == TuringDeployConfs.host,
                ).join(self.model,
                    self.model.deploy_path == TuringDeployConfs.deploy_path,
                ).filter(
                    self.model.server_id == TuringServers.id,
                    self.model.id == kwargs['id'],
                ).order_by(self.model.id.desc()).first()
                if o:
                    o.valid = False
                sc.query(self.model).filter_by(id=kwargs['id']).delete()
                notify_monitor_module(config.redis, "host")
                self.write(json.dumps({
                    'code': 0,
                    'data': 1,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class TuringPreToolConfsListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringPreToolConfs
        self.fields = {
            'name': 'name',
            'day_night': 'day_night',
            'deploy_path': 'deploy_path',
            'script_cpu_valid': 'script_cpu_valid',
            'script_cpu_bind': 'script_cpu_bind',
            'valid': 'valid',
            'server_id': 'server_id',
            'product_list': 'product_list',
            'config_template_id': 'config_template_id',
        }

    def get(self, *args, **kwargs):
        res = []
        server_id = int(self.get_argument('server_id', '0'))
        with mysql_sc() as sc:
            if server_id > 0:
                lines = sc.query(self.model).filter(self.model.server_id == server_id)
            else:
                lines = sc.query(self.model)
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if 'name' not in payload or \
           'day_night' not in payload or \
           'server_id' not in payload or \
           'deploy_path' not in payload or \
           'valid' not in payload or \
           'script_cpu_valid' not in payload or \
           'product_list' not in payload or \
           'config_template_id' not in payload:
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return

        if payload['script_cpu_valid'] and not payload.get('script_cpu_bind', None):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return

        try:
            req_core = []
            used_core = []
            if payload['script_cpu_valid'] and payload.get('script_cpu_bind', None):
                req_core.append(int(payload['script_cpu_bind']))
            data = {}
            for k, v in self.fields.items():
                if v in payload:
                    if v == 'script_cpu_bind' and not payload['script_cpu_valid']:
                        continue
                    data[k] = payload[v]
            with mysql_sc() as sc:
                objs = sc.query(self.model).filter(
                    self.model.valid == True,
                    self.model.server_id == payload['server_id'],
                    self.model.day_night == payload['day_night'],
                ).all()
                for r in objs:
                    if r.script_cpu_valid and r.script_cpu_bind:
                        used_core.append(r.script_cpu_bind)
                objs = sc.query(TuringPreTraderConfs).filter(
                    TuringPreTraderConfs.valid == True,
                    TuringPreTraderConfs.server_id == payload['server_id'],
                    TuringPreTraderConfs.day_night == payload['day_night'],
                ).all()
                for r in objs:
                    if r.script_cpu_valid and r.script_cpu_bind:
                        used_core.append(r.script_cpu_bind)
                    if r.config_cpu_valid and r.config_cpu_bind:
                        used_core.extend(r.config_cpu_bind.values())
                if set(req_core) & set(used_core):
                    self.write(json.dumps({
                        'code': 400,
                        'error': 'cpu core binded.',
                    }))
                    return
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class TuringPreToolConfsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringPreToolConfs
        self.fields = {
            'name': 'name',
            'day_night': 'day_night',
            'deploy_path': 'deploy_path',
            'script_cpu_valid': 'script_cpu_valid',
            'script_cpu_bind': 'script_cpu_bind',
            'valid': 'valid',
            'server_id': 'server_id',
            'product_list': 'product_list',
            'config_template_id': 'config_template_id',
        }

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))

        if payload['script_cpu_valid'] and not payload.get('script_cpu_bind', None):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return

        try:
            req_core = []
            used_core = []
            if payload['script_cpu_valid'] and payload.get('script_cpu_bind', None):
                req_core.append(int(payload['script_cpu_bind']))
            with mysql_sc() as sc:
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    if payload['valid'] == False or \
                       payload['server_id'] != o.server_id or \
                       payload['deploy_path'] != o.deploy_path or \
                       payload['day_night'] != o.day_night:
                        q = sc.query(TuringDeployConfs).join(
                            TuringServers, TuringServers.ip == TuringDeployConfs.host,
                        ).filter(
                            TuringDeployConfs.deploy_path == o.deploy_path,
                            TuringServers.id == o.server_id,
                        ).first()
                        if q:
                            q.valid = False
                    objs = sc.query(self.model).filter(
                        self.model.id != kwargs['id'],
                        self.model.valid == True,
                        self.model.server_id == payload['server_id'],
                        self.model.day_night == payload['day_night'],
                    ).all()
                    for r in objs:
                        if r.script_cpu_valid and r.script_cpu_bind:
                            used_core.append(r.script_cpu_bind)
                    objs = sc.query(TuringPreTraderConfs).filter(
                        TuringPreTraderConfs.valid == True,
                        TuringPreTraderConfs.server_id == payload['server_id'],
                        TuringPreTraderConfs.day_night == payload['day_night'],
                    ).all()
                    for r in objs:
                        if r.script_cpu_valid and r.script_cpu_bind:
                            used_core.append(r.script_cpu_bind)
                        if r.config_cpu_valid and r.config_cpu_bind:
                            used_core.extend(r.config_cpu_bind.values())
                    if set(req_core) & set(used_core):
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'cpu core binded.',
                        }))
                        return
                    for k, v in self.fields.items():
                        if v in payload:
                            if v == 'script_cpu_bind' and not payload['script_cpu_valid']:
                                continue
                            setattr(o, k, payload[v])
                    sc.commit()
                    self.write(json.dumps({
                        'code': 0,
                        'data': o.to_dict(),
                    }))
                else:
                    self.write(json.dumps({
                        'code': 404,
                        'error': 'Data not found.',
                    }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                o = sc.query(TuringDeployConfs).join(
                    TuringServers, TuringServers.ip == TuringDeployConfs.host,
                ).join(self.model,
                    self.model.deploy_path == TuringDeployConfs.deploy_path,
                ).filter(
                    self.model.server_id == TuringServers.id,
                    self.model.id == kwargs['id'],
                ).order_by(self.model.id.desc()).first()
                if o:
                    o.valid = False
                sc.query(self.model).filter_by(id=kwargs['id']).delete()
                self.write(json.dumps({
                    'code': 0,
                    'data': 1,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class TuringPreTraderConfsListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringPreTraderConfs
        self.fields = {
            'name': 'name',
            'day_night': 'day_night',
            'server_id': 'server_id',
            'deploy_path': 'deploy_path',
            'config_template_id': 'config_template_id',
            'account_id': 'account_id',
            'valid': 'valid',
            'script_cpu_valid': 'script_cpu_valid',
            'script_cpu_bind': 'script_cpu_bind',
            'config_cpu_valid': 'config_cpu_valid',
            'config_cpu_bind': 'config_cpu_bind',
            'local_ip': 'local_ip',
            'local_port': 'local_port',
            'src_mac': 'src_mac',
            'nic': 'nic',
        }

    def get(self, *args, **kwargs):
        res = []
        server_id = int(self.get_argument('server_id', '0'))
        with mysql_sc() as sc:
            if server_id > 0:
                lines = sc.query(self.model).filter(self.model.server_id == server_id)
            else:
                lines = sc.query(self.model)
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if 'name' not in payload or \
           'day_night' not in payload or \
           'server_id' not in payload or \
           'deploy_path' not in payload or \
           'config_template_id' not in payload or \
           'account_id' not in payload or \
           'valid' not in payload or \
           'script_cpu_valid' not in payload or \
           'config_cpu_valid' not in payload or \
           'local_ip' not in payload or \
           'local_port' not in payload or \
           'src_mac' not in payload or \
           'nic' not in payload:
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return

        if (payload['script_cpu_valid'] and not payload.get('script_cpu_bind', None)) or \
           (payload['config_cpu_valid'] and not payload.get('config_cpu_bind', None)):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            req_core = []
            used_core = []
            if payload['script_cpu_valid'] and payload.get('script_cpu_bind', None):
                req_core.append(int(payload['script_cpu_bind']))
            if payload['config_cpu_valid'] and payload.get('config_cpu_bind', None):
                for c in payload['config_cpu_bind'].values():
                    req_core.append(int(c))
            data = {}
            for k, v in self.fields.items():
                if v in payload:
                    if (v == 'script_cpu_bind' and not payload['script_cpu_valid']) or \
                       (v == 'config_cpu_bind' and not payload['config_cpu_valid']):
                        continue
                    if v == 'account_id':
                        data[k] = ','.join([str(a) for a in payload[v]])
                    else:
                        data[k] = payload[v]
            with mysql_sc() as sc:
                objs = sc.query(self.model).filter(
                    self.model.valid == True,
                    self.model.server_id == payload['server_id'],
                    self.model.day_night == payload['day_night'],
                ).all()
                for r in objs:
                    if r.script_cpu_valid and r.script_cpu_bind:
                        used_core.append(r.script_cpu_bind)
                    if r.config_cpu_valid and r.config_cpu_bind:
                        used_core.extend(r.config_cpu_bind.values())
                objs = sc.query(TuringPreToolConfs).filter(
                    TuringPreToolConfs.valid == True,
                    TuringPreToolConfs.server_id == payload['server_id'],
                    TuringPreToolConfs.day_night == payload['day_night'],
                ).all()
                for r in objs:
                    if r.script_cpu_valid and r.script_cpu_bind:
                        used_core.append(r.script_cpu_bind)
                if set(req_core) & set(used_core):
                    self.write(json.dumps({
                        'code': 400,
                        'error': 'cpu core binded.',
                    }))
                    return
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class TuringPreTraderConfsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringPreTraderConfs
        self.fields = {
            'name': 'name',
            'day_night': 'day_night',
            'server_id': 'server_id',
            'deploy_path': 'deploy_path',
            'config_template_id': 'config_template_id',
            'account_id': 'account_id',
            'valid': 'valid',
            'script_cpu_valid': 'script_cpu_valid',
            'script_cpu_bind': 'script_cpu_bind',
            'config_cpu_valid': 'config_cpu_valid',
            'config_cpu_bind': 'config_cpu_bind',
            'local_ip': 'local_ip',
            'local_port': 'local_port',
            'src_mac': 'src_mac',
            'nic': 'nic',
        }

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if (payload['script_cpu_valid'] and not payload.get('script_cpu_bind', None)) or \
           (payload['config_cpu_valid'] and not payload.get('config_cpu_bind', None)):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            req_core = []
            used_core = []
            if payload['script_cpu_valid'] and payload.get('script_cpu_bind', None):
                req_core.append(int(payload['script_cpu_bind']))
            if payload['config_cpu_valid'] and payload.get('config_cpu_bind', None):
                for c in payload['config_cpu_bind'].values():
                    req_core.append(int(c))
            with mysql_sc() as sc:
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    if payload['valid'] == False or \
                       payload['server_id'] != o.server_id or \
                       payload['deploy_path'] != o.deploy_path or \
                       payload['config_template_id'] != o.config_template_id or \
                       ','.join([str(a) for a in payload['account_id']]) != o.account_id or \
                       payload['day_night'] != o.day_night:
                        q = sc.query(TuringDeployConfs).join(
                            TuringServers, TuringServers.ip == TuringDeployConfs.host,
                        ).filter(
                            TuringDeployConfs.deploy_path == o.deploy_path,
                            TuringServers.id == o.server_id,
                        ).first()
                        if q:
                            q.valid = False
                            delete_redis_process(config.redis, q.host, q.id)
                    objs = sc.query(self.model).filter(
                        self.model.id != kwargs['id'],
                        self.model.valid == True,
                        self.model.server_id == payload['server_id'],
                        self.model.day_night == payload['day_night'],
                    ).all()
                    for r in objs:
                        if r.script_cpu_valid and r.script_cpu_bind:
                            used_core.append(r.script_cpu_bind)
                        if r.config_cpu_valid and r.config_cpu_bind:
                            used_core.extend(r.config_cpu_bind.values())
                    objs = sc.query(TuringPreToolConfs).filter(
                        TuringPreToolConfs.valid == True,
                        TuringPreToolConfs.server_id == payload['server_id'],
                        TuringPreToolConfs.day_night == payload['day_night'],
                    ).all()
                    for r in objs:
                        if r.script_cpu_valid and r.script_cpu_bind:
                            used_core.append(r.script_cpu_bind)
                    if set(req_core) & set(used_core):
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'cpu core binded.',
                        }))
                        return
                    for k, v in self.fields.items():
                        if v in payload:
                            if (v == 'script_cpu_bind' and not payload['script_cpu_valid']) or \
                               (v == 'config_cpu_bind' and not payload['config_cpu_valid']):
                                continue
                            if v == 'account_id':
                                setattr(o, k, ','.join([str(a) for a in payload[v]]))
                            else:
                                setattr(o, k, payload[v])
                    sc.commit()
                    self.write(json.dumps({
                        'code': 0,
                        'data': o.to_dict(),
                    }))
                else:
                    self.write(json.dumps({
                        'code': 404,
                        'error': 'Data not found.',
                    }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                o = sc.query(TuringDeployConfs).join(
                    TuringServers, TuringServers.ip == TuringDeployConfs.host,
                ).join(self.model,
                    self.model.deploy_path == TuringDeployConfs.deploy_path,
                ).filter(
                    self.model.server_id == TuringServers.id,
                    self.model.id == kwargs['id'],
                ).order_by(self.model.id.desc()).first()
                if o:
                    o.valid = False
                    delete_redis_process(config.redis, o.host, o.id)
                sc.query(self.model).filter_by(id=kwargs['id']).delete()
                self.write(json.dumps({
                    'code': 0,
                    'data': 1,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class TuringDIMEvsListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = DIMFiles

    def get(self, *args, **kwargs):
        _type = self.get_argument('type', '')
        if not _type:
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        file_type = 13 if _type == 'test' else 3
        res = []
        versions = []
        with mysql_sc() as sc:
            l = sc.query(self.model).filter(
                self.model.file_type == file_type,
            ).order_by(
                self.model.id.desc()
            ).first()
            lines = sc.query(self.model).filter(
                self.model.file_type == file_type,
                self.model.r_create_time == l.r_create_time,
            )
            for line in lines:
                if line.version not in versions:
                    versions.append(line.version)
                    res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))


class TuringDIMStrategiesListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = DIMFiles

    def get(self, *args, **kwargs):
        _type = self.get_argument('type', '')
        if not _type:
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        file_type = 11 if _type == 'test' else 1
        res = []
        versions = []
        with mysql_sc() as sc:
            l = sc.query(self.model).filter(
                self.model.file_type == file_type,
            ).order_by(
                self.model.id.desc()
            ).first()
            lines = sc.query(self.model).filter(
                self.model.file_type == file_type,
                self.model.r_create_time == l.r_create_time,
            )
            for line in lines:
                if line.version not in versions:
                    versions.append(line.version)
                    res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))


class TuringDeployProgramsListHandler(ListHandler):
    executor = ThreadPoolExecutor(2)

    def initialize(self, *args, **kwargs):
        self.model = TuringDeployPrograms

    @gen.coroutine
    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if ('server' not in payload) or \
           ('program_id' not in payload) or \
           ('deploy_path' not in payload):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            script_cpu_bind = None
            host = payload['server']
            program_id = payload['program_id']
            deploy_path = payload['deploy_path']
            day_night = -1
            with mysql_sc() as sc:
                pt = sc.query(TuringProgramTypes).join(TuringPrograms).filter(
                    TuringProgramTypes.id == TuringPrograms.type_id,
                    TuringPrograms.id == program_id,
                ).first()
                if not pt:
                    self.write(json.dumps({
                        'code': 404,
                        'error': 'Data not found.',
                    }))
                    return
                if pt.name == 'bss_agent':
                    if not sc.query(TuringPreAgentConfs).join(TuringServers).filter(
                        TuringServers.ip == host,
                        TuringPreAgentConfs.valid == True,
                        TuringPreAgentConfs.deploy_path == deploy_path,
                    ).first():
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Deploy path not pre-config.'
                        }))
                        return
                elif pt.name.startswith('turing_'):
                    t = sc.query(TuringPreTraderConfs).join(TuringServers).filter(
                        TuringServers.ip == host,
                        TuringPreTraderConfs.valid == True,
                        TuringPreTraderConfs.deploy_path == deploy_path,
                    ).first()
                    if not t:
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Deploy path not pre-config.'
                        }))
                        return
                    script_cpu_bind = t.script_cpu_bind
                    day_night = t.day_night
                elif pt.name.startswith('quote_'):
                    t = sc.query(TuringPreToolConfs).join(TuringServers).filter(
                        TuringServers.ip == host,
                        TuringPreToolConfs.valid == True,
                        TuringPreToolConfs.deploy_path == deploy_path,
                    ).first()
                    if not t:
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Deploy path not pre-config.'
                        }))
                        return
                    script_cpu_bind = t.script_cpu_bind
                    day_night = t.day_night
                elif pt.name.startswith('platform_'):
                    if not sc.query(TuringPreForwarderConfs).join(TuringServers).filter(
                        TuringServers.ip == host,
                        TuringPreForwarderConfs.valid == True,
                        TuringPreForwarderConfs.deploy_path == deploy_path,
                    ).first():
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Deploy path not pre-config.'
                        }))
                        return
                elif pt.name.startswith('galileo_'):
                    t = sc.query(GalileoPreTraderConfs).join(TuringServers).filter(
                        TuringServers.ip == host,
                        GalileoPreTraderConfs.valid == True,
                        GalileoPreTraderConfs.deploy_path == deploy_path,
                    ).first()
                    if not t:
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Deploy path not pre-config.'
                        }))
                        return
                    script_cpu_bind = t.script_cpu_bind
                    day_night = t.day_night
                else:
                    self.write(json.dumps({
                        'code': 400,
                        'error': 'Deploy path not pre-config.'
                    }))
                    return

                data = {
                    'host': host,
                    'deploy_path': deploy_path,
                    'program_id': program_id,
                    'day_night': day_night,
                }
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
            tornado.ioloop.IOLoop.instance().add_callback(
                self.async_upload_file,
                host=host,
                deploy_path=deploy_path,
                program_id=program_id,
                day_night=day_night,
                script_cpu_bind=script_cpu_bind,
            )
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    @run_on_executor
    def async_upload_file(self, host, deploy_path, program_id, day_night, script_cpu_bind):
        l_host = config.local['vpn'] if host.rsplit('.', 1)[0] == '192.168.30' else config.local['host']
        try:
            with mysql_sc() as sc:
                p = sc.query(TuringPrograms).filter_by(id=program_id).first()
                if sc.query(self.model).filter(
                    self.model.host == host,
                    self.model.deploy_path == deploy_path,
                ).first():
                    deployed = True
                else:
                    deployed = False
                res = upload_turing_bfile(config.local['user'], l_host,
                                          host, deploy_path, p.filepath, deployed=deployed,
                                          script_cpu_bind=script_cpu_bind)
                o = sc.query(self.model).filter(
                    self.model.host == host,
                    self.model.deploy_path == deploy_path,
                    self.model.program_id == program_id,
                    self.model.day_night == day_night,
                ).order_by(
                    self.model.id.desc()
                ).first()
                o.result = 1 if res else 2
                if res:
                    o = sc.query(TuringDeployConfs).filter(
                        TuringDeployConfs.host == host,
                        TuringDeployConfs.deploy_path == deploy_path,
                    ).first()
                    if o:
                        o.day_night = day_night
                        o.program_id = program_id
                        o.result = 1
                        o.valid = True
                    else:
                        data = {
                            'host': host,
                            'deploy_path': deploy_path,
                            'day_night': day_night,
                            'program_id': program_id,
                            'valid': True,
                            'result': 1,
                            'status': 2,
                        }
                        o = TuringDeployConfs(**data)
                        sc.add(o)
                    sc.commit()

                    pt = sc.query(TuringProgramTypes).filter_by(id=p.type_id).first()
                    if pt.name == 'bss_agent':
                        self.register_agent_event(host)
                    elif pt.name.startswith('turing_') or pt.name.startswith('platform_') or pt.name.startswith('quote_') or pt.name.startswith('galileo_'):
                        self.register_process_event(host, o.id)

        except Exception as e:
            logger.error(str(e))
            raise e

    def register_agent_event(self, host):
        headers = {
            'content-type': 'application/json',
            'whitelist': 'operater',
        }
        data = {
            'type': 'host',
            'host': host,
        }
        try:
            req_url = 'http://127.0.0.1/api/v1/event_handle/deploy_reg_handle'
            http_client = tornado.httpclient.HTTPClient()
            response = http_client.fetch(
                req_url,
                method='POST',
                headers=headers,
                body=json.dumps(data),
            )
            logger.info('Register agent: resp=%s' % response.body)
        except Exception as e:
            logger.error('Register agent error: %s' % str(e))

    def register_process_event(self, host, process_id):
        headers = {
            'content-type': 'application/json',
            'whitelist': 'operater',
        }
        data = {
            'type': 'process',
            'host': host,
            'process_id': process_id,
        }
        try:
            req_url = 'http://127.0.0.1/api/v1/event_handle/deploy_reg_handle'
            http_client = tornado.httpclient.HTTPClient()
            response = http_client.fetch(
                req_url,
                method='POST',
                headers=headers,
                body=json.dumps(data),
            )
            logger.info('Register process: resp=%s' % response.body)
        except Exception as e:
            logger.error('Register process error: %s' % str(e))


class TuringDeployProgramsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringDeployPrograms

    def put(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def delete(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))


class TuringDeployEVsListHandler(ListHandler):
    executor = ThreadPoolExecutor(2)

    def initialize(self, *args, **kwargs):
        self.model = TuringDeployDIMFiles

    @gen.coroutine
    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if ('server' not in payload) or \
           ('deploy_path' not in payload) or \
           ('day_night' not in payload) or \
           ('file_id' not in payload):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            host = payload['server']
            deploy_path = payload['deploy_path']
            day_night = payload['day_night']
            dimfile_id = payload['file_id']
            with mysql_sc() as sc:
                data = {
                    'host': host,
                    'deploy_path': deploy_path,
                    'day_night': day_night,
                    'dimfile_id': dimfile_id,
                }
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))

            tornado.ioloop.IOLoop.instance().add_callback(
                self.async_upload_file,
                host=host,
                deploy_path=deploy_path,
                dimfile_id=dimfile_id,
                day_night=day_night,
                )
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    @run_on_executor
    def async_upload_file(self, host, deploy_path, dimfile_id, day_night):
        l_host = config.local['vpn'] if host.rsplit('.', 1)[0] == '192.168.30' else config.local['host']
        try:
            with mysql_sc() as sc:
                f_obj = sc.query(DIMFiles).filter_by(id=dimfile_id).first()
                if sc.query(self.model).filter(
                    self.model.host == host,
                    self.model.deploy_path == deploy_path,
                ).first():
                    deployed = True
                else:
                    deployed = False
                istest = True if f_obj.file_type > 10 else False
                res = upload_ev_file(config.local['user'], l_host,
                                     host, deploy_path, os.path.join(config.dim['mnt_path'], f_obj.file_path),
                                     deployed=deployed, istest=istest)
                o = sc.query(self.model).filter(
                    self.model.host == host,
                    self.model.deploy_path == deploy_path,
                    self.model.dimfile_id == dimfile_id,
                    self.model.day_night == day_night,
                ).order_by(
                    self.model.id.desc()
                ).first()
                o.result = 1 if res else 2
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class TuringDeployEVsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringDeployDIMFiles

    def put(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def delete(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))


class TuringDeployStrategiesListHandler(ListHandler):
    executor = ThreadPoolExecutor(2)

    def initialize(self, *args, **kwargs):
        self.model = TuringDeployDIMFiles

    @gen.coroutine
    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if ('server' not in payload) or \
           ('deploy_path' not in payload) or \
           ('day_night' not in payload) or \
           ('file_id' not in payload) or \
           ('exchange' not in payload):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            host = payload['server']
            deploy_path = payload['deploy_path']
            day_night = payload['day_night']
            dimfile_id = payload['file_id']
            products = get_my_products(payload['exchange'].lower())
            if not products:
                self.write(json.dumps({
                    'code': 400,
                    'error': 'Payload data error.',
                }))
                return
            with mysql_sc() as sc:
                data = {
                    'host': host,
                    'deploy_path': deploy_path,
                    'day_night': day_night,
                    'dimfile_id': dimfile_id,
                    'products': products,
                }
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                model_id = o.id
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))

            tornado.ioloop.IOLoop.instance().add_callback(
                self.async_upload_file,
                host=host,
                deploy_path=deploy_path,
                dimfile_id=dimfile_id,
                day_night=day_night,
                exchange=payload['exchange'].lower(),
                model_id=model_id,
                )
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    @run_on_executor
    def async_upload_file(self, host, deploy_path, dimfile_id, day_night, exchange, model_id):
        l_host = config.local['vpn'] if host.rsplit('.', 1)[0] == '192.168.30' else config.local['host']
        try:
            with mysql_sc() as sc:
                f_obj = sc.query(DIMFiles).filter_by(id=dimfile_id).first()
                if sc.query(self.model).filter(
                    self.model.host == host,
                    self.model.deploy_path == deploy_path,
                ).first():
                    deployed = True
                else:
                    deployed = False
                istest = True if f_obj.file_type > 10 else False
                res = upload_strategies_file(config.local['user'], l_host,
                                             host, deploy_path, os.path.join(config.dim['mnt_path'], f_obj.file_path),
                                             exchange, day_night, istest=istest)
                o = sc.query(self.model).filter(
                    self.model.id == model_id,
                ).order_by(
                    self.model.id.desc()
                ).first()
                o.result = 1 if res else 2
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class TuringDeployStrategiesDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringDeployDIMFiles

    def put(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))

    def delete(self, *args, **kwargs):
        self.write(json.dumps({
            'code': 404,
            'error': 'Method not found.',
        }))


class TuringGenerateConfsListHandler(BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if ('server' not in payload) or \
           ('source' not in payload) or \
           ('deploy_path' not in payload):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            host = payload['server']
            deploy_path = payload['deploy_path']
            source = payload['source']
            content = ''
            with mysql_sc() as sc:
                if int(source) == 1:
                    r = sc.query(TuringDeployConfs).filter(
                        TuringDeployConfs.host == host,
                        TuringDeployConfs.deploy_path == deploy_path,
                    ).order_by(
                        TuringDeployConfs.id.desc()
                    ).first()
                    if r:
                        content = r.content
                else:
                    r = sc.query(
                        TuringPreTraderConfs.valid.label('valid'),
                        TuringPreTraderConfs.script_cpu_valid.label('script_cpu_valid'),
                        TuringPreTraderConfs.script_cpu_bind.label('script_cpu_bind'),
                        TuringPreTraderConfs.config_cpu_valid.label('config_cpu_valid'),
                        TuringPreTraderConfs.config_cpu_bind.label('config_cpu_bind'),
                        TuringPreTraderConfs.day_night.label('day_night'),
                        TuringPreTraderConfs.local_ip.label('local_ip'),
                        TuringPreTraderConfs.local_port.label('local_port'),
                        TuringPreTraderConfs.src_mac.label('src_mac'),
                        TuringPreTraderConfs.nic.label('nic'),
                        TuringPreTraderConfs.account_id.label('account_id'),
                        #Accounts.name.label('account'),
                        #Accounts.password.label('password'),
                        #Accounts.rsp_pwd.label('rsp_pwd'),
                        TuringConfigTemplates.content.label('template'),
                    ).join(
                        TuringServers,
                        TuringPreTraderConfs.server_id == TuringServers.id,
                    #).join(
                    #    Accounts,
                    #    TuringPreTraderConfs.account_id == Accounts.id,
                    ).join(
                        TuringConfigTemplates,
                        TuringPreTraderConfs.config_template_id == TuringConfigTemplates.id,
                    ).filter(
                        TuringPreTraderConfs.deploy_path == deploy_path,
                        TuringServers.ip == host,
                    ).first()
                    if not r:
                        self.write(json.dumps({
                            'code': 1404,
                            'error': 'Data not found.'
                        }))
                        return
                    else:
                        if not r.valid:
                            self.write(json.dumps({
                                'code': 1404,
                                'error': 'invalid pre-config.'
                            }))
                            return
                    acc_list = r.account_id.split(',')
                    account_info = {}
                    for _acc in acc_list:
                        _a = sc.query(Accounts).filter(Accounts.id == int(_acc)).first()
                        if not _a:
                            self.write(json.dumps({
                                'code': 1404,
                                'error': 'account not config.',
                            }))
                            return
                        account_info[_a.name] = {
                            'password': _a.password,
                            'rsp_pwd': _a.rsp_pwd,
                        }
                    day_night = r.day_night
                    daynight = 'day' if day_night == 0 else 'night'
                    #account = r.account
                    #password = r.password
                    #rsp_pwd = r.rsp_pwd or ''
                    config_cpu_bind = r.config_cpu_bind
                    local_ip = r.local_ip
                    local_port = r.local_port
                    src_mac = r.src_mac
                    nic = r.nic
                    template = r.template
                    is_multi_tunnel = False
                    # check if multi tunnel xml by include alpha
                    if len(acc_list) == 1:
                        account = list(account_info.keys())[0]
                        #for account, _ in account_info.items():
                        for _i in account:
                            if _i.isalpha():
                                is_multi_tunnel = True
                                break
                    d = sc.query(DIMPreConfs).filter().order_by(DIMPreConfs.id.desc()).first()
                    if not d:
                        self.write(json.dumps({
                            'code': 404,
                            'error': 'not config.',
                        }))
                        return
                        uid = d.uid

                    if is_multi_tunnel:
                        password = account_info[account]['password']
                        rsp_pwd = account_info[account]['rsp_pwd']
                        #d = sc.query(DIMPreConfs).filter(
                        #    DIMPreConfs.fake_account == account,
                        #    DIMPreConfs.day_night == day_night,
                        #).order_by(
                        #    DIMPreConfs.id.desc()
                        #).first()
                        #if not d:
                        #    self.write(json.dumps({
                        #        'code': 404,
                        #        'error': 'Account not found in pre-config.',
                        #    }))
                        #    return
                        #uid = d.uid
                        lines = sc.query(DIMPreConfs).filter(
                            DIMPreConfs.uid == uid,
                            DIMPreConfs.fake_account == account,
                            DIMPreConfs.day_night == day_night,
                        ).order_by(
                            DIMPreConfs.product.asc()
                        ).all()
                        if len(lines) == 0:
                            self.write(json.dumps({
                                'code': 404,
                                'error': 'Account not found in pre-config.',
                            }))
                            return
                        conf_dict = {}
                        istest = False
                        for line in lines:
                            if line.type == 2:
                                istest = True
                            product = line.product
                            symbol = line.symbol
                            alphamixer = line.alphamixer
                            strategy = line.strategy
                            max_vol = line.max_vol
                            limit_vol = line.limit_vol
                            single_max_vol = line.single_max_vol
                            ev_dim = line.ev_dim
                            ev_data = line.ev_data
                            exchange = line.exchange
                            client_id = line.account
                            if exchange.lower() == 'czce':
                                long_product = 'zz%s' % product.lower()
                            elif exchange.lower() == 'dce':
                                long_product = 'dl%s' % product.lower()
                            elif exchange.lower() == 'shfe':
                                long_product = 'sh%s' % product.lower()
                            else:
                                long_product = product.lower()
                            k = '%s_%s_%s_%s' % (alphamixer, long_product, daynight, symbol)
                            if k not in conf_dict:
                                conf_dict[k] = {
                                    client_id: [{
                                        'strategy': strategy,
                                        'max_vol': max_vol,
                                        'limit_vol': limit_vol,
                                        'single_max_vol': single_max_vol,
                                        'ev_dim': ev_dim,
                                        'ev_data': ev_data,
                                    }],
                                }
                            else:
                                if client_id not in conf_dict[k]:
                                    conf_dict[k][client_id] = [{
                                        'strategy': strategy,
                                        'max_vol': max_vol,
                                        'limit_vol': limit_vol,
                                        'single_max_vol': single_max_vol,
                                        'ev_dim': ev_dim,
                                        'ev_data': ev_data,
                                    }]
                                else:
                                    conf_dict[k][client_id].append({
                                        'strategy': strategy,
                                        'max_vol': max_vol,
                                        'limit_vol': limit_vol,
                                        'single_max_vol': single_max_vol,
                                        'ev_dim': ev_dim,
                                        'ev_data': ev_data,
                                    })
                        content = self.gen_xml_multi(template, conf_dict, account, password, rsp_pwd, config_cpu_bind, local_ip, local_port, src_mac, nic, istest)
                    else:
                        conf_dict = {}
                        istest = False
                        for account, info in account_info.items():
                            conf_dict[account] = {}
                            password = info['password']
                            rsp_pwd = info['rsp_pwd']
                            #d = sc.query(DIMPreConfs).filter(
                            #    DIMPreConfs.account == account,
                            #    DIMPreConfs.day_night == day_night,
                            #).order_by(
                            #    DIMPreConfs.id.desc()
                            #).first()
                            #if not d:
                            #    self.write(json.dumps({
                            #        'code': 404,
                            #        'error': 'Account not found in pre-config.',
                            #    }))
                            #    return
                            #uid = d.uid
                            lines = sc.query(DIMPreConfs).filter(
                                DIMPreConfs.uid == uid,
                                DIMPreConfs.account == account,
                                DIMPreConfs.day_night == day_night,
                            ).order_by(
                                DIMPreConfs.product.asc()
                            ).all()
                            if len(lines) == 0:
                                self.write(json.dumps({
                                    'code': 404,
                                    'error': 'Account not found in pre-config.',
                                }))
                                return
                            for line in lines:
                                if line.type == 2:
                                    istest = True
                                product = line.product
                                symbol = line.symbol
                                alphamixer = line.alphamixer
                                strategy = line.strategy
                                max_vol = line.max_vol
                                limit_vol = line.limit_vol
                                single_max_vol = line.single_max_vol
                                ev_dim = line.ev_dim
                                ev_data = line.ev_data
                                exchange = line.exchange
                                if exchange.lower() == 'czce':
                                    long_product = 'zz%s' % product.lower()
                                elif exchange.lower() == 'dce':
                                    long_product = 'dl%s' % product.lower()
                                elif exchange.lower() == 'shfe':
                                    long_product = 'sh%s' % product.lower()
                                else:
                                    long_product = product.lower()
                                k = '%s_%s_%s_%s' % (alphamixer, long_product, daynight, symbol)
                                if k not in conf_dict[account]:
                                    conf_dict[account][k] = {
                                        'ev_dim': ev_dim,
                                        'ev_data': ev_data,
                                        'strategies': [{
                                            'strategy': strategy,
                                            'max_vol': max_vol,
                                            'limit_vol': limit_vol,
                                            'single_max_vol': single_max_vol,
                                            'ev_dim': ev_dim,
                                            'ev_data': ev_data,
                                        }],
                                    }
                                else:
                                    conf_dict[account][k]['strategies'].append({
                                        'strategy': strategy,
                                        'max_vol': max_vol,
                                        'limit_vol': limit_vol,
                                        'single_max_vol': single_max_vol,
                                        'ev_dim': ev_dim,
                                        'ev_data': ev_data,
                                    })
                        content = self.gen_xml(template, conf_dict, account_info, config_cpu_bind, local_ip, local_port, src_mac, nic, istest)
                self.write(json.dumps({
                    'code': 0,
                    'data': {
                        'xml': content,
                    },
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def gen_xml_multi(self, template, conf_dict, account, password, rsp_pwd, config_cpu_bind, local_ip, local_port, src_mac, nic, istest):
        kdb_obj = KdbQuery()
        now = datetime.datetime.now()
        if now.hour < 18:
            kdb_date = now.strftime('%Y.%m.%d')
        else:
            kdb_date = (now + datetime.timedelta(days=1)).strftime('%Y.%m.%d')

        root = et.fromstring(template)

        trader_login = root.find('trader_login')
        if trader_login is not None:
            if trader_login.find('local_ip') is not None and local_ip:
                trader_login.find('local_ip').text = local_ip
            if trader_login.find('local_port') is not None and local_port:
                trader_login.find('local_port').text = local_port
            if trader_login.find('src_mac') is not None and src_mac:
                trader_login.find('src_mac').text = src_mac
            if trader_login.find('nic') is not None and nic:
                trader_login.find('nic').text = nic

        account_node = root.find('tot_account_number/account')
        account_node.find('passwd').text = password

        if account_node.find('x1_rsp_pwd') is not None:
            account_node.find('x1_rsp_pwd').text = rsp_pwd

        if config_cpu_bind:
            for k, v in config_cpu_bind.items():
                if root.find(k) is not None:
                    root.find(k).text = str(v)

        # remove duplicate strategey node
        for node in account_node.findall('strategy')[1:]:
            account_node.remove(node)
        strategy_node = account_node.find('strategy')
        for node in strategy_node.findall('client')[1:]:
            strategy_node.remove(node)
        client_node = strategy_node.find('client')
        for node in client_node.findall('sub_strategy')[1:]:
            client_node.remove(node)

        strategy_node = account_node.find('strategy')
        for _ in range(len(conf_dict) - 1):
            account_node.append(copy.deepcopy(strategy_node))
        strategy_node_list = account_node.findall('strategy')

        for strategy_node, k in zip(strategy_node_list, conf_dict):
            client_dict = conf_dict[k]
            long_product = k.split('_')[1]
            symbol = k.rsplit('_', 1)[1]
            k = k.rsplit('_', 1)[0]
            if symbol in ['R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9',
                    'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20']:
                _tmp = k.split('_')
                k_st = '%s_%s%s_%s' % (_tmp[0], _tmp[1], symbol.replace("R",""), _tmp[2])
            elif symbol == 'R1':
                _tmp = k.split('_')
                k_st = '%s_%s_%s' % (_tmp[0], _tmp[1], _tmp[2])
            else:
                _tmp = k.split('_')
                if symbol.isdigit():
                    if len(symbol) == 6:
                        _rank = kdb_obj.get_cb_rank(kdb_date, symbol)
                    else:
                        _rank = kdb_obj.get_option_rank(kdb_date, symbol)
                else:
                    _rank = kdb_obj.get_symbol_rank(kdb_date, symbol)
                k_st = '%s_%s%s_%s' % (_tmp[0], _tmp[1], '' if int(_rank) == 1 else _rank, _tmp[2])
            if istest:
                so = os.path.join('/home/mycapitaltrade/turing_so/test', k_st + '.so')
            else:
                so = os.path.join('/home/mycapitaltrade/turing_so', k_st + '.so')
            if symbol in ['R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9',
                    'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20']:
                if long_product.upper() in ['CP50ETF', 'CP300ZJ', 'CP300SH', 'CP300SZ']:
                    strategy_node.find('symbol').text = kdb_obj.get_opmain_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                elif long_product.upper() in ['CBSZ', 'CBSH']:
                    strategy_node.find('symbol').text = kdb_obj.get_cb_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                else:
                    strategy_node.find('symbol').text = kdb_obj.get_main_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
            else:
                strategy_node.find('symbol').text = symbol
            strategy_node.find('strategy_so').text = so

            client_node = strategy_node.find('client')
            for _ in range(len(client_dict) - 1):
                strategy_node.append(copy.deepcopy(client_node))
            client_node_list = strategy_node.findall('client')
            for client_node, c_id in zip(client_node_list, client_dict):
                client_node.find('client_id').text = c_id
                alpha_dict = client_dict[c_id]
                sub_strategy_node = client_node.find('sub_strategy')
                for _ in range(len(alpha_dict) - 1):
                    client_node.append(copy.deepcopy(sub_strategy_node))
                sub_strategy_node_list = client_node.findall('sub_strategy')
                for node, st_dict in zip(sub_strategy_node_list, alpha_dict):
                    node.find('strat_name').text = st_dict['strategy']
                    node.find('max_pos').text = str(st_dict['max_vol'])
                    node.find('single_side_max_pos_limit').text = str(st_dict['single_max_vol'])
                    node.find('lock_pos_single_side_max_pos').text = str(st_dict['single_max_vol'])
                    ev_list = []
                    ev_dim = st_dict.get('ev_dim', '')
                    ev_data = st_dict.get('ev_data', '')
                    if ev_dim:
                        if istest:
                            ev_list.append(os.path.join('/home/mycapitaltrade/turing_ev/test', ev_dim))
                        else:
                            ev_list.append(os.path.join('/home/mycapitaltrade/turing_ev', ev_dim))
                    if ev_data:
                        ev_list.append(os.path.join('/home/mycapitaltrade/db_file', ev_data))
                    ev = '|'.join(ev_list)
                    node.find('strategy_ev_file').text = ev

        return '<?xml version="1.0" encoding="utf-8"?>\n' + str(et.tostring(root, 'utf-8'), 'utf-8')

    def gen_xml(self, template, conf_dict, account_info, config_cpu_bind, local_ip, local_port, src_mac, nic, istest):
        is_multi = False
        if len(account_info.keys()) > 1:
            is_multi = True

        kdb_obj = KdbQuery()
        now = datetime.datetime.now()
        if now.hour < 18:
            kdb_date = now.strftime('%Y.%m.%d')
        else:
            kdb_date = (now + datetime.timedelta(days=1)).strftime('%Y.%m.%d')

        root = et.fromstring(template)

        if config_cpu_bind:
            for k, v in config_cpu_bind.items():
                if root.find(k) is not None:
                    root.find(k).text = str(v)

        if not is_multi:
            trader_login = root.find('trader_login')
            if trader_login is not None:
                if trader_login.find('local_ip') is not None and local_ip:
                    trader_login.find('local_ip').text = local_ip
                if trader_login.find('local_port') is not None and local_port:
                    trader_login.find('local_port').text = local_port
                if trader_login.find('src_mac') is not None and src_mac:
                    trader_login.find('src_mac').text = src_mac
                if trader_login.find('nic') is not None and nic:
                    trader_login.find('nic').text = nic

        # remove duplicate account node
        tot_node = root.find('tot_account_number')
        for node in tot_node.findall('account')[1:]:
            tot_node.remove(node)
        account_node = tot_node.find('account')
        # remove duplicate strategey node
        for node in account_node.findall('strategy')[1:]:
            account_node.remove(node)
        strategy_node = account_node.find('strategy')
        for node in strategy_node.findall('sub_strategy')[1:]:
            strategy_node.remove(node)

        account_node = tot_node.find('account')
        for _ in range(len(account_info) - 1):
            tot_node.append(copy.deepcopy(account_node))
        account_node_list = tot_node.findall('account')

        for account_node, account in zip(account_node_list, account_info):
            a = account_info[account]
            password = a['password']
            rsp_pwd = a['rsp_pwd']
            if account_node.find('client_id') is not None:
                account_node.find('user_id').text = 'xele_trade'
                account_node.find('client_id').text = account
            else:
                account_node.find('user_id').text = account
            account_node.find('passwd').text = password
            if account_node.find('x1_rsp_pwd') is not None:
                account_node.find('x1_rsp_pwd').text = rsp_pwd
            if account_node.find('fund_account_id') is not None:
                account_node.find('fund_account_id').text = account
            if account_node.find('investor_id') is not None:
                account_node.find('investor_id').text = account

            if is_multi:
                trader_login = account_node.find('trader_login')
                if trader_login is not None:
                    if trader_login.find('local_ip') is not None and local_ip:
                        trader_login.find('local_ip').text = local_ip
                    if trader_login.find('local_port') is not None and local_port:
                        trader_login.find('local_port').text = local_port
                    if trader_login.find('src_mac') is not None and src_mac:
                        trader_login.find('src_mac').text = src_mac
                    if trader_login.find('nic') is not None and nic:
                        trader_login.find('nic').text = nic

            strategy_node = account_node.find('strategy')
            for _ in range(len(conf_dict[account]) - 1):
                account_node.append(copy.deepcopy(strategy_node))
            strategy_node_list = account_node.findall('strategy')

            for strategy_node, k in zip(strategy_node_list, conf_dict[account]):
                alpha_dict = conf_dict[account][k]
                long_product = k.split('_')[1]
                symbol = k.rsplit('_', 1)[1]
                k = k.rsplit('_', 1)[0]
                ev_list = []
                ev_dim = alpha_dict.get('ev_dim', '')
                ev_data = alpha_dict.get('ev_data', '')
                if ev_dim:
                    if istest:
                        ev_list.append(os.path.join('/home/mycapitaltrade/turing_ev/test', ev_dim))
                    else:
                        ev_list.append(os.path.join('/home/mycapitaltrade/turing_ev', ev_dim))
                if ev_data:
                    ev_list.append(os.path.join('/home/mycapitaltrade/db_file', ev_data))
                ev = '|'.join(ev_list)
                if symbol in ['R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9',
                        'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20']:
                    _tmp = k.split('_')
                    k_st = '%s_%s%s_%s' % (_tmp[0], _tmp[1], symbol.replace("R",""), _tmp[2])
                elif symbol == 'R1':
                    _tmp = k.split('_')
                    k_st = '%s_%s_%s' % (_tmp[0], _tmp[1], _tmp[2])
                else:
                    _tmp = k.split('_')
                    if symbol.isdigit():
                        if len(symbol) == 6:
                            _rank = kdb_obj.get_cb_rank(kdb_date, symbol)
                        else:
                            _rank = kdb_obj.get_option_rank(kdb_date, symbol)
                    else:
                        _rank = kdb_obj.get_symbol_rank(kdb_date, symbol)
                    k_st = '%s_%s%s_%s' % (_tmp[0], _tmp[1], '' if int(_rank) == 1 else _rank, _tmp[2])
                if 'relay' in k_st:
                    k_st = '%s_%s' % (k_st, account)
                if istest:
                    so = os.path.join('/home/mycapitaltrade/turing_so/test', k_st + '.so')
                else:
                    so = os.path.join('/home/mycapitaltrade/turing_so', k_st + '.so')
                if symbol in ['R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9',
                        'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20']:
                    if long_product.upper() in ['CP50ETF', 'CP300ZJ', 'CP300SH', 'CP300SZ']:
                        strategy_node.find('symbol').text = kdb_obj.get_opmain_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                    elif long_product.upper() in ['CBSZ', 'CBSH']:
                        strategy_node.find('symbol').text = kdb_obj.get_cb_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                    else:
                        strategy_node.find('symbol').text = kdb_obj.get_main_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                else:
                    strategy_node.find('symbol').text = symbol
                strategy_node.find('strategy_so').text = so
                if strategy_node.find('strategy_ev_file') is not None:
                    strategy_node.find('strategy_ev_file').text = ev

                if long_product == 'dli' and strategy_node.find('max_accum_open_vol') is not None:
                    strategy_node.find('max_accum_open_vol').text = '100000'

                sub_strategy_node = strategy_node.find('sub_strategy')
                for _ in range(len(alpha_dict['strategies']) - 1):
                    strategy_node.append(copy.deepcopy(sub_strategy_node))
                sub_strategy_node_list = strategy_node.findall('sub_strategy')
                for node, st_dict in zip(sub_strategy_node_list, alpha_dict['strategies']):
                    node.find('strat_name').text = st_dict['strategy']
                    node.find('max_pos').text = str(st_dict['max_vol'])
                    node.find('single_side_max_pos_limit').text = str(st_dict['single_max_vol'])
                    node.find('lock_pos_single_side_max_pos').text = str(st_dict['single_max_vol'])
                    st_ev_list = []
                    ev_dim = st_dict.get('ev_dim', '')
                    ev_data = st_dict.get('ev_data', '')
                    if ev_dim:
                        if istest:
                            st_ev_list.append(os.path.join('/home/mycapitaltrade/turing_ev/test', ev_dim))
                        else:
                            st_ev_list.append(os.path.join('/home/mycapitaltrade/turing_ev', ev_dim))
                    if ev_data:
                        st_ev_list.append(os.path.join('/home/mycapitaltrade/db_file', ev_data))
                    st_ev = '|'.join(st_ev_list)
                    if node.find('strategy_ev_file') is not None:
                        node.find('strategy_ev_file').text = st_ev

        return '<?xml version="1.0" encoding="utf-8"?>\n' + str(et.tostring(root, 'utf-8'), 'utf-8')


class TuringDeployConfsListHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringDeployConfs

    @gen.coroutine
    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if ('server' not in payload) or \
           ('deploy_path' not in payload) or \
           ('xml' not in payload):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        logger.info('[Trace TuringDeployConfsListHandler] user:%s, payload:%s' % (self.current_user.get('username', 'nobody'), payload))
        try:
            host = payload['server']
            deploy_path = payload['deploy_path']
            content = payload['xml']
            with mysql_sc() as sc:
                o = sc.query(TuringDeployPrograms).filter(
                    TuringDeployPrograms.host == host,
                    TuringDeployPrograms.deploy_path == deploy_path,
                ).order_by(
                    TuringDeployPrograms.id.desc()
                ).first()
                if not o:
                    self.write(json.dumps({
                        'code': 500,
                        'error': 'Process not deployed.'
                    }))
                    return
                else:
                    if o.result != 1:
                        self.write(json.dumps({
                            'code': 500,
                            'error': 'Process not deployed.'
                        }))
                        return
                o = sc.query(self.model).filter(
                    self.model.host == host,
                    self.model.deploy_path == deploy_path,
                ).first()
                if not o:
                    self.write(json.dumps({
                        'code': 500,
                        'error': 'Process not deployed.'
                    }))
                    return
                else:
                    o.content = content
                    o.result = 1
                    o.valid = True
                    sc.commit()
                    self.write(json.dumps({
                        'code': 0,
                        'data': o.to_dict(),
                    }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class TuringProcessListHandler(BaseHandler):
    executor = ThreadPoolExecutor(2)

    def initialize(self, *args, **kwargs):
        self.model = TuringDeployConfs

    def get(self, *args, **kwargs):
        res_with_header = {
            'agent': {
                'data': [],
                'header': [
                    {'title': '进程ID', 'prop': 'id'},
                    {'title': '部署路径', 'prop': 'deploy_path'},
                    {'title': '程序状态', 'prop': 'status'}
                ],
            },
            'tool': {
                'data': [],
                'header': [
                    {'title': '进程ID', 'prop': 'id'},
                    {'title': '部署路径', 'prop': 'deploy_path'},
                    {'title': '程序状态', 'prop': 'status'}
                ],
            },
            'turing_day': {
                'data': [],
                'header': [
                    {'title': '进程ID', 'prop': 'id'},
                    {'title': '部署路径', 'prop': 'deploy_path'},
                    {'title': '当前配置', 'prop': 'config'},
                    {'title': '程序状态', 'prop': 'status'}
                ],
            },
            'turing_night': {
                'data': [],
                'header': [
                    {'title': '进程ID', 'prop': 'id'},
                    {'title': '部署路径', 'prop': 'deploy_path'},
                    {'title': '当前配置', 'prop': 'config'},
                    {'title': '程序状态', 'prop': 'status'}
                ],
            },
            'platform': {
                'data': [],
                'header': [
                    {'title': '进程ID', 'prop': 'id'},
                    {'title': '部署路径', 'prop': 'deploy_path'},
                    {'title': '程序状态', 'prop': 'status'}
                ],
            },
        }
        res = {
            'agent': [],
            'tool': [],
            'turing_day': [],
            'turing_night': [],
            'platform': [],
        }
        host = self.get_argument('server', '')
        has_header = self.get_argument('header', 'false')
        if not host:
            self.write(json.dumps({
                'code': 500,
                'error': 'Payload data error.',
            }))
            return
        agent_online = query_agent_online(config.redis, host)
        processes_online = query_process_online(config.redis, host)
        with mysql_sc() as sc:
            lines = sc.query(self.model).filter(
                self.model.valid == True,
                self.model.host == host,
            )
            for line in lines:
                pt = sc.query(TuringProgramTypes).join(
                    TuringPrograms, TuringProgramTypes.id == TuringPrograms.type_id,
                ).filter(
                    TuringPrograms.id == line.program_id,
                ).first()
                if not pt:
                    self.write(json.dumps({
                        'code': 500,
                        'error': 'Payload data error.',
                    }))
                    return
                data = line.to_dict()
                if pt.name == 'bss_agent':
                    data['status'] = agent_online
                    res_with_header['agent']['data'].append(data)
                    res['agent'].append(data)
                elif pt.name.startswith('quote_'):
                    data['status'] = processes_online.get(line.id, 2)
                    data['is_quote'] = 1
                    if line.day_night == 0:
                        res_with_header['turing_day']['data'].append(data)
                        res['turing_day'].append(data)
                    else:
                        res_with_header['turing_night']['data'].append(data)
                        res['turing_night'].append(data)
                elif pt.name.startswith('turing_'):
                    data['status'] = processes_online.get(line.id, 2)
                    if line.day_night == 0:
                        res_with_header['turing_day']['data'].append(data)
                        res['turing_day'].append(data)
                    else:
                        res_with_header['turing_night']['data'].append(data)
                        res['turing_night'].append(data)
                elif pt.name.startswith('platform_'):
                    data['status'] = processes_online.get(line.id, 2)
                    res_with_header['platform']['data'].append(data)
                    res['platform'].append(data)
                elif pt.name.startswith('galileo_'):
                    data['status'] = processes_online.get(line.id, 2)
                    data['is_quote'] = 2
                    if line.day_night == 0:
                        res_with_header['turing_day']['data'].append(data)
                        res['turing_day'].append(data)
                    else:
                        res_with_header['turing_night']['data'].append(data)
                        res['turing_night'].append(data)
        self.write(json.dumps({
            'code': 0,
            'data': res_with_header if has_header.lower() == 'true' else res,
        }))

    def check_origin_id(self, xml_data):
        if not xml_data:
            return True
        root = et.fromstring(xml_data)
        if root.find("origin_id") is not None:
            if "-1" == root.find("origin_id").text:
                return False
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if ('cmd' not in payload) or \
           ('process_ids' not in payload):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        process_ids = payload['process_ids']
        res = {
            'agent': [],
            'tool': [],
            'turing_day': [],
            'turing_night': [],
            'platform': [],
        }
        logger.info('[Trace TuringProcessListHandler] user:%s, payload:%s' % (self.current_user.get('username', 'nobody'), payload))
        try:
            tmp_list = []
            run_success = []
            config_success = []
            with mysql_sc() as sc:
                code = 0
                querys = sc.query(self.model).filter(self.model.id.in_(process_ids))
                for i, o in enumerate(querys.all()):
                    if payload['cmd'] == 0:
                        if o.valid == False:
                            code == 500
                            continue
                    pt = sc.query(TuringProgramTypes).join(
                        TuringPrograms, TuringProgramTypes.id == TuringPrograms.type_id,
                    ).join(
                        TuringDeployConfs, TuringPrograms.id == TuringDeployConfs.program_id,
                    ).filter(
                        TuringPrograms.id == o.program_id,
                    ).first()
                    iphost = query_redis_iphost(config.redis, o.host)
                    if not iphost:
                        o.result = 2
                        sc.commit()
                        code = 404
                        continue
                    if pt.name == 'bss_agent':# or pt.name.startswith('quote_'):
                        delete_redis_cmd(config.redis, iphost)
                        o.status = payload['cmd']
                        host = o.host
                        deploy_path = o.deploy_path
                        tornado.ioloop.IOLoop.instance().add_callback(
                            self.async_run_agent,
                            host=host,
                            deploy_path=deploy_path,
                            cmd=payload['cmd'],
                            redis_config=config.redis,
                        )
                        continue
                    _now = datetime.datetime.now()
                    seq = int(str(_now.second)+str(_now.microsecond))
                    if payload['cmd'] == 0:
                        if not self.check_origin_id(o.content):
                            logger.info("host %s, id %s, origin id is -1" % (o.host, o.id))
                            continue

                        cmd = json.dumps({
                            'type': 1,
                            'data': {
                                'opt_type': payload['cmd'],
                                'process_id': o.id,
                                'path': os.path.join(o.deploy_path, 'run.sh'),
                            },
                            'seq': seq,
                        })
                        clear_history_launch_msg(config.redis, iphost, o.id)

                    elif payload['cmd'] == 2:
                        cmd = json.dumps({
                            'type': 1,
                            'data': {
                                'opt_type': payload['cmd'],
                                'process_id': o.id,
                            },
                            'seq': seq,
                        })
                    if not rpush_redis_cmd(config.redis, iphost, cmd):
                        code = 500
                        o.result = 2
                        sc.commit()
                        continue
                    tmp_list.append([i, seq, iphost])
                    if payload['cmd'] == 0 and (pt.name.startswith('turing_') or pt.name.startswith('platform_') or pt.name.startswith('quote_') or pt.name.startswith('galileo_')):
                        update_redis_process(config.redis, o.host, os.path.join(o.deploy_path, 'run.sh'), 1, o.id)
                    elif payload['cmd'] == 2 and (pt.name.startswith('turing_') or pt.name.startswith('platform_') or pt.name.startswith('quote_') or pt.name.startswith('galileo_')):
                        update_redis_process(config.redis, o.host, os.path.join(o.deploy_path, 'run.sh'), 0, o.id)

            for _ in range(15):
                if len(run_success) == len(tmp_list):
                    code = 0
                    break
                yield gen.sleep(1)
                with mysql_sc() as sc:
                    querys = sc.query(self.model).filter(self.model.id.in_(process_ids))
                    for tmp in tmp_list:
                        o = querys.all()[tmp[0]]
                        seq = tmp[1]
                        iphost = tmp[2]
                        rsp = lpop_redis_cmd(config.redis, iphost, seq)
                        if (not rsp) or (json.loads(str(rsp, 'utf-8'))['seq'] != seq) or \
                           (json.loads(str(rsp, 'utf-8'))['data']['return'] != 0):
                            code = 2001
                            continue
                        else:
                            run_success.append(tmp)
                            o.status = payload['cmd']
                            sc.commit()
                            pt = sc.query(TuringProgramTypes).join(
                                TuringPrograms, TuringProgramTypes.id == TuringPrograms.type_id,
                            ).join(
                                TuringDeployConfs, TuringPrograms.id == TuringDeployConfs.program_id,
                            ).filter(
                                TuringPrograms.id == o.program_id,
                            ).first()
                            if payload['cmd'] == 0 and not pt.name.startswith('platform_'):
                                _now = datetime.datetime.now()
                                seq = int(str(_now.second)+str(_now.microsecond))
                                tmp[1] = seq
                                cmd = json.dumps({
                                    'type': 1,
                                    'data': {
                                        'opt_type': 1,
                                        'process_id': o.id,
                                        'conf': o.content,
                                    },
                                    'seq': seq,
                                })
                                if not rpush_redis_cmd(config.redis, iphost, cmd):
                                    code = 404
                                    o.result = 2
                                    sc.commit()
            if payload['cmd'] == 0:
                for _ in range(15):
                    if len(config_success) == len(tmp_list):
                        code = 0
                        break
                    yield gen.sleep(1)
                    with mysql_sc() as sc:
                        querys = sc.query(self.model).filter(self.model.id.in_(process_ids))
                        for tmp in tmp_list:
                            o = querys.all()[tmp[0]]
                            seq = tmp[1]
                            iphost = tmp[2]
                            pt = sc.query(TuringProgramTypes).join(
                                TuringPrograms, TuringProgramTypes.id == TuringPrograms.type_id,
                            ).join(
                                TuringDeployConfs, TuringPrograms.id == TuringDeployConfs.program_id,
                            ).filter(
                                TuringPrograms.id == o.program_id,
                            ).first()
                            if pt.name.startswith('platform_'):
                                continue
                            rsp = lpop_redis_cmd(config.redis, iphost, seq)
                            if (not rsp) or (json.loads(str(rsp, 'utf-8'))['seq'] != seq) or \
                               (json.loads(str(rsp, 'utf-8'))['data']['return'] != 0):
                                code = 2002
                                o.result = 2
                                sc.commit()
                            else:
                                config_success.append(tmp)
                                o.result = 1
                                sc.commit()

            yield gen.sleep(8)
            with mysql_sc() as sc:
                querys = sc.query(self.model).filter(self.model.id.in_(process_ids))
                for o in querys.all():
                    agent_online = query_agent_online(config.redis, o.host)
                    processes_online = query_process_online(config.redis, o.host)
                    pt = sc.query(TuringProgramTypes).join(
                        TuringPrograms, TuringProgramTypes.id == TuringPrograms.type_id,
                    ).join(
                        TuringDeployConfs, TuringPrograms.id == TuringDeployConfs.program_id,
                    ).filter(
                        TuringPrograms.id == o.program_id,
                    ).first()
                    data = o.to_dict()
                    if pt.name == 'bss_agent':
                        data['status'] = agent_online
                        res['agent'].append(data)
                    elif pt.name.startswith('quote_'):
                        data['status'] = processes_online.get(o.id, 2)
                        data['is_quote'] = 1
                        if o.day_night == 0:
                            res['turing_day'].append(data)
                        else:
                            res['turing_night'].append(data)
                    elif pt.name.startswith('turing_'):
                        data['status'] = processes_online.get(o.id, 2)
                        if o.day_night == 0:
                            res['turing_day'].append(data)
                        else:
                            res['turing_night'].append(data)
                    elif pt.name.startswith('platform_'):
                        data['status'] = processes_online.get(o.id, 2)
                        res['platform'].append(data)
                    elif pt.name.startswith('galileo_'):
                        data['status'] = processes_online.get(o.id, 2)
                        data['is_quote'] = 2
                        if o.day_night == 0:
                            res['turing_day'].append(data)
                        else:
                            res['turing_night'].append(data)
            self.write(json.dumps({
                'code': 0,
                'data': res,
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    @run_on_executor
    def async_run_agent(self, host, deploy_path, cmd, redis_config):
        run_agent_process(host, deploy_path, cmd, redis_config)


class TuringPreStrategyConfsListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = DIMPreConfs

    def get(self, *args, **kwargs):
        res = {
            'product': [],
            'test': [],
        }
        exchange = self.get_argument('exchange', '')
        day_night = int(self.get_argument('day_night', '-1'))
        if not exchange or day_night == -1:
            self.write(json.dumps({
                'code': 404,
                'error': 'Payload data error.',
            }))
            return
        alpha_dict = {
            'product': {},
            'test': {}
        }
        with mysql_sc() as sc:
            o = sc.query(self.model).filter(
                self.model.exchange == exchange,
                self.model.day_night == day_night,
                self.model.type == 1,
            ).order_by(self.model.id.desc()).first()
            if o:
                objs = sc.query(self.model).filter(
                    self.model.uid == o.uid,
                    self.model.exchange == exchange,
                    self.model.day_night == day_night,
                    self.model.type == 1,
                )
                for o in objs:
                    if o.alphamixer not in alpha_dict['product']:
                        alpha_dict['product'][o.alphamixer] = [o.to_dict()]
                    else:
                        alpha_dict['product'][o.alphamixer].append(o.to_dict())
            o = sc.query(self.model).filter(
                self.model.exchange == exchange,
                self.model.day_night == day_night,
                self.model.type == 2,
            ).order_by(self.model.id.desc()).first()
            if o:
                objs = sc.query(self.model).filter(
                    self.model.uid == o.uid,
                    self.model.exchange == exchange,
                    self.model.day_night == day_night,
                    self.model.type == 2,
                )
                for o in objs:
                    if o.alphamixer not in alpha_dict['test']:
                        alpha_dict['test'][o.alphamixer] = [o.to_dict()]
                    else:
                        alpha_dict['test'][o.alphamixer].append(o.to_dict())

        for t, st_dict in alpha_dict.items():
            for k, v in st_dict.items():
                res[t].append({
                    'alphamixer': k,
                    'detail': v,
                })
        self.write(json.dumps({
            'code': 0,
            'data': res,
        }))

    def post(self, *args, **kwargs):
        res = []
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if ('type' not in payload) or \
           ('exchange' not in payload) or \
           ('day_night' not in payload) or \
           ('alphamixer' not in payload) or \
           ('account' not in payload):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return

        account_list = []
        account_dict = payload['account']
        while account_dict:
            for account in account_dict:
                account_dict[account] -= 1
                account_list.append(account)
            account_dict = {k: v for k,v in account_dict.items() if v > 0 }

        with mysql_sc() as sc:
            o = sc.query(self.model).filter(
                self.model.exchange == payload['exchange'],
                self.model.day_night == payload['day_night'],
                self.model.type == payload['type'],
            ).order_by(self.model.id.desc()).first()
            if not o:
                self.write(json.dumps({
                    'code': 404,
                    'error': 'Data not found.',
                }))
                return
            uid = o.uid
            lines = sc.query(self.model).filter(
                self.model.uid == uid,
                self.model.exchange == payload['exchange'],
                self.model.day_night == payload['day_night'],
                self.model.alphamixer == payload['alphamixer'],
                self.model.type == payload['type'],
                self.model.fixed == False,
            ).order_by(
                self.model.product.asc()
            ).all()
            if not lines:
                self.write(json.dumps({
                    'code': 1404,
                    'error': 'Data not found.',
                }))
                return
            product_dict = {}
            for o in lines:
                if o.product not in product_dict:
                    product_dict[o.product] = [o]
                else:
                    product_dict[o.product].append(o)
            for k, v_lines in product_dict.items():
                account_list_cp = []
                account_list_cp = copy.deepcopy(account_list) * (len(v_lines) // len(account_list) + 1)
                for line, account in zip(v_lines, account_list_cp):
                    line.account = account
            sc.commit()
            for line in lines:
                res.append(line.to_dict())

        self.write(json.dumps({
            'code': 0,
            'data': res
        }))


class TuringPreStrategyConfsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = DIMPreConfs
        self.fields = {
            'max_vol': 'max_vol',
            'limit_vol': 'limit_vol',
            'single_max_vol': 'single_max_vol',
            'account': 'account',
        }


class TuringPostConfsListHandler(ListHandler):

    def get(self, *args, **kwargs):
        res = []
        date = self.get_argument('date', '')
        day_night = int(self.get_argument('day_night', '-1'))
        if not date or day_night == -1:
            self.write(json.dumps({
                'code': 404,
                'error': 'Payload data error.',
            }))
            return
        end_date = date[:4] + '-' + date[4:6] + '-' + date[6:8] + ' 23:59:59'
        with mysql_sc() as sc:
            o = sc.query(DIMPreConfs).filter(
                DIMPreConfs.type == 1,
                DIMPreConfs.day_night == day_night,
                DIMPreConfs.r_update_time <= end_date,
                DIMPreConfs.account != '',
            ).order_by(DIMPreConfs.id.desc()).first()
            if o:
                objs = sc.query(DIMPreConfs).filter(
                    DIMPreConfs.uid == o.uid,
                    DIMPreConfs.type == 1,
                    DIMPreConfs.day_night == day_night,
                    DIMPreConfs.r_update_time <= end_date,
                    DIMPreConfs.account != '',
                )
                for o in objs:
                    res.append(o.to_dict())
        if res:
            self.write(json.dumps({
                'code': 0,
                'data': res,
            }))
        else:
            self.write(json.dumps({
                'code': 404,
                'error': 'Data not found.',
            }))


class TuringPostFilesListHandler(ListHandler):

    def get(self, *args, **kwargs):
        file_name = self.get_argument('name', '')
        date = self.get_argument('date', '')
        day_night = int(self.get_argument('day_night', '-1'))
        if not file_name or not date or day_night == -1:
            self.write(json.dumps({
                'code': 404,
                'error': 'Payload data error.',
            }))
        end_date = date[:4] + '-' + date[4:6] + '-' + date[6:8] + ' 23:59:59'
        with mysql_sc() as sc:
            o = sc.query(DIMFiles).filter(
                DIMFiles.file_name == file_name,
                DIMFiles.r_update_time <= end_date,
            ).order_by(DIMFiles.id.desc()).first()
            if not o:
                self.write(json.dumps({
                    'code': 404,
                    'error': 'File not found.',
                }))
                return
            self.write(json.dumps({
                'code': 0,
                'data': os.path.join(config.dim['mnt_path'], o.file_path),
            }))


class TuringUpdateXmlSymbolHandler_V2(ListHandler, Notification):

    def get(self, *args, **kwargs):
        process_ids = []
        try:
            host = self.get_argument('host', '')
            with mysql_sc() as sc:
                processes = sc.query(TuringDeployConfs).filter(
                    TuringDeployConfs.valid == 1,
                )
                if host:
                    processes = processes.filter(TuringDeployConfs.host == host)
                dd = sc.query(DIMPreConfs).filter().order_by(DIMPreConfs.id.desc()).first()
                if not dd:
                    self.write(json.dumps({
                        'code': 0,
                        'data': [],
                    }))
                    return
                uid = dd.uid
                logger.info("TuringUpdateXmlSymbolHandler_V2 uid:%s" % uid)
                for process in processes:
                    xml = process.content
                    if not xml:
                        continue
                    host = process.host
                    deploy_path = process.deploy_path
                    r = sc.query(
                        TuringPreTraderConfs.valid.label('valid'),
                        TuringPreTraderConfs.script_cpu_valid.label('script_cpu_valid'),
                        TuringPreTraderConfs.script_cpu_bind.label('script_cpu_bind'),
                        TuringPreTraderConfs.config_cpu_valid.label('config_cpu_valid'),
                        TuringPreTraderConfs.config_cpu_bind.label('config_cpu_bind'),
                        TuringPreTraderConfs.day_night.label('day_night'),
                        TuringPreTraderConfs.local_ip.label('local_ip'),
                        TuringPreTraderConfs.local_port.label('local_port'),
                        TuringPreTraderConfs.src_mac.label('src_mac'),
                        TuringPreTraderConfs.nic.label('nic'),
                        TuringPreTraderConfs.account_id.label('account_id'),
                        #Accounts.name.label('account'),
                        #Accounts.password.label('password'),
                        #Accounts.rsp_pwd.label('rsp_pwd'),
                        TuringConfigTemplates.content.label('template'),
                    ).join(
                        TuringServers,
                        TuringPreTraderConfs.server_id == TuringServers.id,
                    #).join(
                    #    Accounts,
                    #    TuringPreTraderConfs.account_id == Accounts.id,
                    ).join(
                        TuringConfigTemplates,
                        TuringPreTraderConfs.config_template_id == TuringConfigTemplates.id,
                    ).filter(
                        TuringPreTraderConfs.deploy_path == deploy_path,
                        TuringServers.ip == host,
                    ).first()
                    if not r:
                        continue
                    day_night = r.day_night
                    is_multi_tunnel = False
                    acc_list = r.account_id.split(',')
                    account_info = {}
                    has_account = True
                    for _acc in acc_list:
                        _a = sc.query(Accounts).filter(Accounts.id == int(_acc)).first()
                        if not _a:
                            has_account = False
                            continue
                        account = _a.name
                        account_info[_a.name] = {
                            'password': _a.password,
                            'rsp_pwd': _a.rsp_pwd,
                        }
                    if not has_account:
                        continue

                    if len(acc_list) == 1:
                        account = list(account_info.keys())[0]
                        # check if multi tunnel xml by include alpha
                        for _i in account:
                            if _i.isalpha():
                                is_multi_tunnel = True
                                break
                    if is_multi_tunnel:
                        d = sc.query(DIMPreConfs).filter(
                            DIMPreConfs.fake_account == account,
                            DIMPreConfs.day_night == day_night,
                            DIMPreConfs.uid == uid,
                        ).order_by(
                            DIMPreConfs.id.desc()
                        ).first()
                        if not d:
                            logger.error("fake_account:%s day_night=%s" % (account, day_night))
                            continue
                    else:
                        has_conf = True
                        for account, info in account_info.items():
                            d = sc.query(DIMPreConfs).filter(
                                DIMPreConfs.account == account,
                                DIMPreConfs.day_night == day_night,
                                DIMPreConfs.uid == uid,
                            ).order_by(
                                DIMPreConfs.id.desc()
                            ).first()
                            if not d:
                                has_conf = False
                                logger.error("account:%s day_night:%s" % (account, day_night))
                                continue
                        if not has_conf:
                            continue
                    process_ids.append(process.id)

            self.write(json.dumps({
                'code': 0,
                'data': process_ids,
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class TuringBulkDeployConfsListHandler(BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if ('process_ids' not in payload):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        #logger.info('[Trace TuringBulkDeployConfsListHandler] user:%s, payload:%s' % (self.current_user.get('username', 'nobody'), payload))
        try:
            process_ids = payload['process_ids']
            with mysql_sc() as sc:
                for process_id in process_ids:
                    process = sc.query(TuringDeployConfs).filter(
                        TuringDeployConfs.id == process_id
                    ).first()
                    if not process:
                        self.write(json.dumps({
                            'code': 404,
                            'error': 'Process not found.',
                        }))
                        return
                    host = process.host
                    deploy_path = process.deploy_path
                    r = sc.query(
                        TuringPreTraderConfs.valid.label('valid'),
                        TuringPreTraderConfs.script_cpu_valid.label('script_cpu_valid'),
                        TuringPreTraderConfs.script_cpu_bind.label('script_cpu_bind'),
                        TuringPreTraderConfs.config_cpu_valid.label('config_cpu_valid'),
                        TuringPreTraderConfs.config_cpu_bind.label('config_cpu_bind'),
                        TuringPreTraderConfs.day_night.label('day_night'),
                        TuringPreTraderConfs.local_ip.label('local_ip'),
                        TuringPreTraderConfs.local_port.label('local_port'),
                        TuringPreTraderConfs.src_mac.label('src_mac'),
                        TuringPreTraderConfs.nic.label('nic'),
                        TuringPreTraderConfs.account_id.label('account_id'),
                        #Accounts.name.label('account'),
                        #Accounts.password.label('password'),
                        #Accounts.rsp_pwd.label('rsp_pwd'),
                        TuringConfigTemplates.content.label('template'),
                    ).join(
                        TuringServers,
                        TuringPreTraderConfs.server_id == TuringServers.id,
                    #).join(
                    #    Accounts,
                    #    TuringPreTraderConfs.account_id == Accounts.id,
                    ).join(
                        TuringConfigTemplates,
                        TuringPreTraderConfs.config_template_id == TuringConfigTemplates.id,
                    ).filter(
                        TuringPreTraderConfs.deploy_path == deploy_path,
                        TuringServers.ip == host,
                    ).first()
                    if not r:
                        self.write(json.dumps({
                            'code': 1404,
                            'error': 'Data not found.'
                        }))
                        return
                    else:
                        if not r.valid:
                            self.write(json.dumps({
                                'code': 1404,
                                'error': 'invalid pre-config.'
                            }))
                            return
                    acc_list = r.account_id.split(',')
                    account_info = {}
                    for _acc in acc_list:
                        _a = sc.query(Accounts).filter(Accounts.id == int(_acc)).first()
                        if not _a:
                            self.write(json.dumps({
                                'code': 1404,
                                'error': 'account not config.',
                            }))
                            return
                        account_info[_a.name] = {
                            'password': _a.password,
                            'rsp_pwd': _a.rsp_pwd,
                        }

                    day_night = r.day_night
                    daynight = 'day' if day_night == 0 else 'night'
                    #account = r.account
                    #password = r.password
                    #rsp_pwd = r.rsp_pwd or ''
                    config_cpu_bind = r.config_cpu_bind
                    local_ip = r.local_ip
                    local_port = r.local_port
                    src_mac = r.src_mac
                    nic = r.nic
                    template = r.template
                    is_multi_tunnel = False
                    # check if multi tunnel xml by include alpha
                    if len(acc_list) == 1:
                        account = list(account_info.keys())[0]
                        #for account, _ in account_info.items():
                        for _i in account:
                            if _i.isalpha():
                                is_multi_tunnel = True
                                break
                    d = sc.query(DIMPreConfs).filter().order_by(DIMPreConfs.id.desc()).first()
                    if not d:
                        self.write(json.dumps({
                            'code': 404,
                            'error': 'not config.',
                        }))
                        return
                    uid = d.uid
                        
                    if is_multi_tunnel:
                        password = account_info[account]['password']
                        rsp_pwd = account_info[account]['rsp_pwd']
                        #d = sc.query(DIMPreConfs).filter(
                        #    DIMPreConfs.fake_account == account,
                        #    DIMPreConfs.day_night == day_night,
                        #).order_by(
                        #    DIMPreConfs.id.desc()
                        #).first()
                        #if not d:
                        #    self.write(json.dumps({
                        #        'code': 404,
                        #        'error': 'Account not found in pre-config.',
                        #    }))
                        #    return
                        #uid = d.uid
                        lines = sc.query(DIMPreConfs).filter(
                            DIMPreConfs.uid == uid,
                            DIMPreConfs.fake_account == account,
                            DIMPreConfs.day_night == day_night,
                        ).order_by(
                            DIMPreConfs.product.asc()
                        ).all()
                        if len(lines) == 0:
                            self.write(json.dumps({
                                'code': 404,
                                'error': 'Account not found in pre-config.',
                            }))
                            return

                        conf_dict = {}
                        istest = False
                        for line in lines:
                            if line.type == 2:
                                istest = True
                            product = line.product
                            symbol = line.symbol
                            alphamixer = line.alphamixer
                            strategy = line.strategy
                            max_vol = line.max_vol
                            limit_vol = line.limit_vol
                            single_max_vol = line.single_max_vol
                            ev_dim = line.ev_dim
                            ev_data = line.ev_data
                            exchange = line.exchange
                            client_id = line.account
                            if exchange.lower() == 'czce':
                                long_product = 'zz%s' % product.lower()
                            elif exchange.lower() == 'dce':
                                long_product = 'dl%s' % product.lower()
                            elif exchange.lower() == 'shfe':
                                long_product = 'sh%s' % product.lower()
                            else:
                                long_product = product.lower()
                            k = '%s_%s_%s_%s' % (alphamixer, long_product, daynight, symbol)
                            if k not in conf_dict:
                                conf_dict[k] = {
                                    client_id: [{
                                        'strategy': strategy,
                                        'max_vol': max_vol,
                                        'limit_vol': limit_vol,
                                        'single_max_vol': single_max_vol,
                                        'ev_dim': ev_dim,
                                        'ev_data': ev_data,
                                    }],
                                }
                            else:
                                if client_id not in conf_dict[k]:
                                    conf_dict[k][client_id] = [{
                                        'strategy': strategy,
                                        'max_vol': max_vol,
                                        'limit_vol': limit_vol,
                                        'single_max_vol': single_max_vol,
                                        'ev_dim': ev_dim,
                                        'ev_data': ev_data,
                                    }]
                                else:
                                    conf_dict[k][client_id].append({
                                        'strategy': strategy,
                                        'max_vol': max_vol,
                                        'limit_vol': limit_vol,
                                        'single_max_vol': single_max_vol,
                                        'ev_dim': ev_dim,
                                        'ev_data': ev_data,
                                    })
                        pre_content = process.content
                        if not pre_content:
                            content = self.gen_xml_multi(template, conf_dict, account, password, rsp_pwd,
                                    config_cpu_bind, local_ip, local_port, src_mac, nic, istest)
                        else:
                            content = self.gen_xml_multi(template, conf_dict, account, password, rsp_pwd,
                                    config_cpu_bind, local_ip, local_port, src_mac, nic, istest, pre_content)

                    else:
                        conf_dict = {}
                        istest = False
                        for account, info in account_info.items():
                            conf_dict[account] = {}
                            password = info['password']
                            rsp_pwd = info['rsp_pwd']

                            #d = sc.query(DIMPreConfs).filter(
                            #    DIMPreConfs.account == account,
                            #    DIMPreConfs.day_night == day_night,
                            #).order_by(
                            #    DIMPreConfs.id.desc()
                            #).first()
                            #if not d:
                            #    self.write(json.dumps({
                            #        'code': 404,
                            #        'error': 'Account not found in pre-config.',
                            #    }))
                            #    return
                            #uid = d.uid
                            lines = sc.query(DIMPreConfs).filter(
                                DIMPreConfs.uid == uid,
                                DIMPreConfs.account == account,
                                DIMPreConfs.day_night == day_night,
                            ).order_by(
                                DIMPreConfs.product.asc()
                            ).all()
                            if len(lines) == 0:
                                self.write(json.dumps({
                                    'code': 404,
                                    'error': 'Account not found in pre-config.',
                                }))
                                return
                        
                            for line in lines:
                                if line.type == 2:
                                    istest = True
                                product = line.product
                                symbol = line.symbol
                                alphamixer = line.alphamixer
                                strategy = line.strategy
                                max_vol = line.max_vol
                                limit_vol = line.limit_vol
                                single_max_vol = line.single_max_vol
                                ev_dim = line.ev_dim
                                ev_data = line.ev_data
                                exchange = line.exchange
                                if exchange.lower() == 'czce':
                                    long_product = 'zz%s' % product.lower()
                                elif exchange.lower() == 'dce':
                                    long_product = 'dl%s' % product.lower()
                                elif exchange.lower() == 'shfe':
                                    long_product = 'sh%s' % product.lower()
                                else:
                                    long_product = product.lower()
                                k = '%s_%s_%s_%s' % (alphamixer, long_product, daynight, symbol)
                                if k not in conf_dict[account]:
                                    conf_dict[account][k] = {
                                        'ev_dim': ev_dim,
                                        'ev_data': ev_data,
                                        'strategies': [{
                                            'strategy': strategy,
                                            'max_vol': max_vol,
                                            'limit_vol': limit_vol,
                                            'single_max_vol': single_max_vol,
                                            'ev_dim': ev_dim,
                                            'ev_data': ev_data,
                                        }],
                                    }
                                else:
                                    conf_dict[account][k]['strategies'].append({
                                        'strategy': strategy,
                                        'max_vol': max_vol,
                                        'limit_vol': limit_vol,
                                        'single_max_vol': single_max_vol,
                                        'ev_dim': ev_dim,
                                        'ev_data': ev_data,
                                    })
                        pre_content = process.content
                        if not pre_content:
                            content = self.gen_xml(template, conf_dict, account_info,
                                    config_cpu_bind, local_ip, local_port, src_mac, nic, istest)
                        else:
                            content = self.gen_xml(template, conf_dict, account_info,
                                    config_cpu_bind, local_ip, local_port, src_mac, nic, istest, pre_content)
                    process.content = content

            self.write(json.dumps({
                'code': 0,
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def gen_xml_multi(self, template, conf_dict, account, password, rsp_pwd,
                      config_cpu_bind, local_ip, local_port, src_mac, nic, istest, pre_xml=None):
        kdb_obj = KdbQuery()
        now = datetime.datetime.now()
        if now.hour < 18:
            kdb_date = now.strftime('%Y.%m.%d')
        else:
            kdb_date = (now + datetime.timedelta(days=1)).strftime('%Y.%m.%d')

        if not pre_xml:
            root = et.fromstring(template)

            trader_login = root.find('trader_login')
            if trader_login is not None:
                if trader_login.find('local_ip') is not None and local_ip:
                    trader_login.find('local_ip').text = local_ip
                if trader_login.find('local_port') is not None and local_port:
                    trader_login.find('local_port').text = local_port
                if trader_login.find('src_mac') is not None and src_mac:
                    trader_login.find('src_mac').text = src_mac
                if trader_login.find('nic') is not None and nic:
                    trader_login.find('nic').text = nic

            account_node = root.find('tot_account_number/account')
            account_node.find('passwd').text = password

            if account_node.find('x1_rsp_pwd') is not None:
                account_node.find('x1_rsp_pwd').text = rsp_pwd

            if config_cpu_bind:
                for k, v in config_cpu_bind.items():
                    if account_node.find(k) is not None:
                        account_node.find(k).text = v
        else:
            root = et.fromstring(pre_xml)
            account_node = root.find('tot_account_number/account')

        # remove duplicate strategey node
        for node in account_node.findall('strategy')[1:]:
            account_node.remove(node)
        strategy_node = account_node.find('strategy')
        for node in strategy_node.findall('client')[1:]:
            strategy_node.remove(node)
        client_node = strategy_node.find('client')
        for node in client_node.findall('sub_strategy')[1:]:
            client_node.remove(node)

        strategy_node = account_node.find('strategy')
        for _ in range(len(conf_dict) - 1):
            account_node.append(copy.deepcopy(strategy_node))
        strategy_node_list = account_node.findall('strategy')

        for strategy_node, k in zip(strategy_node_list, conf_dict):
            client_dict = conf_dict[k]
            long_product = k.split('_')[1]
            symbol = k.rsplit('_', 1)[1]
            k = k.rsplit('_', 1)[0]
            if symbol in ['R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9',
                    'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20']:
                _tmp = k.split('_')
                k_st = '%s_%s%s_%s' % (_tmp[0], _tmp[1], symbol.replace("R",""), _tmp[2])
            elif symbol == 'R1':
                _tmp = k.split('_')
                k_st = '%s_%s_%s' % (_tmp[0], _tmp[1], _tmp[2])
            else:
                _tmp = k.split('_')
                if symbol.isdigit():
                    if len(symbol) == 6:
                        _rank = kdb_obj.get_cb_rank(kdb_date, symbol)
                    else:
                        _rank = kdb_obj.get_option_rank(kdb_date, symbol)
                else:
                    _rank = kdb_obj.get_symbol_rank(kdb_date, symbol)
                k_st = '%s_%s%s_%s' % (_tmp[0], _tmp[1], '' if int(_rank) == 1 else _rank, _tmp[2])
            if istest:
                so = os.path.join('/home/mycapitaltrade/turing_so/test', k_st + '.so')
            else:
                so = os.path.join('/home/mycapitaltrade/turing_so', k_st + '.so')
            if symbol in ['R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9',
                    'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20']:
                if long_product.upper() in ['CP50ETF', 'CP300ZJ', 'CP300SH', 'CP300SZ']:
                    strategy_node.find('symbol').text = kdb_obj.get_opmain_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                elif long_product.upper() in ['CBSZ', 'CBSH']:
                    strategy_node.find('symbol').text = kdb_obj.get_cb_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                else:
                    strategy_node.find('symbol').text = kdb_obj.get_main_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
            else:
                strategy_node.find('symbol').text = symbol
            strategy_node.find('strategy_so').text = so

            client_node = strategy_node.find('client')
            for _ in range(len(client_dict) - 1):
                strategy_node.append(copy.deepcopy(client_node))
            client_node_list = strategy_node.findall('client')
            for client_node, c_id in zip(client_node_list, client_dict):
                client_node.find('client_id').text = c_id
                alpha_dict = client_dict[c_id]
                sub_strategy_node = client_node.find('sub_strategy')
                for _ in range(len(alpha_dict) - 1):
                    client_node.append(copy.deepcopy(sub_strategy_node))
                sub_strategy_node_list = client_node.findall('sub_strategy')
                for node, st_dict in zip(sub_strategy_node_list, alpha_dict):
                    node.find('strat_name').text = st_dict['strategy']
                    node.find('max_pos').text = str(st_dict['max_vol'])
                    node.find('single_side_max_pos_limit').text = str(st_dict['single_max_vol'])
                    node.find('lock_pos_single_side_max_pos').text = str(st_dict['single_max_vol'])
                    ev_list = []
                    ev_dim = st_dict.get('ev_dim', '')
                    ev_data = st_dict.get('ev_data', '')
                    if ev_dim:
                        if istest:
                            ev_list.append(os.path.join('/home/mycapitaltrade/turing_ev/test', ev_dim))
                        else:
                            ev_list.append(os.path.join('/home/mycapitaltrade/turing_ev', ev_dim))
                    if ev_data:
                        ev_list.append(os.path.join('/home/mycapitaltrade/db_file', ev_data))
                    ev = '|'.join(ev_list)
                    node.find('strategy_ev_file').text = ev

        return '<?xml version="1.0" encoding="utf-8"?>\n' + str(et.tostring(root, 'utf-8'), 'utf-8')

    def gen_xml(self, template, conf_dict, account_info,
                config_cpu_bind, local_ip, local_port, src_mac, nic, istest, pre_xml=None):
        is_multi = False
        if len(account_info.keys()) > 1:
            is_multi = True

        kdb_obj = KdbQuery()
        now = datetime.datetime.now()
        if now.hour < 18:
            kdb_date = now.strftime('%Y.%m.%d')
        else:
            kdb_date = (now + datetime.timedelta(days=1)).strftime('%Y.%m.%d')

        if not pre_xml:
            root = et.fromstring(template)

            if not is_multi:
                trader_login = root.find('trader_login')
                if trader_login is not None:
                    if trader_login.find('local_ip') is not None and local_ip:
                        trader_login.find('local_ip').text = local_ip
                    if trader_login.find('local_port') is not None and local_port:
                        trader_login.find('local_port').text = local_port
                    if trader_login.find('src_mac') is not None and src_mac:
                        trader_login.find('src_mac').text = src_mac
                    if trader_login.find('nic') is not None and nic:
                        trader_login.find('nic').text = nic

            #account_node = root.find('tot_account_number/account')
            #account_node.find('user_id').text = account
            #account_node.find('passwd').text = password

            #if account_node.find('x1_rsp_pwd') is not None:
            #    account_node.find('x1_rsp_pwd').text = rsp_pwd

            #if account_node.find('fund_account_id') is not None:
            #    account_node.find('fund_account_id').text = account

            if config_cpu_bind:
                for k, v in config_cpu_bind.items():
                    if account_node.find(k) is not None:
                        account_node.find(k).text = v

            tot_node = root.find('tot_account_number')

            # remove duplicate account node
            tot_node = root.find('tot_account_number')
            for node in tot_node.findall('account')[1:]:
                tot_node.remove(node)
            account_node = tot_node.find('account')
            # remove duplicate strategey node
            for node in account_node.findall('strategy')[1:]:
                account_node.remove(node)
            strategy_node = account_node.find('strategy')
            for node in strategy_node.findall('sub_strategy')[1:]:
                strategy_node.remove(node)

            account_node = tot_node.find('account')
            for _ in range(len(account_info) - 1):
                tot_node.append(copy.deepcopy(account_node))
            account_node_list = tot_node.findall('account')

            for account_node, account in zip(account_node_list, account_info):
                a = account_info[account]
                password = a['password']
                rsp_pwd = a['rsp_pwd']
                if account_node.find('client_id') is not None:
                    account_node.find('user_id').text = 'xele_trade'
                    account_node.find('client_id').text = account
                else:
                    account_node.find('user_id').text = account
                account_node.find('passwd').text = password
                if account_node.find('x1_rsp_pwd') is not None:
                    account_node.find('x1_rsp_pwd').text = rsp_pwd
                if account_node.find('fund_account_id') is not None:
                    account_node.find('fund_account_id').text = account
                if account_node.find('investor_id') is not None:
                    account_node.find('investor_id').text = account

                if is_multi:
                    trader_login = account_node.find('trader_login')
                    if trader_login is not None:
                        if trader_login.find('local_ip') is not None and local_ip:
                            trader_login.find('local_ip').text = local_ip
                        if trader_login.find('local_port') is not None and local_port:
                            trader_login.find('local_port').text = local_port
                        if trader_login.find('src_mac') is not None and src_mac:
                            trader_login.find('src_mac').text = src_mac
                        if trader_login.find('nic') is not None and nic:
                            trader_login.find('nic').text = nic

        else:
            root = et.fromstring(pre_xml)
            #account_node = root.find('tot_account_number/account')
            tot_node = root.find('tot_account_number')
            account_node_list = tot_node.findall('account')

        for account_node in account_node_list:
            if account_node.find('client_id') is not None:
                account = account_node.find('client_id').text
            else:
                account = account_node.find('user_id').text
            # remove duplicate strategey node
            for node in account_node.findall('strategy')[1:]:
                account_node.remove(node)
            strategy_node = account_node.find('strategy')
            for node in strategy_node.findall('sub_strategy')[1:]:
                strategy_node.remove(node)

            strategy_node = account_node.find('strategy')
            for _ in range(len(conf_dict[account]) - 1):
                account_node.append(copy.deepcopy(strategy_node))
            strategy_node_list = account_node.findall('strategy')

            for strategy_node, k in zip(strategy_node_list, conf_dict[account]):
                alpha_dict = conf_dict[account][k]
                long_product = k.split('_')[1]
                symbol = k.rsplit('_', 1)[1]
                k = k.rsplit('_', 1)[0]
                ev_list = []
                ev_dim = alpha_dict.get('ev_dim', '')
                ev_data = alpha_dict.get('ev_data', '')
                if ev_dim:
                    if istest:
                        ev_list.append(os.path.join('/home/mycapitaltrade/turing_ev/test', ev_dim))
                    else:
                        ev_list.append(os.path.join('/home/mycapitaltrade/turing_ev', ev_dim))
                if ev_data:
                    ev_list.append(os.path.join('/home/mycapitaltrade/db_file', ev_data))
                ev = '|'.join(ev_list)
                if symbol in ['R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9',
                        'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20']:
                    _tmp = k.split('_')
                    k_st = '%s_%s%s_%s' % (_tmp[0], _tmp[1], symbol.replace("R",""), _tmp[2])
                elif symbol == 'R1':
                    _tmp = k.split('_')
                    k_st = '%s_%s_%s' % (_tmp[0], _tmp[1], _tmp[2])
                else:
                    _tmp = k.split('_')
                    if symbol.isdigit():
                        if len(symbol) == 6:
                            _rank = kdb_obj.get_cb_rank(kdb_date, symbol)
                        else:
                            _rank = kdb_obj.get_option_rank(kdb_date, symbol)
                    else:
                        _rank = kdb_obj.get_symbol_rank(kdb_date, symbol)
                    k_st = '%s_%s%s_%s' % (_tmp[0], _tmp[1], '' if int(_rank) == 1 else _rank, _tmp[2])
                if 'relay' in k_st:
                    k_st = '%s_%s' % (k_st, account)
                if istest:
                    so = os.path.join('/home/mycapitaltrade/turing_so/test', k_st + '.so')
                else:
                    so = os.path.join('/home/mycapitaltrade/turing_so', k_st + '.so')
                if symbol in ['R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9',
                        'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20']:
                    if long_product.upper() in ['CP50ETF', 'CP300ZJ', 'CP300SH', 'CP300SZ']:
                        strategy_node.find('symbol').text = kdb_obj.get_opmain_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                    elif long_product.upper() in ['CBSZ', 'CBSH']:
                        strategy_node.find('symbol').text = kdb_obj.get_cb_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                    else:
                        strategy_node.find('symbol').text = kdb_obj.get_main_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                else:
                    strategy_node.find('symbol').text = symbol
                strategy_node.find('strategy_so').text = so
                if strategy_node.find('strategy_ev_file') is not None:
                    strategy_node.find('strategy_ev_file').text = ev

                if long_product == 'dli' and strategy_node.find('max_accum_open_vol') is not None:
                    strategy_node.find('max_accum_open_vol').text = '100000'

                sub_strategy_node = strategy_node.find('sub_strategy')
                for _ in range(len(alpha_dict['strategies']) - 1):
                    strategy_node.append(copy.deepcopy(sub_strategy_node))
                sub_strategy_node_list = strategy_node.findall('sub_strategy')
                for node, st_dict in zip(sub_strategy_node_list, alpha_dict['strategies']):
                    node.find('strat_name').text = st_dict['strategy']
                    node.find('max_pos').text = str(st_dict['max_vol'])
                    node.find('single_side_max_pos_limit').text = str(st_dict['single_max_vol'])
                    node.find('lock_pos_single_side_max_pos').text = str(st_dict['single_max_vol'])
                    st_ev_list = []
                    ev_dim = st_dict.get('ev_dim', '')
                    ev_data = st_dict.get('ev_data', '')
                    if ev_dim:
                        if istest:
                            st_ev_list.append(os.path.join('/home/mycapitaltrade/turing_ev/test', ev_dim))
                        else:
                            st_ev_list.append(os.path.join('/home/mycapitaltrade/turing_ev', ev_dim))
                    if ev_data:
                        st_ev_list.append(os.path.join('/home/mycapitaltrade/db_file', ev_data))
                    st_ev = '|'.join(st_ev_list)
                    if node.find('strategy_ev_file') is not None:
                        node.find('strategy_ev_file').text = st_ev

        return '<?xml version="1.0" encoding="utf-8"?>\n' + str(et.tostring(root, 'utf-8'), 'utf-8')


class TuringModelSettingsHandler(BaseHandler):

    def get(self, *args, **kwargs):
        host = self.get_argument('host', None)
        day_night = self.get_argument('day_night', None)
        if not host or not day_night:
            self.write(json.dumps({
                'code': 400,
                'error': 'payload data error.',
            }))
            return
        turing_xml_list = []
        with mysql_sc() as sc:
            lines = sc.query(TuringDeployConfs).filter(
                TuringDeployConfs.host == host,
                TuringDeployConfs.day_night == day_night,
            )
            for line in lines:
                if line.content:
                    turing_xml_list.append(line.content)
        res = generate_modelsettings(turing_xml_list)
        self.write(json.dumps({
            'code': 0,
            'data': res,
        }))


class TuringPreForwarderConfsListHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringPreForwarderConfs
        self.fields = {
            'name': 'name',
            'deploy_path': 'deploy_path',
            'valid': 'valid',
            'server_id': 'server_id',
        }

    def get(self, *args, **kwargs):
        res = []
        server_id = int(self.get_argument('server_id', '0'))
        with mysql_sc() as sc:
            if server_id > 0:
                lines = sc.query(self.model).filter(self.model.server_id == server_id)
            else:
                lines = sc.query(self.model)
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if sorted(payload.keys()) != sorted(self.fields.values()):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return
        try:
            data = {}
            for k, v in self.fields.items():
                data[k] = payload[v]
            with mysql_sc() as sc:
                if payload['valid']:
                    if sc.query(self.model).filter(
                        self.model.server_id == payload['server_id'],
                        self.model.valid == True,
                    ).first():
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Only one available agent.'
                        }))
                        return
                o = self.model(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class TuringPreForwarderConfsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = TuringPreForwarderConfs
        self.fields = {
            'name': 'name',
            'deploy_path': 'deploy_path',
            'valid': 'valid',
            'server_id': 'server_id',
        }

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                if payload['valid']:
                    if sc.query(self.model).filter(
                        self.model.id != kwargs['id'],
                        self.model.server_id == payload['server_id'],
                        self.model.valid == True,
                    ).first():
                        self.write(json.dumps({
                            'code': 400,
                            'error': 'Only one available agent.'
                        }))
                        return
                o = sc.query(self.model).filter_by(id=kwargs['id']).first()
                if o:
                    if payload['valid'] == False or \
                       payload['server_id'] != o.server_id or \
                       payload['deploy_path'] != o.deploy_path:
                        q = sc.query(TuringDeployConfs).join(
                            TuringServers, TuringServers.ip == TuringDeployConfs.host,
                        ).filter(
                            TuringDeployConfs.deploy_path == o.deploy_path,
                            TuringServers.id == o.server_id,
                        ).first()
                        if q:
                            q.valid = False
                    for k, v in self.fields.items():
                        if v in payload:
                            setattr(o, k, payload[v])
                    sc.commit()
                    self.write(json.dumps({
                        'code': 0,
                        'data': o.to_dict(),
                    }))
                else:
                    self.write(json.dumps({
                        'code': 404,
                        'error': 'Data not found.',
                    }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                o = sc.query(TuringDeployConfs).join(
                    TuringServers, TuringServers.ip == TuringDeployConfs.host,
                ).join(self.model,
                    self.model.deploy_path == TuringDeployConfs.deploy_path,
                ).filter(
                    self.model.server_id == TuringServers.id,
                    self.model.id == kwargs['id'],
                ).order_by(self.model.id.desc()).first()
                if o:
                    o.valid = False
                sc.query(self.model).filter_by(id=kwargs['id']).delete()
                self.write(json.dumps({
                    'code': 0,
                    'data': 1,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class TuringDynamicModifyMaxPosHandler(BaseHandler):

    def check_user_permission(self):
        if self.current_user['id'] in [21, 38]:
            return True
        return False

    def post(self, *args, **kwargs):
        if not self.check_user_permission():
            self.write(json.dumps({
                'code': 400,
                'error': 'No permission.',
            }))
            return

        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if 'account' not in payload or 'max_pos' not in payload:
            self.write(json.dumps({
                'code': 500,
                'error': 'payload data error',
            }))
            return

        vid = int(payload.get('vid', 0))
        account_name = str(payload['account'])
        if '-' in account_name:
            account_name, vid = account_name.split('-')
            vid = int(vid)
        if len(account_name) == 12:
            account_name = str(int(account_name))

        max_pos = int(payload['max_pos'])
        symbol = payload.get('symbol', 'ALL')

        now = datetime.datetime.now()
        if now.hour > 8 and now.hour < 16:
            day_night = 0
        elif now.hour > 20 or now.hour < 3:
            day_night = 1
        else:
            self.write(json.dumps({
                'code': 500,
                'error': 'no trading time',
            }))
            return

        kdb = KdbQuery()
        trading_date = kdb.get_trading_date(hour=21)

        with mysql_sc() as sc:
            account = sc.query(Accounts.id).filter(
                Accounts.name == account_name,
            ).first()
            if not account:
                self.write(json.dumps({
                    'code': 500,
                    'error': 'account(%s) not found' % account_name,
                }))
                return
            account_id = account.id

            if sc.query(TuringPreTraderConfs).filter(
                TuringPreTraderConfs.valid == 1,
                TuringPreTraderConfs.day_night == day_night,
                or_(
                    TuringPreTraderConfs.account_id.like('%{},%'.format(account_id)),
                    TuringPreTraderConfs.account_id.like('%,{},%'.format(account_id)),
                    TuringPreTraderConfs.account_id.like('%,{}%'.format(account_id)),
                    TuringPreTraderConfs.account_id == account_id,
                )
            ).first():
                account_type = 1 # is turing
            elif sc.query(GalileoPreTraderConfs).filter(
                GalileoPreTraderConfs.valid == 1,
                GalileoPreTraderConfs.type == 2,
                GalileoPreTraderConfs.day_night == day_night,
                GalileoPreTraderConfs.account == account_id,
            ).first():
                account_type = 2 # is galileo
            else:
                self.write(json.dumps({
                    'code': 404,
                    'error': 'account configuration not found.',
                }))
                return

            if account_type == 1:
                process = sc.query(
                    TuringDeployConfs.id,
                    TuringDeployConfs.host,
                ).join(
                    TuringServers,
                    TuringServers.ip == TuringDeployConfs.host,
                ).join(
                    TuringPreTraderConfs,
                    and_(
                        TuringPreTraderConfs.deploy_path == TuringDeployConfs.deploy_path,
                        TuringPreTraderConfs.server_id == TuringServers.id,
                        TuringPreTraderConfs.valid == 1,
                    )
                ).filter(
                    TuringDeployConfs.valid == 1,
                    TuringDeployConfs.day_night == day_night,
                    TuringPreTraderConfs.day_night == day_night,
                    or_(
                        TuringPreTraderConfs.account_id.like('%{},%'.format(account_id)),
                        TuringPreTraderConfs.account_id.like('%,{},%'.format(account_id)),
                        TuringPreTraderConfs.account_id.like('%,{}%'.format(account_id)),
                        TuringPreTraderConfs.account_id == account_id,
                    )
                ).first()
                if not process:
                    self.write(json.dumps({
                        'code': 500,
                        'error': 'process not found: day_night %s, account %s' % (day_night, account_name),
                    }))
                    return

                process_id = process.id
                ip = process.host
                seq = int(datetime.datetime.now().strftime('%y%m%d%H%M%S%f')[:-3])

                queue = 'oss:a:cmd:%s' % ip
                cmd = {
                    'type': 11,
                    'seq': seq,
                    'data': {
                        'process_id': process_id,
                        'account': account_name,
                        'symbol': symbol,
                        'max_pos': max_pos,
                    }
                }
                if not rpush_redis_cmd(config.redis, ip, json.dumps(cmd)):
                    self.write(json.dumps({
                        'code': 500,
                        'error': 'send cmd error: ip %s, cmd %s' % (ip, cmd)
                    }))
                    return

                logger.info("[SEND CMD] %s, %s" % (ip, cmd))

                data = {
                    'type': 11,
                    'seq': seq,
                    'cmd': cmd,
                    'execute': 1,
                    'current_date': trading_date,
                    'day_night': day_night,
                    'r_create_user': self.current_user['username'],
                }
                sc.add(TuringCommandLogs(**data))

            elif account_type == 2:
                processes = sc.query(
                    TuringDeployConfs.id.label('id'),
                    TuringDeployConfs.host.label('host'),
                    GalileoPreTraderConfs.account_id.label('v_account_id'),
                ).join(
                    TuringServers,
                    TuringServers.ip == TuringDeployConfs.host,
                ).join(
                    GalileoPreTraderConfs,
                    and_(
                        GalileoPreTraderConfs.deploy_path == TuringDeployConfs.deploy_path,
                        GalileoPreTraderConfs.server_id == TuringServers.id,
                        GalileoPreTraderConfs.valid == 1,
                        GalileoPreTraderConfs.type == 2,
                    )
                ).filter(
                    TuringDeployConfs.valid == 1,
                    TuringDeployConfs.day_night == day_night,
                    GalileoPreTraderConfs.account == account_id,
                )

                if not processes.all():
                    self.write(json.dumps({
                        'code': 500,
                        'error': 'process not found: day_night %s, account %s' % (day_night, account_name),
                    }))
                    return

                if vid > 0:
                    conf = sc.query(DIMPreConfs.v_account_id).filter(
                        DIMPreConfs.account_id == vid,
                        DIMPreConfs.account == account_name,
                        DIMPreConfs.day_night == day_night,
                        DIMPreConfs.status == 1,
                    ).order_by(
                        DIMPreConfs.id.desc(),
                    ).first()
                    if not conf:
                        self.write(json.dumps({
                            'code': 500,
                            'error': 'dim configuration not found',
                        }))
                        return
                    processes = processes.filter(
                        GalileoPreTraderConfs.account_id == conf.v_account_id,
                    )

                last_conf = sc.query(DIMPreConfs.uid).filter(
                    DIMPreConfs.account == account_name,
                    DIMPreConfs.day_night == day_night,
                    DIMPreConfs.status == 1,
                ).order_by(
                    DIMPreConfs.id.desc(),
                ).first()
                if not last_conf:
                    self.write(json.dumps({
                        'code': 500,
                        'error': 'dim configuration not found',
                    }))
                    return

                last_uid = last_conf.uid

                for process in processes:
                    process_id = process.id
                    ip = process.host
                    v_account_id = process.v_account_id
                    conf = sc.query(DIMPreConfs.account_id).filter(
                        DIMPreConfs.v_account_id == v_account_id,
                        DIMPreConfs.account == account_name,
                        DIMPreConfs.day_night == day_night,
                        DIMPreConfs.uid == last_uid,
                    ).order_by(
                        DIMPreConfs.id.desc(),
                    ).first()
                    if not conf:
                        logger.info("TuringDynamicModifyMaxPosHandler DEBUG, %s %s %s %s" % (process_id, ip, account_name, v_account_id))
                        continue
                    vid = conf.account_id

                    seq = int(datetime.datetime.now().strftime('%y%m%d%H%M%S%f')[:-3])
                    queue = 'oss:a:cmd:%s' % ip
                    cmd = {
                        'type': 11,
                        'seq': seq,
                        'data': {
                            'process_id': process_id,
                            'account': account_name,
                            'symbol': symbol,
                            'max_pos': max_pos,
                            'vid': vid,
                        }
                    }
                    if not rpush_redis_cmd(config.redis, ip, json.dumps(cmd)):
                        self.write(json.dumps({
                            'code': 500,
                            'error': 'send cmd error: ip %s, cmd %s' % (ip, cmd)
                        }))
                        return
                    logger.info("[SEND CMD] %s, %s" % (ip, cmd))

                    data = {
                        'type': 11,
                        'seq': seq,
                        'cmd': cmd,
                        'execute': 1,
                        'current_date': trading_date,
                        'day_night': day_night,
                        'r_create_user': self.current_user['username'],
                    }
                    sc.add(TuringCommandLogs(**data))

        self.write(json.dumps({
            'code': 0,
            'data': '',
        }))


class TuringDynamicModifyMaxPosBySymbolHandler(BaseHandler):

    def check_user_permission(self):
        if self.current_user['id'] in [21, 38]:
            return True
        return False

    def post(self, *args, **kwargs):
        if not self.check_user_permission():
            self.write(json.dumps({
                'code': 400,
                'error': 'No permission.',
            }))
            return

        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        if 'accounts' not in payload or 'max_pos' not in payload or 'symbol' not in payload:
            self.write(json.dumps({
                'code': 500,
                'error': 'payload data error',
            }))
            return

        max_pos = int(payload['max_pos'])
        symbol = str(payload['symbol'])

        now = datetime.datetime.now()
        if now.hour > 8 and now.hour < 16:
            day_night = 0
        elif now.hour > 20 or now.hour < 3:
            day_night = 1
        else:
            self.write(json.dumps({
                'code': 500,
                'error': 'no trading time',
            }))
            return

        kdb = KdbQuery()
        trading_date = kdb.get_trading_date(hour=21)

        offset = 0
        for acc in payload['accounts']:
            offset += 1
            account_name = str(acc)
            if '-' in account_name:
                account_name, vid = account_name.split('-')
                vid = int(vid)
            else:
                vid = 0
            if len(account_name) == 12:
                account_name = str(int(account_name))
            with mysql_sc() as sc:
                account = sc.query(Accounts.id).filter(
                    Accounts.name == account_name,
                ).first()
                if not account:
                    self.write(json.dumps({
                        'code': 500,
                        'error': 'account(%s) not found' % account_name,
                    }))
                    return
                account_id = account.id

                if sc.query(TuringPreTraderConfs).filter(
                    TuringPreTraderConfs.valid == 1,
                    TuringPreTraderConfs.day_night == day_night,
                    or_(
                        TuringPreTraderConfs.account_id.like('%{},%'.format(account_id)),
                        TuringPreTraderConfs.account_id.like('%,{},%'.format(account_id)),
                        TuringPreTraderConfs.account_id.like('%,{}%'.format(account_id)),
                        TuringPreTraderConfs.account_id == account_id,
                    )
                ).first():
                    account_type = 1 # is turing
                elif sc.query(GalileoPreTraderConfs).filter(
                    GalileoPreTraderConfs.valid == 1,
                    GalileoPreTraderConfs.type == 2,
                    GalileoPreTraderConfs.day_night == day_night,
                    GalileoPreTraderConfs.account == account_id,
                ).first():
                    account_type = 2 # is galileo
                else:
                    continue

                if account_type == 1:
                    process = sc.query(
                        TuringDeployConfs.id,
                        TuringDeployConfs.host,
                    ).join(
                        TuringServers,
                        TuringServers.ip == TuringDeployConfs.host,
                    ).join(
                        TuringPreTraderConfs,
                        and_(
                            TuringPreTraderConfs.deploy_path == TuringDeployConfs.deploy_path,
                            TuringPreTraderConfs.server_id == TuringServers.id,
                            TuringPreTraderConfs.valid == 1,
                        )
                    ).filter(
                        TuringDeployConfs.valid == 1,
                        TuringDeployConfs.day_night == day_night,
                        TuringPreTraderConfs.day_night == day_night,
                        or_(
                            TuringPreTraderConfs.account_id.like('%{},%'.format(account_id)),
                            TuringPreTraderConfs.account_id.like('%,{},%'.format(account_id)),
                            TuringPreTraderConfs.account_id.like('%,{}%'.format(account_id)),
                            TuringPreTraderConfs.account_id == account_id,
                        )
                    ).first()
                    if not process:
                        self.write(json.dumps({
                            'code': 500,
                            'error': 'process not found: day_night %s, account %s' % (day_night, account_name),
                        }))
                        return
                    process_id = process.id
                    ip = process.host
                    seq = int(datetime.datetime.now().strftime('%m%d%H%M%S%f')[:-3]) * 10000 + offset * 100

                    queue = 'oss:a:cmd:%s' % ip
                    cmd = {
                        'type': 11,
                        'seq': seq,
                        'data': {
                            'process_id': process_id,
                            'account': account_name,
                            'symbol': symbol,
                            'max_pos': max_pos,
                        }
                    }
                    if not rpush_redis_cmd(config.redis, ip, json.dumps(cmd)):
                        self.write(json.dumps({
                            'code': 500,
                            'error': 'send cmd error: ip %s, cmd %s' % (ip, cmd)
                        }))
                        return

                    logger.info("[SEND CMD] %s, %s" % (ip, cmd))

                    data = {
                        'type': 11,
                        'seq': seq,
                        'cmd': cmd,
                        'execute': 1,
                        'current_date': trading_date,
                        'day_night': day_night,
                        'r_create_user': self.current_user['username'],
                    }
                    sc.add(TuringCommandLogs(**data))

                elif account_type == 2:
                    seq = int(datetime.datetime.now().strftime('%m%d%H%M%S%f')[:-3]) * 10000 + offset * 100
                    processes = sc.query(
                        TuringDeployConfs.id,
                        TuringDeployConfs.host,
                        GalileoPreTraderConfs.account_id.label('v_account_id'),
                    ).join(
                        TuringServers,
                        TuringServers.ip == TuringDeployConfs.host,
                    ).join(
                        GalileoPreTraderConfs,
                        and_(
                            GalileoPreTraderConfs.deploy_path == TuringDeployConfs.deploy_path,
                            GalileoPreTraderConfs.server_id == TuringServers.id,
                            GalileoPreTraderConfs.valid == 1,
                            GalileoPreTraderConfs.type == 2,
                        )
                    ).filter(
                        TuringDeployConfs.valid == 1,
                        TuringDeployConfs.day_night == day_night,
                        GalileoPreTraderConfs.account == account_id,
                    )

                    if not processes.all():
                        self.write(json.dumps({
                            'code': 500,
                            'error': 'process not found: day_night %s, account %s' % (day_night, account_name),
                        }))
                        return

                    if vid > 0:
                        conf = sc.query(DIMPreConfs.v_account_id).filter(
                            DIMPreConfs.account_id == vid,
                            DIMPreConfs.account == account_name,
                            DIMPreConfs.day_night == day_night,
                            DIMPreConfs.status == 1,
                        ).order_by(
                            DIMPreConfs.id.desc(),
                        ).first()
                        if not conf:
                            self.write(json.dumps({
                                'code': 500,
                                'error': 'dim configuration not found',
                            }))
                            return
                        processes = processes.filter(
                            GalileoPreTraderConfs.account_id == conf.v_account_id,
                        )

                    last_conf = sc.query(DIMPreConfs.uid).filter(
                        DIMPreConfs.account == account_name,
                        DIMPreConfs.day_night == day_night,
                        DIMPreConfs.status == 1,
                    ).order_by(
                        DIMPreConfs.id.desc(),
                    ).first()
                    if not last_conf:
                        self.write(json.dumps({
                            'code': 500,
                            'error': 'dim configuration not found',
                        }))
                        return
                    last_uid = last_conf.uid

                    offset1 = 0
                    for process in processes:
                        offset1 += 1
                        process_id = process.id
                        ip = process.host
                        v_account_id = process.v_account_id
                        conf = sc.query(DIMPreConfs.account_id).filter(
                            DIMPreConfs.v_account_id == v_account_id,
                            DIMPreConfs.account == account_name,
                            DIMPreConfs.day_night == day_night,
                            DIMPreConfs.uid == last_uid,
                        ).order_by(
                            DIMPreConfs.id.desc(),
                        ).first()
                        if not conf:
                            logger.info("TuringDynamicModifyMaxPosBySymbolHandler DEBUG, %s %s %s %s" % (process_id, ip, account_name, v_account_id))
                            continue
                        vid = conf.account_id

                        seq = seq + offset1
                        queue = 'oss:a:cmd:%s' % ip
                        cmd = {
                            'type': 11,
                            'seq': seq,
                            'data': {
                                'process_id': process_id,
                                'account': account_name,
                                'symbol': symbol,
                                'max_pos': max_pos,
                                'vid': vid
                            }
                        }
                        if not rpush_redis_cmd(config.redis, ip, json.dumps(cmd)):
                            self.write(json.dumps({
                                'code': 500,
                                'error': 'send cmd error: ip %s, cmd %s' % (ip, cmd)
                            }))
                            return
                        logger.info("[SEND CMD] %s, %s" % (ip, cmd))
                        data = {
                            'type': 11,
                            'seq': seq,
                            'cmd': cmd,
                            'execute': 1,
                            'current_date': trading_date,
                            'day_night': day_night,
                            'r_create_user': self.current_user['username'],
                        }
                        sc.add(TuringCommandLogs(**data))

        self.write(json.dumps({
            'code': 0,
            'data': '',
        }))

class TuringDynamicModifyMaxPosResponseHandler(BaseHandler):

    def check_user_permission(self):
        if self.current_user['id'] in [21, 38, 11]:
            return True
        return False

    def get(self, *args, **kwargs):
        if not self.check_user_permission():
            self.write(json.dumps({
                'code': 400,
                'error': 'No permission.',
            }))
            return

        now = datetime.datetime.now()
        kdb = KdbQuery()
        trading_date = kdb.get_trading_date(hour=21)
        ret = []
        with mysql_sc() as sc:
            cmds = sc.query(TuringCommandLogs).filter(
                TuringCommandLogs.type == 11,
                TuringCommandLogs.current_date == trading_date,
            ).order_by(
                TuringCommandLogs.id.desc(),
            )
            for r in cmds:
                execute = r.execute
                cmd = r.cmd
                r_create_user = r.r_create_user
                r_create_time = r.r_create_time.strftime('%Y-%m-%d %H:%M:%S')
                if not cmd.get('data', {}):
                    continue
                account = cmd['data'].get('account', 'UNKOWN')
                vid = cmd['data'].get('vid', None)
                if vid is not None:
                    account = '%s-%s' % (account, vid)
                symbol = cmd['data'].get('symbol', 'UNKOWN')
                if symbol == 'ALL':
                    symbol = 'all'
                max_pos = cmd['data'].get('max_pos', 'UNKOWN')
                if execute == -1:
                    status = 'FAILED'
                elif execute == 0:
                    status = 'DONE'
                elif execute == 1:
                    status = 'DOING'
                    if (now - parse(r_create_time)).total_seconds() > 5 * 60:
                        r.execute = 2
                        status = 'OVER TIME'
                elif execute == 2:
                    status = 'OVER TIME'
                else:
                    status = 'UNKOWN'
                msg = '{} {} sent, {} {} {}        [{}]'.format(r_create_time, r_create_user, account, symbol, max_pos, status)
                ret.append({
                    'msg': msg,
                    'status': status,
                })

        self.write(json.dumps({
            'code': 0,
            'data': ret,
        }))

class TuringGenQuoteConfsHandler(BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))

        if ('server' not in payload) or \
           ('source' not in payload) or \
           ('deploy_path' not in payload):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return

        try:
            kdb_obj = KdbQuery()
            now = datetime.datetime.now()
            if now.hour < 18:
                kdb_date = now.strftime('%Y.%m.%d')
            else:
                kdb_date = (now + datetime.timedelta(days=1)).strftime('%Y.%m.%d')

            host = payload['server']
            deploy_path = payload['deploy_path']
            source = payload['source']
            config = ''

            if int(source) == 1:
                with mysql_sc() as sc:
                    r = sc.query(TuringDeployConfs).filter(
                        TuringDeployConfs.host == host,
                        TuringDeployConfs.deploy_path == deploy_path,
                    ).order_by(
                        TuringDeployConfs.id.desc()
                    ).first()
                    if r:
                        config = r.content
            else:
                with mysql_sc() as sc:
                    r = sc.query(
                        TuringPreToolConfs.valid.label('valid'),
                        TuringPreToolConfs.day_night.label('day_night'),
                        TuringPreToolConfs.script_cpu_valid.label('script_cpu_valid'),
                        TuringPreToolConfs.script_cpu_bind.label('script_cpu_bind'),
                        TuringPreToolConfs.product_list.label('product_list'),
                        TuringConfigTemplates.content.label('template'),
                    ).join(
                        TuringServers,
                        TuringPreToolConfs.server_id == TuringServers.id,
                    ).join(
                        TuringConfigTemplates,
                        TuringPreToolConfs.config_template_id == TuringConfigTemplates.id,
                    ).filter(
                        TuringPreToolConfs.deploy_path == deploy_path,
                        TuringServers.ip == host,
                    ).first()
                    if not r:
                        self.write(json.dumps({
                            'code': 1404,
                            'error': 'Data not found.'
                        }))
                        return
                    if not r.valid:
                        self.write(json.dumps({
                            'code': 1404,
                            'error': 'invalid pre-config.'
                        }))
                        return
                    template = r.template
                    if not template:
                        self.write(json.dumps({
                            'code': 1404,
                            'error': 'template content is null.'
                        }))
                        return
                    symbol_list = []
                    for p, ranks in r.product_list.items():
                        if ranks == 'all':
                            if p.endswith('50ETF'):
                                symbols = ["SH" + s for s in kdb_obj.get_all_opmain_code(kdb_date, p.lower())]
                            elif p.endswith('300SH'): 
                                symbols = ["SH" + s for s in kdb_obj.get_all_opmain_code(kdb_date, p.lower())]
                            elif p.endswith('300SZ'):
                                symbols = ["SZ" + s for s in kdb_obj.get_all_opmain_code(kdb_date, p.lower())]
                            elif p.endswith('300ZJ'):
                                symbols = kdb_obj.get_all_opmain_code(kdb_date, p.lower())
                            symbol_list.extend(symbols)
                        else:
                            for rank in ranks.split(','):
                                if p.endswith('.SH') or p.endswith('.SZ'):
                                    symbol = p.upper()
                                elif p.endswith('_F'):
                                    prod = p.split('_')[0]
                                    symbol = kdb_obj.get_fmain_code(kdb_date, prod.upper(), int(rank))
                                elif p.endswith('50ETF'): 
                                    symbol = kdb_obj.get_opmain_code(kdb_date, p.lower(), int(rank))
                                    symbol = 'SH%s' % symbol
                                elif p.endswith('300SH'):
                                    symbol = kdb_obj.get_opmain_code(kdb_date, p.lower(), int(rank))
                                    symbol = 'SH%s' % symbol
                                elif p.endswith('300SZ'):
                                    symbol = kdb_obj.get_opmain_code(kdb_date, p.lower(), int(rank))
                                    symbol = 'SZ%s' % symbol
                                elif p.endswith('300ZJ'):
                                    symbol = kdb_obj.get_opmain_code(kdb_date, p.lower(), int(rank))
                                elif p.upper() == 'CBSZ' or p.upper() == 'CBSH':
                                    symbol = kdb_obj.get_cb_code(kdb_date, p.lower(), int(rank))
                                else:
                                    symbol = kdb_obj.get_main_code(kdb_date, p.lower(), int(rank))
                                symbol_list.append(symbol)

                config = self.gen_quote_conf(template, symbol_list, kdb_obj)
                if config is None:
                    self.write(json.dumps({
                        'code': 1404,
                        'error': 'gen config failed.'
                    }))
                    return

            self.write(json.dumps({
                'code': 0,
                'data': {
                    'xml': config,
                },
            }))

        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def gen_quote_conf(self, template, symbol_list, kdb_obj):
        root = et.fromstring(template)

        if root.find('symbol_list') is not None:
            symbol_list_node = root.find('symbol_list')
            for _node in symbol_list_node.findall('symbol')[1:]:
                symbol_list_node.remove(_node)
            symbol_node = symbol_list_node.find('symbol')
            if symbol_node is None:
                return None

            for _ in range(len(symbol_list) - 1):
                symbol_list_node.append(copy.deepcopy(symbol_node))

            symbol_nodes = symbol_list_node.findall('symbol')
            for _node, sym in zip(symbol_nodes, symbol_list):
                _node.text = sym

        elif root.find('symbol') is not None:
            symbol_list_node = root.find('symbol')
            symbol_list_node.text = ','.join(symbol_list)

        elif root.find('symbol_info') is not None:
            for _node in root.findall('symbol_info')[1:]:
                root.remove(_node)
            symbol_node = root.find('symbol_info')
            if symbol_node.find('symbol') is None \
                    or symbol_node.find('multiple') is None \
                    or symbol_node.find('tick_size') is None:
                return None
            for _ in range(len(symbol_list) - 1):
                root.append(copy.deepcopy(symbol_node))

            symbol_nodes = root.findall('symbol_info')
            for _node , sym in zip(symbol_nodes, symbol_list):
                symbol_unit = kdb_obj.get_symbol_unit(sym)
                _node.find('symbol').text = sym
                _node.find('multiple').text = str(int(symbol_unit['N']))
                _node.find('tick_size').text = str(symbol_unit['S_INFO_MFPRICE'])

        else:
            return None

        return str(et.tostring(root, 'utf-8'), 'utf-8')


class QuoteUpdateXmlSymbolHandler(ListHandler, Notification):

    def get(self, *args, **kwargs):
        process_ids = []
        try:
            host = self.get_argument('host', '')
            kdb_obj = KdbQuery()
            now = datetime.datetime.now()
            if now.hour < 18:
                kdb_date = now.strftime('%Y.%m.%d')
            else:
                kdb_date = (now + datetime.timedelta(days=1)).strftime('%Y.%m.%d')

            prod_symbol_dict = {}

            with mysql_sc() as sc:
                processes = sc.query(TuringDeployConfs).filter(
                    TuringDeployConfs.valid == 1,
                )
                if host:
                    processes = processes.filter(TuringDeployConfs.host == host)
                for process in processes:
                    xml = process.content
                    if not xml:
                        continue
                    host = process.host
                    deploy_path = process.deploy_path
                    r = sc.query(
                        TuringPreToolConfs.valid.label('valid'),
                        TuringPreToolConfs.day_night.label('day_night'),
                        TuringPreToolConfs.script_cpu_valid.label('script_cpu_valid'),
                        TuringPreToolConfs.script_cpu_bind.label('script_cpu_bind'),
                        TuringPreToolConfs.product_list.label('product_list'),
                        TuringConfigTemplates.content.label('template'),
                    ).join(
                        TuringServers,
                        TuringPreToolConfs.server_id == TuringServers.id,
                    ).join(
                        TuringConfigTemplates,
                        TuringPreToolConfs.config_template_id == TuringConfigTemplates.id,
                    ).filter(
                        TuringPreToolConfs.deploy_path == deploy_path,
                        TuringServers.ip == host,
                        TuringPreToolConfs.valid == 1,
                    ).first()
                    if not r:
                        continue
                    if not r.product_list:
                        continue
                    symbol_list = []
                    try:
                        for p, ranks in r.product_list.items():
                            if ranks == 'all':
                                if p.endswith('50ETF'):
                                    symbols = ["SH" + s for s in kdb_obj.get_all_opmain_code(kdb_date, p.lower())]
                                elif p.endswith('300SH'): 
                                    symbols = ["SH" + s for s in kdb_obj.get_all_opmain_code(kdb_date, p.lower())]
                                elif p.endswith('300SZ'):
                                    symbols = ["SZ" + s for s in kdb_obj.get_all_opmain_code(kdb_date, p.lower())]
                                elif p.endswith('300ZJ'):
                                    symbols = kdb_obj.get_all_opmain_code(kdb_date, p.lower())
                                symbol_list.extend(symbols)
                            else:
                                for rank in ranks.split(','):
                                    if p.endswith('.SH') or p.endswith('.SZ'):
                                        symbol = p.upper()
                                    elif p.endswith('_F'):
                                        prod = p.split('_')[0]
                                        if (p, int(rank)) in prod_symbol_dict:
                                            symbol = prod_symbol_dict[(p, int(rank))]
                                        else:
                                            symbol = kdb_obj.get_fmain_code(kdb_date, prod.upper(), int(rank))
                                            prod_symbol_dict[(p, int(rank))] = symbol
                                    elif p.endswith('50ETF'):
                                        if (p, int(rank)) in prod_symbol_dict:
                                            symbol = prod_symbol_dict[(p, int(rank))]
                                        else:
                                            symbol = kdb_obj.get_opmain_code(kdb_date, p.lower(), int(rank))
                                            symbol = 'SH%s' % symbol
                                            prod_symbol_dict[(p, int(rank))] = symbol
                                    elif p.endswith('300SH') or p.endswith('300SZ') or p.endswith('300ZJ'):
                                        if (p, int(rank)) in prod_symbol_dict:
                                            symbol = prod_symbol_dict[(p, int(rank))]
                                        else:
                                            symbol = kdb_obj.get_opmain_code(kdb_date, p.lower(), int(rank))
                                            if p.endswith("300SH"):
                                                symbol = "SH%s" % symbol
                                            elif p.endswith("300SZ"):
                                                symbol = "SZ%s" % symbol
                                            prod_symbol_dict[(p, int(rank))] = symbol
                                    elif p.upper() == 'CBSZ' or p.upper() == 'CBSH':
                                        if (p, int(rank)) in prod_symbol_dict:
                                            symbol = prod_symbol_dict[(p, int(rank))]
                                        else:
                                            symbol = kdb_obj.get_cb_code(kdb_date, p.lower(), int(rank))
                                            prod_symbol_dict[(p, int(rank))] = symbol
                                    else:
                                        if (p, int(rank)) in prod_symbol_dict:
                                            symbol = prod_symbol_dict[(p, int(rank))]
                                        else:
                                            symbol = kdb_obj.get_main_code(kdb_date, p.lower(), int(rank))
                                            prod_symbol_dict[(p, int(rank))] = symbol
                                    symbol_list.append(symbol)
                    except Exception as e:
                        logger.error(str(e))

                    config = self.gen_quote_conf(xml, symbol_list, kdb_obj)
                    if config is None:
                        raise ValueError("Update xml failed")
                        #self.write(json.dumps({
                        #    'code': 1404,
                        #    'error': 'gen config failed.'
                        #}))
                        #return
                    process.content = config

            self.write(json.dumps({
                'code': 0,
            }))

        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def gen_quote_conf(self, template, symbol_list, kdb_obj):
        root = et.fromstring(template)

        if root.find('symbol_list') is not None:
            symbol_list_node = root.find('symbol_list')
            for _node in symbol_list_node.findall('symbol')[1:]:
                symbol_list_node.remove(_node)
            symbol_node = symbol_list_node.find('symbol')
            if symbol_node is None:
                return None

            for _ in range(len(symbol_list) - 1):
                symbol_list_node.append(copy.deepcopy(symbol_node))

            symbol_nodes = symbol_list_node.findall('symbol')
            for _node, sym in zip(symbol_nodes, symbol_list):
                _node.text = sym

        elif root.find('symbol') is not None:
            symbol_list_node = root.find('symbol')
            symbol_list_node.text = ','.join(symbol_list)

        elif root.find('symbol_info') is not None:
            for _node in root.findall('symbol_info')[1:]:
                root.remove(_node)
            symbol_node = root.find('symbol_info')
            if symbol_node.find('symbol') is None \
                    or symbol_node.find('multiple') is None \
                    or symbol_node.find('tick_size') is None:
                return None
            for _ in range(len(symbol_list) - 1):
                root.append(copy.deepcopy(symbol_node))

            symbol_nodes = root.findall('symbol_info')
            for _node , sym in zip(symbol_nodes, symbol_list):
                symbol_unit = kdb_obj.get_symbol_unit(sym)
                _node.find('symbol').text = sym
                _node.find('multiple').text = str(int(symbol_unit['N']))
                _node.find('tick_size').text = str(symbol_unit['S_INFO_MFPRICE'])

        else:
            return None

        return str(et.tostring(root, 'utf-8'), 'utf-8')


class TuringCtpInfoAutoUpdateHandler(BaseHandler):

    def initialize(self, *args, **kwargs):
        self.model = None
        self.fields = {}    # key: model-key, value: payload-key
        #self.no_login = ['get']
        self.no_login = []

    def get(self, *args, **kwargs):
        now = datetime.datetime.now()
        if now.hour < 18:
            kdb_date = now.strftime('%Y.%m.%d')
        else:
            kdb_date = (now + datetime.timedelta(days=1)).strftime('%Y.%m.%d')

        with mysql_sc() as sc:
            sc.query(UserInfo).filter().delete()
            sc.query(SymbolList).filter().delete()
            sc.query(SymbolMargin).filter().delete()
            sc.query(AccountInfo).filter().delete()
            sc.query(CtpAccountPos).filter().delete()
            sc.commit()

            cli_list = [
                a[0] for a in
                sc.query(
                    distinct(Accounts.client_name)
                ).filter(
                    Accounts.valid == 1,
                    Accounts.use_turing == 1,
                )
            ]

            if '85011366' not in cli_list:
                cli_list.append('85011366')
            if '910086' not in cli_list:
                cli_list.append('910086')
            if '85011682' not in cli_list:
                cli_list.append('85011682')

            lines = sc.query(
                Accounts.client_name.label('user_id'),
                Accounts.query_passwd.label('password'),
                Counters.counter_forwarder_addr.label('ctp_forwarder_addr'),
                Counters.broker_no.label('broker_no'),
                Accounts.product_info.label('product_info'),
                Accounts.auth_code.label('auth_code'),
            ).join(
                Counters,# Counters.name == Accounts.query_broker,
                Counters.broker_id == Accounts.broker_id,
            ).filter(
                Accounts.client_name.in_(cli_list),
                Accounts.query_passwd != '',
                Accounts.query_broker != '',
                Accounts.need_query == 1,
                Counters.name == Accounts.query_broker,
            )
            for obj in lines:
                ctp_forwarder_addr = obj.ctp_forwarder_addr.split('//')[-1]
                if not ctp_forwarder_addr:
                    continue
                ctp_ip, ctp_port = ctp_forwarder_addr.split(':')
                data = {
                    'user_id': obj.user_id,
                    'user_passwd': obj.password,
                    'server_ip': ctp_ip,
                    'server_port': ctp_port,
                    'broker_id': obj.broker_no,
                    'request_cycle': 60,
                }
                if obj.product_info and obj.auth_code:
                    data['product_info'] = obj.product_info
                    data['auth_code'] = obj.auth_code
                sc.add(UserInfo(**data))


            kdb = KdbQuery()

            product_set = {}
            d = sc.query(DIMPreConfs).filter().order_by(DIMPreConfs.id.desc()).first()
            uid = d.uid
            lines = sc.query(DIMPreConfs).filter(
                DIMPreConfs.uid == uid,
            )
            for line in lines:
                product = line.product
                rank = line.symbol
                exchange = line.exchange
                if exchange.lower() == 'czce':
                    long_product = 'zz%s' % product.lower()
                elif exchange.lower() == 'dce':
                    long_product = 'dl%s' % product.lower()
                elif exchange.lower() == 'shfe':
                    long_product = 'sh%s' % product.lower()
                else:
                    long_product = product.lower()
                if long_product.upper() in ['CP50ETF', 'CP300ZJ', 'CP300SH', 'CP300SZ']:
                    continue
                if (long_product, rank) not in product_set:
                    if rank in ['R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9',
                            'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20']:
                        if long_product.upper() in ['CP50ETF', 'CP300ZJ', 'CP300SH', 'CP300SZ']:
                            symbol = kdb.get_opmain_code(kdb_date, long_product, rank=int(rank.replace('R', '')))
                        elif long_product.upper() in ['CBSZ', 'CBSH']:
                            symbol = kdb.get_cb_code(kdb_date, long_product, rank=int(rank.replace('R', '')))
                        else:
                            symbol = kdb.get_main_code(kdb_date, long_product, rank=int(rank.replace('R', '')))
                    else:
                        symbol = rank
                    product_set[(long_product, rank)] = symbol

            for symbol in product_set.values():
                data = {'symbol': symbol}
                sc.add(SymbolList(**data))

        self.write(json.dumps({
            'code': 0,
        }))


class GalileoPreConfsHandler(ListHandler):

    def initialize(self, *args, **kwargs):
        self.type = 0

    def get(self, *args, **kwargs):
        res = []
        server_id = int(self.get_argument('server_id', '0'))
        with mysql_sc() as sc:
            lines = sc.query(GalileoPreTraderConfs).filter()
            if server_id > 0:
                lines = lines.filter(GalileoPreTraderConfs.server_id == server_id)
            if self.type != 0:
                lines = lines.filter(GalileoPreTraderConfs.type == self.type)
            for line in lines:
                res.append(line.to_dict())
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        data = {
            'server_id': payload['server_id'],
            'type': self.type,
            'valid': payload['valid'],
            'day_night': payload['day_night'],
            'name': payload['name'],
            'deploy_path': payload['deploy_path'],
            'config_template_id': payload['config_template_id'],
            'script_cpu_valid': payload['script_cpu_valid'],
            'script_cpu_bind': payload['script_cpu_bind'],
            'account': payload['account_id'],
        }
        #if 'tunnel_id' in payload:
        #    data['tunnel_id'] = payload['tunnel_id']
        if 'v_account_id' in payload:
            data['account_id'] = payload['v_account_id']

        try:
            with mysql_sc() as sc:
                o = GalileoPreTraderConfs(**data)
                sc.add(o)
                sc.commit()
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class GalileoPreConfsDetailHandler(IDHandler):

    def initialize(self, *args, **kwargs):
        self.model = None
        self.fields = {}    # key: model-key, value: payload-key
        self.no_login = []

    def get(self, *args, **kwargs):
        with mysql_sc() as sc:
            o = sc.query(GalileoPreTraderConfs).filter(
                GalileoPreTraderConfs.id == kwargs['id'],
            ).first()
            if o:
                self.write(json.dumps({
                    'code': 0,
                    'data': o.to_dict(),
                }))
            else:
                self.write(json.dumps({
                    'code': 404,
                    'error': 'Data not found.',
                }))

    def put(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))
        try:
            with mysql_sc() as sc:
                o = sc.query(GalileoPreTraderConfs).filter(
                    GalileoPreTraderConfs.id == kwargs['id']
                ).first()
                if o:
                    if 'valid' in payload:
                        o.valid = payload['valid']
                    if 'day_night' in payload:
                        o.day_night = payload['day_night']
                    if 'name' in payload:
                        o.name = payload['name']
                    if 'deploy_path' in payload:
                        o.deploy_path = payload['deploy_path']
                    if 'config_template_id' in payload:
                        o.config_template_id = payload['config_template_id']
                    if 'script_cpu_valid' in payload:
                        o.script_cpu_valid = payload['script_cpu_valid']
                    if 'script_cpu_bind' in payload:
                        o.script_cpu_bind = payload['script_cpu_bind']
                    if 'account_id' in payload:
                        o.account = payload['account_id']
                    #if 'tunnel_id' in payload:
                    #    o.tunnel_id = payload['tunnel_id']
                    if 'v_account_id' in payload:
                        o.account_id = payload['v_account_id']
                    sc.commit()
                    self.write(json.dumps({
                        'code': 0,
                        'data': o.to_dict(),
                    }))
                else:
                    self.write(json.dumps({
                        'code': 404,
                        'error': 'Data not found',
                    }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def delete(self, *args, **kwargs):
        try:
            with mysql_sc() as sc:
                sc.query(GalileoPreTraderConfs).filter(
                    GalileoPreTraderConfs.id == kwargs['id']
                ).delete()
                self.write(json.dumps({
                    'code': 0,
                    'data': 1,
                }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class GalileoPreTraderConfsHandler(GalileoPreConfsHandler):

    def initialize(self, *args, **kwargs):
        self.type = 1


class GalileoPreTraderConfsDetailHandler(GalileoPreConfsDetailHandler):

    def initialize(self, *args, **kwargs):
        self.type = 1


class GalileoPreStrategyConfsHandler(GalileoPreConfsHandler):

    def initialize(self, *args, **kwargs):
        self.type = 2


class GalileoPreStrategyConfsDetailHandler(GalileoPreConfsDetailHandler):

    def initialize(self, *args, **kwargs):
        self.type = 2


class GalileoGenConfsHandler(BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))

        if ('server' not in payload) or \
           ('source' not in payload) or \
           ('deploy_path' not in payload):
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return

        #try:
        host = payload['server']
        deploy_path = payload['deploy_path']
        source = payload['source']
        config = ''

        if int(source) == 1:
            with mysql_sc() as sc:
                r = sc.query(TuringDeployConfs).filter(
                    TuringDeployConfs.host == host,
                    TuringDeployConfs.deploy_path == deploy_path,
                ).order_by(
                    TuringDeployConfs.id.desc()
                ).first()
                if r:
                    config = r.content
        else:
            with mysql_sc() as sc:
                r = sc.query(
                    GalileoPreTraderConfs.valid.label('valid'),
                    GalileoPreTraderConfs.day_night.label('day_night'),
                    GalileoPreTraderConfs.script_cpu_valid.label('script_cpu_valid'),
                    GalileoPreTraderConfs.script_cpu_bind.label('script_cpu_bind'),
                    GalileoPreTraderConfs.type.label('type'),
                    GalileoPreTraderConfs.account.label('account'),
                    #GalileoPreTraderConfs.tunnel_id.label('tunnel_id'),
                    GalileoPreTraderConfs.account_id.label('account_id'),
                    TuringConfigTemplates.content.label('template'),
                    Accounts.name.label('username'),
                    Accounts.password.label('password'),
                    Accounts.rsp_pwd.label('rsp_pwd'),
                ).join(
                    TuringServers,
                    GalileoPreTraderConfs.server_id == TuringServers.id,
                ).join(
                    Accounts,
                    GalileoPreTraderConfs.account == Accounts.id,
                ).join(
                    TuringConfigTemplates,
                    GalileoPreTraderConfs.config_template_id == TuringConfigTemplates.id,
                ).filter(
                    GalileoPreTraderConfs.deploy_path == deploy_path,
                    TuringServers.ip == host,
                ).first()
                if not r:
                    self.write(json.dumps({
                        'code': 1404,
                        'error': 'Data not found.'
                    }))
                    return
                if not r.valid:
                    self.write(json.dumps({
                        'code': 1404,
                        'error': 'invalid pre-config.'
                    }))
                    return
                template = r.template
                if not template:
                    self.write(json.dumps({
                        'code': 1404,
                        'error': 'template content is null.'
                    }))
                    return
                username = r.username
                password = r.password
                rsp_pwd = r.rsp_pwd or ''
                day_night = r.day_night

                d = sc.query(DIMPreConfs).filter(
                    DIMPreConfs.day_night == day_night,
                ).order_by(
                    DIMPreConfs.id.desc()
                ).first()
                if not d:
                    self.write(json.dumps({
                        'code': 404,
                        'error': 'not config.',
                    }))
                    return
                uid = d.uid
 
                if r.type == 1:  #galileo tunnel
                    ss = sc.query(
                        GalileoPreTraderConfs.account_id.label('account_id')
                    ).join(
                        TuringServers,
                        GalileoPreTraderConfs.server_id == TuringServers.id,
                    ).filter(
                        TuringServers.ip == host,
                        GalileoPreTraderConfs.type == 2,
                        GalileoPreTraderConfs.account == r.account,
                    )
                    s_acccount_ids = []
                    for s in ss:
                        if s.account_id is not None and s.account_id != '':
                            s_acccount_ids.append(s.account_id)

                    conf_dict = {}
                    lines = sc.query(DIMPreConfs).filter(
                        DIMPreConfs.uid == uid,
                        DIMPreConfs.account == username,
                        DIMPreConfs.day_night == day_night,
                    ).order_by(
                        DIMPreConfs.product.asc()
                    ).all()
                    #if len(lines) == 0:
                    #    self.write(json.dumps({
                    #        'code': 404,
                    #        'error': 'Account not found in pre-config.',
                    #    }))
                    #    return
                        
                    for line in lines:
                        product = line.product
                        symbol = line.symbol
                        exchange = line.exchange
                        account_id = line.v_account_id
                        if exchange.lower() == 'czce':
                            long_product = 'zz%s' % product.lower()
                        elif exchange.lower() == 'dce':
                            long_product = 'dl%s' % product.lower()
                        elif exchange.lower() == 'shfe':
                            long_product = 'sh%s' % product.lower()
                        else:
                            long_product = product.lower()
                        if account_id not in conf_dict:
                            conf_dict[account_id] = [(long_product, symbol)]
                        else:
                            if (long_product, symbol) not in conf_dict[account_id]:
                                conf_dict[account_id].append((long_product, symbol))

                    config = self.gen_tunnel_conf(template, username, password, rsp_pwd, s_acccount_ids, conf_dict, day_night)
                    if config is None:
                        self.write(json.dumps({
                            'code': 1404,
                            'error': 'gen config failed.'
                        }))
                        return
                else:
                    account_id = r.account_id
                    if account_id is None:
                        self.write(json.dumps({
                            'code': 1405,
                            'error': 'invalid pre-config.'
                        }))
                        return

                    conf_dict = {}
                    acc_id = -1

                    #d = sc.query(DIMPreConfs).filter(
                    #    DIMPreConfs.uid == uid,
                    #    DIMPreConfs.account == username,
                    #    DIMPreConfs.day_night == day_night,
                    #).first()
                    #if not d:
                    #    self.write(json.dumps({
                    #        'code': 404,
                    #        'error': 'Account not found in pre-config.',
                    #    }))
                    #    return

                    lines = sc.query(DIMPreConfs).filter(
                        DIMPreConfs.uid == uid,
                        DIMPreConfs.account == username,
                        DIMPreConfs.day_night == day_night,
                        DIMPreConfs.v_account_id == account_id,
                    ).order_by(
                        DIMPreConfs.product.asc()
                    )

                    daynight = 'day' if day_night == 0 else 'night'
                    for line in lines:
                        line.status = 1
                        acc_id = line.account_id
                        product = line.product
                        symbol = line.symbol
                        alphamixer = line.alphamixer
                        strategy = line.strategy
                        max_vol = line.max_vol
                        limit_vol = line.limit_vol
                        single_max_vol = line.single_max_vol
                        ev_dim = line.ev_dim
                        ev_data = line.ev_data
                        exchange = line.exchange
                        quote_lv = line.quote_lv
                        if exchange.lower() == 'czce':
                            long_product = 'zz%s' % product.lower()
                        elif exchange.lower() == 'dce':
                            long_product = 'dl%s' % product.lower()
                        elif exchange.lower() == 'shfe':
                            long_product = 'sh%s' % product.lower()
                        else:
                            long_product = product.lower()
                        k = '%s_%s_%s_%s' % (alphamixer, long_product, daynight, symbol)
                        if k not in conf_dict:
                            conf_dict[k] = {
                                'ev_dim': ev_dim,
                                'ev_data': ev_data,
                                'quote_lv': quote_lv,
                                'strategies': [{
                                    'strategy': strategy,
                                    'max_vol': max_vol,
                                    'limit_vol': limit_vol,
                                    'single_max_vol': single_max_vol,
                                    'ev_dim': ev_dim,
                                    'ev_data': ev_data,
                                }],
                            }
                        else:
                            conf_dict[k]['strategies'].append({
                                'strategy': strategy,
                                'max_vol': max_vol,
                                'limit_vol': limit_vol,
                                'single_max_vol': single_max_vol,
                                'ev_dim': ev_dim,
                                'ev_data': ev_data,
                            })
                    sc.commit()

                    config = self.gen_strategy_conf(template, username, password, rsp_pwd, account_id, conf_dict, acc_id)
                    if config is None:
                        self.write(json.dumps({
                            'code': 1404,
                            'error': 'gen config failed.'
                        }))
                        return

        self.write(json.dumps({
            'code': 0,
            'data': {
                'xml': config,
            },
        }))

        #except Exception as e:
        #    logger.error(str(e))
        #    self.write(json.dumps({
        #        'code': 500,
        #        'error': str(e),
        #    }))

    def gen_tunnel_conf(self, template, username, password, rsp_pwd, s_acccount_ids, conf_dict, day_night):
        kdb_obj = KdbQuery()
        now = datetime.datetime.now()
        if now.hour < 18:
            kdb_date = now.strftime('%Y.%m.%d')
        else:
            kdb_date = (now + datetime.timedelta(days=1)).strftime('%Y.%m.%d')

        root = et.fromstring(template)
        account = root.find('account')
        account.find('user_id').text = username
        if account.find('fund_account_id') is not None:
            account.find('fund_account_id').text = username
        account.find('passwd').text = password
        if account.find('x1_rsp_pwd') is not None:
            account.find('x1_rsp_pwd').text = rsp_pwd

        for node in account.findall('sub_account')[1:]:
            account.remove(node)
        sub_account = account.find('sub_account')
        for node in sub_account.findall('symbol_info')[1:]:
            sub_account.remove(node)

        sub_account = account.find('sub_account')
        if len(conf_dict) == 0:
            account.find('user_id').text = "0"
        else:
            for _ in range(len(conf_dict) - 1):
                account.append(copy.deepcopy(sub_account))
            sub_account_list = account.findall('sub_account')

            for sub_node, account_id in zip(sub_account_list, conf_dict):
                sub_node.find('account_id').text = str(account_id)
                symbol_info = sub_node.find('symbol_info')
                for _ in range(len(conf_dict[account_id]) - 1):
                    sub_node.append(copy.deepcopy(symbol_info))
                symbol_info_list = sub_node.findall('symbol_info')
                for symbol_node, item in zip(symbol_info_list, conf_dict[account_id]):
                    long_product = item[0]
                    symbol = item[1]
                    if symbol in ['R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9',
                            'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20']:
                        if long_product.upper() in ['CP50ETF', 'CP300ZJ', 'CP300SH', 'CP300SZ']:
                            symbol_node.find('symbol').text = kdb_obj.get_opmain_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                        elif long_product.upper() in ['CBSZ', 'CBSH']:
                            symbol_node.find('symbol').text = kdb_obj.get_cb_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                        else:
                            symbol_node.find('symbol').text = kdb_obj.get_main_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                            symbol_node.find('max_accum_cancel_vol').text = '480' if day_night == 0 else '300'
                    else:
                        symbol_node.find('symbol').text = symbol
                        symbol_node.find('max_accum_cancel_vol').text = '480' if day_night == 0 else '300'

        return '<?xml version="1.0" encoding="utf-8"?>\n' + str(et.tostring(root, 'utf-8'), 'utf-8')

    def gen_strategy_conf(self, template, username, password, rsp_pwd, account_id, conf_dict, acc_id):
        kdb_obj = KdbQuery()
        now = datetime.datetime.now()
        if now.hour < 18:
            kdb_date = now.strftime('%Y.%m.%d')
        else:
            kdb_date = (now + datetime.timedelta(days=1)).strftime('%Y.%m.%d')

        root = et.fromstring(template)
        root.find('origin_id').text = str(acc_id)
        trade_info = root.find('trade_info')
        trade_info.find('v_account_id').text = str(account_id)

        tot_node = root.find('tot_account_number')
        account_node = tot_node.find('account')
        account_node.find('user_id').text = username
        if account_node.find('fund_account_id').text is not None:
            account_node.find('fund_account_id').text = username
        account_node.find('passwd').text = password
        if account_node.find('x1_rsp_pwd') is not None:
            account_node.find('x1_rsp_pwd').text = rsp_pwd

        for node in account_node.findall('strategy')[1:]:
            account_node.remove(node)
        strategy_node = account_node.find('strategy')
        for node in strategy_node.findall('sub_strategy')[1:]:
            strategy_node.remove(node)

        if len(conf_dict) > 0:
            for _ in range(len(conf_dict) - 1):
                account_node.append(copy.deepcopy(strategy_node))
            strategy_node_list = account_node.findall('strategy')

            for strategy_node, k in zip(strategy_node_list, conf_dict):
                alpha_dict = conf_dict[k]
                long_product = k.split('_')[1]
                symbol = k.rsplit('_', 1)[1]
                k = k.rsplit('_', 1)[0]
                ev_list = []
                ev_dim = alpha_dict.get('ev_dim', '')
                ev_data = alpha_dict.get('ev_data', '')
                quote_lv = alpha_dict.get('quote_lv', 0)
                if ev_dim:
                    ev_list.append(os.path.join('/home/mycapitaltrade/turing_ev', ev_dim))
                if ev_data:
                    ev_list.append(os.path.join('/home/mycapitaltrade/db_file', ev_data))
                ev = '|'.join(ev_list)
                if symbol in ['R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9',
                        'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20']:
                    _tmp = k.split('_')
                    k_st = '%s_%s%s_%s' % (_tmp[0], _tmp[1], symbol.replace("R",""), _tmp[2])
                elif symbol == 'R1':
                    _tmp = k.split('_')
                    k_st = '%s_%s_%s' % (_tmp[0], _tmp[1], _tmp[2])
                else:
                    _tmp = k.split('_')
                    if symbol.isdigit():
                        if len(symbol) == 6:
                            _rank = kdb_obj.get_cb_rank(kdb_date, symbol)
                        else:
                            _rank = kdb_obj.get_option_rank(kdb_date, symbol)
                    else:
                        _rank = kdb_obj.get_symbol_rank(kdb_date, symbol)
                    k_st = '%s_%s%s_%s' % (_tmp[0], _tmp[1], '' if int(_rank) == 1 else _rank, _tmp[2])
                #if 'relay' in k_st:
                #    k_st = '%s_%s' % (k_st, username)
                so = os.path.join('/home/mycapitaltrade/turing_so', k_st + '.so')
                if symbol in ['R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9',
                        'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20']:
                    if long_product.upper() in ['CP50ETF', 'CP300ZJ', 'CP300SH', 'CP300SZ']:
                        strategy_node.find('symbol').text = kdb_obj.get_opmain_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                    elif long_product.upper() in ['CBSZ', 'CBSH']:
                        strategy_node.find('symbol').text = kdb_obj.get_cb_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                    else:
                        strategy_node.find('symbol').text = kdb_obj.get_main_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                else:
                    strategy_node.find('symbol').text = symbol
                strategy_node.find('strategy_so').text = so
                if strategy_node.find('strategy_ev_file') is not None:
                    strategy_node.find('strategy_ev_file').text = ev
                if strategy_node.find('strategy_quote_lv') is not None:
                    strategy_node.find('strategy_quote_lv').text = str(quote_lv)

                if long_product == 'dli' and strategy_node.find('max_accum_open_vol') is not None:
                    strategy_node.find('max_accum_open_vol').text = '100000'

                sub_strategy_node = strategy_node.find('sub_strategy')
                for _ in range(len(alpha_dict['strategies']) - 1):
                    strategy_node.append(copy.deepcopy(sub_strategy_node))
                sub_strategy_node_list = strategy_node.findall('sub_strategy')
                for node, st_dict in zip(sub_strategy_node_list, alpha_dict['strategies']):
                    node.find('strat_name').text = st_dict['strategy']
                    node.find('max_pos').text = str(st_dict['max_vol'])
                    node.find('single_side_max_pos_limit').text = str(st_dict['single_max_vol'])
                    node.find('lock_pos_single_side_max_pos').text = str(st_dict['single_max_vol'])
                    st_ev_list = []
                    ev_dim = st_dict.get('ev_dim', '')
                    ev_data = st_dict.get('ev_data', '')
                    if ev_dim:
                        st_ev_list.append(os.path.join('/home/mycapitaltrade/turing_ev', ev_dim))
                    if ev_data:
                        st_ev_list.append(os.path.join('/home/mycapitaltrade/db_file', ev_data))
                    st_ev = '|'.join(st_ev_list)
                    if node.find('strategy_ev_file') is not None:
                        node.find('strategy_ev_file').text = st_ev

        return '<?xml version="1.0" encoding="utf-8"?>\n' + str(et.tostring(root, 'utf-8'), 'utf-8')


class GalileoBulkGenConfsHandler(BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        if not self.request.headers['content-type'].startswith("application/json"):
            self.write(json.dumps({
                'code': 415,
                'error': 'No json data.',
            }))
            return
        payload = json.loads(str(self.request.body, 'utf-8'))

        if 'process_ids' not in payload:
            self.write(json.dumps({
                'code': 400,
                'error': 'Payload data error.',
            }))
            return

        self.m_product_symbol = {}
        self.m_symbol_rank = {}
        try:
            process_ids = payload['process_ids']
            with mysql_sc() as sc:
                for process_id in process_ids:
                    logger.info("GalileoBulkGenConfsHandler process_id:%s" % process_id)
                    process = sc.query(TuringDeployConfs).filter(
                        TuringDeployConfs.id == process_id
                    ).first()
                    if not process:
                        self.write(json.dumps({
                            'code': 404,
                            'error': 'Process not found.',
                        }))
                        return
                    host = process.host
                    deploy_path = process.deploy_path

                    r = sc.query(
                        GalileoPreTraderConfs.valid.label('valid'),
                        GalileoPreTraderConfs.day_night.label('day_night'),
                        GalileoPreTraderConfs.script_cpu_valid.label('script_cpu_valid'),
                        GalileoPreTraderConfs.script_cpu_bind.label('script_cpu_bind'),
                        GalileoPreTraderConfs.type.label('type'),
                        GalileoPreTraderConfs.account.label('account'),
                        #GalileoPreTraderConfs.tunnel_id.label('tunnel_id'),
                        GalileoPreTraderConfs.account_id.label('account_id'),
                        TuringConfigTemplates.content.label('template'),
                        Accounts.name.label('username'),
                        Accounts.password.label('password'),
                        Accounts.rsp_pwd.label('rsp_pwd'),
                    ).join(
                        TuringServers,
                        GalileoPreTraderConfs.server_id == TuringServers.id,
                    ).join(
                        Accounts,
                        GalileoPreTraderConfs.account == Accounts.id,
                    ).join(
                        TuringConfigTemplates,
                        GalileoPreTraderConfs.config_template_id == TuringConfigTemplates.id,
                    ).filter(
                        GalileoPreTraderConfs.deploy_path == deploy_path,
                        TuringServers.ip == host,
                    ).first()
                    if not r:
                        self.write(json.dumps({
                            'code': 1404,
                            'error': 'Data not found.'
                        }))
                        return
                    if not r.valid:
                        self.write(json.dumps({
                            'code': 1404,
                            'error': 'invalid pre-config.'
                        }))
                        return
                    template = r.template
                    if not template:
                        self.write(json.dumps({
                            'code': 1404,
                            'error': 'template content is null.'
                        }))
                        return
                    username = r.username
                    password = r.password
                    rsp_pwd = r.rsp_pwd or ''
                    day_night = r.day_night

                    d = sc.query(DIMPreConfs).filter(
                        DIMPreConfs.day_night == day_night,
                    ).order_by(
                        DIMPreConfs.id.desc()
                    ).first()
                    if not d:
                        self.write(json.dumps({
                            'code': 404,
                            'error': 'not config.',
                        }))
                        return
                    uid = d.uid
                    if r.type == 1:  #galileo tunnel
                        ss = sc.query(
                            GalileoPreTraderConfs.account_id.label('account_id')
                        ).join(
                            TuringServers,
                            GalileoPreTraderConfs.server_id == TuringServers.id,
                        ).filter(
                            TuringServers.ip == host,
                            GalileoPreTraderConfs.type == 2,
                            GalileoPreTraderConfs.account == r.account,
                        )
                        s_acccount_ids = []
                        for s in ss:
                            if s.account_id is not None and s.account_id != '':
                                s_acccount_ids.append(s.account_id)

                        conf_dict = {}
                        lines = sc.query(DIMPreConfs).filter(
                            DIMPreConfs.uid == uid,
                            DIMPreConfs.account == username,
                            DIMPreConfs.day_night == day_night,
                        ).order_by(
                            DIMPreConfs.product.asc()
                        ).all()
                        #if len(lines) == 0:
                        #    self.write(json.dumps({
                        #        'code': 404,
                        #        'error': 'Account not found in pre-config.',
                        #    }))
                        #    return

                        for line in lines:
                            product = line.product
                            symbol = line.symbol
                            exchange = line.exchange
                            account_id = line.v_account_id
                            if exchange.lower() == 'czce':
                                long_product = 'zz%s' % product.lower()
                            elif exchange.lower() == 'dce':
                                long_product = 'dl%s' % product.lower()
                            elif exchange.lower() == 'shfe':
                                long_product = 'sh%s' % product.lower()
                            else:
                                long_product = product.lower()
                            if account_id not in conf_dict:
                                conf_dict[account_id] = [(long_product, symbol)]
                            else:
                                if (long_product, symbol) not in conf_dict[account_id]:
                                    conf_dict[account_id].append((long_product, symbol))

                        pre_content = process.content

                        config = self.gen_tunnel_conf(template, username, password, rsp_pwd, s_acccount_ids, conf_dict, pre_content, day_night)
                        if config is None:
                            self.write(json.dumps({
                                'code': 1404,
                                'error': 'gen config failed.'
                            }))
                            return
                    else:
                        account_id = r.account_id
                        if account_id is None:
                            self.write(json.dumps({
                                'code': 1405,
                                'error': 'invalid pre-config.'
                            }))
                            return

                        conf_dict = {}
                        acc_id = -1
                        #d = sc.query(DIMPreConfs).filter(
                        #    DIMPreConfs.uid == uid,
                        #    DIMPreConfs.account == username,
                        #    DIMPreConfs.day_night == day_night,
                        #).first()
                        #if not d:
                        #    self.write(json.dumps({
                        #        'code': 404,
                        #        'error': 'Account not found in pre-config.',
                        #    }))
                        #    return

                        lines = sc.query(DIMPreConfs).filter(
                            DIMPreConfs.uid == uid,
                            DIMPreConfs.account == username,
                            DIMPreConfs.day_night == day_night,
                            DIMPreConfs.v_account_id == account_id,
                        ).order_by(
                            DIMPreConfs.product.asc()
                        )

                        daynight = 'day' if day_night == 0 else 'night'
                        for line in lines:
                            line.status = 1
                            acc_id = line.account_id
                            product = line.product
                            symbol = line.symbol
                            alphamixer = line.alphamixer
                            strategy = line.strategy
                            max_vol = line.max_vol
                            limit_vol = line.limit_vol
                            single_max_vol = line.single_max_vol
                            ev_dim = line.ev_dim
                            ev_data = line.ev_data
                            exchange = line.exchange
                            quote_lv = line.quote_lv
                            if exchange.lower() == 'czce':
                                long_product = 'zz%s' % product.lower()
                            elif exchange.lower() == 'dce':
                                long_product = 'dl%s' % product.lower()
                            elif exchange.lower() == 'shfe':
                                long_product = 'sh%s' % product.lower()
                            else:
                                long_product = product.lower()
                            k = '%s_%s_%s_%s' % (alphamixer, long_product, daynight, symbol)
                            if k not in conf_dict:
                                conf_dict[k] = {
                                    'ev_dim': ev_dim,
                                    'ev_data': ev_data,
                                    'quote_lv': quote_lv,
                                    'strategies': [{
                                        'strategy': strategy,
                                        'max_vol': max_vol,
                                        'limit_vol': limit_vol,
                                        'single_max_vol': single_max_vol,
                                        'ev_dim': ev_dim,
                                        'ev_data': ev_data,
                                    }],
                                }
                            else:
                                conf_dict[k]['strategies'].append({
                                    'strategy': strategy,
                                    'max_vol': max_vol,
                                    'limit_vol': limit_vol,
                                    'single_max_vol': single_max_vol,
                                    'ev_dim': ev_dim,
                                    'ev_data': ev_data,
                                })
                        sc.commit()
                        pre_content = process.content

                        config = self.gen_strategy_conf(template, username, password, rsp_pwd, account_id, conf_dict, pre_content, acc_id)
                        if config is None:
                            self.write(json.dumps({
                                'code': 1404,
                                'error': 'gen config failed.'
                            }))
                            return

                    process.content = config

            self.write(json.dumps({
                'code': 0,
            }))

        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))

    def gen_tunnel_conf(self, template, username, password, rsp_pwd, s_acccount_ids, conf_dict, pre_xml, day_night):
        kdb_obj = KdbQuery()
        now = datetime.datetime.now()
        if now.hour < 18:
            kdb_date = now.strftime('%Y.%m.%d')
        else:
            kdb_date = (now + datetime.timedelta(days=1)).strftime('%Y.%m.%d')

        if pre_xml:
            root = et.fromstring(pre_xml)
            account = root.find('account')
            account.find('user_id').text = username
        else:
            root = et.fromstring(template)
            account = root.find('account')
            account.find('user_id').text = username
            if account.find('fund_account_id') is not None:
                account.find('fund_account_id').text = username
            account.find('passwd').text = password
            if account.find('x1_rsp_pwd') is not None:
                account.find('x1_rsp_pwd').text = rsp_pwd

        for node in account.findall('sub_account')[1:]:
            account.remove(node)
        sub_account = account.find('sub_account')
        for node in sub_account.findall('symbol_info')[1:]:
            sub_account.remove(node)

        sub_account = account.find('sub_account')
        if len(conf_dict) == 0:
            account.find('user_id').text = "0"
        else:
            for _ in range(len(conf_dict) - 1):
                account.append(copy.deepcopy(sub_account))
            sub_account_list = account.findall('sub_account')

            for sub_node, account_id in zip(sub_account_list, conf_dict):
                sub_node.find('account_id').text = str(account_id)
                symbol_info = sub_node.find('symbol_info')
                for _ in range(len(conf_dict[account_id]) - 1):
                    sub_node.append(copy.deepcopy(symbol_info))
                symbol_info_list = sub_node.findall('symbol_info')
                for symbol_node, item in zip(symbol_info_list, conf_dict[account_id]):
                    long_product = item[0]
                    symbol = item[1]
                    if symbol in ['R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9',
                            'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20']:
                        if (long_product.upper(), symbol) in self.m_product_symbol:
                            symbol_node.find('symbol').text = self.m_product_symbol[(long_product.upper(), symbol)]
                        else:
                            if long_product.upper() in ['CP50ETF', 'CP300ZJ', 'CP300SH', 'CP300SZ']:
                                symbol_node.find('symbol').text = kdb_obj.get_opmain_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                            elif long_product.upper() in ['CBSZ', 'CBSH']:
                                symbol_node.find('symbol').text = kdb_obj.get_cb_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                            else:
                                symbol_node.find('symbol').text = kdb_obj.get_main_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                                symbol_node.find('max_accum_cancel_vol').text = '480' if day_night == 0 else '300'
                            self.m_product_symbol[(long_product.upper(), symbol)] = symbol_node.find('symbol').text
                    else:
                        symbol_node.find('symbol').text = symbol
                        symbol_node.find('max_accum_cancel_vol').text = '480' if day_night == 0 else '300'

        return '<?xml version="1.0" encoding="utf-8"?>\n' + str(et.tostring(root, 'utf-8'), 'utf-8')

    def gen_strategy_conf(self, template, username, password, rsp_pwd, account_id, conf_dict, pre_xml, acc_id):
        kdb_obj = KdbQuery()
        now = datetime.datetime.now()
        if now.hour < 18:
            kdb_date = now.strftime('%Y.%m.%d')
        else:
            kdb_date = (now + datetime.timedelta(days=1)).strftime('%Y.%m.%d')

        if pre_xml:
            root = et.fromstring(pre_xml)
            root.find('origin_id').text = str(acc_id)
            trade_info = root.find('trade_info')
            trade_info.find('v_account_id').text = str(account_id)

            tot_node = root.find('tot_account_number')
            account_node = tot_node.find('account')
        else:
            root = et.fromstring(template)
            root.find('origin_id').text = str(acc_id)
            trade_info = root.find('trade_info')
            trade_info.find('v_account_id').text = str(account_id)

            tot_node = root.find('tot_account_number')
            account_node = tot_node.find('account')
            account_node.find('user_id').text = username
            if account_node.find('fund_account_id').text is not None:
                account_node.find('fund_account_id').text = username
            account_node.find('passwd').text = password
            if account_node.find('x1_rsp_pwd') is not None:
                account_node.find('x1_rsp_pwd').text = rsp_pwd

        for node in account_node.findall('strategy')[1:]:
            account_node.remove(node)
        strategy_node = account_node.find('strategy')
        for node in strategy_node.findall('sub_strategy')[1:]:
            strategy_node.remove(node)

        if len(conf_dict) > 0:
            for _ in range(len(conf_dict) - 1):
                account_node.append(copy.deepcopy(strategy_node))
            strategy_node_list = account_node.findall('strategy')

            for strategy_node, k in zip(strategy_node_list, conf_dict):
                alpha_dict = conf_dict[k]
                long_product = k.split('_')[1]
                symbol = k.rsplit('_', 1)[1]
                k = k.rsplit('_', 1)[0]
                ev_list = []
                ev_dim = alpha_dict.get('ev_dim', '')
                ev_data = alpha_dict.get('ev_data', '')
                quote_lv = alpha_dict.get('quote_lv', 0)
                if ev_dim:
                    ev_list.append(os.path.join('/home/mycapitaltrade/turing_ev', ev_dim))
                if ev_data:
                    ev_list.append(os.path.join('/home/mycapitaltrade/db_file', ev_data))
                ev = '|'.join(ev_list)
                if symbol in ['R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9',
                        'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20']:
                    _tmp = k.split('_')
                    k_st = '%s_%s%s_%s' % (_tmp[0], _tmp[1], symbol.replace("R",""), _tmp[2])
                elif symbol == 'R1':
                    _tmp = k.split('_')
                    k_st = '%s_%s_%s' % (_tmp[0], _tmp[1], _tmp[2])
                else:
                    _tmp = k.split('_')
                    if symbol in self.m_symbol_rank:
                        _rank = self.m_symbol_rank[symbol]
                    else:
                        if symbol.isdigit():
                            if len(symbol) == 6:
                                _rank = kdb_obj.get_cb_rank(kdb_date, symbol)
                            else:
                                _rank = kdb_obj.get_option_rank(kdb_date, symbol)
                        else:
                            _rank = kdb_obj.get_symbol_rank(kdb_date, symbol)
                        self.m_symbol_rank[symbol] = _rank
                    k_st = '%s_%s%s_%s' % (_tmp[0], _tmp[1], '' if int(_rank) == 1 else _rank, _tmp[2])
                #if 'relay' in k_st:
                #    k_st = '%s_%s' % (k_st, username)
                so = os.path.join('/home/mycapitaltrade/turing_so', k_st + '.so')
                if symbol in ['R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9',
                        'R10', 'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20']:
                    if (long_product.upper(), symbol) in self.m_product_symbol:
                        strategy_node.find('symbol').text = self.m_product_symbol[(long_product.upper(), symbol)]
                    else:
                        if long_product.upper() in ['CP50ETF', 'CP300ZJ', 'CP300SH', 'CP300SZ']:
                            strategy_node.find('symbol').text = kdb_obj.get_opmain_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                        elif long_product.upper() in ['CBSZ', 'CBSH']:
                            strategy_node.find('symbol').text = kdb_obj.get_cb_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                        else:
                            strategy_node.find('symbol').text = kdb_obj.get_main_code(kdb_date, long_product, rank=int(symbol.replace('R', '')))
                        self.m_product_symbol[(long_product, symbol)] = strategy_node.find('symbol').text
                else:
                    strategy_node.find('symbol').text = symbol
                strategy_node.find('strategy_so').text = so
                if strategy_node.find('strategy_ev_file') is not None:
                    strategy_node.find('strategy_ev_file').text = ev
                if strategy_node.find('strategy_quote_lv') is not None:
                    strategy_node.find('strategy_quote_lv').text = str(quote_lv)

                if long_product == 'dli' and strategy_node.find('max_accum_open_vol') is not None:
                    strategy_node.find('max_accum_open_vol').text = '100000'

                sub_strategy_node = strategy_node.find('sub_strategy')
                for _ in range(len(alpha_dict['strategies']) - 1):
                    strategy_node.append(copy.deepcopy(sub_strategy_node))
                sub_strategy_node_list = strategy_node.findall('sub_strategy')
                for node, st_dict in zip(sub_strategy_node_list, alpha_dict['strategies']):
                    node.find('strat_name').text = st_dict['strategy']
                    node.find('max_pos').text = str(st_dict['max_vol'])
                    node.find('single_side_max_pos_limit').text = str(st_dict['single_max_vol'])
                    node.find('lock_pos_single_side_max_pos').text = str(st_dict['single_max_vol'])
                    st_ev_list = []
                    ev_dim = st_dict.get('ev_dim', '')
                    ev_data = st_dict.get('ev_data', '')
                    if ev_dim:
                        st_ev_list.append(os.path.join('/home/mycapitaltrade/turing_ev', ev_dim))
                    if ev_data:
                        st_ev_list.append(os.path.join('/home/mycapitaltrade/db_file', ev_data))
                    st_ev = '|'.join(st_ev_list)
                    if node.find('strategy_ev_file') is not None:
                        node.find('strategy_ev_file').text = st_ev

        return '<?xml version="1.0" encoding="utf-8"?>\n' + str(et.tostring(root, 'utf-8'), 'utf-8')


class GalileoDeployProcessIdsHandler(BaseHandler):

    def get(self, *args, **kwargs):
        process_ids = []
        try:
            host = self.get_argument('host', '')
            with mysql_sc() as sc:
                processes = sc.query(TuringDeployConfs).filter(
                    TuringDeployConfs.valid == 1,
                )
                if host:
                    processes = processes.filter(TuringDeployConfs.host == host)
                for process in processes:
                    xml = process.content
                    if not xml:
                        continue
                    host = process.host
                    deploy_path = process.deploy_path

                    r = sc.query(
                        GalileoPreTraderConfs.valid.label('valid'),
                        GalileoPreTraderConfs.day_night.label('day_night'),
                        GalileoPreTraderConfs.script_cpu_valid.label('script_cpu_valid'),
                        GalileoPreTraderConfs.script_cpu_bind.label('script_cpu_bind'),
                        GalileoPreTraderConfs.type.label('type'),
                        GalileoPreTraderConfs.account.label('account'),
                        #GalileoPreTraderConfs.tunnel_id.label('tunnel_id'),
                        GalileoPreTraderConfs.account_id.label('account_id'),
                        TuringConfigTemplates.content.label('template'),
                        Accounts.name.label('username'),
                        Accounts.password.label('password'),
                        Accounts.rsp_pwd.label('rsp_pwd'),
                    ).join(
                        TuringServers,
                        GalileoPreTraderConfs.server_id == TuringServers.id,
                    ).join(
                        Accounts,
                        GalileoPreTraderConfs.account == Accounts.id,
                    ).join(
                        TuringConfigTemplates,
                        GalileoPreTraderConfs.config_template_id == TuringConfigTemplates.id,
                    ).filter(
                        GalileoPreTraderConfs.deploy_path == deploy_path,
                        TuringServers.ip == host,
                    ).first()
                    if not r:
                        continue
                    if not r.valid:
                        continue
                    template = r.template
                    if not template:
                        continue
                    username = r.username
                    password = r.password
                    rsp_pwd = r.rsp_pwd or ''
                    day_night = r.day_night

                    dd = sc.query(DIMPreConfs).filter(
                        DIMPreConfs.day_night == day_night,
                    ).order_by(
                        DIMPreConfs.id.desc()
                    ).first()
                    if not dd:
                        continue
                    uid = dd.uid
                 
                    if r.type == 1:  #galileo tunnel
                        ss = sc.query(
                            GalileoPreTraderConfs.account_id.label('account_id')
                        ).join(
                            TuringServers,
                            GalileoPreTraderConfs.server_id == TuringServers.id,
                        ).filter(
                            TuringServers.ip == host,
                            GalileoPreTraderConfs.type == 2,
                            GalileoPreTraderConfs.account == r.account,
                        )
                        s_acccount_ids = []
                        for s in ss:
                            if s.account_id is not None and s.account_id != '':
                                s_acccount_ids.append(s.account_id)
                        if not s_acccount_ids:
                            continue

                        d = sc.query(DIMPreConfs).filter(
                            DIMPreConfs.account == username,
                            DIMPreConfs.day_night == day_night,
                            DIMPreConfs.uid == uid,
                        ).order_by(
                            DIMPreConfs.id.desc()
                        ).first()
                        if not d:
                            continue
                    else:
                        account_id = r.account_id
                        if account_id is None:
                            continue

                        conf_dict = {}
                        d = sc.query(DIMPreConfs).filter(
                            DIMPreConfs.account == username,
                            DIMPreConfs.day_night == day_night,
                            #DIMPreConfs.account_id == account_id,
                            DIMPreConfs.uid == uid,
                        ).order_by(
                            DIMPreConfs.id.desc()
                        ).first()
                        if not d:
                            continue

                    process_ids.append(process.id)

            self.write(json.dumps({
                'code': 0,
                'data': process_ids,
            }))
        except Exception as e:
            logger.error(str(e))
            self.write(json.dumps({
                'code': 500,
                'error': str(e),
            }))


class GalileoGetStrategyAlertsHandler(BaseHandler):

    def get(self, *args, **kwargs):
        now = datetime.datetime.now()
        if now.hour >= 9 and now.hour < 21:
            day_night = 0
        else:
            day_night = 1

        kdb = KdbQuery()
        trading_date = kdb.get_trading_date(hour=21)

        ret = []
        with mysql_sc() as sc:
            alerts = sc.query(TuringStAlertLogs).filter(
                TuringStAlertLogs.trading_date == trading_date,
                #TuringStAlertLogs.day_night == day_night,
            ).order_by(
                TuringStAlertLogs.r_create_time.desc()
            )

            for o in alerts:
                if o.trading_time.strftime('%H:%M:%S') < '21:00:00' and o.trading_time.strftime('%H:%M:%S') >= '20:55:00':
                    continue
                if o.exchange in ['CFFEX'] and \
                        (o.trading_time.strftime('%H:%M:%S') < '09:30:00' and o.trading_time.strftime('%H:%M:%S') >= '09:10:00'):
                    continue
                if o.exchange in ['SHFE', 'DCE', 'CZCE'] and \
                        (o.trading_time.strftime('%H:%M:%S') < '09:00:00' and o.trading_time.strftime('%H:%M:%S') >= '08:55:00'):
                    continue
                if '停板' in o.err_msg or '涨跌' in o.err_msg:
                    continue
                ret.append(o.to_desc())

        self.write(json.dumps({
            'code': 0,
            'data': ret,
        }))


class GalileoTotalStrategyAlertsHandler(BaseHandler):

    def get(self, *args, **kwargs):
        total = 0
        self_trade = 0

        now = datetime.datetime.now()
        if now.hour >= 9 and now.hour < 21:
            day_night = 0
        else:
            day_night = 1

        kdb = KdbQuery()
        trading_date = kdb.get_trading_date(hour=21)

        ret = []
        with mysql_sc() as sc:
            alerts = sc.query(TuringStAlertLogs.trading_time, TuringStAlertLogs.exchange, TuringStAlertLogs.err_msg).filter(
                TuringStAlertLogs.trading_date == trading_date,
                #TuringStAlertLogs.day_night == day_night,
            ).order_by(
                TuringStAlertLogs.r_create_time.desc()
            )

            for o in alerts:
                if o.trading_time.strftime('%H:%M:%S') < '21:00:00' and o.trading_time.strftime('%H:%M:%S') >= '20:55:00':
                    continue
                if o.exchange in ['CFFEX'] and \
                        (o.trading_time.strftime('%H:%M:%S') < '09:30:00' and o.trading_time.strftime('%H:%M:%S') >= '09:10:00'):
                    continue
                if o.exchange in ['SHFE', 'DCE', 'CZCE'] and \
                        (o.trading_time.strftime('%H:%M:%S') < '09:00:00' and o.trading_time.strftime('%H:%M:%S') >= '08:55:00'):
                    continue
                if '停板' in o.err_msg or '涨跌' in o.err_msg:
                    continue

                total += 1
                if '自成交' in o.err_msg:
                    self_trade += 1

        self.write(json.dumps({
            'code': 0,
            'data': {
                'total': total,
                'self_trade': self_trade,
            },
        }))


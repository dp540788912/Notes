#!/usr/bin/python

import os
import sys
import json


def get_my_products(exchange):
    if exchange == 'cffex':
        return [
            'if', 't', 'tf', 'ic', 'ih',
        ]
    elif exchange == 'czce':
        return [
            'zzcf', 'zzfg', 'zzma', 'zzoi', 'zzrm',
            'zzsr', 'zzta', 'zzwh', 'zzzc', 'zzap',
            'zzsm', 'zzsf', 'zzcj', 'zzur', 'zzsa',
        ]
    elif exchange == 'dce':
        return [
            'dla', 'dlbb', 'dlc', 'dlcs', 'dlfb',
            'dli', 'dlj', 'dljd', 'dljm', 'dll',
            'dlm', 'dlp', 'dlpp', 'dlv', 'dly',
            'dlb', 'dleg', 'dleb', 'dlrr', 'dlpg',
        ]
    elif exchange == 'shfe':
        return [
            'shag', 'shal', 'shau', 'shbu', 'shcu',
            'shhc', 'shni', 'shpb', 'shrb', 'shru',
            'shzn', 'shsc', 'shfu', 'shsp', 'shnr',
            'shss', 'shlu',
        ]
    elif exchange == 'sse':
        return [
            'cp50etf', 'cp300sh', 'cbsh',
        ]
    elif exchange == 'szse':
        return [
            'cp300sz', 'cbsz',
        ]
    else:
        return []


def get_my_accounts(exchange):
    if exchange == 'cffex':
        return [
            '120300555','120300559','120300576','120301731',
            '120302119','100102058','100103186','120302161',
            '120302162',
            '20052225','20052119','20033866','20097092','20052123',
            '80001866','80002928',
        ]
    elif exchange == 'dce':
        return [
            '76050147','81241332',
        ]
    else:
        return []


origin = sys.argv[1]
day_night = sys.argv[2]
exchange = sys.argv[3]

for product in get_my_products(exchange):
    #if 'relay' in origin:
    #    for account in get_my_accounts(exchange):
    #        cmd = 'cp %s.so %s_%s_%s_%s.so' % (origin, origin, product, day_night, account)
    #        os.system(cmd)
    #        cmd = 'cp %s.so %s_%s2_%s_%s.so' % (origin, origin, product, day_night, account)
    #        os.system(cmd)
    if 'opt' in origin:
        cmd = 'cp %s.so %s_%s_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s2_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s3_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s4_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s5_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s6_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s7_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s8_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s9_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
    elif 'cb' in origin:
        cmd = 'cp %s.so %s_%s_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s2_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s3_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s4_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s5_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s6_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s7_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s8_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s9_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s10_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s11_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s12_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s13_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s14_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s15_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s16_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s17_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s18_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s19_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s20_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
    else:
        cmd = 'cp %s.so %s_%s_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s2_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)
        cmd = 'cp %s.so %s_%s3_%s.so' % (origin, origin, product, day_night)
        os.system(cmd)


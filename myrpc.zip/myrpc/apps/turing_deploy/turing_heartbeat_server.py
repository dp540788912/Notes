# -*- coding:utf-8 -*-

import time
import datetime
import json
import redis
import requests

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText



conf = {
    #'ip': '127.0.0.1',
    'ip': '192.168.10.99',
    'port': '6379',
    'heartbeat': 'a:oss:turing:heartbeat',
}

rds = redis.Redis(conf['ip'], conf['port'])

users = ['LiShaoFeng', 'WangDan', 'HeWenGuan', 'GuoZiFan']

alert_process = []


def notify_wechat(recipients, message):
    agentid = 1000010
    secret = 'Y2Y7wcdfP7ksrT8w9kWgJNcUiM6oedE0GsQ_jFfnsVM'
    corpid = 'ww7c9916c2f31d5aa4'
    token_url = 'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=%s&corpsecret=%s' % (corpid, secret)
    msg_url = 'https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=%s'
    try:
        response = requests.get(token_url)
        if response.status_code == 200:
            token = response.json()['access_token']
            msg_url = msg_url % token
            payload = {
                "touser": "|".join(recipients),
                "toparty": "",
                "msgtype": "text",
                "agentid": agentid,
                "text": {
                    "content": message
                },
                "safe": "0"
            }
            response = requests.post(msg_url, json=payload)
            json_data = response.json()
            if json_data['errcode'] == 0:
                return True
            raise RuntimeError("发送微信失败: %s" % json_data['errmsg'])
        else:
            raise RuntimeError("无法连接微信服务器")
    except Exception as e:
        raise RuntimeError("发送微信异常: %s" % e)


if __name__ == '__main__':

    last = time.time()
    now = last
    hosts = rds.keys(pattern='a:oss:turing:heartbeat:*')

    while True:
        now = time.time()

        if (int(now) - int(last)) > 60 * 60:
            hosts = rds.keys(pattern='a:oss:turing:heartbeat:*')
            last = now

        n = datetime.datetime.now().strftime("%H:%M:%S")
        if (n > "02:30:00" and n < "09:00:00") or (n > "15:00:00" and n < "21:00:00"):
            time.sleep(10)
            continue

        for r in hosts:
            data = rds.hgetall(r)
            for k, v in data.items():
                if (int(now) - int(v)/1000) > 60 * 10:
                    if k not in alert_process:
                        alert_process.append(k)
                        h = str(r, 'utf-8').split(':')[-1]
                        message = '[Turing心跳异常] 主机 %s, 进程ID %s' % (h, str(k, 'utf-8'))
                        print(message)
                        notify_wechat(users, message)
                else:
                    if k in alert_process:
                        alert_process.remove(k)
                        h = str(r, 'utf-8').split(':')[-1]
                        message = '[Turing心跳恢复] 主机 %s, 进程ID %s' % (h, str(k, 'utf-8'))
                        print(message)
                        notify_wechat(users, message)

        time.sleep(10)


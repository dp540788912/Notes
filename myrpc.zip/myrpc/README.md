
# Install

0. pip install -i https://pypi.doubanio.com/simple　virtualenv

1. virtualenv --python=python3 --no-site-packages venv

2. source venv/bin/activate

3. pip install -i https://pypi.doubanio.com/simple -r requirements.txt


#Demo Server

```python
from rpc import Server, Router

calculator = Router('calculator')


@calculator.register()
def add(data):
    return data[0] + data[1]


@calculator.register()
def sub(data):
    return data[0] - data[1]


@calculator.register()
def mut(data):
    return data[0] * data[1]


@calculator.register()
def div(data):
    return data[0] / 0


s = Server('calculator')
s.register(calculator.handlers)
s.listenandstart(8769)
```

#Demo Client
```python
from rpc import Client

service = 'calculator'
app_id = 'test123'
app_token = 'xxxxx'

c = Client(service=service, host='xxxx', port='xxxx', app_id=app_id, app_token=app_token)

data = [1, 2]

res = c.add(data)

res = c.sub(data)

data = [1, 0]

res = c.div(data)

```
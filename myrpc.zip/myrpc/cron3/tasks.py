# -*- coding:utf-8 -*-

from celery import Celery
from celery.utils.log import get_task_logger
from cron3 import app
from positions_task import write_position


logger = get_task_logger(__name__)

@app.task
def calc_position_task():
    logger.info('start to calculate position ..')
    write_position()
    logger.info('calculation finished.')
    return True


#-*-coding:utf-8-*-


import os
import sys

from celery import Celery


ROOT_PATH = os.path.abspath('.')
OPERATE_PATH = os.path.join(ROOT_PATH, 'apps/operation_deploy')


if ROOT_PATH not in sys.path:
    sys.path.append(ROOT_PATH)

if OPERATE_PATH not in sys.path:
    sys.path.append(OPERATE_PATH)

class Router():
    def route_for_task(self, task, args=None, kwargs=None):
        #if task.startswith('cron.tasks'):
        #    return {'queue': 'celery_task'}
        #else:
        return {'queue': 'deploy_task'}

app = Celery()
app.config_from_object('cron3.celeryconfig')
app.conf.update(CELERY_ROUTES=(Router(),))



from datetime import datetime, timedelta
from celery.schedules import crontab


BROKER_URL = 'redis://127.0.0.1'
CELERY_IMPORTS = (
    'cron3.tasks',
)
CELERY_RESULT_BACKEND = 'redis://127.0.0.1:6379'
CELERY_TASK_RESULT_EXPIRES = 5
CELERYD_CONCURRENCY = 4
CELERYD_PREFETCT_MULTIPLIER = 1
CELERY_TIMEZONE = 'Asia/Hong_Kong'
CELERY_ACCEPT_CONTENT = ['pickle', 'json']

CELERYBEAT_SCHEDULE = {
    'test': {
        'task': 'cron3.tasks.calc_position_task',
        'schedule': crontab(hour=[4, 16]),
        #'schedule': timedelta(seconds=300),
    },

}

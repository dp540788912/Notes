#-*-coding:utf-8-*-

class CommonConfig(object):
    pass


class Production(CommonConfig):


    statsd = {
        'host': '192.168.3.183',
        'port': 8125,
    }

    sentry = {
        'dsn': 'http://cef2ab91f43948acaf41b9cddcefa11c:687fb2819fa14b4da1285964ad422292@192.168.3.183:9090/5'
    }

class Debug(CommonConfig):


    statsd = {
        'host': '192.168.3.183',
        'port': 8125,
    }

    sentry = {
        'dsn': 'http://f39bf41e49f841b6847511e0506edc8a:113a24855eca48648636b1f311a1990b@192.168.3.183:9090/6'
    }

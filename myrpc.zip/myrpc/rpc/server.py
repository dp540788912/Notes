#-*-coding:utf-8-*-


import json
import msgpack
from statsd import StatsClient
from tornado import ioloop
from tornado import gen
from tornado.web import RequestHandler, Application
from tornado.httpserver import HTTPServer
from tornado.concurrent import Future
from raven import Client as Sentry
from rpc.config import Production, Debug


class EntryPoint(RequestHandler):

    def encode_response(self, data):
        if self.content_type == 'application/msgpack':
            self.write(msgpack.packb(data))
        else:
            self.write(json.dumps(data))

    def prepare(self):
        content_type = self.request.headers['content-type']
        if content_type.startswith("application/json"):
            self.decode_args = json.loads(str(self.request.body, 'utf-8'))
            self.content_type = 'application/json'
        elif content_type.startswith("application/msgpack"):
            self.decode_args = msgpack.unpackb(self.request.body)
            self.content_type = 'application/msgpack'
        else:
            self.decode_args = None
            self.content_type = content_type

    @gen.coroutine
    def post(self, *args, **kwargs):
        if self.application.settings['service'].name in ['log_report']:
            data = self.decode_args[b'data'] if b'app_id' in self.decode_args else self.decode_args
            res = yield self.entry(data)
            return self.encode_response(res)
        else:
            if not self.check_auth():
                return self.encode_response({
                    'code': 100,
                    'data': 'app auth failed'
                })
            res = yield self.entry(self.decode_args[b'data'])
            return self.encode_response(res)

    def entry(self, data, *args, **kwargs):
        fut = Future()
        fut.set_result(self.application.settings['service'].entry(self.request.path, data))
        return fut

    def check_auth(self):
        return True


class Server(object):

    def __init__(self, name, app_config=None, server_config=None, debug=True):
        self.name = name
        self.app_config = app_config
        if debug:
            self.config = Debug()
        else:
            self.config = Production()
        if server_config:
            self.config = server_config
        self.statsd = StatsClient(self.config.statsd['host'], self.config.statsd['port'])
        self.sentry = Sentry(self.config.sentry['dsn'])

    def entry(self, path, data, *args, **kwargs):
        key = path.rsplit('/', 1)[-1]
        self.statsd.incr('rpc.service.%s.%s' % (self.name, key))
        if key not in self.router:
            return {
                'code': 101,
                'data': 'can not find mathod path=%s' % path,
            }
        try:
            return self.router[key](data)
        except Exception as e:
            self.sentry.captureException()
            return {
                'code': 102,
                'data': 'app method %s.%s run exception:%s' % (self.name, key, e)
            }

    def make_app(self):
        self.app = Application(self.handlers, xsrf_cookies=False, service=self)
        self.http_server = HTTPServer(self.app)

    def register(self, router):
        self.router = router
        self.handlers = []
        for k in self.router:
            self.handlers.append((r'/%s/%s' % (self.name, k), EntryPoint))

    def listen(self, port):
        self.make_app()
        self.http_server.listen(port)

    def start(self):
        ioloop.IOLoop.instance().start()

    def listenandstart(self, port):
        self.listen(port)
        self.start()

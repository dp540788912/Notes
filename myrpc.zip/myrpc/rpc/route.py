#-*-coding:utf-8-*-

import functools


class Router(object):
    def __init__(self, name=''):
        self.name = name
        self.handlers = {}

    def register(self, *args, **kwargs):
        def inner(fun):
            @functools.wraps(fun)
            def wrapper(*fargs, **fkwargs):
                return fun(*fargs, **fkwargs)
            funcname = kwargs.get('name', fun.__name__)
            self.handlers[funcname] = fun
            return wrapper
        return inner
#-*-coding:utf-8-*-

import time
import hashlib
import msgpack
import requests


class Client(object):
    def __init__(self, service, host, port, app_id='', app_token='', debug=True):
        if debug:
            self.url = 'http://%s:%s/%s' % (host, port, service)
        else:
            self.url = 'http://%s:%s/%s' % (host, port, service)
        self.service = service
        self.host = host
        self.port = port
        self.app_id = app_id
        self.app_token = app_token

    def __getattr__(self, method):
        return lambda *args, **kargs: self(method, *args, **kargs)

    def __call__(self, method, data):
        headers = {
            'content-type': 'application/msgpack',
        }
        request_time = str(int(time.time()))
        params = {
            'app_id': self.app_id,
            'time': request_time,
            'app_token': hashlib.md5((self.app_token + request_time).encode('utf8')).hexdigest(),
            'data': data,
        }

        r = requests.post('%s/%s' % (self.url, method), data=msgpack.packb(params), headers=headers)
        try:
            return msgpack.unpackb(r.content)
        except:
            return r.content

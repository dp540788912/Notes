# 名词解释
    1. 策略
        一个策略就是实现了一系列接口的代码块  /support/wiki.html Python API/样本策略
        使用Python编写，采用Cython编译成so封装保密

        系统内分为按功能分为普通交易策略，ev生产策略，因子生产策略，算法交易策略，风险模块，轧差交易策略
        其中普通交易策略，ev生产策略， 因子生产策略最为普遍，我们常说的策略也就是指普通交易策略，通过一系列接口实现交易逻辑
        由交易程序驱动运行，调用相应的接口， 例如
        a. 启动的时候调用on_init
        b. 针对每一笔行情调用 on_book
        c. 定时调用on_timer
        在这些回调函数里面实现发单，撤单的逻辑 
        
        输入: 昨日的仓位，今日的行情
        输出：今日的交易记录     
        由某一天的初始资金，初始仓位， 交易记录，结算价， 计算出当日的结束持仓，当日盈亏，结束资金等; 结束持仓，结束资金 作为下一天的初始仓位，初始资金 

    2. ev
        ev是指一个ev生产程序，按照模板实现了一个接口 /support/wiki.html 策略参数文件(ev)上传
        使用Python编写，采用Cython编译成so或者源码提交
        输入参数：交易日(trading_date)，交易时段(day_night)，输出文件，日志文件，其他数据kdb，npq，或者自定义的存储数据
        输出： 自定义内容格式写入到输出文件，输出文件可以作为交易策略的输入参数文件
    
    3. backtest
        从历史某一天开始至提交日期，按日期顺序 调用 策略或者ev 产生对应的输出

    4. papertrading
        从提交日期开始，每天自动按顺序调用策略或者ev 产生对应的输出
    5. 实盘
        对于普通交易策略，使用真实交易账户，资金，对接券商/期货公司行情，发单至交易所 做程序化交易产生盈亏
    6. 盘后分析
        采用实盘接近的条件，模拟真实的交易状态，产生模拟的输出，用于和实盘比较差异，提高交易质量，
        盘后分析的结果可以认为是理想情况下应该达到的目标


# 表结构介绍

## 策略：
    strategy 
        node=='ev' 表示 ev 生产策略
        node=='back_test' 表示 普通so回测策略
    strategy_upload_file
        策略程序文件存储的表  strategy_upload_file.id == strategy.strategy_upload_file_id
        更新策略so，ev生产so 本质就上就是覆盖 某一个文件的内容
        获取某个策略的程序文件路径
        s = sc.query(Strategy).filter(Strategy.id == s_id ).first()
        s.strategy_upload_file['abs_path']
    
# 回测结果
    strategy_result, backtest_result_detail, backtest_result_account
    ev 或者回测相关的结果

# 实盘
    strategy 每次提交实盘都会生产一个对应的 strategy_portfolio vstrategies 表记录
    vstrategies.strategy_id = strategy.id
    vstrategies.portfolio_id = strategy_portfolio.id
    strategy_portfolio.business 表示股票业务或者期货业务
    vstrategies.status 15 代表实盘， 16 代表下线

    









# ev生产
    0. 应用场景
        交易策略在初始化的时候需要知道一些参数值，例如昨天的收盘价，最近10天的均价，最近5天的交易量等等，这些变量没办法在初始化的时候计算，也没办法在初始化时读取到数据库里面的值
        更抽象的说法是，交易策略可能需要获取到 截止到开盘前的某个时间点 现实世界当中已知的任何信息x，x变量的值 由一个程序(ev生产程序)计算，按自定义的格式写入到一个按协议约定的文件当中，策略在初始化的时候按自定义的格式读取该文件的内容
    1. 功能描述
        a. 策略订阅ev，一个ev的输出文件 作为交易策略的输入载体
        b. ev订阅其他ev，多个ev之间顺序依赖，ev之间数据共享，一个ev生产的数据存储在自定义的路径下，另外一个ev读取该内容做下一步的计算 
    2. 运行机制
        
        a. 研究员本地编写程序(参考模板 /support/wiki.html 策略参数文件(ev)上传)
        
        b. 上传ev生产程序
            打开页面/strategy/ev-upload.html --> 点击新建 --> 填写表单 --> 保存           
        
        c. 回测历史
            保存之后会自动开始执行回测历史
        
        d. 修改开始日期重做
            在/strategy/ev-upload.html 页面对某一个ev 点击修改开始日期 --> 保存
            停止正在运行的生产任务，删除strategy_result 中的记录，重新开始 回测历史流程
        
        f. 重新计算某一天
            策略研究 / 实盘管理 / 每日任务
            输入ev_id, 点击重做，输入日期 保存

        e. 按顺序每日自动papertrading  (夜盘是18点自动执行， 日盘股票2点执行，期货6点执行)
    
    3. 代码流程
        a. 上传ev生产程序
            POST /api/v1/strategy_upload/strategy  strategy表新增一条记录
            保存之后, 自动开始历史回测成产
            start_strategy_task.delay(strategy.id) --> ev_start_strategy_task.apply_async(args=(strategy_id,), queue=queue) --> strategy.start_task(auto=False) --> strategy.start_ev_task_v3(*args, **kwargs)
            生产的结果记录在strategy_result 表中，每个ev每一个交易日一条记录

            start_ev_task_v3 中调用subprocess 执行 
            com_list = ['/usr/bin/python3', strategy_py, json.dumps(cfg)]
            output_string = subprocess.check_output(com_list, universal_newlines=True, cwd=cwd, stderr=subprocess.STDOUT)
            进程的工作目录为 jupyter_userworkspace/{user_id}_{username}，ev生产程序可以从当前目录读写数据
            机器上执行 ps aux | grep ev_outxxxx  可以看到正在运行的ev生产程序

         
        b. 修改开始日期重做
            POST /api/v1/strategy_upload/strategy/(?P<id>\w+)
            停止正在运行的生产任务，删除strategy_result 中的记录，重新开始 回测历史流程
        
        c. 重新计算某一天
            POST /api/v1/platform/strategymanager/strategy/papertrading/<id>
            redo_ev_task.delay(s.id, start_date, end_date=end_date) --> queue_redo_ev_task.apply_async(args=(s_id, start_date), kwargs=kwargs, queue=queue) --> s.start_ev_task_v3(**kw)
        d. 每日自动papertrading
            celery 定时任务 查看cron/celeryconfig
            auto_daily_ev_task_stock
            auto_daily_ev_task    --> strategy_ev_task.delay(s.id, trading_date)
            strategy_ev_task 中通过check_dependency 保证执行顺序，如果依赖的ev没有执行完成，则调用strategy_ev_task.apply_async(args=(strategy_id, start_date, redo_times + 1), countdown=120) 两分钟之后执行，并累加超时次数超过200次则认为超时
   
        e. 查看依赖是否完成
           查看直接依赖是否全部完成
           ```
            s = sc.query(Strategy).filter(Strategy.id == 215164).first()
            s.check_dependency('20200114', 0)
           ```
           
           查看整个依赖链是否全部完成
           ```
            from service.back_test.ev_task import get_dep_ev_id
            ev_id = 215164
            today = '20200114'
            ev_ids = get_dep_ev_id(ev_id)
            ev_ids = get_dep_ev_id(ev_id)
            ev_ids_status = {}
            error_ev_ids = []

            for sr in sc.query(StrategyResult).filter(StrategyResult.strategy_id.in_(ev_ids), StrategyResult.date == today):
                ev_ids_status[sr.strategy_id] = sr.status

            for ev_id in ev_ids:
                if ev_ids_status.get(ev_id, 2) == 0:     #0表示成功执行
                    continue
                if ev_ids_status.get(ev_id, 2) == -1:       # -1 表示失败
                    error_ev_ids.append(ev_id)
                print(ev_id, ev_ids_status.get(ev_id, 2))     # 2表示未执行

           ```

           获取所有实盘相关的ev_id
           from service.back_test.ev_task import get_live_ev_ids_cache
        
        d. 实盘盘前状态统计邮件
            ssh 100
            crontab -l
            30 05 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh daily_ev_check.sh >/dev/null 2>&1 &
            00 06 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh daily_ev_check.sh >/dev/null 2>&1 &
            00 07 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh daily_ev_check.sh >/dev/null 2>&1 &
            00 19 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh daily_ev_check.sh >/dev/null 2>&1 &

    4. 其他
        a. 股票夜盘ev生产
            ssh 100
            crontab -l
            30 21 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh stock_ev_night_generate.sh >/dev/null 2>&1 &
            28 22 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh stock_ev_night_check.sh >/dev/null 2>&1 &
            stock_ev_night_generate.py
            21点30开始，每过5分钟检查kdb的数据状态，如果状态就绪则开始执行，否则检查12次(1小时)之后直接开始执行
        
        b. 股票周末的ev执行
            一般的周末ev执行和平时没有差异，月度训练时会耗时很久，月度训练为每个月的第一个假期后的第一个交易日，所以月度训练放在每个月的第一个假期执行
            ssh 100
            crontab -l
            30 03 * * 1-6 cd /home/rss/bss_server/strategy_upload/bin && sh stock_weekday_ev_task.sh >/dev/null 2>&1 &
        
        c. 期货ev
            期货ev为每个交易日开盘前执行
            celeryconfig
            'auto_daily_ev_task': {
                'task': 'cron.strategy_upload_task.auto_daily_ev_task',
                'schedule': crontab(minute=[5], hour=[6, 7, 18, 19]),
            },
        d. 机器
            120， 140  149 116 60
            其中 149， 116，121,60 有GPU
            通过 get_task_queue 现在运行的机器 

# 回测盘后

# 回测

  ## 相关表
      策略 strategy
      策略文件 strategy_upload_file
      回测结果 strategy_result, backtest_result_detail, backtest_result_account
  ## 使用场景
  
  ### 使用场景1 策略上传
         策略上传回测是平台最基本的功能，研究员在本地按sdp框架写好策略代码，编译成so文件，上传到平台，配置好一系列参数之后，开始一段
         历史时间的模拟，通过观察交易的Pnl绩效，来简单评估策略的有效性。
         sdp框架 ，demo策略，编译的so方法等可以参考文档  /support/wiki.html
         主要参数：依赖的ev，订阅的行情等
         
         策略上传(strategy/index.html --> 新建) ---> 修改回测配置(开始日期，面值，成交模型等)，保存之后就会开始回测
         
         API 
         策略上传 POST /api/v1/strategy_upload/strategy 新建或者修改策略
         
         修改回测配置 POST /api/v1/strategy_upload/strategy/(?P<id>\w+)
            a. stop_task
            b. update_config
            c. start_strategy_task
                  delete last back_test result
                  start_task  --> start_back_test_task_v4
            start_back_test_task_v4 函数的作用就是根据配置的参数封装一个回测系统需要的task格式，然后将task写入redis 队列 new_master_add_task
            回测系统从队列中取出task做历史回测，将每日回测的结果写入相关的结果表中
                   
                
   ### 使用场景2 策略分析
         股票交易，期货交易 --> 策略组合与分析 --> 策略分析 --> 添加配置 / 重做
         添加配置是指使用相同的so，不同的参数clone一个策略，进行一段时间的历史回测，然后对比不同参数的回测结果
         添加配置：
            POST /api/v1/platform/statistic/performance/factor/strategy
            这个api 会clone 一个旧的策略，再更新新设置的一些参数，然后开始回测
            开始回测也是调用 start_strategy_task 函数
         重做：
            POST /api/v1/platform/statistic/strategy/backtest/(?P<id>\d+)$
            重做分为从第一天开始做，还是从上一次回测完成的日期开始做也就是接力
            重做流程是1.删除上一次回测的结果 2. 调用 start_strategy_task 函数
            接力： 1. 找到 上一次回测完成的最大的日期 max_date，
                  2. 删除 大于max_date 的回测结果
                  3. 调用 redo_strategy_papertrading
                  redo_strategy_papertrading 函数中会先删除 start_date 之后的回测指标
                  剩下的流程就和 start_strategy_task 一致了
   
   ### 每日自动papertrading
       由 celery 触发 auto_daily_task 函数
        
   回调函数
      strategy_back_test_trading_date_done 
          回测过程中每个夜盘或者日盘结束时调用，此函数主要是为了实时刷新回测结果指标
          由 BackTestPerformance.update_strategy(strategy_id) 完成计算
      back_test_done 
          一个task完成时调用
          刷新回测结果
          计算股票策略相关的指标
          import_stock_style_exposure.apply_async(args=(s_id,), countdown=15)
          import_stock_income_attribution.apply_async(args=(s_id,), countdown=15)
   
   回测结果计算
   Pnl 回测的pnl曲线 Strategy.back_test_output 函数
        调用 analysis.performance_analysis.PerformanceAnalyzer 计算，
        不要关注 这个包里面的计算逻辑，需要关注调用的入参，如初始资金，结束资金，初始仓位，结束仓位等
   年度指标， BackTestPerformance.update_strategy(strategy_id)   分年计算每一年的收益率，夏普，最大回测等
        年段指标的计算也是调用analysis.performance_analysis.PerformanceAnalyzer 只是输入参数只截取了其中某一年的数据
  
    
# 联合模拟

    ## 业务说明
        联合模拟基于回测，与回测的区别是：回测是单个策略独自进行；联合模拟是2个及以上策略一起进行，回测系统把一个tick的行情feed给每个子策略后，
        再分发下一个tick的行情，以此类推。
    ## 前端实现
        UI基于“策略及组合分析”
        1、新建联合模拟
            1)首先在“策略选择”tab页选择需要联合模拟的子策略；
            2)然后进入“策略分析”tab页，选择需要进行联合模拟的子策略，点击“联合模拟配置”按钮进行配置；配置完成后点击“开始回测”；
        2、重做&接力联合模拟
            参考上面“回测”--“使用场景2 策略分析”
        3、查看联合模拟结果
            点击联合模拟策略的净值曲线图，调整到联合模拟tab页
    ## 后端实现
        1、新建联合模拟
            后端收到请求后，会clone所有联合模拟的子策略，并创建一个新的联合模拟策略。
            新的联合模拟只是一个概念策略，没有实体so，strategy_type='34'。联合模拟策略及其子策略的node=union_simu。
            平台会根据参加联合模拟的子策略的信息组装回测任务下发到回测系统。回测系统会把联合模拟策略及其子策略的回报分别上报给平台。
            POST /api/v1/platform/statistic/stock/union_simulation
        2、重做&接力联合模拟
            参考上面“回测”--“使用场景2 策略分析”
        3、查看联合模拟结果
            基于“绩效分析”实现
            GET /api/v1/platform/statistic/union_simulation/performance/(?P<id>\d+)


# 结算(bss_server/new_settlement)
    相关表:
        结算结果
           结算后策略资金Pnl vs_base  
           结算后策略账户资金Pnl vs_account
           结算后策略账户持仓信息 vs_positions
        交易日志
           实盘交易日志 trade_logs 
           实盘手动调整的交易记录 settement_manual_tradelogs
        出入金
           vstrategy_account_detail
    
    1. 实盘每个交易日 07点计算，19点结算
       192.168.10.100 机器 crontab 
        07:  cd /home/rss/bss_server/strategy_upload/bin && sh settlement.sh 1 >/dev/null 2>&1 &
        19:  cd /home/rss/bss_server/strategy_upload/bin && sh settlement.sh 0 >/dev/null 2>&1 &
    
    2. 手动结算
        import sys
        sys.path.append('/home/rss/bss_server/strategy_upload/')
        sys.path.append('/home/rss/bss_server/strategy_upload/strategy_upload')
        from bin.daily_settlement import settle
        trading_date = '20200203'
        day_night = 0 | 1
        settle(trading_date, day_night)
    3. 重新计算某个策略的某一天
        trading_date = '20200203'
        day_night = 0 | 1
        r = settle(trading_date, day_night, v_id, notify=False)
        print(v_id, bool(r[v_id]))
        
        使用实时价格 有时早上自动结算失败，数据组外盘价格没入库，可以采用实时价格结算，传入 set_position=True, in_trading=True 两个参数
        in_trading 代表是否使用实时价格
        set_position 代表结果是否写入数据库
        r = settle(trading_date, day_night, v_id, notify=False, set_position=True, in_trading=True)
        print(v_id, bool(r[v_id]))
        
        如果 bool(r[v_id]) 为 False 结算失败，可以上sentry 根据上报的错误，定位失败的原因，一般是由于交易日志有误，多卖，或者时间顺序不对等
    4. 邮件报告(结算完自动发送)
        from cron.strategy_upload_task import settlement_notify
        settlement_notify('20200203', 1)
        或者手动检查是否都已经结算完成 两条sql都没有查询到记录就代表全部策略结算完成，否则就得定位原因，重新结算某个策略
        
        sql_summary = """select id, `status`, portfolio_id, strategy_id, closing_out, group_id, set_close_time
                         from vstrategies where `status`=15 and id not in (
                         select vstrategy_id from vs_base where settle_date='%s' and daynight='%s'
                         )""" % (trading_date, day_night)
        sql_summary2 = """select id, `status`, portfolio_id, strategy_id, closing_out, group_id, set_close_time
        from vstrategies
        where (id in (select DISTINCT vstrategy_id from vs_base))
        and id not in (select DISTINCT vstrategy_id from vs_base where settle_date='%s' and daynight='%s')
        and `status` not in (-1, 16)
            """ % (trading_date, day_night)


        结算简介：
            1. 我们用以下几个变量来简单表示一个策略的状态
                S = （cash， position， pnl）
             
                cash: 资金
                
                position： 仓位
                    symbol    volumn   price
                    
                    symbol1： volumn1  p1  
                    symbol2： volumn2  p2
                    symbol3： volumn3  p3
                pnl:  盈亏
            
            2. 使用logs 来表示 策略状态的变化
                    Time  Direction  OpenClose   Symbol  Volumn  Price
                l1  0900     0           0       000001   200     1
                l2
                l3
        
            3. 那么对于任意时刻T，T时刻的状态St 总是可以通过这些参数来计算：
               任意一个已知小于T时刻Ta的状态 Sa
               Ta时刻到T时刻之间所有发生的 Logs
               St.position.symbol1.volumn = Sa.position.symbol1.volumn 
                                + sum（[l.Volumn for l in Logs if l.Symbol == Sa.position.symbol1 and l.Direction == '买']）
                                - sum（[l.Volumn for l in Logs if l.Symbol == Sa.position.symbol1 and l.Direction == '卖']）
               
               任意时刻 仓位市值的计算为：
                   Value(St.position) =  sum([p.volumn * p.price for p in St.position])
               那么Sa 到 St的 Pnl
                   Pnl = Value(St.position) - Value(sa.position) 
                         + sum([l.Volumn * l.Price for l in Logs if l.Direction == '卖'])
                         - sum([l.Volumn * l.Price for l in Logs if l.Direction == '买'])
                   
                St.cash = Sa.cash + Pnl
        
        
    

# 实盘

## 交易跟踪

## 实盘绩效

## 其他指标

## 策略分析

## 因子开发

## 实盘运营管理
 
# 服务器列表
    192.168.10.100(121.46.13.124): web服务
                    celery 进程
    192.168.10.116: celery 进程(股票实盘ev)
    192.168.10.120: celery 进程(期货ev及其他计算任务)
    192.168.10.140: celery 进程(因子生产，ev生产)
    192.168.10.149: celery 进程(因子生产，ev生产)
    192.168.10.60: celery 进程(非实盘的ev生产等)
    
    用户统一为rss，密码由运营授权
    代码统一在/home/rss/bss_server/
    所有服务都通过superversord 管理
    发布时先从本地同步到192.168.10.100，100机器home目录下有同步到其他机器的脚本 sh rsync_xxx.sh
    sudo supervisorctl restart xxx 即可重启相关服务
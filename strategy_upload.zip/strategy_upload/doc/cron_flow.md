# celery 定时任务

## 每天定时下发papertrading
-  23点40分执行

```mermaid
graph TB
    A[cron.strategy_upload_task.auto_daily_task]
    B[service.back_test.models.Strategy.add_strategy_event]
    C[service.back_test.models.StrategyEventTrack.dd_strategy_event]

    A ==> B
    B ==> C
```
## 期货相关的ev
- 发送到120机器执行
- 每天 6点5分，7点5分，18点5分，19点5分执行
- start_task 见下面流程1.1

```mermaid
graph TB
    A[cron.strategy_upload_task.auto_daily_ev_task]
    B[cron.strategy_upload_task.strategy_ev_task]
    C[cron.strategy_upload_task.daily_auto_strategy_ev_task]
    D[service.back_test.models.Strategy.start_task]
    A== no check dependency ==>B
    A== check dependency ==> C
    C ==> D
```

## 股票相关的ev
- 3点执行
- 按用户和任务类型发送到不同的机器
- start_task 见下面流程1.1
```mermaid
graph TB
    A[cron.strategy_upload_task.auto_daily_ev_task_stock]
    B[cron.strategy_upload_task.strategy_ev_task]
    C[cron.strategy_upload_task.daily_auto_strategy_ev_task]
    D[service.back_test.models.Strategy.start_task]
    A== no check dependency ==>B
    A== check dependency ==> C
    C ==> D
```

## 其余少数几个ev
- 2点执行的
- start_task 见下面流程1.1

```mermaid
graph TB
    A[cron.strategy_upload_task.auto_daily_ev_task_stock_factor]
    B[cron.strategy_upload_task.strategy_ev_task]
    C[cron.strategy_upload_task.daily_auto_strategy_ev_task]
    D[service.back_test.models.Strategy.start_task]
    A== no check dependency ==>B
    A== check dependency ==> C
    C ==> D
```

## 因子pnl等数据papertrading计算

- 周一c触发

```mermaid
graph TB
    A[bin.factor_pool_papertrading]
    B[service.stock_factor.models.StockFactorStrategy.send_papertrading_event]
    C[consts.StockFactorEvaleQueue]
    D[bin.factor_evalue2.factor_evaluate_worker2]

    A ==> B
    B ==> C
    C == notify ==>D
```
---


# celery 异步任务触发流程

## 1. 策略生产和暂停

API URL: /api/v1/strategy_upload/strategy

### 1.1
```mermaid
graph TB
    A[service.stock_factor.handlers.StockFackotStrategyDetailHandler.post]
    B[service.back_test.models.Strategy.stop_task]
    C[service.back_test.models.Strategy.add_strategy_event]
    D[service.back_test.models.StrategyEventTrack.add_strategy_event]
    E[strategy_upload.cron.strategy_upload_task.start_strategy_task]
    F[cron.strategy_upload_task.start_strategy_task]
    G[cron.strategy_upload_task.ev_start_strategy_task]
    H[service.back_test.models.Strategy.start_task]
    I[cron.strategy_upload_task.get_task_queue]
    J[service.back_test.models.Strategy.start_ev_task_v3]
    K[service.back_test.models.Strategy.start_back_test_task_v4]
    L[service.back_test.models.Strategy.start_trade_list]


    A== stop ==>B
    A== ev,back_test,order_list,trademaster_order_list ==>E
    B ==> C
    C ==> D
    E ==> F
    F == ev ==> I
    I == yes ==> G
    I == no ==> H
    G ==> H
    F == back_test,order_list,trademaster_order_list ==> H
    H == ev ==> J
    H == back_test ==> K
    H == order_list,trademaster_order_list ==>  L
    
```
- start_ev_task_v3: 开始生产ev，调用流程见1.2
- start_back_test_task_v4: 函数的作用就是根据配置的参数封装一个回测系统需要的task格式，然后将task写入redis 队列 new_master_add_task


### 1.2
```mermaid
graph TB
    J[service.back_test.models.Strategy.start_ev_task_v3]
    N[cron.strategy_upload_task.ev_trading_date_done]
    M[service.back_test.models.Strategy.start_stock_factor_task]
    R[cron.strategy_upload_task.ev_task_done]
    W[service.stock_factor.models.StockFactorStrategy.stock_factor_publush_daily]
    X[service.stock_factor.models.StockFactorStrategy.stock_factor_publish]
    Y[service.stock_factor.csv2npq.gen_factor]

    J == stock factor ==> M
    J == other factor ==> N
    
    N ==> W
    W ==> X
    X ==> Y
    Y ==> R
    subgraph block two
    N
    W
    X
    Y
    end
```
- ev_trading_date_done ev计算每一天完成时调用
- ev_task_done ev计算整个任务完成时调用
- start_stock_factor_task 生产股票ev，调用流程见1.3


### 1.3
```mermaid
graph TB
    M[service.back_test.models.Strategy.start_stock_factor_task]
    O[service.back_test.models.Strategy.gen_stock_factor_from_csv]
    P[service.stock_factor.models.StockFactorStrategy.gen_factor_from_csv]
    Q[service.stock_factor.ev_factor2.StockEvGenerateFactor]
    R[cron.strategy_upload_task.ev_task_done]
    S[cron.strategy_upload_task.factor_task_done]
    T[service.stock_factor.models.StockFactorStrategy.send_simulator_event]
    U[cron.strategy_upload_task.factor_out_sample_done]
    V[cron.strategy_upload_task.factor_in_sample_done]
    Z[cron.strategy_upload_task.factor_trading_date_done]

    
    M == csv ==> O
    M == py,so ==>U
    U ==> V
    V ==> Z
    O ==> P
    P ==> Q
    Z ==> R
    R ==more than 20 days ==>S
    S==>T
```
- factor_out_sample_done 因子计算样本外完成时调用
- factor_in_sample_done 因子计算样本内完成时调用
- factor_trading_date_done 因子计算每天完成时调用,调用流程见1.4
- ev_task_done ev计算整个任务完成时调用
- factor_task_done 因子计算完成时调用


### 1.4
```mermaid
graph TB
    J[service.back_test.models.Strategy.start_ev_task_v3]
    Z[cron.strategy_upload_task.factor_trading_date_done]
    AA[service.stock_factor.factor_checkbias.do_check_bias]
    BB[service.stock_factor.factor_checkbias.check_bias_init]
    CC[service.stock_factor.factor_checkbias.check_bias_redo_check_date]
    DD[service.stock_factor.factor_checkbias.check_bias_compare]
    EE[cron.strategy_upload_task.redo_ev_task]
    
    Z ==> AA
    AA == UNINIT ==> BB
    AA == INITED ==> CC
    AA == REDO_CHECK_DATE ==> DD
    CC ==> EE
    EE ==> J
```
- redo_ev_task 假如在检查bias的过程发现，这个ev已经初始化过了，就会重算以前的ev
- start_ev_task_v3 见1.2

# 定时任务
## celery
   1. auto_daily_task  23点40分执行， 每天定时下发papertrading
   2. auto_daily_ev_task 
      非股票用户相关的ev，即期货相关的ev，发送到120机器执行
      每天 6点5分，7点5分， 18点5分，19点5分执行
      代码使用当前时间。
   3. auto_daily_ev_task_stock 股票相关的ev，3点执行，按用户和任务类型发送到不同的机器 
      可以参考 get_task_queue
   4. auto_daily_ev_task_stock_factor 两点执行，少数几个ev是放在2点执行的
   5. deploy_daily_check 盘前ev检查，开盘前45分钟执行，目前这个检查已经被更早的邮件报告取代
   6. auto_generate_daily_slippage 生产每日实盘股票策略的vwap绩效
   7. auto_vs_back_test 实盘策略的盘后分析 19点30 执行
   8. send_hedge_position， auto_send_cash_limit，send_cta_position_to_opt
      实盘相关的几个定时任务，目前功能基本没有在使用了，my-live_trading_cron 执行
   9. query_account_cash 期货账户账户风险查询，每10秒采样一次，对应显示页面/future/future-risk-monitor.html的数据
   
## celery 异步任务
   1. update_strategy_performance 主要是计算期货策略的pnl，绩效相关的数据，组合分析的时候可能会使用到
   2. update_stock_indicators_performance 计算股票的 日均股票数，撤单率，换手率等
   3. update_strategy_track_data_cache_new 更新交易跟踪的数据
   4. settlement_notify 结算通知
   5. update_strategy_sorting_result 计算 策略及组合分析页面的相关指标，策略的年度绩效等
   6. update_stock_hedge_vs 缓存 实盘股票策略，和对冲端之间的对应关系
   7. update_strategy_confidence 修改策略回测结果的可信度，目前该功能几乎没在使用了
   8. notify_vs_off_line 实盘测了下线通知
   9. strategy_back_test_trading_date_done 回测任务每个日盘或者夜盘执行完调用
   10. back_test_done 回测任务完成时调用
   11. vs_back_test_trading_date_done 盘后分析任务每个日盘或者夜盘执行完调用
   12. vs_back_test_done 盘后分析任务完成时调用， 用于更新绩效缓存
   13. import_stock_style_exposure 计算股票策略的风格偏离数据 回测任务完成时调用 /links/strategy-style-exposure.html?sid=215711&&vid=2032 点击策略ID时进入该页面
   14. import_stock_income_attribution 计算股票策略的收益归因，回测任务完成时调用 /links/strategy-income-attribution.html?sid=215711
   15. ev_trading_date_done ev计算每一天完成时调用
   16. ev_task_done ev计算整个任务完成时调用
   17. factor_trading_date_done 因子计算每天完成时调用
   18. factor_in_sample_done 因子计算样本内完成时调用
   19. factor_out_sample_done 因子计算样本外完成时调用
   20. factor_task_done 因子计算完成时调用
   21. gen_portfolio_daily_max_volume_ratio_delay 计算多个策略组合时的每日最大市场占比 组合分析页面
   22. generate_strategy_portfolio_risk_delay 计算多个策略组合时的风格偏离相关数据 组合分析页面
   23. generate_vs_portfolio_risk_delay 实盘每个策略集的风格偏离数据 实盘绩效页面
   24. generate_future_mkt_volumn_ratio_delay 计算期货账户的每日实盘交易占比 /future/trade-volume.html

## 100 机器crontab
    05 8 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh settlement.sh 1 >/dev/null 2>&1 &
        夜盘结算
    00 7 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh settlement.sh 1 >/dev/null 2>&1 &
        夜盘结算 7点执行一次是为了准备好回放的策略配置，但是有些策略可能由于数据没有结算失败，所以8点再执行一次
    00 19 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh settlement.sh 0 >/dev/null 2>&1 &
        日盘计算
    00 07 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh daily_error_ev.sh >/dev/null 2>&1 &
        某些ev需要放在最后执行，华健要求
    30 08 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh import_strategy_evaluation.sh >/dev/null 2>&1 &
        导入股票策略的IC数据等，需要绑定实盘策略和数据文件路径和 预测周期，策略升级版本后目前暂时没有此类跟踪数据
    25 05 * * 1-6 cd /home/rss/bss_server/strategy_upload/bin && sh copy_common_ev.sh >/dev/null 2>&1 &
        实盘公用的一些ev，组合优化，交易执行相关的，没有绑定到任何策略，每天的数据copy到一个公用的目录上传
    25 06 * * 1-6 cd /home/rss/bss_server/strategy_upload/bin && sh copy_common_ev.sh >/dev/null 2>&1 &
    58 06 * * 1-6 cd /home/rss/bss_server/strategy_upload/bin && sh copy_common_ev.sh >/dev/null 2>&1 &
    00 08 * * 1-6 cd /home/rss/bss_server/strategy_upload/bin && sh copy_common_ev.sh >/dev/null 2>&1 &
    00 06 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh daily_update_strategy_performance.sh 0 >/dev/null 2>&1 &
    00 20 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh daily_update_investment_performance.sh 0 >/dev/null 2>&1 &
        全量更新一次策略的实盘，回测绩效数据
    20 15 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh vwap_daily_download.sh >/dev/null 2>&1 &
        下载实盘股票策略的vwap数据
    50 15 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh import_vwap_orders.sh >/dev/null 2>&1 &
        导入实盘股票策略的vwap数据 vwap_orders, vwap_executions, vwap_indicators
    45 15 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh query_account_cash.sh >/dev/null 2>&1 &
        查询账户资金
    05 23 * * * cd /home/rss/volume_profile && python3.5 /home/rss/volume_profile/volume_profile.py > /home/rss/volume_profile/volume_profile.log 2>&1 &
        曾毅的任务
    45 16 * * * cd /home/rss/vwap_analyzer;python3.5 VWAP_analyzer_bss.py > cron_analyzer.log
        分析实盘股票策略的vwap数据 结果写入 vwap_result 
    30 05 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh daily_ev_check.sh >/dev/null 2>&1 &
        盘前ev检查
    00 06 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh daily_ev_check.sh >/dev/null 2>&1 &
    00 07 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh daily_ev_check.sh >/dev/null 2>&1 &
    00 19 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh daily_ev_check.sh >/dev/null 2>&1 &
    00 22 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh import_stock_factor_return.sh >/dev/null 2>&1 &
        每日计算股票市场的风格收益        
    30 21 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh stock_ev_night_generate.sh >/dev/null 2>&1 &
        股票ev 提前生产，某一些耗时的ev，需要使用的数据在晚上9点半之前就准备好了，就可以放在前一个交易日晚上9点半执行
    28 22 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh stock_ev_night_check.sh >/dev/null 2>&1 &
        夜晚的股票ev执行结果检查
    28 15 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh clear_t0_position.sh >/dev/null 2>&1 &
        每个交易日收盘后将T0 未平的仓位 导给 对应的Alpha策略
    30 19 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh set_strategy_offline.sh >/dev/null 2>&1 &
        结算后检查是否有下线的策略
    30 05 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh import_live_income_attribution.sh >/dev/null 2>&1 &
        全量计算股票策略的收益归因
    10 19 * * 1-5 cd /home/rss/bss_server/strategy_upload/bin && sh update_vs_t0_alpha_position.sh >/dev/null 2>&1 &
        统计实盘t0仓位因子的市值
    30 03 * * 1-6 cd /home/rss/bss_server/strategy_upload/bin && sh stock_weekday_ev_task.sh >/dev/null 2>&1 &
        周末或者假期提前计算下一个交易日的股票相关的ev生产
    30 10 * * 1 cd /home/rss/bss_server/strategy_upload/bin && sh factor_pool_papertrading.sh >/dev/null 2>&1 &
        因子pnl等数据papertrading计算
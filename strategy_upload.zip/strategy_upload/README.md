Install

0. pip install -i https://pypi.doubanio.com/simple virtualenv

1. virtualenv --python=python3 --no-site-packages venv

2. source venv/bin/activate

3. pip install -i https://pypi.doubanio.com/simple -r requirements.txt

#TODO Migrate from virtualenv to  python3 build-in module venv.
```
python3.5 -m venv /path/to/new/virtual/environment
```

from ..util import RecordUserMixin, RecordTimeMixin, BaseModel
from sqlalchemy import Column, BigInteger, Date, Boolean, Integer, JSON, VARCHAR


class LiveControlTrack(RecordUserMixin, RecordTimeMixin, BaseModel):
    __tablename__ = 'live_control_track'
    id = Column(Integer, primary_key=True, autoincrement=True)
    type = Column(Integer)
    seq = Column(Integer)
    vs_id = Column(Integer)
    data = Column(JSON)
    host = Column(VARCHAR)

from .example import ExampleModel

__all__ = ['ExampleModel']

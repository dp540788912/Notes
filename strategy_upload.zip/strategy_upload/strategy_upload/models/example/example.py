from sqlalchemy import Column, Integer, String
from ..util import AllBaseMixin, BaseModel


class ExampleModel(BaseModel, AllBaseMixin):
    id = Column(Integer, primary_key=True, autoincrement=True)
    value = Column(String(32), nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'value': self.value,
            'r_create_time': self.r_create_time.strftime('%Y%m%d'),
            'r_create_user_id': self.r_create_user_id
        }

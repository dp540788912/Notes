from ..util import BaseModel
from sqlalchemy import BIGINT, Column, VARCHAR, Boolean


class DeployConfs(BaseModel):
    __tablename__ = 'deploy_confs'

    id = Column(BIGINT, primary_key=True)
    host = Column(VARCHAR(255))
    name = Column(VARCHAR(255))
    deploy_path = Column(VARCHAR(255))
    vstrategy_id = Column(BIGINT)
    valid = Column(Boolean, default=True, nullable=True)

from sqlalchemy import Column, DateTime, Integer, Boolean
from sqlalchemy.sql import func
from sqlalchemy.ext.declarative import declared_attr, declarative_base
from functools import reduce


class JsonSerializableBase:
    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}


BaseModel = declarative_base(cls=(JsonSerializableBase,))


def migrate(base_model, engine, model=None):
    """
    create table using orm
    :param base_model: sqlalchemy declarative base class
    :param engine: sqlalchemy engine obj
    :param model: model class needed to migrate
    :return:
    """
    if model is None:
        base_model.metadata.create_all(engine)
    else:
        model.__table__.create(engine, checkfirst=True)


class RecordTimeMixin(object):
    """
    record row modification time
    """
    r_create_time = Column(DateTime, nullable=False, server_default=func.now())
    r_update_time = Column(DateTime, nullable=False, server_default=func.now(), onupdate=func.now())


class RecordUserMixin(object):
    """
    record operator id
    """
    r_create_user_id = Column(Integer, nullable=False)
    r_update_user_id = Column(Integer, nullable=True)


class SoftDeleteMixin(object):
    """
    record deleted status
    """
    deleted = Column(Boolean, nullable=False, index=True, default=False)


class AutoTableNameMixin(object):
    """
    auto create db table name based on class name
    """

    @staticmethod
    def _name_formatter(name):
        return reduce(lambda x, y: x + ('_' if y.isupper() else '') + y, name).lower()

    @declared_attr
    def __tablename__(cls):
        return cls._name_formatter(cls.__name__)


class AllBaseMixin(RecordTimeMixin, RecordUserMixin, SoftDeleteMixin, AutoTableNameMixin):
    """
    base mixin class all in one
    """
    pass

from sqlalchemy import Column, BigInteger, Date, Boolean

from ..util import AllBaseMixin, BaseModel, RecordTimeMixin, SoftDeleteMixin, AutoTableNameMixin


class VsRelationBase(AllBaseMixin):
    """
    base class of vs relation
    """
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    vs_id = Column(BigInteger, index=True, nullable=False)
    link_vs_id = Column(BigInteger, index=True, nullable=False)
    link_date = Column(Date, nullable=False)
    unlink_date = Column(Date, nullable=True)


class VsT0Relation(VsRelationBase, BaseModel):
    """
    table: vs_t0_relation
    record vs and t0 vs relation
    """
    share_resp = Column(Boolean, nullable=False, default=False)


class VsHedgeRelation(VsRelationBase, BaseModel):
    """
    table: vs_hedge_relation
    record vs and hedge vs relation
    """
    pass


class UnionSimuStrategyRelation(RecordTimeMixin, SoftDeleteMixin, AutoTableNameMixin, BaseModel):
    """
    table: union_simu_strategy_relation
    record union simu strategy relation
    """
    id = Column(BigInteger, primary_key=True, autoincrement=True)
    main_s_id = Column(BigInteger, index=True, nullable=False)
    link_s_id = Column(BigInteger, index=True, nullable=False)

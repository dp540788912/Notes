# -*-coding:utf-8-*-
import asyncio
import tornado.ioloop
import tornado.web
from tornado.options import define, options
from tornado.platform.asyncio import AsyncIOMainLoop
from statsd import StatsClient
from raven import Client as Sentry

from service.urls import urls
from config import config
from log import logger


class Application(tornado.web.Application):
    def __init__(self, handlers):
        self.logger = logger
        self.cfg = config
        self.sentry = Sentry(self.cfg.sentry_dsn)
        self.statsd = StatsClient(host=self.cfg.statsd['host'], port=self.cfg.statsd['port'])
        tornado.web.Application.__init__(self, handlers, debug=self.cfg.Debug, xsrf_cookies=False)


def make_app():
    return Application(urls)


if __name__ == "__main__":
    define("port", default=18887, help="run on the given port", type=int)
    AsyncIOMainLoop().install()
    options.parse_command_line()
    app = make_app()
    app.listen(options.port, xheaders=True)
    asyncio.get_event_loop().run_forever()

# -*-coding:utf-8-*-


import sys
import json
import datetime
import math
import numpy as np
import pandas as pd
from dateutil.parser import parse
from qpython import qconnection

from config import config as cfg


def format_str(s, encoding='utf-8'):
    if sys.version_info >= (3, 0):
        return str(s, encoding)
    else:
        return s


def transform_date(int_days):
    begin = datetime.datetime(2000, 1, 1)
    return (begin + datetime.timedelta(days=int_days)).strftime('%Y%m%d')


class KdbQuery(object):
    def __init__(self, host=cfg.KDB_HOST, port=cfg.KDB_PORT,
                 username=cfg.KDB_USER, password=cfg.KDB_PASSWD):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.connect()

    def __del__(self):
        self.release()

    def reconnect(self):
        try:
            self.release()
        finally:
            return self.connect()

    def release(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def connect(self):
        try:
            self.conn = qconnection.QConnection(host=self.host, port=self.port,
                                                username=self.username, password=self.password)
            self.conn.open()
            return self.conn.is_connected()
        except Exception as err:
            return False

    def check(self):
        if self.conn.is_connected():
            return True
        else:
            return False

    def sync_query(self, q_sql):
        data = None
        if self.check():
            data = self.conn.sync(str(q_sql))
        return data

    def async_query(self, q_sql, **kwargs):
        data = None
        if self.check():
            self.conn.async(str(q_sql))
            data = self.conn.receive(**kwargs)
        return data

    def query_all_data(self, q_sql):
        data = None
        if self.check():
            self.conn.async(str(q_sql))
            data = self.conn.receive(data_only=False, raw=False)
        return data

    def internal_days_to_product_trading_days(self, product, is_night, start_date, end_date, is_level1):
        """

        :param product:
        :param is_night:
        :param start_date: YYYY.MM.DD
        :param end_date: YYYY.MM.DD
        :param is_level1:
        :return:
        """
        all_date = {}
        single_product = False
        if isinstance(product, (list, tuple)):
            product = '`'.join(product)
        else:
            single_product = True
        if is_level1:
            q_sql = ".gw.asyncexec[(`GetProductDate;`InternalDate;`TradeDate;`%s;(%s;`CTP);(%s;%s));`FuturesBasicInfo]" % \
                    (product, is_night, start_date, end_date)
        else:
            q_sql = ".gw.asyncexec[(`GetProductDate;`InternalDate;`TradeDate;`%s;%s;(%s;%s));`FuturesBasicInfo]" % \
                    (product, is_night, start_date, end_date)
        q_data = self.async_query(q_sql)
        all_date = json.loads(str(q_data, 'utf-8'))
        if single_product:
            return all_date.get(product, {})
        else:
            return all_date

    def product_price(self, date):
        q_sql = '.gw.asyncexec["select from CFuturesEODPrices where TRADE_DT=%s";`FuturesBasicInfo]' % date
        q_ret = self.async_query(q_sql)
        return q_ret

    def get_open_price(self, days, symbols):
        open_price = []
        open_price_index, symbol_index = -1, -1
        for d in days:
            ret = self.product_price(d)
            if (open_price_index < 0) or (symbol_index < 0):
                df = pd.DataFrame(ret)
                open_price_index = list(df.columns.values).index('OPENPRICE')
                symbol_index = list(df.columns.values).index('SYMBOL')
                open_price.append({str(r[symbol_index], 'utf-8'): r[open_price_index]
                                   for r in ret if (str(r[symbol_index], 'utf-8') in symbols)})
        return open_price

    def symbol_price(self, date, symbol):
        q_sql = '.gw.asyncexec["select from CFuturesEODPrices where TRADE_DT=%s, (lower SYMBOL)=`%s";`FuturesBasicInfo]' % (
            date, symbol)
        q_ret = self.async_query(q_sql)
        return q_ret

    def get_symbol_settleprice(self, day, symbol):
        ret = self.symbol_price(day, symbol.lower())
        df = pd.DataFrame(ret)
        columns = list(df.columns.values)
        settle_price_index = columns.index('SETTLEPRICE')
        for r in ret:
            if str(r[symbol_index], 'utf-8').lower() == symbol.lower():
                return {
                    'settle_price': r[settle_price_index],
                }
        return {}

    def get_price(self, day, symbol, product):
        ret = self.symbol_price(day, symbol.lower())
        df = pd.DataFrame(ret)
        columns = list(df.columns.values)
        close_price_index = columns.index('CLOSEPRICE')
        open_price_index = columns.index('OPENPRICE')
        last_close_price_index = columns.index('PRELASTCLOSE')
        symbol_index = columns.index('SYMBOL')
        volume_index = columns.index('VOLUME')
        amount_index = columns.index('AMOUNT')
        for r in ret:
            if str(r[symbol_index], 'utf-8').lower() == symbol.lower():
                unit = self.get_product_unit(product)
                return {
                    'close_price': r[close_price_index],
                    'open_price': r[open_price_index],
                    'last_close_price': r[last_close_price_index],
                    'volume': r[volume_index],
                    'amount': r[amount_index],
                    'avg_price': (10000.00 / unit) * (float(r[amount_index]) / r[volume_index]),
                    'unit': unit,
                }
        return {}

    def get_product_unit(self, product):
        if product.lower().startswith(("sh", "dl", "zz")):
            product = product[2:]
        q_sql = '.gw.asyncexec[" select distinct S_INFO_CODE, S_INFO_PUNIT:N from CFuturescontpro ' \
                'where S_INFO_CODE=`%s";`FuturesBasicInfo]' % product.upper()
        q_ret = self.async_query(q_sql)
        return q_ret[0][1]

    def get_stock_price(self, date, symbol):
        q_sql = ".gw.asyncexec[\"select S_DQ_PRECLOSE, S_DQ_OPEN , S_DQ_CLOSE, S_DQ_AVGPRICE " \
                "from AShareEODPrices where TRADE_DT=%s, SYMBOL=`%s \"; `EquityFactor]" % (date, symbol)
        r = self.async_query(q_sql)[0]
        return {
            'last_close_price': r[0],
            'open_price': r[1],
            'close_price': r[2],
            'avg_price': r[3],
        }

    def get_spot_price(self, date, constituentcode):
        sql1 = """.gw.asyncexec["select S_DQ_OPEN, S_DQ_CLOSE, S_DQ_AVGPRICE, TRADE_DT from CGoldSpotEODPrices
                where TRADE_DT=%s, CONSTITUENTCODE=`$(\\"%s\\")";`FuturesBasicInfo]""" % (date, constituentcode)
        df1 = pd.DataFrame(self.async_query(sql1))
        if len(df1.values) <= 0:
            return {}
        row = df1.values[0]
        res = {
            'last_close_price': 0,
            'open_price': float(row[0]),
            'close_price': float(row[2]),
            'avg_price': float(row[2]),
        }

        sql2 = """.gw.asyncexec["select S_DQ_CLOSE, TRADE_DT from CGoldSpotEODPrices
                where TRADE_DT < %s, CONSTITUENTCODE=`$(\\"%s\\")";`FuturesBasicInfo]""" % (date, constituentcode)
        df2 = pd.DataFrame(self.async_query(sql2))
        res['last_close_price'] = float(df2.loc[[df2['TRADE_DT'].idxmax()]]['S_DQ_CLOSE'].values[0])
        return res

    def get_symbol_product(self, symbols):
        symbols = ';'.join(['\\"%s\\"' % s.lower() for s in symbols])
        q_sql = """.gw.asyncexec["select distinct SYMBOL, PRODUCT from CFuturesEODPrices
        where TRADE_DT>=2017.01.01, (lower SYMBOL) in `$(%s)";`FuturesBasicInfo]""" % symbols
        ret = self.async_query(q_sql)
        return {str(r[0], 'utf-8').lower(): str(r[1], 'utf-8').lower() for r in ret}

    def get_products_unit(self, symbols):
        symbols = ';'.join(['\\"%s\\"' % s.lower() for s in symbols])
        q_sql = """.gw.asyncexec["(select distinct S_INFO_CODE:CONSTITUENTCODE, S_INFO_PUNIT from CGoldSpotContpro
        where (lower CONSTITUENTCODE) in `$(%s)) union (
        select distinct S_INFO_CODE, S_INFO_PUNIT:N from CFuturescontpro where (lower S_INFO_CODE) in `$(%s)
        )";`FuturesBasicInfo]""" % (symbols, symbols)
        q_ret = self.async_query(q_sql)
        return {str(r[0], 'utf-8').lower(): r[1] for r in q_ret}

    def get_fee_data(self, date):
        q_sql = """.gw.asyncexec["select Product,`ByVol=FeeMode, MyIntraSimuFee, MyInterSimuFee
        from FeeRateV2 where date= %s"; `FeeRateDB]""" % date
        q_ret = self.async_query(q_sql)
        detail = {
            str(r[0], 'utf-8').lower(): {
                'FeeMode': bool(r[1]),
                'MyIntraSimuFee': float(r[2]),
                'MyInterSimuFee': float(r[3]),
            }
            for r in q_ret
        }
        return {
            date: detail
        }

    def get_symbol_exchange(self):
        q_sql = """.gw.asyncexec[\"raze {select EXCHANGE,PRODUCT,SYMBOL from x where date=last date}
        peach `MainCon`FMainCon \"; `FuturesBasicInfo]"""
        q_ret = self.async_query(q_sql)
        res = {}
        for r in q_ret:
            exch = str(r[0], 'utf-8').upper()
            res[str(r[1], 'utf-8')] = exch
            res[str(r[2], 'utf-8')] = exch
        return res

    def stock_symbols_price(self, begin_date, end_date, symbols):
        symbol_str = '`'.join([s.lower() for s in symbols])
        q_sql = ".gw.asyncexec[\"select SYMBOL, TRADE_DT, S_DQ_PRECLOSE, S_DQ_OPEN , S_DQ_CLOSE, S_DQ_AVGPRICE " \
                "from AShareEODPrices where TRADE_DT>=%s, TRADE_DT<=%s, (lower SYMBOL) in `%s \"; `EquityFactor]" % (
                    begin_date, end_date, symbol_str
                )
        q_ret = self.async_query(q_sql)
        df = pd.DataFrame(q_ret)
        df['TRADE_DT'] = df['TRADE_DT'].apply(transform_date)
        df['SYMBOL'] = df['SYMBOL'].apply(lambda s: str(s, 'utf-8').split('.')[0].lower())
        columns = list(df.columns.values)
        last_close_price_index = columns.index('S_DQ_PRECLOSE')
        open_price_index = columns.index('S_DQ_OPEN')
        close_price_index = columns.index('S_DQ_CLOSE')
        avg_price_price_index = columns.index('S_DQ_AVGPRICE')
        price_details = {}
        for k, g in df.groupby(['SYMBOL', 'TRADE_DT']):
            key = '_'.join(k)
            for v in g.values:
                price_details[key] = {
                    'last_close_price': v[last_close_price_index],
                    'open_price': v[open_price_index],
                    'close_price': v[close_price_index],
                    'avg_price': v[avg_price_price_index],
                }
        return price_details

    def future_symbols_price(self, begin_date, end_date, symbols):
        symbol_str = '`'.join([s.lower() for s in symbols])
        q_sql = '.gw.asyncexec["select from CFuturesEODPrices where TRADE_DT>=%s, TRADE_DT<=%s, (lower SYMBOL) in `%s";`FuturesBasicInfo]' % (
            begin_date, end_date, symbol_str)
        q_ret = self.async_query(q_sql)
        df = pd.DataFrame(q_ret)
        df['TRADE_DT'] = df['TRADE_DT'].apply(transform_date)
        df['SYMBOL'] = df['SYMBOL'].apply(lambda s: str(s, 'utf-8').lower())
        df['PRODUCT'] = df['PRODUCT'].apply(lambda s: str(s, 'utf-8').lower())
        columns = list(df.columns.values)
        close_price_index = columns.index('CLOSEPRICE')
        open_price_index = columns.index('OPENPRICE')
        last_close_price_index = columns.index('PRELASTCLOSE')
        symbol_index = columns.index('SYMBOL')
        volume_index = columns.index('VOLUME')
        amount_index = columns.index('AMOUNT')
        product_index = columns.index('PRODUCT')
        products = list(set(df['PRODUCT'].values))
        units = self.get_products_unit(products)
        price_details = {}
        for k, g in df.groupby(['SYMBOL', 'TRADE_DT']):
            key = '_'.join(k)
            for v in g.values:
                if (units.get(v[product_index], 0) or 0) <= 0:
                    continue
                if (v[volume_index] == 0):
                    continue
                price_details[key] = {
                    'close_price': v[close_price_index],
                    'open_price': v[open_price_index],
                    'last_close_price': v[last_close_price_index],
                    'avg_price': (10000.00 / units[v[product_index]]) * (float(v[amount_index]) / v[volume_index]),
                }
        return price_details

    def spot_symbols_price(self, begin_date, end_date, symbols):
        begin_date = (parse(begin_date) - datetime.timedelta(days=100)).strftime('%Y.%m.%d')
        symbols_str = ';'.join(['\\"%s\\"' % s.lower() for s in symbols])
        sql = """.gw.asyncexec["select CONSTITUENTCODE, S_DQ_OPEN, S_DQ_CLOSE, S_DQ_AVGPRICE, TRADE_DT from CGoldSpotEODPrices
                where TRADE_DT>=%s, TRADE_DT<=%s, (lower CONSTITUENTCODE) in `$(%s)";`FuturesBasicInfo]""" % (
            begin_date, end_date, symbols_str
        )
        df = pd.DataFrame(self.async_query(sql))
        df['TRADE_DT'] = df['TRADE_DT'].apply(transform_date)
        df['SYMBOL'] = df['CONSTITUENTCODE'].apply(lambda s: str(s, 'utf-8').lower())
        columns = list(df.columns.values)
        close_price_index = columns.index('S_DQ_CLOSE')
        open_price_index = columns.index('S_DQ_OPEN')
        avg_price_price_index = columns.index('S_DQ_AVGPRICE')
        symbol_index = columns.index('SYMBOL')
        trade_date_index = columns.index('TRADE_DT')
        price_details = {}
        for k, g in df.groupby(['SYMBOL']):
            values = list(g.sort_values(['TRADE_DT']).values)
            for i, v in enumerate(values):
                key = '%s_%s' % (k, v[trade_date_index])
                price_details[key] = {
                    'close_price': v[close_price_index],
                    'open_price': v[open_price_index],
                    'avg_price': v[avg_price_price_index],
                }
                if i == 0:
                    price_details[key]['last_close_price'] = price_details[key]['open_price']
                else:
                    price_details[key]['last_close_price'] = values[i - 1][close_price_index]
        return price_details

    def get_trading_date(self, hour=18, calendar_date=None, calendar_hour=None):
        now = datetime.datetime.now()
        if not calendar_date:
            calendar_date = now.strftime('%Y%m%d')
        now_hour = now.hour
        if calendar_hour:
            now_hour = int(calendar_hour)
        q_sql = """.gw.asyncexec["select TRADE_DT from Calendar where EXCHANGE=`SSE, TRADE_DT>=2017.01.01";`FuturesBasicInfo]"""
        ret = self.async_query(q_sql)
        dates = [r[0] for r in ret]
        for d in sorted(dates):
            d = transform_date(int(d))
            if now_hour >= hour:
                if d > calendar_date:
                    return d
            else:
                if d >= calendar_date:
                    return d
        raise ValueError('get trading date error')

    def get_symbol_details(self):
        res = {}
        q_sql = """.gw.asyncexec[\"select S_INFO_SECURITIESTYPES, S_INFO_CODE, EXCHMARKET
        from WindCustomCode where (`$S_INFO_SECURITIESTYPES) in `FU`A`NM`G,(`$EXCHMARKET) in `CFFEX`DCE`CZCE`SHFE`SSE`SZSE`SGE\";`EquityFactor]"""
        df = self.async_query(q_sql, pandas=True)
        df['S_INFO_SECURITIESTYPES'] = df['S_INFO_SECURITIESTYPES'].apply(lambda s: str(s, 'utf-8').upper())
        df['S_INFO_CODE'] = df['S_INFO_CODE'].apply(lambda s: str(s, 'utf-8').lower())
        df['EXCHMARKET'] = df['EXCHMARKET'].apply(lambda s: str(s, 'utf-8').upper())
        for index, row in df.iterrows():
            res[row['S_INFO_CODE']] = {
                'product': row['S_INFO_CODE'],
                'exchange': row['EXCHMARKET'],
                'type': row['S_INFO_SECURITIESTYPES']
            }
        return res

    def get_all_products_unit(self):
        q_sql = """.gw.asyncexec["(select distinct S_INFO_CODE:CONSTITUENTCODE, S_INFO_PUNIT from CGoldSpotContpro) union (
        select distinct S_INFO_CODE, S_INFO_PUNIT:N from CFuturescontpro)";`FuturesBasicInfo]"""
        q_ret = self.async_query(q_sql)
        return {str(r[0], 'utf-8').lower(): r[1] for r in q_ret}

    def get_nebor_trading_date(self, trading_date):
        trading_date = parse(trading_date)
        begin_date = (trading_date - datetime.timedelta(days=100)).strftime('%Y.%m.%d')
        q_sql = """.gw.asyncexec["select TRADE_DT from Calendar where EXCHANGE=`SSE, TRADE_DT>=%s";`FuturesBasicInfo]""" % begin_date
        ret = self.async_query(q_sql)
        dates = sorted([r[0] for r in ret])
        for index, d in enumerate(dates):
            d = transform_date(int(d))
            if d == trading_date.strftime('%Y%m%d'):
                return {
                    'prev': transform_date(int(dates[index - 1])),
                    'next': transform_date(int(dates[index + 1]))
                }
        raise ValueError('get trading date error')

    def get_stock_index_data(self, symbol, begin_date, end_date):
        sql = """.gw.asyncexec["select SYMBOL,TRADE_DT,S_DQ_PCTCHANGE from AIndexEODPrices  where date within %s %s , SYMBOL=`%s";`EquityFactor]
        """ % (begin_date, end_date, symbol)
        return self.async_query(sql, pandas=True)

    def get_future_index_data(self, symbol, begin_date, end_date):
        sql = """.gw.asyncexec["(select lower SYMBOL,TRADE_DT:NEXTDATE from MainCon
        where NEXTDATE within ({begin_date},{end_date}),(lower MAINFLAG) in  lower `{symbol})
        lj `SYMBOL`TRADE_DT xkey select SYMBOL,TRADE_DT,PRODUCT,PRELASTCLOSE,OPENPRICE,CLOSEPRICE from CFuturesEODPrices
        where date within ({begin_date},{end_date})";`FuturesBasicInfo]""".format(
            **{'begin_date': begin_date, 'end_date': end_date, 'symbol': symbol})
        return self.async_query(sql, pandas=True)

    def get_hedge_ret(self, hedge, begin_date, end_date):
        hedge = hedge.lower()
        begin_date = parse(begin_date).strftime('%Y.%m.%d')
        end_date = parse(end_date).strftime('%Y.%m.%d')
        symbol_map = {
            'hs300': '000300.SH',
            'zz500': '000905.SH',
            'sz50': '000016.SH',
            'if': 'if1',
            'ih': 'ih1',
            'ic': 'ic1',
            'if_tmp': '000300.SH',
            'ih_tmp': '000016.SH',
            'ic_tmp': '000905.SH',
        }
        ret = pd.DataFrame()
        if hedge in ('hs300', 'zz500', 'sz50'):
            symbol = symbol_map[hedge]
            s1 = self.get_stock_index_data(symbol, begin_date, end_date)
            ret['date'] = s1.TRADE_DT.apply(lambda d: d.strftime('%Y-%m-%d'))
            ret['hedge_ret'] = s1.S_DQ_PCTCHANGE / 100.0
        elif hedge in ('if', 'ih', 'ic'):
            symbol = symbol_map[hedge]
            s1 = self.get_future_index_data(symbol, begin_date, end_date)
            s1.PRELASTCLOSE.loc[np.isnan(s1.PRELASTCLOSE)] = s1.OPENPRICE
            ret['date'] = s1.TRADE_DT.apply(lambda d: d.strftime('%Y-%m-%d'))
            ret['hedge_ret'] = s1.CLOSEPRICE / s1.PRELASTCLOSE - 1.0

            if begin_date < '2015.04.16' and hedge in ('ih', 'ic'):
                symbol = symbol_map['%s_tmp' % hedge]
                s2 = self.get_stock_index_data(symbol, begin_date, '2015.04.15')
                s3 = pd.DataFrame()
                s3['date'] = s2.TRADE_DT.apply(lambda d: d.strftime('%Y-%m-%d'))
                s3['hedge_ret'] = s2.S_DQ_PCTCHANGE / 100.0
                ret = ret.append(s3)
            elif begin_date < '2010.04.16' and hedge in ('if'):
                symbol = symbol_map['%s_tmp' % hedge]
                s2 = self.get_stock_index_data(symbol, begin_date, '2010.04.15')
                s3 = pd.DataFrame()
                s3['date'] = s2.TRADE_DT.apply(lambda d: d.strftime('%Y-%m-%d'))
                s3['hedge_ret'] = s2.S_DQ_PCTCHANGE / 100.0
                ret = ret.append(s3)
        else:
            raise ValueError('get hedge ret error: %s' % hedge)
        ret.set_index('date', inplace=True)
        return ret.to_dict()['hedge_ret']

    def get_corp_actions(self, kdb_start_date, kdb_end_date):

        def to_date(_padas_ts):
            if pd.notnull(_padas_ts):
                return _padas_ts.strftime('%Y%m%d')
            return '19000101'

        def convert_nan(_f):
            if math.isnan(_f):
                return 0
            return _f

        data_d = {}

        q_sql = """.gw.asyncexec[" 0! delete OBJECT_ID,UPDATETIME from select by OBJECT_ID from `OBJECT_ID`UPDATETIME xasc  select OBJECT_ID,UPDATETIME, 
                                     SYMBOL,EQY_RECORD_DT,EX_DT,LISTING_DT_OF_DVD_SHR,S_DIV_BONUSRATE,S_DIV_CONVERSEDRATE from AShareDividend 
                                where (EQY_RECORD_DT>%s) & (EQY_RECORD_DT<%s) & ( (S_DIV_BONUSRATE>0) | (S_DIV_CONVERSEDRATE>0) ) "; `EquityFactor]' 
                 """ % (kdb_start_date, kdb_end_date)

        q_ret_df = self.async_query(q_sql, pandas=True)
        if q_ret_df is None:
            return data_d

        # date_d = {'eqy':{}, #股权登记，相关股票 'ex':{},  #除权除息日，相关股票 'listing':{},#红股上市日，相关股票 }

        for index, row in q_ret_df.iterrows():
            symbol = row['SYMBOL'].decode('utf-8')
            k = symbol.rfind('.')
            symbol = symbol[:k]

            record_dt = to_date(row['EQY_RECORD_DT'])
            k = '%s-%s' % (record_dt, symbol)

            data_d[k] = {'eqy_dt': record_dt,
                         'ex_dt': to_date(row['EX_DT']),
                         'listing_dt': to_date(row['LISTING_DT_OF_DVD_SHR']),
                         'ratio': convert_nan(row['S_DIV_BONUSRATE']) + convert_nan(row['S_DIV_CONVERSEDRATE'])
                         }

        return data_d

    def get_today_next_trading_date(self, trading_date):

        trading_date = parse(trading_date)
        begin_date = (trading_date - datetime.timedelta(days=100)).strftime('%Y.%m.%d')
        q_sql = """.gw.asyncexec["select TRADE_DT from Calendar where EXCHANGE=`SSE, TRADE_DT>=%s";`FuturesBasicInfo]""" % begin_date
        ret = self.async_query(q_sql)
        dates = sorted([r[0] for r in ret])

        today_is_trading_day = False
        is_next = True

        for index, d in enumerate(dates):
            d = transform_date(int(d))
            if d == trading_date.strftime('%Y%m%d'):
                today_is_trading_day = True
                return today_is_trading_day, transform_date(int(dates[index + 1])), transform_date(
                    int(dates[index + 2]))

            if d > trading_date.strftime('%Y%m%d'):
                if is_next:
                    is_next = False
                    continue
                return today_is_trading_day, transform_date(int(dates[index - 1])), d

        raise ValueError('get trading date error')

    def get_trading_days_since(self, _date):
        q_sql = """.gw.asyncexec["select TRADE_DT from Calendar where EXCHANGE=`SSE, TRADE_DT>=%s";`FuturesBasicInfo]""" % _date
        ret = self.async_query(q_sql)
        dates = sorted([r[0] for r in ret])

        return [transform_date(int(d)) for d in dates]  # format : %Y%m%d

    def get_trading_days_kdb(self, begindate, enddate):
        begindate = parse(begindate).strftime('%Y.%m.%d')
        enddate = parse(enddate).strftime('%Y.%m.%d')
        q_sql = """
        .gw.asyncexec["select TRADE_DT from Calendar where EXCHANGE=`SSE, TRADE_DT>=%s, TRADE_DT<=%s";`FuturesBasicInfo]
        """ % (begindate, enddate)
        ret = self.async_query(q_sql)
        dates = sorted([r[0] for r in ret])
        return [transform_date(int(d)) for d in dates]

    def get_trading_days(self, begindate, enddate):
        try:
            return self.get_trading_days_npq(begindate, enddate)
        except Exception as e:
            return self.get_trading_days_kdb(begindate, enddate)

    def get_trading_days_npq(self, begindate, enddate):
        from my.data import meta_api
        begindate = int(parse(begindate).strftime('%Y%m%d'))
        enddate = int(parse(enddate).strftime('%Y%m%d'))
        dates = meta_api.get_trading_date_range(begindate, enddate, 'SSE')
        return [str(int(d.replace('-', ''))) for d in dates]

    def get_last_trading_date(self, _date):
        qsql = '.gw.asyncexec["select max TRADE_DT from Calendar where TRADE_DT <%s";`FuturesBasicInfo]' % _date
        q_ret = self.async_query(qsql)
        q_ret = [x[0] for x in q_ret]
        days = int(q_ret[0])
        origin_date = datetime.date(2000, 1, 1)
        return str(origin_date + datetime.timedelta(days=days))

    def get_next_trading_date(self, _date):
        qsql = '.gw.asyncexec["select min TRADE_DT from Calendar where TRADE_DT >%s";`FuturesBasicInfo]' % _date
        q_ret = self.async_query(qsql)
        q_ret = [x[0] for x in q_ret]
        days = int(q_ret[0])
        origin_date = datetime.date(2000, 1, 1)
        return str(origin_date + datetime.timedelta(days=days))

    def is_trading_date(self, _date):
        qsql = ".gw.asyncexec[(`GetTradeDate;`sse;(%s;%s));`EquityFactor]" % (_date, _date)
        trading_date = self.async_query(qsql)
        if not trading_date:
            return False
        if _date.replace('.', '') != str(trading_date[0][0]):
            return False
        else:
            return True

    def get_forex_rate(self, trading_date):
        trading_date = parse(trading_date).strftime('%Y.%m.%d')
        q_sql = """.gw.asyncexec["select distinct date from ForeignEODPrices where date>= 2000.01.01,DATASOURCE =`ForexDB"; `FuturesBasicInfo]"""
        df = self.async_query(q_sql, pandas=True)
        dates = df['date'].apply(lambda s: s.strftime('%Y.%m.%d')).values
        if trading_date not in dates:
            dates = sorted(list(dates) + [trading_date])
            index = dates.index(trading_date)
            if index == 0:
                trading_date = dates[1]
            else:
                trading_date = dates[index - 1]
        q_sql = """.gw.asyncexec["select from ForeignEODPrices where date= %s,DATASOURCE =`ForexDB"; `FuturesBasicInfo]""" % trading_date
        df = self.async_query(q_sql, pandas=True)
        df['SYMBOL'] = df['SYMBOL'].apply(lambda s: s.decode('utf-8').lower())
        res = {
            'cny': 1.0
        }
        for index, row in df.iterrows():
            try:
                if 'cnh' not in row['SYMBOL']:
                    continue
                currency = row['SYMBOL'].split('.')
                if currency[1] == 'cnh':
                    res[currency[0]] = float(row['SETTLEPRICE'])
                elif currency[0] == 'cnh':
                    res[currency[1]] = 1 / float(row['SETTLEPRICE'])
            except Exception as e:
                pass
        return res

    def get_foreign_symbols_feerate(self):
        last_fee_sql = """.gw.asyncexec["select Product, MyProduct,ExchCode,`ByVol=FeeMode,TradeUnit, MyIntraSimuFee,TickSize,
        MyInterSimuFee,ExchIntraOpenFee,ExchInterOpenFee,ExchIntraCloseFee, ExchInterCloseFee,MyBrokerOpenFee,MyBrokerCloseFee,date,Category,Currency
        from ForeignFeeRateV2 where date = last date ";`FeeRateDB]"""
        df = self.async_query(last_fee_sql, pandas=True)
        df['Product'] = df['Product'].apply(lambda s: format_str(s, 'utf-8').lower())
        df['ExchCode'] = df['ExchCode'].apply(lambda s: format_str(s, 'utf-8').upper())
        df['Currency'] = df['Currency'].apply(lambda s: format_str(s, 'utf-8').upper())
        detail = {}
        for index, row in df.iterrows():
            detail['%s@%s' % (row['Product'], row['ExchCode'])] = {
                'FeeMode': row['FeeMode'],
                'MyIntraSimuFee': row['MyIntraSimuFee'],
                'MyInterSimuFee': row['MyInterSimuFee'],
                'ExchgCode': row['ExchCode'],
                'TradeUnit': row['TradeUnit'],
                'ExchIntraOpenFee': row['ExchIntraOpenFee'],
                'ExchInterOpenFee': row['ExchInterOpenFee'],
                'ExchIntraCloseFee': row['ExchIntraCloseFee'],
                'ExchInterCloseFee': row['ExchInterCloseFee'],
                'MyBrokerOpenFee': row['MyBrokerOpenFee'],
                'MyBrokerCloseFee': row['MyBrokerCloseFee'],
                'Category': row['Category'],
                'Currency': row['Currency'],
            }
        return detail

    def get_foreign_symbols(self):
        q_sql = """.gw.asyncexec["select EXCHANGE,PRODUCT,SYMBOL from FMainCon
        where EXCHANGE in `SGX`NYMEX`CME`CBOT`COMEX`LME`ICEE`IPE`ICEU`APEX ,
        NEXTDATE<=.z.D ,NEXTDATE = max NEXTDATE"; `FuturesBasicInfo]"""
        df = self.async_query(q_sql, pandas=True)
        df['EXCHANGE'] = df['EXCHANGE'].apply(lambda s: format_str(s, 'utf-8').upper())
        df['PRODUCT'] = df['PRODUCT'].apply(lambda s: format_str(s, 'utf-8').lower())
        df['SYMBOL'] = df['SYMBOL'].apply(lambda s: format_str(s, 'utf-8').lower())
        res = {}
        for index, row in df.iterrows():
            res[row['SYMBOL']] = {
                'product': row['PRODUCT'],
                'exchange': row['EXCHANGE'],
                'type': 'FU',
            }
        return res

    def get_futures_info(self, **kwargs):
        q_sql = """.gw.asyncexec["delete N from 0!(1!select windcode:S_INFO_WINDCODE,sec_name:S_INFO_CODE,
                lastdelivery_date:FS_INFO_LTDLDATE, product:FS_INFO_SCCODE, exchange:S_INFO_EXCHMARKET
                 from CFuturesDescription where FS_INFO_LTDLDATE >=%s) lj (1!select
                windcode:S_INFO_WINDCODE,contractmultiplier:N from CFuturescontpro)";`FuturesBasicInfo]
                """ % kwargs.get('trading_date', datetime.datetime.now().strftime('%Y.%m.%d'))
        df = self.async_query(q_sql, pandas=True)
        df['windcode'] = df['windcode'].apply(lambda s: format_str(s, 'utf-8'))
        df['symbol'] = df['sec_name'].apply(lambda s: format_str(s, 'utf-8'))
        df['product'] = df['product'].apply(lambda s: format_str(s, 'utf-8').upper())
        df['exchange'] = df['exchange'].apply(lambda s: format_str(s, 'utf-8').upper())
        df['lastdelivery_date'] = df['lastdelivery_date'].apply(lambda d: d.strftime('%Y%m%d'))
        res = {}
        for index, row in df.iterrows():
            res[row['windcode']] = {
                'windcode': row['windcode'],
                'symbol': row['symbol'],
                'product': row['product'],
                'lastdelivery_date': row['lastdelivery_date'],
                'contractmultiplier': row['contractmultiplier'],
                'exchange': row['exchange'],
            }
            res[row['symbol'].lower()] = res[row['windcode']]
        return res

    def get_future_fee_data(self):
        detail = {}
        last_fee_sql = """.gw.asyncexec["select Product, MyProduct,ExchCode,`ByVol=FeeMode,TradeUnit, MyIntraSimuFee,TickSize,
        MyInterSimuFee,ExchIntraOpenFee,ExchInterOpenFee,ExchIntraCloseFee, ExchInterCloseFee,MyBrokerOpenFee,MyBrokerCloseFee,date,Category
        from FeeRateV2 where date = last date";`FeeRateDB]"""
        df = self.async_query(last_fee_sql, pandas=True)
        df['Product'] = df['Product'].apply(lambda s: format_str(s, 'utf-8').upper())
        df['ExchCode'] = df['ExchCode'].apply(lambda s: format_str(s, 'utf-8').upper())
        for index, row in df.iterrows():
            if row['Product'] in detail:
                continue
            detail[row['Product']] = {
                'FeeMode': row['FeeMode'],
                'MyIntraSimuFee': row['MyIntraSimuFee'],
                'MyInterSimuFee': row['MyInterSimuFee'],
                'ExchgCode': row['ExchCode'],
                'TradeUnit': row['TradeUnit'],
                'ExchIntraOpenFee': row['ExchIntraOpenFee'],
                'ExchInterOpenFee': row['ExchInterOpenFee'],
                'ExchIntraCloseFee': row['ExchIntraCloseFee'],
                'ExchInterCloseFee': row['ExchInterCloseFee'],
                'MyBrokerOpenFee': row['MyBrokerOpenFee'],
                'MyBrokerCloseFee': row['MyBrokerCloseFee'],
                'Category': row['Category'],
            }
        return detail

    def get_main_code(self, trading_date):
        trading_date = parse(trading_date).strftime('%Y.%m.%d')
        sql = """.gw.asyncexec["select SYMBOL,PRODUCT, MAINLEVEL from MainCon where NEXTDATE=%s"; `FuturesBasicInfo]'""" % trading_date
        df = self.async_query(sql, pandas=True)
        df['SYMBOL'] = df['SYMBOL'].apply(lambda s: format_str(s, 'utf-8'))
        df['PRODUCT'] = df['PRODUCT'].apply(lambda s: format_str(s, 'utf-8').lower())
        res = {}
        for _, row in df.iterrows():
            res['%s|%s' % (row['PRODUCT'], row['MAINLEVEL'])] = row['SYMBOL']
            all_symbol_key = '%s|%s' % (row['PRODUCT'], 'A')
            product_all = res.setdefault(all_symbol_key, [])
            product_all.append(row['SYMBOL'])
        return res

    def get_foreign_main_code(self, trading_date):
        trading_date = parse(trading_date).strftime('%Y.%m.%d')
        sql = """.gw.asyncexec["select SYMBOL,PRODUCT, EXCHANGE	, MAINLEVEL from FMainCon where NEXTDATE=%s"; `FuturesBasicInfo]'""" % trading_date
        df = self.async_query(sql, pandas=True)
        df['SYMBOL'] = df['SYMBOL'].apply(lambda s: format_str(s, 'utf-8'))
        df['PRODUCT'] = df['PRODUCT'].apply(lambda s: format_str(s, 'utf-8').lower())
        df['EXCHANGE'] = df['EXCHANGE'].apply(lambda s: format_str(s, 'utf-8').upper())
        res = {}
        for _, row in df.iterrows():
            res['%s@%s|%s' % (row['PRODUCT'], row['EXCHANGE'], row['MAINLEVEL'])] = row['SYMBOL']
            all_symbol_key = '%s@%s|%s' % (row['PRODUCT'], row['EXCHANGE'], 'A')
            product_all = res.setdefault(all_symbol_key, [])
            product_all.append(row['SYMBOL'])
        return res

    def is_trading_date2(self, calendar_date):
        calendar_date = parse(calendar_date)
        begin_date = calendar_date.strftime('%Y.%m.%d')
        q_sql = """.gw.asyncexec["select TRADE_DT from Calendar where EXCHANGE=`SSE, TRADE_DT=%s";`FuturesBasicInfo]""" % begin_date
        ret = self.async_query(q_sql)
        if len(ret):
            return True
        else:
            return False

    def get_stock_market_volume(self, trading_date, symbol, begin_time, end_time):
        q_sql = """.gw.asyncexec["select sum Volume from  1_select deltas Volume from EquityDepth where
        date={trading_date},Symbol=`{symbol},Time within {begin_time} {end_time}";`EquityDB]""".format(
            trading_date=trading_date,
            symbol=symbol,
            begin_time=begin_time,
            end_time=end_time
        )
        rows = self.async_query(q_sql)
        return rows[0][0]

    def get_future_simu_fee_data(self):
        q_sql = '.gw.asyncexec[" select Product, Exch, `ByVol=FeeMode, TradeUnit, SimuFee from FeeRate where date=last date, Category=0"; `FeeRateDB]'
        df = self.async_query(q_sql, pandas=True)
        df['Product'] = df['Product'].apply(lambda s: format_str(s, 'utf-8').upper())
        df['Exch'] = df['Exch'].apply(lambda s: format_str(s, 'utf-8').upper())
        detail = {}
        for index, row in df.iterrows():
            if row['Product'] in detail:
                continue
            detail[row['Product']] = {
                'Exch': row['Exch'],
                'FeeMode': row['FeeMode'],
                'TradeUnit': row['TradeUnit'],
                'SimuFee': row['SimuFee'],
            }
        return detail

    def get_index_settle_price(self):
        sql = '.gw.asyncexec["select SYMBOL,TRADE_DT,S_DQ_CLOSE from AIndexEODPrices where SYMBOL in `h00905.CSI`000905.SH, TRADE_DT= max TRADE_DT";`EquityFactor]'
        df = self.async_query(sql, pandas=True)
        detail = {}
        for index, row in df.iterrows():
            detail[str(row['SYMBOL'], 'utf-8')] = float(row['S_DQ_CLOSE'])
        return detail

    def get_symbol_sellteprice(self, date, symbol):
        q_sql = '.gw.asyncexec["select from CFuturesEODPrices where TRADE_DT=%s, (lower SYMBOL)=`%s";`FuturesBasicInfo]' % (
            date, symbol.lower())
        q_ret = self.async_query(q_sql, pandas=True)
        return float(q_ret['SETTLEPRICE'])

    def get_main_code2(self, date, product, rank=1):
        try:
            q_sql = ".gw.asyncexec[(`GetMaincode;%s;`%s;%d); `FuturesBasicInfo]" % \
                    (date, product, rank)
            q_ret = self.async_query(q_sql)
            return str(q_ret[0][0], 'utf-8')
        except Exception as e:
            raise ValueError('query kdb main symbol error.')

    def get_opmain_code(self, date, product, rank):
        try:
            q_sql = """.gw.asyncexec["select first SYMBOL from OPMainCon where NEXTDATE>=%s,MAINLEVEL=%s,PRODUCT=`%s";`OptionBasicInfo]""" % (
                date, rank, product.upper())
            q_ret = self.async_query(q_sql, pandas=True)
            return str(q_ret['SYMBOL'][0], 'utf-8')
        except Exception as e:
            raise ValueError('query kdb opmain symbol error.')

    def get_cb_code(self, date, product, rank):
        try:
            q_sql = """.gw.asyncexec["select from EquityMainCon where NEXTDATE>=%s,MAINLEVEL=%s,PRODUCT=`%s";`EquityFactor]""" % (date, rank, product.upper())
            q_ret = self.async_query(q_sql, pandas=True)
            return str(q_ret['SYMBOL'][0], 'utf-8')
        except Exception as e:
            raise ValueError('query kdb opmain symbol error.')

    def get_symbol_trade_unit(self, symbol):
        q_sql = '.gw.asyncexec["select N from CFuturescontpro where SYMBOL=upper `%s";`FuturesBasicInfo]' % symbol
        q_ret = self.async_query(q_sql)
        return int(q_ret[0][0])

    def get_hibor_1m(self, trading_date):
        trading_date = parse(trading_date).strftime('%Y.%m.%d')
        sql = '.gw.asyncexec["select from HiborPrices where SYMBOL=`HIBOR1M.IR, TRADE_DT= %s";`EquityFactor]' % trading_date
        df = self.async_query(sql, pandas=True)
        rate = 0
        for _, row in df.iterrows():
            rate = float(row['B_INFO_RATE'])
        return rate

    def get_stock_ev_data_status(self, trading_date, day_night):
        trading_date = parse(trading_date).strftime('%Y.%m.%d')
        sql = """.gw.asyncexec["select last flag from `time xasc select from DataForEV where date=%s, project=`stock, Category=%s";`DataQuality]""" % (
            trading_date, day_night)
        df = self.async_query(sql, pandas=True)
        s = False
        for _, row in df.iterrows():
            if format_str(row['flag']) == 'SUCCESS':
                return True
            return s
        return s

    def get_stock_close_price(self, trading_date, day_night):
        trading_date = parse(trading_date).strftime('%Y.%m.%d')
        day_night = int(day_night)
        if day_night == 1:
            prev_trading_date = self.get_nebor_trading_date(trading_date)['prev']
            trading_date = parse(prev_trading_date).strftime('%Y.%m.%d')
        sql = '.gw.asyncexec[\"select SYMBOL,S_DQ_CLOSE from AShareEODPrices  where  TRADE_DT=%s\";`EquityFactor]' % trading_date
        df = self.async_query(sql, pandas=True)
        df['SYMBOL'] = df['SYMBOL'].apply(lambda s: format_str(s, 'utf-8').split('.')[0].lower())
        res = {}
        for index, row in df.iterrows():
            res[row['SYMBOL']] = float(row['S_DQ_CLOSE'])
        return res

    def get_symbol_rank(self, trading_date, symbol):
        trading_date = parse(trading_date).strftime('%Y.%m.%d')
        try:
            q_sql = """.gw.asyncexec["select first MAINLEVEL from `NEXTDATE  xasc select from MainCon where NEXTDATE>=%s,SYMBOL=`%s";`FuturesBasicInfo]""" % (trading_date, symbol)
            q_ret = self.async_query(q_sql)
            ret = int(q_ret[0][0])
            if ret <= 0:
                raise ValueError('query kdb symbol rank error.')
            return ret
        except Exception as e:
            raise ValueError('query kdb symbol rank error.')

    def get_option_rank(self, trading_date, symbol):
        trading_date = parse(trading_date).strftime('%Y.%m.%d')
        try:
            q_sql = """.gw.asyncexec["select first MAINLEVEL from OPMainCon where NEXTDATE>=%s,SYMBOL=`%s";`OptionBasicInfo]""" % (trading_date, symbol)
            q_ret = self.async_query(q_sql, pandas=True)
            ret = int(q_ret['MAINLEVEL'][0])
            if ret <= 0:
                raise ValueError('query kdb option symbol rank error.')
            return ret
        except Exception as e:
            raise ValueError('query kdb option symbol rank error.')

    def get_cb_rank(self, trading_date, symbol):
        trading_date = parse(trading_date).strftime('%Y.%m.%d')
        try:
            q_sql = """.gw.asyncexec["select first MAINLEVEL from EquityMainCon where NEXTDATE>=%s,SYMBOL=`%s";`EquityFactor]""" % (trading_date, symbol)
            q_ret = self.async_query(q_sql, pandas=True)
            ret = int(q_ret['MAINLEVEL'][0])
            if ret <= 0:
                raise ValueError('query kdb option symbol rank error.')
            return ret
        except Exception as e:
            raise ValueError('query kdb option symbol rank error.')


if __name__ == '__main__':
    # kdb = KdbQuery()
    # print(kdb.get_stock_close_price(trading_date='20200310', day_night=0))
    pass

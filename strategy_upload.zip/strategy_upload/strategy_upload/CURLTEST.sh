curl http://localhost:18887
curl http://localhost:18887/api/v1/platform/account_funds
from .strategy import StrategyBasicData, VsBasicData

__all__ = ['StrategyBasicData', 'VsBasicData']

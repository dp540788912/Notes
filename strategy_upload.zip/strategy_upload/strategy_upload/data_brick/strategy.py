from sqlalchemy import or_

from service.back_test.models import Strategy, VStrategies, StrategyPortfolio
from .base import DataBrickMixin, DataBrickCacheKey
from config import DataBrickRedisBackend
from db import session_context


class StrategyBasicData(DataBrickMixin):
    cache_key = DataBrickCacheKey.prefix.format("strategy_basic_data:{}")
    cache_backend = DataBrickRedisBackend()
    cache_identifier = 's_id'
    cache_time_in_seconds = 3600 * 24

    @classmethod
    def get_data_from_source(cls, identifiers):
        data = dict()
        with session_context() as sc:
            records = sc.query(Strategy).filter(
                Strategy.id.in_(identifiers)
            ).all()
            for r in records:
                d = {
                    's_id': r.id,
                    'name': r.name,
                    'id_no': r.id_no,
                    'node': r.node,
                    'username': r.username,
                    'user_id': r.r_create_user_id,
                    'strategy_type': r.strategy_type,
                    'paper_trading_date': r.paper_trading_date.strftime("%Y%m%d")
                }
                data[d[cls.cache_identifier]] = d
        return data


class VsBasicData(DataBrickMixin):
    cache_key = DataBrickCacheKey.prefix.format("vs_basic_data:{}")
    cache_backend = DataBrickRedisBackend()
    cache_identifier = 'vs_id'
    cache_time_in_seconds = 3600 * 8

    @classmethod
    def get_data_from_source(cls, identifiers):
        data = dict()
        with session_context() as sc:
            records = sc.query(
                VStrategies.id,
                VStrategies.strategy_id,
                VStrategies.portfolio_id,
                StrategyPortfolio.name.label('portfolio_name'),
                StrategyPortfolio.live_time,
                StrategyPortfolio.business,
                Strategy.name.label('strategy_name'),
                Strategy.id_no
            ).join(
                StrategyPortfolio, VStrategies.portfolio_id == StrategyPortfolio.id
            ).join(
                Strategy, VStrategies.strategy_id == Strategy.id
            ).filter(
                VStrategies.id.in_(identifiers),
            ).all()
            for r in records:
                d = {
                    'vs_id': r.id,
                    's_id': r.strategy_id,
                    'portfolio_id': r.portfolio_id,
                    'portfolio_name': r.portfolio_name,
                    'live_date': r.live_time.strftime("%Y%m%d"),
                    'business': r.business,
                    'strategy_name': r.strategy_name,
                    'id_no': r.id_no
                }
                data[d[cls.cache_identifier]] = d
        return data

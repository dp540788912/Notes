import json
import random


class DataBrickCacheKey(object):
    prefix = "data_brick:{}"


class DataBrickMixin(object):
    """
    Data Brick Mixin
    class variable must assign before use:
        cache_key
        cache_backend
        cache_identifier
    class method must implement before use:
        get_data_from_source
    then you have the following public methods:
        get_many
        get_one
        update_caches
        update_cache
    """
    cache_key = None
    cache_backend = None
    cache_identifier = None
    cache_time_in_seconds = 0
    cache_time_plus_range = 30

    @classmethod
    def get_data_from_source(cls, identifiers):
        """
        get data from source
        :param identifiers: list, identifiers
        :return: dict, [identifier1: {}, identifier2: {}, ...], {} must contain cls.cache_identifier field
        """
        raise NotImplemented

    @classmethod
    def _cache_loader(cls, cache):
        """
        decode cache
        :param cache: string, cache read from cache backend
        :return: dict, decoded cache
        """
        return cache and json.loads(str(cache, 'utf-8'))

    @classmethod
    def _get_from_cache(cls, identifiers):
        """

        :param identifiers: list, list of cls.cache_identifier
        :return: dict, {identifier: {}, ...}
        """
        keys = [cls.cache_key.format(i) for i in identifiers]
        if keys:
            caches = cls.cache_backend.mget(keys)
            caches = [cls._cache_loader(cache) for cache in caches]
        else:
            caches = list()

        data = dict()
        null_identifiers = list()
        for index, cache in enumerate(caches):
            identifier = identifiers[index]
            if cache is None:
                null_identifiers.append(identifier)
            else:
                data[identifier] = cache
        if null_identifiers:
            null_data = cls.get_data_from_source(null_identifiers)
            if null_data:
                data.update(null_data)
                cls._update_caches_using_data(null_data)
        return data

    @classmethod
    def _update_caches_using_data(cls, source_data):
        """

        :param source_data: dict, {identifier: {}, ...}
        :return:
        """
        mapping = {cls.cache_key.format(k): json.dumps(v) for k, v in source_data.items()}
        cls.cache_backend.mset(mapping)
        if cls.cache_time_in_seconds > 0:
            pipeline = cls.cache_backend.pipeline(transaction=False)
            for key in mapping.keys():
                pipeline.expire(key, cls.cache_time_in_seconds + random.randrange(cls.cache_time_plus_range))
            pipeline.execute()

    @classmethod
    def _update_caches_using_identifiers(cls, identifiers):
        source_data = cls.get_data_from_source(identifiers)
        if source_data:
            cls._update_caches_using_data(source_data)

    @classmethod
    def get_many(cls, identifiers, cache=True):
        if cache:
            data = cls._get_from_cache(identifiers)
        else:
            data = cls.get_data_from_source(identifiers)
        return data

    @classmethod
    def get_one(cls, identifier, cache=True):
        data = cls.get_many(identifiers=[identifier], cache=cache)
        return data and data[identifier]

    @classmethod
    def update_caches(cls, identifiers):
        cls._update_caches_using_identifiers(identifiers)

    @classmethod
    def update_cache(cls, identifier):
        cls.update_caches(identifiers=[identifier])

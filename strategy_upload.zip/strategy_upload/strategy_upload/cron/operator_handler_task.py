import sys
import os
from datetime import datetime
from constant import CompanyEmailGroup
from cron import app
from cron.strategy_upload_task import quant_ops_wechat_app_send_text_task, rss_mail_task, \
    quant_dev_wechat_app_send_text_task

root_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
bin_path = os.path.join(root_path, 'bin')
project_path = os.path.join(root_path, 'strategy_upload/strategy_upload')
if bin_path not in sys.path:
    sys.path.append(bin_path)
if project_path not in sys.path:
    sys.path.append(project_path)
from settlement_command import settle
from service.back_test.models import VsAccount
from db import session_context
from service.operation_deploy.helper import generate_redo_settlement


@app.task
def cashio_approved_task(effect_date, vs_id, auditor, strict=True):
    """
    callback cash io approved by operator

    :param effect_date: str cash change effect date
    :param vs_id: int
    :param auditor: str
    :param strict: bool permission auto settlement when redo more than 2 times
    :return:
    """

    effect_date = datetime.strptime(effect_date, "%Y-%m-%d").date()
    with session_context() as sc:
        vs_account = sc.query(VsAccount).filter(VsAccount.vstrategy_id == vs_id).order_by(
            VsAccount.settle_date.desc()).first()
        if vs_account is None:
            raise ValueError("can not find vs id")

        settle_date = vs_account.settle_date
        old_cash = vs_account.cash
        day_night = vs_account.daynight
    redo = generate_redo_settlement(settle_date, effect_date, day_night)
    # not find settle need to redo
    if len(redo) == 0:
        return
    # if strict mode,operator do not allow to settle auto
    if len(redo) > 2 and strict:
        raise ValueError("do not allow redo more than two settlement in strict mode")
    # redo settlement in order
    for i in redo:
        settle(i[0].isoformat(), 0 if i[1] == "DAY" else 1, vs_id)
    with session_context() as sc:
        vs_account = sc.query(VsAccount).filter(VsAccount.vstrategy_id == vs_id).order_by(
            VsAccount.settle_date.desc()).first()
        if vs_account is None:
            raise ValueError("can not find vs id")
        new_cash = vs_account.cash
    redo_list = "\n".join([" %s %s %s" % (i[0].isoformat(), 0 if i[1] == "DAY" else 1, vs_id) for i in redo])
    body = "vs_id: {vs_id}\n审核人:{auditor}\n出入金生效时间:{effect_date}\n最新结算时间:{settle_date}\n日夜盘:{day_night}\n自动结算前面值:{old_cash}\n自动结算后面值:{new_cash}\n重做列表:\n{redo}".format(
        vs_id=vs_id, old_cash=old_cash, new_cash=new_cash, settle_date=settle_date.strftime("%Y-%m-%d"),
        effect_date=effect_date.strftime("%Y-%m-%d"), day_night=day_night, redo=redo_list, auditor=auditor)
    rss_mail_task.delay("出入金自动结算", body, [CompanyEmailGroup.quant_dev, CompanyEmailGroup.quant_ops])

# -*-coding:utf-8-*-

import os
import datetime
import json
import redis
import pandas as pd
import requests
import copy

from cron import app
from utils import send_email
from extensions import sentry
from service.back_test.models import VStrategies, VStrategyAccountDetail
from service.back_test.live_position_models import VsBase, VsAccount, VsPosition, PositionCorpActionsTable
from service.back_test.live_trading_models import CashLimit, CashLimitDetail, VsLiveParameter
from db import session, engine
from config import config, ProductConfigIDC, RedisCache0

import consts
from constant import CompanyEmailGroup, RedisKeyConstant
from utility.db_util import TradeCalendar
from service.monitor.helper import SelfTradeMonitor

from celery.utils.log import get_task_logger

logger = get_task_logger('strategy_upload_task')


@app.task
def self_trade_monitor_task():
    now = datetime.datetime.now()
    date = now.strftime("%Y%m%d")
    hour_str = now.strftime("%H%M")
    if not (("0930" <= hour_str <= "1130") or ("1300" <= hour_str <= "1500")):
        return False

    trading_calendar = TradeCalendar.init_from_kdb(**config.kdb_config)
    if not trading_calendar.is_trading_date(date=date):
        return False

    monitor = SelfTradeMonitor(trading_date=date)
    self_trade_info = monitor.get_self_trade_info()
    info = {
        "self_trade_info": self_trade_info,
        "update_at": now.strftime("%Y%m%d %H:%M:%S")
    }

    rds = RedisCache0()
    key = RedisKeyConstant.SelfTradeMonitorInfo.value.format(trading_date=monitor.trading_date)
    rds.set(key, json.dumps(info), ex=24 * 60 * 60)


@app.task
def send_cash_limit(cash_id, clear=False):
    try:
        sc = session()
        cash_limit = sc.query(CashLimit).filter(CashLimit.id == cash_id).first()
        cash_limit_details = sc.query(CashLimitDetail).filter(CashLimitDetail.cash_limit_id == cash_id)
        now_time = datetime.datetime.now()
        now_time_str = now_time.strftime('%Y%m%d %X')
        now_day_str = now_time.strftime('%Y%m%d')
        now_hour = now_time.hour

        if (not clear) and int(cash_limit.status) != 1:
            return False

        vs_id = cash_limit.vs_id

        if 8 <= now_hour <= 15:
            day_night = 0
        elif (0 <= now_hour <= 4) or (20 <= now_hour <= 23):
            day_night = 1
        else:
            raise ValueError('day_night error')
        if day_night == 0:
            begin_timestamp = 85800000
            end_timestamp = 153000000
        else:
            begin_timestamp = 205800000
            end_timestamp = 273000000

        msg = []
        for l in cash_limit_details:
            end_time = l.end_time.strftime('%Y%m%d %X')
            if clear:
                msg.append({
                    'symbol': l.symbol,
                    'max_long_ratio': 1,
                    'max_short_ratio': 1,
                    'start_time': begin_timestamp,
                    'end_time': end_timestamp,
                })
            else:
                if now_time_str <= end_time:
                    if l.end_time.strftime('%Y%m%d') > now_day_str:
                        _end_time = end_timestamp
                    else:
                        if day_night == 0:
                            _end_time = min(int(l.end_time.strftime('%H%M%S000')), end_timestamp)
                        else:
                            if now_hour <= 4:
                                _end_time = min(int(l.end_time.strftime('%H%M%S000') + 240000000), end_timestamp)
                            else:
                                _end_time = min(int(l.end_time.strftime('%H%M%S000')), end_timestamp)
                    msg.append({
                        'symbol': l.symbol,
                        'max_long_ratio': float(l.long_limit),
                        'max_short_ratio': float(l.short_limit),
                        'start_time': begin_timestamp,
                        'end_time': _end_time,
                    })

        if msg:
            serverip_sql = '''
               select id, host from deploy_confs where vstrategy_id=%s and day_night=%s and valid=1
            ''' % (vs_id, day_night)
            cursor = sc.execute(serverip_sql)
            process_id, serverip = cursor.fetchone()
            if not isinstance(config, ProductConfigIDC):
                queue = 'oss:a:cmd:tmp:%s' % serverip
            else:
                queue = 'oss:a:cmd:tmp:%s' % serverip
            task_cmd = {
                'type': 6,
                'seq': 999999,
                'data': {
                    'process_id': process_id,
                    'msg': msg,
                }
            }
            rds = redis.Redis(host=config.redis['host'], port=config.redis['port'], db=config.redis['db'])
            rds.rpush(queue, json.dumps(task_cmd))
            logger.info('send task[%s] to agent %s' % (task_cmd, queue))
            notify_send_cash_limit.delay(queue, task_cmd)
    except Exception as e:
        sc.close()
        sentry.captureException()
        notify_send_cash_limit.delay('Send Cash Limit Error', {
            'vs_id': vs_id
        })
        return False
    sc.close()
    return True


@app.task
def notify_send_cash_limit(queue, msg):
    try:
        msg = json.dumps(msg, indent=4)
        content = queue + '\r\n\r\n' + msg
        send_email('send cash limit', content, [CompanyEmailGroup.quant_dev])
    except Exception as e:
        return False
    return True


@app.task
def send_live_parameter(para_id):
    try:
        sc = session()
        para = sc.query(VsLiveParameter).filter(VsLiveParameter.id == para_id).first()
        vs_id = para.vs_id
        now_time = datetime.datetime.now()
        now_hour = now_time.hour

        if 8 <= now_hour <= 15:
            day_night = 0
        elif (0 <= now_hour <= 4) or (20 <= now_hour <= 23):
            day_night = 1
        else:
            raise ValueError('day_night error')

        serverip_sql = '''
            select id, host from deploy_confs where vstrategy_id=%s and day_night=%s and valid=1
        ''' % (vs_id, day_night)
        cursor = sc.execute(serverip_sql)
        process_id, serverip = cursor.fetchone()
        if not isinstance(config, ProductConfigIDC):
            queue = 'oss:a:cmd:tmp:%s' % serverip
        else:
            queue = 'oss:a:cmd:tmp:%s' % serverip

        msg = {
            'parameter0': para.parameter0 and float(para.parameter0) or 0,
            'parameter1': para.parameter1 and float(para.parameter1) or 0,
            'parameter2': para.parameter2 and float(para.parameter2) or 0,
            'parameter3': para.parameter3 and float(para.parameter3) or 0,
            'parameter4': para.parameter4 and float(para.parameter4) or 0,
            'parameter5': para.parameter5 and float(para.parameter5) or 0,
            'parameter6': para.parameter6 and float(para.parameter6) or 0,
            'parameter7': para.parameter7 and float(para.parameter7) or 0,
            'parameter8': para.parameter8 and float(para.parameter8) or 0,
            'parameter9': para.parameter9 and float(para.parameter9) or 0,
        }

        task_cmd = {
            'type': 7,
            'seq': 999999,
            'data': {
                'process_id': process_id,
                'msg': msg,
            }
        }
        rds = redis.Redis(host=config.redis['host'], port=config.redis['port'], db=config.redis['db'])
        rds.rpush(queue, json.dumps(task_cmd))
        logger.info('send task[%s] to agent %s' % (task_cmd, queue))
        notify_send_live_parameter.delay(queue, task_cmd)
    except Exception as e:
        sc.close()
        sentry.captureException()
        notify_send_live_parameter.delay('Send live_parameter Error', {
            'para_id': para_id
        })
        return False
    sc.close()
    return True


@app.task
def notify_send_live_parameter(queue, msg):
    try:
        msg = json.dumps(msg, indent=4)
        content = queue + '\r\n\r\n' + msg
        send_email('send live_parameter', content, [CompanyEmailGroup.quant_dev])
    except Exception as e:
        return False
    return True


@app.task
def upgrade_vs_position(old_vs_id, new_vs_id, trading_date):
    try:
        sc = session()
        old_vs = sc.query(VStrategies).filter(VStrategies.id == old_vs_id).filter()
        new_vs = sc.query(VStrategies).filter(VStrategies.id == new_vs_id).filter()
        acc_exchange = {}
        for acc in new_vs.symbols_accounts:
            acc_exch = acc_exchange.setdefault(acc['account'], [])
            acc_exch.append(acc['exchange'])
        old_vs_base = sc.query(VsBase).filter(VsBase).filter(
            VsBase.vstrategy_id == old_vs_id, VsBase.settle_date == trading_date, VsBase.daynight == 'DAY', ).first()
        if not old_vs_base:
            return False

        sc.query(VsBase).filter(VsBase).filter(
            VsBase.vstrategy_id == new_vs_id,
            VsBase.settle_date == trading_date,
            VsBase.daynight == 'DAY',
        ).delete()
        sc.query(VsAccount).filter(VsAccount).filter(
            VsBase.vstrategy_id == new_vs_id,
            VsBase.settle_date == trading_date,
            VsBase.daynight == 'DAY',
        ).delete()
        sc.query(VsPosition).filter(VsPosition).filter(
            VsBase.vstrategy_id == new_vs_id,
            VsBase.settle_date == trading_date,
            VsBase.daynight == 'DAY',
        ).delete()
        sc.query(VStrategyAccountDetail).filter(
            VStrategyAccountDetail.vstrategy_id == new_vs_id,
            VStrategyAccountDetail.trading_date.is_(None),
        ).delete()
        sc.commit()

        old_accounts = sc.query(VsAccount).filter(
            VsAccount.vstrategy_id == old_vs_id,
            VsAccount.settle_date == trading_date,
            VsAccount.daynight == 'DAY'
        )

        old_vs_positions = sc.query(VsPosition).filter(
            VsPosition.vstrategy_id == old_vs_id,
            VsPosition.settle_date == trading_date,
            VsPosition.daynight == 'DAY',
        )

        new_vs_base = VsBase(
            vstrategy_id=new_vs_id,
            cash=old_vs_base.cash,
            accumulated_pnl=0,
            settle_date=trading_date,
            daynight='DAY',
            available_cash=old_vs_base.available_cash,
            asset_cash=old_vs_base.asset_cash,
            defer_fee=0,
            fee=0,
            pnl=0,
            position_cash=old_vs_base.position_cash,
            total_asset=old_vs_base.total_asset,
            dividend=old_vs_base.dividend,
        )
        sc.add(new_vs_base)
        for old_acc in old_accounts:
            new_acc = VsAccount(
                vstrategy_id=new_vs_id,
                account=old_acc.account,
                settle_date=trading_date,
                cash=old_acc.cash,
                accumulated_pnl=0,
                daynight='DAY',
                available_cash=old_acc.available_cash,
                asset_cash=old_acc.asset_cash,
                defer_fee=0,
                fee=0,
                pnl=0,
                position_cash=old_acc.position_cash,
                total_asset=old_acc.total_asset,
                dividend=old_acc.dividend
            )
            sc.add(new_acc)
            new_acc_d = VStrategyAccountDetail(
                vstrategy_id=new_vs_id,
                portfolio_id=new_vs.portfolio_id,
                account=old_acc.account,
                amount=old_acc.total_asset,
                actual_amount=0,
                exchange=acc_exchange[old_acc.account][0]
            )
            sc.add(new_acc_d)
        for old_pos in old_vs_positions:
            new_pos = VsPosition(
                vstrategy_id=new_vs_id,
                settle_date=trading_date,
                daynight='DAY',
                symbol=old_pos.symbol,
                symbol_type=old_pos.symbol_type,
                account=old_pos.account,
                yest_long_pos=old_pos.yest_long_pos,
                yest_long_avg_price=old_pos.yest_long_avg_price,
                yest_short_pos=old_pos.yest_short_pos,
                yest_short_avg_price=old_pos.yest_short_avg_price,
                today_long_pos=old_pos.today_long_pos,
                today_long_avg_price=old_pos.today_long_avg_price,
                today_short_pos=old_pos.today_short_pos,
                today_short_avg_price=old_pos.today_short_avg_price,
                today_settle_price=old_pos.today_settle_price,
                exchange=old_pos.exchange,
                symbol_pnl=old_pos.symbol_pnl,
                symbol_fee=old_pos.symbol_fee,
                today_max_pos=old_pos.today_max_pos,
            )
            sc.add(new_pos)
        new_position_corp = sc.query(
            PositionCorpActionsTable
        ).filter(
            PositionCorpActionsTable.vstrategy_id == new_vs_id,
        ).first()
        if not new_position_corp:
            old_postion_corps = sc.query(
                PositionCorpActionsTable
            ).filter(
                PositionCorpActionsTable.vstrategy_id == old_vs_id,
            )
            for old_corp in old_postion_corps:
                new_corp = PositionCorpActionsTable(
                    vstrategy_id=new_vs_id,
                    account=old_corp.account,
                    symbol=old_corp.symbol,
                    today_long_pos=old_corp.today_long_pos,
                    today_short_pos=old_corp.today_short_pos,
                    eqy_record_date=old_corp.eqy_record_date,
                    ex_date=old_corp.ex_date,
                    cash_dividend_per_share=old_corp.cash_dividend_per_share,
                    dividend_cash_payout_date=old_corp.dividend_cash_payout_date,
                    payout_cash=old_corp.payout_cash,
                    share_bonus_rate=old_corp.share_bonus_rate,
                    share_conversederate_rate=old_corp.share_conversederate_rate,
                    dividend_share_listing_date=old_corp.dividend_share_listing_date,
                    payout_pos=old_corp.payout_pos,
                    payout_short_pos=old_corp.payout_short_pos,
                )
                sc.add(new_corp)
        old_vs.status = 16
        new_vs.status = 15
        sc.commit()

        notify_upgrade_vs_position(old_vs_id, new_vs_id, trading_date)

    except Exception as e:
        sc.close()
        sentry.captureException()
        return False
    sc.close()
    return True


@app.task
def notify_upgrade_vs_position(old_vs_id, new_vs_id, trading_date):
    try:
        old_base_sql = """
            select * from vs_base where vstrategy_id={vstrategy_id} and settle_date='{settle_date}' and daynight='DAY'
        """.format(vstrategy_id=old_vs_id, settle_date=trading_date)
        old_account_sql = """
            select * from vs_accounts where vstrategy_id={vstrategy_id} and settle_date='{settle_date}' and daynight='DAY'
        """.format(vstrategy_id=old_vs_id, settle_date=trading_date)
        old_vs_position_sql = """
            select * from vs_positions where vstrategy_id={vstrategy_id} and settle_date='{settle_date}' and daynight='DAY'
        """.format(vstrategy_id=old_vs_id, settle_date=trading_date)
        old_corp = """
            select * from position_corp_actions_table where vstrategy_id={vstrategy_id}
        """.format(vstrategy_id=old_vs_id)

        new_base_sql = """
            select * from vs_base where vstrategy_id={vstrategy_id} and settle_date='{settle_date}' and daynight='DAY'
        """.format(vstrategy_id=new_vs_id, settle_date=trading_date)
        new_account_sql = """
            select * from vs_accounts where vstrategy_id={vstrategy_id} and settle_date='{settle_date}' and daynight='DAY'
        """.format(vstrategy_id=new_vs_id, settle_date=trading_date)
        new_vs_position_sql = """
            select * from vs_positions where vstrategy_id={vstrategy_id} and settle_date='{settle_date}' and daynight='DAY'
        """.format(vstrategy_id=new_vs_id, settle_date=trading_date)
        new_corp = """
            select * from position_corp_actions_table where vstrategy_id={vstrategy_id}
        """.format(vstrategy_id=new_vs_id)
        new_account_detail = """
            select * from vstrategy_account_detail where vstrategy_id={vstrategy_id}
        """.format(vstrategy_id=new_vs_id)

        df_old_base_sql = pd.read_sql_query(old_base_sql, engine)
        df_old_account_sql = pd.read_sql_query(old_account_sql, engine)
        df_old_vs_position_sql = pd.read_sql_query(old_vs_position_sql, engine)
        df_old_corp = pd.read_sql_query(old_corp, engine)
        df_new_base_sql = pd.read_sql_query(new_base_sql, engine)
        df_new_account_sql = pd.read_sql_query(new_account_sql, engine)
        df_new_vs_position_sql = pd.read_sql_query(new_vs_position_sql, engine)
        df_new_corp = pd.read_sql_query(new_corp, engine)
        df_new_account_detail = pd.read_sql_query(new_account_detail, engine)
        contents = [
            'vs_base',
            df_new_base_sql.to_html(),
            df_old_base_sql.to_html(),
            'vs_account',
            df_new_account_sql.to_html(),
            df_old_account_sql.to_html(),
            'vs_position',
            df_old_vs_position_sql.to_html(),
            df_new_vs_position_sql.to_html(),
            'position_corp_actions_table',
            df_new_corp.to_html(),
            df_old_corp.to_html(),
            'new_account_detail',
            df_new_account_detail.to_html()
        ]
        content = '\n\n\n\n'.join(contents)
        send_email('send notify_upgrade_vs_position', content, [CompanyEmailGroup.quant_dev])
    except Exception as e:
        send_email(
            'send notify_upgrade_vs_position error',
            str(e),
            [CompanyEmailGroup.quant_dev]
        )
        return False
    return True


@app.task
def query_account_cash():
    ''' Futures account risk monitoring celery task.
        indirectly used by :func: `strategy_upload/service/statistic/handlers FutureRiskHandler`
    '''
    if not isinstance(config, ProductConfigIDC):
        return True

    accounts = copy.deepcopy(consts.future_risk_accounts)

    url = 'http://{host}:{port}/api/v1/speedquote/equityaccount'.format(
        host='192.168.10.100',
        port=13333
    )
    try:
        cash = requests.get(url).json()['data']
    except Exception as e:
        cash = {}
    account_cash = {}
    query_time = datetime.datetime.now().strftime('%H%M%S')

    for acc, acc_d in accounts.items():
        acc_data = cash.get(acc, {})
        if not acc_data:
            continue
        total_asset, available, risk = 0, 0, 0
        for acc_cash in acc_data['data']:
            if acc_cash['currency'] == acc_d['currency']:
                total_asset = float(acc_cash['margin'])

            elif acc_cash['currency'] == '%s-0' % acc_d['currency']:
                available = float(acc_cash['margin'])
        if total_asset:
            risk = 1 - float(available) / total_asset
        account_cash[acc] = [query_time, round(risk, 5), int(available), int(total_asset)]

    for acc, acc_d in account_cash.items():
        acc_file = os.path.join(config.media, 'account_cash_risk/%s.json' % acc)
        if os.path.exists(acc_file):
            f = open(acc_file, 'r')
            try:
                data = json.load(f)
            except Exception as e:
                data = {
                    'values': []
                }
            f.close()
        else:
            data = {
                'values': []
            }
        data['values'].append(acc_d)
        data['values'] = data['values'][-8640:]
        f = open(acc_file, 'w')
        json.dump(data, f)
        f.close()
    return True

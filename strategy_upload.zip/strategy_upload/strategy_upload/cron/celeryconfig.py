from datetime import timedelta
from celery.schedules import crontab
from consts import stock_night_ev_ids
from constant import StrategyPortfolioConstant
from config import config

BROKER_URL = 'redis://%s' % config.redis['host']
CELERY_IMPORTS = (
    'cron.strategy_upload_task',
    'cron.live_trading_task',
    'cron.error_handler_task',
    'cron.operator_handler_task'
)
CELERY_RESULT_BACKEND = 'redis://%s:%s' % (config.redis['host'], config.redis['port'])
CELERY_TASK_RESULT_EXPIRES = 5
CELERYD_CONCURRENCY = 10
CELERYD_PREFETCH_MULTIPLIER = 1
CELERY_TIMEZONE = 'Asia/Shanghai'
CELERY_ACCEPT_CONTENT = ['pickle', 'json']

CELERYBEAT_SCHEDULE = {
    # four schedules, each run in every 15, 30, 45, 60 minutes
    'generate_future_mkt_volume_ratio_task': {
        'task': 'cron.strategy_upload_task.check_future_mkt_volume_ratio_task_ready',
        'schedule': crontab(minute=[40], hour=[5, 15, 22], day_of_week="1-6"),
        'kwargs': {
            "count": 3,
            "wait": 10*60
        }
    },

    'auto_daily_paper_trading_task': {
        'task': 'cron.strategy_upload_task.auto_daily_paper_trading_task',
        'schedule': crontab(minute=[2], hour=[0], day_of_week='2-6'),
        'kwargs': {
            "trading_date": "today",
            "day_night": 0,
            "offset": -1,
        }
    },
    # 提前生产208418
    'produce_ev_in_advance': {
        'task': 'cron.strategy_upload_task.produce_ev_in_advance',
        'schedule': crontab(minute=[30], hour=[21], day_of_week='1-5'),
        'kwargs': {
            "ids": ",".join([str(i) for i in stock_night_ev_ids]),
            "day_night": 0
        }
    },
    # 股票日盘实盘ev生产
    'daily_stock_ev_task_live': {
        'task': 'cron.strategy_upload_task.auto_daily_dependence_produce',
        'schedule': crontab(minute=[0, 20], hour=[3], day_of_week='2-6'),
        'kwargs': {
            'offset': 0,
            'day_night': 0,
            'is_live': True,
            'reset_fail': True,
            'business': 1,
            'node_type': 'ev'
        }
    },
    # 期货日盘实盘实盘生产
    'daily_future_ev_task_day': {
        'task': 'cron.strategy_upload_task.auto_daily_dependence_produce',
        'schedule': crontab(minute=[0], hour=[6], day_of_week='2-6'),
        'kwargs': {
            'offset': 0,
            'day_night': 0,
            'is_live': True,
            'reset_fail': True,
            'business': 0,
            'node_type': 'ev'
        }
    },
    # 期货夜盘实盘生产
    'daily_future_ev_task_night': {
        'task': 'cron.strategy_upload_task.auto_daily_dependence_produce',
        'schedule': crontab(minute=[0, 20], hour=[19], day_of_week='1-5'),
        'kwargs': {
            'offset': 1,
            'day_night': 1,
            'is_live': True,
            'reset_fail': True,
            'business': 0,
            'node_type': 'ev'
        }
    },
    # 股票+期货日盘非实盘ev生产
    'daily_stock_ev_task_test': {
        'task': 'cron.strategy_upload_task.auto_daily_dependence_produce',
        'schedule': crontab(minute=[0], hour=[10], day_of_week='2-6'),
        'kwargs': {
            'offset': 0,
            'day_night': 0,
            'is_live': False,
            'business': None,
            'node_type': 'ev'
        }
    },
    # 期货夜盘非实盘生产
    'daily_future_ev_task_test': {
        'task': 'cron.strategy_upload_task.auto_daily_dependence_produce',
        'schedule': crontab(minute=[0], hour=[20], day_of_week='1-5'),
        'kwargs': {
            'offset': 1,
            'day_night': 1,
            'is_live': False,
            'business': 0,
            'node_type': 'ev'
        }
    },
    # 行情检查后触发实盘策略的期货盘后分析+日间因子生产+股票盘后分析
    'auto_data_check': {
        'task': 'cron.strategy_upload_task.auto_data_check',
        'schedule': crontab(minute=45, hour=19),
    },
    # # 实盘策略的盘后分析 股票
    # 'auto_vs_back_test_stock': {
    #     'task': 'cron.strategy_upload_task.auto_vs_back_test',
    #     'schedule': crontab(minute=00, hour=22),
    #     'kwargs': {
    #         'business': StrategyPortfolioConstant.Business.Stock.value
    #     }
    # },
    'auto_update_close_status': {
        'task': 'cron.strategy_upload_task.auto_update_close_status',
        'schedule': crontab(minute=[0], hour=[9, 21]),
    },
    'auto_update_strategy_status': {
        'task': 'cron.strategy_upload_task.auto_update_strategy_status',
        'schedule': crontab(minute=[0], hour=[10, 15, 18]),
    },
    'auto_daily_account_funds_task': {
        'task': 'cron.strategy_upload_task.auto_daily_account_funds_task',
        'schedule': crontab(minute=[0], hour=[21]),
    },
    # 缓存实盘股票策略，和对冲端之间的对应关系
    'update_stock_hedge_vs': {
        'task': 'cron.strategy_upload_task.update_stock_hedge_vs',
        'schedule': timedelta(seconds=480),
    },
    # 期货账户账户风险查询，每10秒采样一次，对应显示页面/future/future-risk-monitor.html的数据
    'query_account_cash': {
        'task': 'cron.live_trading_task.query_account_cash',
        'schedule': timedelta(seconds=10),
    },
    'update_live_stock_vs_position_abstract_info_task': {
        'task': 'cron.strategy_upload_task.update_live_stock_vs_position_abstract_info_task',
        'schedule': crontab(minute='15', hour='15', day_of_week='1-5'),
    },
    # 更新股票自成交信息
    'self_trade_monitor_task': {
        'task': 'cron.live_trading_task.self_trade_monitor_task',
        'schedule': crontab(minute='*/1', hour='9-12,13-15', day_of_week='1-5'),
    },
}

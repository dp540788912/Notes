# -*-coding:utf-8-*-


import os
import redis
import datetime
import time
import random
import pandas as pd
from celery.utils.log import get_task_logger
from sqlalchemy.sql import func, and_, or_
from dateutil.parser import parse
import consts
from utils import send_email
from extensions import sentry
from db import session, engine, session_context
from config import config, ProductConfigIDC, RssMail, QuantDevWeChatAPP, QuantOpsWeChatAPP, CompanyPlatformWeChatAPP
from utils import ttl_cache, del_cache, notify_operation_wechat
from cron import app
from service.back_test.models import Strategy, VStrategies, StrategyPortfolio, BackTestTradeLogs, StrategyResult, \
    BackTestConfig, VsbBackTestPara
from service.back_test.live_position_models import VsBase
from service.back_test.models import VStrategyAccountDetail, ClearPosition
from service.back_test.ev_task import get_live_ev_ids_cache
from service.account_funds.models import AccountBalanceCounter, Accounts, AccountFunds
from service.statistic.live_pnl import VsPnlGraph
from service.statistic.performance import BackTestPerformance, StrategyPerformance
from service.statistic.investment import InvestmentPerformanceService, gen_hash_value
from service.statistic.models import VsAggregationPnl, StrategyTradingVolumeRatio, \
    StrategyTradingVolumeRatioStatistic, StrategyStyleExposure, StrategyBackTestTradeIndicator, \
    StrategyRiskAttribute, StrategyIncomeAttribution
from service.strategymanager.manager import live_ev_check
from service.statistic.convert_backtest_tradelog import tradelogs2dataframe
from service.vwap.models import StrategyBackTestSlippage, StrategyVwapResult
from service.back_test.t0_factors import get_t0_position
from service.dependence.dependency import get_local_dependence_tree, RemoteTree, dependence_tree_generation
from kdb_query import KdbQuery
from constant import CompanyEmailGroup, VStrategiesConstant, CompanyUser, StrategyConstant, \
    StrategyEventTrackConstant, StockFactorEvaluationQueueEvent, CeleryQueueName, TradingTimeRange, Task
from utility.db_util import TradeCalendar
from service.back_test.task_helper import vs_back_test_analysis, vs_union_simu_back_test_analysis_from_alpha_vs, \
    BackTestAnalysisCheckFailException

logger = get_task_logger('strategy_upload_task')


def choose_task_queue(uid, s_id):
    live_ev_ids = get_live_ev_ids_cache()
    if uid in CompanyUser.future_team_user_ids():
        return CeleryQueueName.Cron120Task.value
    elif uid in CompanyUser.cron_strategy_upload_task_user_ids():
        return CeleryQueueName.CronStrategyUploadTask.value
    elif uid in CompanyUser.gpu_user_ids():
        q = random.choice(CeleryQueueName.gup_task_queues())
        # if q == CeleryQueueName.StockTeamCronTask.value and s_id not in live_ev_ids:
        #     return CeleryQueueName.StockTeam60EvTask.value
        # else:
        return q
    elif uid in CompanyUser.factor_user_ids():
        return random.choice(CeleryQueueName.factor_task_queues())
    elif uid in CompanyUser.stock_team_user_ids():
        if s_id not in live_ev_ids:
            return CeleryQueueName.StockTeam60EvTask.value
        else:
            return CeleryQueueName.StockTeamCronTask.value
    else:
        return CeleryQueueName.Cron120Task.value


@app.task
def rss_mail_task(title, content, to_addrs, content_type="plain", cc=None):
    mail = RssMail()
    try:
        mail.send(title, content, to_addrs, content_type=content_type, cc=cc)
    except Exception as e:
        sentry.captureException()


@app.task
def company_platform_wechat_app_send_text_task(text, to_users=None, to_parties=None, to_tags=None):
    company_platform_app = CompanyPlatformWeChatAPP()
    try:
        company_platform_app.send_text(text, to_users=to_users, to_parties=to_parties, to_tags=to_tags)
    except Exception as e:
        sentry.captureException()


@app.task
def quant_dev_wechat_app_send_text_task(text, to_users=None, to_parties=None, to_tags=None):
    quant_dev_app = QuantDevWeChatAPP()
    try:
        quant_dev_app.send_text(text, to_users=to_users, to_parties=to_parties, to_tags=to_tags)
    except Exception as e:
        sentry.captureException()


@app.task
def quant_ops_wechat_app_send_text_task(text, to_users=None, to_parties=None, to_tags=None):
    if not config.Debug:
        quant_ops_app = QuantOpsWeChatAPP()
        try:
            quant_ops_app.send_text(text, to_users=to_users, to_parties=to_parties, to_tags=to_tags)
        except Exception as e:
            sentry.captureException()


@app.task
def update_strategy_status(strategy_id):
    sc = session()
    s = sc.query(Strategy).filter(Strategy.id == strategy_id).first()
    if s.progress()['progress'] >= 0.9:
        s.update_status()
        sc.commit()
        sc.close()
        return True
    if time.mktime(s.r_update_time.timetuple()) >= (time.time() - 5):
        s.update_cache()
        sc.close()
        return False
    s.update_status()
    sc.commit()
    sc.close()
    return True


@app.task
def ev_start_strategy_task(strategy_id):
    sc = session()
    strategy = sc.query(Strategy).filter(Strategy.id == strategy_id).first()
    try:
        strategy.start_task(auto=False)
        sc.close()
        return True, strategy_id
    except Exception as e:
        sentry.captureException()
        sc.close()
        return False, strategy_id


@app.task
def start_strategy_task(strategy_id, **kwargs):
    Strategy.set_single_interest(strategy_id)
    sc = session()
    strategy = sc.query(Strategy).filter(Strategy.id == strategy_id).first()

    if strategy.node == 'back_test' and kwargs.get('task_id') and kwargs['task_id'] != strategy.st_uuid:
        sc.close()
        return False

    try:
        if strategy.node == 'ev':
            queue = choose_task_queue(uid=strategy.r_create_user_id, s_id=strategy_id)
            if queue:
                ev_start_strategy_task.apply_async(args=(strategy_id,), queue=queue)
                sc.close()
                return True

        if strategy.node in ('back_test', 'order_list', 'trademaster_order_list', 'union_simu'):
            sc.query(BackTestTradeLogs).filter(BackTestTradeLogs.strategy_id == strategy.id).delete(
                synchronize_session=False)

            if strategy.strategy_type in consts.stock_strategy_type:
                sc.query(StrategyBackTestSlippage).filter(
                    StrategyBackTestSlippage.strategy_id == strategy_id,
                    StrategyBackTestSlippage.config_id == 0
                ).delete(synchronize_session=False)

                sc.query(StrategyVwapResult).filter(
                    StrategyVwapResult.strategy_id == strategy_id,
                    StrategyVwapResult.config_id == 0,
                ).delete(synchronize_session=False)

                sc.query(
                    StrategyTradingVolumeRatioStatistic
                ).filter(
                    StrategyTradingVolumeRatioStatistic.s_id == strategy_id,
                ).delete(synchronize_session=False)

                sc.query(
                    StrategyTradingVolumeRatio
                ).filter(
                    StrategyTradingVolumeRatio.s_id == strategy_id,
                ).delete(synchronize_session=False)

                sc.query(
                    StrategyStyleExposure
                ).filter(
                    StrategyStyleExposure.strategy_id == strategy_id,
                ).delete(synchronize_session=False)

                sc.query(
                    StrategyRiskAttribute
                ).filter(
                    StrategyRiskAttribute.strategy_id == strategy_id,
                ).delete(synchronize_session=False)

                sc.query(
                    StrategyBackTestTradeIndicator
                ).filter(
                    StrategyBackTestTradeIndicator.s_id == strategy_id,
                ).delete(synchronize_session=False)

                sc.query(
                    StrategyIncomeAttribution
                ).filter(
                    StrategyIncomeAttribution.strategy_id == strategy_id,
                ).delete(synchronize_session=False)

            sc.commit()

        strategy.start_task(auto=False)
        sc.close()
        return True
    except Exception as e:
        sentry.captureException()
        sc.close()
        return False


@app.task
def refer_start_back_test(user_id, strategy_id):
    result = True
    sc = session()
    strategy = sc.query(Strategy).filter(Strategy.id == strategy_id).first()
    if strategy:
        try:
            strategy.start_task(user_id=user_id, auto=False)
        except Exception as e:
            sentry.captureException()
            result = False
    sc.close()
    return result


@app.task(queue=CeleryQueueName.QueueCommon.value)
def strategy_ev_task(strategy_id, start_date, redo_times=0, st_uuid=''):
    sc = session()
    s = sc.query(Strategy).filter(Strategy.id == strategy_id).first()
    if st_uuid and (st_uuid != s.st_uuid):
        sc.close()
        return False

    try:
        if redo_times >= 200:
            raise ValueError('ev redo too many times %s %s %s' % (strategy_id, start_date, redo_times))

        # queue = get_task_queue(user_id=s.r_create_user_id, ev_id=strategy_id)
        queue = choose_task_queue(uid=s.r_create_user_id, s_id=strategy_id)
        if queue:
            check = s.check_dependency(start_date, 0)
            if not check:
                strategy_ev_task.apply_async(args=(strategy_id, start_date, redo_times + 1, st_uuid), countdown=120)
                sc.close()
                return False

            daily_auto_strategy_ev_task.apply_async(args=(strategy_id, start_date), queue=queue)
            sc.close()
            return True

        s.start_task(start_date=start_date, auto=True)
        success = True
    except Exception as e:
        sentry.captureException()
        success = False

    sc.close()
    return success


@app.task
def queue_redo_ev_task(s_id, start_date, **kwargs):
    """
    redo someday's ev

    :param s_id: int
        strategy id
    :param start_date: str
        %Y%m%d
    :param kwargs:
        strategy param
    :return:
    """
    sc = session()
    s = sc.query(Strategy).filter(
        Strategy.id == s_id
    ).first()
    try:
        kw = {
            'start_date': start_date,
        }
        if kwargs.get('end_date'):
            kw['end_date'] = kwargs['end_date']
        s.start_ev_task_v3(**kw)
        success = True
    except Exception as e:
        sentry.captureException()
        success = False

    sc.close()
    return success


@app.task
def daily_auto_strategy_ev_task(strategy_id, start_date):
    sc = session()
    s = sc.query(Strategy).filter(Strategy.id == strategy_id).first()
    try:
        s.start_task(start_date=start_date, auto=True)
        success = True
    except Exception as e:
        sentry.captureException()
        success = False

    sc.close()
    return success


@app.task
def redo_ev_task(s_id, start_date, **kwargs):
    sc = session()
    s = sc.query(Strategy).filter(
        Strategy.id == s_id
    ).first()
    try:
        # queue = get_task_queue(user_id=s.r_create_user_id, ev_id=s_id)
        queue = choose_task_queue(uid=s.r_create_user_id, s_id=s_id)
        if queue:
            queue_redo_ev_task.apply_async(args=(s_id, start_date), kwargs=kwargs, queue=queue)
            sc.close()
            return True
        kw = {
            'start_date': start_date,
        }
        if kwargs.get('end_date'):
            kw['end_date'] = kwargs['end_date']
        s.start_ev_task_v3(**kw)
        success = True
    except Exception as e:
        sentry.captureException()
        success = False

    sc.close()
    return success


def _delete_result(sc, s_id, start_date):
    """
    根据策略id删除start_date后面的数据，此函数不做commit，调用此函数后请自行commit
    :param sc:
    :param s_id:        策略id
    :param start_date:
    :return:
    """
    # delete data after start date
    sc.query(StrategyBackTestSlippage).filter(
        StrategyBackTestSlippage.strategy_id == s_id,
        StrategyBackTestSlippage.trading_date >= start_date,
        StrategyBackTestSlippage.config_id == 0
    ).delete(synchronize_session=False)

    sc.query(StrategyVwapResult).filter(
        StrategyVwapResult.strategy_id == s_id,
        StrategyVwapResult.trading_date >= start_date,
        StrategyVwapResult.config_id == 0,
    ).delete(synchronize_session=False)

    sc.query(
        StrategyTradingVolumeRatioStatistic
    ).filter(
        StrategyTradingVolumeRatioStatistic.s_id == s_id,
        StrategyTradingVolumeRatioStatistic.trading_date >= start_date,
    ).delete(synchronize_session=False)

    sc.query(
        StrategyTradingVolumeRatio
    ).filter(
        StrategyTradingVolumeRatio.s_id == s_id,
        StrategyTradingVolumeRatio.trading_date >= start_date,
    ).delete(synchronize_session=False)

    sc.query(
        StrategyStyleExposure
    ).filter(
        StrategyStyleExposure.strategy_id == s_id,
        StrategyStyleExposure.trading_date >= start_date,
    ).delete(synchronize_session=False)

    sc.query(
        StrategyRiskAttribute
    ).filter(
        StrategyRiskAttribute.strategy_id == s_id,
        StrategyRiskAttribute.trading_date >= start_date,
    ).delete(synchronize_session=False)

    sc.query(
        StrategyBackTestTradeIndicator
    ).filter(
        StrategyBackTestTradeIndicator.s_id == s_id,
        StrategyBackTestTradeIndicator.trading_date >= start_date,
    ).delete(synchronize_session=False)

    sc.query(
        StrategyIncomeAttribution
    ).filter(
        StrategyIncomeAttribution.strategy_id == s_id,
        StrategyIncomeAttribution.trading_date >= start_date,
    ).delete(synchronize_session=False)


@app.task(queue='cron_120_task')
def redo_strategy_papertrading(s_id, start_date):
    sc = session()
    s = sc.query(Strategy).filter(Strategy.id == s_id).first()
    try:
        if s.node in ('back_test', 'union_simu') and (s.strategy_type in consts.stock_strategy_type):

            # 如果是联合模拟策略还需要把子策略的result删除
            if s.node == "union_simu":
                union_s_ids = [int(k) for k in s.detail.get('union_stra_weight', {}).keys()]
                for union_s_id in union_s_ids:
                    _delete_result(sc, union_s_id, start_date)

            _delete_result(sc, s_id, start_date)
            sc.commit()

        s.start_task(start_date=start_date, auto=True)

        if s.strategy_status != 'LT':
            s.strategy_status = 'PT'
            sc.commit()

    except Exception as e:
        sentry.captureException()
        sc.close()
        return False

    sc.close()
    return True


@app.task
def auto_daily_paper_trading_task(trading_date, day_night, offset, include_strategy_type=None,
                                  exclude_strategy_type=None, auto_max_date=True):
    """
    daily paper trading
    :param trading_date: str %Y%m%d
    :param day_night: int DAY=0 NIGHT=1 no use
    :param offset: int offset from trading_date
    :param auto_max_date: bool auto find done paper trading date
    :param include_strategy_type: str "1,2,3,4"
    :param exclude_strategy_type: str "1,2,3,4"
    :return:
    """
    trading_calendar = TradeCalendar.init_from_kdb(**config.kdb_config)
    last_trading_date = trading_calendar[trading_date, offset]
    start_date = last_trading_date.astype(datetime.datetime).strftime("%Y%m%d")
    sc = session()

    strategies = sc.query(Strategy).filter(
        Strategy.is_delete == 0,
        Strategy.is_test == 0,
        Strategy.end_date >= start_date,
        Strategy.status == consts.TASK_FINISHED,
    ).order_by(
        Strategy.id.desc()
    )

    if include_strategy_type is not None:
        include = str(include_strategy_type).split(",")
        strategies = strategies.filter(Strategy.strategy_type.in_(include))

    if exclude_strategy_type is not None:
        exclude = str(include_strategy_type).split(",")
        strategies = strategies.filter(Strategy.strategy_type.notin_(exclude))
    s_dates = {_s_d[0]: _s_d[1] for _s_d in sc.query(
        StrategyResult.strategy_id, func.max(StrategyResult.date)
    ).filter(
        StrategyResult.status == consts.TASK_FINISHED,
        StrategyResult.config_id == 0,
    ).group_by(StrategyResult.strategy_id)} if auto_max_date else {}

    for s in strategies:
        try:
            if s.node in ('ev', 'order_list', 'trademaster_order_list'):
                continue

            # 联合策略的子策略不下发 papertrading 任务
            if s.is_derive_strategy and s.node == "union_simu":
                continue

            if s_dates.get(s.id):
                _start_date = (parse(s_dates[s.id]) + datetime.timedelta(days=1)).strftime("%Y%m%d")
                _start_date = min(_start_date, start_date)
            else:
                _start_date = start_date

            if (s.r_create_user_id == CompanyUser.HuangChunChun['id'] and (
                    s.strategy_type in consts.alpha_stock_strategy_type)) or \
                    (s.strategy_type in consts.t0_stock_strategy_type):
                redo_strategy_papertrading.apply_async(args=(s.id, _start_date), countdown=900)
                continue

            Strategy.add_strategy_event(
                s.id,
                _start_date,
                TradingTimeRange.Day.value,
                StrategyEventTrackConstant.Event.AutoStrategyPaperTrading.value,
                task_id=s.st_uuid
            )

            s.start_task(start_date=_start_date, auto=True)

            if s.strategy_status != 'LT':
                s.strategy_status = 'PT'
                sc.commit()
        except Exception as e:
            sentry.captureException()
            continue

    sc.close()
    return True


@app.task
def auto_daily_ev_task(day=None):
    now = datetime.datetime.now()
    today = now.strftime('%Y%m%d')
    now_hour = now.hour

    if day:
        today = day

    if now_hour >= 17:
        day_night = 1
    else:
        day_night = 0

    if now.weekday() >= 5:
        return True

    sc = session()
    strategies = sc.query(Strategy).filter(
        Strategy.is_delete == 0,
        Strategy.is_test == 0,
        Strategy.end_date >= today,
        Strategy.status != consts.TASK_STOPPED,
        Strategy.node == 'ev',
        Strategy.r_create_user_id.notin_(consts.stock_ev_user_ids),
    ).order_by('id')

    for s in strategies:
        if (s.day_night != 2) and (s.day_night != day_night):
            continue
        if s.id in consts.STOCK_FACTOR_EV:
            continue
        try:
            strategy_ev_task.delay(s.id, today, redo_times=0, st_uuid=s.st_uuid)
        except Exception as e:
            sentry.captureException()
            continue

    sc.close()
    return True


@app.task
def daily_stock_ev_task(is_live=True):
    today_str = datetime.datetime.today().strftime('%Y%m%d')
    sc = session()

    strategies = sc.query(Strategy).filter(
        Strategy.is_delete == 0,
        Strategy.is_test == 0,
        Strategy.end_date >= today_str,
        Strategy.status != StrategyConstant.Status.STOPPED.value,
        Strategy.node == StrategyConstant.Node.EV.value,
        Strategy.r_create_user_id.in_(CompanyUser.stock_ev_user_ids()),
        Strategy.id.notin_(consts.STOCK_FACTOR_EV)
    )

    if is_live:
        strategies = strategies.filter(
            Strategy.id.in_(get_live_ev_ids_cache())
        )
    else:
        strategies = strategies.filter(
            Strategy.id.notin_(get_live_ev_ids_cache())
        )

    strategies = strategies.order_by(
        Strategy.id.asc()
    ).all()

    for s in strategies:
        try:
            strategy_ev_task.delay(s.id, today_str, redo_times=0, st_uuid=s.st_uuid)
        except Exception as e:
            sentry.captureException()
            continue

    sc.close()
    return True


@app.task
def daily_stock_factor_task():
    today_str = datetime.datetime.today().strftime('%Y%m%d')
    sc = session()

    strategies = sc.query(Strategy).filter(
        Strategy.is_delete == 0,
        Strategy.is_test == 0,
        Strategy.end_date >= today_str,
        Strategy.status != StrategyConstant.Status.STOPPED.value,
        Strategy.node == StrategyConstant.Node.EV.value,
        Strategy.id.in_(consts.STOCK_FACTOR_EV)
    ).order_by(
        Strategy.id.asc()
    ).all()

    for s in strategies:
        try:
            strategy_ev_task.delay(s.id, today_str, redo_times=0, st_uuid=s.st_uuid)
        except Exception as e:
            sentry.captureException()
            continue

    sc.close()
    return True


@app.task(queue=CeleryQueueName.QueueCommon.value)
def vs_back_test(vs_id, day, **kwargs):
    sc = session()
    vs = sc.query(VStrategies).filter(VStrategies.id == vs_id).first()
    if not vs:
        sc.close()
        return False

    s = sc.query(Strategy).filter(Strategy.id == vs.strategy_id).first()
    sp = sc.query(StrategyPortfolio).filter(StrategyPortfolio.id == vs.portfolio_id).first()

    live_time = (sp.live_time or sp.r_create_time).strftime('%Y%m%d')
    if day < live_time:
        day = live_time

    # 在VsbBackTestPara表中记录或者更新数据
    vs_back_para = sc.query(VsbBackTestPara).filter(VsbBackTestPara.vstrategy_id == vs_id,
                                                    VsbBackTestPara.trading_date == day)
    if vs_back_para.first():
        vs_back_para.update({'use_last_live_position': kwargs.get('use_last_live_position', False)})
        sc.commit()
    else:
        obj = VsbBackTestPara(vstrategy_id=vs_id,
                              trading_date=day,
                              use_last_live_position=kwargs.get('use_last_live_position', False))
        sc.add(obj)
        sc.commit()

    auto = kwargs.get("auto", False)

    try:
        if s.node == StrategyConstant.Node.BackTest.value:
            vs_back_test_analysis(vs.id, day, **kwargs)
        elif s.node == StrategyConstant.Node.UnionSimu.value \
                and s.strategy_type == StrategyConstant.StrategyType.StockAlpha.value:
            vs_union_simu_back_test_analysis_from_alpha_vs(vs.id, day, **kwargs)
        else:
            pass
    except BackTestAnalysisCheckFailException as e:
        if auto and vs.status == VStrategiesConstant.Status.Live.value:
            vs_back_test.apply_async(args=(vs.id, day), kwargs=kwargs, countdown=30 * 60)
    except Exception as e:
        sc.close()
        sentry.captureException()
        return False

    sc.close()
    return True


@app.task
def auto_vs_back_test(vs_ids=None, day=None, count=0, business="future"):
    """

    :param vs_ids: list
    :param day: string, "%Y%m%d", trading date
    :param count: int
    :param business: string, StrategyPortfolioConstant.Business
    :return:
    """
    date = datetime.date.today().strftime("%Y%m%d")
    if day:
        date = day

    trading_calendar = TradeCalendar.init_from_kdb(**config.kdb_config)
    if not trading_calendar.is_trading_date(date=date):
        return False

    # if isinstance(config, ProductConfigIDC) and not vs_ids:
    #     from my.data import status as data_status
    #     _status = data_status(int(date), 0)
    #
    #     if _status != 'SUCCESS':
    #         if count <= 3:
    #             content = "数据状态未就绪，盘后分析延后30分钟"
    #             company_platform_wechat_app_send_text_task.delay(content + suffix)
    #             auto_vs_back_test.apply_async(args=(vs_ids, day, count + 1, business), countdown=1800)
    #             return False
    #         else:
    #             content = "数据状态未就绪，多次延迟后开始盘后分析"
    #             company_platform_wechat_app_send_text_task.delay(content + suffix)
    #     else:
    #         company_platform_wechat_app_send_text_task.delay(content + suffix)
    content = "date={date}, business={business} 开始盘后分析".format(date=date, business=business)
    company_platform_wechat_app_send_text_task.delay(content)
    sc = session()

    settle_vs_ids = sc.query(
        VsBase.vstrategy_id
    ).filter(
        VsBase.settle_date == date
    ).distinct()

    vstrategies = sc.query(
        VStrategies.id.label('id'),
        Strategy.r_create_user_id.label('user_id'),
        Strategy.strategy_type.label('s_type'),
        Strategy.node.label('s_node'),
    ).join(
        Strategy, Strategy.id == VStrategies.strategy_id
    ).join(
        StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
    ).filter(
        or_(
            VStrategies.status == VStrategiesConstant.Status.Live.value,
            VStrategies.id.in_(settle_vs_ids)
        ),
        StrategyPortfolio.business == business
    )

    if vs_ids:
        if not isinstance(vs_ids, list):
            vs_ids = [vs_ids]
        vstrategies = vstrategies.filter(VStrategies.id.in_(vs_ids))

    for vs in vstrategies:
        if vs.user_id == CompanyUser.HuangChunChun['id'] \
                and vs.s_type in StrategyConstant.StrategyType.alpha_stock_group():
            vs_back_test.apply_async(args=(vs.id, date), kwargs={'auto': True}, countdown=900)
        else:
            vs_back_test.delay(vs.id, date, auto=True)

        Strategy.add_vs_event(
            vs.id,
            date, 0,
            StrategyEventTrackConstant.Event.AutoVsBackTest.value
        )

    sc.close()
    return True


@app.task(queue=CeleryQueueName.QueueCommon.value)
def update_strategy_performance(strategy_id):
    """
    主要是计算期货策略的pnl，绩效相关的数据，组合分析的时候可能会使用到
    """
    # now = datetime.datetime.now()
    # if now.hour >= 23 or now.hour <= 8:
    #     return True
    StrategyPerformance.update_strategy(strategy_id)
    return True


@app.task(queue=CeleryQueueName.QueueCommon.value)
def update_track_detail_cache_new():
    sc = session()
    live_strategies = sc.query(
        VStrategies.id.label('vs_id'),
        Strategy.id_no.label('id_no'),
        StrategyPortfolio.name.label('name'),
    ).join(
        Strategy, or_(
            and_(
                Strategy.id == VStrategies.strategy_id, VStrategies.group_id == 0
            ),
            Strategy.id == VStrategies.group_id
        )
    ).join(
        StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
    ).filter(
        VStrategies.status == consts.STRATEGY_LIVE,
        VStrategies.source == 'platform',
    )
    strategy_ids = set([(s.id_no, s.name) for s in live_strategies])
    sc.close()

    for (s_id, p_name) in strategy_ids:
        try:
            cache_key = 'platform_track_basic_data_%s_%s' % (s_id, p_name)
            ttl = ttl_cache(cache_key)
            if not (ttl and ttl > 20):
                update_strategy_track_data_cache_new.delay(s_id, portfolio_name=p_name)
        except Exception as e:
            sentry.captureException()
    return True


@app.task(queue=CeleryQueueName.QueueCommon.value)
def update_strategy_track_data_cache_new(strategy_id, **kwargs):
    """
    更新交易跟踪的数据
    """
    try:
        from service.statistic.track import StrategyTrackService
        ss = StrategyTrackService(id_no=strategy_id, **kwargs)
        ss.get_basic_data(cache=False)
        ss.strategy_track(cache=False)
    except Exception as e:
        sentry.captureException()
        return False
    return True


@app.task
def auto_update_close_status():
    sc = session()
    closing_objs = sc.query(VStrategies).filter(VStrategies.closing_out == consts.STRATEGY_CLOSING_OUT).all()
    from service.back_test.models import ClearPosition
    for obj in closing_objs:
        clear = ClearPosition(obj.id)
        clear.check_position()
    sc.close()


@app.task
def settlement_notify(trading_date, day_night):
    """
    结算通知
    """
    trading_date = parse(trading_date).strftime('%Y%m%d')
    day_night = {
        0: 'DAY',
        1: 'NIGHT',
    }[int(day_night)]

    sql_summary = """select id, `status`, portfolio_id, strategy_id, closing_out, group_id, set_close_time
                     from vstrategies where `status`=15 and id not in (
                     select vstrategy_id from vs_base where settle_date='%s' and daynight='%s'
                     )""" % (trading_date, day_night)
    sql_summary2 = """select id, `status`, portfolio_id, strategy_id, closing_out, group_id, set_close_time
    from vstrategies
    where (id in (select DISTINCT vstrategy_id from vs_base))
    and id not in (select DISTINCT vstrategy_id from vs_base where settle_date='%s' and daynight='%s')
    and `status` not in (-1, 16)
        """ % (trading_date, day_night)
    sql_base = """select * from vs_base where settle_date='%s' and daynight='%s'""" % (trading_date, day_night)
    sql_accounts = """select * from vs_accounts where settle_date='%s' and daynight='%s'""" % (trading_date, day_night)

    df = pd.read_sql_query(sql_summary, engine)
    df_summary2 = pd.read_sql_query(sql_summary2, engine)
    df1 = pd.read_sql_query(sql_base, engine)
    df2 = pd.read_sql_query(sql_accounts, engine)
    title = '%s_%s Settlement' % (trading_date, day_night)
    content = '\n\n'.join([df.to_html(), df_summary2.to_html(), df1.to_html(), df2.to_html()])
    to_addr = [CompanyEmailGroup.quant_dev, CompanyEmailGroup.quant_ops, CompanyEmailGroup.LiShaoFeng,
               CompanyEmailGroup.ZhouChaoLin, CompanyEmailGroup.HuBo]

    send_email(title, content, to_addr, content_type='html')
    if len(df) + len(df_summary2) == 0:
        notify_operation_wechat("结算成功")
    else:
        notify_operation_wechat("结算失败，请查看邮件")
    VsAggregationPnl.update_aggregation_pnl()
    # InvestmentPerformanceService.publish_vs_update(['all'])
    return True


@app.task
def upload_tradelist_notify(strategy_id, date, **kwargs):
    from config import ProductConfigIDC
    if not isinstance(config, ProductConfigIDC):
        return True
    sql = """
    select * from orderlist where strategy_id=%s and date=%s
    """ % (strategy_id, date)
    df = pd.read_sql_query(sql, engine)
    title = '%s_%s Upload TradeList' % (strategy_id, date)
    if kwargs.get('trade_list'):
        df1 = pd.DataFrame(data=kwargs['trade_list']['values'], columns=kwargs['trade_list']['keys'])
        content = '\n\n'.join([df1.to_html(), df.to_html()])
    else:
        content = df.to_html()
    to_addr = [CompanyEmailGroup.quant_dev, CompanyEmailGroup.LiShaoFeng]
    send_email(title, content, to_addr, content_type='html')
    return True


@app.task
def auto_update_strategy_status():
    sc = session()

    for s in sc.query(Strategy).filter(Strategy.strategy_status == 'LT'):
        if s.group_id > 0:
            vs = sc.query(VStrategies).filter(VStrategies.status == 15, VStrategies.group_id == s.id)
        else:
            vs = sc.query(VStrategies).filter(VStrategies.status == 15, VStrategies.strategy_id == s.id)
        count = vs.count()
        if count == 0:
            s.strategy_status = 'PT'

    for vs in sc.query(VStrategies).filter(VStrategies.status == 15):
        if vs.group_id > 0:
            g = sc.query(Strategy).filter(Strategy.id == vs.group_id).first()
            g.strategy_status = 'LT'
        s = sc.query(Strategy).filter(Strategy.id == vs.strategy_id).first()
        s.strategy_status = 'LT'

    for sp in sc.query(StrategyPortfolio).filter(StrategyPortfolio.status == 15):
        vs = sc.query(VStrategies).filter(VStrategies.status != 16, VStrategies.portfolio_id == sp.id)
        count = vs.count()
        if count == 0:
            sp.status = 16

    sc.commit()
    sc.close()
    return True


@app.task(queue=CeleryQueueName.QueueCommon.value)
def auto_daily_account_funds_task(trading_day=None):
    """
    :param 
        trading_day: str, eg '2018.04.11'
    :return
        bool, True for success, False for failure
    """
    if not trading_day:
        trading_day = time.strftime('%Y.%m.%d')

    if not KdbQuery().is_trading_date(trading_day):
        logger.info("[account_funds]% is not trading date, so not need to query account funds." % trading_day)
        return True

    # 从实盘查询所有账户
    sc = session()
    accounts = sc.query(Accounts).filter_by(need_query=True)
    if 0 == accounts.count():
        logger.info("[account_funds]No account need to query.")
        return True

    trading_day = trading_day.replace('.', '-')
    for account in accounts:
        account_no = account.name
        _notional_strategy = 0

        # 账户权益
        funds_data = sc.query(
            AccountBalanceCounter.balance,
        ).filter(
            AccountBalanceCounter.account == account_no,
            AccountBalanceCounter.trading_day == trading_day
        ).first()
        if not funds_data:
            logger.info("[account_funds]No data on %s for account %s." % (trading_day, account_no))
            continue

        # 账户所投资策略的面值之和
        notional_query = sc.query(
            func.sum(VStrategyAccountDetail.amount)
        ).join(
            VStrategies, VStrategies.id == VStrategyAccountDetail.vstrategy_id
        ).filter(
            VStrategies.status == 15,  # 实盘
            VStrategyAccountDetail.account == account_no
        ).first()
        _notional_strategy += notional_query and notional_query[0] or 0

        record = sc.query(
            AccountFunds
        ).filter_by(
            account=account_no,
            trading_day=trading_day
        ).first()
        if not record:
            detail = AccountFunds(
                account=account_no,
                trading_day=trading_day,
                balance=funds_data.balance,
                notional_strategy=0,
            )
            sc.add(detail)
        else:
            setattr(record, 'balance', funds_data.balance)
            setattr(record, 'notional_strategy', 0)
        sc.commit()
    sc.close()
    return True


@app.task(queue='cron_120_task')
def update_strategy_sorting_result(strategy_id):
    """
    计算策略及组合分析页面的相关指标，策略的年度绩效等
    """
    BackTestPerformance.update_strategy(strategy_id)
    return True


@app.task(queue=CeleryQueueName.QueueCommon.value)
def check_vs_pnl_graph(pnl_args, filename):
    redo = False
    if not os.path.exists(filename):
        redo = True
    if (time.time() - os.stat(filename).st_mtime) > 43200:
        redo = True
    if not redo:
        return None
    try:
        vs_pnl = VsPnlGraph(vs_ids=pnl_args['vs_ids'], summary=pnl_args['summary'], filename=filename,
                            is_future=pnl_args.get('is_future'))
        vs_pnl.graph()
    except Exception as e:
        sentry.captureException()
        return False
    return True


@app.task(queue=CeleryQueueName.QueueCommon.value)
def back_test_done(s_id, config_id=0):
    """
    回测任务完成时调用
    """
    sc = session()
    s = sc.query(Strategy).filter(
        Strategy.id == s_id
    ).first()
    if not s:
        sc.close()
        return False
    if s.strategy_type == '26':
        sc.close()
        return True

    # 联合模拟完毕后清除掉T0子策略的绩效cache，重新计算绩效
    if s.node == "union_simu":
        sub_sts = s.detail.get("sub_sts", [])
        for sub_st_id in sub_sts:
            sub_st = sc.query(Strategy).filter(
                Strategy.id == sub_st_id
            ).first()
            if not sub_st:
                continue
            strategy_type = sub_st.detail.get("strategy_type", None)
            if not strategy_type:
                continue
            # 判断子策略是不是T0策略
            if strategy_type == "18":
                del_cache('platform_strategy_detail_%s_0_0' % sub_st)
                update_strategy_sorting_result.apply_async(args=(sub_st,), countdown=15)
                update_strategy_performance.apply_async(args=(sub_st,), countdown=15)

    del_cache('platform_strategy_brief_%s_0_0' % s_id)
    del_cache('platform_strategy_detail_%s_0_0' % s_id)
    del_cache('platform_strategy_output_%s_0' % s_id)
    update_strategy_sorting_result.apply_async(args=(s_id,), countdown=15)
    update_strategy_performance.apply_async(args=(s_id,), countdown=15)
    if config_id == 0:
        import_stock_style_exposure.apply_async(args=(s_id,), countdown=15)
        import_stock_income_attribution.apply_async(args=(s_id,), countdown=15)
        try:
            get_t0_position(s_id, cache=False)
        except Exception as e:
            sentry.captureException()
    sc.close()
    return s_id


@app.task(queue=CeleryQueueName.QueueCommon.value)
def vs_back_test_done(vs_id, **kwargs):
    """
    盘后分析任务完成时调用， 用于更新绩效缓存
    """
    status = kwargs.get('status')
    if status == consts.AGENT_TASK_FAILED:
        Strategy.add_vs_event(
            vs_id, datetime.datetime.now().strftime('%Y%m%d'), 0, 'VsBackTestFailed'
        )
    elif status == consts.AGENT_TASK_FINISHED:
        Strategy.add_vs_event(
            vs_id, datetime.datetime.now().strftime('%Y%m%d'), 0, 'VsBackTestFinished'
        )
    else:
        pass

    sc = session()
    try:
        vs = sc.query(
            VStrategies.strategy_id.label('strategy_id'),
            VStrategies.group_id.label('group_id'),
        ).filter(
            VStrategies.id == vs_id
        ).first()

        del_cache('platform_live_strategy_analysis_v2_%s' % vs.strategy_id)
        del_cache('platform_strategy_brief_%s_0_0' % vs.strategy_id)
        del_cache('platform_strategy_detail_%s_0_0' % vs.strategy_id)
        del_cache('platform_strategy_output_%s_0' % vs.strategy_id)
        del_cache('platform_strategy_vs_back_test_pnl_%s_0' % vs.strategy_id)

        if vs.group_id:
            del_cache('platform_live_strategy_analysis_v2_%s' % vs.group_id)
            del_cache('platform_strategy_brief_%s_0_0' % vs.group_id)
            del_cache('platform_strategy_detail_%s_0_0' % vs.group_id)
            del_cache('platform_strategy_output_%s_0' % vs.group_id)
            del_cache('platform_strategy_vs_back_test_pnl_%s_0' % vs.group_id)

        cache_rds = redis.Redis(
            host=config.data_cache['host'],
            port=config.data_cache['port'],
            db=config.data_cache['db']
        )

        # 策略绩效页面前端用了该数据用于展示 /api/v1/platform/investment_performance/vs/pnl
        for key in cache_rds.keys('platform_investment_basic_data_*%s*pnl_data.json' % gen_hash_value([vs_id])):
            cache_rds.delete(key)

        for key in cache_rds.keys('investment_performance_net_pnl_*%s*' % vs_id):
            cache_rds.delete(key)

        for key in cache_rds.keys('investment_performance_net_pnl_*%s*' % vs.strategy_id):
            cache_rds.delete(key)

        if vs.group_id:
            for key in cache_rds.keys('investment_performance_net_pnl_*%s*' % vs.group_id):
                cache_rds.delete(key)
    except Exception as e:
        sentry.captureException()
        sc.close()
        return False

    sc.close()
    return True


@app.task
def clear_investment_performance_cache():
    try:
        Strategy.clear_investmentperformance_cache()
        InvestmentPerformanceService.clear_basic_cache(None)
    except Exception as e:
        sentry.captureException()


@app.task(queue=CeleryQueueName.QueueCommon.value)
def update_stock_hedge_vs():
    try:
        InvestmentPerformanceService.get_stock_hedge_vs(cache=False)
    except Exception as e:
        sentry.captureException()
        return False
    return True


@app.task
def update_strategy_confidence(strategy_id):
    """
    修改策略回测结果的可信度
    """
    try:

        del_cache('platform_live_strategy_analysis_v2_%s' % strategy_id)
        del_cache('platform_strategy_brief_%s_0_0' % strategy_id)
        del_cache('platform_strategy_detail_%s_0_0' % strategy_id)
        del_cache('platform_strategy_output_%s_0' % strategy_id)

        cache_rds = redis.Redis(
            host=config.data_cache['host'],
            port=config.data_cache['port'],
            db=config.data_cache['db']
        )
        sc = session()
        for vs_id in sc.query(VStrategies.id).filter(VStrategies.strategy_id == strategy_id):
            for key in cache_rds.keys('investment_performance_net_pnl_*%s*' % vs_id[0]):
                cache_rds.delete(key)
        for key in cache_rds.keys('investment_performance_net_pnl_*%s*' % strategy_id):
            cache_rds.delete(key)
        sc.close()
        update_strategy_performance.delay(strategy_id)
        update_strategy_sorting_result.delay(strategy_id)
    except Exception as e:
        sentry.captureException()
        return False
    return True


@app.task
def notify_vs_off_line(vs_id):
    """
    实盘策略下线通知
    """
    try:
        sc = session()
        sql = 'SELECT deploy.`host`,st.id_no,deploy.id from vstrategies vs LEFT JOIN deploy_confs deploy on vs.id=deploy.vstrategy_id LEFT JOIN strategy st on st.id=vs.strategy_id WHERE vs.id = %s' % vs_id
        for host, name, process_id in sc.execute(sql):
            msg = '策略下线通知: 策略{name}(vs_id={vs_id}) host:{host}已下线, process_id={process_id}'.format(vs_id=vs_id,
                                                                                                   process_id=process_id,
                                                                                                   host=host, name=name)
            notify_operation_wechat(msg)
        sc.close()
    except Exception as e:
        sentry.captureException()
        return False
    return True


@app.task(queue='cron_120_task')
def strategy_back_test_trading_date_done(s_id, trading_date, day_night, config_id=0):
    """
    回测任务每个日盘或者夜盘执行完调用
    """
    from service.vwap.models import StrategyVwapResult
    from service.statistic.models import StrategyTradingVolumeRatio

    if config_id != 0:
        return False
    if day_night != 0:
        return False

    now_hour = datetime.datetime.now().strftime('%H%M')
    if not ('0000' <= now_hour <= '0730'):
        update_strategy_sorting_result.delay(s_id)

    sc = session()
    s = sc.query(
        Strategy.strategy_type.label('strategy_type')
    ).filter(
        Strategy.id == s_id
    ).first()
    if not s:
        sc.close()
        return False

    if s.strategy_type in consts.stock_strategy_type:
        StrategyVwapResult.gen_vwap_result(s_id, trading_date)
        StrategyTradingVolumeRatio.genarate_mkt_volume_ratio(s_id, trading_date)

    try:
        tradelogs2dataframe(s_id, trading_date, redo=True)
    except Exception as e:
        sentry.captureException()

    sc.close()
    return True


@app.task(queue='cron_120_task')
def vs_back_test_trading_date_done(vs_id, trading_date, day_night):
    """
    盘后分析任务每个日盘或者夜盘执行完调用
    """
    from service.vwap.models import VsVwapResult
    from service.statistic.models import VsBacktestTradingVolumeRatio
    vs_back_test_done.delay(vs_id)
    if day_night != 0:
        Strategy.add_vs_event(
            vs_id, trading_date, day_night, 'CurrentTradingDateStart'
        )
        return False
    Strategy.add_vs_event(
        vs_id, trading_date, day_night, 'CurrentTradingDateEnd'
    )
    VsVwapResult.gen_vwap_result(vs_id, trading_date)
    VsBacktestTradingVolumeRatio.genarate_mkt_volume_ratio(vs_id, trading_date)
    return True


@app.task(queue='cron_120_task')
def import_stock_style_exposure(s_id):
    """
    计算股票策略的风格偏离数据
    """
    StrategyStyleExposure.import_strategy_style_exposure(s_id)
    return s_id


@app.task(queue='cron_120_task')
def import_stock_income_attribution(s_id, clear_history=False):
    """
    计算股票策略的收益归因
    """
    StrategyIncomeAttribution.import_strategy_income_attribution(s_id, clear_history)
    return True


@app.task
def stock_factor_publish_delay_task(factor_id, strategy_id, **kwargs):
    from service.stock_factor.models import StockFactorStrategy
    try:
        StockFactorStrategy.stock_factor_publish(factor_id, strategy_id, **kwargs)
    except Exception as e:
        sentry.captureException()
        return False
    return True


@app.task(queue=CeleryQueueName.QueueCommon.value)
def investment_check_or_generate_range_pnl_delay(vs_ids, pnl, **kwargs):
    try:
        InvestmentPerformanceService.check_or_generate_range_pnl(vs_ids, pnl, **kwargs)
    except Exception as e:
        sentry.captureException()
        return False
    return True


@app.task(queue='cron_140_task')
def ev_trading_date_done(s_id, trading_date, day_night, **kwargs):
    from service.stock_factor.models import StockFactorStrategy
    sc = session()
    s = sc.query(Strategy).filter(
        Strategy.id == s_id,
    ).first()
    if kwargs.get('task_progress'):
        s.task_progress = kwargs['task_progress']
        sc.commit()
    s_type = s.strategy_type
    sc.close()
    if s_type == '26':
        try:
            StockFactorStrategy.stock_factor_publish_daily(trading_date, factor_id=s_id)
        except Exception as e:
            sentry.captureException()
    return True, s_id, trading_date, day_night


@app.task(queue='cron_140_task')
def ev_task_done(s_id, **kwargs):
    if 's_status' in kwargs:
        sc = session()
        s = sc.query(Strategy).filter(Strategy.id == s_id).first()
        s.status = kwargs['s_status']
        sc.commit()
        sc.close()

    return True, s_id


@app.task(queue='cron_140_task')
def factor_trading_date_done(s_id, trading_date, **kwargs):
    from service.stock_factor.factor_checkbias import do_check_bias
    if kwargs.get('task_progress'):
        sc = session()
        s = sc.query(Strategy).filter(
            Strategy.id == s_id,
        ).first()
        s.task_progress = kwargs['task_progress']
        sc.commit()
        sc.close()

    try:
        do_check_bias(s_id, trading_date)
    except Exception as e:
        sentry.captureException()

    return True, s_id, trading_date


@app.task(queue='cron_140_task')
def factor_in_sample_done(s_id, trading_date, **kwargs):
    """
    notify simulator to simulate sample
    :param s_id: strategy id
    :param trading_date: date
    :return:
    """
    from service.stock_factor.models import StockFactorStrategy
    if kwargs.get('task_progress'):
        sc = session()
        s = sc.query(Strategy).filter(
            Strategy.id == s_id,
        ).first()
        s.task_progress = kwargs['task_progress']
        sc.commit()
        sc.close()

    StockFactorStrategy.send_event(factor_id=s_id, event=StockFactorEvaluationQueueEvent.Simulator.value)
    return True, s_id, trading_date


@app.task(queue='cron_140_task')
def factor_out_sample_done(s_id, trading_date, **kwargs):
    from service.stock_factor.models import StockFactorStrategy
    if kwargs.get('task_progress'):
        sc = session()
        s = sc.query(Strategy).filter(
            Strategy.id == s_id,
        ).first()
        s.task_progress = kwargs['task_progress']
        sc.commit()
        sc.close()

    StockFactorStrategy.send_event(factor_id=s_id, event=StockFactorEvaluationQueueEvent.CheckFactorDirection.value)
    return True, s_id, trading_date


@app.task(queue='cron_140_task')
def factor_task_done(s_id, **kwargs):
    from service.stock_factor.models import StockFactorStrategy
    if 's_status' in kwargs:
        sc = session()
        s = sc.query(Strategy).filter(Strategy.id == s_id).first()
        s.status = kwargs['s_status']
        sc.commit()
        sc.close()

    if kwargs.get('do_simulator'):
        StockFactorStrategy.send_event(factor_id=s_id, event=StockFactorEvaluationQueueEvent.Simulator.value)
    return True, s_id


@app.task(queue='cron_140_task')
def factor_upload_csv_done(s_id):
    from service.stock_factor.models import StockFactorStrategy
    StockFactorStrategy.send_event(factor_id=s_id, event=StockFactorEvaluationQueueEvent.Simulator.value)
    return True, s_id


@app.task(queue='cron_140_task')
def gen_portfolio_daily_max_volume_ratio_delay(s_ids):
    """
    计算多个策略组合时的每日最大市场占比，组合分析页面
    """
    from service.statistic.models import StrategyTradingVolumeRatioStatistic
    try:
        StrategyTradingVolumeRatioStatistic.gen_portfolio_daily_max_volume_ratio(s_ids)
    except Exception as e:
        sentry.captureException()
        return False
    return True


@app.task(queue='stock_team_factor_task')
def generate_strategy_portfolio_risk_delay(s_ids):
    """
    计算多个策略组合时的风格偏离相关数据，组合分析页面
    """
    from service.statistic.models import PortfolioRiskAttribute
    PortfolioRiskAttribute.generate_strategy_portfolio_risk(s_ids)
    return True


@app.task(queue='stock_team_factor_task')
def generate_vs_portfolio_risk_delay(vs_ids):
    """
    实盘每个策略集的风格偏离数据，实盘绩效页面
    """
    from service.statistic.models import PortfolioRiskAttribute
    PortfolioRiskAttribute.generate_vs_portfolio_risk(vs_ids)


@app.task
def generate_future_mkt_volume_ratio_delay(trading_date, time_range_minutes, filter_account=None):
    """
    计算期货账户的每日实盘交易占比/future/trade-volume.html
    """
    from service.statistic.future_mkt_volumn_ratio import get_mkt_volume_ratio
    try:
        get_mkt_volume_ratio(trading_date, filter_account=filter_account, time_range_minutes=time_range_minutes)
    except Exception as e:
        sentry.captureException()
        return False
    return True


@app.task
def check_future_mkt_volume_ratio_task_ready(count=3, wait=60*10):
    """
    检查任务cron_future_mkt_volume_ratio_task是否就绪
    需要两个条件，当天数据状态正常，以及能正常拿到市场总量数据（后者计算代码里判断并抛措）
    """
    today = datetime.date.today()
    yesterday = today - datetime.timedelta(days=1)

    today, yesterday = today.strftime("%Y%m%d"), yesterday.strftime("%Y%m%d")

    try:
        from my.data import status as data_status
        today_status = data_status(int(today), consts.DayNight.day.value) + data_status(int(today), consts.DayNight.night.value)
        yesterday_status = data_status(int(yesterday), consts.DayNight.day.value) + data_status(int(yesterday), consts.DayNight.night.value)
    except Exception:
        sentry.captureException()
        return False
    if count > 0:
        for status, date in zip([yesterday_status, today_status], [yesterday, today]):

            if "SUCCESS" in status:
                logger.info("[{}] data ready, mission started".format(date))
                cron_future_mkt_volume_ratio_task.delay(date)
            else:
                content = "<check_future_mkt_volume_ratio_task_ready>: [{}] Data not ready, wait for {}s before next " \
                          "attempt".format(date, wait)
                company_platform_wechat_app_send_text_task.delay(content)
                check_future_mkt_volume_ratio_task_ready.apply_async(args=(count-1, wait))
                return False


@app.task
def cron_future_mkt_volume_ratio_task(date):
    """
    计算期货账户交易在市场的总量占比，每日在交易时间开始执行，包括夜盘
    """
    from service.statistic.future_mkt_volumn_ratio import get_mkt_volume_ratio
    try:
        for time_interval in [15, 30, 45, 60]:
            get_mkt_volume_ratio(date, filter_account=None, time_range_minutes=time_interval)
            logger.info("market volume ratio for date [{}] with time interval [{}] ready"
                        .format(date, time_interval))
    except Exception as e:
        sentry.captureException()
        return False
    return True


@app.task(queue=CeleryQueueName.QueueCommon.value)
def update_live_stock_vs_position_abstract_info_task():
    """
    更新实盘股票策略仓位概要信息
    """
    from service.operation_deploy.helper import update_live_stock_vs_position_abstract_info
    try:
        update_live_stock_vs_position_abstract_info()
    except Exception as e:
        sentry.captureException()
        return False
    return True


@app.task
def vstrategy_offline_task(vs_ids=None):
    """
    实盘策略下线
    """
    sc = session()
    if not vs_ids:
        closing_objs = sc.query(VStrategies).filter(VStrategies.closing_out == consts.STRATEGY_CLOSING_OUT)
        vs_ids = [obj.id for obj in closing_objs]
    for vs_id in vs_ids:
        try:
            clear = ClearPosition(vs_id)
            clear.check_position_and_off_line()
        except Exception as e:
            sentry.captureException()
            continue
    sc.close()


@app.task
def auto_daily_dependence_produce(offset, day_night, is_live, id=None, user=None, business=None, node_type=None,
                                  reset_fail=False, max_running=40):
    """
    :param offset: int days from today
    :param day_night: int
    :param is_live: bool
    :param id: int
    :param user: int
    :param business: int 0=future 1=stock
    :param node_type: str
    :param reset_fail: bool reset failed node
    :param max_running: int max worker
    :return:
    """
    tc = TradeCalendar.init_from_kdb(host=config.KDB_HOST, port=config.KDB_PORT, username=config.KDB_USER,
                                     password=config.KDB_PASSWD)
    # 夜盘只在交易日生产
    if day_night == 1 and "today" not in tc:
        return
    date = tc[tc["today"], offset].astype(datetime.datetime).strftime("%Y%m%d")
    dependence_producer.delay(date=date, day_night=day_night, is_live=is_live, user=user, id=id, business=business,
                              node_type=node_type, reset_fail=reset_fail, max_running=max_running)


@app.task
def dependence_producer(date, day_night, is_live=None, id=None, business=None, node_type=None, user=None,
                        max_running=10, reset_fail=False, reset_referrer=False, once=False):
    """
    produce dependence from remote dependence tree

    :param date: str %Y%m%d
    :param day_night: int 0=DAY 1=NIGHT
    :param id: int
    :param business: int 0=future 1=stock
    :param node_type: str
    :param user: int
    :param max_running: int
    :param reset_fail: bool whether reset failed node to created
    :param reset_referrer: bool whether reset the referred node to created
        这个只有传入id和once才会有效
    :param once: bool
    :param is_live:  bool
    :return:
    """
    key = RemoteTree.dependence_tree_key.format(date=date, day_night=str(day_night))
    remote_tree = RemoteTree(key=key, **config.redis)
    if not remote_tree.key_exists():
        remote_tree = dependence_tree_generation(date, day_night)
    else:
        remote_tree.pull()
    # 重置failed节点
    if reset_fail:
        failed = remote_tree.find(status=Task.TaskStatus.Failed.value, id=id)
        for i in failed.index:
            remote_tree.update_node(i, "status", Task.TaskStatus.Failed.value, Task.TaskStatus.Created.value)
        # 只能在第一次调用dependence_producer的时候reset failed node
        reset_fail = False
    # 当某一结点不应该成功,但是成功了,导致该节点和引用这个节点的节点全部不对,全部相关节点强制重置
    # 只支持单一节点
    if isinstance(id, int) and not once and reset_referrer:
        referrer = remote_tree.get_all_reference_node(id)
        for i in referrer:
            remote_tree.update_node_force(i, "status", Task.TaskStatus.Created.value)
        reset_referrer = False

    available = remote_tree.find(id=id, user=user, is_live=is_live, business=business, node_type=node_type,
                                 is_root=False, available_only=True)
    available_num = len(available.index)
    # 无可执行的依赖
    if available_num == 0:
        df = remote_tree.find(id=id, user=user, is_live=is_live, business=business, node_type=node_type, is_root=False)
        # 查看所有任务是否都被执行
        if len(df) == len(
                df[df["status"].isin([Task.TaskStatus.Success.value, Task.TaskStatus.Failed.value])]) and is_live:
            dependence_check.delay(date)
            return "all task successes"
        else:
            return "not find task"
    running_num = len(available[available["status"]
                                == Task.TaskStatus.Running.value])
    # 超过最大可执行任务数量
    if running_num > max_running:
        return
    # 调整相应slice
    available = available.iloc[:(max_running - running_num)]
    todo = []
    for i in available.itertuples(False):
        # 像更新节点状态
        signal = remote_tree.update_node(
            i.id, "status", Task.TaskStatus.Created.value, Task.TaskStatus.Running.value)
        # 要是该节点被别人先更新,就不会下发任务
        if int(signal) == 0:
            continue
        todo.append(i)
    for i in todo:
        queue = choose_task_queue(i.creator, i.id)
        callback = dependence_producer_callback.s(
            strategy_id=i.id, date=date, day_night=day_night, is_live=is_live, id=id, node_type=node_type,
            business=business, user=user, max_running=max_running, reset_fail=reset_fail, reset_referrer=reset_referrer,
            once=once)
        queue_redo_ev_task.apply_async(kwargs={"s_id": i.id, "start_date": date, "end_date": date}, queue=queue,
                                       link=callback)
    return "start " + str(todo)


@app.task
def produce_ev_in_advance(ids, day_night):
    """
    :param ids: str "11,22,33"
    :param day_night: int 0=DAY 1=NIGHT
    :return:
    """
    ids = [int(i) for i in ids.split(",")]
    for i in range(12):
        kdb = KdbQuery()
        s = kdb.get_stock_ev_data_status(datetime.datetime.now().strftime('%Y.%m.%d'), 0)
        if not s:
            notify_operation_wechat('股票夜盘ev生产数据未就绪，延后5分钟')
            time.sleep(300)
        else:
            break
    notify_operation_wechat('股票夜盘ev生产开始执行')
    date = Strategy.get_trading_date()
    for ev_id in ids:
        callback = dependence_producer_callback.s(strategy_id=ev_id, date=date, day_night=day_night, once=True)
        queue_redo_ev_task.apply_async(kwargs={"s_id": ev_id, "start_date": date, "end_date": date}, link=callback)


@app.task
def dependence_producer_callback(result, strategy_id=None, date=None, day_night=None, is_live=None, id=None,
                                 business=None, node_type=None, user=None, max_running=10, reset_fail=False,
                                 reset_referrer=False, once=False):
    with session_context() as sc:
        # 查询成功结果
        result = sc.query(StrategyResult).filter(
            StrategyResult.strategy_id == strategy_id,
            StrategyResult.status != Task.TaskStatus.Failed.value,
            StrategyResult.date == date
        ).first()
    key = RemoteTree.dependence_tree_key.format(date=date, day_night=str(day_night))
    remote_tree = RemoteTree(key=key, **config.redis)
    remote_tree.pull()
    # # 失败
    if result is None:
        # 更新节点状态返回
        remote_tree.update_node(
            strategy_id, "status", Task.TaskStatus.Running.value, Task.TaskStatus.Failed.value)
        return strategy_id, False
    # 更新节点状态
    signal = remote_tree.update_node(strategy_id, "status", Task.TaskStatus.Running.value,
                                     Task.TaskStatus.Success.value)
    # 假如是once或者更新节点状态失败
    if once or int(signal) == 0:
        return strategy_id, once
    # 指定id更新有两种情况,once等于True或者False
    # - True  只要更新该节点,会在上面return
    # - False 更新完该节点,接着查找依赖树中可用的更新
    if id is not None:
        id = None
    dependence_producer.delay(date=date, day_night=day_night, is_live=is_live, id=id, node_type=node_type,
                              business=business, user=user, max_running=max_running, reset_fail=reset_fail,
                              reset_referrer=reset_referrer, once=once)
    return strategy_id, True


@app.task
def dependence_check(date):
    data2 = live_ev_check()
    columns = ['id', 'user_name', 'name', 'short_filename', 'size', 'lines', 'short_last_filename', 'last_size',
               'last_lines']
    df = pd.DataFrame(
        [[v[c] for c in columns]
         for v in sorted(data2.values(), key=lambda d: d['id'])],
        columns=columns
    )

    error_info = []
    live_ev_ids = get_live_ev_ids_cache(cache=False)
    sc = session()
    for ev_id in live_ev_ids:
        sr = sc.query(
            StrategyResult
        ).filter(
            StrategyResult.strategy_id == ev_id,
            StrategyResult.date == date,
            StrategyResult.status == -1
        ).first()
        if sr:
            s = sc.query(Strategy).filter(Strategy.id == ev_id).first()
            error_msg = """<br></br> <br></br>
                ev 生产失败 %s  %s  %s
                """ % (s.id, s.username, sr.detail)
            error_info.append(error_msg)

    sc.close()

    receivers = [
        CompanyEmailGroup.quant_dev,
        CompanyEmailGroup.dto,
        CompanyEmailGroup.ZhouChaoLin,
        CompanyEmailGroup.XuXinXin
    ]

    content = df.to_html() + ''.join(error_info)
    send_email('strategy　ev　daily　check　%s' %
               date, content, receivers, content_type='html')


@app.task
def auto_data_check(trading_date="today", count=0):
    from my.data import status as data_status
    trading_calendar = TradeCalendar.init_from_kdb(**config.kdb_config)
    if trading_date not in trading_calendar:
        return False
    trading_date = trading_calendar[trading_date].astype(datetime.datetime).strftime("%Y%m%d")
    _status = data_status(int(trading_date), 0)
    count += 1
    if _status != 'SUCCESS':
        if count <= 3:
            content = "数据状态检查第%d次失败" % count
            auto_data_check.apply_async(args=(trading_date, count), countdown=1800)
        else:
            content = "数据状态错误，请联系数据组"
        company_platform_wechat_app_send_text_task.delay(content)
        return False
    company_platform_wechat_app_send_text_task.delay("行情数据正常")
    auto_vs_back_test.delay(day=trading_date, business="future")
    auto_vs_back_test.apply_async(kwargs={"day": trading_date, "business": "stock"}, countdown=3600)
    auto_daily_paper_trading_task.delay(trading_date=trading_date, day_night=0, offset=0, include_strategy_type=26)

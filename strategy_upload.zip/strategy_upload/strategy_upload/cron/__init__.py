# -*-coding:utf-8-*-


import os
import sys
from celery import Celery
from constant import CeleryQueueName

app_root = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))

if app_root not in sys.path:
    sys.path.append(app_root)


class Router(object):
    def route_for_task(self, task, args=None, kwargs=None):
        if task.startswith('cron.strategy_upload_task.stock_team_'):
            return {'queue': 'stock_team_cron_task'}
        elif task.startswith('cron.strategy_upload_task.cron_120_'):
            return {'queue': 'cron_120_task'}
        elif task.startswith('cron.strategy_upload_task.cron_140_'):
            return {'queue': 'cron_140_task'}
        elif task.startswith('cron.strategy_upload_task.queue_common'):
            return {'queue': CeleryQueueName.QueueCommon.value}
        elif task.startswith('cron.live_trading_task'):
            return {'queue': 'cron_live_trading_task'}
        elif task.startswith('cron.'):
            return {'queue': CeleryQueueName.CronStrategyUploadTask.value}
        else:
            return {'queue': 'empty'}


app = Celery('background')
app.config_from_object('cron.celeryconfig')
app.conf.update(CELERY_ROUTES=(Router(),))

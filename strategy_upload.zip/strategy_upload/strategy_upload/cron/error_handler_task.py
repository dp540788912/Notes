from cron import app


# def SettlementNegativePositionError_Handler(error):
#
#     callback = WeiXinSettlementCallback(error.data["trading_date"], error.data["day_night"])
#     settlement_position_simulator(error.data["vs_id"], error.data["trading_date"], error.data["day_night"], callback)
#
#
# def SettlementZeroPositionError_Handler(error):
#     from tool_scripts.error_handler_tool import settlement_position_simulator, WeiXinSettlementCallback
#     callback = WeiXinSettlementCallback(error.data["trading_date"], error.data["day_night"])
#     settlement_position_simulator(error.data["vs_id"], error.data["trading_date"], error.data["day_night"], callback)

# @app.task
# def ErrorHandler(error):
#     error_name = error.__class__.__name__
#     if error_name == "SettlementZeroPositionError":
#         SettlementZeroPositionError_Handler(error)
#     elif error_name == "SettlementNegativePositionError":
#         SettlementNegativePositionError_Handler(error)

@app.task
def settlement_error_simulator_task(vs_id, trading_date, day_night, **kwargs):
    from tool_scripts.error_handler_tool import settlement_position_simulator, WeiXinSettlementCallback
    callback = WeiXinSettlementCallback(trading_date, day_night)
    settlement_position_simulator(vs_id, trading_date, day_night, callback)

# -*-coding:utf-8-*-
# -*-coding:utf-8-*-


from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from sqlalchemy import Column, ForeignKey
from sqlalchemy.schema import UniqueConstraint
from sqlalchemy.dialects.mysql import BIGINT, VARCHAR, FLOAT, BOOLEAN, DATETIME, INTEGER, JSON, DOUBLE, TEXT, DATE, TIME

from db import ModelBase


class StrategyUploadFile(ModelBase):
    __tablename__ = 'strategy_upload_file'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=False)
    filename = Column(VARCHAR(255), nullable=False)
    relative_path = Column(VARCHAR(255), nullable=False)
    file_type = Column(VARCHAR(8), nullable=False)


class Strategy(ModelBase):
    __tablename__ = 'strategy'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=False)
    r_update_user_id = Column(INTEGER, nullable=True)
    username = Column(VARCHAR(32), nullable=False)
    name = Column(VARCHAR(255), nullable=False)
    status = Column(INTEGER, nullable=False, default=1)
    description = Column(VARCHAR(255), nullable=True, default="")
    node = Column(VARCHAR(32), nullable=False)
    start_date = Column(VARCHAR(16), nullable=False)
    end_date = Column(VARCHAR(16), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    products = Column(JSON, nullable=False)
    max_pos = Column(INTEGER, nullable=True, default=0)
    dependency = Column(JSON)
    detail = Column(JSON, nullable=False)
    st_uuid = Column(VARCHAR(64), nullable=False)
    code = Column(VARCHAR(4), nullable=False)
    id_no = Column(VARCHAR(32), nullable=False)
    strategy_upload_file_id = Column(INTEGER, nullable=False)
    strategy_type = Column(VARCHAR(4), nullable=True)
    strategy_status = Column(VARCHAR(4), nullable=True)
    strategy_feature = Column(VARCHAR(4), nullable=True)
    strategy_underlying = Column(VARCHAR(4), nullable=True)
    strategy_para_type = Column(VARCHAR(4), nullable=True)
    is_delete = Column(INTEGER, nullable=False, default=0)
    is_test = Column(INTEGER, nullable=False, default=0)
    error = Column(JSON, nullable=True)
    live_time = Column(DATETIME, nullable=True)


class StrategyResult(ModelBase):
    __tablename__ = 'strategy_result'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(INTEGER, index=True)
    date = Column(VARCHAR(16), nullable=False)
    taskdate = Column(VARCHAR(16), nullable=False)  # 多参数任务时会用到
    product = Column(VARCHAR(255), nullable=False)
    paras = Column(JSON, nullable=True)
    pnl = Column(DOUBLE, default=0)
    detail = Column(JSON, nullable=True)
    status = Column(INTEGER, nullable=False, default=1)
    result_file_name = Column(VARCHAR(512), nullable=True)
    done_time = Column(DATETIME, nullable=True)
    redo_times = Column(INTEGER, default=0)


class StrategyPortfolio(ModelBase):
    __tablename__ = 'strategy_portfolio'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(128), nullable=False)
    fund = Column(DOUBLE, nullable=False)
    description = Column(VARCHAR(255), nullable=True)
    status = Column(INTEGER, nullable=False, default=11)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=False)
    r_update_user_id = Column(INTEGER, nullable=True)
    live_time = Column(DATETIME, nullable=True)
    username = Column(VARCHAR(32), nullable=False)
    source = Column(VARCHAR(32), nullable=True)
    vstrategy_obj = relationship('VStrategies', backref='strategy_portfolio', passive_deletes=True)


class VStrategies(ModelBase):
    __tablename__ = 'vstrategies'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    status = Column(INTEGER, default=11)
    portfolio_id = Column(ForeignKey('strategy_portfolio.id', ondelete='CASCADE'))
    strategy_id = Column(INTEGER, nullable=False)
    strategy_weight = Column(DOUBLE, nullable=True, default=0)
    symbols_accounts = Column(JSON, nullable=True)
    source = Column(VARCHAR(32), nullable=True)
    name = Column(VARCHAR(128), nullable=True)


class VwapOrder(ModelBase):
    __tablename__ = 'vwap_orders'

    __table_args__ = (
        UniqueConstraint('parent_order_id', 'trading_date', 'day_night'),
    )
    id = Column(BIGINT(unsigned=True), primary_key=True)
    parent_order_id = Column(VARCHAR(64), nullable=False)
    trading_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    algorithm = Column(VARCHAR(16), nullable=False)


class VwapExecution(ModelBase):
    __tablename__ = 'vwap_executions'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    order_id = Column(BIGINT, nullable=False)
    parent_order_id = Column(VARCHAR(64), nullable=False)
    trading_date = Column(DATE, nullable=False)
    trade_time = Column(TIME, nullable=False)
    internal_date = Column(DATE, nullable=False)
    calendar_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    symbol = Column(VARCHAR(128), nullable=False)
    direction = Column(INTEGER, nullable=False)
    parent_order_size = Column(INTEGER, nullable=False)
    child_order_size = Column(INTEGER, nullable=False)
    exec_size = Column(INTEGER, nullable=False)
    exec_price = Column(DOUBLE, nullable=False)
    order_type = Column(INTEGER, nullable=False)
    vtraded = Column(INTEGER, nullable=False)
    vtarget = Column(INTEGER, nullable=False)
    indicator = Column(FLOAT, nullable=False)
    filename = Column(VARCHAR(256), nullable=True)
    vstrategy_id = Column(BIGINT, nullable=False)
    account = Column(VARCHAR(32), nullable=False)
    user_id = Column(INTEGER, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())


class VwapIndicator(ModelBase):
    __tablename__ = 'vwap_indicators'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    order_id = Column(BIGINT, nullable=False)
    parent_order_id = Column(VARCHAR(64), nullable=False)
    trading_date = Column(DATE, nullable=False)
    trade_time = Column(TIME, nullable=False)
    internal_date = Column(DATE, nullable=False)
    calendar_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    symbol = Column(VARCHAR(128), nullable=False)
    direction = Column(INTEGER, nullable=False)
    bp1 = Column(DOUBLE, nullable=False)
    sp1 = Column(DOUBLE, nullable=False)
    bv1 = Column(INTEGER, nullable=False)
    sv1 = Column(INTEGER, nullable=False)
    first_amt = Column(DOUBLE, nullable=False)
    first_vol = Column(BIGINT, nullable=False)
    amt = Column(DOUBLE, nullable=False)
    vol = Column(BIGINT, nullable=False)
    vtraded = Column(INTEGER, nullable=False)
    vtarget = Column(INTEGER, nullable=False)
    indicator = Column(FLOAT, nullable=False)
    outstanding_qty = Column(BIGINT, nullable=False)
    filename = Column(VARCHAR(256), nullable=True)
    vstrategy_id = Column(BIGINT, nullable=False)
    user_id = Column(INTEGER, nullable=False)
    account = Column(VARCHAR(32), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())


class VwapResult(ModelBase):
    __tablename__ = 'vwap_results'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    order_id = Column(BIGINT, nullable=False)
    parent_order_id = Column(VARCHAR(64), nullable=False)
    vstrategy_id = Column(BIGINT, nullable=False)
    account = Column(VARCHAR(32), nullable=False)
    trading_date = Column(DATE, nullable=False)
    trade_time = Column(TIME, nullable=True)
    day_night = Column(INTEGER, nullable=False)
    symbol = Column(VARCHAR(128), nullable=False)
    direction = Column(INTEGER, nullable=False)
    parent_order_size = Column(INTEGER, nullable=False)
    mkt_vol = Column(BIGINT, nullable=False)
    mkt_duration_vol = Column(BIGINT, nullable=False)
    mkt_duration_vwap = Column(DOUBLE, nullable=False)
    mkt_duration_twap = Column(DOUBLE, nullable=False)
    exec_vwap = Column(DOUBLE, nullable=False)
    vwap_slippage = Column(DOUBLE, nullable=False)
    twap_slippage = Column(DOUBLE, nullable=False)
    start_time = Column(INTEGER, nullable=False)
    end_time = Column(INTEGER, nullable=False)
    passive_rate = Column(FLOAT, nullable=False)
    filled_rate = Column(FLOAT, nullable=False)
    user_id = Column(INTEGER, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    algorithm = Column(VARCHAR(16), nullable=False)


class ParentOrder(ModelBase):
    __tablename__ = 'parent_orders'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    parent_order_id = Column(VARCHAR(64), nullable=False)
    vstrategy_id = Column(BIGINT, nullable=False)
    symbol = Column(VARCHAR(128), nullable=False)
    parent_order_size = Column(INTEGER, nullable=False)
    limit_price = Column(DOUBLE, nullable=False)
    algorithm = Column(INTEGER, nullable=False)  # algorithm: 1-DMA; 2-VWAP; 3-TWAP;
    side = Column(INTEGER, nullable=False)  # 方向 1-buy, 2-sell
    start_time = Column(TIME, nullable=False)
    start_time_ms = Column(INTEGER, nullable=False)
    end_time = Column(TIME, nullable=False)
    end_time_ms = Column(INTEGER, nullable=False)
    timestamp = Column(TIME, nullable=False)
    timestamp_ms = Column(INTEGER, nullable=False)
    internal_date = Column(DATE, nullable=False)
    calendar_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    trading_date = Column(DATE, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())


class ChildrenOrder(ModelBase):
    __tablename__ = 'child_orders'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    child_order_id = Column(VARCHAR(64), nullable=False)
    vstrategy_id = Column(BIGINT, nullable=False)
    parent_order_id = Column(VARCHAR(64), nullable=False)
    child_order_size = Column(INTEGER, nullable=False)
    execution_price = Column(DOUBLE, nullable=False)
    order_type = Column(INTEGER, nullable=False)  # order_type: 1：PASSIVE; 2:AGGRESSIVE;
    indicator = Column(FLOAT, nullable=False)
    timestamp = Column(TIME, nullable=False)
    timestamp_ms = Column(INTEGER, nullable=False)
    internal_date = Column(DATE, nullable=False)
    calendar_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    trading_date = Column(DATE, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())


class TradeHedge(ModelBase):
    __tablename__ = 'tradehedge'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=True)
    date = Column(VARCHAR(16), nullable=False)
    strategy_id = Column(INTEGER, nullable=False)
    symbol = Column(VARCHAR(32), nullable=False)
    hedge_type = Column(VARCHAR(128), nullable=True)
    threshold = Column(VARCHAR(128), nullable=True)
    frequency = Column(VARCHAR(128), nullable=True)


class OrderList(ModelBase):
    __tablename__ = 'orderlist'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=True)
    date = Column(VARCHAR(16), nullable=False)
    strategy_id = Column(INTEGER, nullable=False)
    symbol = Column(VARCHAR(32), nullable=False)
    weight = Column(DOUBLE, nullable=True)
    size = Column(INTEGER, nullable=True)
    limit_price = Column(DOUBLE, nullable=True)
    algo = Column(VARCHAR(16), nullable=False)
    start = Column(VARCHAR(16), nullable=False)
    end = Column(VARCHAR(16), nullable=True)
    hedge_id = Column(INTEGER, nullable=False)


class VStrategyPerfSummary(ModelBase):
    __tablename__ = 'vstrategy_perf_summary'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vstrategy_id = Column(BIGINT, nullable=False)
    trading_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    allocation = Column(DOUBLE, nullable=False)
    pnl = Column(DOUBLE, nullable=False)
    cum_pnl = Column(DOUBLE, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=False)
    r_update_user_id = Column(INTEGER, nullable=True)


class StrategyPerfSummary(ModelBase):
    __tablename__ = 'strategy_perf_summary'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(BIGINT, nullable=False)
    trading_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    allocation = Column(DOUBLE, nullable=False)
    pnl = Column(DOUBLE, nullable=False)
    cum_pnl = Column(DOUBLE, nullable=False)
    net_asset_value = Column(DOUBLE, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=False)
    r_update_user_id = Column(INTEGER, nullable=True)


if __name__ == '__main__':
    from db import engine

    ModelBase.metadata.create_all(engine)

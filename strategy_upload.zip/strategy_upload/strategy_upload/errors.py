import json


class DataNotReadyException(Exception):
    def __init__(self, msg=None):
        if not msg:
            msg = "data not ready yet"
        super().__init__(msg)


class DecoratorNotSupportedError(Exception):
    def __init__(self):
        super().__init__("decorator is not supported by function")


class DefaultErrorFormatter(Exception):
    error_type = None
    error_detail = None

    def __init__(self, **kwargs):
        self.data = kwargs

    def __str__(self):
        return json.dumps(self.data, ensure_ascii=False, sort_keys=True)


class HelperErrorFormatter(DefaultErrorFormatter):
    help = None
    template = "错误类型: %s\n错误详情: %s\n处理方法: %s\n信息:\n%s"

    @classmethod
    def render(cls, msg):
        return cls.template % (cls.error_type, cls.error_detail, cls.help, msg)


class Error(type):
    # keep name unique
    name = {}

    def __new__(cls, name, config, formatter=(HelperErrorFormatter,)):
        if not name.endswith("Error"):
            raise ValueError("`Error` must in name,plaese rename the error")
        if name in cls.name:
            raise KeyError("error name : %s dupliacted" % name)
        err = super().__new__(cls, name, formatter, config)
        cls.name[name] = err
        return err

    def __init__(self, name, config, formatter=(HelperErrorFormatter,)):
        super().__init__(name, config, formatter)


SettlementPositionZeroError = Error("SettlementPositionZeroError", {"error_type": "结算错误", "error_detail": "trade_logs顺序错误", "help": "调整trade_logs数据顺序"})
SettlementNegativePositionError = Error("SettlementNegativePositionError", {"error_type": "结算错误", "error_detail": "trade_logs遗失", "help": "补手动交易记录"})

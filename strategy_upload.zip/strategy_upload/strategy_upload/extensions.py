# -*-coding:utf-8-*-

from concurrent.futures import ProcessPoolExecutor

from statsd import StatsClient
from raven import Client as Sentry

from config import config as cfg

sentry = Sentry(cfg.sentry_dsn)
sentry_mod = Sentry(cfg.sentry_mod)

statsd = StatsClient(host=cfg.statsd['host'], port=cfg.statsd['port'])

executor = ProcessPoolExecutor(4)

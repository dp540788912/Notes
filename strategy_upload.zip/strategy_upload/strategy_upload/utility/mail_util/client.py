import smtplib

from email.utils import parseaddr, formataddr
from email.header import Header
from email.mime.text import MIMEText


class CompanyMail(object):
    def __init__(self, from_addr, password, smtp_server, smtp_server_port):
        self.from_addr = from_addr
        self.password = password
        self.smtp_server = smtp_server
        self.smtp_server_port = smtp_server_port

    @staticmethod
    def addr_formatter(addr):
        name, addr = parseaddr(addr)
        return formataddr((Header(name, "utf-8").encode(), addr))

    def send(self, title, content, to_addrs, content_type="plain", cc=None):
        msg = MIMEText(content, content_type, "utf-8")
        msg["From"] = self.addr_formatter("<{}>".format(self.from_addr))
        to_addrs = [self.addr_formatter("<{}>".format(a)) for a in to_addrs]
        msg["To"] = ",".join(to_addrs)
        if cc is not None:
            Cc = [self.addr_formatter("<{}>".format(a)) for a in cc]
            msg["Cc"] = ",".join(Cc)
            to_addrs.extend(Cc)
        msg["Subject"] = Header(title, "utf-8").encode()
        server = smtplib.SMTP(self.smtp_server, self.smtp_server_port)
        try:
            server.ehlo()
            server.starttls()
            server.ehlo()
            server.login(self.from_addr, self.password)
            server.sendmail(self.from_addr, to_addrs, msg.as_string())
        except Exception as e:
            raise e
        finally:
            server.quit()

from .client import CompanyMail

__all__ = ['CompanyMail']

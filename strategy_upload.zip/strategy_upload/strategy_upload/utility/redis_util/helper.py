import datetime


class RedisCounter(object):
    def __init__(self, rdc, name):
        """
        Redis counter
        :param rdc: basic_lib.redis_util.RedisClient instance
        :param name: counter name
        """
        self.rdc = rdc
        self.name = name

    def get_ex(self):
        raise NotImplementedError

    def reset(self):
        """
        Reset counter to 0
        :return:
        """
        self.rdc.set(name=self.name, value=0, ex=self.get_ex())

    def num(self):
        """
        Get counter num
        :return: Int
        """
        res = self.rdc.get(name=self.name)
        if res is None:
            self.reset()
            return self.num()
        else:
            return int(res.decode('utf-8'))

    def inc(self, amount=1):
        """
        Increase counter by amount
        :param amount: Int
        :return:
        """
        self.rdc.incrby(name=self.name, amount=amount)

    def reach_limit(self, limit):
        """
        True if reach limit
        :param limit: Int
        :return: Boolean
        """
        if self.num() < limit:
            flag = False
        else:
            flag = True
        return flag


class RedisCounterWithinDay(RedisCounter):
    def __init__(self, rdc, name):
        super().__init__(rdc, name)

    def get_ex(self):
        now = datetime.datetime.now()
        tomorrow = now + datetime.timedelta(days=1)
        tonight = datetime.datetime(year=tomorrow.year, month=tomorrow.month, day=tomorrow.day)
        return int(tonight.timestamp() - now.timestamp())


class RedisLock(object):
    def __init__(self, rdc, name):
        self.rdc = rdc
        self.key = name

    def is_lock(self):
        return self.rdc.exists(self.key) == 1

    def lock(self, value="", ex=None):
        if ex is not None:
            res = self.rdc.set(self.key, value, ex=ex)
        else:
            res = self.rdc.set(self.key, value)
        return res is not None

    def unlock(self):
        return self.rdc.delete(self.key) == 1

import time
from basic_lib.common_util import singleton
from basic_lib.redis_util import RedisClient, RedisCounterWithinDay, RedisLock

TEST_REDIS_CONFIG = {
    'host': '192.168.1.14',
    'port': '6379',
    'db': 15
}


@singleton
class TestRedisClient(RedisClient):
    def __init__(self):
        super().__init__(TEST_REDIS_CONFIG)


def test_counter():
    rdc = TestRedisClient()
    counter_name = 'counter:test_counter'
    counter = RedisCounterWithinDay(rdc=rdc, name=counter_name)
    counter.inc(1)
    assert counter.num() == 1
    counter.reset()
    assert counter.num() == 0
    counter.inc()
    assert counter.num() == 1
    limit = 2
    assert counter.reach_limit(limit) == False
    counter.inc(2)
    assert counter.num() == 3
    assert counter.reach_limit(limit) == True


def test_lock():
    rdc = TestRedisClient()
    lock_name = "lock:test_lock"
    lock = RedisLock(rdc=rdc, name=lock_name)
    assert lock.is_lock() == False
    assert lock.lock() == True
    assert lock.is_lock() == True
    assert lock.unlock() == True
    assert lock.is_lock() == False
    ex = 5
    assert lock.lock(ex=ex)
    assert lock.is_lock() == True
    time.sleep(ex)
    assert lock.is_lock() == False


if __name__ == '__main__':
    # test_counter()
    # test_lock()
    pass

import redis


class RedisClient(redis.Redis):
    def __init__(self, redis_config_dict):
        self.pool = redis.ConnectionPool(**redis_config_dict)
        super().__init__(connection_pool=self.pool)

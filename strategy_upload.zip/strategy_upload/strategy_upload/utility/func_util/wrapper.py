from tornado.ioloop import IOLoop
from tornado.gen import Future


def async_celery_call(func, *args, **kwargs):
    def _on_result(future, async_result):
        if async_result.ready():
            future.set_result(async_result.result)
        else:
            IOLoop.instance().add_callback(_on_result, future, async_result)

    f = Future()
    r = func.delay(*args, **kwargs)
    IOLoop.instance().add_callback(_on_result, f, r)
    return f


def multi_sort(lst, specs):
    """
    multiple sort of list which can specify different reverse order for each key
    :param lst: list of dicts, [{},{},...]
    :param specs: tuple of tuples, ((), (), ...), inside tuple (dict_key, default, reverse_flag)
    :return: sorted list
    """
    for key, default, reverse in reversed(specs):
        lst.sort(key=lambda x: x.get(key, default), reverse=reverse)
    return lst


def multi_sort_test():
    objs = [
        {
            'name': 'john',
            'grade': 'A',
            'age': 15
        },
        {
            'name': 'jane',
            'grade': 'B',
            'age': 12
        },
        {
            'name': 'dave',
            # 'grade': 'B',
            'age': 10
        },
    ]
    print(multi_sort(objs, (('grade', 'A', True), ('age', 9, False))))


if __name__ == '__main__':
    # multi_sort_test()
    pass

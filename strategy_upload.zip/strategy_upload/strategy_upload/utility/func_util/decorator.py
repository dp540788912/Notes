import time
from functools import wraps
from collections import OrderedDict


def check_market_data_status(f):
    """
    check if data is available. "date" param should be either the first param or included in **kwargs
    Parameters
    ----------
    Returns
    -------

    """
    def decorator(*args, **kwargs):
        from errors import DataNotReadyException
        try:
            date = None
            for k in kwargs:
                if "date" in k:
                    date = kwargs.get(k)
                    break
            if not date:
                date = args[0]

            from my.data import status as data_status
            _status = data_status(int(date), 0)
            if _status.lower() != "success":
                raise DataNotReadyException
        except Exception as e:
            if not isinstance(e, DataNotReadyException):
                print("warning: decorator is not supported")
                return f(*args, **kwargs)
            else:
                raise e

        return f(*args, **kwargs)
    return decorator


def retry(retries=3, delay=1, multi=2, timeout=10):
    """
    function
    --------
    retry a function "retries" times every "delay" time until total time reaches timeout

    Parameters
    ----------
    retries: max times of retrying the function
    delay: delay between retries in seconds
    multi: multiplier of delay
    timeout: Stop retry when timeout is reached
    Returns: decorator
    -------

    """

    def decorator(f):
        @wraps(f)
        def inner(*args, **kwargs):
            start_time = time.time()
            m_retry, m_delay = retries, delay
            while m_retry > 0 and (time.time() - start_time <= timeout):

                try:
                    return f(*args, **kwargs)
                except Exception as e:
                    print("retry in {} seconds because of {}".format(m_delay, e.__repr__()))
                    time.sleep(m_delay)
                    m_retry -= 1
                    m_delay *= multi

            return f(*args, **kwargs)
        return inner

    return decorator


def singleton(cls):
    instances = {}

    def _singleton(*args, **kw):
        if cls not in instances:
            instances[cls] = cls(*args, **kw)
        return instances[cls]

    return _singleton


def record_time(func):
    @wraps(func)
    def inner(*args, **kwargs):
        before = time.time()
        rs = func(*args, **kwargs)
        after = time.time()
        print("TIME SPEND:", after - before)
        return rs

    return inner


def login_required(func):
    @wraps(func)
    def inner(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return
        return func(self, *args, **kwargs)

    return inner


class FixSizeOrderedDict(OrderedDict):
    def __init__(self, *args, max=0, **kwargs):
        self._max = max
        super().__init__(*args, **kwargs)

    def __setitem__(self, key, value):
        OrderedDict.__setitem__(self, key, value)
        if self._max > 0:
            if len(self) > self._max:
                self.popitem(False)


def TradingDateTTLCache(ttl, cache_size=10, refresh=True):
    """
    用于缓存交易日信息的专用cache
    缓存过期条件:
        1. 传入的trading_date和day_night不一样
        2. ttl过期
    使用方法:
        被装饰的函数或者class trading_date,day_night必须以kwargs的形式传入

    :param ttl: int
    :return:
    """

    def wrapper(func):
        cache = FixSizeOrderedDict(max=cache_size)
        cache_ts = FixSizeOrderedDict(max=cache_size)

        @wraps(func)
        def _wrapper(*args, **kwargs):
            now = int(time.time())
            trading_date = kwargs.get("trading_date", "")
            day_night = kwargs.get("day_night", 0)
            daynight = kwargs.get("day_night", "")
            key = str(trading_date) + str(day_night) + str(daynight)
            if key not in cache:
                val = func(*args, **kwargs)
                cache[key] = val
                cache_ts[key] = now
                return val
            old = cache[key]
            if now - cache_ts.get(key, 0) > ttl:
                if refresh and hasattr(old, "refresh"):
                    old.refresh()
                else:
                    cache[key] = func(*args, **kwargs)
                cache_ts[key] = now
            return cache[key]

        return _wrapper

    return wrapper

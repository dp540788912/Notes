from qpython.qconnection import QConnection
import datetime
import time
import numpy as np
import unittest


class KDBConnection(QConnection):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def query(self, sql, async_query=True, data_only=True, raw=False, numpy_temporals=True):
        msg_t = 0 if async_query else 1
        super().query(msg_t, sql)
        data = self.receive(data_only=data_only, raw=raw, numpy_temporals=numpy_temporals)
        return data

    def query_safe(self, sql, retry=3, interval=1):
        i = 0
        while not self.is_connected():
            time.sleep(interval)
            self.open()
            i += 1
            if i > retry:
                raise RuntimeError("can not connect to %s:%s" % (str(self.host), str(self.port)))
        return self.query(sql)


# TODO
class KDBConnectionPool:
    def __init__(self):
        pass


class TradeCalendar:
    """
    Trade Calendar

    Usage:
    1.
        1.1 init calendar from specific data which must be numpy.ndarray[numpy.datetime64]
        ```
        calendar = TradeCalendar(data)
        ```
        1.2 init calendar from kdb
        ```
        calendar = TradeCalendar.init_from_kdb(host,port,username,password)
        ```
    2. assert date is in trade calendar
        ```
        calendar.is_trading_date(date)
        ```
        or
        ```
        date in calendar
        ```
    3. calculate trade day
        3.1 get next day
        ```
        calendar.trading_date_calc(date, 1)
        ```
        or
        ```
        calendar[date, 1]
        ```
        3.2 get previous day
        ```
        calendar.trading_date_calc(date, -1)
        ```
        or
        ```
        calendar[date, -1]
        ```
    4. trade day range
        calendar[date:date]

    NOTE: param `date` support types below
        1. datetime.datetime.date
        2. np.datetime64
        3. str %Y-%m-%d | 'today'
    """

    def __init__(self, data):
        """
        :param data: np.ndarray[np.datetime64]
        """
        self.data = data

    def is_trading_date(self, date="today"):
        """
        check whether date is in trading calendar

        :param date: Union[datetime.datetime,np.datetime64,str]
        :return: np.datetime64
        """
        date = self.format_date(date)
        return date in self.data

    def trading_date_calc(self, date, offset, strict=False):
        """
        calc date offset

        :param date: Union[datetime.datetime,np.datetime64,str] base date
        :param offset: int
        :param strict: bool
            check whether date and target date is in trade calendar
        :return: np.datetime64
        """
        date = self.format_date(date)
        idx = self.trading_date_idx(date, strict=strict)
        if idx == -1:
            return None
        cur = idx + offset
        if cur < 0 or cur > len(self.data):
            if strict:
                raise ValueError("calendar index error")
            else:
                return None
        return self.data[cur]

    def trading_date_idx(self, date="today", strict=False):
        """
        find date idx in calendar

        :param date: Union[datetime.datetime,np.datetime64,str] base date
        :param strict: bool
            check whether date not in trade calendar , if strict raise error , else return -1
        :return: int
        """
        date = self.format_date(date)
        idx = np.argwhere(self.data == date)
        if len(idx) != 1:
            if strict:
                raise ValueError("can not find trading date: %s in calendar" % str(date))
            else:
                return -1
        return idx[0][0]

    def get_nearest_trading_date(self, date="today"):
        """
        return next nearest trading day if today is not in calendar else return today

        :param date: Union[datetime.datetime,np.datetime64,str]
        :return:
        """
        date = self.format_date(date)
        for i in self.data:
            if i >= date:
                return i
        raise ValueError("can not find nearest trading day in calendar")

    def get_next_trading_date(self, date="today"):
        """
        if date is trading day return next trading day, else return nearest trading date

        :param date:
        :return: np.datetime64
        """
        date = self.format_date(date)
        if not self.is_trading_date(date):
            return self.get_nearest_trading_date(date)
        else:
            return self[date, 1]

    def get_prev_trading_date(self, date="today"):

        date = self.get_nearest_trading_date(date)
        return self[date, -1]

    def date_range(self, start, end, date_format="", strict=False):
        """
        select a range of date in trading calendar

        :param start: Union[datetime.datetime,np.datetime64,str]
        :param end: Union[datetime.datetime,np.datetime64,str]
        :param date_format: str
        :param strict: bool
            if start date or end date not in trading calendar will return None,
            else choosing nearest trading to replace old value
        :return:
        """
        start = self.trading_date_idx(self[start]) if not strict else self.trading_date_idx(start, strict)
        end = self.trading_date_idx(self[end]) if not strict else self.trading_date_idx(end, strict)
        if start == -1 or end == -1:
            return None
        if date_format:
            return [i.astype(datetime.datetime).strftime(date_format) for i in self.data[start:end]]
        else:
            return self.data[start:end]

    @staticmethod
    def format_date(date):
        if isinstance(date, np.datetime64):
            return date
        if isinstance(date, str):
            if len(date) == 8 and date.isnumeric():
                date = date[0:4] + "-" + date[4:6] + "-" + date[6:]
        elif isinstance(date, datetime.datetime):
            date = datetime.date()
        return np.datetime64(date)

    def __getitem__(self, item):
        if isinstance(item, int):
            return self.data[item]
        elif isinstance(item, slice):
            return self.date_range(item.start, item.stop)
        elif isinstance(item, (str, datetime.date, datetime.datetime, np.datetime64)):
            return self.get_nearest_trading_date(item)
        elif isinstance(item, tuple):
            return self.trading_date_calc(item[0], item[1])
        else:
            raise KeyError("unsupported type %s" % (str(type(item))))

    def __contains__(self, item):
        return self.is_trading_date(item)

    def __len__(self):
        return len(self.data)

    def __iter__(self):
        return self.data

    def __str__(self):
        return self.data.__str__()

    def __repr__(self):
        return self.data.__repr__()

    @classmethod
    def init_from_kdb(cls, *args, start=None, end=None, **kwargs):
        """

        :param args:  `KDBConnection` params
        :param start: str preset param, no use right now
        :param end: str preset param, no use right now
        :param kwargs:  `KDBConnection` kwargs
        :return:
        """
        q = """.gw.asyncexec["select TRADE_DT from Calendar where EXCHANGE=`SSE, TRADE_DT>=2017.01.01";`FuturesBasicInfo]"""
        conn = KDBConnection(*args, **kwargs)
        with conn:
            result = conn.query(q)
        return cls(result["TRADE_DT"])


# 这个测试用例不知道写哪里，我就先写着，以后有统一的test文件夹，再搬 by chenyijian
class TestTradeCalendar(unittest.TestCase):
    def setUp(self):
        base = np.datetime64("today")
        data = np.array([base + np.timedelta64(i, "D") for i in range(-150, 150) if i != 120], dtype=np.datetime64)
        self.off_day = base + np.timedelta64(120, "D")
        self.calendar = TradeCalendar(data)

    def test_is_trading_date(self):
        today = self.calendar.format_date("today")
        self.assertTrue(self.calendar.is_trading_date(today))
        self.assertFalse(self.calendar.is_trading_date(self.off_day))
        self.assertTrue(today in self.calendar)
        self.assertFalse(self.off_day in self.calendar)

    def test_trading_date_calc(self):
        today = self.calendar.format_date("today")
        tomorrow = today + np.timedelta64(1, "D")
        yesterday = today - np.timedelta64(1, "D")
        self.assertTrue(self.calendar.trading_date_calc(today, 1) == tomorrow)
        self.assertTrue(self.calendar.trading_date_calc(today, -1) == yesterday)
        self.assertTrue(self.calendar[today, 1] == tomorrow)
        self.assertTrue(self.calendar[today, -1] == yesterday)

    def test_trading_date_range(self):
        start_date = self.calendar[0]
        end_date = self.calendar[-1]
        result = self.calendar[start_date:end_date]
        for i in range(len(result)):
            a = result[i]
            b = self.calendar[i]
            self.assertTrue(a == b)

    def test_get_nearest_trading_date(self):
        today = self.calendar.format_date("today")
        self.assertTrue(self.calendar.get_nearest_trading_date(today) == today)

    def test_get_next_trading_date(self):
        today = self.calendar.format_date("today")
        next_trading_date = self.calendar.get_next_trading_date(today)
        # check case :  today is trading day
        self.assertTrue(self.calendar[today, 1] == next_trading_date)
        # check case :  today is not trading day
        self.assertTrue(
            self.calendar.get_next_trading_date(self.off_day) == self.calendar.get_nearest_trading_date(self.off_day))


if __name__ == '__main__':
    # unittest.main()
    pass

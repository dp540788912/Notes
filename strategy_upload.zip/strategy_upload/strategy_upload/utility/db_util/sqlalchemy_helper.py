def migrate(base_model, engine, model=None):
    if model is None:
        base_model.metadata.create_all(engine)
    else:
        model.__table__.create(engine, checkfirst=True)

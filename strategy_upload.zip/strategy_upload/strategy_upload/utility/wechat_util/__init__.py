from .client import CompanyWeChatAPP

__all__ = ['CompanyWeChatAPP']

import requests


class CompanyWeChatAPP(object):
    TOKEN_URL = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid={}&corpsecret={}"
    MSG_URL = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token={}"

    def __init__(self, agent_id, corp_id, secret, to_users=None, to_parties=None, to_tags=None,
                 redis_client=None):
        self.agent_id = agent_id
        self.corp_id = corp_id
        self.secret = secret
        self.to_users = to_users
        self.to_parties = to_parties
        self.to_tags = to_tags
        self.redis_client = redis_client

    def token_url(self):
        return self.TOKEN_URL.format(self.corp_id, self.secret)

    def msg_url(self, token):
        return self.MSG_URL.format(token)

    def format_receivers(self, to_users=None, to_parties=None, to_tags=None):
        users = to_users or self.to_users
        parties = to_parties or self.to_parties
        tags = to_tags or self.to_tags

        users = "|".join(users) if users else ""
        parties = "|".join(parties) if parties else ""
        tags = "|".join(tags) if tags else ""
        return users, parties, tags

    def get_token(self):
        key = "CompanyWeChatAPP:get_token:{agent_id}".format(agent_id=self.agent_id)
        if self.redis_client:
            token = self.redis_client.get(key)
            if token:
                return str(token, 'utf-8')

        res = requests.get(self.token_url())
        if res.status_code == 200:
            token = res.json().get("access_token", None)
            if token and self.redis_client:
                self.redis_client.set(key, token, 3600)
            return token

        return None

    @staticmethod
    def post(msg_url, payload):
        response = requests.post(msg_url, json=payload)
        if response.status_code == 200:
            json_data = response.json()
            if json_data['errcode'] == 0:
                return True
        return False

    def send_text(self, text, to_users=None, to_parties=None, to_tags=None):
        token = self.get_token()
        if token:
            msg_url = self.msg_url(token)
            to_users, to_parties, to_tags = self.format_receivers(to_users, to_parties, to_tags)
            if any([to_users, to_parties, to_tags]):
                payload = {
                    "touser": to_users,
                    "toparty": to_parties,
                    "totag": to_tags,
                    "msgtype": "text",
                    "agentid": self.agent_id,
                    "text": {
                        "content": text
                    },
                    "safe": "0"
                }
                return self.post(msg_url, payload)
        return False

    def send_article(self, title, url, desc="", pic_url="", to_users=None, to_parties=None, to_tags=None):
        token = self.get_token()
        if token:
            msg_url = self.msg_url(token)
            to_users, to_parties, to_tags = self.format_receivers(to_users, to_parties, to_tags)
            if any([to_users, to_parties, to_tags]):
                payload = {
                    "touser": to_users,
                    "toparty": to_parties,
                    "totag": to_tags,
                    "msgtype": "news",
                    "agentid": self.agent_id,
                    "news": {
                        "articles": [
                            {
                                "title": title,
                                "description": desc,
                                "url": url,
                                "picurl": pic_url
                            }
                        ]
                    },
                    "safe": "0"
                }
                return self.post(msg_url, payload)
        return False

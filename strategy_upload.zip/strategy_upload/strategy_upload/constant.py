import os

from enum import Enum, IntEnum


# user role
class UserRoleConstant(Enum):
    Manager = "manager"
    TraderStock = "trader_stock"
    TraderFuture = "trader_future"
    Empty = ""


# user group constant
class UserGroupConstant(Enum):
    AllBusiness = 39
    StockTrader = 41
    FutureTrader = 42
    Manager = 55

    @classmethod
    def stock_group(cls):
        return (
            cls.StockTrader.value,
        )

    @classmethod
    def future_group(cls):
        return (
            cls.FutureTrader.value,
        )

    @classmethod
    def manager_group(cls):
        return (
            cls.Manager.value,
            cls.AllBusiness.value
        )


# hedge benchmark
class HedgeBenchmark(Enum):
    NoHedge = ''
    IF = 'IF'
    IC = 'IC'
    IH = 'IH'
    HS300 = 'HS300'
    ZZ500 = 'ZZ500'
    SZ50 = 'SZ50'
    H00300 = 'H00300'
    H00905 = 'H00905'
    H00016 = 'H00016'
    MarginHedgeList = 'MarginHedgeList'

    @classmethod
    def name_zh_dict(cls):
        dct = {
            cls.NoHedge.value: '无 (不对冲)',
            cls.IF.value: 'IF 主力合约',
            cls.IC.value: 'IC 主力合约',
            cls.IH.value: 'IH 主力合约',
            cls.HS300.value: '沪深300指数',
            cls.ZZ500.value: '中证500指数',
            cls.SZ50.value: '证50指数',
            cls.H00300.value: '沪深300全收益指数',
            cls.H00905.value: '中证500全收益指数',
            cls.H00016.value: '上证50全收益指数',
            cls.MarginHedgeList: '融券对冲清单'
        }
        return dct


# hedge type
class HedgeType(Enum):
    NoHedge = ''
    Position = 'position'
    Full = 'full'
    Beta90 = 'beta_90'
    Live = 'live_{vs_id}'

    @classmethod
    def name_zh_dict(cls):
        dct = {
            cls.NoHedge.value: '无',
            cls.Position.value: '按仓位',
            cls.Full.value: '全资金',
            cls.Beta90.value: '90%资金',
            cls.Live.value: '按实盘成交',
        }
        return dct


# celery queue name
class CeleryQueueName(Enum):
    QueueDefault = 'queue_default'  # for beat and task distribution, worker on 116
    QueueCommon = 'queue_common'  # worker on 60, 116, 149
    QueueStock = 'queue_stock'  # worker on 60, 116, 149
    QueueStockFactor = 'queue_stock_factor'  # worker on 140, 149
    QueueFuture = 'queue_future'  # worker on 120

    StockTeam60EvTask = 'stock_team_60_ev_task'  # 60
    StockTeamCronTask = 'stock_team_cron_task'  # 116
    CronStrategyUploadTask = 'cron_strategy_upload_task'  # 116
    Cron120Task = 'cron_120_task'  # 120
    Cron140Task = 'cron_140_task'  # 140
    StockTeamFactorTask = 'stock_team_factor_task'  # 149

    @classmethod
    def gup_task_queues(cls):
        return [
            cls.StockTeamCronTask.value,
            cls.StockTeamFactorTask.value,
            cls.StockTeam60EvTask.value
        ]

    @classmethod
    def factor_task_queues(cls):
        return [
            cls.Cron140Task.value,
            cls.StockTeamFactorTask.value
        ]


# Trading Time Range
class TradingTimeRange(Enum):
    Day = 0
    Night = 1


# API Response Code
class APIResponseCode(Enum):
    OK = 0
    DefaultError = -1


# stock factor evaluation queue event
class StockFactorEvaluationQueueEvent(Enum):
    Simulator = 'Simulator'
    CheckFactorDirection = 'CheckFactorDirection'
    Papertrading = 'Papertrading'
    JudgeCheck = 'JudgeCheck'


# Company Users
class CompanyUser(object):
    ZhangLong = {
        'id': 34
    }
    JiangMingMing = {
        'id': 71
    }
    ZengYi = {
        'id': 76
    }
    HuangChunChun = {
        'id': 407
    }
    HuaJian = {
        'id': 453
    }
    WuTianHao = {
        'id': 609
    }
    PanYiHui = {
        'id': 698
    }
    WuGangHui = {
        'id': 706
    }
    GuiYaNan = {
        'id': 708
    }

    @classmethod
    def future_team_user_ids(cls):
        return [28, 29, 83, 38, 71, 487, 501]

    @classmethod
    def gpu_user_ids(cls):
        return [453, 407, 698]

    @classmethod
    def stock_team_user_ids(cls):
        return [453, 407, 34, 609, 698]

    @classmethod
    def factor_user_ids(cls):
        return [688, 692, 693, 694, 695, 696, 639, 708, 706]

    @classmethod
    def cron_strategy_upload_task_user_ids(cls):
        return [38, 71, 501, 100, 76, 83, 487]

    @classmethod
    def stock_ev_user_ids(cls):
        return list(set(cls.stock_team_user_ids() + cls.factor_user_ids() + [18, 76]))


# common path
class CommonPath(object):
    beegfs_platform = '/mnt/beegfs_platform'
    beegfs_dev = '/mnt/beegfs_dev'
    beegfs_npq107 = '/mnt/beegfs_npq107'
    jupyter_user_work_space = '/home/rss/jupyter_userworkspace/'
    beegfs_dev_storage_r = os.path.join(beegfs_dev, 'storage_r')
    stock_group_share = os.path.join(beegfs_dev_storage_r, 'stock_group_share')
    media = os.path.join(beegfs_platform, 'media')
    portfolio_optimization_ev = os.path.join(media, 'portfolio_optimization_ev')
    portfolio_optimization_ev_share = os.path.join(stock_group_share, 'portfolio_optimization_ev')
    strategy_upload = os.path.join(media, 'strategy_upload')
    strategy_output = os.path.join(strategy_upload, 'output')
    strategy_vwap_performance = os.path.join(strategy_upload, 'vwap_performance')
    ev_alpha_evaluation = os.path.join(beegfs_npq107, 'ev_alpha_evalue')
    new_factor_evaluation = os.path.join(ev_alpha_evaluation, 'new_factor_evalue')
    stock_factor_graph = os.path.join(media, 'stock_factor_graph')
    stock_factor_daily_summary_pnl = os.path.join(new_factor_evaluation, 'daily_summary_pnl')
    stock_factor_pool_pnl = os.path.join(new_factor_evaluation, 'factor_pool_pnl')
    stock_factor_pool_manual_pnl = os.path.join(new_factor_evaluation, 'factor_pool_manual_pnl')


# Company Mail Setting
class CompanyMailSetting(object):
    rss = {
        'from_addr': 'rss@mycapital.net',
        'password': 'Mycapital0427',
        'smtp_server': 'smtp.qiye.163.com',
        'smtp_server_port': 25,
    }


# Company WeChat APP Setting
class CompanyWeChatAPPSetting(object):
    corp_id = 'ww7c9916c2f31d5aa4'
    company_platform = {
        'agent_id': 1000003,
        'secret': 'EIXZMCl-lX4jsyJRTjfYOmQksySB3UeZkJiczOh5Ulo',
        'corp_id': corp_id,
        'to_tags': ['12'],
        'to_parties': [],
        'to_users': [],
    }
    quant_dev = {
        'agent_id': 1000017,
        'secret': 'rzb_y7KF-CEkQo_QKf8_qcL1DD_N1jEqDoC5mO-baNY',
        'corp_id': corp_id,
        'to_tags': ['5'],
        'to_parties': [],
        'to_users': [],
    }
    quant_dev_test = {
        'agent_id': 1000018,
        'secret': 'H1AxRa7OXLwLROw6zBMtlb9SSFB-yYpIq3o4l1P3MZE',
        'corp_id': corp_id,
        'to_tags': ['6'],
        'to_parties': [],
        'to_users': [],
    }
    quant_ops = {
        'agent_id': 1000019,
        'secret': 'dK4oPjeOI9iPAhIpLzjLfW94xpcH6xH5qGDJTsnqz28',
        'corp_id': corp_id,
        'to_tags': ['7'],
        'to_parties': [],
        'to_users': [],
    }


# Company WeChat account
class CompanyWeChatAccount(object):
    quant_ops = ['LiZhiBingsandy', 'rice', 'JiangBo', 'Hubo', 'Feng']
    quant_dev = ['jpmike', 'YingYongWuBiDeDaJianGe']


# Company email group
class CompanyEmailGroup(object):
    base = '{}@mycapital.net'
    quant_dev = base.format('quant_dev')
    quant_dev_test = base.format('quant_dev_test')
    quant_ops = base.format('quant_ops')
    data_team = base.format('Data_team')
    dto = base.format('dto')
    ZhouChaoLin = base.format('zhouchaolin')
    XuXinXin = base.format('laurence_xu')
    LiShaoFeng = base.format('lishaofeng')
    HuBo = base.format('hubo')
    LuoYang = base.format('luoyang')
    ZengDan = base.format('rice')


# field enum for table strategy_event_track
class StrategyEventTrackConstant(object):
    class Event(Enum):
        AddStrategyBackTest = 'AddStrategyBackTest'
        PrepareStrategyTask = 'PrepareStrategyTask'
        BackTestDepCheck = 'BackTestDepCheck'
        SendStrategyTask = 'SendStrategyTask'
        RelayStrategyBackTest = 'RelayStrategyBackTest'
        StopStrategyBackTest = 'StopStrategyBackTest'
        RedoStrategyBackTest = 'RedoStrategyBackTest'
        AddEvTask = 'AddEvTask'
        AutoStrategyPaperTrading = 'AutoStrategyPaperTrading'
        EvDepCheck = 'EvDepCheck'
        FactorDepCheck = 'FactorDepCheck'
        AutoVsBackTest = 'AutoVsBackTest'
        PrepareVsTask = 'PrepareVsTask'
        SendVsTask = 'SendVsTask'

    class Status(Enum):
        Fail = -1
        Success = 0

    class DetailError(Enum):
        EVDependenceNotReady = 'ev dependence not ready'
        FactorDependenceNotReady = 'factor dependence not ready'


# field enum for table stock_factor_strategy
class StockFactorStrategyConstant(object):
    class FactorType(Enum):
        FactorAlpha = 'FACTOR_ALPHA'
        FactorInDay = 'FACTOR_INDAY'

    class Category(Enum):
        Basic = 'BASIC'
        Normal = 'NORMAL'

    class Status2(Enum):
        Upload = 'Upload'
        Pool = 'Pool'

    class Status(Enum):
        Upload = 'Upload'
        Judged = 'Judged'
        Pool = 'Pool'


# field enum for table strategy
class StrategyConstant(object):
    class StrategyType(Enum):
        Stock = '02'
        StockAlpha = '15'
        StockLongOnly = '16'
        StockShortOnly = '17'
        StockT0 = '18'
        StockAlphaHedgeStrategy = '20'
        StockFactor = '26'
        HKStockAlpha = '27'
        HKStockT0 = '28'
        MergeTrade = '31'
        StockMasterTrade = '33'
        JointSimulationStrategy = '34'

        @classmethod
        def alpha_stock_group(cls):
            return [
                cls.StockAlpha.value,
                cls.HKStockAlpha.value,
                cls.StockMasterTrade.value
            ]

        @classmethod
        def stock_group(cls):
            return [
                cls.Stock.value,
                cls.StockAlpha.value,
                cls.StockLongOnly.value,
                cls.StockShortOnly.value,
                cls.StockT0.value,
                cls.StockAlphaHedgeStrategy.value,
                cls.StockFactor.value,
                cls.HKStockAlpha.value,
                cls.HKStockT0.value,
                cls.StockMasterTrade.value,
                cls.JointSimulationStrategy.value
            ]

        @classmethod
        def stock_not_factor_group(cls):
            return [
                cls.Stock.value,
                cls.StockAlpha.value,
                cls.StockLongOnly.value,
                cls.StockShortOnly.value,
                cls.StockT0.value,
                cls.StockAlphaHedgeStrategy.value,
                cls.HKStockAlpha.value,
                cls.HKStockT0.value,
                cls.StockMasterTrade.value,
                cls.JointSimulationStrategy.value
            ]

    class Status(Enum):
        STOPPED = -2
        FAILED = -1
        FINISHED = 0
        RUNNING = 1
        NEW = 2

    class Node(Enum):
        EV = 'ev'
        OrderList = 'order_list'
        BackTest = 'back_test'
        Group = 'group'
        CashManager = 'cash_manager'
        TradeMasterOrderList = 'trademaster_order_list'
        UnionSimu = 'union_simu'

    class DetailAlgorithm(Enum):
        Manual = 'manual'
        Fundamental = 'fundamental'
        Genetic = 'genetic'
        DeepLearning = 'deep-learning'
        Other = 'other'
        ZZ500 = 'ZZ500'
        AlphaFactorCombination = 'AlphaFactorCombination'

        @classmethod
        def all(cls):
            return [ele.value for ele in cls]

        @classmethod
        def manual_group(cls):
            return [cls.Manual.value,
                    cls.Fundamental.value]

        @classmethod
        def zz500_group(cls):
            return [cls.ZZ500.value]

    class DetailLogLevel(Enum):
        Production = 1
        Debug = 2


def strategy_constant_test():
    assert 'StockAlpha' == StrategyConstant.StrategyType.StockAlpha.name
    assert '15' == StrategyConstant.StrategyType.StockAlpha.value


# field enum for table strategy_portfolio
class StrategyPortfolioConstant(object):
    class Business(Enum):
        Stock = "stock"
        Future = "future"
        Empty = ""

        @classmethod
        def all(cls):
            return [ele.value for ele in cls]


# field enum for table vstrategies
class VStrategiesConstant(object):
    class Status(Enum):
        Delete = -1
        ToBeDeploy = 13
        ToBeConfig = 14
        Live = 15
        OffShelf = 16
        ClosingOut = 17

        @classmethod
        def normal_status(cls):
            return [
                cls.ToBeDeploy.value,
                cls.ToBeConfig.value,
                cls.Live.value,
                cls.OffShelf.value
            ]


# field enum for table settlement_manual_tradelogs
class SettlementManualTradeLogConstant(object):
    class EntrustNo(Enum):
        Manual = 111111111
        T0Auto = 888888888


def vstrategies_constant_test():
    assert 'Delete' == VStrategiesConstant.Status.Delete.name
    assert -1 == VStrategiesConstant.Status.Delete.value


# assemble redis key here
class RedisKeyConstant(Enum):
    Test = "test:{}"

    LiveStockVSPositionAbstractInfo = "LiveStockVSPositionAbstractInfo:{vs_id}_{account}"

    # factor evaluation
    FactorSimulatorStatus = "factor_simulator_status_{factor_id}"
    FactorPaperTradingStatus = "factor_papertrading_status_{factor_id}"
    FactorJudgeCheckStatus = "factor_judge_check_status_{factor_id}"
    StockFactorEvaluationQueue = "stock_factor_evaluation_queue"

    # live server command queue
    OssACmd = "oss:a:cmd:{server_ip}"
    TestOssACmd = Test.format(OssACmd)

    # redis key storing the future account risk data
    # related class: FutureRiskHandler
    redis_future_risk_key = "a:oss:turing:account_complete"
    redis_account_key = "a:oss:turing:position_complete"

    # self trade monitor info
    SelfTradeMonitorInfo = "self_trade_monitor_info:{trading_date}"


class Task:
    class TaskStatus(IntEnum):
        Error = -2
        Failed = -1
        Created = 0
        Ready = 1
        Pending = 2
        Waiting = 3
        Running = 4
        Success = 5
        Stopping = 6
        Stopped = 7


def redis_key_constant_test():
    assert "LiveStockVSPositionAbstractInfo:1234_123456789" == \
           RedisKeyConstant.LiveStockVSPositionAbstractInfo.value.format(vs_id=1234, account=123456789)


if __name__ == '__main__':
    # strategy_constant_test()
    # vstrategies_constant_test()
    # redis_key_constant_test()
    # print(StrategyConstant.DetailAlgorithm.all())
    pass

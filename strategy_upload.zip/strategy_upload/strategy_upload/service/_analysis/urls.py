# -*-coding:utf-8-*-

from service._analysis.handlers import *

urls = [
    ('/api/v1/platform/analysis/ticker', TickerHander),
    ('/api/v1/platform/analysis/trade-list', TradeListHander),
]


#/v1/ticker
#/v1/portfolio/analysis
#/v1/portfolio/strategy_analysis/(?P<id>\d+)
#/v1/moms/trade-list
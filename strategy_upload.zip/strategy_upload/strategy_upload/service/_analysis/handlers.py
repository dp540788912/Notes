# -*-coding:utf-8-*-

from collections import OrderedDict
import re
import pandas

from tornado import gen
from  sqlalchemy import and_, or_, tuple_, func
from db import session
from service.basehandler import BaseHandler, CurrentUserMixin, JsonPayloadMixin
from service._analysis._lru_cache import lru_cache
from service._analysis._utils import kdb_async, dict_tree_to_vue_tree, dataframe_to_vue_table, symbol_to_mycap_symbol
from service.back_test.models import VStrategies, VsBase, VsAccount, VsPosition


EXCH_NAMES = {
    b'CFFEX': '中国金融期货交易所 (CFFEX)',
    b'DCE': '大连商品交易所 (DCE)',
    b'CZCE': '郑州商品交易所 (CZCE)',
    b'SHFE': '上海期货交易所 (SHFE)',
    b'SGE': '上海黄金交易所 (SGE)',
    b'CBOT': '芝加哥期货交易所 (CBOT)',
    b'CME': '芝加哥商品交易所 (CME)',
    b'COMEX': '纽约金属交易所 (COMEX)',
    b'NYMEX': '纽约商品交易所 (NYMEX)',
    b'ICEU': '洲际交易所 纽约 (ICE New York)',
    b'ICESG': '洲际交易所 新加坡 (ICE Singapore)',
    b'LME': '伦敦金属交易所 (LME)',
    b'HKEX': '香港交易所 (HKEx)',
    b'TOCOM': '东京商品交易所 (TOCOM)',
    b'SGX': '新加坡交易所 (SGX)',
    b'BMD': '马来西亚衍生品交易所 (BMD)'
}

EXCH_SYMBOL_REPLACE = {
    b'LME': (b'(.*)', b'\g<1>3M')        # Replace CU with CU3M
}


KDB_SQL_GET_EXCHANGES = '.gw.asyncexec["raze \
            {`EXCHANGE`PRODUCT xasc select distinct upper EXCHANGE,PRODUCT from x \
            where date=last date, not EXCHANGE in `sgx`hkfe`kse} \
            peach `MainCon`FMainCon "; `FuturesBasicInfo]'
KDB_SQL_GET_SGE_PRODUCTS = '.gw.asyncexec["exec distinct CONSTITUENTCODE from CGoldSpotEODPrices"; `FuturesBasicInfo]'

@lru_cache(timeout=1800)
@gen.coroutine
def get_ticker_tree():
    # Futures
    futures = yield kdb_async(KDB_SQL_GET_EXCHANGES, pandas=True)
    result = OrderedDict()
    for row in futures.iterrows():
        exch = row[1]['EXCHANGE']
        product = row[1]['PRODUCT']
        symbol = product
        if exch not in result:
            result[exch] = []
            if exch in (b'SHFE', b'DCE', b'CZCE', b'CFFEX'):
                _exch_all_symbol = '%sALL' % exch.decode('utf-8')
                result[exch].append([_exch_all_symbol, _exch_all_symbol, exch, 'futures'])
        if exch in EXCH_SYMBOL_REPLACE:
            symbol = re.sub(EXCH_SYMBOL_REPLACE[exch][0], EXCH_SYMBOL_REPLACE[exch][1], symbol)
        result[exch].append([product, symbol, exch, 'futures'])
    exchanges = dict_tree_to_vue_tree(result, ['name', 'symbol', 'exch', 'type'])

    # Spot
    spot_sge = yield kdb_async(KDB_SQL_GET_SGE_PRODUCTS)
    exchanges.append({'name': '上海黄金交易所 (SGE)',
                      'children': [{'type': 'spot', 'symbol': x, 'exch': 'SGE', 'name': x} for x in spot_sge.tolist()]})
    exchanges += [{'name': '上海证券交易所 (SSE)', 'url': '?exch=SSE', 'children': []},
                  {'name': '深圳证券交易所 (SZSE)', 'url': '?exch=SZSE', 'children': []}]

    for exch in exchanges:
        if exch['name'] in EXCH_NAMES:
            exch['name'] = EXCH_NAMES[exch['name']]
        exch['selectable'] = False

    indexes = [{'name': '国内股票指数', 'selectable': False, 'children': [
            {'name': '沪深300 (000300.SH)', 'symbol': '000300.SH', 'exch': 'SSE', 'type': 'stock'},
            {'name': '沪深300 (399300.SZ)', 'symbol': '399300.SZ', 'exch': 'SZSE', 'type': 'stock'},
            {'name': '中证500 (000905.SH)', 'symbol': '000905.SH', 'exch': 'SSE', 'type': 'stock'},
            {'name': '中证500 (399905.SZ)', 'symbol': '399905.SZ', 'exch': 'SZSE', 'type': 'stock'},
            {'name': '上证50 (000016.SH)', 'symbol': '000016.SH', 'exch': 'SSE', 'type': 'stock'}]}]

    constituents = [{'name': '沪深300', 'symbol': 'HS300', 'exch': 'SSE', 'type': 'index', 'url': '?index=000300', 'children': []},
               {'name': '中证500', 'symbol': 'ZZ500', 'exch': 'SSE', 'type': 'index', 'url': '?index=000905', 'children': []},
               {'name': '上证50', 'symbol': 'SH50', 'exch': 'SSE', 'type': 'index', 'url': '?index=000016', 'children': []},
               {'name': '沪深A股', 'symbol': 'HSA', 'exch': 'SSE', 'type': 'index', 'url': '?index=HSA', 'children': []}]

    return [{'name': '交易所', 'children': exchanges, 'selectable': False},
            {'name': '指数', 'children': indexes, 'selectable': False},
            {'name': '指数成份股', 'children': constituents, 'selectable': False}]


@lru_cache(timeout=1800)
@gen.coroutine
def get_tickers_by_index(index):
    tickers = yield kdb_async(
        '.gw.asyncexec["`SYMBOL xasc select SYMBOL from \
        GetConditionsStockFactorData[`TradeStatus;(`%s;`NUL);(2050.01.01;2050.01.01)]"; \
        `EquityFactor]' % index,
        pandas=True)

    result = []
    if type(tickers) == pandas.core.frame.DataFrame:
        for row in tickers.iterrows():
            symbol_split = row[1]['SYMBOL'].split(b'.')
            exch = 'SSE' if symbol_split[1] == b'SH' else 'SZSE'
            result.append([row[1]['SYMBOL'], symbol_split[0], exch, 'stock'])

    return dict_tree_to_vue_tree(result, ['name', 'symbol', 'exch', 'type'])


@lru_cache(timeout=1800)
@gen.coroutine
def get_tickers_by_exch(exch):
    # Query stocks and bonds from kdb+
    tickers = yield kdb_async(
        '.gw.asyncexec["(exec asc SYMBOL from AShareDescription where S_INFO_EXCHMARKET=`' + exch + ', S_INFO_DELISTDATE=0n),'
        + '`$exec asc S_INFO_WINDCODE from WindCustomCode where S_INFO_SECURITIESTYPES like string \\"G\\",'
        + 'SECURITY_STATUS=101001000, S_INFO_EXCHMARKET like \\"' + exch + '\\"";`EquityFactor]',
        pandas=True)

    if type(tickers) == pandas.core.series.Series:
        result = [[x, x.split(b'.')[0], 'stock', exch] for x in tickers.tolist()]
    else:
        result = []

    return dict_tree_to_vue_tree(result, ['name', 'symbol', 'type', 'exch'])



class TickerHander(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        exch = self.get_argument('exch', default=None)
        index = self.get_argument('index', default=None)
        if exch:
            result = yield get_tickers_by_exch(exch)
        elif index:
            result = yield get_tickers_by_index(index)
        else:
            result = yield get_ticker_tree()

        self.json_response({
            'code': 0,
            'data': result
        })



class TradeListHander(JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        from service.order_list.models import OrderList
        _date = self.get_argument('date')
        _st_id = self.get_argument('st_id', default=None)
        _format = self.get_argument('format', default='json')

        if _format == 'csv' and _st_id is None:
            self.json_response({
                'code': 1007,
                'error': '必选参数不能为空'
            })
            return

        result = OrderList.trade_list_generate(_st_id, _date)

        if _format == 'csv':
            self.set_header('Content-Type', 'text/csv')
            self.set_header('content-Disposition', 'attachment; filename=%s.csv' % _st_id)
            self.write(result[int(_st_id)])
        else:
            self.json_response({
                'code': 0,
                'data': result,
            })
        return

    @gen.coroutine
    def post(self, *args, **kwargs):
        try:
            req_data = self.get_payload()
            date = str(req_data['date'])
            strategy_id = req_data['strategy_id']
            _columns = req_data['trade_list']['keys']
            _data = req_data['trade_list']['values']

        except Exception as e:
            self.application.sentry.captureException()
            self.json_response({
                'code': 1008,
                'error': '非法参数'
            })
            return

        trade_list = pandas.DataFrame(data=_data, columns=_columns)

        result = yield trade_list_validate(date, strategy_id, trade_list)

        self.write({'code': 0, 'data': result})
        self.json_response({
            'code': 0,
            'data': result,
        })

TRADE_LIST_HEADER_MAP = {
    'index': '序号', 'symbol': '代码', 'weight': '目标权重', 'size': '目标手数/股数', 'limit_price': '限价', \
    'algo': '算法', 'start': '开始', 'end': '结束', 'valid': '检查', 'match': '撮合', '__current_pos': '当前仓位'
}

DEFAULT_EXECUTION = {'algo': 'vwap', 'start': '9:00', 'end': '23:59'}


def _get_vstrategy_ids(strategy_id):
    sc = session()
    vs_ids = [r[0] for r in sc.query(VStrategies.id).filter(
        VStrategies.strategy_id == int(strategy_id),
        VStrategies.status == 15,
    )]
    sc.close()
    return vs_ids


def _get_vs_position(ids):
    data = {}
    if ids:
        sc = session()
        vs_bases_filter1 = sc.query(
            VsBase.vstrategy_id, func.max(VsBase.settle_date)
        ).filter(
            VsBase.vstrategy_id.in_(ids)
        ).group_by(
            VsBase.vstrategy_id
        )

        vs_bases_filter2 = sc.query(
            VsBase.vstrategy_id, VsBase.settle_date, func.min(VsBase.daynight)
        ).filter(
            tuple_(
                VsBase.vstrategy_id, VsBase.settle_date
            ).in_(
                vs_bases_filter1
            )
        ).group_by(
            VsBase.vstrategy_id, VsBase.settle_date
        )

        vs_bases = sc.query(
            VsBase
        ).filter(
            tuple_(VsBase.vstrategy_id, VsBase.settle_date, VsBase.daynight).in_(
                vs_bases_filter2
            )
        )

        vs_positions = sc.query(
            VsPosition
        ).filter(
            tuple_(
                VsPosition.vstrategy_id, VsPosition.settle_date, VsPosition.daynight
            ).in_(
                vs_bases_filter2
            )
        )

        vs_accounts = sc.query(
            VsAccount
        ).filter(
            tuple_(
                VsAccount.vstrategy_id, VsAccount.settle_date, VsAccount.daynight
            ).in_(
                vs_bases_filter2
            )
        )

        for row in vs_bases:
            data[row.vstrategy_id] = {
                'settle_date': row.settle_date.strftime('%Y-%m-%d'),
                'daynight': row.daynight,
                'cash': float(row.cash),
                'cumulative_pnl': float(row.accumulated_pnl),
                'available_cash': float(row.available_cash),
                'data': {},
                'accounts': {},
            }

        for row in vs_positions:
            data[row.vstrategy_id]['data'][row.symbol] = {
                'yest_long_pos': int(row.yest_long_pos),
                'yest_long_avg_price': float(row.yest_long_avg_price),
                'yest_short_pos': int(row.yest_short_pos),
                'yest_short_avg_price': float(row.yest_short_avg_price),
                'today_long_pos': int(row.today_long_pos),
                'today_long_avg_price': float(row.today_long_avg_price),
                'today_short_pos': int(row.today_short_pos),
                'today_short_avg_price': float(row.today_short_avg_price),
                'account': row.account,
            }
        for row in vs_accounts:
            data[row.vstrategy_id]['accounts'][row.vstrategy_id] = {
                'cash': float(row.cash),
                'cumulative_pnl': float(row.accumulated_pnl),
                'available_cash': float(row.available_cash),
            }

        sc.close()
    return {
        'data': data,
    }

@gen.coroutine
def trade_list_validate(date, strategy_id, trade_list):
    def str_to_float(x):
        try:
            return float(x)
        except (ValueError, TypeError):
            return None

    vstrategy_id = _get_vstrategy_ids(strategy_id)
    positions = None
    if vstrategy_id:

        pos = _get_vs_position(vstrategy_id)

        for vs_id in vstrategy_id:
            try:
                df = pandas.DataFrame.from_dict(pos['data'][vs_id]['data'], orient='index')
                df.index = df.index.map(lambda x: str.encode(x))
                df.index.name = 'symbol'
                df['__current_pos'] = df['today_long_pos'] - df['today_short_pos']
                df = df[['__current_pos']]

                if positions is None:
                    positions = df
                else: # Calculate positions of all vstrategies
                    positions = positions.add(df, fill_value=0)
            except KeyError:
                pass

    trade_list['symbol'] = trade_list['symbol'].apply(lambda x: str.encode(symbol_to_mycap_symbol(x)))
    if 'weight' in trade_list.columns:
        trade_list['weight'] = trade_list['weight'].apply(str_to_float)
    else:
        trade_list['weight'] = None

    if 'size' in trade_list.columns:
        trade_list['size'] = trade_list['size'].apply(str_to_float)
    else:
        trade_list['size'] = None

    if 'limit_price' in trade_list.columns:
        trade_list['limit_price'] = trade_list['limit_price'].apply(str_to_float)
    trade_list.index = [x + 1 for x in trade_list.index]

    # Check symbol validity
    traded_stocks = (yield kdb_async(
        '.gw.asyncexec["asc exec distinct SYMBOL from GetConstituentStock[(`HSA;`nul);(2050.01.01;2050.01.01)]";`EquityFactor]')).tolist()
    traded_stocks_alternative = [x[0:6] for x in traded_stocks]
    traded_spot_futures = (yield kdb_async(
        '.gw.asyncexec["(exec distinct CONSTITUENTCODE from CGoldSpotEODPrices), \
        raze {exec distinct SYMBOL from x where date=max date} peach `MainCon`FMainCon "; `FuturesBasicInfo]')).tolist()

    traded_symbols = traded_stocks + traded_stocks_alternative + traded_spot_futures
    trade_list['valid'] = (trade_list['symbol'].isin(traded_symbols)) & ((trade_list['size'].isnull()==False) | (trade_list['weight'].isnull()==False))

    # Find all matching trades
    match_list = []
    trade_list_fillna = trade_list.fillna(0)
    for row in trade_list_fillna.itertuples():
        matched_indices = trade_list_fillna[
            (trade_list_fillna['valid'] == True) &
            (trade_list_fillna['symbol'] == row.symbol) &
            (trade_list_fillna['limit_price'] == row.limit_price) &
            (trade_list_fillna['algo'] == row.algo) &
            (trade_list_fillna['start'] == row.start) &
            (trade_list_fillna['end'] == row.end)
        ].index.tolist()
        if len(matched_indices) < 2:
            matched_indices = []

        match_list.append(matched_indices)

    trade_list['match'] = match_list
    original_list = trade_list.copy()

    matched_indices = []
    dropped_indices = []
    for index, row in trade_list.iterrows():
        # Merge matched trades
        if index not in dropped_indices:
            if row['valid'] == True and len(row['match']) > 1:
                trade_list.loc[index, 'weight'] = trade_list.loc[row['match'], 'weight'].sum()
                trade_list.loc[index, 'size'] = trade_list.loc[row['match'], 'size'].sum()
                to_drop = [x for x in row['match'] if x != index]
                matched_indices.append(index)
                dropped_indices += to_drop
                trade_list.drop(to_drop, inplace=True)
            elif row['valid'] == False:
                trade_list.drop(index, inplace=True)

    matched_list = trade_list.loc[matched_indices]
    matched_list['index'] = matched_list['match']
    matched_list = matched_list[['index', 'symbol', 'weight', 'size', 'limit_price', 'algo', 'start', 'end']]

    original_list['index'] = original_list.index
    original_list.sort_values(by=['valid', 'index'], inplace=True)
    original_list['valid'] = original_list['valid'].apply(
        lambda x: {'state': x, 'reason': 'symbol不合法或不存在；或weight和size列都为空。'
                   if not x else ''}
    )
    original_list = original_list[['index', 'symbol', 'weight', 'size', 'limit_price', 'algo', 'start', 'end', 'valid', 'match']]

    if positions is not None:
        trade_list = trade_list.set_index('symbol').merge(positions, how='left', left_index=True, right_index=True)
        trade_list['symbol'] = trade_list.index
    else:
        trade_list['__current_pos'] = None

    trade_list = trade_list[['symbol', '__current_pos', 'weight', 'size', 'limit_price', 'algo', 'start', 'end']]

    # Find symbols with non-zero positions but missing from the trade list
    if positions is not None:
        symbol_listed = trade_list['symbol'].tolist()
        symbol_open = [x for x in positions.index.tolist()]
        symbol_missing = [x for x in symbol_open if (x not in symbol_listed and x in traded_symbols)]


        # Find the best trading algo, start, end for each missing symbol
        trade_list_stock = trade_list.loc[trade_list['symbol'].apply(lambda x: x.decode()[0].isdigit())]
        trade_list_futures = trade_list.loc[trade_list['symbol'].apply(lambda x: not x.decode()[0].isdigit())]
        if not trade_list_stock.empty:
            stock_execution = trade_list_stock[['symbol', 'algo', 'start', 'end']].groupby(by=['algo', 'start', 'end'], as_index=False) \
                                .count().sort_values('symbol').iloc[-1]
        else:
            stock_execution = DEFAULT_EXECUTION
        if not trade_list_futures.empty:
            futures_execution = trade_list_futures[['symbol', 'algo', 'start', 'end']].groupby(by=['algo', 'start', 'end'], as_index=False) \
                                .count().sort_values('symbol').iloc[-1]
        else:
            futures_execution = DEFAULT_EXECUTION

        clear_list = []  # Symbols to clear position
        for x in symbol_missing:
            if x.decode()[0].isdigit(): # stock
                exe = stock_execution
            else: # futures
                product, contract, _ = re.split(r'(\d+)', x.decode())
                if len(product) == 0:
                    exe = DEFAULT_EXECUTION
                else:
                    same_product = trade_list.loc[trade_list.symbol.str.startswith(product.encode())]
                    if not same_product.empty:
                        first_row = same_product.iloc[0]
                        exe = {'algo': first_row['algo'], 'start': first_row['start'], 'end': first_row['end']}
                    else:
                        exe = futures_execution

            clear_list.append({'symbol': x, '__current_pos': positions['__current_pos'][x], 'weight': 0, 'size': 0,
                               'limit_price': None, 'algo': exe['algo'], 'start': exe['start'], 'end': exe['end']})

        if len(clear_list) > 0:
            trade_list = pandas.DataFrame(clear_list, columns=
                                ['symbol', '__current_pos', 'weight', 'size', 'limit_price', 'algo', 'start', 'end'])\
                               .append(trade_list, ignore_index=True)
            trade_list.index = [x + 1 for x in trade_list.index]

    result = {
        'original': dataframe_to_vue_table(original_list, titles=TRADE_LIST_HEADER_MAP),
        'final': dataframe_to_vue_table(trade_list, titles=TRADE_LIST_HEADER_MAP),
        'matched': dataframe_to_vue_table(matched_list, titles=TRADE_LIST_HEADER_MAP)
    }

    return result
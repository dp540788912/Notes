# -*-coding:utf-8-*-

import pandas
import numpy
import re
from enum import Enum

from tornado import gen
from qpython import qconnection

from config import config as cfg
from service._analysis._lru_cache import lru_cache


@lru_cache(maxsize=255, timeout=10)
@gen.coroutine
def kdb_async(sql, pandas=True):
    """
    Async kdb+ query with caching. Data in kdb+ are rarely changed in a day.
    """
    with qconnection.QConnection(
            host=cfg.KDB_HOST,
            port=cfg.KDB_PORT,
            username=cfg.KDB_USER,
            password=cfg.KDB_PASSWD) as q:
        q.async(sql)
        return q.receive(pandas=pandas)


Exchanges = Enum('Exchanges', 'CFFEX CZCE SHFE DCE')
FuturesList = {'ic': Exchanges.CFFEX, 'if': Exchanges.CFFEX, 'ih': Exchanges.CFFEX, 't': Exchanges.CFFEX, 'tf': Exchanges.CFFEX, 'cf': Exchanges.CZCE, 'cy': Exchanges.CZCE,
                'fg': Exchanges.CZCE, 'jr': Exchanges.CZCE, 'lr': Exchanges.CZCE, 'ma': Exchanges.CZCE, 'oi': Exchanges.CZCE, 'pm': Exchanges.CZCE, 'ri': Exchanges.CZCE,
                'rm': Exchanges.CZCE, 'rs': Exchanges.CZCE, 'sf': Exchanges.CZCE, 'sm': Exchanges.CZCE, 'sr': Exchanges.CZCE, 'ta': Exchanges.CZCE, 'wh': Exchanges.CZCE,
                'zc': Exchanges.CZCE, 'a': Exchanges.DCE, 'b': Exchanges.DCE, 'bb': Exchanges.DCE, 'c': Exchanges.DCE, 'cs': Exchanges.DCE, 'fb': Exchanges.DCE, 'i': Exchanges.DCE,
                'j': Exchanges.DCE, 'jd': Exchanges.DCE, 'jm': Exchanges.DCE, 'l': Exchanges.DCE, 'm': Exchanges.DCE, 'p': Exchanges.DCE, 'pp': Exchanges.DCE, 'v': Exchanges.DCE,
                'y': Exchanges.DCE, 'ag': Exchanges.SHFE, 'al': Exchanges.SHFE, 'au': Exchanges.SHFE, 'bu': Exchanges.SHFE, 'cu': Exchanges.SHFE, 'fu': Exchanges.SHFE,
                'hc': Exchanges.SHFE, 'ni': Exchanges.SHFE, 'pb': Exchanges.SHFE, 'rb': Exchanges.SHFE, 'ru': Exchanges.SHFE, 'sn': Exchanges.SHFE, 'wr': Exchanges.SHFE, 'zn': Exchanges.SHFE}


def dict_tree_to_vue_tree(dict_tree, field_names=None):
    """
    Convert internal dict tree to Vue tree
    See dict_tree in the test case below for structure
    :param dict_tree: dictionary
    :param field_names: list, each item represents the field name of the corresponding item in dict_tree
    :return: list
    """
    result = []
    if field_names is None:
        field_names = ['id', 'name']

    if isinstance(dict_tree, dict):
        for key, value in dict_tree.items():
            result.append({'name': key, 'children': dict_tree_to_vue_tree(value, field_names)})

    elif isinstance(dict_tree, list):
        for item in dict_tree:
            if isinstance(item, list):
                res = {}
                for idx, val in enumerate(item):
                    if idx < len(field_names):
                        res[field_names[idx]] = val
                result.append(res)
    return result


def dataframe_to_vue_table(df, titles=None):
    """
    Convert pandas dataframe to Vue table {headers:[], rows:[]}
    :param df: pandas dataframe
    :param titles: dictionary, default None
    :return: dictionary with two keys 'headers' and 'rows'
    """
    cols = df.columns.values.tolist()
    headers = [{'prop': x, 'title': titles[x] if titles is not None and x in titles else x} for x in cols]
    rows = [{cols[i]: row[i] for i in range(len(row))} for row in df.itertuples(index=False)]

    return {'headers': headers, 'rows': rows}


def symbol_to_mycap_symbol(symbol):
    """
    Convert a futures symbol to mycapital futures symbol like
    IF1801 a1801 CF801 cu1801 (note the cases and number of digits)
    :param symbol: a futures symbol
    :return:
    """
    product, contract, _ = re.split(r'(\d+)', symbol)
    product = product.lower()
    if product in FuturesList:
        if FuturesList[product] == Exchanges.CFFEX:
            product = product.upper()
        elif FuturesList[product] == Exchanges.CZCE:
            product = product.upper()
            contract = contract[-3:]
        return product + contract
    else:
        return symbol

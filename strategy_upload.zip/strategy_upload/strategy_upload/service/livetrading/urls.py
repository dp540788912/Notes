# -*-coding:utf-8-*-


from service.livetrading.handlers import *

urls = [
    (r'/api/v1/platform/livetrading/cashlimit$', VstrategyCashLimitHandler),
    (r'/api/v1/platform/livetrading/cashlimit/(?P<id>\d+)$', VstrategyCashLimitDetailHandler),
    (r'/api/v1/platform/livetrading/vstrategy/parameter/(?P<id>\d+)$', VstrategyParameterDetailHandler),
    (r'/api/v1/platform/livetrading/hedge/metric$', HedgeMetricHandler),
    (r'/api/v1/platform/livetrading/hedge/metric_v2$', HedgeMetricV2Handler),
]

# -*-coding:utf-8-*-

import datetime
from tornado import gen
from sqlalchemy import func
from service.basehandler import BaseHandler, CurrentUserMixin, JsonPayloadMixin

import consts
from db import session
from kdb_query import KdbQuery
from service.back_test.models import Strategy, VStrategies, StrategyPortfolio, StrategyPerfInput
from service.back_test.models import VsAccount
from service.back_test.live_trading_models import CashLimit, CashLimitDetail, VsLiveParameter
from service.livetrading.hedge_metric import FundHedgeService
from cron.live_trading_task import send_cash_limit, send_live_parameter
from service.livetrading.hedge_metric_v2 import hedge_data
import json


class VstrategyCashLimitHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):

        vs_ids = self.get_argument('vs_ids', '')
        vs_ids = [int(v_id) for v_id in vs_ids.split(',')]

        data = {}
        sc = session()

        strategy_detail = sc.query(
            VStrategies.id.label('vs_id'),
            VStrategies.symbols_accounts_detail.label('symbols_accounts_detail'),
            Strategy.id.label('s_id'),
            Strategy.id_no.label('id_no'),
            Strategy.products.label('products'),
            StrategyPortfolio.name.label('sp_name'),
        ).join(
            Strategy, Strategy.id == VStrategies.strategy_id,
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id,
        ).filter(
            VStrategies.id.in_(vs_ids),
            VStrategies.status == consts.STRATEGY_LIVE,
        )
        current_trading_date, current_day_night = StrategyPerfInput.get_trading_date_day_night()
        kdb = KdbQuery()
        main_code = kdb.get_main_code(current_trading_date)
        foreign_main_code = kdb.get_foreign_main_code(current_trading_date)
        for s in strategy_detail:
            vs_d = data.setdefault(s.vs_id, {
                'vs_id': s.vs_id,
                's_id': s.s_id,
                'strategy_id': s.id_no,
                'portfolio_name': s.sp_name,
                'accounts': {},
                'symbols': [],
                'current_cash_limit': {},
            })
            for l_acc in VStrategies.normalization_symbols_accounts(s.symbols_accounts_detail):
                l_acc_d = vs_d['accounts'].setdefault(
                    l_acc['account'], {
                        'total_asset': 0
                    }
                )
                l_acc_d['total_asset'] += l_acc['amount']
            if s.products:
                for p in s.products[0]:
                    if p['exch'] in consts.STOCK_EXCHANGE:
                        vs_d['symbols'].append(p['symbol'])
                    elif p['exch'] in consts.FUTURE_EXCHANGE:
                        if ('A' in p['rank']) or ('a' in p['rank']):
                            vs_d['symbols'].extend(main_code['%s|A' % (p['symbol'].lower())])
                        else:
                            for r in p['rank']:
                                if r:
                                    vs_d['symbols'].append(main_code['%s|%s' % (p['symbol'].lower(), r)])
                    elif p['exch'] in consts.FOREIGN_EXCHANGE:
                        if p['exch'].upper() == 'LME':
                            vs_d['symbols'].append(p['symbol'])
                            continue
                        if ('A' in p['rank']) or ('a' in p['rank']):
                            p_symbol = p['symbol'].lower()
                            p_exch = p['exch'].upper()
                            if p_symbol == 'b' and p_exch == 'ICEE':
                                p_exch = 'ICEU'
                            vs_d['symbols'].extend(foreign_main_code['%s@%s|A' % (p_symbol, p_exch)])
                        else:
                            for r in p['rank']:
                                if r:
                                    p_symbol = p['symbol'].lower()
                                    p_exch = p['exch'].upper()
                                    if p_symbol == 'b' and p_exch == 'ICEE':
                                        p_exch = 'ICEU'
                                    vs_d['symbols'].append(foreign_main_code['%s@%s|%s' % (p_symbol, p_exch, r)])
                    else:
                        raise ValueError('can not support exchange')

        vs_ids = list(data.keys())
        latest_settle_day = StrategyPerfInput.get_latest_settle_day()
        trading_date = latest_settle_day['trading_date']
        day_night = latest_settle_day['day_night']
        vs_accounts = sc.query(
            VsAccount.vstrategy_id.label('vs_id'),
            VsAccount.account.label('account'),
            VsAccount.total_asset.label('total_asset'),
        ).filter(
            VsAccount.vstrategy_id.in_(vs_ids),
            VsAccount.settle_date == trading_date,
            VsAccount.daynight == ('NIGHT' if day_night == 1 else 'DAY')
        )
        for vs_acc in vs_accounts:
            data[vs_acc.vs_id]['accounts'][vs_acc.account]['total_asset'] = float(vs_acc.total_asset)

        vs_cash_limit = sc.query(
            CashLimit.vs_id.label('vs_id'),
            func.max(CashLimit.id).label('cash_id'),
        ).filter(
            CashLimit.vs_id.in_(vs_ids),
            CashLimit.status == 1
        ).group_by(
            CashLimit.vs_id
        )

        cashlimit2vs = {r[1]: r[0] for r in vs_cash_limit}

        vs_cash_limit = sc.query(
            CashLimit
        ).filter(
            CashLimit.id.in_(cashlimit2vs.keys())
        )

        vs_cash_limit_detail = sc.query(
            CashLimitDetail
        ).filter(
            CashLimitDetail.cash_limit_id.in_(cashlimit2vs.keys())
        )
        for l in vs_cash_limit:
            vs_id = cashlimit2vs[l.id]
            data[vs_id]['current_cash_limit']['cash_id'] = l.id
            data[vs_id]['current_cash_limit']['remark'] = l.remark
            data[vs_id]['current_cash_limit']['username'] = l.username
            data[vs_id]['current_cash_limit']['detail'] = {}
            data[vs_id]['current_cash_limit']['start_time'] = ''
            data[vs_id]['current_cash_limit']['end_time'] = ''

        for l in vs_cash_limit_detail:
            vs_id = cashlimit2vs[l.cash_limit_id]
            data[vs_id]['current_cash_limit']['detail'][l.symbol] = {
                'symbol': l.symbol,
                'start_time': l.start_time.strftime('%Y-%m-%d %X'),
                'end_time': l.end_time.strftime('%Y-%m-%d %X'),
                'long_limit': float(l.long_limit),
                'short_limit': float(l.short_limit),
            }

            if not data[vs_id]['current_cash_limit']['start_time']:
                data[vs_id]['current_cash_limit']['start_time'] = data[vs_id]['current_cash_limit']['detail'][l.symbol][
                    'start_time']
            else:
                data[vs_id]['current_cash_limit']['start_time'] = min(
                    data[vs_id]['current_cash_limit']['start_time'],
                    data[vs_id]['current_cash_limit']['detail'][l.symbol]['start_time']
                )

            if not data[vs_id]['current_cash_limit']['end_time']:
                data[vs_id]['current_cash_limit']['end_time'] = data[vs_id]['current_cash_limit']['detail'][l.symbol][
                    'end_time']
            else:
                data[vs_id]['current_cash_limit']['end_time'] = max(
                    data[vs_id]['current_cash_limit']['end_time'],
                    data[vs_id]['current_cash_limit']['detail'][l.symbol]['end_time']
                )

        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        group_ids = self.get_user_group()
        if (2 not in group_ids) and (22 not in group_ids) and (32 not in group_ids):
            self.json_response({
                'code': 1124,
                'error': 'only investment group has permission'
            })
            return

        payload = self.get_payload()
        vs_ids = [int(v_id) for v_id in payload.keys()]
        sc = session()
        vs_detail = sc.query(
            VStrategies.id,
            VStrategies.strategy_id
        ).filter(
            VStrategies.id.in_(vs_ids)
        )
        vs2strategy = {vs[0]: vs[1] for vs in vs_detail}
        _now = datetime.datetime.now()
        now_time = _now.strftime('%Y-%m-%d %X')
        now_weekday = _now.weekday()
        now_hour = _now.strftime('%H%M')

        is_trading_time = False
        if (0 <= now_weekday <= 4) and (('0855' <= now_hour <= '1500') or ('2055' <= now_hour <= '0200')):
            is_trading_time = True

        cash_limits = sc.query(CashLimit).filter(CashLimit.vs_id.in_(vs_ids))
        cash_limit_ids = []
        for cash_limit in cash_limits:
            cash_limit.status = 0
            cash_limit_ids.append(cash_limit.id)
        cash_limit_details = sc.query(CashLimitDetail).filter(CashLimitDetail.cash_limit_id.in_(cash_limit_ids))
        for cash_limit_d in cash_limit_details:
            cash_limit_d.end_time = now_time
        sc.commit()
        new_cash_limit_ids = []
        for vs_id, vs_d in payload.items():
            vs_id = int(vs_id)
            cash_limit = CashLimit(
                vs_id=vs_id,
                strategy_id=vs2strategy[vs_id],
                remark=vs_d.get('remark', ''),
                r_create_user_id=self.current_user['id'],
                r_update_user_id=self.current_user['id'],
                username=self.current_user['username'],
            )
            sc.add(cash_limit)
            sc.flush()
            for symbol, s_d in vs_d['position_limit'].items():
                cash_limit_d = CashLimitDetail(
                    cash_limit_id=cash_limit.id,
                    symbol=symbol,
                    start_time=vs_d.get('start_time', now_time),
                    end_time=vs_d['end_time'],
                    long_limit=float(s_d['long']),
                    short_limit=float(s_d['short']),
                )
                sc.add(cash_limit_d)
            new_cash_limit_ids.append(cash_limit.id)
        sc.commit()
        sc.close()
        if is_trading_time:
            is_trading_time = KdbQuery().is_trading_date2(_now.strftime('%Y%m%d'))
            if is_trading_time:
                for cash_id in new_cash_limit_ids:
                    send_cash_limit.delay(cash_id)
        self.json_response({
            'code': 0,
            'data': {}
        })
        return True


class VstrategyCashLimitDetailHandler(JsonPayloadMixin, CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def put(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        group_ids = self.get_user_group()
        if (2 not in group_ids) and (22 not in group_ids) and (32 not in group_ids):
            self.json_response({
                'code': 1124,
                'error': 'only investment group has permission'
            })
            return

        payload = self.get_payload()
        cash_id = int(kwargs['id'])
        sc = session()
        cash_limit_detail = sc.query(CashLimitDetail).filter(CashLimitDetail.cash_limit_id == cash_id)
        for d in cash_limit_detail:
            if 'start_time' in payload:
                d.start_time = payload['start_time']
            if 'end_time' in payload:
                d.end_time = payload['end_time']
        sc.commit()

        now_time = datetime.datetime.now()
        now_weekday = now_time.weekday()
        now_hour = now_time.strftime('%H%M')
        is_trading_time = False
        if (0 <= now_weekday <= 4) and (('0855' <= now_hour <= '1500') or ('2055' <= now_hour <= '0200')):
            is_trading_time = True

        if is_trading_time:
            is_trading_time = KdbQuery().is_trading_date2(now_time.strftime('%Y%m%d'))
            if is_trading_time:
                send_cash_limit.delay(cash_id)

        self.json_response({
            'code': 0,
            'data': {}
        })
        return True

    @gen.coroutine
    def delete(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        group_ids = self.get_user_group()
        if (2 not in group_ids) and (22 not in group_ids) and (32 not in group_ids):
            self.json_response({
                'code': 1124,
                'error': 'only investment group has permission'
            })
            return

        now_time = datetime.datetime.now()
        now_weekday = now_time.weekday()
        now_hour = now_time.strftime('%H%M')
        is_trading_time = False
        if (0 <= now_weekday <= 4) and (('0855' <= now_hour <= '1500') or ('2055' <= now_hour <= '0200')):
            is_trading_time = True

        if is_trading_time:
            is_trading_time = KdbQuery().is_trading_date2(now_time.strftime('%Y%m%d'))

        cash_id = int(kwargs['id'])
        sc = session()
        cash_limit = sc.query(CashLimit).filter(CashLimit.id == cash_id).first()
        cash_limit_detail = sc.query(CashLimitDetail).filter(CashLimitDetail.cash_limit_id == cash_id)
        cash_limit.status = 0
        now_time = datetime.datetime.now().strftime('%Y-%m-%d %X')
        for d in cash_limit_detail:
            d.end_time = now_time
        sc.commit()
        if is_trading_time:
            send_cash_limit.delay(cash_id, clear=True)
        self.json_response({
            'code': 0,
            'data': {}
        })
        return True


class VstrategyParameterDetailHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):

        vs_id = int(kwargs['id'])

        sc = session()
        parameters = sc.query(VsLiveParameter).filter(VsLiveParameter.vs_id == vs_id)
        strategy_detail = sc.query(
            VStrategies.id.label('vs_id'),
            Strategy.id.label('s_id'),
            Strategy.id_no.label('id_no'),
            StrategyPortfolio.name.label('sp_name'),
        ).join(
            Strategy, Strategy.id == VStrategies.strategy_id,
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id,
        ).filter(
            VStrategies.id == vs_id
        ).first()
        data = {
            'vs_id': vs_id,
            's_id': strategy_detail.s_id,
            'strategy_id': strategy_detail.id_no,
            'portfolio_name': strategy_detail.sp_name,
            'parameters': [para.to_dict() for para in parameters],
        }

        self.json_response({
            'code': 0,
            'data': data
        })
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        group_ids = self.get_user_group()
        if (2 not in group_ids) and (22 not in group_ids) and (32 not in group_ids):
            self.json_response({
                'code': 1124,
                'error': 'only investment group has permission'
            })
            return
        now_time = datetime.datetime.now()
        now_weekday = now_time.weekday()
        now_hour = now_time.strftime('%H%M')
        is_trading_time = False
        if (0 <= now_weekday <= 4) and (('0855' <= now_hour <= '1500') or ('2055' <= now_hour <= '0200')):
            is_trading_time = True

        if is_trading_time:
            is_trading_time = KdbQuery().is_trading_date2(now_time.strftime('%Y%m%d'))

        if not is_trading_time:
            self.json_response({
                'code': 1301,
                'error': '非交易时间段设置无效',
            })
            return

        payload = self.get_payload()
        vs_id = int(kwargs['id'])

        sc = session()
        vs_detail = sc.query(
            VStrategies.id,
            VStrategies.strategy_id
        ).filter(
            VStrategies.id == vs_id,
            VStrategies.status == consts.STRATEGY_LIVE
        )
        vs2strategy = {vs[0]: vs[1] for vs in vs_detail}
        if not vs2strategy:
            sc.close()
            self.json_response({
                'code': 1300,
                'error': 'can not find live vstrategy id=%s' % vs_id
            })
            return

        para = VsLiveParameter(
            r_create_user_id=self.current_user['id'],
            username=self.current_user['username'],
            vs_id=vs_id,
            strategy_id=vs2strategy[vs_id],
            remark=payload.get('remark', ''),
            parameter0=float(payload['parameter0']),
            parameter1=float(payload['parameter1']),
            parameter2=float(payload['parameter2']),
            parameter3=float(payload['parameter3']),
            parameter4=float(payload['parameter4']),
            parameter5=float(payload['parameter5']),
            parameter6=float(payload['parameter6']),
            parameter7=float(payload['parameter7']),
            parameter8=float(payload['parameter8']),
            parameter9=float(payload['parameter9']),
        )
        sc.add(para)
        sc.commit()
        data = para.to_dict()
        para_id = para.id
        if is_trading_time:
            send_live_parameter.delay(para_id)
        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return


class HedgeMetricHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        ss = FundHedgeService()
        yield ss.async_get_live_quote()
        data = ss.get_data()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return


class HedgeMetricV2Handler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        try:
            resp = hedge_data()
            # flatten alpha/hedge summary and detail dict to sorted list
            for strategy_set_data in resp.values():
                alpha_data = strategy_set_data["alpha_strategies"]
                alpha_data["detail"] = [alpha_data["detail"][i] for i in sorted(alpha_data["detail"])]
                alpha_data["summary"] = [alpha_data["summary"][i][j] for i in sorted(alpha_data["summary"]) for j in
                                         sorted(alpha_data["summary"][i])]
                for h_data in strategy_set_data["hedge_strategies"].values():
                    h_data["detail"] = [h_data["detail"][i] for i in sorted(h_data["detail"])]
                    h_data["summary"] = [h_data["summary"][i][j] for i in sorted(h_data["summary"]) for j in
                                         sorted(h_data["summary"][i])]
            body = json.dumps({"code": 0, "data": resp}, ensure_ascii=False)
            self.write(body)
        except Exception as e:
            self.application.sentry.captureException()
            self.json_response({
                'code': -1,
                'data': 'data error',
            })
        return

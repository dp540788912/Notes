import simplejson as json
import sys
import os
import pandas as pd

root_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
project_path = os.path.join(root_path, 'strategy_upload')
if project_path not in sys.path:
    sys.path.append(root_path)
from db import session_context, session, engine, Session
from service.back_test.models import VStrategies, Strategy, SettlementManualTradelog, TradeLogs, VsPosition, VsAccount, \
    VsBase, NewStrategySet, NewStrategySetdetail, StockHedgeVs
from models.strategy import VsHedgeRelation
from utility.db_util.kdb_helper import TradeCalendar
from utility.func_util.decorator import TradingDateTTLCache
from config import config
from sqlalchemy.orm import Query
from sqlalchemy.sql.expression import Case, Cast, literal_column
from sqlalchemy.dialects.mysql import DECIMAL
from sqlalchemy.sql.functions import GenericFunction, sqltypes
from sqlalchemy.types import BOOLEAN
from pprint import pprint
from kdb_query import KdbQuery
import requests
from collections import defaultdict

acc_transfer_fee = 0.00002
stamp_tax = 0.001
broker_fee = 0.00016

# TODO 手续暂时写死在文件里面，后面要根据account存入mysql
StockFeeConst = {
    "SSE": {
        "A": {
            "open_today_fee_rate": broker_fee + acc_transfer_fee,
            "open_yest_fee_rate": broker_fee + acc_transfer_fee,
            "close_today_fee_rate": broker_fee + acc_transfer_fee + stamp_tax,
            "close_yest_fee_rate": broker_fee + acc_transfer_fee + stamp_tax
        },
        "J": {
            "open_today_fee_rate": broker_fee + acc_transfer_fee,
            "open_yest_fee_rate": broker_fee + acc_transfer_fee,
            "close_today_fee_rate": broker_fee + acc_transfer_fee + stamp_tax,
            "close_yest_fee_rate": broker_fee + acc_transfer_fee + stamp_tax
        },
        "S": {
            "open_today_fee_rate": broker_fee + acc_transfer_fee,
            "open_yest_fee_rate": broker_fee + acc_transfer_fee,
            "close_today_fee_rate": broker_fee + acc_transfer_fee + stamp_tax,
            "close_yest_fee_rate": broker_fee + acc_transfer_fee + stamp_tax
        }
    },
    "SZSE": {
        "A": {
            "open_today_fee_rate": broker_fee,
            "open_yest_fee_rate": broker_fee,
            "close_today_fee_rate": broker_fee + stamp_tax,
            "close_yest_fee_rate": broker_fee + stamp_tax
        },
        "J": {
            "open_today_fee_rate": broker_fee + acc_transfer_fee,
            "open_yest_fee_rate": broker_fee + acc_transfer_fee,
            "close_today_fee_rate": broker_fee + acc_transfer_fee + stamp_tax,
            "close_yest_fee_rate": broker_fee + acc_transfer_fee + stamp_tax
        },
        "S": {
            "open_today_fee_rate": broker_fee + acc_transfer_fee,
            "open_yest_fee_rate": broker_fee + acc_transfer_fee,
            "close_today_fee_rate": broker_fee + acc_transfer_fee + stamp_tax,
            "close_yest_fee_rate": broker_fee + acc_transfer_fee + stamp_tax
        }
    }
}


class group_concat(GenericFunction):
    type = sqltypes.String


class DefaultDictWithKey(dict):
    def __init__(self, func, **kwargs):
        self.func = func
        super().__init__(**kwargs)

    def __missing__(self, key):
        value = self.func(key)
        self[key] = value
        return value


class DictMapping(dict):
    pass


class LiveVsPosition(pd.DataFrame):
    def __init__(self, date, day_night):
        self.date = date
        self.day_night = day_night


class VstrategyMapping(DictMapping):
    pass


class Context:
    trade_calendar = TradeCalendar.init_from_kdb(host=config.KDB_HOST, port=config.KDB_PORT, username=config.KDB_USER,
                                                 password=config.KDB_PASSWD)


@TradingDateTTLCache(600)
class VsHedgeRelationDetail(dict, Context):
    def __init__(self, trading_date="", day_night=0):
        self.refresh()

    def refresh(self):
        with session_context() as sc:
            query = sc.query(StockHedgeVs.stock_vs_id, StockHedgeVs.future_vs_id).filter(
                StockHedgeVs.valid == True,
            )
            for alpha_id, hedge_id in query:
                self[alpha_id] = [hedge_id]


@TradingDateTTLCache(1800, refresh=False)
class SymbolDetailDict(dict, Context):
    def __init__(self, trading_date="", day_night=0):
        self.trading_date = trading_date
        self.day_night = day_night
        self.kdb = KdbQuery()
        self.refresh()

    def refresh(self):
        self.update_forex_future_symbol_detail()
        self.update_future_symbol_detail()
        self.update_stock_symbol_detail()

    def update_stock_symbol_detail(self):
        """
        china stock symbol detail from wind database

        :return:
        """
        sql = """.gw.asyncexec[\"select S_INFO_SECURITIESTYPES, S_INFO_CODE, EXCHMARKET
               from WindCustomCode where (`$S_INFO_SECURITIESTYPES) in `A`J`S,(`$EXCHMARKET) in `SSE`SZSE`SGE\";`EquityFactor]"""
        symbol_df = self.kdb.async_query(sql, pandas=True)
        symbol_df["exchange"] = symbol_df["EXCHMARKET"].str.decode("utf-8")
        symbol_df["product"] = symbol_df["S_INFO_CODE"].str.decode("utf-8")
        symbol_df["symbol"] = symbol_df["S_INFO_CODE"].str.decode("utf-8")
        symbol_df["symbol_type"] = symbol_df["S_INFO_SECURITIESTYPES"].str.decode("utf-8")
        symbol_df = symbol_df.assign(key=symbol_df.symbol + "@" + symbol_df.exchange)

        for row in symbol_df.itertuples(index=False):
            detail = self[row.key]
            detail["symbol"] = row.symbol
            detail["exchange"] = row.exchange
            detail["product"] = row.product
            detail["symbol_type"] = row.symbol_type
            self[row.symbol] = detail
            detail["open_today_fee_rate"] = StockFeeConst[row.exchange][row.symbol_type]["open_today_fee_rate"]
            detail["open_yest_fee_rate"] = StockFeeConst[row.exchange][row.symbol_type]["open_yest_fee_rate"]
            detail["close_today_fee_rate"] = StockFeeConst[row.exchange][row.symbol_type]["close_today_fee_rate"]
            detail["close_yest_fee_rate"] = StockFeeConst[row.exchange][row.symbol_type]["close_yest_fee_rate"]
            detail["fee_rate_mode"] = False
            detail["trade_unit"] = 1
        # 特殊处理，由于平台symbol不统一，后续统一为symbol@exchange
        self["000905.SH"] = self["000905@SSE"]

    # TODO 目前发现wind数据库里面也有期货的数据，需要和数据组确认是否可以和股票一起提取
    def update_future_symbol_detail(self):
        """
        china future symbol detail

        :return:
        """
        trading_date = self.trading_date.replace("-", ".")
        symbol_sql = """.gw.asyncexec[\"select EXCHANGE,PRODUCT,SYMBOL from MainCon where date = last date \"; `FuturesBasicInfo]"""
        fee_sql = """.gw.asyncexec["select Product, MyProduct,ExchCode,`ByVol=FeeMode,TradeUnit, MyIntraSimuFee,TickSize,
        MyInterSimuFee,ExchIntraOpenFee,ExchInterOpenFee,ExchIntraCloseFee, ExchInterCloseFee,MyBrokerOpenFee,MyBrokerCloseFee,date,Category
        from FeeRateV2 where date = %s, Category=%s";`FeeRateDB]""" % (trading_date, self.day_night)
        symbol_df = self.kdb.async_query(symbol_sql, pandas=True)
        symbol_df["exchange"] = symbol_df["EXCHANGE"].str.decode("utf-8")
        symbol_df["product"] = symbol_df["PRODUCT"].str.decode("utf-8")
        symbol_df["symbol"] = symbol_df["SYMBOL"].str.decode("utf-8")
        symbol_df = symbol_df.assign(key=symbol_df.symbol + "@" + symbol_df.exchange)
        fee_df = self.kdb.async_query(fee_sql, pandas=True)
        fee_df["ExchCode"] = fee_df["ExchCode"].str.decode("utf-8")
        fee_df["Product"] = fee_df["Product"].str.decode("utf-8")
        fee_df = fee_df.assign(
            open_today_fee_rate=fee_df.ExchIntraOpenFee * (1 + fee_df.MyBrokerOpenFee),
            open_yest_fee_rate=fee_df.ExchInterOpenFee * (1 + fee_df.MyBrokerOpenFee),
            close_today_fee_rate=fee_df.ExchIntraCloseFee * (1 + fee_df.MyBrokerCloseFee),
            close_yest_fee_rate=fee_df.ExchInterCloseFee * (1 + fee_df.MyBrokerCloseFee),
        ).set_index("Product")
        fee_dct = fee_df.rename({
            "ExchCode": "exchange",
            "TradeUnit": "trade_unit",
            "Currency": "currency",
            "FeeMode": "fee_rate_mode"
        }, axis=1).to_dict("index")
        for row in symbol_df.itertuples(index=False):
            detail = self[row.key]
            detail["symbol"] = row.symbol
            detail["exchange"] = row.exchange
            detail["product"] = row.product
            detail["symbol_type"] = "FU"
            self[row.symbol] = detail
            fee_detail = fee_dct.get(row.product, None)
            if fee_detail is None:
                continue
            detail["open_today_fee_rate"] = fee_detail["open_today_fee_rate"]
            detail["open_yest_fee_rate"] = fee_detail["open_yest_fee_rate"]
            detail["close_today_fee_rate"] = fee_detail["close_today_fee_rate"]
            detail["close_yest_fee_rate"] = fee_detail["close_yest_fee_rate"]
            detail["trade_unit"] = fee_detail["trade_unit"]
            detail["fee_rate_mode"] = fee_detail["fee_rate_mode"]

    def update_forex_future_symbol_detail(self):
        """
        update forex future symbol detail from kdb

        :return:
        """
        trading_date = self.trading_date.replace("-", ".")
        symbol_sql = """.gw.asyncexec["select distinct EXCHANGE,PRODUCT,SYMBOL from FMainCon
                where EXCHANGE in `SGX`NYMEX`CME`CBOT`COMEX`LME`ICEE`IPE`ICEU`HKEX`APEX ,date >=%s "; `FuturesBasicInfo]""" % trading_date
        fee_sql = """.gw.asyncexec["select Product, MyProduct,ExchCode,`ByVol=FeeMode,TradeUnit, MyIntraSimuFee,TickSize,
        MyInterSimuFee,ExchIntraOpenFee,ExchInterOpenFee,ExchIntraCloseFee, ExchInterCloseFee,MyBrokerOpenFee,MyBrokerCloseFee,date,Category,Currency
        from ForeignFeeRateV2 where date=%s, Category=%s";`FeeRateDB]""" % (trading_date, self.day_night)
        symbol_df = self.kdb.async_query(symbol_sql, pandas=True)
        symbol_df["exchange"] = symbol_df["EXCHANGE"].str.decode("utf-8")
        symbol_df["product"] = symbol_df["PRODUCT"].str.decode("utf-8")
        symbol_df["symbol"] = symbol_df["SYMBOL"].str.decode("utf-8")
        symbol_df = symbol_df.assign(key=symbol_df.symbol + "@" + symbol_df.exchange)
        fee_df = self.kdb.async_query(fee_sql, pandas=True)
        fee_df["ExchCode"] = fee_df["ExchCode"].str.decode("utf-8")
        fee_df["Product"] = fee_df["Product"].str.decode("utf-8")
        fee_df = fee_df.assign(
            key=fee_df.Product + "@" + fee_df.ExchCode,
            open_today_fee_rate=fee_df.ExchIntraOpenFee * (1 + fee_df.MyBrokerOpenFee),
            open_yest_fee_rate=fee_df.ExchInterOpenFee * (1 + fee_df.MyBrokerOpenFee),
            close_today_fee_rate=fee_df.ExchIntraCloseFee * (1 + fee_df.MyBrokerCloseFee),
            close_yest_fee_rate=fee_df.ExchInterCloseFee * (1 + fee_df.MyBrokerCloseFee),
        ).set_index("key")
        fee_dct = fee_df.rename({
            "Product": "product",
            "ExchCode": "exchange",
            "TradeUnit": "trade_unit",
            "Currency": "currency",
            "FeeMode": "fee_rate_mode"
        }, axis=1).to_dict("index")

        for row in symbol_df.itertuples(index=False):
            detail = self[row.key]
            detail["symbol"] = row.symbol
            detail["exchange"] = row.exchange
            detail["product"] = row.product
            detail["symbol_type"] = "FU"
            self[row.symbol + "F"] = detail
            fee_detail = fee_dct.get(row.product + "@" + row.exchange, None)
            if fee_detail is None:
                continue
            detail["open_today_fee_rate"] = fee_detail["open_today_fee_rate"]
            detail["open_yest_fee_rate"] = fee_detail["open_yest_fee_rate"]
            detail["close_today_fee_rate"] = fee_detail["close_today_fee_rate"]
            detail["close_yest_fee_rate"] = fee_detail["close_yest_fee_rate"]
            detail["trade_unit"] = fee_detail["trade_unit"]
            detail["currency"] = fee_detail["currency"]
            detail["fee_rate_mode"] = fee_detail["fee_rate_mode"]

    # TODO 对于缓存类需要禁止外部修改，后续会重写全部metaclass
    def get_symbol_detail(self, symbol):
        """
        this will be only way to access data in future

        :param symbol: str {symbol}@{exchange}
        :return:
        """
        return self[symbol]

    def __missing__(self, key):
        value = SymbolDetailMapping()
        self[key] = value
        return value


class SymbolDetailMapping(DictMapping):
    def __init__(self, symbol="", product="", symbol_type="", exchange="", fee_rate_mode=False, currency="CNY",
                 trade_unit=1.0, open_today_fee_rate=0.0, open_yest_fee_rate=0.0, close_today_fee_rate=0.0,
                 close_yest_fee_rate=0.0):
        self["symbol"] = symbol
        self["product"] = product
        self["symbol_type"] = symbol_type
        self["exchange"] = exchange
        self["currency"] = currency
        self["trade_unit"] = trade_unit
        self["open_today_fee_rate"] = open_today_fee_rate
        self["open_yest_fee_rate"] = open_yest_fee_rate
        self["close_today_fee_rate"] = close_today_fee_rate
        self["close_yest_fee_rate"] = close_yest_fee_rate
        self["forex_rate"] = 1.0
        self["fee_rate_mode"] = fee_rate_mode


class VsSymbolPositionMapping(DictMapping):
    def __init__(self, vs_id, account, symbol, trading_date, day_night,
                 pnl=0.0, floating_pnl=0.0, fee=0.0, settle_price=0.0,
                 long_pnl=0.0, short_pnl=0.0, long_floating_pnl=0.0, short_floating_pnl=0.0,
                 long_open_volume=0.0, short_open_volume=0.0, long_close_volume=0.0, short_close_volume=0.0,
                 open_today_fee=0.0, open_yest_fee=0.0, close_today_fee=0.0, close_yest_fee=0.0,
                 today_long_pos=0.0, today_short_pos=0.0,
                 today_long_avg_price=0.0, today_short_avg_price=0.0,
                 long_open_cost=0.0, short_open_cost=0.0, long_close_cost=0.0, short_close_cost=0.0,
                 yest_long_pos=0.0, yest_short_pos=0.0,
                 yest_long_avg_price=0.0, yest_short_avg_price=0.0,
                 yest_long_notional=0.0, yest_short_notional=0.0):
        self.cache_key = "vs_symbol_position_{vs_id}_{account}_{symbol}"
        symbol_detail = SymbolDetailDict(trading_date, day_night).get_symbol_detail(symbol)
        if symbol_detail is None:
            return
        self.update(symbol_detail)
        self["vs_id"] = vs_id
        self["account"] = account
        self["symbol"] = symbol
        self["trading_date"] = trading_date
        self["day_night"] = day_night
        self["settle_price"] = settle_price
        self["today_long_pos"] = today_long_pos
        self["today_short_pos"] = today_short_pos
        self["today_long_avg_price"] = today_long_avg_price
        self["today_short_avg_price"] = today_short_avg_price
        self["yest_long_pos"] = yest_long_pos
        self["yest_long_avg_price"] = yest_long_avg_price
        self["yest_short_pos"] = yest_short_pos
        self["yest_short_avg_price"] = yest_short_avg_price
        self["yest_long_notional"] = yest_long_notional
        self["yest_short_notional"] = yest_short_notional
        self["pnl"] = pnl
        self["fee"] = fee
        self["open_today_fee"] = open_today_fee
        self["open_yest_fee"] = open_yest_fee
        self["close_today_fee"] = close_today_fee
        self["close_yest_fee"] = close_yest_fee
        self["floating_pnl"] = floating_pnl
        self["long_pnl"] = long_pnl
        self["short_pnl"] = short_pnl
        self["long_open_volume"] = long_open_volume
        self["short_open_volume"] = short_open_volume
        self["long_close_volume"] = long_close_volume
        self["short_close_volume"] = short_close_volume
        self["long_open_cost"] = long_open_cost
        self["short_open_cost"] = short_open_cost
        self["long_close_cost"] = long_close_cost
        self["short_close_cost"] = short_close_cost
        self["long_floating_pnl"] = long_floating_pnl
        self["short_floating_pnl"] = short_floating_pnl
        self["today_net_cost"] = 0.0

    def calc_pnl(self):
        long_open_volume = self["long_open_volume"]
        short_open_volume = self["short_open_volume"]
        long_close_volume = self["long_close_volume"]
        short_close_volume = self["short_close_volume"]
        settle_price = self["settle_price"]
        long_open_avg_price = self["long_open_cost"] / long_open_volume if long_open_volume else 0
        short_open_avg_price = self["short_open_cost"] / short_open_volume if short_open_volume else 0
        long_close_avg_price = self["long_close_cost"] / long_close_volume if long_close_volume else 0
        short_close_avg_price = self["short_close_cost"] / short_close_volume if short_close_volume else 0
        self["today_long_pos"] = long_open_volume - long_close_volume
        self["today_short_pos"] = short_open_volume - short_close_volume
        self["long_pnl"] = (long_close_avg_price - long_open_avg_price) * long_close_volume
        self["short_pnl"] = (short_open_avg_price - short_close_avg_price) * short_close_volume
        self["pnl"] = self["long_pnl"] + self["short_pnl"]
        self["today_long_notional"] = self["today_long_pos"] * self["settle_price"] * self["trade_unit"]
        self["today_short_notional"] = self["today_short_pos"] * self["settle_price"] * self["trade_unit"]
        self["long_floating_pnl"] = (settle_price - long_open_avg_price) * self["today_long_pos"]
        self["short_floating_pnl"] = (short_open_avg_price - settle_price) * self["today_short_pos"]
        self["floating_pnl"] = self["long_floating_pnl"] + self["short_floating_pnl"]
        self["today_long_avg_price"] = long_open_avg_price
        self["today_short_avg_price"] = short_open_avg_price

    def calc_fee(self):
        self["fee"] = self["open_today_fee"] + self["open_yest_fee"] + self["close_today_fee"] + self["close_yest_fee"]


@TradingDateTTLCache(300)
class LiveClosePrice(DictMapping):
    """
    close price from speed quote

    include stock index etf future close price
    """

    def __init__(self, *, trading_date=None, day_night=None, loop=None):
        """
        try to get live close price from api
        """
        resp = requests.get("http://%s/api/v1/speedquote/equityquote" % config.quote_api_host)
        data = resp.json()["data"]
        for key, value in data.items():
            if "@SZ" in key:
                self[key.replace("@SZ", "@SZSE")] = value["LastPrice"]
            elif "@SH" in key:
                self[key.replace("@SH", "@SSE")] = value["LastPrice"]
            elif ".SZ" in key:
                self[key.replace(".SZ", "@SZSE")] = value["LastPrice"]
            elif ".SH" in key:
                self[key.replace(".SH", "@SSE")] = value["LastPrice"]
            elif "IC" in key:
                self[key.upper() + "@CFFEX"] = value["LastPrice"]
            else:
                self[key] = value["LastPrice"]
        # 000905需要把价格做特殊处理
        self["000905.SH@SSE"] /= 10000
        self.trading_date = trading_date
        self.day_night = day_night


@TradingDateTTLCache(1800, refresh=False)
class KDBClosePrice(DictMapping, Context):
    """
    close price from kdb

    include stock index etf future close price
    """

    def __init__(self, *, trading_date=None, day_night=None):
        if trading_date is None or day_night is None:
            raise ValueError
        self.trading_date = trading_date
        self.day_night = day_night
        offset = 0 if self.day_night == 0 else 1
        self.stock_date = str(self.trade_calendar[self.trading_date, offset]).replace("-", ".")
        self.future_date = self.trading_date.replace("-", ".")
        self.kdb = KdbQuery()
        self.update_future_price()
        self.update_index_price()
        self.update_etf_price()
        self.update_stock_price()

    def update_stock_price(self):
        stock_sql = '.gw.asyncexec[\"select SYMBOL,S_DQ_CLOSE from AShareEODPrices  where  TRADE_DT=%s\";`EquityFactor]' % self.stock_date
        data = self.kdb.async_query(stock_sql)
        for symbol, price in data:
            s = symbol.decode("utf-8")
            s = s.replace(".SZ", "@SZSE").replace(".SH", "@SSE")
            self[s] = price

    def update_etf_price(self):
        etf_sql = '.gw.asyncexec[\"select S_INFO_WINDCODE,S_DQ_CLOSE from ChinaClosedFundEODPrice where date =%s\";`EquityFactor]' % self.stock_date
        data = self.kdb.async_query(etf_sql)
        for symbol, price in data:
            s = symbol.decode("utf-8")
            s = s.replace(".SZ", "@SZSE").replace(".SH", "@SSE")
            self[s] = price

    def update_index_price(self):
        etf_sql = '.gw.asyncexec[\"select SYMBOL,S_DQ_CLOSE from AIndexEODPrices where date =%s\";`EquityFactor]' % self.stock_date
        data = self.kdb.async_query(etf_sql)
        for symbol, price in data:
            s = symbol.decode("utf-8")
            s = s.replace(".SZ", "@SZSE").replace(".SH", "@SSE")
            self[s] = price

    def update_future_price(self):
        if self.day_night == 0:
            sql = '.gw.asyncexec["select SYMBOL,EXCHANGE,SETTLEPRICE from CFuturesEODPrices where TRADE_DT=%s"; `FuturesBasicInfo]' % self.future_date
        else:
            sql = '.gw.asyncexec["select Symbol,Exchange, ClosePrice from EONPrices where date=%s,DataSource=`CTP "; `FuturesBasicInfo ]' % self.future_date
        data = self.kdb.async_query(sql)
        for symbol, exch, price in data:
            s = symbol.decode("utf-8")
            e = exch.decode("utf-8").upper()
            if e == "CZCE" or e == "CFFEX":
                s = s.upper()
            self[s + "@" + e] = price

    def update_forex_price(self):
        if self.day_night == 0:
            sql = '.gw.asyncexec["select SYMBOL,EXCHANGE,SETTLEPRICE from ForeignEODPrices where date= %s,DATASOURCE =`FMarketDB"; `FuturesBasicInfo]' % self.future_date
        else:
            sql = '.gw.asyncexec["select Symbol,Exchange, ClosePrice from EONPrices where date= %s,DataSource =`FMarketDB"; `FuturesBasicInfo]' % self.future_date
        data = self.kdb.async_query(sql)
        for symbol, exch, price in data:
            s = symbol.decode("utf-8").upper()
            e = exch.decode("utf-8").upper()
            self[s + "@" + e] = price


class VsAccountPositionMapping(DictMapping):
    def __init__(self, vs_id, account, trading_date, day_night,
                 accumulated_pnl=0.0, fee=0.0, pnl=0.0,
                 cash=0.0, asset_cash=0.0, available_cash=0.0, total_asset=0.0,
                 position_cash=0.0, long_position_cash=0.0, short_position_cash=0.0):
        self.symbols = DefaultDictWithKey(self.default_symbol)
        self["account"] = account
        self["vs_id"] = vs_id
        self["trading_date"] = trading_date
        self["day_night"] = day_night
        self["accumulated_pnl"] = accumulated_pnl
        self["fee"] = fee
        self["pnl"] = pnl
        self["cash"] = cash
        self["asset_cash"] = asset_cash
        self["total_asset"] = total_asset
        self["available_cash"] = available_cash
        self["position_cash"] = position_cash
        self["long_position_cash"] = long_position_cash
        self["short_position_cash"] = short_position_cash

    def calc_from_symbols(self):
        long_position_cash = 0
        short_position_cash = 0
        position_cash = 0
        cash_change = 0
        fee = 0
        pnl = 0
        for symbol_data in self.symbols.values():
            symbol_data.calc_pnl()
            symbol_data.calc_fee()
            pnl += symbol_data["pnl"] + symbol_data["floating_pnl"]
            long_position_cash += symbol_data["today_long_notional"]
            short_position_cash += symbol_data["today_short_notional"]
            fee += symbol_data["fee"]
            cash_change += symbol_data["today_net_cost"]

        self["long_position_cash"] = long_position_cash
        self["short_position_cash"] = short_position_cash
        self["position_cash"] = long_position_cash + short_position_cash
        self["available_cash"] = self["asset_cash"] + cash_change
        self["total_asset"] = self["position_cash"] + self["available_cash"]
        self["fee"] = fee
        self["pnl"] = pnl

    def default_symbol(self, key):
        val = VsSymbolPositionMapping(vs_id=self["vs_id"], account=self["account"], symbol=key,
                                      trading_date=self["trading_date"], day_night=self["day_night"])
        return val


class VSPositionMapping(DictMapping):
    def __init__(self, vs_id, trading_date, day_night):
        self["vs_id"] = vs_id
        self["trading_date"] = trading_date
        self["day_night"] = day_night
        self.accounts = DefaultDictWithKey(self.default_account)

    def default_account(self, key):
        val = VsAccountPositionMapping(vs_id=self["vs_id"], account=key, trading_date=self["trading_date"],
                                       day_night=self["day_night"])
        return val


class VsPositionDict(dict):
    def __init__(self, trading_date, day_night):
        self.trading_date = trading_date
        self.day_night = day_night

    def __missing__(self, key):
        val = VSPositionMapping(vs_id=key, trading_date=self.trading_date, day_night=self.day_night)
        self[key] = val
        return val

    def printer(self, vs_id_filter=None, account_filter=None, symbol_filter=None):
        if vs_id_filter and not isinstance(vs_id_filter, (tuple, list)):
            vs_id_filter = [vs_id_filter]
        for vs_id in self:
            if vs_id_filter and vs_id not in vs_id_filter:
                continue
            accounts = self[vs_id].accounts
            for account in accounts:
                if account_filter and account_filter != account:
                    continue
                symbols = accounts[account].symbols
                for symbol in symbols:
                    if symbol_filter and symbol_filter != symbol:
                        continue
                    symbol_data = symbols[symbol]
                    pprint(symbol_data)


@TradingDateTTLCache(60)
def get_agg_trade_log(trading_date=None, day_night=None, vs_id=None) -> pd.DataFrame:
    """

    :param trading_date: str %Y-%m-%d
    :param day_night: int 0=DAY 1=NIGHT
    :param vs_id: Generics[int,List[int]]
    :return: pd.DataFrame
    """
    day_night = day_night
    daynight = "NIGHT" if day_night else "DAY"
    if isinstance(vs_id, int):
        vs_id = [vs_id]
    entities_trade_log = [TradeLogs.vstrategy_id, TradeLogs.account, TradeLogs.symbol, TradeLogs.direction,
                          TradeLogs.open_close, TradeLogs.trade_vol, TradeLogs.trade_price,
                          literal_column("FALSE", type_=BOOLEAN).label("is_manual")]
    entities_manual = [SettlementManualTradelog.vstrategy_id, SettlementManualTradelog.account,
                       SettlementManualTradelog.symbol,
                       Case(whens={"BUY": 0}, value=SettlementManualTradelog.direction, else_=1).label(
                           "direction"),
                       Case(whens={"OPEN": 0}, value=SettlementManualTradelog.open_close, else_=1).label(
                           "open_close"),
                       Cast(SettlementManualTradelog.trade_vol, DECIMAL(9, 2)).label("trade_vol"),
                       Cast(SettlementManualTradelog.trade_price, DECIMAL(9, 2)).label("trade_price"),
                       literal_column("TRUE", type_=BOOLEAN).label("is_manual")
                       ]
    query_trade_log = Query(TradeLogs).with_entities(*entities_trade_log).filter(
        TradeLogs.trading_date == trading_date,
        TradeLogs.day_night == day_night,
        TradeLogs.log_type == "3",
        TradeLogs.entrust_status.in_(["p", "c"]),
    )
    query_manual = Query(SettlementManualTradelog).with_entities(*entities_manual).filter(
        SettlementManualTradelog.trading_date == trading_date,
        SettlementManualTradelog.daynight == daynight
    )
    if vs_id:
        query_trade_log = query_trade_log.filter(TradeLogs.vstrategy_id.in_(vs_id))
        query_manual = query_manual.filter(SettlementManualTradelog.vstrategy_id.in_(vs_id))
    sql1 = query_trade_log.statement.compile(compile_kwargs={"literal_binds": True})
    sql2 = query_manual.statement.compile(compile_kwargs={"literal_binds": True})
    exec_sql = " union all ".join([str(sql1), str(sql2)])
    df = pd.read_sql_query(exec_sql, engine)
    df["trade_cost"] = df["trade_vol"] * df["trade_price"]
    return df


# @TradingDateTTLCache(30)
def hedge_monitor_data(position_dct: VsPositionDict, trading_date=None, day_night=None):
    if position_dct is None:
        position_dct = VsPositionDict(trading_date, day_night)
    return position_dct


def fill_today_position(position_dct: VsPositionDict, trading_date=None, day_night=None, vs_id=None, live_close=True):
    """
    fill trade log to position dct and calc volume and cash usage and fee and so on

    :param position_dct:
    :param trading_date: str %Y-%m-%d
    :param day_night: int 0=DAY 1=NIGHT
    :param vs_id: int
    :param live_close: use live close or kdb close price as settle price
    :return:
    """
    trade_log_detail = get_agg_trade_log(trading_date=trading_date, day_night=day_night, vs_id=vs_id)
    if len(trade_log_detail) == 0:
        return position_dct
    symbol_trade_log = trade_log_detail.groupby(["vstrategy_id", "account", "symbol", "direction", "open_close"])
    symbol_summary = symbol_trade_log[["trade_vol", "trade_cost"]].sum()
    symbol_summary["trade_avg_price"] = symbol_summary["trade_cost"] / symbol_summary["trade_vol"]
    close_price_data = LiveClosePrice(trading_date=trading_date, day_night=day_night) if live_close else KDBClosePrice(
        trading_date=trading_date, day_night=day_night)
    for val in symbol_summary.itertuples():
        idx = val.Index
        vs_id = idx[0]
        account = idx[1]
        symbol = idx[2]
        direction = idx[3]
        open_close = idx[4]
        symbol_data = position_dct[vs_id].accounts[account].symbols[symbol]
        trade_unit = symbol_data["trade_unit"]
        settle_price = close_price_data.get(symbol_data["symbol"] + "@" + symbol_data["exchange"], 0.0)
        symbol_data["settle_price"] = settle_price
        vol = val.trade_vol
        cost = val.trade_cost * trade_unit
        if direction == 0 and open_close == 0:
            symbol_data["long_open_volume"] += vol
            symbol_data["long_open_cost"] += cost
            symbol_data["today_net_cost"] -= cost
            fee_rate = symbol_data["open_today_fee_rate"]
            fee = fee_rate * vol if symbol_data["fee_rate_mode"] else fee_rate * cost
            symbol_data["open_today_fee"] += fee
        elif (direction == 1 and open_close == 0) or direction == 3:
            symbol_data["short_open_volume"] += vol
            symbol_data["short_open_cost"] += cost
            symbol_data["today_net_cost"] -= cost
            fee_rate = symbol_data["open_today_fee_rate"]
            fee = fee_rate * vol if symbol_data["fee_rate_mode"] else fee_rate * cost
            symbol_data["open_today_fee"] = fee
        elif direction == 1 and open_close > 0:
            symbol_data["long_close_volume"] += vol
            symbol_data["long_close_cost"] += cost
            symbol_data["today_net_cost"] += cost
            if open_close < 3:
                fee_rate = symbol_data["close_today_fee_rate"]
                fee = fee_rate * vol if symbol_data["fee_rate_mode"] else fee_rate * cost
                symbol_data["close_today_fee"] += fee
            else:
                fee_rate = symbol_data["close_yest_fee_rate"]
                fee = fee_rate * vol if symbol_data["fee_rate_mode"] else fee_rate * cost
                symbol_data["close_yest_fee"] += fee
        elif (direction == 0 and open_close > 0) or direction == 4 or direction == 5:
            symbol_data["short_close_volume"] += vol
            symbol_data["short_close_cost"] += cost
            symbol_data["today_net_cost"] += cost
            if open_close < 3:
                fee_rate = symbol_data["close_today_fee_rate"]
                fee = fee_rate * vol if symbol_data["fee_rate_mode"] else fee_rate * cost
                symbol_data["close_today_fee"] += fee
            else:
                fee_rate = symbol_data["close_yest_fee_rate"]
                fee = fee_rate * vol if symbol_data["fee_rate_mode"] else fee_rate * cost
                symbol_data["close_yest_fee"] += fee
    return position_dct


def fill_last_vstrategy_data(position_dct: VsPositionDict, trading_date=None, day_night=None, vs_id=None):
    """
    fill last trading segment `vs_base` data to position_dct

    :param position_dct:
    :param trading_date: str %Y-%m-%d
    :param day_night: int 0=DAY 1=NIGHT
    :param vs_id: int
    :return:
    """
    if isinstance(vs_id, int):
        vs_id = [vs_id]
    entities = [VsBase.vstrategy_id, VsBase.accumulated_pnl, VsBase.cash]
    daynight = "NIGHT" if day_night else "DAY"
    with session_context() as sc:
        vs_result = sc.query(VsBase).with_entities(*entities).filter(VsBase.settle_date == trading_date,
                                                                     VsBase.daynight == daynight)
        if vs_id:
            vs_result = vs_result.filter(VsBase.vstrategy_id.in_(vs_id))
        for vs_id, accumulated_pnl, cash in vs_result:
            vs_data = position_dct[vs_id]
            vs_data["accumulated_pnl"] = float(accumulated_pnl)
            vs_data["cash"] = float(cash)
    return position_dct


def fill_last_account_data(position_dct: VsPositionDict, trading_date=None, day_night=None, vs_id=None):
    """
    fill last trading segment `vs_account` data to position_dct

    :param trading_date: str %Y-%m-%d
    :param day_night: int 0=DAY 1=NIGHT
    :param vs_id: int
    :param vs_id:
    :return:
    """
    if isinstance(vs_id, int):
        vs_id = [vs_id]
    entities = [
        VsAccount.vstrategy_id,
        VsAccount.account,
        VsAccount.accumulated_pnl,
        VsAccount.cash,
        VsAccount.available_cash,
        VsAccount.asset_cash,
        VsAccount.total_asset
    ]
    daynight = "NIGHT" if day_night else "DAY"
    with session_context() as sc:
        account_result = sc.query(VsAccount).with_entities(*entities).filter(VsAccount.settle_date == trading_date,
                                                                             VsAccount.daynight == daynight)
        if vs_id:
            account_result = account_result.filter(VsAccount.vstrategy_id.in_(vs_id))
        for vs_id, account, accumulated_pnl, cash, available_cash, asset_cash, total_asset in account_result:
            account_data = position_dct[vs_id].accounts[account]
            account_data["accumulated_pnl"] = float(accumulated_pnl)
            account_data["cash"] = float(cash)
            account_data["available_cash"] = float(available_cash)
            account_data["asset_cash"] = float(asset_cash)
            account_data["total_asset"] = float(total_asset)
    return position_dct


def fill_last_symbol_data(position_dct: VsPositionDict, trading_date=None, day_night=None, vs_id=None, live_close=True):
    """
    fill last trading segment `vs_position` data to position_dct
    :param position_dct:
    :param trading_date: str %Y-%m-%d
    :param day_night: int 0=DAY 1=NIGHT
    :param vs_id: int
    :param live_close: use live close or kdb close price as settle price
    :return:
    """
    entities = [VsPosition.vstrategy_id, VsPosition.account, VsPosition.symbol,
                VsPosition.today_long_pos,
                VsPosition.today_short_pos,
                VsPosition.today_long_avg_price,
                VsPosition.today_short_avg_price,
                VsPosition.today_settle_price
                ]
    if isinstance(vs_id, int):
        vs_id = [vs_id]
    daynight = "NIGHT" if day_night else "DAY"
    close_price_data = LiveClosePrice(trading_date=trading_date, day_night=day_night) if live_close else KDBClosePrice(
        trading_date=trading_date, day_night=day_night)
    with session_context() as sc:
        position_result = sc.query(VsPosition).with_entities(*entities).filter(VsPosition.settle_date == trading_date,
                                                                               VsPosition.daynight == daynight)
        if vs_id:
            position_result = position_result.filter(VsPosition.vstrategy_id.in_(vs_id))
        for vs_id, account, symbol, long_pos, short_pos, long_avg_price, short_avg_price, yest_settle_price in position_result:
            symbol_data = position_dct[vs_id].accounts[account].symbols[symbol]
            symbol_data["yest_long_pos"] = float(long_pos)
            symbol_data["yest_short_pos"] = float(short_pos)
            symbol_data["yest_long_avg_price"] = float(long_avg_price)
            symbol_data["yest_short_avg_price"] = float(short_avg_price)
            price = float(yest_settle_price)
            unit = symbol_data["trade_unit"]
            cost = price * unit
            symbol_data["short_open_cost"] = symbol_data["yest_short_pos"] * cost
            symbol_data["long_open_cost"] = symbol_data["yest_long_pos"] * cost
            symbol_data["short_open_volume"] = symbol_data["yest_short_pos"]
            symbol_data["long_open_volume"] = symbol_data["yest_long_pos"]
            settle_price = close_price_data.get(symbol_data["symbol"] + "@" + symbol_data["exchange"], 0.0)
            symbol_data["settle_price"] = settle_price
    return position_dct


def copy_last_postion(position_dct: VsPositionDict):
    """
    task yest symbol postion as today init position
    :param position_dct:
    :return:
    """
    for vs_id in position_dct:
        accounts = position_dct[vs_id].accounts
        for account in accounts:
            symbols = accounts[account].symbols
            for symbol in symbols:
                symbol_data = symbols[symbol]
                symbol_data["today_long_pos"] = symbol_data["yest_long_pos"]
                symbol_data["today_short_pos"] = symbol_data["yest_short_pos"]
                symbol_data["today_long_avg_price"] = symbol_data["yest_long_avg_price"]
                symbol_data["today_short_avg_price"] = symbol_data["yest_short_avg_price"]
    return position_dct


def convert_hedge_type(hedge_type):
    hedge_type = hedge_type.lower()
    if hedge_type == 'full':
        return 1
    elif hedge_type == 'half':
        return 0.5
    elif hedge_type == 'beta_60':
        return 0.6
    elif hedge_type == 'beta_70':
        return 0.7
    elif hedge_type == 'position':
        return 1
    return None


class HedgeSymbolDetail(dict):
    def __init__(self, symbol):
        self["symbol"] = symbol
        self["exchange"] = ""
        self["long_position_cash"] = 0
        self["short_position_cash"] = 0
        self["position_cash"] = 0
        self["long_position"] = 0
        self["short_position"] = 0
        self["available_cash"] = 0
        self["hedge_ratio"] = 0.0
        self["s_id"] = 0
        self["vs_id"] = 0
        self["id_no"] = ""
        self["alpha_s_id"] = 0
        self["alpha_id_no"] = ""


class HedgeAccount(dict):
    def __init__(self, vs_id, account):
        self["vs_id"] = vs_id
        self["account"] = account
        self["s_id"] = 0
        self["long_position_cash"] = 0
        self["short_position_cash"] = 0
        self["position_cash"] = 0
        self["long_position"] = 0
        self["short_position"] = 0
        self["monetary_fund_position_cash"] = 0.0
        self["available_cash"] = 0
        self["hedge_ratio"] = 0
        self["alpha_s_id"] = 0
        self["alpha_id_no"] = ""
        self["gap"] = 0.0
        self["id_no"] = ""


class HedgeStrategies(dict):
    def __init__(self):
        self["summary"] = DefaultDictWithKey(lambda x: DefaultDictWithKey(lambda y: HedgeAccount(vs_id=x, account=y)))
        self["detail"] = DefaultDictWithKey(lambda x: HedgeSymbolDetail(x))


class AlphaStrategies(dict):
    def __init__(self):
        self["summary"] = DefaultDictWithKey(lambda x: DefaultDictWithKey(lambda y: HedgeAccount(vs_id=x, account=y)))
        self["detail"] = DefaultDictWithKey(lambda x: dict())


def hedge_data():
    entities = [NewStrategySet.name, VStrategies.id, Strategy.id, Strategy.id_no, Strategy.strategy_type,
                Strategy.hedge_type]
    today = str(Context.trade_calendar["today"])
    # 查找所有对冲端，alpha端策略
    with session_context() as sc:
        strategies = sc.query(NewStrategySet
                              ).join(
            NewStrategySetdetail,
            NewStrategySet.id == NewStrategySetdetail.strategy_set_id
        ).join(
            VStrategies,
            VStrategies.id == NewStrategySetdetail.vs_id
        ).join(
            Strategy,
            VStrategies.strategy_id == Strategy.id
        ).filter(
            Strategy.strategy_type.in_([15, 20]),
            VStrategies.status == 15
        ).with_entities(*entities)
        data = [{
            "strategy_set_name": st[0],
            "vs_id": st[1],
            "s_id": st[2],
            "id_no": st[3],
            "strategy_type": st[4],
            "hedge_ratio": convert_hedge_type(st[5])
        } for st in strategies]
    vs_ids = [i["vs_id"] for i in data]
    dct = hedge_monitor_data(None, trading_date=today, day_night=0)
    dct = fill_last_vstrategy_data(dct, trading_date=today, day_night=1, vs_id=vs_ids)
    dct = fill_last_account_data(dct, trading_date=today, day_night=1, vs_id=vs_ids)
    dct = fill_last_symbol_data(dct, trading_date=today, day_night=1, vs_id=vs_ids)
    dct = copy_last_postion(dct)
    dct = fill_today_position(dct, trading_date=today, day_night=0, vs_id=vs_ids)
    result = defaultdict(
        lambda: dict(
            hedge_available_cash=1, hedge_long_position_cash=1, hedge_short_position_cash=1, hedge_position_cash=0.0,
            alpha_available_cash=1, alpha_long_position_cash=1, alpha_short_position_cash=1, alpha_position_cash=0.0,
            hedge_strategies=defaultdict(lambda: HedgeStrategies()),
            alpha_strategies=AlphaStrategies(), hedge_ratio=0.0,
        )
    )
    # 计算alpha和hedge的仓位
    for i in data:
        vs_id = i["vs_id"]
        strategy_set_detail = result[i["strategy_set_name"]]
        for account_name, account_data in dct[vs_id].accounts.items():
            # alpha策略计算
            account_data.calc_from_symbols()
            if account_data["long_position_cash"] == 0 and account_data["short_position_cash"] == 0:
                continue
            if i["strategy_type"] == "15":
                alpha_account_summary = strategy_set_detail["alpha_strategies"]["summary"][vs_id][account_name]
                strategy_set_detail["alpha_strategies"]["detail"][vs_id] = account_data
                account_data["s_id"] = i["s_id"]
                account_data["id_no"] = i["id_no"]
                account_data["hedge_ratio"] = i["hedge_ratio"]
                alpha_account_summary["long_position_cash"] += account_data["long_position_cash"]
                alpha_account_summary["short_position_cash"] += account_data["short_position_cash"]
                alpha_account_summary["position_cash"] += account_data["long_position_cash"] - \
                                                          account_data["short_position_cash"]
                alpha_account_summary["available_cash"] += account_data["available_cash"]
                alpha_account_summary["s_id"] = i["s_id"]
                alpha_account_summary["id_no"] = i["id_no"]
                strategy_set_detail["alpha_long_position_cash"] += account_data["long_position_cash"]
                strategy_set_detail["alpha_short_position_cash"] += account_data["short_position_cash"]
                strategy_set_detail["alpha_available_cash"] += account_data["available_cash"]
            # 对冲端策略计算
            else:
                strategy_set_detail["hedge_available_cash"] += account_data["available_cash"]
                for symbol in account_data.symbols.values():
                    symbol_type = symbol["symbol_type"]
                    hedge_products = strategy_set_detail["hedge_strategies"]
                    hedge_account_summary = hedge_products[symbol_type]["summary"][vs_id][account_name]
                    hedge_account_summary["long_position_cash"] += symbol["today_long_notional"]
                    hedge_account_summary["short_position_cash"] += symbol["today_short_notional"]
                    hedge_account_summary["position_cash"] += symbol["today_long_notional"] - symbol[
                        "today_short_notional"]
                    strategy_set_detail["hedge_long_position_cash"] += symbol["today_long_notional"]
                    strategy_set_detail["hedge_short_position_cash"] += symbol["today_short_notional"]
                    hedge_account_summary["available_cash"] = account_data["available_cash"]
                    hedge_account_summary["s_id"] = i["s_id"]
                    hedge_account_summary["id_no"] = i["id_no"]
                    hedge_account_summary["hedge_ratio"] = i["hedge_ratio"]
                    if not symbol_type or symbol_type == "A":
                        continue
                    hedge_detail = hedge_products[symbol_type]["detail"][symbol["symbol"]]
                    hedge_detail["exchange"] = symbol["exchange"]
                    hedge_detail["s_id"] = i["s_id"]
                    hedge_detail["vs_id"] = vs_id
                    hedge_detail["id_no"] = i["id_no"]
                    hedge_detail["short_position"] += symbol["today_short_pos"]
                    hedge_detail["short_position_cash"] += symbol["today_short_notional"]
                    hedge_detail["long_position"] += symbol["today_long_pos"]
                    hedge_detail["long_position_cash"] += symbol["today_long_notional"]
                    hedge_detail["position_cash"] += symbol["today_long_notional"] - symbol["today_short_notional"]
                    hedge_detail["close_price"] = symbol["settle_price"]
        strategy_set_detail["hedge_position_cash"] = strategy_set_detail["hedge_long_position_cash"] - \
                                                     strategy_set_detail["hedge_short_position_cash"]
        strategy_set_detail["alpha_position_cash"] = strategy_set_detail["alpha_long_position_cash"] - \
                                                     strategy_set_detail["alpha_short_position_cash"]
    hedge_relation_detail = VsHedgeRelationDetail(trading_date=today, day_night=0)
    zz500_close_price = LiveClosePrice(trading_date=today, day_night=0).get("000905.SH@SSE", 0.0) * 200
    # 计算对冲比例
    for fund_hedge_detail in result.values():
        fs = fund_hedge_detail["hedge_short_position_cash"] + fund_hedge_detail["alpha_short_position_cash"]
        fl = fund_hedge_detail["hedge_long_position_cash"] + fund_hedge_detail["alpha_long_position_cash"]
        fund_hedge_detail["hedge_ratio"] = fs / fl
        hedge_strategies = fund_hedge_detail["hedge_strategies"]
        for alpha_id, alpha_detail in fund_hedge_detail["alpha_strategies"]["detail"].items():
            # 以alpha id 作为key，查找相对应的hedge id
            hedge_ids = hedge_relation_detail.get(alpha_id, None)
            if hedge_ids is None:
                continue
            for hedge_id in hedge_ids:
                # 更新对应hedge_summary的对冲比率，alpha信息，gap
                for hedge_product, hedge_product_detail in hedge_strategies.items():
                    hedge_summary = hedge_product_detail["summary"].get(hedge_id, None)
                    if hedge_summary is None:
                        continue
                    for hedge_acc in hedge_summary.values():
                        sp = hedge_acc["short_position_cash"] + alpha_detail["short_position_cash"]
                        lp = hedge_acc["long_position_cash"] + alpha_detail["long_position_cash"]
                        hedge_acc["hedge_ratio"] = sp / lp
                        hedge_acc["alpha_s_id"] = alpha_detail["s_id"]
                        hedge_acc["alpha_id_no"] = alpha_detail["id_no"]
                        if hedge_product == "FU":
                            hedge_acc["gap"] = (fl - fs) / zz500_close_price
                    # 给 hedge_detail 加上alpha_s_id
                    # 这边有待改进，也许需要在上面计算hedge仓位的时候加上alpha信息，而不是在这边遍历，导致复杂度升高
                    for hedge_symbol_detail in hedge_product_detail["detail"].values():
                        if hedge_symbol_detail["vs_id"] != hedge_id:
                            continue
                        hedge_symbol_detail["alpha_s_id"] = alpha_detail["s_id"]
                        hedge_symbol_detail["alpha_id_no"] = alpha_detail["id_no"]

    return result


if __name__ == '__main__':
    b = hedge_data()
    for strategy_set_data in b.values():
        alpha_data = strategy_set_data["alpha_strategies"]
        alpha_data["detail"] = [alpha_data["detail"][i] for i in sorted(alpha_data["detail"])]
        alpha_data["summary"] = [alpha_data["summary"][i][j] for i in sorted(alpha_data["summary"]) for j in
                                 sorted(alpha_data["summary"][i])]
        for h_data in strategy_set_data["hedge_strategies"].values():
            h_data["detail"] = [h_data["detail"][i] for i in sorted(h_data["detail"])]
            h_data["summary"] = [h_data["summary"][i][j] for i in sorted(h_data["summary"]) for j in
                                 sorted(h_data["summary"][i])]
    data = json.dumps(b, indent=4, ensure_ascii=False)
    with open("pp.json", "w") as f:
        f.write(data)

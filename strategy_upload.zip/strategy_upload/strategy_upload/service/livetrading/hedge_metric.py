# -*-coding:utf-8-*-

import datetime
from sqlalchemy import tuple_, func

from service.back_test.models import Strategy, VStrategies, VStrategyAccountDetail, StrategyPerfInput
from service.account_funds.models import AccountBalanceCounter
from service.back_test.live_trading_models import FundHedgeConfig
from service.statistic.baseservice import ServiceBaseService
from db import session
from extensions import sentry

import consts


class FundHedgeService(ServiceBaseService):

    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.sc = session()
        self.trading_date, self.day_night = StrategyPerfInput.get_trading_date_day_night()
        self.now_time = datetime.datetime.now().strftime('%H%M')
        self.hedge_config = {}
        self.accounts = {}
        self.symbols = set()
        self.future_trade_unit = {
            'IC': 200,
            'IF': 300,
            'IH': 300,
        }
        self.vs_detail = {}
        self.vs_ids_str = ''
        self.last_day_position = {}
        self.trading_data = {}

        super(FundHedgeService, self).__init__()

    def __del__(self):
        self.sc.close()
        self.kdb.release()

    def get_hedge_config(self):
        hedges = self.sc.query(FundHedgeConfig)
        hedge_config = {}
        accounts = {}
        for h in hedges:
            h_config = hedge_config.setdefault(h.hedge_key, {
                'name': '',
                'stock': [],
                'future': [],
                'account': {
                }
            })
            h_config['name'] = h.hedge_key
            if h.account_type == 'STOCK':
                h_config['stock'].append(h.account)
            elif h.account_type == 'FUTURE':
                h_config['future'].append(h.account)
            h_config['account'][h.account] = {
                'account': h.account,
                'account_type': h.account_type,
                'min_cash': float(h.min_cash),
                'max_cash': float(h.max_cash),
                'total_asset': 0,
                'available_cash': 0,
            }
            accounts[h.account] = {
                'account': h.account,
                'account_type': h.account_type,
                'total_asset': 0,
                'available_cash': 0,
                'strategy_cash': 0,
            }
        self.hedge_config = hedge_config
        self.accounts = accounts

    def get_account_total_asset(self):
        accounts_asset = self.sc.query(
            AccountBalanceCounter.account.label('account'),
            AccountBalanceCounter.balance.label('balance'),
            AccountBalanceCounter.available.label('available'),
        ).filter(
            tuple_(
                AccountBalanceCounter.account,
                AccountBalanceCounter.trading_day
            ).in_(
                self.sc.query(
                    AccountBalanceCounter.account,
                    func.max(AccountBalanceCounter.trading_day)
                ).filter(
                    AccountBalanceCounter.account.in_(self.accounts.keys())
                ).group_by(
                    AccountBalanceCounter.account
                )
            )
        )

        for acc in accounts_asset:
            self.accounts[acc.account]['total_asset'] = float(acc.balance)
            if self.accounts[acc.account]['account_type'] == 'FUTURE':
                self.accounts[acc.account]['available_cash'] = float(acc.available)

    def get_vstrategies(self):
        vstrategies = self.sc.query(
            VStrategies.id.label('vs_id'),
            VStrategyAccountDetail.account.label('account'),
            VStrategyAccountDetail.amount.label('amount'),
            Strategy.id.label('s_id'),
            Strategy.id_no.label('s_id_no'),
            Strategy.hedge.label('s_hedge'),
            Strategy.hedge_type.label('s_hedge_type'),
        ).join(
            Strategy, Strategy.id == VStrategies.strategy_id
        ).join(
            VStrategyAccountDetail, VStrategyAccountDetail.vstrategy_id == VStrategies.id
        ).filter(
            VStrategyAccountDetail.account.in_(self.accounts.keys()),
            VStrategies.status == 15
        )
        vs_detail = {}
        for vs in vstrategies:
            vs_d = vs_detail.setdefault(vs.vs_id, {
                'vs_id': vs.vs_id,
                's_id': vs.s_id,
                'id_no': vs.s_id_no,
                'hedge': vs.s_hedge,
                'hedge_type': vs.s_hedge_type or '',
                'account': [],
                'cashio': 0,
                'accumulated_pnl': 0,
                'today_pnl': 0,
                'fee': 0,
                'total_asset': 0,
            })
            vs_d['account'].append(vs.account)
            vs_d['cashio'] += float(vs.amount)
        self.vs_detail = vs_detail
        self.vs_ids_str = ','.join(map(str, self.vs_detail.keys()))
        return True

    def get_vs_total_asset(self):
        self.get_last_day_position()
        self.get_current_day_trading_logs()
        for v_id, vs_d in self.vs_detail.items():
            pnl = self.get_vs_pnl(v_id)
            vs_d['today_pnl'] = pnl['pnl']
            vs_d['fee'] = pnl['fee']
            vs_d['total_asset'] = vs_d['cashio'] + vs_d['accumulated_pnl'] + vs_d['today_pnl']
            vs_d['hedge_rate'] = FundHedgeService.convert_hedge_type(vs_d['hedge_type'])
            vs_d['hedge_product'] = FundHedgeService.convert_hedge(vs_d['hedge'])
            vs_d['position_cash'] = pnl['position_cash']
            vs_d['ic_cash'] = pnl['ic_cash']
            vs_d['if_cash'] = pnl['if_cash']
            vs_d['ih_cash'] = pnl['ih_cash']
            vs_d['ic_vol'] = pnl['ic_vol']
            vs_d['if_vol'] = pnl['if_vol']
            vs_d['ih_vol'] = pnl['ih_vol']
            vs_d['future_hedge_cash'] = 0
            vs_d['stock_hedge_cash'] = 0
            vs_d['fee'] = pnl['fee']
            vs_d_acc = self.accounts[vs_d['account'][0]]
            if vs_d_acc['account_type'] == 'STOCK':
                # vs_d_acc['strategy_cash'] += vs_d['total_asset']
                vs_d_acc['strategy_cash'] += (vs_d['cashio'] + vs_d['accumulated_pnl'])
                vs_d['stock_hedge_cash'] = pnl['position_cash']  # vs_d['total_asset'] * vs_d['hedge_rate']
                vs_d['account_type'] = 'STOCK'
            else:
                vs_d['account_type'] = 'FUTURE'
        return True

    def get_vs_pnl(self, vs_id):
        v_trade_d = self.trading_data.get(vs_id, {})
        pnl, fee = 0, 0
        position_cash = 0
        ic_cash = 0
        ih_cash = 0
        if_cash = 0
        ic_vol = 0
        ih_vol = 0
        if_vol = 0

        for k, s_trade_d in v_trade_d.items():
            symbol = s_trade_d['symbol']
            if symbol in ('204001', '131810'):
                continue
            currency = 'CNY'
            trade_unit = self.get_symbol_trade_unit(symbol, currency)
            exchange_rate = 1
            long_fee, short_fee = 0, 0
            if s_trade_d['bov'] + s_trade_d['sov'] > 0:
                long_fee_data = {
                    'symbol': symbol,
                    'currency': currency,
                    'direction': 0,
                    'open_close': 0,
                    'exchange_rate': exchange_rate,
                    'volume': s_trade_d['bov'] + s_trade_d['sov'],
                    'turnover': (s_trade_d['bon'] + s_trade_d['son']) * trade_unit,
                    'trade_unit': trade_unit,
                }
                try:
                    long_fee = self.cal_fee(long_fee_data)
                except Exception as e:
                    sentry.captureException()
            if s_trade_d['scv'] + s_trade_d['bcv'] > 0:
                short_fee_data = {
                    'symbol': symbol,
                    'currency': currency,
                    'direction': 1,
                    'open_close': 1,
                    'exchange_rate': exchange_rate,
                    'volume': s_trade_d['scv'] + s_trade_d['bcv'],
                    'turnover': (s_trade_d['scn'] + s_trade_d['bcn']) * trade_unit,
                    'trade_unit': trade_unit,
                }
                try:
                    short_fee = self.cal_fee(short_fee_data)
                except Exception as e:
                    sentry.captureException()
            try:
                if symbol in ('204001', '131810'):
                    last_price = 0
                else:
                    last_price = self.quote_data[symbol]['LastPrice']
                if last_price < 0:
                    raise ValueError('%s, %s, last price error' % (symbol, last_price))
                if symbol.isdigit() and ('0800' <= self.now_time <= '0925'):
                    last_price = 0
                    raise ValueError('%s, %s, last price error2' % (symbol, last_price))
            except Exception as e:
                last_price = 0
                if s_trade_d['last_bov'] + s_trade_d['bov'] + s_trade_d['sov'] + s_trade_d['last_sov']:
                    last_price = (
                                         s_trade_d['last_bon'] + s_trade_d['bon'] + s_trade_d['son'] + s_trade_d[
                                     'last_son']
                                 ) / float(
                        s_trade_d['last_bov'] + s_trade_d['bov'] + s_trade_d['sov'] + s_trade_d['last_sov'])

            long_pnl = last_price * (
                    s_trade_d['last_bov'] + s_trade_d['bov'] - s_trade_d['scv']
            ) + s_trade_d['scn'] - (s_trade_d['last_bon'] + s_trade_d['bon'])

            short_pnl = (s_trade_d['last_son'] + s_trade_d['son']) - s_trade_d['bcn'] - last_price * (
                    s_trade_d['last_sov'] + s_trade_d['sov'] - s_trade_d['bcv']
            )

            _pos = abs((
                               s_trade_d['last_bov'] + s_trade_d['bov'] - s_trade_d['scv']
                       ) - (
                               s_trade_d['last_sov'] + s_trade_d['sov'] - s_trade_d['bcv']
                       ))
            pos_cash = last_price * _pos * trade_unit
            if 'IC' in symbol:
                if self.quote_data.get('000905.SH', {}).get('LastPrice', 0):
                    _price = self.quote_data['000905.SH']['LastPrice'] / 10000
                    pos_cash = pos_cash * _price / last_price

                ic_cash += pos_cash
                ic_vol += _pos
                self.symbols.add(symbol)
            elif 'IF' in symbol:
                if_cash += pos_cash
                if_vol += _pos
                self.symbols.add(symbol)
            elif 'IH' in symbol:
                ih_cash += pos_cash
                ih_vol += _pos
                self.symbols.add(symbol)
            position_cash += pos_cash

            fee += long_fee + short_fee
            pnl += ((long_pnl + short_pnl) * exchange_rate * trade_unit - long_fee - short_fee)

        return {
            'pnl': pnl,
            'fee': fee,
            'position_cash': position_cash,
            'ic_cash': ic_cash,
            'if_cash': if_cash,
            'ih_cash': ih_cash,
            'ic_vol': ic_vol,
            'if_vol': if_vol,
            'ih_vol': ih_vol,
        }

    def get_current_day_trading_logs(self):
        """
        :TODO:  highly duplicated code with  function  in strategy_upload\strategy_upload\service\statistic\investment.py  which has the same name. 
        """
        if not self.vs_detail:
            return False

        trading_data = {}

        sql = """select vstrategy_id, symbol, account, direction, open_close, sum(trade_vol), sum(trade_vol* trade_price) from
          ((select vstrategy_id, symbol, account, direction, open_close, trade_vol,  trade_price
          from trade_logs  where vstrategy_id in ({vs_ids_str}) and trading_date={trading_date} and log_type='3' and entrust_status in ('p', 'c'))
          UNION all (
           select vstrategy_id, symbol, account,
            case direction when 'BUY' then 0 when 'SELL' then 1 end as direction,
            case open_close when 'OPEN' then 0 when 'CLOSE' then 1 end as open_close,
           trade_vol,  trade_price
           from settlement_manual_tradelogs where vstrategy_id in ({vs_ids_str}) and trading_date={trading_date}
          )) as a
         group by vstrategy_id, symbol, account, direction, open_close
        """.format(vs_ids_str=self.vs_ids_str, trading_date=self.trading_date)

        for r in self.sc.execute(sql):
            v_id = r[0]
            sym = r[1]
            acc = r[2]
            d_flag = int(r[3])
            o_flag = int(r[4])
            qty = float(r[5])
            amount = float(r[6])
            v_trade = trading_data.setdefault(v_id, {})
            v_sym_trade = v_trade.setdefault('%s|%s' % (sym, acc), {
                'symbol': sym,
                'account': acc,
                'bov': 0,
                'bon': 0,
                'scv': 0,
                'scn': 0,
                'sov': 0,
                'son': 0,
                'bcv': 0,
                'bcn': 0,
                'last_bov': 0,
                'last_bon': 0,
                'last_sov': 0,
                'last_son': 0,
                'last_long_freeze': 0,
                'last_short_freeze': 0,
                'last_settle_price': 0,
            })

            if d_flag == consts.Direction.buy.value and o_flag == consts.OpenClose.open.value:
                # buy open
                v_sym_trade['bov'] += qty
                v_sym_trade['bon'] += amount
            elif d_flag == consts.Direction.sell.value and o_flag == consts.OpenClose.open.value:
                # sell open
                v_sym_trade['sov'] += qty
                v_sym_trade['son'] += amount
            elif d_flag == consts.Direction.sell.value:
                # sell close
                v_sym_trade['scv'] += qty
                v_sym_trade['scn'] += amount
            elif d_flag == consts.Direction.buy.value:
                # buy close
                v_sym_trade['bcv'] += qty
                v_sym_trade['bcn'] += amount

        for v_id, pos in self.last_day_position.items():
            v_trade = trading_data.setdefault(v_id, {})
            for k, sym_pos in pos.items():
                v_sym_trade = v_trade.setdefault(k, {
                    'symbol': sym_pos['symbol'],
                    'account': sym_pos['account'],
                    'bov': 0,
                    'bon': 0,
                    'scv': 0,
                    'scn': 0,
                    'sov': 0,
                    'son': 0,
                    'bcv': 0,
                    'bcn': 0,
                    'last_bov': 0,
                    'last_bon': 0,
                    'last_sov': 0,
                    'last_son': 0,
                    'last_long_freeze': 0,
                    'last_short_freeze': 0,
                    'last_settle_price': 0,
                })
                v_sym_trade['last_bov'] += sym_pos['long_pos']
                v_sym_trade['last_bon'] += sym_pos['long_pos'] * sym_pos['settle_price']
                v_sym_trade['last_sov'] += sym_pos['short_pos']
                v_sym_trade['last_son'] += sym_pos['short_pos'] * sym_pos['settle_price']
                v_sym_trade['last_long_freeze'] = sym_pos.get('long_freeze', 0)
                v_sym_trade['last_short_freeze'] = sym_pos.get('short_freeze', 0)
                v_sym_trade['last_settle_price'] = sym_pos['settle_price']
        self.trading_data = trading_data
        return True

    def get_last_day_position(self):
        data = {}
        if not self.vs_detail:
            return False

        if self.day_night == 0:
            sql = """
            select vstrategy_id, symbol, today_long_pos, today_short_pos, today_settle_price, account,
            today_long_freeze_pos, today_short_freeze_pos
            from vs_positions
            where vstrategy_id in ({vs_ids_str}) and settle_date = {settle_date}
              and daynight='NIGHT' and (today_long_pos > 0 or today_short_pos >0)
            """.format(
                settle_date=self.trading_date, vs_ids_str=self.vs_ids_str
            )
            # Duplicated code with the 'else' branch.
            # for r in self.sc.execute(sql):
            #     v_id = r[0]
            #     sym = r[1]
            #     acc = r[5]
            #     v_pos = data.setdefault(v_id, {})
            #     v_pos['%s|%s' % (sym, acc)] = {
            #         'symbol': sym,
            #         'account': acc,
            #         'long_pos': float(r[2]),
            #         'short_pos': float(r[3]),
            #         'settle_price': float(r[4]),
            #         'long_freeze': float(r[6]),
            #         'short_freeze': float(r[7]),
            #     }
        else:
            sql = """
            select vstrategy_id, symbol, today_long_pos, today_short_pos, today_settle_price, account,
            today_long_freeze_pos, today_short_freeze_pos
            from vs_positions
            where vstrategy_id in ({vs_ids_str}) and settle_date = (select max(settle_date) from vs_base where daynight='DAY')
            and daynight='DAY' and (today_long_pos > 0 or today_short_pos >0)
            """.format(vs_ids_str=self.vs_ids_str)

        for r in self.sc.execute(sql):
            v_id = r[0]
            sym = r[1]
            acc = r[5]
            v_pos = data.setdefault(v_id, {})
            v_pos['%s|%s' % (sym, acc)] = {
                'symbol': sym,
                'account': acc,
                'long_pos': float(r[2]),
                'short_pos': float(r[3]),
                'settle_price': float(r[4]),
                'long_freeze': float(r[6]),
                'short_freeze': float(r[7]),
            }
        self.last_day_position = data

        sql = """
        select vstrategy_id, accumulated_pnl from vs_base where (vstrategy_id, settle_date) in (
        select vstrategy_id, max(settle_date) from vs_base where vstrategy_id in ({vs_ids_str}) and daynight='DAY' group by vstrategy_id
        ) and daynight='DAY'
        """.format(vs_ids_str=self.vs_ids_str)
        for r in self.sc.execute(sql):
            self.vs_detail[r[0]]['accumulated_pnl'] = float(r[1])

        return True

    @staticmethod
    def convert_hedge_type(hedge_type):
        hedge_type = hedge_type.lower()
        if hedge_type == 'full':
            return 1
        elif hedge_type == 'half':
            return 0.5
        elif hedge_type == 'beta_60':
            return 0.6
        elif hedge_type == 'beta_70':
            return 0.7
        elif hedge_type == 'position':
            return 1
        return 0

    @staticmethod
    def convert_hedge(hedge):
        h = hedge.upper()
        if h in ('IF', 'IH', 'IC'):
            return h
        elif h == 'HS300':
            return 'IF'
        elif h == 'ZZ500':
            return 'IC'
        elif h == 'SZ50':
            return 'IH'
        return ''

    def get_data(self):
        """
        :return:
            - 'delta': 对冲差值
            - 'hedge_vol':已对冲手数
        """
        self.get_hedge_config()
        self.get_account_total_asset()
        self.get_vstrategies()
        self.get_vs_total_asset()
        res = {}
        for key, d in self.hedge_config.items():
            for acc, acc_d in d['account'].items():
                acc_d['total_asset'] = self.accounts[acc]['total_asset']
                acc_d['available_cash'] = self.accounts[acc]['available_cash']
                if acc_d['account_type'] == 'STOCK':
                    acc_d['available_cash'] = acc_d['total_asset'] - self.accounts[acc]['strategy_cash']

            hedge_vs = {
                'IF': {
                    'stock_hedge_cash': 0,
                    'future_hedge_cash': 0,
                    'hedge_vol': 0,
                    'delta': 0,
                    'strategies': {},
                },
                'IC': {
                    'stock_hedge_cash': 0,
                    'future_hedge_cash': 0,
                    'hedge_vol': 0,
                    'delta': 0,
                    'strategies': {},
                },
                'IH': {
                    'stock_hedge_cash': 0,
                    'future_hedge_cash': 0,
                    'hedge_vol': 0,
                    'delta': 0,
                    'strategies': {},
                }
            }

            res[key] = {
                'name': key,
                'account_cash': d,
                'hedge_vs': hedge_vs,
            }

            for vs_id, vs_d in self.vs_detail.items():
                if not any(_a in d['account'] for _a in vs_d['account']):
                    continue
                vs_d_acc = self.accounts[vs_d['account'][0]]
                if vs_d_acc['account_type'] == 'STOCK':
                    if not vs_d['hedge_product']:
                        continue
                    hedge_vs[vs_d['hedge_product']]['strategies'][vs_id] = {
                        'id': vs_id,
                        'id_no': vs_d['id_no'],
                        's_id': vs_d['s_id'],
                        'total_asset': vs_d['total_asset'],
                        'hedge_rate': vs_d['hedge_rate'],
                        'stock_hedge_cash': vs_d['stock_hedge_cash'],
                        'future_hedge_cash': vs_d['future_hedge_cash'],
                    }
                    hedge_vs[vs_d['hedge_product']]['stock_hedge_cash'] += vs_d['stock_hedge_cash']
                else:
                    hedge_vs['IF']['future_hedge_cash'] += vs_d['if_cash']
                    hedge_vs['IC']['future_hedge_cash'] += vs_d['ic_cash']
                    hedge_vs['IH']['future_hedge_cash'] += vs_d['ih_cash']
                    hedge_vs['IF']['hedge_vol'] += vs_d['if_vol']
                    hedge_vs['IC']['hedge_vol'] += vs_d['ic_vol']
                    hedge_vs['IH']['hedge_vol'] += vs_d['ih_vol']

            for pp, pp_hedge in hedge_vs.items():
                pp_price = 0
                if pp.lower() == 'ic':
                    #if self.quote_data.get('000905.SH', {}).get('LastPrice', 0):
                    #    pp_price = [self.quote_data['000905.SH']['LastPrice'] / 10000]
                    pp_price = self.quote_data['000905.SH'].get('LastPrice', 0) / 10000
                # 如果没有中证500指数值，则可能会拿平台行情中的ic期货价格，
                # NOTE by xuxx:  这段逻辑可以去掉，防止对冲监控时对基差出现误判。
                #if not pp_price:
                #    pp_price = [
                #        self.quote_data.get(s, {}).get('LastPrice', 999999999) for s in self.symbols if s[:2] == pp
                #       ]

                if pp_price:
                    #pp_price = min(pp_price)
                    trade_unit = self.future_trade_unit.get(pp, 0)
                    if not trade_unit:
                        continue
                    # 如果是IC对冲，则 对冲差值 =  (股票端持仓市值 - 对冲端)/(中证500指数值*IC合约乘数)
                    # 对冲端目前仅为期货，后续还有：融券股票/ETF，收益互换指数合约
                    pp_hedge['delta'] = round(
                        (pp_hedge['stock_hedge_cash'] - pp_hedge['future_hedge_cash']) / (pp_price * trade_unit)
                        , 4
                    )

            res[key]['hedge_vs'] = hedge_vs

        return sorted(res.values(), key=lambda x: x['name'])

# -*-coding:utf-8-*-


from service.file_upload.handlers import *

urls = [
    (r'/api/v1/platform/file_upload/file$', FileUploadHandler),
    (r'/api/v1/platform/file_upload/file/(?P<file_md5>\w+)$', FileUploadDetailHandler),
    (r'/api/v1/platform/file_upload/process/(?P<file_md5>\w+)$', FileUploadProcessHandler),
]

# -*-coding:utf-8-*-

import os
import shutil
import json
import datetime
from service.basehandler import CurrentUserMixin, BaseHandler
from tornado import gen

from config import config


def get_file_info_by_path(file_path):
    meta_file = os.path.join(file_path, 'meta.json')
    if not os.path.exists(meta_file):
        return {}
    meta_f = open(meta_file, 'r')
    meta_info = json.load(meta_f)
    meta_f.close()
    total = meta_info['chunk_total']
    done = set()
    for f in os.listdir(file_path):
        if 'chunk_index_file_' in f:
            done.add(int(f.rsplit('_', 1)[1]))
    meta_info['process'] = (len(done) / total) if total != 0 else 0
    meta_info['done'] = sorted(done)
    return meta_info


def mergefilechunks(file_path, filename):
    meta_file = os.path.join(file_path, 'meta.json')
    if not os.path.exists(meta_file):
        return ''
    meta_f = open(meta_file, 'r')
    meta_info = json.load(meta_f)
    meta_f.close()
    total = meta_info['chunk_total']
    merge_file = os.path.join(file_path, filename)
    for i in range(total):
        chunk_f = os.path.join(file_path, 'chunk_index_file_' % i)
        cmd = 'cat %s > %s' % (chunk_f, merge_file)
        os.system(cmd)
    return merge_file


def read_in_chunks(filePath, chunk_size=1024*1024):
    file_object = open(filePath, 'rb')
    while True:
        chunk_data = file_object.read(chunk_size)
        if not chunk_data:
            break
        yield chunk_data


def mergefilechunks2(file_path, filename):
    meta_file = os.path.join(file_path, 'meta.json')
    if not os.path.exists(meta_file):
        return ''
    meta_f = open(meta_file, 'r')
    meta_info = json.load(meta_f)
    meta_f.close()
    total = meta_info['chunk_total']
    merge_file = os.path.join(file_path, filename)
    merge_file = open(merge_file, 'wb')
    for i in range(total):
        chunk_f = os.path.join(file_path, 'chunk_index_file_%s' % i)
        for chunk_data in read_in_chunks(chunk_f):
            merge_file.write(chunk_data)
        merge_file.flush()
    merge_file.close()
    ext = meta_info.get('file_ext', '')
    if ext == '.zip':
        unpack_zip(file_path, filename)
    elif ext == '.rar':
        unpack_rar(file_path, filename)
    return merge_file


def unpack_zip(file_path, file_name, **kwargs):
    pack_file = os.path.join(file_path, file_name)
    shutil.unpack_archive(pack_file, file_path)

def unpack_rar(file_path, file_name, **kwargs):
    import rarfile
    pack_file = os.path.join(file_path, file_name)
    rf = rarfile.RarFile(pack_file)
    rf.extractall(file_path)


class FileUploadHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        #self.get_current_user()
        #if not self.current_user:
        #    return False

        current_user = {
            'username': self.get_argument('username'),
        }

        base_dir = os.path.join(config.media, 'platform_file_upload', current_user['username'])

        file_name = self.get_argument('file_name')
        location_file_name = self.get_argument('location_file_name', file_name)
        file_md5 = self.get_argument('file_md5')
        chunk_total = int(self.get_argument('chunk_total'))

        chunk_index = int(self.get_argument('chunk_index'))

        if '/' in file_name:
            file_name = file_name.split('/')[-1]

        if '\\' in file_name:
            file_name = file_name.split('\\')[-1]

        file_name = file_name.replace(' ', '')

        file_exts = os.path.splitext(file_name)
        ext = file_exts[1]
        file_meta = {
            'file_name': file_name,
            'file_ext': ext,
            'file_unpack_name': '%s.csv' % file_exts[0],
            'location_file_name': location_file_name,
            'file_md5': file_md5,
            'upload_time': datetime.datetime.now().strftime('%Y-%m-%d %X'),
            'chunk_total': chunk_total,
        }

        if (not file_md5) or (not chunk_total):
            self.json_response({
                'code': 5002,
                'data': 'file_md5(%s) or chunk_total(%s) error' % (file_md5, chunk_total)
            })
            return True

        content = self.request.files['content'][0]['body']

        file_path = os.path.join(base_dir, file_md5)
        if not os.path.exists(file_path):
            os.makedirs(file_path)

        meta_file = os.path.join(file_path, 'meta.json')
        if not os.path.exists(meta_file):
            meta_f = open(meta_file, 'w')
            json.dump(file_meta, meta_f)
            meta_f.close()

        chunk_index_file_path = os.path.join(file_path, 'chunk_index_file_%s' % str(chunk_index))

        data_fd = os.open(chunk_index_file_path, os.O_CREAT | os.O_RDWR)
        os.write(data_fd, content)
        os.fsync(data_fd)
        os.close(data_fd)

        done = set()
        for f in os.listdir(file_path):
            if 'chunk_index_file_' in f:
                done.add(int(f.rsplit('_', 1)[1]))

        if len(done) == chunk_total:
            mergefilechunks2(file_path, file_name)

        self.json_response({
            'code': 0,
            'data': {}
        })
        return True

    @gen.coroutine
    def get(self, *args, **kwargs):

        self.get_current_user()
        if not self.current_user:
            return False
        base_dir = os.path.join(config.media, 'platform_file_upload', self.current_user['username'])
        files = []
        ext = self.get_argument('ext', '').lower()
        if os.path.exists(base_dir):
            for f_md5 in os.listdir(base_dir):
                meta_info = get_file_info_by_path(os.path.join(base_dir, f_md5))
                if (not ext) or (meta_info['file_name'][-3:].lower() == ext) or (meta_info.get('file_unpack_name', '')[-3:].lower() == ext):
                    files.append(meta_info)
        self.json_response({
            'code': 0,
            'data': files,
        })
        return True


class FileUploadProcessHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        file_md5 = kwargs['file_md5']
        base_dir = os.path.join(config.media, 'platform_file_upload', self.current_user['username'])
        file_path = os.path.join(base_dir, file_md5)
        meta_info = get_file_info_by_path(file_path)
        if not meta_info:
            self.json_response({
                'code': 5001,
                'data': 'file not found',
                'error': 'file not found',
            })
        self.json_response({
            'code': 0,
            'data': meta_info,
        })
        return True

class FileUploadDetailHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def delete(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        file_md5 = kwargs['file_md5']
        base_dir = os.path.join(config.media, 'platform_file_upload', self.current_user['username'])
        file_path = os.path.join(base_dir, file_md5)
        meta_info = get_file_info_by_path(file_path)
        if not meta_info:
            self.json_response({
                'code': 5001,
                'data': 'file not found',
                'error': 'file not found',
            })
        shutil.rmtree(file_path)
        self.json_response({
            'code': 0,
            'data': {},
        })
        return True

from service.basehandler import BaseHandler, CurrentUserMixin, JsonPayloadMixin
from models.live_control_track import LiveControlTrack
from models.operator import DeployConfs
from db import session_context
import json
import uuid
from config import RedisCache0
from constant import RedisKeyConstant


# 实盘策略控制
class LiveControlHandler(CurrentUserMixin, BaseHandler):
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        if not self.request.body:
            self.json_response({"code": -1, 'error': 'empty data'})
            return
        body = self.request.body.decode("utf-8")
        data = json.loads(body)
        vs_id = data.pop("vs_id", 0)
        if not vs_id:
            self.json_response({"code": -1, 'error': 'vs_id is empty'})
            return
        if "type" not in data or not isinstance(data.get("data", None), dict):
            self.json_response({"code": -1, 'error': 'error post body\n' + body})
            return
        with session_context() as sc:
            query = sc.query(DeployConfs.id, DeployConfs.host).filter(
                DeployConfs.vstrategy_id == vs_id,
                DeployConfs.valid == 1,
            )
            rds = RedisCache0()
            for process_id, host in query:
                seq = uuid.uuid4().int & ((1 << 16) - 1)
                data['seq'] = seq
                data["data"]["process_id"] = process_id
                track = LiveControlTrack()
                track.r_create_user_id = self.current_user["id"]
                track.r_update_user_id = self.current_user["id"]
                track.host = host
                track.type = data["type"]
                track.seq = seq
                track.vs_id = vs_id
                track.data = data
                sc.add(track)
                # 这边没有deepcopy,需要commit,来保证seq,process_id是对的
                sc.commit()
                key = RedisKeyConstant.OssACmd.value.format(server_ip=host)
                msg = json.dumps(data)
                rds.rpush(key, msg)
        self.json_response({
            "code": 0,
            "data": []
        })
        return

    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        with session_context() as sc:
            query = sc.query(LiveControlTrack).order_by(LiveControlTrack.id.desc())
            offset = self.get_query_argument("offset", 0)
            page_size = self.get_query_argument("page_size", 100)
            query = query.limit(page_size).offset(offset)
            result = [i.as_dict() for i in query]
            self.json_response({
                "code": 0,
                "data": result
            })
        return

from service.live_control.handlers import *

urls = [
    (r'/api/v1/platform/live_control$', LiveControlHandler),
]

# -*-coding:utf-8-*-

import hashlib
import uuid

from db import session
from service.openapi.models import AppToken
from service.back_test.models import Strategy
from service.order_list.models import OrderList
from service.basehandler import CurrentUserMixin, BaseHandler, JsonPayloadMixin

from cron.strategy_upload_task import upload_tradelist_notify


class OpenApiBaseHandler(BaseHandler, JsonPayloadMixin):

    def get_secure_payload(self):
        """
        {
            'app_id': '123',
            'token': '123',
            'datetime': '2018-02-08 11:11:11',
            'data': {}
        }
        """
        payload = self.get_payload()
        app_id = payload['app_id']
        token = payload['token']
        datetime_str = payload['datetime']
        app_token = AppToken.get_app_token(app_id, status='APPROVED')
        if not app_token:
            self.json_response({
                'code': 3001,
                'error': 'can not find app_token app_id=%s' % app_id
            })
            self.finish()
            return False
        check_bytes = (app_token['app_token'] + datetime_str).encode('utf-8')
        check_token = hashlib.md5(check_bytes).hexdigest()
        if check_token != token:
            self.json_response({
                'code': 3002,
                'error': 'app_token check error',
            })
            self.finish()
            return False
        payload['app_token'] = app_token
        return payload

    def get_secure_args(self):
        pass


class OpenApiAppkeysHandle(CurrentUserMixin, BaseHandler, JsonPayloadMixin):

    def get(self, *args, **kwargs):
        self.json_response({
            'code': 0,
            'data': {
                'app_keys': [
                    {
                        'id': 'tradelistupload',
                        'name': 'trade自动上传API',
                    }
                ]
            }
        })
        return


class OpenApiApplyHandle(CurrentUserMixin, BaseHandler, JsonPayloadMixin):

    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        sc = session()
        app_tokens = sc.query(AppToken).filter(AppToken.user_id == self.current_user['id'])
        self.json_response({
            'code': 0,
            'data': {
                'app_tokens': [a.to_dict_detail() for a in app_tokens]
            }
        })
        sc.close()
        return

    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        payload = self.get_payload()

        sc = session()
        app_id = ('%s_%s' % (self.current_user['username'], payload['app_key']))
        app_token = hashlib.md5(uuid.uuid4().hex.encode('utf-8')).hexdigest()

        token = AppToken.get_app_token(app_id)
        if token:
            sc.close()
            self.json_response({
                'code': 1301,
                'error': 'app_token for app_key(%s) is already exists app_id: %s' % (
                    payload['app_key'], app_id
                )
            })
            return

        token = AppToken(
            name=payload.get('name', '') or app_id,
            user_id=self.current_user['id'],
            app_key=payload['app_key'],
            app_id=app_id,
            app_token=app_token,
            status='APPLYING',
            request_msg=payload.get('request_msg', ''),
        )

        sc.add(token)
        sc.commit()
        data = token.to_dict_detail()
        sc.close()
        self.json_response({
            'code': 0,
            'data': data
        })
        return


class OpenApiAuditHandle(CurrentUserMixin, BaseHandler, JsonPayloadMixin):

    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        if self.current_user['id'] not in [1]:
            self.json_response({
                'code': 1302,
                'error': 'you have no permission to audit'
            })
            return
        sc = session()
        app_tokens = sc.query(AppToken).filter(AppToken.status.in_(['APPLYING']))
        self.json_response({
            'code': 0,
            'data': {
                'app_tokens': [a.to_dict_detail() for a in app_tokens]
            }
        })
        return

    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        if self.current_user['id'] not in [1]:
            self.json_response({
                'code': 1302,
                'error': 'you have no permission to audit'
            })
            return

        payload = self.get_payload()
        """{
            'id': 100,
            'status': 'APPROVED|REJECTED',
            'audit_msg': '',
        }"""
        if payload['status'] not in ('APPROVED', 'REJECTED'):
            self.json_response({
                'code': 1302,
                'error': 'audit status must in (APPROVED, REJECTED)'
            })
            return
        sc = session()
        token = sc.query(AppToken).filter(AppToken.id == payload['id']).first()
        if not token:
            sc.close()
            self.json_response({
                'code': 1300,
                'error': 'can not find app_token id(%s)' % payload['id']
            })
            return
        token.status = payload['status']
        token.audit_msg = payload.get('audit_msg', '')
        sc.add(token)
        sc.commit()
        data = token.to_dict_detail()
        sc.close()
        self.json_response({
            'code': 0,
            'data': data
        })
        return


class UploadTradeListHandle(OpenApiBaseHandler):

    def post(self, *args, **kwargs):
        payload = self.get_secure_payload()
        data = payload['data']
        user_id = payload['app_token']['user_id']
        sc = session()
        strategy = sc.query(Strategy).filter(
            Strategy.id_no == data['strategy_id'],
            Strategy.r_create_user_id == user_id,
            Strategy.node.in_(['order_list', 'trademaster_order_list']),
        ).first()
        upload_tradelist_notify.apply_async(
            args=[strategy.id, data['date']],
            kwargs={'trade_list': data['trade_list']},
            countdown=10)
        if not strategy:
            self.json_response({
                'code': 3013,
                'error': 'strategy is not find or is not order list type'
            })
            sc.close()
            return
        order_list = sc.query(OrderList).filter(
            OrderList.date == data['date'],
            OrderList.strategy_id == strategy.id
        )
        order_list.delete()
        keys_index = {k: index for index, k in enumerate(data['trade_list']['keys'])}
        sum_weight = 0
        for v in data['trade_list']['values']:
            order_kwargs = {
                'r_create_user_id': user_id,
                'r_update_user_id': user_id,
                'date': data['date'],
                'strategy_id': strategy.id,
                'hedge_id': -1,
                'symbol': v[keys_index['symbol']],
                'algo': v[keys_index['algo']],
                'start': v[keys_index['start']],
                'end': v[keys_index['end']],
            }
            if (keys_index.get('weight', -1) >= 0) and (v[keys_index['weight']] or v[keys_index['weight']] == 0):
                order_kwargs['weight'] = float(v[keys_index['weight']])
                sum_weight += abs(order_kwargs['weight'])
            if (keys_index.get('size', -1) >= 0) and (v[keys_index['size']] or v[keys_index['size']] == 0):
                order_kwargs['size'] = int(v[keys_index['size']])
            if (keys_index.get('limit_price', -1) >= 0) and (
                    v[keys_index['limit_price']] or v[keys_index['limit_price']] == 0):
                order_kwargs['limit_price'] = float(v[keys_index['limit_price']])
            if ('weight' not in order_kwargs) and ('size' not in order_kwargs):
                sc.close()
                self.json_response({
                    'code': 3030,
                    'error': 'orderlist error:symbol(%s) miss weight and size' % order_kwargs['symbol']
                })
                return False
            o = OrderList(
                **order_kwargs
            )
            sc.add(o)
        if sum_weight > 1:
            sc.close()
            self.json_response({
                'code': 1029,
                'error': 'sum of abs_weight > 1'
            })
            return False
        sc.commit()
        sc.close()
        data = {
            'code': 0
        }
        self.json_response(data)
        return

#-*-coding:utf-8-*-


from sqlalchemy.sql import func
from sqlalchemy import Column
from sqlalchemy.dialects.mysql import BIGINT, VARCHAR, DATETIME

from db import ModelBase, session


class AppToken(ModelBase):

    __tablename__ = 'my_app_token'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=True)
    user_id = Column(BIGINT(unsigned=True), nullable=False)
    app_key = Column(VARCHAR(32), nullable=False)
    app_id = Column(VARCHAR(32), nullable=False, unique=True)
    app_token = Column(VARCHAR(32), nullable=False, unique=True)
    status = Column(VARCHAR(32), nullable=False)    # APPLYING|APPROVED|REJECTED|INVALID
    auditer = Column(BIGINT(unsigned=True), nullable=True)
    audit_msg = Column(VARCHAR(512), nullable=True)
    request_msg = Column(VARCHAR(512), nullable=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'user_id': self.user_id,
            'app_id': self.app_id,
            'app_token': self.app_token,
            'app_key': self.app_key,
            'status': self.status,
        }

    def to_dict_detail(self):
        d = self.to_dict()
        d['audit_msg'] = self.audit_msg
        return d

    @staticmethod
    def get_app_token(app_id, **kwargs):
        sc = session()
        if 'status' in kwargs:
            app_token = sc.query(AppToken).filter(
                AppToken.app_id == app_id,
                AppToken.status == kwargs['status']
            ).first()
        else:
            app_token = sc.query(AppToken).filter(AppToken.app_id == app_id).first()
        if app_token:
            data = app_token.to_dict()
        else:
            data = {}
        sc.close()
        return data

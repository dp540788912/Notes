#-*-coding:utf-8-*-


from service.openapi.handlers import *

urls = [
    (r'/api/v1/platform/openapi$', OpenApiApplyHandle),
    (r'/api/v1/platform/openapi/appkeys$', OpenApiAppkeysHandle),
    (r'/api/v1/platform/openapi/audit$', OpenApiAuditHandle),
    (r'/api/v1/platform/openapi/orderlist$', UploadTradeListHandle),
]

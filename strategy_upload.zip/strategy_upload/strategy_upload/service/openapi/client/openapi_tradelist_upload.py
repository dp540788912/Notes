# coding: utf-8
import hashlib
import json
import requests
import datetime
import pandas as pd
import numpy as np

# Configurations
app = ('https://www.mycapital.net/api/v1/platform/openapi/orderlist',
       'zijun_upload_tradelist', '973f39366faee825208f353ca106b73b')
strategy = ('ZIJ01_01_20170104_002', './test123.csv')
date = '20180209'


def openapi_tradelist_upload(app, strategy, date):
    '''
    Parameters
    ==========
    app: tuple 
        app[0]: str, Application url
        app[1]: str, Application ID
        app[2]: str, Application token
    strategy : tuple
        strategy[0] :str, Strategy ID in www.mycapital.net (e.g.ZIJ01_01_20170104_002)
        strategy[1] :str, Local file path of trade list file. 
    date: str
        trading date

    Exceptions:
    ==========
    ValueError
        Incase of upload failure, raise ValueError exception.
    '''
    tradelist_df = pd.read_csv(
        strategy[1],
        sep=',',
        dtype={
            'date': str,
            'symbol': str,
            'weight': float,
            'size': float,
            'limit_price': float,
            'algo': str,
            'start': str,
            'end': str
        })

    data = {
        'app_id': app[1],
        'datetime': datetime.datetime.now().strftime('%Y-%m-%d %X'),
        'data': {
            'strategy_id': strategy[0],
            'date': date,
            'trade_list': {
                'keys':
                    list(tradelist_df.columns),
                'values': [[
                    v if not isinstance(v, (int, float, np.float, np.int)) else
                    ('' if np.isnan(v) else v) for v in values
                ] for values in tradelist_df.values],
            },
        }
    }
    data['token'] = hashlib.md5(
        (app[2] + data['datetime']).encode('utf-8')).hexdigest()
    headers = {
        'content-type': 'application/json',
    }
    r = requests.post(app[0], data=json.dumps(data), headers=headers).json()
    if r['code'] != 0:
        raise ValueError('upload error')


if __name__ == '__main__':
    openapi_tradelist_upload(app, strategy, date)

import datetime
import json

from config import config, RedisCache0
from service.basehandler import BaseHandler, CurrentUserMixin, JsonPayloadMixin
from constant import APIResponseCode
from utility.func_util import login_required
from constant import RedisKeyConstant
from utility.db_util import TradeCalendar
from data_brick.strategy import VsBasicData

from .helper import SelfTradeMonitor


class SelfTradeMonitorHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):
    @login_required
    def get(self, *args, **kwargs):
        trading_date = str(self.get_argument("trading_date", datetime.date.today().strftime("%Y%m%d")))

        trading_calendar = TradeCalendar.init_from_kdb(**config.kdb_config)
        if not trading_calendar.is_trading_date(date=trading_date):
            self.json_response({
                "code": APIResponseCode.DefaultError.value,
                "error": "{trading_date} is not trading date".format(trading_date=trading_date)
            })
            return

        rds = RedisCache0()
        key = RedisKeyConstant.SelfTradeMonitorInfo.value.format(trading_date=trading_date)
        info = rds.get(key)
        if info:
            info = json.loads(info.decode('utf-8'))
        else:
            monitor = SelfTradeMonitor(trading_date=trading_date)
            self_trade_info = monitor.get_self_trade_info()
            update_at = datetime.datetime.now().strftime("%Y%m%d %H:%M:%S")
            info = {
                "self_trade_info": self_trade_info,
                "update_at": update_at
            }
            if self_trade_info:
                rds.set(key, json.dumps(info), ex=24 * 60 * 60)

        info["self_trade_count"] = len(info["self_trade_info"])

        vs_ids = set()
        for lst in info["self_trade_info"]:
            for ele in lst:
                vs_ids.add(int(ele["vs_id"]))

        vs_basic_data = VsBasicData.get_many(identifiers=list(vs_ids))
        info["vs_basic_data"] = vs_basic_data

        self.json_response({
            "code": APIResponseCode.OK.value,
            "data": info
        })

from .handlers import SelfTradeMonitorHandler

urls = [
    (r'/api/v1/platform/monitor/self_trade_monitor', SelfTradeMonitorHandler),
]

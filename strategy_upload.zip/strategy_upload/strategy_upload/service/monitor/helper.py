import datetime

from db import session_context


class SelfTradeMonitor(object):
    ACCOUNT_FILTER = [("209202001088", "50214819")]

    def __init__(self, trading_date, account_filter=None):
        """

        :param trading_date: string, "%Y%m%d"
        :param account_filter: list[tuple]
        """
        self.trading_date = trading_date
        self.account_filter = account_filter or self.ACCOUNT_FILTER
        self.trade_logs_dict = self._get_trade_logs_dict()

    def _get_trade_logs_dict(self):
        trade_logs_dict = dict()
        with session_context() as sc:
            trade_logs_sql = "SELECT id,exchange_time,exchange_microsec,vstrategy_id,symbol," \
                             "account,direction,trade_price,trade_no " \
                             "FROM trade_logs WHERE trading_date={trading_date} AND log_type='3' " \
                             "AND day_night=0 AND trade_no != 0 " \
                             "ORDER BY id DESC".format(trading_date=self.trading_date)
            records = sc.execute(trade_logs_sql).fetchall()
            for r in records:
                r_id = r["id"]
                if r["exchange_time"] is None and r["exchange_microsec"] is None:
                    continue

                trade_logs_dict[r_id] = {
                    "r_id": r_id,
                    "exchange_time": "{}.{}".format(str(r["exchange_time"]), r["exchange_microsec"]),
                    "trade_no": r["trade_no"],
                    "vs_id": r["vstrategy_id"],
                    "symbol": r["symbol"],
                    "account": r["account"],
                    "direction": r["direction"],
                    "trade_price": r["trade_price"],
                }
        return trade_logs_dict

    def _group_by_symbol(self):
        account_symbol_dict = dict()
        for r_id, log in self.trade_logs_dict.items():
            account = log["account"]
            symbol = log["symbol"]
            buy_sell = self._to_buy_sell(log["direction"])
            if not buy_sell:
                continue
            account_dict = account_symbol_dict.setdefault(account, {})
            symbol_dict = account_dict.setdefault(symbol, {
                "buy": [],
                "sell": []
            })
            symbol_dict[buy_sell].append({
                "r_id": r_id,
                "trade_no": log["trade_no"],
                "exchange_time": log["exchange_time"],
                "trade_price": log["trade_price"]
            })
        return account_symbol_dict

    def _group_by_account(self):
        new_account_symbol_dict = dict()
        account_symbol_dict = self._group_by_symbol()
        for accounts in self.account_filter:
            key = "_".join(accounts)
            value = dict()
            for acc in accounts:
                for symbol, symbol_dict in account_symbol_dict.get(acc, {}).items():
                    v = value.setdefault(symbol, {
                        "buy": [],
                        "sell": []
                    })
                    v["buy"].extend(symbol_dict["buy"])
                    v["sell"].extend(symbol_dict["sell"])

            new_account_symbol_dict[key] = value
        return new_account_symbol_dict

    def _to_timestamp(self, calendar_time):
        fmt = "%Y%m%d %H:%M:%S"
        date_string = "{} {}".format(self.trading_date, calendar_time)
        dt = datetime.datetime.strptime(date_string, fmt)
        return int(dt.timestamp())

    @staticmethod
    def _to_buy_sell(direction):
        if direction in [0, 5]:
            result = "buy"
        elif direction in [1, 3]:
            result = "sell"
        else:
            result = ""
        return result

    def _check_self_trade(self):
        account_symbol = self._group_by_account()
        self_trade_log_list = list()
        for acc, acc_dict in account_symbol.items():
            for symbol, symbol_dict in acc_dict.items():
                for buy_record in symbol_dict["buy"]:
                    for sell_record in symbol_dict["sell"]:
                        if buy_record["trade_price"] == sell_record["trade_price"] \
                                and (buy_record["trade_no"] == sell_record["trade_no"]
                                     or buy_record["exchange_time"] == sell_record["exchange_time"]):
                            self_trade_log_list.append((buy_record["r_id"], sell_record["r_id"]))
        return self_trade_log_list

    def get_self_trade_info(self):
        info = list()
        self_trade_log_list = self._check_self_trade()
        for tp in self_trade_log_list:
            info.append([self.trade_logs_dict[tp[0]], self.trade_logs_dict[tp[1]]])
        return info

    def update_trade_logs_dict(self):
        self.trade_logs_dict = self._get_trade_logs_dict()

# -*-coding:utf-8-*-
from Crypto.Cipher import AES
import base64
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from sqlalchemy import Column, ForeignKey
from sqlalchemy.dialects.mysql import BIGINT, VARCHAR, FLOAT, BOOLEAN, DATETIME, INTEGER, JSON, DOUBLE, TEXT, DATE, \
    TIME, SMALLINT
from sqlalchemy import BigInteger, Column, Date, DateTime, Enum, Float, Index, Integer, String, Time, text, JSON

from db import ModelBase, engine, session, session_context
from service.back_test.models import Users


class Brokers(ModelBase):
    __tablename__ = 'brokers'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
        }


class Accounts(ModelBase):
    __tablename__ = 'accounts'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    # 账户号码
    name = Column(VARCHAR(32), nullable=False, unique=True)
    password = Column(VARCHAR(128), nullable=False)
    fund_total = Column(FLOAT, nullable=False, default=0)
    fund_occupied = Column(FLOAT, nullable=False, default=0)
    broker_id = Column(ForeignKey('brokers.id'))
    user_id = Column(ForeignKey('users.id'))
    valid = Column(BOOLEAN, nullable=False, default=True)
    use_turing = Column(BOOLEAN, nullable=True)
    seat = Column(VARCHAR(256), nullable=True, default='CTP主席')
    rsp_pwd = Column(VARCHAR(128), nullable=True)
    client_name = Column(VARCHAR(32), nullable=True)
    need_query = Column(BOOLEAN, nullable=True)
    # 账户名称
    account_name = Column(VARCHAR(256), nullable=True)
    fund_ratio = Column(VARCHAR(32), nullable=True)
    use_for = Column(VARCHAR(64), nullable=True)
    market = Column(VARCHAR(256), nullable=True)
    counter_seat = Column(VARCHAR(256), nullable=True)
    query_passwd = Column(VARCHAR(256), nullable=True)
    query_broker = Column(VARCHAR(32), nullable=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER)
    r_update_user_id = Column(INTEGER)

    broker_obj = relationship('Brokers')
    user_obj = relationship('Users')

    def to_dict(self):
        return {
            'id': self.id,
            'account': self.name,
            'account_name': self.account_name,
            'password': self.password,
            'broker': {
                'id': self.broker_obj.id,
                'name': self.broker_obj.name,
            },
            'username': self.user_obj.name
        }

    @staticmethod
    def encrypt(text):
        if len(text) > 16:
            return text
        key = b'\x02\x0c!W@\xad\te\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        cipher = AES.new(key, AES.MODE_ECB)
        if isinstance(text, str):
            text = text[:16].encode('utf-8')
        elif isinstance(text, bytes):
            text = text[:16]
        else:
            raise ValueError('text type error: %s' % text)
        text = text + b'\x00' * (16 - len(text)) + b'\t\x8b*UqU\xdc\xbd\x02\xab\xcf`\xd7\x80\xe8\xe5' * 3
        return str(base64.b64encode(cipher.encrypt(text)), 'utf-8')


class AccountFunds(ModelBase):
    __tablename__ = 'account_funds'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    account = Column(VARCHAR(128), nullable=False)
    trading_day = Column(DATE, nullable=False)
    # 总权益
    balance = Column(DOUBLE, nullable=False)
    # 策略面值
    notional_strategy = Column(DOUBLE, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())

    def to_dict(self):
        return {
            'id': self.id,
            'account': self.account,
            'trading_day': self.trading_day,
            'balance': float(self.balance),
            'notional_strategy': float(self.notional_strategy),
        }


class AccountBalanceCounter(ModelBase):
    """ Account fields queried from CTP.
    """ 
    __tablename__ = 'account_balance_counter'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    account = Column(VARCHAR(128), nullable=False)
    account_name = Column(VARCHAR(128), nullable=False)
    broker = Column(VARCHAR(128), nullable=False)
    # 交易日
    trading_day = Column(DATE, nullable=False)
    # 上次结算准备金
    pre_balance = Column(DOUBLE, nullable=False)
    # 结算准备金
    balance = Column(DOUBLE, nullable=False)
    # 可用资金
    available = Column(DOUBLE, nullable=False)
    # 可取资金
    withdraw_quota = Column(DOUBLE, nullable=False)
    # 入金金额
    deposit = Column(DOUBLE, nullable=False)
    # 出金金额
    withdraw = Column(DOUBLE, nullable=False)
    # 手续费
    commission = Column(DOUBLE, nullable=False)
    # 平仓盈亏
    close_profit = Column(DOUBLE, nullable=False)
    # 持仓盈亏
    position_profit = Column(DOUBLE, nullable=False)
    # RMB:人民币 USD：美元
    currency = Column(VARCHAR(10), nullable=False, default='RMB')
    user_type = Column(SMALLINT, nullable=False)
    ctime = Column(DATETIME, nullable=False, server_default=func.now())
    utime = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())

    def to_dict(self):
        return {
            'id': self.id,
            'account': self.account,
            'trading_day': str(self.trading_day),
            'pre_balance': float(self.pre_balance),
            'balance': float(self.balance),
            'available': float(self.available),
            'withdraw_quota': float(self.withdraw_quota),
            'deposit': float(self.deposit),
            'withdraw': float(self.withdraw),
            'commission': float(self.commission),
            'close_profit': float(self.close_profit),
            'position_profit': float(self.position_profit),
            'currency': self.currency,
        }

    @staticmethod
    def add_init_record(account, account_name, broker, trading_date, deposit):
        with session_context() as sc:
            record = AccountBalanceCounter(
                account=account,
                account_name=account_name,
                broker=broker,
                trading_day=trading_date,
                pre_balance=0,
                balance=0,
                available=0,
                withdraw_quota=0,
                deposit=deposit,
                withdraw=0,
                commission=0,
                close_profit=0,
                position_profit=0,
                user_type=1
            )
            sc.add(record)


class AccountPositionCounter(ModelBase):
    __tablename__ = 'account_position_counter'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    account = Column(VARCHAR(128), nullable=False)
    # 交易日
    trading_day = Column(DATE, nullable=False)
    exchange = Column(VARCHAR(12), nullable=False)
    # 合约代码
    symbol = Column(VARCHAR(128), nullable=False)
    # 1:'Future',:2:'Stock', 3:'Spot', 4:'Option'
    symbol_type = Column(SMALLINT, nullable=False)
    yest_long_pos = Column(INTEGER, nullable=False)
    yest_long_avg_price = Column(DOUBLE, nullable=False)
    yest_short_pos = Column(INTEGER, nullable=False)
    yest_short_avg_price = Column(DOUBLE, nullable=False)
    # 今仓包括昨仓
    today_long_pos = Column(INTEGER, nullable=False)
    today_long_avg_price = Column(DOUBLE, nullable=False)
    today_short_pos = Column(INTEGER, nullable=False)
    today_short_avg_price = Column(DOUBLE, nullable=False)
    ctime = Column(DATETIME, nullable=False, server_default=func.now())
    utime = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())


class AccountOrderCounter(ModelBase):
    __tablename__ = 'account_order_counter'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    account = Column(VARCHAR(128), nullable=False)
    # 交易日
    trading_day = Column(DATE, nullable=False)
    # 委托日
    insert_day = Column(DATE, nullable=False)
    exchange = Column(VARCHAR(12), nullable=False)
    # 合约代码
    symbol = Column(VARCHAR(128), nullable=False)
    # 1:'Future',:2:'Stock', 3:'Spot', 4:'Option'
    symbol_type = Column(SMALLINT, nullable=False)
    # 委托时间
    insert_time = Column(TIME, nullable=False)
    # 本地报单编号
    order_local_id = Column(VARCHAR(32), nullable=False)
    # 报单编号
    order_sys_id = Column(VARCHAR(32), nullable=False)
    # 0:买 1:卖
    direction = Column(INTEGER, nullable=False)
    # 0:开 1:平
    open_close = Column(INTEGER, nullable=False)
    # 投机套保标志 1:投机 2:套利 3:套保
    hedge_flag = Column(INTEGER, nullable=False)
    order_price = Column(DOUBLE, nullable=False)
    order_vol = Column(INTEGER, nullable=False)
    # 报单状态
    order_status = Column(SMALLINT, nullable=False)
    order_price_type = Column(INTEGER, nullable=False)
    order_type = Column(INTEGER, nullable=False)
    ctime = Column(DATETIME, nullable=False, server_default=func.now())
    utime = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())


class AccountTradeCounter(ModelBase):
    __tablename__ = 'account_trade_counter'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    account = Column(VARCHAR(128), nullable=False)
    # 交易日
    trading_day = Column(DATE, nullable=False)
    exchange = Column(VARCHAR(12), nullable=False)
    # 合约代码
    symbol = Column(VARCHAR(128), nullable=False)
    # 1:'Future',:2:'Stock', 3:'Spot', 4:'Option'
    symbol_type = Column(SMALLINT, nullable=False)
    # 0:买 1:卖
    direction = Column(INTEGER, nullable=False)
    # 0:开 1:平
    open_close = Column(INTEGER, nullable=False)
    # 投机套保标志 1:投机 2:套利 3:套保
    hedge_flag = Column(INTEGER, nullable=False)
    # 本地报单编号
    order_local_id = Column(VARCHAR(32), nullable=False)
    # 报单编号
    order_sys_id = Column(VARCHAR(32), nullable=False)
    # 成交编号
    trade_id = Column(VARCHAR(32), nullable=False)
    trade_price = Column(DOUBLE, nullable=False)
    trade_vol = Column(INTEGER, nullable=False)
    # 成交时间
    trade_time = Column(TIME, nullable=False)
    ctime = Column(DATETIME, nullable=False, server_default=func.now())
    utime = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())

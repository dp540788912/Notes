# -*-coding:utf-8-*-

import json
from tornado import gen
from sqlalchemy import distinct
from log import logger
from service.back_test.models import VStrategyAccountDetail, Strategy, VStrategies
from service.account_funds.models import *
from service.basehandler import BaseHandler, CurrentUserMixin
from utils import send_email, send_wx

import consts


class AccountFundsForPlatformHandler(CurrentUserMixin, BaseHandler):

    def get_account_funds(self, sc, account_no):
        data = {'deposit_withdraw_history': [], 'fund': 0}

        # 出入金
        funds_data = sc.query(
            AccountBalanceCounter.id,
            AccountBalanceCounter.trading_day,
            AccountBalanceCounter.currency,
            AccountBalanceCounter.deposit,
            AccountBalanceCounter.withdraw,
        ).filter(
            AccountBalanceCounter.account == account_no,
        ).order_by(
            AccountBalanceCounter.trading_day
        )
        
        # TODO count() judgment can be removed.
        if funds_data.count() > 0:
            for r in funds_data:
                cash = r.deposit - r.withdraw
                if cash == 0:
                    continue
                data['deposit_withdraw_history'].append({
                    'id': r.id,
                    'cash': float(cash),
                    'currency': r.currency,
                    'trading_day': str(r.trading_day),
                })

                data['fund'] += cash

        # 账户权益、策略面值
        data['balance_value_history'] = []
        funds = sc.query(
            AccountFunds
        ).filter_by(
            account=account_no
        ).order_by(AccountFunds.trading_day)
        if 0 == funds.count():
            data['balance'] = 0
            data['notional_strategy'] = 0
        else:
            for fund in funds:
                data['balance_value_history'].append({
                    'trading_day': fund.trading_day.strftime('%Y-%m-%d'),
                    'balance': float(fund.balance),
                    'notional': float(fund.notional_strategy),
                })

            data['balance'] = float(data['balance_value_history'][-1]['balance'])
            data['notional_strategy'] = float(data['balance_value_history'][-1]['notional'])

        # 账户投资的策略信息
        vids = sc.query(
            distinct(VStrategyAccountDetail.vstrategy_id)
        ).join(
            VStrategies, VStrategies.id == VStrategyAccountDetail.vstrategy_id
        ).filter(
            VStrategies.status == 15,  # 实盘
            VStrategyAccountDetail.account == account_no
        )
        data['num_strategy'] = vids.count()
        data['strategy_info'] = []
        if 0 == vids.count():
            return data
        vstrategy_ids = [vid[0] for vid in vids]
        for vid in vstrategy_ids:
            strategy_info = sc.query(Strategy.id, Strategy.id_no, Strategy.name
                                     ).join(
                VStrategies, VStrategies.strategy_id == Strategy.id
            ).filter(
                VStrategies.id == vid
            ).first()
            if not strategy_info:
                logger.error("No found strategy of vstrategy_id = %d" % vid)
                data['strategy_info'].append(
                    {
                        's_id': 0,
                        'name': '',
                        'id_no': ''
                    }
                )
                continue
            data['strategy_info'].append(
                {
                    's_id': strategy_info.id,
                    'name': strategy_info.name,
                    'id_no': strategy_info.id_no
                }
            )
        return data

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        group_ids = self.get_user_group()
        # operation group_id = 3
        if 3 in group_ids:
            self.current_user['is_superuser'] = True

        sc = session()
        if self.current_user['is_superuser']:
            accounts = sc.query(Accounts).filter_by(need_query=True)
        else:
            r_create_user_ids = [self.current_user['id']]
            if self.is_stock_group():
                r_create_user_ids.append(consts.stock_user['id'])
            if self.is_future_group():
                r_create_user_ids.append(consts.future_user['id'])

            accounts = sc.query(Accounts).filter(
                Accounts.need_query == True,
                Accounts.user_id.in_(r_create_user_ids),
            )
        if 0 == accounts.count():
            self.write(json.dumps({
                'code': 0,
                'data': []
            }))
            sc.close()
            return True

        out_data = []
        for account in accounts:
            account_info = account.to_dict()
            account_funds = self.get_account_funds(sc, account.name)
            data = dict(account_info, **account_funds)
            data['is_superuser'] = self.current_user['is_superuser']
            out_data.append(data)

        self.json_response({
            'code': 0,
            'data': out_data
        })
        sc.close()
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        me = self.get_user_detail()
        group_ids = [int(g['id']) for g in me['groups']]
        # operation group_id = 3
        if 3 in group_ids:
            self.current_user['is_superuser'] = True

        payload = json.loads(str(self.request.body, 'utf-8'))
        sc = session()
        account = Accounts(
            name=payload['account'],
            account_name=payload['account_name'],
            password=Accounts.encrypt(payload['password']),
            broker_id=payload['broker_id'],
            user_id=self.current_user['id'],
            use_turing=False,
            r_create_user_id=self.current_user['id'],
            r_update_user_id=self.current_user['id'],
        )
        sc.add(account)
        sc.commit()
        out_data = account.to_dict()
        out_data['is_superuser'] = self.current_user['is_superuser']
        out_data['fund'] = 0
        out_data['balance'] = 0
        out_data['num_strategy'] = 0
        out_data['notional_strategy'] = 0
        out_data['deposit_withdraw_history'] = []
        out_data['balance_value_history'] = []
        out_data['strategy_info'] = []

        sc.close()
        self.write(json.dumps({
            'code': 0,
            'data': out_data
        }))

    @gen.coroutine
    def put(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        payload = json.loads(str(self.request.body, 'utf-8'))
        in_id = int(kwargs['id'])
        sc = session()
        account = sc.query(Accounts).filter_by(id=in_id).first()
        if not account:
            sc.close()
            self.write(json.dumps({
                'code': 1300,
                'error': '账户不存在'
            }))
            return False

        for k, v in payload.items():
            if k == 'account':
                setattr(account, 'name', payload[k])
            elif k == 'password':
                setattr(account, k, Accounts.encrypt(payload[k]))
            else:
                setattr(account, k, payload[k])
        sc.commit()

        account_info = account.to_dict()
        account_funds = self.get_account_funds(sc, account.name)
        data = dict(account_info, **account_funds)
        data['is_superuser'] = self.current_user['is_superuser']
        sc.close()
        self.write(json.dumps({
            'code': 0,
            'data': data
        }))

    @gen.coroutine
    def delete(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        in_id = int(kwargs['id'])
        sc = session()
        account = sc.query(Accounts).filter_by(id=in_id).first()
        if not account:
            sc.close()
            self.write(json.dumps({
                'code': 1300,
                'error': '账户不存在'
            }))

        vstrategy_ids = sc.query(
            distinct(VStrategyAccountDetail.vstrategy_id)
        ).join(
            VStrategies, VStrategies.id == VStrategyAccountDetail.vstrategy_id
        ).filter(
            VStrategies.status == 15,  # 实盘
            VStrategyAccountDetail.account == account.name
        )
        if 0 == vstrategy_ids.count():
            try:
                sc.query(Accounts).filter_by(id=in_id).delete()
                sc.commit()
                sc.close()
                self.write(json.dumps({
                    'code': 0
                }))
            except Exception as e:
                self.write(json.dumps({
                    'code': 1399,
                    'error': str(e)
                }))
        else:
            sc.close()
            self.write(json.dumps({
                'code': 1400,
                'error': '删除账户前，请先删除账户的实盘交易数据'
            }))


class DepositWithdrawHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        payload = json.loads(str(self.request.body, 'utf-8'))
        if 0 == payload['cash']:
            self.write(json.dumps({
                'code': 1500,
                'error': '出入金金额不能是0！'
            }))
            return False

        sc = session()
        account = sc.query(Accounts).filter_by(name=payload['account']).first()
        if not account:
            self.write(json.dumps({
                'code': 1300,
                'error': '账户不存在'
            }))
            return False

        settle_data = sc.query(
            AccountBalanceCounter
        ).filter_by(
            account=payload['account'],
            trading_day=payload['trading_day']
        ).first()
        if settle_data:
            if payload['cash'] > 0:
                setattr(settle_data, 'deposit', float(settle_data.deposit) + payload['cash'])
            else:
                setattr(settle_data, 'withdraw', float(settle_data.withdraw) + abs(payload['cash']))
        else:
            if payload['cash'] > 0:
                settle_data = AccountBalanceCounter(
                    account=payload['account'],
                    trading_day=payload['trading_day'],
                    pre_balance=0,
                    balance=0,
                    available=0,
                    withdraw_quota=0,
                    deposit=payload['cash'],
                    withdraw=0,
                    commission=0,
                    close_profit=0,
                    position_profit=0,
                    currency=payload['currency'],
                )
            else:
                settle_data = AccountBalanceCounter(
                    account=payload['account'],
                    trading_day=payload['trading_day'],
                    pre_balance=0,
                    balance=0,
                    available=0,
                    withdraw_quota=0,
                    deposit=0,
                    withdraw=abs(payload['cash']),
                    commission=0,
                    close_profit=0,
                    position_profit=0,
                    currency=payload['currency'],
                )
            sc.add(settle_data)
        sc.commit()
        sc.close()

        self.write(json.dumps({
            'code': 0,
            'data': {
                'account': payload['account'],
                'trading_day': str(payload['trading_day']),
                'cash': float(payload['cash']),
                'currency': payload['currency']
            }
        }))

        return True

    def dispatch_notice(self, subject, content):
        wx_list = ['DongQun', 'LiZhiBingsandy', 'lily', 'ZhangPing']
        email_list = ['peter@mycapital.net', 'sandy@mycapital.net', 'lily@mycapital.net', 'zhangping@mycapital.net']

        agentid = 1000003
        secret = 'EIXZMCl-lX4jsyJRTjfYOmQksySB3UeZkJiczOh5Ulo'

        send_wx(agentid, secret, content, wx_list)
        send_email(subject, content, email_list)


class AccountLatestEquityForOperationHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        sc = session()
        accounts = sc.query(Accounts).filter_by(need_query=True)
        if 0 == accounts.count():
            self.write(json.dumps({
                'code': 0,
                'data': []
            }))
            sc.close()
            return True

        out_data = {}
        for account in accounts:
            settle_data = sc.query(
                AccountBalanceCounter.trading_day,
                AccountBalanceCounter.balance,
                AccountBalanceCounter.currency,
            ).filter_by(
                account=account.name
            ).order_by(
                AccountBalanceCounter.trading_day.desc()
            ).first()
            if not settle_data:
                out_data[account.name] = {
                    'trading_day': '',
                    'balance': -1,
                    'currency': ''
                }
            else:
                out_data[account.name] = {
                    'trading_day': str(settle_data.trading_day),
                    'balance': float(settle_data.balance),
                    'currency': settle_data.currency
                }
        sc.close()
        self.write(json.dumps({
            'code': 0,
            'data': out_data
        }))
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):

        payload = json.loads(str(self.request.body, 'utf-8'))
        sc = session()
        accounts = sc.query(Accounts).filter_by(name=payload['account'])
        if 0 == accounts.count():
            sc.close()
            self.write(json.dumps({
                'code': 1300,
                'error': '账户不存在'
            }))
            return False

        settle_data = sc.query(
            AccountBalanceCounter
        ).filter_by(
            account=payload['account'],
            trading_day=payload['trading_day']
        ).first()
        if settle_data:
            setattr(settle_data, 'balance', payload['balance'])
        else:
            settle_data = AccountBalanceCounter(
                account=payload['account'],
                trading_day=payload['trading_day'],
                pre_balance=0,
                balance=payload['balance'],
                available=0,
                withdraw_quota=0,
                deposit=0,
                withdraw=0,
                commission=0,
                close_profit=0,
                position_profit=0,
                currency=payload['currency'],
            )
            sc.add(settle_data)
        sc.commit()
        sc.close()
        self.write(json.dumps({
            'code': 0,
            'data': {
                'account': payload['account'],
                'trading_day': str(payload['trading_day']),
                'balance': float(payload['balance']),
                'currency': payload['currency']
            }
        }))
        return True


class AccountFundHistoryForOperationHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        start_trading_day = self.get_argument('start_trading_day', '')
        end_trading_day = self.get_argument('end_trading_day', '')
        accounts = self.get_argument('account', '')
        if not start_trading_day or not end_trading_day or not accounts:
            self.write(json.dumps({
                'code': 1400,
                'error': '接口错误'
            }))
            return False

        account_no_list = accounts.split(',')
        sc = session()
        out_data = {}
        for account_no in account_no_list:
            accounts = sc.query(Accounts).filter_by(name=account_no)
            if 0 == accounts.count():
                sc.close()
                self.write(json.dumps({
                    'code': 1300,
                    'error': '账户%s不存在' % account_no
                }))
                return False

            out_data[account_no] = []
            data = sc.query(
                AccountBalanceCounter.trading_day,
                AccountBalanceCounter.balance,
                AccountBalanceCounter.currency,
                AccountBalanceCounter.deposit,
                AccountBalanceCounter.withdraw,
            ).filter(
                AccountBalanceCounter.account == account_no,
                AccountBalanceCounter.trading_day >= start_trading_day,
                AccountBalanceCounter.trading_day <= end_trading_day,
            ).order_by(
                AccountBalanceCounter.trading_day
            )
            if 0 == data.count():
                data = sc.query(
                    AccountBalanceCounter.trading_day,
                    AccountBalanceCounter.balance,
                    AccountBalanceCounter.currency,
                    AccountBalanceCounter.deposit,
                    AccountBalanceCounter.withdraw,
                ).filter(
                    AccountBalanceCounter.account == account_no
                ).order_by(
                    AccountBalanceCounter.trading_day.desc()
                )

            for r in data:
                out_data[account_no].append(
                    {
                        'trading_day': str(r.trading_day),
                        'balance': float(r.balance),
                        'currency': r.currency,
                        'deposit': float(r.deposit),
                        'withdraw': float(r.withdraw)
                    })
        sc.close()
        self.write(json.dumps({
            'code': 0,
            'data': out_data
        }))
        return True

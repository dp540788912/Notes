# -*-coding:utf-8-*-

from service.account_funds.handlers import *

urls = [
    (r'/api/v1/platform/account_funds', AccountFundsForPlatformHandler),
    (r'/api/v1/platform/account_funds/(?P<id>\w+)$', AccountFundsForPlatformHandler),
    (r'/api/v1/platform/account/deposit_withdraw', DepositWithdrawHandler),
    (r'/api/v1/platform/account/equity', AccountLatestEquityForOperationHandler),
    (r'/api/v1/platform/account/fund/history', AccountFundHistoryForOperationHandler),
]

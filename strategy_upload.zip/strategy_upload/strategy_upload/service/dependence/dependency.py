import os
import sys

root_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
if root_path not in sys.path:
    sys.path.append(root_path)
from db import session_context
from service.back_test.models import Strategy, VStrategies, StrategyPortfolio, StrategyResult, Users
from service.back_test.ev_task import get_live_server_strategy_ids
import json
import consts
import pandas as pd
from redis import Redis
from datetime import datetime
from config import config
from constant import Task, StrategyConstant, CompanyUser
from consts import STOCK_FACTOR_EV
from extensions import sentry


class Node(dict):
    def __init__(self, id, tree):
        """
        {
            "id": 0, // int
            "refs": 0, // int
            "children": [] // List[int]
        }

        :param id: int node id
        :param tree: Tree
        """
        self.tree = tree
        self["refs"] = 0
        self["id"] = id
        self["children"] = []

    def increase(self):
        self["refs"] += 1

    def decrease(self):
        self["refs"] -= 1
        if self["refs"] >= 0:
            return
        for i in self["children"]:
            self.tree[i].decrease()
            if self.tree[i].refs == 0:
                self.tree[i].decrease()

    def add_children(self, id):
        if id in self["children"]:
            return False
        self["children"].append(id)
        self.tree[id].increase()
        return True


class StrategyNode(Node):
    data = None

    def __new__(cls, *args, **kwargs):
        if cls.data is None:
            with session_context() as sc:
                cls.data = {s.id: {"children": s.direct_dep_factor_ids()} for s in sc.query(Strategy)}
        return super().__new__(cls)

    def __init__(self, id, tree):
        super().__init__(id, tree)
        for i in self.data[self.id]["children"]:
            self.add_children(i)


class EvNode(Node):
    data = None

    def __new__(cls, *args, **kwargs):
        if cls.data is None:
            cls.init_data()

        return super().__new__(cls)

    @classmethod
    def init_data(cls):
        data = {}
        with session_context() as sc:
            strategies = sc.query(Strategy, Users).join(Users, Strategy.r_create_user_id == Users.id).filter(
                Strategy.is_delete == 0,
                Strategy.is_test == 0,
            )
            stock_identifier = CompanyUser.stock_ev_user_ids()
            for s in strategies:
                data[s.Strategy.id] = {
                    "children": list(set(s.Strategy.direct_dep_factor_ids() + s.Strategy.direct_dep_ids())),
                    "name": s.Strategy.name,
                    "creator": s.Strategy.r_update_user_id,
                    "creator_name": s.Users.name,
                    "business": 1 if s.Strategy.r_update_user_id in stock_identifier else 0,
                    "node_type": s.Strategy.node,
                    "is_live": False,
                    "is_root": False,
                    "is_error": False
                }
            live_strategy = [i for i in sc.query(
                VStrategies.strategy_id,
                StrategyPortfolio.business
            ).join(
                Strategy, VStrategies.strategy_id == Strategy.id,
            ).join(
                StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
            ).filter(
                VStrategies.status == 15,
                StrategyPortfolio.business.in_(['stock', 'future'])
            )]
            for i in live_strategy:
                temp = data.get(i[0], None)
                if temp is None:
                    continue
                temp["is_live"] = True
                temp["is_root"] = True

        cls.data = data

    def __init__(self, id, tree):
        """
        {
            "id": 0, // int
            "refs": 0, // int
            "creator": 0, // int
            "status": 0, // enum
            "is_root": True, // bool
            "is_live": True, // bool
            "is_error": True, // bool
            "children": [] // List[int]
        }

        :param id: int node id
        :param tree: Tree
        """
        super().__init__(id, tree)
        data = self.data.get(id, None)
        if data is None:
            raise ValueError("this node %s is deleted" % str(id))
        self.update(**data)
        for i in data["children"]:
            try:
                child = self.tree[i]
                child.increase()
                if child["is_error"]:
                    self["is_error"] = True
                if self.live:
                    child.live = True
            #   发现子节点不存在
            except ValueError:
                self["is_error"] = True
                reference = self.tree.get_all_reference_node(self["id"])
                for i in reference:
                    self.tree[i]["is_error"] = True

    @property
    def live(self):
        return self["is_live"]

    @live.setter
    def live(self, value):
        self["is_live"] = value
        if not value:
            return
        # if parent's is_live marked as True,mark children's is_live as True
        for i in self["children"]:
            self.tree[i].live = value

    def increase(self):
        super(EvNode, self).increase()
        if self["is_root"]:
            self["is_root"] = False


class RemoteNode(Node):
    def __init__(self, id, tree, **kw):
        super().__init__(id, tree)
        self.update(**kw)


class Tree(dict):

    def __init__(self, *ids, node_class=Node):
        """
        {
            id: `Node`
        }

        :param ids: init id list
        :param node_class: func(tree:Tree ,key:any)->node:Node
        """
        self.node_class = node_class
        super().__init__()
        for i in ids:
            self[i]

    def add_dependency(self, *ids):
        """
        pass new dependency and return dependency which actually need deploy

        :param ids: list[int]
        :return: list[int]
        """
        old_id = list(self.keys())
        for i in ids:
            self[i]
        new_id = list(self.keys())
        return list(set(new_id) - set(old_id))

    def remove_dependency(self, *ids):
        """
        remove dependency and return dependency which actually need remove

        :param ids: list[int]
        :return:
        example:
            1.
                    A
                  /  \
                B      C

                remove [A],actually need to remove [A,B,C]
            2.
                    A
                  /  \
                B      C

                remove [B],actually need to remove [B]
            3.
                    A     B
                  /  \  /  \
                C     D     E
                remove [A],actually need to remove [A,C]
        """
        for i in ids:
            if i not in self:
                raise ValueError("id:%s not in " % (str(i)))
            self[i].decrease()
        return

    def gc(self):
        """
        collect no use node

        :return: list[Node]
        """
        return [value.id for value in self.values() if value.refs == -1]

    def get_all_dependency_node(self, id):
        result = set()
        return self.__get_all_dependency_node(result, id)

    def __get_all_dependency_node(self, result, id):
        node = self.get(id, None)
        if node is None:
            return result
        result.add(node["id"])
        if len(node["children"]) != 0:
            for i in node["children"]:
                self.__get_all_dependency_node(result, i)
        return result

    def get_all_reference_node(self, id):
        result = set()
        return self.__get_all_reference_node(result, id)

    def __get_all_reference_node(self, result, id):
        node = self.get(id, None)
        if node is None:
            return result
        result.add(node["id"])
        for i in self.values():
            if id in i["children"]:
                self.__get_all_reference_node(result, i["id"])
        return result

    def __missing__(self, k):
        node = self.node_class(k, self)
        self[k] = node
        return node


class RemoteTree(Tree):
    """
    dependence tree communicate with redis
    """
    dependence_tree_key = "strategy_dependence_tree_{date}_{day_night}"

    # lua for update data at redis
    __update_thread_safe = """local content = redis.call('get',KEYS[1])
    local data = cjson.decode(content)
    local node = data[KEYS[2]]
    if (node==nil or node[KEYS[3]] ~= tonumber(KEYS[4]))
    then
        return 0
    end
    node[KEYS[3]] = tonumber(KEYS[5])
    local result = cjson.encode(data)
    result = string.gsub(result, "{}", "[]")
    redis.call('set',KEYS[1],result)
    return 1
    """

    __update_force = """local content = redis.call('get',KEYS[1])
    local data = cjson.decode(content)
    local node = data[KEYS[2]]
    if (node==nil)
    then
        return 0
    end
    node[KEYS[3]] = tonumber(KEYS[4])
    local result = cjson.encode(data)
    result = string.gsub(result, "{}", "[]")
    redis.call('set',KEYS[1],result)
    return 1
    """

    def __init__(self, key=None, auto_pull=False, **redis_param):
        """
        :param key: str key at redis
        :param auto_pull: bool  auto pull from redis if key is not None
        :return: RemoteTree
        """

        super().__init__(node_class=RemoteNode)
        if "host" not in redis_param:
            raise ValueError("you must pass redis host to RemoteTree")
        self.redis = Redis(**redis_param)
        self.key = key
        if auto_pull and key is not None:
            self.pull()

    def parse_tree_data(self, raw):
        """
        parse serialized tree data

        :param raw: str
        :return:
        """
        data = json.loads(raw)
        for key, val in data.items():
            self[int(key)] = self.node_class(**val, tree=self)

    def find_available_to_execute(self):
        """
        find all id which can execute
        :return:
        """
        completed = [value["id"] for key, value in self.items() if value["status"] == Task.TaskStatus.Success.value]
        available = []
        for key, value in self.items():
            if value["status"] != Task.TaskStatus.Created.value:
                continue
            if all([c in completed for c in value["children"]]):
                available.append(value["id"])
        return available

    def update_node(self, id, field, pre_val, val):
        """
        compare pre_val in redis,if no change,then update node data in redis

        :param id: int node id
        :param field: str field of node data
        :param pre_val: any pre_val
        :param val: any field value
        :return: bool
        """
        result = self.redis.eval(self.__update_thread_safe, 5, self.key, id, field, pre_val, val)
        if int(result) == 0:
            return False
        self[id][field] = val
        return True

    def update_node_force(self, id, field, val):
        """
        compare pre_val in redis,if no change,then update node data in redis

        :param id: int node id
        :param field: str field of node data
        :param val: any field value
        :return: bool
        """
        result = self.redis.eval(self.__update_force, 4, self.key, id, field, val)
        if int(result) == 0:
            return False
        self[id][field] = val
        return True

    def add_node(self):
        pass

    def push(self, expire_seconds=8640000, overwrite=False):
        """
        !!! BE CAREFULLY FOR USING THIS METHOD

        :param expire_seconds: int
        :param overwrite: bool
        :return:
        """
        return self.redis.set(self.key, json.dumps(self), ex=expire_seconds, nx=overwrite)

    def pull(self):
        """
        pull data from redis

        :return:
        """
        if self.key is None:
            raise ValueError("you must set key before pull")
        raw = self.redis.get(self.key)
        self.parse_tree_data(raw.decode("utf-8"))

    def key_exists(self):
        return self.redis.exists(self.key)

    def set_key(self, key):
        self.key = key

    def to_df(self):
        return pd.DataFrame.from_dict(self, orient="index")

    def find(self, id=None, user=None, refs=None, is_live=None, is_root=None, is_error=None,
             status=None, node_type=None, business=None, available_only=False):
        """
        filter dependence tree by conditions

        :param id: TypeVar[int, List, Tuple]
        :param user: TypeVar[int, List, Tuple]
        :param refs: int
        :param business:int 0=stock 1=future
        :param status: enum Task.TaskStatus
        :param is_live: bool
        :param is_root: bool
        :param is_error: bool
        :param available_only: bool
        :return: pandas.DataFrame
        """
        df = self.to_df()
        if id is not None:
            df = df[df["id"] == id] if isinstance(id, int) else df[df["id"].isin(id)]
        if user is not None:
            df = df[df["creator"] == user] if isinstance(user, int) else df[df["creator"].isin(user)]
        if is_live is not None:
            df = df[df["is_live"] == is_live]
        if is_root is not None:
            df = df[df["is_root"] == is_root]
        if is_error is not None:
            df = df[df["is_error"] == is_error]
        if refs is not None:
            df = df[df["refs"] == refs]
        if node_type is not None:
            df = df[df["node_type"] == node_type]
        if business is not None:
            df = df[df["business"] == business]
        if status is not None:
            df = df[df["status"] == status]
        if available_only:
            available = self.find_available_to_execute()
            df = df[df.index.isin(available)]
        return df

    def task_plan(self, live_only=True):
        """
        make node task plan

        :return: List[List[int]]
        """
        result = []
        # deep copy
        tree_mirror = json.loads(json.dumps(self))
        keys = list(tree_mirror.keys())
        # convert key to int
        for k in keys:
            val = tree_mirror.pop(k)
            if live_only and not val["is_live"]:
                continue
            tree_mirror[int(k)] = val
            val["status"] = Task.TaskStatus.Created.value
        while True:
            available = RemoteTree.find_available_to_execute(tree_mirror)
            for i in available:
                tree_mirror[i]["status"] = Task.TaskStatus.Success.value
            if len(available) == 0:
                break
            result.append(available)
        return result

    @classmethod
    def from_local(cls, local, key=None, auto_pull=False, **redis_param):
        """
        convert local tree to remote tree for communicating with redis

        :param local: Tree local tree
        :param key: str key at redis
        :param auto_pull: bool  auto pull from redis if key is not None
        :return: RemoteTree
        """
        tree = cls(key=key, auto_pull=auto_pull, **redis_param)
        for key, val in local.items():
            n = tree.node_class(**val, status=Task.TaskStatus.Created.value, tree=tree)
            tree[key] = n
        return tree

    def __str__(self):
        return json.dumps(self, indent=4)


def deploy_simulator(host, new=[], old=[]):
    """
    添加或者移除某个服务器上的依赖，返回需要移除和需要添加的依赖

    :param host: str server host
    :param new: list[int] ids need to be deployed
    :param old: list[int] ids need to be removeed
    :return:
       {"need_deploy": list[int], "need_remove": list[int]}
    """
    live_ids = get_live_server_strategy_ids(host)
    tree = Tree(*live_ids, node_class=StrategyNode)
    need_deploy = tree.add_dependency(*new)
    tree.remove_dependency(*old)
    need_remove = tree.gc()
    return {"need_deploy": need_deploy, "need_remove": need_remove}


def get_strategy_id_from_id_no(*id_nos):
    """
    mapping id_no to id

    :param id_nos: list[str] id_no need to mapping
    :return:
        {id_no: id}
    """
    with session_context() as sc:
        strategy = sc.query(Strategy).filter(
            Strategy.id_no.in_(list(id_nos)))
        return {s.id_no: s.id for s in strategy}


def get_strategy_id_no_from_id(*ids):
    """
    mapping id to id_no

    :param ids: list[int] id need to mapping
    :return:
        {id: id_no}
    """
    with session_context() as sc:
        strategy = sc.query(Strategy).filter(
            Strategy.id.in_(ids))
        return {s.id: s.id_no for s in strategy}


def get_local_dependence_tree():
    """
    this is a example to build default dependence tree

    :return:
    """
    today = datetime.now()
    # 拿到所需节点
    with session_context() as sc:
        strategies = sc.query(Strategy).filter(
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.end_date >= today,
            # Strategy.status != consts.TASK_STOPPED,
        ).order_by('id')
        online = [s.id for s in strategies]
    EvNode.init_data()
    data = EvNode.data
    # 把节点传入依赖树，依赖树自动生成依赖关系
    # 假如没有传子节点，依赖树会自动生成，但是根节点一定要传入
    tree = Tree(*online, node_class=EvNode)
    # 特殊处理,把部分基础因子标为实盘因子
    for i in STOCK_FACTOR_EV:
        tree[i]["is_live"] = True
    return tree


def get_remote_dependence_tree_from_local(local_tree, redis_param=config.redis, key="test_node"):
    """
    example to convert local tree to remote tree

    :param local_tree: Tree
    :param redis_param: dict
    :param key: str
    :return:
    """

    return RemoteTree.from_local(local_tree, key=key, **redis_param)


def dependence_tree_generation(date, day_night, reset=False):
    """
    :param date: str %Y%m%d
    :param day_night: int 0=DAY 1=NIGHT
    :param reset: bool whether reset remote tree in redis
    :return:
    """
    try:
        key = RemoteTree.dependence_tree_key.format(date=date, day_night=str(day_night))
        remote_tree = RemoteTree(key=key, **config.redis)
        if not reset and remote_tree.key_exists():
            remote_tree.pull()
        else:
            local_tree = get_local_dependence_tree()
            for key, val in local_tree.items():
                n = remote_tree.node_class(**val, status=Task.TaskStatus.Created.value, tree=remote_tree)
                remote_tree[key] = n
        remote_tree.push()
        return remote_tree
    except Exception as e:
        sentry.captureException()
        return None

from service.basehandler import BaseHandler, CurrentUserMixin
from config import RedisCache0
from .dependency import RemoteTree
import json
from constant import APIResponseCode
from cron.strategy_upload_task import dependence_producer
from extensions import sentry


class DependenceTreeHandler(CurrentUserMixin, BaseHandler):
    def get(self, date, day_night):
        """
        dependence tree data

        :param date: str %Y%m%d parse from url
        :param day_night: str 0=DAY 1=NIGHT parse from url
        :return:
        """
        self.get_current_user()
        if not self.current_user:
            return
        try:
            client = RedisCache0()
            data = {"code": APIResponseCode.OK.value, "data": "?"}
            key = RemoteTree.dependence_tree_key.format(date=date, day_night=str(day_night))
            tree = client.get(key)
        except Exception as e:
            sentry.captureException()
            self.json_response(
                {
                    'code': APIResponseCode.DefaultError.value,
                    'error': str(e)
                }
            )
            return
        if not tree:
            tree = "{}"
        else:
            tree = tree.decode("utf-8")
        resp = json.dumps(data)
        resp = resp.replace('"?"', tree)
        self.finish(resp)

    def post(self, date, day_night):
        """
        publish task to redo dependence tree

        :param date: str %Y%m%d parse from url
        :param day_night: str 0=DAY 1=NIGHT parse from url

        :payload is_live: bool default=True
        :payload id: int default=None
        :payload business: int 0=future 1=stock
        :payload node_type: str default=None
        :payload user: int default=None
        :payload reset_fail: bool default=False whether reset failed node to created
        :payload reset_referrer: bool default=False whether reset the referred node to created
            这个只有传入id和once is True才会有效
        :payload once: bool default=True
        :payload is_live: bool

        :return:
        """
        self.get_current_user()
        if not self.current_user:
            return
        once = self.get_argument("once", True)
        is_live = self.get_argument("is_live", True)
        reset_fail = self.get_argument("reset_fail", False)
        reset_referrer = self.get_argument("reset_referrer", False)
        id = self.get_argument("id", None)
        business = self.get_argument("business", None)
        node_type = self.get_argument("node_type", None)
        user = self.get_argument("user", None)
        try:
            task_id = dependence_producer.delay(date=date, day_night=day_night, is_live=is_live, user=user, id=id,
                                                business=business, once=once, node_type=node_type,
                                                reset_fail=reset_fail, reset_referrer=reset_referrer)
        except Exception as e:
            sentry.captureException()
            self.json_response(
                {
                    'code': APIResponseCode.DefaultError.value,
                    'error': str(e)
                }
            )
            return
        self.json_response({
            "code": APIResponseCode.OK.value,
            "data": task_id
        })

from service.dependence.handlers import DependenceTreeHandler

urls = [
    (r'/api/v1/platform/dependence/(\d{8})/(\d{1})', DependenceTreeHandler),
]

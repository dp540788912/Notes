#-*-coding:utf-8-*-

from service.order_list.handlers import *

urls = [
    (r'/api/v1/platform/orderlist$', OrderListHandler),
    (r'/api/v1/platform/orderlist/strategy$', OrderListStrategyHandler),
    (r'/api/v1/platform/orderlist/hedge$', OrderListHedgeHandler),

    (r'/api/v1/platform/tradelist$', TradeListHandler),
    (r'/api/v1/platform/tradelist/trading_date$', TradeListTradingDateHandler),
    (r'/api/v1/platform/tradelist/quantamental$', TradeListQuantamentalHandler),
]

#-*-coding:utf-8-*-

import pandas as pd
from dateutil.parser import parse
from sqlalchemy.sql import func
from sqlalchemy import Column
from sqlalchemy.dialects.mysql import BIGINT, VARCHAR, FLOAT, BOOLEAN, DATETIME, INTEGER, JSON, DOUBLE, TEXT, DATE, TIME
from db import ModelBase, session


class TradeHedge(ModelBase):
    __tablename__ = 'tradehedge'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=True)
    date = Column(VARCHAR(16), nullable=False)
    strategy_id = Column(INTEGER, nullable=False)
    symbol = Column(VARCHAR(32), nullable=False)
    hedge_type = Column(VARCHAR(128), nullable=True)
    threshold = Column(VARCHAR(128), nullable=True)
    frequency = Column(VARCHAR(128), nullable=True)

    def detail(self):
        return {
            'id': self.id,
            'date': self.date,
            'strategy_id': self.strategy_id,
            'symbol': self.symbol,
            'hedge_type': self.hedge_type or '',
            'threshold': self.threshold or '',
            'frequency': self.frequency or '',
        }


class OrderList(ModelBase):

    __tablename__ = 'orderlist'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=True)
    date = Column(VARCHAR(16), nullable=False)
    strategy_id = Column(INTEGER, nullable=False)
    symbol = Column(VARCHAR(32), nullable=False)
    weight = Column(DOUBLE, nullable=True)
    size = Column(INTEGER, nullable=True)
    limit_price = Column(DOUBLE, nullable=True)
    algo = Column(VARCHAR(16), nullable=False)
    start = Column(VARCHAR(16), nullable=False)
    end = Column(VARCHAR(16), nullable=True)
    hedge_id = Column(INTEGER, nullable=False)

    def detail(self):
        return {
            'id': self.id,
            'date': self.date,
            'strategy_id': self.strategy_id,
            'symbol': self.symbol,
            'weight': self.weight and float(self.weight),
            'size': self.size,
            'limit_price': self.limit_price and float(self.limit_price),
            'algo': self.algo,
            'start': self.start,
            'end': self.end or '',
            'hedge_id': self.hedge_id,
        }

    @staticmethod
    def generate_ev_file(strategy_id, date, ev_filename):
        date = parse(date).strftime('%Y%m%d')
        strategy_id = int(strategy_id)
        sc = session()
        s_order_list = sc.query(OrderList).filter(
            OrderList.strategy_id == strategy_id,
            OrderList.date == date,
        )
        orderlist_count = s_order_list.count()
        if orderlist_count <= 0:
            sc.close()
            raise ValueError('order list is empty strategy_id=%s, date=%s' % (strategy_id, date))
        columns = ['symbol', 'weight', 'size', 'limit_price', 'algo', 'start', 'end']
        trade_list = []
        for o in s_order_list:
            o_d = o.detail()
            try:
                o_d['weight'] = float(o_d['weight'])
            except Exception as e:
                pass
            trade_list.append([o_d[k] for k in columns])
        trade_list_pd = pd.DataFrame(data=trade_list, columns=columns)
        trade_list_pd.to_csv(ev_filename, index=False, encoding='utf8')
        sc.close()
        return True

    @staticmethod
    def trade_list_generate(strategy_id, date):
        date = parse(date).strftime('%Y%m%d')
        sc = session()
        if strategy_id:
            order_list = sc.query(OrderList).filter(OrderList.strategy_id == int(strategy_id), OrderList.date == date)
        else:
            order_list = sc.query(OrderList).filter(OrderList.date == date)

        order_list = [o.detail() for o in order_list]
        _columns = ['id', 'strategy_id', 'hedge_id', 'symbol', 'weight', 'size', 'limit_price', 'algo', 'start', 'end']
        res = {}
        for l in order_list:
            s_order_list = res.setdefault(l['strategy_id'], {
                'trade_list': []
            })
            s_order_list['trade_list'].append([l[k] for k in _columns])

        result = {}
        for s_id, s_order_list in res.items():
            trade_list = pd.DataFrame(data=s_order_list['trade_list'], columns=_columns)
            result[int(s_id)] = trade_list[
                ['symbol', 'weight', 'size', 'limit_price', 'algo', 'start', 'end']
            ].to_csv(index=False)
        sc.close()
        return result

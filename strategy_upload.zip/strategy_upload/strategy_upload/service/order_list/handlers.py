#-*-coding:utf-8-*-

import sys
if sys.version_info[0] < 3:
    from StringIO import StringIO
else:
    from io import StringIO
import pandas
import numpy
import datetime
from dateutil.parser import parse
from tornado import gen
from sqlalchemy import or_, and_

from db import session
from service.order_list.models import TradeHedge, OrderList
from service.basehandler import BaseHandler, CurrentUserMixin, JsonPayloadMixin
from service.back_test.models import Strategy, Quantamentals, QuantamentalDetails
from kdb_query import KdbQuery

def get_today():
    now = datetime.datetime.now()
    return now.strftime("%Y%m%d")


class OrderListHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        sc = session()
        date = parse(self.get_argument('date')).strftime('%Y%m%d')
        hedges = sc.query(TradeHedge).filter(TradeHedge.date == date)
        order_list = sc.query(OrderList).filter(OrderList.date == date)
        hedges = [h.detail() for h in hedges]
        order_list = [o.detail() for o in order_list]
        strategy_ids = list(set([l['strategy_id'] for l in hedges] + [l['strategy_id'] for l in order_list]))
        res = {
            'date': date,
            'hedge_keys': ['id', 'strategy_id', 'symbol', 'hedge_type', 'threshold', 'frequency'],
            'trade_list_keys': ['id', 'strategy_id', 'hedge_id', 'symbol', 'weight', 'size', 'limit_price', 'algo', 'start', 'end'],
            'detail': []
        }
        for s_id in sorted(strategy_ids):
            d = {
                'strategy_id': s_id,
                'hedge': [[l[k] for k in res['hedge_keys']] for l in hedges if l['strategy_id'] == s_id],
                'trade_list': [[l[k] for k in res['trade_list_keys']] for l in order_list if l['strategy_id'] == s_id]
            }
            res['detail'].append(d)
        sc.close()
        data = {
            'code': 0,
            'data': res
        }
        self.json_response(data)
        return


class OrderListStrategyHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        sc = session()
        strategies = sc.query(Strategy).filter(
            Strategy.r_create_user_id == self.current_user['id'],
            Strategy.node.in_(['order_list', 'trademaster_order_list']),
            Strategy.is_test == 0,
            Strategy.is_delete == 0,
        )
        res = [
            {
                'strategy_id': s.id_no,
                'id': s.id,
                'name': s.name,
                'desc': s.description,
            } for s in strategies
        ]
        sc.close()
        data = {
            'code': 0,
            'data': res
        }
        self.json_response(data)
        return


class OrderListHedgeHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        payload = self.get_payload()
        """
        payload = {
            'date': '20170621',
            'strategy_id': 1,
            'hedge': {
                'symbol': 'IF',
                'hedge_type': 'xxx',
                'threshold': 'xxx',
                'frequency': 'xxx'
            },
            'trade_list': {
                'keys': ['symbol', 'weight', 'limit_price', 'algo', 'start', 'end'],
                'values': [
                    ['600001', 12.3, 45.6, 'vwap', '13:00', '15:00']
                ],
            }
        }
        trade list ： date strategy_id  symbol weight limit_price algo start end
        对冲 ： date strategy_id symbol hedge_type  threshold   frequency
        weight limit_price  是 float
        """
        sc = session()
        strategy = sc.query(Strategy).filter(
            Strategy.id == payload['strategy_id'],
            Strategy.r_create_user_id == self.current_user['id'],
            Strategy.node.in_(['order_list', 'trademaster_order_list']),
        ).first()
        if not strategy:
            self.json_response({
                'code': 1113,
                'error': 'strategy is not find or is not order list type'
            })
            sc.close()
            return
        hedge = sc.query(TradeHedge).filter(
            TradeHedge.date == payload['date'],
            TradeHedge.strategy_id == payload['strategy_id'],
        )
        order_list = sc.query(OrderList).filter(
            OrderList.date == payload['date'],
            OrderList.strategy_id == payload['strategy_id']
        )
        hedge = hedge.first()
        if not hedge:
            hedge = TradeHedge(
                r_create_user_id=self.current_user['id'],
                r_update_user_id=self.current_user['id'],
                date=payload['date'],
                strategy_id=payload['strategy_id'],
                symbol=payload['hedge']['symbol'],
                hedge_type=payload['hedge']['hedge_type'],
                threshold=payload['hedge']['threshold'],
                frequency=payload['hedge']['frequency']
            )
            sc.add(hedge)
            sc.commit()
        else:
            hedge.symbol = payload['hedge']['symbol']
            hedge.hedge_type = payload['hedge']['hedge_type']
            hedge.threshold = payload['hedge']['threshold']
            hedge.frequency = payload['hedge']['frequency']
            hedge.r_update_user_id = self.current_user['id']
        order_list.delete()
        hedge_id = hedge.id
        keys_index = {k: index for index, k in enumerate(payload['trade_list']['keys'])}
        sum_weight = 0
        for v in payload['trade_list']['values']:
            order_kwargs = {
                'r_create_user_id': self.current_user['id'],
                'r_update_user_id': self.current_user['id'],
                'date': payload['date'],
                'strategy_id': payload['strategy_id'],
                'hedge_id': hedge_id,
                'symbol': v[keys_index['symbol']],
                #'weight': float(v[keys_index['weight']]),
                'algo': v[keys_index['algo']],
                'start': v[keys_index['start']],
                'end': v[keys_index['end']],
            }
            if (keys_index.get('weight', -1) >= 0) and (v[keys_index['weight']] or v[keys_index['weight']] == 0):
                order_kwargs['weight'] = float(v[keys_index['weight']])
                sum_weight += abs(order_kwargs['weight'])
            if (keys_index.get('size', -1) >= 0) and (v[keys_index['size']] or v[keys_index['size']] == 0):
                order_kwargs['size'] = int(v[keys_index['size']])
            if v[keys_index['limit_price']]:
                order_kwargs['limit_price'] = float(v[keys_index['limit_price']])
            if ('weight' not in order_kwargs) and ('size' not in order_kwargs):
                sc.close()
                self.json_response({
                    'code': 1030,
                    'error': 'orderlist error:symbol(%s) miss weight and size' % order_kwargs['symbol']
                })
                return False
            o = OrderList(
                **order_kwargs
            )
            sc.add(o)
        if sum_weight > 1:
            sc.close()
            self.json_response({
                'code': 1029,
                'error': 'sum of abs_weight > 1'
            })
            return False
        sc.commit()
        sc.close()
        data = {
            'code': 0
        }
        self.json_response(data)
        return


class TradeListHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        sc = session()
        hedges = None
        order_list = None

        date = self.get_argument('date', None)
        if date is not None:
            date = parse(date).strftime('%Y%m%d')
            hedges = sc.query(TradeHedge).filter(TradeHedge.date == date)
            order_list = sc.query(OrderList).filter(OrderList.date == date)

        start_date = self.get_argument('start_date', None)
        if start_date is not None:
            start_date = parse(start_date).strftime('%Y%m%d')
            end_date = self.get_argument('end_date', None)
            if end_date is None:
                end_date = get_today()
            else:
                end_date = parse(end_date).strftime('%Y%m%d')
            hedges = sc.query(TradeHedge).filter(and_(TradeHedge.date >= start_date, TradeHedge.date <= end_date))
            order_list = sc.query(OrderList).filter(and_(OrderList.date >= start_date, OrderList.date <= end_date))

        st_id = self.get_argument('st_id', None)
        if st_id is not None:
            st_id = int(st_id)
            if hedges is None:
                hedges = sc.query(TradeHedge).filter(TradeHedge.strategy_id == st_id)
                order_list = sc.query(OrderList).filter(OrderList.strategy_id == st_id)
            else:
                hedges = hedges.filter(TradeHedge.strategy_id == st_id)
                order_list = order_list.filter(OrderList.strategy_id == st_id)


        hedges = [h.detail() for h in hedges]
        order_list = [o.detail() for o in order_list.order_by(OrderList.date.asc())]
        #all_ids = list(set([l['strategy_id'] for l in hedges] + [l['strategy_id'] for l in order_list]))
        #all_dates = list(set([l['date'] for l in hedges] + [l['date'] for l in order_list]))

        res = {
            'hedge_keys': ['id', 'strategy_id', 'symbol', 'hedge_type', 'threshold', 'frequency'],
            'trade_list_keys': ['id', 'strategy_id', 'hedge_id', 'symbol', 'weight', 'size', 'limit_price', 'algo',
                                'start', 'end'],
        }

        q_strat_id = int(self.get_argument('q_id', 0))
        if q_strat_id > 0:
            res['trade_list_keys'].append('direction')

            quantamentals = sc.query(
                QuantamentalDetails.direction.label('direction'), QuantamentalDetails.date.label('date'),
                Quantamentals.product.label('product'),
            ).join(
                Quantamentals, QuantamentalDetails.quantamental_id == Quantamentals.id,
            ).filter(
                Quantamentals.q_strat_id == q_strat_id,
            )
            q_details, q_date_list = {}, {}
            for q in quantamentals:
                q_details.setdefault(q.product.lower(), {})
                q_details[q.product.lower()][q.date] = q.direction
            q_date_list = {k: sorted(list(v.keys())) for k, v in q_details.items()}

        data = {}
        for l in hedges:
            if l['strategy_id'] not in data:
                data[l['strategy_id']] = {
                    'st_id': l['strategy_id'],
                    'detail': {}
                }
            if l['date'] not in data[l['strategy_id']]['detail']:
                data[l['strategy_id']]['detail'][l['date']] = {
                    'date': l['date'],
                    'hedge': [],
                    'trade_list': [],
                }
            data[l['strategy_id']]['detail'][l['date']]['hedge'].append([l[k] for k in res['hedge_keys']])

        current_idx = {}
        for l in order_list:
            if l['strategy_id'] not in data:
                data[l['strategy_id']] = {
                    'st_id': l['strategy_id'],
                    'detail': {}
                }
            if l['date'] not in data[l['strategy_id']]['detail']:
                data[l['strategy_id']]['detail'][l['date']] = {
                    'date': l['date'],
                    'hedge': [],
                    'trade_list': [],
                }
            trade_list_detail = [l[k] for k in res['trade_list_keys'] if k != 'direction']

            if 'direction' in res['trade_list_keys']:
                _symbol = l['symbol']
                _direction = 0
                _date = l['date']
                _product = _symbol if _symbol.isdigit() else ''.join([_x.lower() for _x in _symbol if _x.isalpha()])
                if _product not in current_idx:
                    current_idx[_product] = 0
                if _product in q_date_list:
                    if _date >= q_date_list[_product][0]:
                        while current_idx[_product] < len(q_date_list[_product]) - 1:
                            if _date >= q_date_list[_product][current_idx[_product]] and _date < q_date_list[_product][current_idx[_product] + 1]:
                                _direction = q_details[_product][q_date_list[_product][current_idx[_product]]]
                                break
                            else:
                                current_idx[_product] += 1
                        else:
                            _direction = q_details[_product][q_date_list[_product][-1]]
                trade_list_detail.append(_direction)

            data[l['strategy_id']]['detail'][l['date']]['trade_list'].append(trade_list_detail)

        for st_id, detail in data.items():
            detail['detail'] = sorted(detail['detail'].values(), key=lambda _d: _d['date'])
        sc.close()
        res['code'] = 0
        res['data'] = sorted(data.values(), key=lambda _d: _d['st_id'])

        self.json_response(res)
        return

    @gen.coroutine
    def post(self, *args, **kwargs):
        """
        Admin-only POST handler to overwrite historical trade lists by uploading a file
        """
        self.get_current_user()
        if not self.current_user:
            return False
        strategy_id = self.get_argument('strategy_id', -1)
        # Check for superuser privilege
        #if not self.current_user['is_superuser']:
        #    self.json_response({
        #        'code': 1004,
        #        'error': 'Only administrators can perform this action.'
        #    })
        #    return

        sc = session()
        try:
            # Check if the strategy is a trade-list strategy
            if not self.current_user['is_superuser']:
                strategy = sc.query(Strategy).filter(
                    Strategy.id == strategy_id,
                    Strategy.node.in_(['order_list', 'trademaster_order_list']),
                    Strategy.r_create_user_id == self.current_user['id'],
                ).first()
            else:
                strategy = sc.query(Strategy).filter(
                    Strategy.id == strategy_id,
                    Strategy.node.in_(['order_list', 'trademaster_order_list']),
                ).first()
            if not strategy:
                self.json_response({
                    'code': 1005,
                    'error': 'Strategy not found, or is not a trade-list strategy.'
                })
                return

            upload_file = self.request.files['file'][0]
            file_name = upload_file['filename']
            if file_name.split('.')[-1] != 'csv':
                self.json_response({
                    'code': 1002,
                    'error': 'The file uploaded must be in ".csv" format.'
                })
                return
            file_body = upload_file['body']
            file_body = file_body.decode("utf-8").replace('\\r', '\r').replace('\\n', '\n')
            trade_list = pandas.read_csv(StringIO(file_body), sep=',', dtype={
                'date': str, 'symbol': str, 'weight': numpy.float64, 'size': numpy.float64,
                'limit_price': numpy.float64, 'algo': str, 'start': str, 'end': str
            })

            # Check columns
            cols = trade_list.columns.tolist()
            missing_cols = [x for x in ['date', 'symbol', 'algo', 'start', 'end'] if x not in cols]
            if 'size' not in cols and 'weight' not in cols:
                missing_cols.append('size')
                missing_cols.append('weight')
            if missing_cols:
                self.json_response({
                    'code': 1002,
                    'error': 'Missing column(s) [%s] from the csv file.' % ', '.join(missing_cols)
                })
                return

            # Prepare database operations
            if not self.current_user['is_superuser']:
                trade_list_max_date = trade_list['date'].max()
                if trade_list_max_date > strategy.r_create_time.strftime('%Y%m%d'):
                    self.json_response({
                        'code': 1002,
                        'error': 'tradlist error: max trading date must be earlier than strategy upload_date'
                    })
                    return
            trade_list.sort_values(by='date', inplace=True)

            if 'weight' in cols:
                trade_list['abs_weight'] = trade_list['weight'].apply(lambda _d: abs(_d) if _d else 0)
                if any(trade_list.groupby('date')['abs_weight'].sum() > 1):
                    self.json_response({
                        'code': 1029,
                        'error': "trade_list.groupby('date')['abs_weight'].sum() > 1"
                    })
                    return
                del trade_list['abs_weight']

            trade_list_to_delete = sc.query(OrderList).filter(
                OrderList.date <= trade_list['date'].max(),
                OrderList.strategy_id == strategy_id
            )
            trade_list_to_delete.delete()

            sc.commit()

            date_index = cols.index('date')
            symbol_index = cols.index('symbol')
            algo_index = cols.index('algo')
            start_index = cols.index('start')
            end_index = cols.index('end')

            weight_index, size_index, limit_price_index = -1, -1, -1
            if 'weight' in cols:
                weight_index = cols.index('weight')
            if 'size' in cols:
                size_index = cols.index('size')
            if 'limit_price' in cols:
                limit_price_index = cols.index('limit_price')

            orderlists = []
            for row in trade_list.values:
                order_kwargs = {
                    'r_create_user_id': self.current_user['id'],
                    'r_update_user_id': self.current_user['id'],
                    'date': row[date_index],
                    'strategy_id': strategy_id,
                    'hedge_id': -1,   # No hedge as of 2017.09.05
                    'symbol': row[symbol_index],
                    'algo': row[algo_index],
                    'start': row[start_index],
                    'end': row[end_index],
                    'weight': None,
                    'size': None,
                    'limit_price': None,
                }
                if weight_index >= 0 and not numpy.isnan(row[weight_index]):
                    order_kwargs['weight'] = row[weight_index]
                if size_index >= 0 and not numpy.isnan(row[size_index]):
                    order_kwargs['size'] = row[size_index]
                if limit_price_index >= 0 and not numpy.isnan(row[limit_price_index]):
                    order_kwargs['limit_price'] = row[limit_price_index]
                orderlists.append(order_kwargs)
            sc.execute(OrderList.__table__.insert(), orderlists)
            sc.commit()
        except Exception as e:
            self.application.sentry.captureException()
            sc.rollback()
            self.json_response({
                'code': 1002,
                'error': 'Unknown error occurs. Please check the system log.'
            })
            return
        finally:
            sc.close()

        self.json_response({'code': 0})
        return


class TradeListTradingDateHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        kdb = KdbQuery()
        begin_date = datetime.datetime.now()
        begin_date_str = begin_date.strftime('%Y%m%d')
        end_date = begin_date + datetime.timedelta(days=40)
        days = kdb.get_trading_days(begin_date_str, end_date.strftime('%Y%m%d'))
        now_hour = begin_date.hour
        if days[0] == begin_date_str and (now_hour >= 9):
            trading_date = days[1]
        else:
            trading_date = days[0]
        self.json_response({
            'code': 0,
            'data': {
                'trading_date': trading_date
            }
        })
        return True


class TradeListQuantamentalHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        q_id = int(self.get_argument('q_id', 0))
        data = {}
        try:
            sc = session()
            if q_id <= 0:
                self.json_response({
                    'code': -1,
                    'error': '',
                    'data': {},
                })
                return
            quantamentals = sc.query(Quantamentals).filter(Quantamentals.q_strat_id == q_id)
            for _q in quantamentals:
                product = _q.product
                data[product] = {}
                quantamental_details = sc.query(QuantamentalDetails).filter(
                    QuantamentalDetails.quantamental_id == _q.id,
                )
                for _d in quantamental_details:
                    data[product][_d.date] = _d.direction

        except Exception as e:
            self.application.sentry.captureException()
            sc.rollback()
            self.json_response({
                'code': -1,
                'error': '',
                'data': {},
            })
            return
        finally:
            sc.close()

        self.json_response({
            'code': 0,
            'data': data,
        })

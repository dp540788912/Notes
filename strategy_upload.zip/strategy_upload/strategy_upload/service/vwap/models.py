# -*-coding:utf-8-*-

import os
import datetime
import csv
import math
import pandas as pd
import numpy as np
from dateutil.parser import parse
from sqlalchemy.sql import func
from sqlalchemy import Column
from sqlalchemy import distinct
from sqlalchemy.schema import UniqueConstraint
from sqlalchemy.dialects.mysql import BIGINT, VARCHAR, FLOAT, BOOLEAN, DATETIME, INTEGER, JSON, DOUBLE, TEXT, DATE, TIME

import consts
from kdb_query import KdbQuery
from db import ModelBase, session, session_context, engine
from utils import get_stock_detail, get_cache, set_cache, del_cache
from extensions import sentry
from service.back_test.models import Strategy, VStrategies, StrategyPortfolio, ParentOrder
from constant import CommonPath, StrategyConstant, VStrategiesConstant
from utility.db_util import TradeCalendar, migrate
from config import config


def calc_strategy_daily_slippage(vwap_results_df, vwap_info_df):
    if vwap_info_df.empty:
        vwap_results_df['exec_value'] = vwap_results_df[['parent_order_size', 'exec_vwap', 'filled_rate']].product(
            axis=1)
        vwap_results_df['weightd_vwap_slippage'] = vwap_results_df.apply(
            lambda row: row['exec_value'] * row['vwap_slippage'] / vwap_results_df['exec_value'].sum(),
            axis=1
        )
        return {
            'avg': vwap_results_df['weightd_vwap_slippage'].sum(),
            'std': vwap_results_df['vwap_slippage'].std(),
            'total_value': vwap_results_df['exec_value'].sum(),
        }
    else:
        vwap_results_df['traded_size'] = vwap_results_df['parent_order_size'] * vwap_results_df['filled_rate']
        vwap_results_df['traded_amt'] = vwap_results_df['traded_size'] * vwap_results_df['exec_vwap']
        vwap_results_df_tmp = vwap_results_df.groupby(['symbol', 'direction'])[
            ['traded_size', 'traded_amt']].sum().reset_index()
        vwap_results_df_tmp['exec_vwap'] = vwap_results_df_tmp['traded_amt'] / vwap_results_df_tmp['traded_size']

        vwap_info_df['mkt_vwap'] = vwap_info_df['turnover'] / vwap_info_df['size']
        vwap_perf_merged = vwap_results_df_tmp.merge(vwap_info_df, left_on=['symbol', 'direction'],
                                                     right_on=['symbol', 'direction'], how='inner')
        vwap_perf_merged['slippage'] = vwap_perf_merged.apply(
            lambda x: (x['exec_vwap'] / x['mkt_vwap'] - 1) * 10000 if x['direction'] == 1 else (x['exec_vwap'] / x[
                'mkt_vwap'] - 1) * -10000, axis=1
        )
        daily_slippage = (vwap_perf_merged['slippage'] * vwap_perf_merged['traded_amt']).sum() / vwap_perf_merged[
            'traded_amt'].sum()
        return {
            'avg': daily_slippage,
            'std': vwap_results_df['vwap_slippage'].std(),
            'total_value': vwap_perf_merged['traded_amt'].sum(),
        }


def get_product_to_exchange_info():
    kdb = KdbQuery()
    product2exchange = {}
    product2exchange.update(get_stock_detail())
    product2exchange.update(consts.LONGPRODUCT2EXCHANGE)
    product2exchange.update(consts.SHORTPRODUCTS2EXCHANGE)
    product2exchange.update(kdb.get_symbol_exchange())
    return product2exchange


def parse_filename(filename):
    fields = filename.split('_')
    if len(fields) != 10:
        raise ValueError('executions filename (%s)error:' % filename)
    # 20161130_000001_59404_buy_95300_105100_2800000000000009_vwap_sim_execution.csv
    if fields[8] not in ('sim', 'real'):
        raise ValueError('executions filename (%s) status, error:' % filename)
    res = {
        'day_night': 0 if 90000 <= int(fields[4]) <= 153000 else 1,
        'trading_date': '',
        'internal_date': '',
        'calendar_date': fields[0],
        'symbol': fields[1],
        'direction': {'buy': 0, 'sell': 1}[fields[3]],
        'parent_order_id': fields[6],
        'vstrategy_id': int(fields[6][-6:]),
        'short_product': fields[1],
        'product': fields[1],
        'algorithm': fields[7],
        'status': fields[8],
    }
    if fields[8] == 'sim':
        res['trading_date'] = res['calendar_date']
        res['internal_date'] = res['calendar_date']
    else:
        if res['day_night'] == 0:
            res['trading_date'] = res['calendar_date']
            res['internal_date'] = res['calendar_date']
        else:
            calendar_date = parse(res['calendar_date'])
            if 0 <= int(fields[4]) <= 73000:
                res['internal_date'] = (calendar_date + datetime.timedelta(days=-1)).strftime('%Y%m%d')
                res['trading_date'] = Strategy.get_trading_date(calendar_date=res['calendar_date'], calendar_hour=7)
            else:
                res['internal_date'] = res['calendar_date']
                res['trading_date'] = Strategy.get_trading_date(calendar_date=res['calendar_date'], calendar_hour=21)
    return res


class VwapOrder(ModelBase):
    """
    实盘的vwap数据 每天盘后从实盘服务器下载 导入数据库
    表结构 和实盘输出的vwap文件对应
    """
    __tablename__ = 'vwap_orders'

    __table_args__ = (
        UniqueConstraint('parent_order_id', 'trading_date', 'day_night', 'status'),
    )
    id = Column(BIGINT(unsigned=True), primary_key=True)
    parent_order_id = Column(VARCHAR(64), nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)
    day_night = Column(INTEGER, nullable=False)
    algorithm = Column(VARCHAR(16), nullable=False)
    status = Column(VARCHAR(16), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())


class VwapExecution(ModelBase):
    """
    实盘的vwap数据 每天盘后从实盘服务器下载 导入数据库
    表结构 和实盘输出的vwap文件对应
    """

    __tablename__ = 'vwap_executions'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    order_id = Column(BIGINT, nullable=False, index=True)
    parent_order_id = Column(VARCHAR(64), nullable=False, index=True)
    trading_date = Column(DATE, nullable=False)
    trade_time = Column(TIME, nullable=False)
    internal_date = Column(DATE, nullable=False)
    calendar_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    symbol = Column(VARCHAR(128), nullable=False)
    direction = Column(INTEGER, nullable=False)
    parent_order_size = Column(INTEGER, nullable=False)
    child_order_size = Column(INTEGER, nullable=False)
    exec_size = Column(INTEGER, nullable=False)
    exec_price = Column(DOUBLE, nullable=False)
    order_type = Column(INTEGER, nullable=False)
    vtraded = Column(INTEGER, nullable=False)
    vtarget = Column(INTEGER, nullable=False)
    indicator = Column(FLOAT, nullable=False)
    filename = Column(VARCHAR(256), nullable=True)
    vstrategy_id = Column(BIGINT, nullable=False)
    account = Column(VARCHAR(32), nullable=False)
    user_id = Column(INTEGER, nullable=False)
    status = Column(VARCHAR(16), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    order_sent_time = Column(INTEGER, nullable=False, default=0)

    @staticmethod
    def import_from_csv(filename):
        f = open(filename)
        file_base_name = os.path.basename(filename)
        filename_parse = parse_filename(file_base_name)
        sc = session()
        exists = sc.query(VwapExecution.id).filter(VwapExecution.filename == file_base_name).limit(1).first()
        if exists:
            sc.close()
            return True
        vwaporder = sc.query(VwapOrder).filter(
            VwapOrder.parent_order_id == filename_parse['parent_order_id'],
            VwapOrder.trading_date == filename_parse['trading_date'],
            VwapOrder.day_night == filename_parse['day_night'],
            VwapOrder.status == filename_parse['status'],
        ).first()
        if not vwaporder:
            vwaporder = VwapOrder(
                parent_order_id=filename_parse['parent_order_id'],
                trading_date=filename_parse['trading_date'],
                day_night=filename_parse['day_night'],
                algorithm=filename_parse['algorithm'],
                status=filename_parse['status'],
            )
            sc.add(vwaporder)
            sc.commit()
        if filename_parse['status'] == 'real':
            vstrategy_detail = sc.query(
                VStrategies.symbols_accounts_detail.label('symbols_accounts_detail'),
                StrategyPortfolio.r_create_user_id.label('user_id')
            ).join(
                StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
            ).filter(VStrategies.id == filename_parse['vstrategy_id']).first()
            user_id = vstrategy_detail.user_id
            symbols_accounts = VStrategies.normalization_symbols_accounts(vstrategy_detail.symbols_accounts_detail)
            kdb = KdbQuery()
            product2exchange = {}
            product2exchange.update(get_stock_detail())
            product2exchange.update(consts.LONGPRODUCT2EXCHANGE)
            product2exchange.update(consts.SHORTPRODUCTS2EXCHANGE)
            product2exchange.update(kdb.get_symbol_exchange())
            exchange2accounts = {symbol_account['exchange']: symbol_account['account'] for symbol_account in
                                 symbols_accounts}
            if ('SSE' not in exchange2accounts) and ('SZSE' in exchange2accounts):
                exchange2accounts['SSE'] = exchange2accounts['SZSE']
            if ('SZSE' not in exchange2accounts) and ('SSE' in exchange2accounts):
                exchange2accounts['SZSE'] = exchange2accounts['SSE']
            account = exchange2accounts[product2exchange[filename_parse['product']]]
        elif filename_parse['status'] == 'sim':
            strategy = sc.query(
                Strategy.r_create_user_id
            ).filter(Strategy.id == filename_parse['vstrategy_id']).first()
            if not strategy:
                sc.close()
                raise ValueError('can not find strategy: strategy_id=%s' % filename_parse['vstrategy_id'])
            user_id = strategy[0]
            account = ''
        reader = csv.DictReader(f)
        trading_date = parse(filename_parse['trading_date'])
        internal_date = parse(filename_parse['internal_date'])
        calendar_date = parse(filename_parse['calendar_date'])
        for row in reader:
            trade_time_str = row['Time'].zfill(9)
            trade_time_str = '%s:%s:%s.%s' % (
                trade_time_str[:2], trade_time_str[2:4], trade_time_str[4:6], trade_time_str[6:9])
            trade_time = parse(trade_time_str).time()
            indicator = float(row['Indicator'])
            if indicator == float('-inf'):
                indicator = 0
            if math.isnan(indicator):
                indicator = 0
            exe = VwapExecution(
                order_id=vwaporder.id,
                parent_order_id=filename_parse['parent_order_id'],
                trading_date=trading_date,
                trade_time=trade_time,
                internal_date=internal_date,
                calendar_date=calendar_date,
                day_night=filename_parse['day_night'],
                symbol=filename_parse['symbol'],
                direction=filename_parse['direction'],
                parent_order_size=int(row['ParentOrderSize']),
                child_order_size=int(row['ChildOrderSize']),
                exec_size=int(row['ExecSize']),
                exec_price=float(row['ExecPrice']),
                order_type={'PASSIVE': 1, 'AGGRESSIVE': 2}[row['Order_type'].upper()],
                vtraded=int(row['Vtraded']),
                vtarget=int(row['Vtarget']),
                indicator=indicator,
                filename=file_base_name,
                vstrategy_id=filename_parse['vstrategy_id'],
                account=account,
                user_id=user_id,
                status=filename_parse['status'],
                order_sent_time=int(row.get('OrderSentTime', 0) or 0),
            )
            sc.add(exe)
        sc.commit()
        sc.close()
        return True

    def brief(self):
        return {
            'OrderID': self.order_id,
            'vstrategy_id': self.vstrategy_id,
            'ParentID': self.parent_order_id,
            'trading_date': self.trading_date.strftime('%Y%m%d'),
            'day_night': self.day_night,
            'Symbol': self.symbol,
            'Direction': self.direction,
            'ParentOrderSize': self.parent_order_size,
            'Account': self.account,
        }

    def detail(self):
        return {
            'OrderID': self.order_id,
            'ParentID': self.parent_order_id,
            'trading_date': self.trading_date.strftime('%Y%m%d'),
            'day_night': self.day_night,
            'Time': int(self.trade_time.strftime('%H%M%S000')),
            'ParentOrderSize': self.parent_order_size,
            'ChildOrderSize': self.child_order_size,
            'ExecSize': self.exec_size,
            'ExecPrice': float(self.exec_price),
            'Order_type': self.order_type,
            'Vtraded': self.vtraded,
            'Vtarget': self.vtarget,
            'Indicator': self.indicator,
            'OrderSentTime': self.order_sent_time,
        }


class VwapIndicator(ModelBase):
    """
    实盘的vwap数据 每天盘后从实盘服务器下载 导入数据库
    表结构 和实盘输出的vwap文件对应
    """

    __tablename__ = 'vwap_indicators'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    order_id = Column(BIGINT, nullable=False, index=True)
    parent_order_id = Column(VARCHAR(64), nullable=False, index=True)
    trading_date = Column(DATE, nullable=False)
    trade_time = Column(TIME, nullable=False)
    internal_date = Column(DATE, nullable=False)
    calendar_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    symbol = Column(VARCHAR(128), nullable=False)
    direction = Column(INTEGER, nullable=False)
    bp1 = Column(DOUBLE, nullable=False)
    sp1 = Column(DOUBLE, nullable=False)
    bv1 = Column(INTEGER, nullable=False)
    sv1 = Column(INTEGER, nullable=False)
    first_amt = Column(DOUBLE, nullable=False)
    first_vol = Column(BIGINT, nullable=False)
    amt = Column(DOUBLE, nullable=False)
    vol = Column(BIGINT, nullable=False)
    vtraded = Column(INTEGER, nullable=False)
    vtarget = Column(INTEGER, nullable=False)
    indicator = Column(FLOAT, nullable=False)
    outstanding_qty = Column(BIGINT, nullable=False)
    filename = Column(VARCHAR(256), nullable=True)
    vstrategy_id = Column(BIGINT, nullable=False)
    user_id = Column(INTEGER, nullable=False)
    account = Column(VARCHAR(32), nullable=False)
    status = Column(VARCHAR(16), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    vwap_signal = Column(INTEGER, nullable=False, default=0)

    @staticmethod
    def import_from_csv(filename):
        f = open(filename)
        file_base_name = os.path.basename(filename)
        filename_parse = parse_filename(file_base_name)
        sc = session()
        exists = sc.query(VwapIndicator.id).filter(VwapIndicator.filename == file_base_name).limit(1).first()
        if exists:
            sc.close()
            return True
        vwaporder = sc.query(VwapOrder).filter(
            VwapOrder.parent_order_id == filename_parse['parent_order_id'],
            VwapOrder.trading_date == filename_parse['trading_date'],
            VwapOrder.day_night == filename_parse['day_night'],
            VwapOrder.status == filename_parse['status'],
        ).first()
        if not vwaporder:
            vwaporder = VwapOrder(
                parent_order_id=filename_parse['parent_order_id'],
                trading_date=filename_parse['trading_date'],
                day_night=filename_parse['day_night'],
                algorithm=filename_parse['algorithm'],
                status=filename_parse['status'],
            )
            sc.add(vwaporder)
            sc.commit()
        if filename_parse['status'] == 'real':
            vstrategy_detail = sc.query(
                VStrategies.symbols_accounts_detail.label('symbols_accounts_detail'),
                StrategyPortfolio.r_create_user_id.label('user_id')
            ).join(
                StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
            ).filter(VStrategies.id == filename_parse['vstrategy_id']).first()
            user_id = vstrategy_detail.user_id
            symbols_accounts = VStrategies.normalization_symbols_accounts(vstrategy_detail.symbols_accounts_detail)
            kdb = KdbQuery()
            product2exchange = {}
            product2exchange.update(get_stock_detail())
            product2exchange.update(consts.LONGPRODUCT2EXCHANGE)
            product2exchange.update(consts.SHORTPRODUCTS2EXCHANGE)
            product2exchange.update(kdb.get_symbol_exchange())
            exchange2accounts = {symbol_account['exchange']: symbol_account['account'] for symbol_account in
                                 symbols_accounts}
            if ('SSE' not in exchange2accounts) and ('SZSE' in exchange2accounts):
                exchange2accounts['SSE'] = exchange2accounts['SZSE']
            if ('SZSE' not in exchange2accounts) and ('SSE' in exchange2accounts):
                exchange2accounts['SZSE'] = exchange2accounts['SSE']
            account = exchange2accounts[product2exchange[filename_parse['product']]]
        elif filename_parse['status'] == 'sim':
            strategy = sc.query(
                Strategy.r_create_user_id
            ).filter(Strategy.id == filename_parse['vstrategy_id']).first()
            if not strategy:
                sc.close()
                raise ValueError('can not find strategy: strategy_id=%s' % filename_parse['vstrategy_id'])
            user_id = strategy[0]
            account = ''
        reader = csv.DictReader(f)
        trading_date = parse(filename_parse['trading_date'])
        internal_date = parse(filename_parse['internal_date'])
        calendar_date = parse(filename_parse['calendar_date'])
        for row in reader:
            # ParentID, Time, BP1, SP1, BV1, SV1, FirstAmt, FirstVolume, Amt, Volume, Vtarget, Vtraded, Ind, OutstandingQty, CalendarDate
            trade_time_str = row['Time'].zfill(9)
            trade_time_str = '%s:%s:%s.%s' % (
                trade_time_str[:2], trade_time_str[2:4], trade_time_str[4:6], trade_time_str[6:9])
            trade_time = parse(trade_time_str).time()
            indicator = float(row['Ind'])
            if indicator == float('-inf'):
                indicator = 0
            if math.isnan(indicator):
                indicator = 0
            ind = VwapIndicator(
                order_id=vwaporder.id,
                parent_order_id=filename_parse['parent_order_id'],
                trading_date=trading_date,
                trade_time=trade_time,
                internal_date=internal_date,
                calendar_date=calendar_date,
                day_night=filename_parse['day_night'],
                symbol=filename_parse['symbol'],
                direction=filename_parse['direction'],
                bp1=float(row['BP1']),
                sp1=float(row['SP1']),
                bv1=int(row['BV1']),
                sv1=int(row['SV1']),
                first_amt=float(row['FirstAmt']),
                first_vol=int(row['FirstVolume']),
                amt=float(row['Amt']),
                vol=int(row['Volume']),
                vtraded=int(row['Vtraded']),
                vtarget=int(row['Vtarget']),
                indicator=indicator,
                outstanding_qty=int(row['OutstandingQty']),
                filename=file_base_name,
                vstrategy_id=filename_parse['vstrategy_id'],
                account=account,
                user_id=user_id,
                status=filename_parse['status'],
                vwap_signal=int(row.get('Signal', 0) or 0),
            )
            sc.add(ind)
        sc.commit()
        sc.close()
        return True

    def detail(self):
        return {
            'OrderID': self.order_id,
            'ParentID': self.parent_order_id,
            'trading_date': self.trading_date.strftime('%Y%m%d'),
            'day_night': self.day_night,
            'Time': int(self.trade_time.strftime('%H%M%S000')),
            'BP1': float(self.bp1),
            'SP1': float(self.sp1),
            'BV1': self.bv1,
            'SV1': self.sv1,
            'FirstAmt': float(self.first_amt),
            'FirstVolume': self.first_vol,
            'Amt': float(self.amt),
            'Volume': self.vol,
            'Vtraded': self.vtraded,
            'Vtarget': self.vtarget,
            'Indicator': self.indicator,
            'OutstandingQty': self.outstanding_qty,
            'Signal': self.vwap_signal,
        }


class VwapResult(ModelBase):
    """
    实盘vwap绩效
    """
    __tablename__ = 'vwap_results'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    order_id = Column(BIGINT, nullable=False)
    parent_order_id = Column(VARCHAR(64), nullable=False)
    vstrategy_id = Column(BIGINT, nullable=False)
    account = Column(VARCHAR(32), nullable=False)
    trading_date = Column(DATE, nullable=False)
    trade_time = Column(TIME, nullable=True)
    day_night = Column(INTEGER, nullable=False)
    symbol = Column(VARCHAR(128), nullable=False)
    direction = Column(INTEGER, nullable=False)
    parent_order_size = Column(INTEGER, nullable=False)
    mkt_vol = Column(BIGINT, nullable=False)
    mkt_duration_vol = Column(BIGINT, nullable=False)
    mkt_duration_vwap = Column(DOUBLE, nullable=False)
    mkt_duration_twap = Column(DOUBLE, nullable=False)
    exec_vwap = Column(DOUBLE, nullable=False)
    vwap_slippage = Column(DOUBLE, nullable=False)
    twap_slippage = Column(DOUBLE, nullable=False)
    start_time = Column(INTEGER, nullable=False)
    end_time = Column(INTEGER, nullable=False)
    passive_rate = Column(FLOAT, nullable=False)
    filled_rate = Column(FLOAT, nullable=False)
    user_id = Column(INTEGER, nullable=False)
    status = Column(VARCHAR(16), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    algorithm = Column(VARCHAR(16), nullable=False)

    def brief(self):
        return {
            'id': self.id,
            'res_id': self.id,
            'order_id': self.order_id,
            'trading_date': self.trading_date.strftime('%Y%m%d'),
            'day_night': {0: 'day', 1: 'night'}[int(self.day_night)],
            'symbol': self.symbol,
            'account': self.account,
            'direction': {0: 'buy', 1: 'sell'}[int(self.direction)],
            'vstrategy_id': self.vstrategy_id,
            'algorithm': self.algorithm,
        }

    def detail(self):
        return {
            'OrderId': self.order_id,
            'Account': self.account,
            'Date': self.trading_date.strftime('%Y%m%d'),
            'Direction': self.direction,
            'EndTime': self.end_time,
            'ExecVWAP': float(self.exec_vwap),
            'FilledRate': self.filled_rate,
            'MktDurationTWAP': float(self.mkt_duration_twap),
            'MktDurationVWAP': float(self.mkt_duration_vwap),
            'MktDurationVolume': self.mkt_duration_vol,
            'MktVolume': self.mkt_vol,
            'ParentID': self.parent_order_id,
            'ParentOrderSize': self.parent_order_size,
            'PassiveRate': self.passive_rate,
            'StartTime': self.start_time,
            'StratID': self.vstrategy_id,
            'Symbol': self.symbol,
            'TWAPslippage': float(self.twap_slippage),
            'VWAPslippage': float(self.vwap_slippage),
            'day_night': self.day_night,
            'algorithm': self.algorithm,
        }

    @staticmethod
    def gen_vwap_result(trading_date):
        """

        :param trading_date: string, "%Y%m%d"
        :return:
        """
        file_path = os.path.join(CommonPath.strategy_vwap_performance, trading_date)
        vwap_result_file_names = list()
        vwap_info_file_names = list()
        for _, _, f_names in os.walk(file_path):
            for f_name in f_names:
                if f_name.endswith("performance.csv"):
                    vwap_result_file_names.append(f_name)
                elif f_name.endswith("perfinfo.csv"):
                    vwap_info_file_names.append(f_name)
                else:
                    pass

        product_to_exchange_info = get_product_to_exchange_info()
        try:
            vwap_result_records = list()
            exchange_to_account = dict()
            for name in vwap_result_file_names:
                file = os.path.join(file_path, name)
                df = pd.read_csv(file, dtype={'symbol': str})
                for _, row in df.iterrows():
                    vs_id = row['v_id']
                    symbol = row['symbol']
                    if vs_id not in exchange_to_account.keys():
                        exchange_to_account[vs_id] = VStrategies.get_exchange_to_account_info(vs_id=vs_id)
                    account = exchange_to_account[vs_id][product_to_exchange_info[symbol]]
                    vwap_result_records.append(
                        {
                            'order_id': 0,
                            'parent_order_id': row['parent_order_id'],
                            'vstrategy_id': vs_id,
                            'account': account,
                            'trading_date': row['trading_date'],
                            'day_night': row['day_night'],
                            'symbol': symbol,
                            'direction': row['direction'],
                            'parent_order_size': row['parent_order_size'],
                            'mkt_vol': row['mkt_vol'],
                            'mkt_duration_vol': row['mkt_duration_vol'],
                            'mkt_duration_vwap': row['mkt_duration_vwap'],
                            'mkt_duration_twap': row['mkt_duration_twap'],
                            'exec_vwap': row['exec_vwap'],
                            'vwap_slippage': row['vwap_slippage'],
                            'twap_slippage': row['twap_slippage'],
                            'start_time': row['start_time'],
                            'end_time': row['end_time'],
                            'passive_rate': row['passive_rate'],
                            'filled_rate': row['filled_rate'],
                            'user_id': 16,
                            'status': 'real',
                            'algorithm': 'vwap'
                        }
                    )

            if vwap_result_records:
                with session_context() as sc:
                    vs_ids = list(set([r['vstrategy_id'] for r in vwap_result_records]))
                    sc.query(VwapResult).filter(
                        VwapResult.vstrategy_id.in_(vs_ids),
                        VwapResult.trading_date == trading_date,
                    ).delete(synchronize_session=False)

                # use sqlalchemy core
                engine.execute(
                    VwapResult.__table__.insert(),
                    vwap_result_records
                )

            vwap_info_records = list()
            for name in vwap_info_file_names:
                file = os.path.join(file_path, name)
                df = pd.read_csv(file, dtype={'symbol': str})
                for _, row in df.iterrows():
                    vwap_info_records.append(
                        {
                            'vs_id': row['strat_id'],
                            'trading_date': row['trading_date'],
                            'symbol': row['symbol'],
                            'direction': row['direction'],
                            'size': row['size'],
                            'turnover': row['turnover']
                        }
                    )

            if vwap_info_records:
                with session_context() as sc:
                    vs_ids = list(set([r['vs_id'] for r in vwap_info_records]))
                    sc.query(VwapInfo).filter(
                        VwapInfo.vs_id.in_(vs_ids),
                        VwapInfo.trading_date == trading_date,
                    ).delete(synchronize_session=False)

                engine.execute(
                    VwapInfo.__table__.insert(),
                    vwap_info_records
                )
        except Exception as e:
            print(str(e))
            sentry.captureException()
            return False

        return True

    @staticmethod
    def download_vwap_result(trading_date):
        """
        download vstrategy vwap result file from trading server
        :param trading_date: string, "%Y%m%d"
        :return: boolean
        """
        trading_calendar = TradeCalendar.init_from_kdb(**config.kdb_config)
        if not trading_calendar.is_trading_date(date=trading_date):
            return False

        with session_context() as sc:
            # vs_ids = [
            #     v_id[0] for v_id in sc.query(
            #         distinct(ParentOrder.vstrategy_id)
            #     ).filter(ParentOrder.trading_date == trading_date)
            # ]
            #
            # if not vs_ids:
            #     return False
            #
            # vs_ids_str = ','.join(map(str, vs_ids))
            #
            # merge_vs_sql = """select DISTINCT merge_vstrategy_id from pre_strategy_confs
            # where vstrategy_id in ({vs_ids_str})""".format(vs_ids_str=vs_ids_str)
            #
            # merge_vs_ids = [r[0] for r in sc.execute(merge_vs_sql) if r[0] and r[0] > 0]
            #
            # vs_ids.extend(merge_vs_ids)
            #
            # vs_ids_str = ','.join(map(str, vs_ids))
            #
            # vs_detail = sc.query(
            #     VStrategies.id.label('id'),
            #     Strategy.id_no.label('id_no'),
            # ).filter(
            #     VStrategies.strategy_id == Strategy.id,
            #     VStrategies.id.in_(vs_ids)
            # )

            merge_vs_records = sc.query(
                VStrategies.id.label('vs_id'),
                Strategy.id_no.label('id_no')
            ).filter(
                VStrategies.strategy_id == Strategy.id,
                VStrategies.status == VStrategiesConstant.Status.Live.value,
                Strategy.strategy_type == StrategyConstant.StrategyType.MergeTrade.value
            ).all()

            merge_vs_ids = [r.vs_id for r in merge_vs_records]
            merge_vs_ids_str = ','.join(map(str, merge_vs_ids))

            deploy_vs_sql = """
                select vstrategy_id, `host` from deploy_confs
                where vstrategy_id in ({merge_vs_ids_str}) and day_night=0 and valid=1
                """.format(merge_vs_ids_str=merge_vs_ids_str)

            vs_server_ip = {r[0]: r[1] for r in sc.execute(deploy_vs_sql)}

            for vs in merge_vs_records:
                try:
                    vs_id = vs.vs_id
                    s_id_no = vs.id_no
                    server_ip = vs_server_ip.get(vs_id, '192.168.10.114')

                    if server_ip.split('.')[2] == '30':
                        idc_server_ip = '192.168.30.100'
                    elif server_ip.split('.')[2] == '40':
                        idc_server_ip = '192.168.40.100'
                    else:
                        idc_server_ip = '192.168.10.100'

                    vwap_result_file_name = "~/output/{s_id_no}_{vs_id}/{trading_date}_{vs_id}_performance.csv".format(
                        s_id_no=s_id_no, vs_id=vs_id, trading_date=trading_date
                    )
                    scp_dst_path = os.path.join(CommonPath.strategy_vwap_performance, trading_date)

                    cmd1 = "mkdir -p {scp_dst_path}".format(scp_dst_path=scp_dst_path)
                    os.system(cmd1)

                    cmd2 = """salt-ssh -i {server_ip} cmd.run "test -e {vwap_result_file_name} && 
                    scp {vwap_result_file_name} rss@{idc_server_ip}:{scp_dst_path}"
                    """.format(server_ip=server_ip, idc_server_ip=idc_server_ip, scp_dst_path=scp_dst_path,
                               vwap_result_file_name=vwap_result_file_name)
                    os.system(cmd2)

                    vwap_info_file_name = "~/output/{s_id_no}_{vs_id}/{trading_date}_{vs_id}_perfinfo.csv".format(
                        s_id_no=s_id_no, vs_id=vs_id, trading_date=trading_date
                    )

                    cmd3 = """salt-ssh -i {server_ip} cmd.run "test -e {vwap_info_file_name} && 
                    scp {vwap_info_file_name} rss@{idc_server_ip}:{scp_dst_path}"
                    """.format(server_ip=server_ip, idc_server_ip=idc_server_ip, scp_dst_path=scp_dst_path,
                               vwap_info_file_name=vwap_info_file_name)
                    os.system(cmd3)

                except Exception as e:
                    sentry.captureException()
                    return False

        return True


class StrategySlippage(ModelBase):
    """
    使用vwap_results中的数据，计算vwap算法的绩效 auto_generate_daily_slippage
    股票交易--> 实盘绩效 --> VWAP (实盘/盘后)
    """
    __tablename__ = 'vwap_strategy_slippage'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(BIGINT, nullable=True)
    vstrategy_id = Column(BIGINT, nullable=True)
    trading_date = Column(DATE, nullable=False)
    slippage_avg = Column(DOUBLE, nullable=False)
    slippage_std = Column(DOUBLE, nullable=False)
    cash_value = Column(DOUBLE, nullable=True, default=0)

    @staticmethod
    def generate_daily_slippage(date):
        """

        :param date: '%Y%m%d'
        :return:
        """
        from service.statistic.models import VsTradingVolumeRatio

        sc = session()

        vwap_vs_ids = sc.query(distinct(VwapResult.vstrategy_id)).filter(VwapResult.status == 'real',
                                                                         VwapResult.trading_date == date)
        vwap_vs_ids = [r[0] for r in vwap_vs_ids]
        if not vwap_vs_ids:
            sc.close()
            return False

        vs_details = sc.query(VStrategies.id.label('vs_id'), VStrategies.strategy_id.label('s_id')).filter(
            VStrategies.id.in_(vwap_vs_ids))

        s_id2vs_ids = {}
        for r in vs_details:
            s_id2vs_ids[r.s_id] = s_id2vs_ids.get(r.s_id, []) + [r.vs_id]

        for s_id, vs_ids in s_id2vs_ids.items():
            for vs_id in vs_ids:
                try:
                    slippage = StrategySlippage.calc_strategy_daily_slippage([vs_id], date)
                    if math.isnan(slippage['avg']) or math.isnan(slippage['std']) or math.isnan(
                            slippage['total_value']):
                        continue

                    slippage_obj = sc.query(StrategySlippage).filter(
                        StrategySlippage.vstrategy_id == vs_id,
                        StrategySlippage.trading_date == date,
                    ).first()
                    if slippage_obj:
                        slippage_obj.slippage_avg = slippage['avg']
                        slippage_obj.slippage_std = slippage['std']
                        slippage_obj.cash_value = slippage['total_value']
                    else:
                        slippage_obj = StrategySlippage(
                            vstrategy_id=vs_id,
                            trading_date=date,
                            slippage_avg=slippage['avg'],
                            slippage_std=slippage['std'],
                            cash_value=slippage['total_value'],
                        )
                        sc.add(slippage_obj)
                    sc.commit()
                except Exception as e:
                    sentry.captureException()
                    continue

                try:
                    VsTradingVolumeRatio.genarate_mkt_volume_ratio(vs_id, date)
                except Exception as e:
                    sentry.captureException()

            try:
                slippage = StrategySlippage.calc_strategy_daily_slippage(vs_ids, date)
                if math.isnan(slippage['avg']) or math.isnan(slippage['std']) or math.isnan(slippage['total_value']):
                    continue
                slippage_obj = sc.query(StrategySlippage).filter(
                    StrategySlippage.strategy_id == s_id,
                    StrategySlippage.trading_date == date,
                ).first()
                if slippage_obj:
                    slippage_obj.slippage_avg = slippage['avg']
                    slippage_obj.slippage_std = slippage['std']
                    slippage_obj.cash_value = slippage['total_value']
                else:
                    slippage_obj = StrategySlippage(
                        strategy_id=s_id,
                        trading_date=date,
                        slippage_avg=slippage['avg'],
                        slippage_std=slippage['std'],
                        cash_value=slippage['total_value'],
                    )
                    sc.add(slippage_obj)
                sc.commit()
            except Exception as e:
                sentry.captureException()
                continue

        sc.close()
        return True

    @staticmethod
    def calc_strategy_daily_slippage(vs_ids, date):
        """
        计算每日基础数据
        :param vs_ids: list
        :param date: '%Y%m%d'
        :return:
        """
        if not isinstance(vs_ids, list):
            raise ValueError('vs_ids type is not list')

        vwap_results = StrategySlippage.get_vwap_results(vs_ids, date)
        vwap_results_df = pd.DataFrame(vwap_results['values'], columns=vwap_results['columns'])
        if vwap_results_df.empty:
            raise ValueError('%s, %s vwap_results is empty' % (vs_ids, date))

        vwap_info = StrategySlippage.get_vwap_info(vs_ids, date)
        vwap_info_df = pd.DataFrame(vwap_info['values'], columns=vwap_info['columns'])
        return calc_strategy_daily_slippage(vwap_results_df=vwap_results_df, vwap_info_df=vwap_info_df)

    @staticmethod
    def get_vwap_results(vs_ids, date):
        sc = session()
        vwap_results = sc.query(VwapResult).filter(
            VwapResult.status == 'real',
            VwapResult.trading_date == date,
            VwapResult.vstrategy_id.in_(vs_ids)
        )
        columns = ['vs_id', 'trading_date', 'parent_order_size', 'vwap_slippage', 'exec_vwap', 'filled_rate',
                   'symbol', 'direction']
        values = [[r.vstrategy_id, r.trading_date.strftime('%Y%m%d'), r.parent_order_size,
                   float(r.vwap_slippage), float(r.exec_vwap), float(r.filled_rate),
                   r.symbol, r.direction] for r in vwap_results]
        sc.close()
        return {
            'columns': columns,
            'values': values,
        }

    @staticmethod
    def get_vwap_info(vs_ids, date):
        sc = session()
        vwap_infos = sc.query(VwapInfo).filter(
            VwapInfo.vs_id.in_(vs_ids),
            VwapInfo.trading_date == date,
        )
        columns = ['vs_id', 'trading_date', 'symbol', 'direction', 'size', 'turnover']
        values = [
            [
                r.vs_id, r.trading_date.strftime('%Y%m%d'), r.symbol, r.direction, r.size, r.turnover
            ] for r in vwap_infos]
        sc.close()
        return {
            'columns': columns,
            'values': values,
        }

    @staticmethod
    def get_strategy_daily_slippage(ids, id_type):
        """

        :param ids: id depend by id type
        :param id_type: 's': strategy, 'vs': vstrategy
        :return:
        """
        sc = session()
        if id_type == 'vs':
            slippages = sc.query(StrategySlippage).filter(StrategySlippage.vstrategy_id.in_(ids)).all()
        elif id_type == 's':
            slippages = sc.query(StrategySlippage).filter(
                StrategySlippage.strategy_id.in_(ids),
                StrategySlippage.vstrategy_id.is_(None),
            ).all()
        else:
            slippages = list()

        columns = ['strategy_id', 'vstrategy_id', 'trading_date', 'slippage_avg', 'slippage_std', 'cash_value']
        values = [
            [r.strategy_id, r.vstrategy_id, r.trading_date.strftime('%Y-%m-%d'), float(r.slippage_avg),
             float(r.slippage_std), float(r.cash_value)]
            for r in slippages
        ]
        sc.close()
        return {
            'columns': columns,
            'values': values,
        }

    @staticmethod
    def calc_strategy_slippage(ids, id_type):
        daily_slippages = StrategySlippage.get_strategy_daily_slippage(ids, id_type)
        daily_slippages_df = pd.DataFrame(daily_slippages['values'], columns=daily_slippages['columns'])
        slippage_avg = np.average(daily_slippages_df.slippage_avg, weights=daily_slippages_df.cash_value)
        return {
            'avg': slippage_avg,
            'std': np.sqrt(np.average((daily_slippages_df.slippage_avg - slippage_avg) ** 2,
                                      weights=daily_slippages_df.cash_value)),
        }

    @staticmethod
    def get_strategy_slippage(ids, id_type, cache=True):
        cache_key = 'vwap_strategy_slippage_%s' % ('_'.join([str(_i) for _i in sorted(set(ids))]))
        if cache:
            cache_data = get_cache(cache_key)
            if cache_data:
                return cache_data

        try:
            slippage = StrategySlippage.calc_strategy_slippage(ids, id_type)
        except Exception as e:
            return {
                'avg': None,
                'std': None,
            }

        if not (math.isnan(slippage['avg']) or math.isnan(slippage['std'])):
            set_cache(cache_key, slippage, 7200)

        if math.isnan(slippage['avg']):
            slippage['avg'] = None
        if math.isnan(slippage['std']):
            slippage['std'] = None

        return slippage


class VsVwapResult(ModelBase):
    """
    盘后分析的vwap绩效
    """
    __tablename__ = 'vs_vwap_results'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vstrategy_id = Column(BIGINT, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)
    trade_time = Column(TIME, nullable=True)
    day_night = Column(INTEGER, nullable=False)
    symbol = Column(VARCHAR(128), nullable=False)
    Direction = Column(INTEGER, nullable=False)
    ParentOrderSize = Column(INTEGER, nullable=False)
    mkt_vol = Column(BIGINT, nullable=False)
    MktDurationVolume = Column(BIGINT, nullable=False)
    MktDurationVWAP = Column(DOUBLE, nullable=False)
    MktDurationTWAP = Column(DOUBLE, nullable=False)
    ExecVWAP = Column(DOUBLE, nullable=False)
    VWAPslippage = Column(DOUBLE, nullable=False)
    TWAPslippage = Column(DOUBLE, nullable=False)
    StartTime = Column(INTEGER, nullable=False)
    EndTime = Column(INTEGER, nullable=False)
    PassiveRate = Column(FLOAT, nullable=False)
    FilledRate = Column(FLOAT, nullable=False)
    PassiveFilledRate = Column(DOUBLE, nullable=False)
    SignalNumIndBuy = Column(DOUBLE, nullable=False)
    SignalNumIndSell = Column(DOUBLE, nullable=False)
    SignalFilledRate = Column(DOUBLE, nullable=False)
    SignalCancelRate = Column(DOUBLE, nullable=False)
    LastAggRate = Column(DOUBLE, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())

    @staticmethod
    def gen_vwap_result(vs_id, trading_date):
        """

        :param vs_id: vstrategy id, int
        :param trading_date: string, %Y%m%d
        :return:
        """
        try:
            records = list()
            perf_records = list()
            with session_context() as sc:
                s = sc.query(Strategy).join(
                    VStrategies, VStrategies.strategy_id == Strategy.id
                ).filter(
                    VStrategies.id == vs_id
                ).first()
                if s:
                    file_name = os.path.join(
                        CommonPath.jupyter_user_work_space,
                        "{uid}_{username}/strategy/output/vstrategy/{vs_id}/SmartExecution/"
                        "{trading_date}/{trading_date}_{s_id}_performance.csv".format(
                            uid=s.r_create_user_id, username=s.username, vs_id=vs_id,
                            trading_date=trading_date, s_id=s.id
                        )
                    )
                    if os.path.exists(file_name):
                        df = pd.read_csv(file_name, dtype={'symbol': str})
                        for _, row in df.iterrows():
                            records.append(
                                {
                                    'vstrategy_id': vs_id,
                                    'trading_date': row['trading_date'],
                                    'day_night': row['day_night'],
                                    'symbol': row['symbol'],
                                    'Direction': row['direction'],
                                    'ParentOrderSize': row['parent_order_size'],
                                    'mkt_vol': row['mkt_vol'],
                                    'MktDurationVolume': row['mkt_duration_vol'],
                                    'MktDurationVWAP': row['mkt_duration_vwap'],
                                    'MktDurationTWAP': row['mkt_duration_twap'],
                                    'ExecVWAP': row['exec_vwap'],
                                    'VWAPslippage': row['vwap_slippage'],
                                    'TWAPslippage': row['twap_slippage'],
                                    'StartTime': row['start_time'],
                                    'EndTime': row['end_time'],
                                    'PassiveRate': row['passive_rate'],
                                    'FilledRate': row['filled_rate'],
                                    'PassiveFilledRate': row['passive_filled_rate'],
                                    'SignalNumIndBuy': row['signal_buy_num'],
                                    'SignalNumIndSell': row['signal_sell_num'],
                                    'SignalFilledRate': row['signal_filled_rate'],
                                    'SignalCancelRate': row['signal_cancel_rate'],
                                    'LastAggRate': row['last_agg_rate'],
                                }
                            )
                        if records:
                            sc.query(VsVwapResult).filter(
                                VsVwapResult.vstrategy_id == vs_id,
                                VsVwapResult.trading_date == trading_date,
                            ).delete()

                    perf_file_name = os.path.join(
                        CommonPath.jupyter_user_work_space,
                        "{uid}_{username}/strategy/output/vstrategy/{vs_id}/SmartExecution/"
                        "{trading_date}/{trading_date}_{s_id}_perfinfo.csv".format(
                            uid=s.r_create_user_id, username=s.username, vs_id=vs_id,
                            trading_date=trading_date, s_id=s.id
                        )
                    )
                    if os.path.exists(perf_file_name):
                        df = pd.read_csv(perf_file_name, dtype={'symbol': str})
                        for _, row in df.iterrows():
                            perf_records.append(
                                {
                                    'vs_id': vs_id,
                                    'trading_date': row['trading_date'],
                                    'symbol': row['symbol'],
                                    'direction': row['direction'],
                                    'size': row['size'],
                                    'turnover': row['turnover']
                                }
                            )
                        if perf_records:
                            sc.query(VsVwapInfo).filter(
                                VsVwapInfo.vs_id == vs_id,
                                VsVwapInfo.trading_date == trading_date,
                            ).delete()

            if records:
                # use sqlalchemy core
                engine.execute(
                    VsVwapResult.__table__.insert(),
                    records
                )

            if perf_records:
                engine.execute(
                    VsVwapInfo.__table__.insert(),
                    perf_records
                )

            if records:
                VsBackTestSlippage.gen_vwap_slippage(vs_id, trading_date)
        except Exception as e:
            sentry.captureException()
            return False

        return True


class StrategyVwapResult(ModelBase):
    """
    回测的vwap绩效
    """
    __tablename__ = 'strategy_vwap_results'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(BIGINT, nullable=False, index=True)
    config_id = Column(INTEGER, nullable=False, default=0)
    trading_date = Column(DATE, nullable=False, index=True)
    trade_time = Column(TIME, nullable=True)
    day_night = Column(INTEGER, nullable=False)
    symbol = Column(VARCHAR(128), nullable=False)
    Direction = Column(INTEGER, nullable=False)
    ParentOrderSize = Column(INTEGER, nullable=False)
    mkt_vol = Column(BIGINT, nullable=False)
    MktDurationVolume = Column(BIGINT, nullable=False)
    MktDurationVWAP = Column(DOUBLE, nullable=False)
    MktDurationTWAP = Column(DOUBLE, nullable=False)
    ExecVWAP = Column(DOUBLE, nullable=False)
    VWAPslippage = Column(DOUBLE, nullable=False)
    TWAPslippage = Column(DOUBLE, nullable=False)
    StartTime = Column(INTEGER, nullable=False)
    EndTime = Column(INTEGER, nullable=False)
    PassiveRate = Column(FLOAT, nullable=False)
    FilledRate = Column(FLOAT, nullable=False)
    PassiveFilledRate = Column(DOUBLE, nullable=False)
    SignalNumIndBuy = Column(DOUBLE, nullable=False)
    SignalNumIndSell = Column(DOUBLE, nullable=False)
    SignalFilledRate = Column(DOUBLE, nullable=False)
    SignalCancelRate = Column(DOUBLE, nullable=False)
    LastAggRate = Column(DOUBLE, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())

    @staticmethod
    def gen_vwap_result(s_id, trading_date):
        """

        :param s_id: strategy id, int
        :param trading_date: string, %Y%m%d
        :return:
        """
        try:
            records = list()
            perf_records = list()
            with session_context() as sc:
                s = sc.query(Strategy).filter(
                    Strategy.id == s_id
                ).first()
                if s:
                    file_name = os.path.join(
                        CommonPath.jupyter_user_work_space,
                        "{uid}_{username}/strategy/output/{id_no}/{st_uuid}/SmartExecution/"
                        "{trading_date}/{trading_date}_{s_id}_performance.csv".format(
                            uid=s.r_create_user_id, username=s.username, id_no=s.id_no, st_uuid=s.st_uuid,
                            trading_date=trading_date, s_id=s.id
                        )
                    )
                    if os.path.exists(file_name):
                        df = pd.read_csv(file_name, dtype={'symbol': str})
                        for _, row in df.iterrows():
                            records.append(
                                {
                                    'strategy_id': row['v_id'],
                                    'trading_date': row['trading_date'],
                                    'day_night': row['day_night'],
                                    'symbol': row['symbol'],
                                    'Direction': row['direction'],
                                    'ParentOrderSize': row['parent_order_size'],
                                    'mkt_vol': row['mkt_vol'],
                                    'MktDurationVolume': row['mkt_duration_vol'],
                                    'MktDurationVWAP': row['mkt_duration_vwap'],
                                    'MktDurationTWAP': row['mkt_duration_twap'],
                                    'ExecVWAP': row['exec_vwap'],
                                    'VWAPslippage': row['vwap_slippage'],
                                    'TWAPslippage': row['twap_slippage'],
                                    'StartTime': row['start_time'],
                                    'EndTime': row['end_time'],
                                    'PassiveRate': row['passive_rate'],
                                    'FilledRate': row['filled_rate'],
                                    'PassiveFilledRate': row['passive_filled_rate'],
                                    'SignalNumIndBuy': row['signal_buy_num'],
                                    'SignalNumIndSell': row['signal_sell_num'],
                                    'SignalFilledRate': row['signal_filled_rate'],
                                    'SignalCancelRate': row['signal_cancel_rate'],
                                    'LastAggRate': row['last_agg_rate'],
                                }
                            )
                        if records:
                            sc.query(StrategyVwapResult).filter(
                                StrategyVwapResult.strategy_id == s_id,
                                StrategyVwapResult.trading_date == trading_date,
                            ).delete()

                    perf_file_name = os.path.join(
                        CommonPath.jupyter_user_work_space,
                        "{uid}_{username}/strategy/output/{id_no}/{st_uuid}/SmartExecution/"
                        "{trading_date}/{trading_date}_{s_id}_perfinfo.csv".format(
                            uid=s.r_create_user_id, username=s.username, id_no=s.id_no, st_uuid=s.st_uuid,
                            trading_date=trading_date, s_id=s.id
                        )
                    )
                    if os.path.exists(perf_file_name):
                        df = pd.read_csv(perf_file_name, dtype={'symbol': str})
                        for _, row in df.iterrows():
                            perf_records.append(
                                {
                                    's_id': row['strat_id'],
                                    'trading_date': row['trading_date'],
                                    'symbol': row['symbol'],
                                    'direction': row['direction'],
                                    'size': row['size'],
                                    'turnover': row['turnover']
                                }
                            )
                        if perf_records:
                            sc.query(StrategyVwapInfo).filter(
                                StrategyVwapInfo.s_id == s_id,
                                StrategyVwapInfo.trading_date == trading_date,
                            ).delete()

            if records:
                # use sqlalchemy core
                engine.execute(
                    StrategyVwapResult.__table__.insert(),
                    records
                )

            if perf_records:
                engine.execute(
                    StrategyVwapInfo.__table__.insert(),
                    perf_records
                )

            if records:
                StrategyBackTestSlippage.gen_vwap_slippage(s_id, trading_date)
        except Exception as e:
            sentry.captureException()
            return False

        return True


class StrategyBackTestSlippage(ModelBase):
    """
    回测的vwap绩效
    """
    __tablename__ = 'vwap_strategy_back_test_slippage'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(BIGINT, nullable=False, index=True)
    config_id = Column(INTEGER, nullable=False, default=0)
    trading_date = Column(DATE, nullable=False, index=True)
    slippage_avg = Column(DOUBLE, nullable=False)
    slippage_std = Column(DOUBLE, nullable=False)
    cash_value = Column(DOUBLE, nullable=True, default=0)

    @staticmethod
    def gen_vwap_slippage(s_id, trading_date):
        sc = session()
        try:
            slippage = StrategyBackTestSlippage.calc_strategy_daily_slippage(s_id, trading_date)
            if math.isnan(slippage['avg']) or math.isnan(slippage['std']) or math.isnan(slippage['total_value']):
                raise ValueError('slippage is nan %s %s' % (s_id, trading_date))
            slippage_obj = sc.query(StrategyBackTestSlippage).filter(
                StrategyBackTestSlippage.strategy_id == s_id,
                StrategyBackTestSlippage.trading_date == trading_date,
            ).first()
            if slippage_obj:
                slippage_obj.slippage_avg = slippage['avg']
                slippage_obj.slippage_std = slippage['std']
                slippage_obj.cash_value = slippage['total_value']
            else:
                slippage_obj = StrategyBackTestSlippage(
                    strategy_id=s_id,
                    trading_date=trading_date,
                    slippage_avg=slippage['avg'],
                    slippage_std=slippage['std'],
                    cash_value=slippage['total_value'],
                )
                sc.add(slippage_obj)
            sc.commit()
        except Exception as e:
            sentry.captureException()

        sc.close()
        del_cache('vwap_strategy_back_test_slippage_%s' % s_id)
        return True

    @staticmethod
    def calc_strategy_daily_slippage(s_id, date):
        vwap_results = StrategyBackTestSlippage.get_vwap_results(s_id, date)
        vwap_results_df = pd.DataFrame(vwap_results['values'], columns=vwap_results['columns'])
        if vwap_results_df.empty:
            raise ValueError('%s, %s vwap_results is empty' % (s_id, date))

        vwap_info = StrategyBackTestSlippage.get_vwap_info(s_id, date)
        vwap_info_df = pd.DataFrame(vwap_info['values'], columns=vwap_info['columns'])
        return calc_strategy_daily_slippage(vwap_results_df=vwap_results_df, vwap_info_df=vwap_info_df)

    @staticmethod
    def get_vwap_results(s_id, date):
        sc = session()
        vwap_results = sc.query(StrategyVwapResult).filter(
            StrategyVwapResult.strategy_id == s_id,
            StrategyVwapResult.trading_date == date,
        )
        columns = ['s_id', 'trading_date', 'parent_order_size', 'vwap_slippage', 'exec_vwap', 'filled_rate', 'symbol',
                   'direction']
        values = [
            [
                r.strategy_id, r.trading_date.strftime('%Y%m%d'),
                r.ParentOrderSize, float(r.VWAPslippage), float(r.ExecVWAP), float(r.FilledRate), r.symbol, r.Direction
            ] for r in vwap_results]
        sc.close()
        return {
            'columns': columns,
            'values': values,
        }

    @staticmethod
    def get_vwap_info(s_id, date):
        sc = session()
        vwap_infos = sc.query(StrategyVwapInfo).filter(
            StrategyVwapInfo.s_id == s_id,
            StrategyVwapInfo.trading_date == date,
        )
        columns = ['s_id', 'trading_date', 'symbol', 'direction', 'size', 'turnover']
        values = [
            [
                r.s_id, r.trading_date.strftime('%Y%m%d'), r.symbol, r.direction, r.size, r.turnover
            ] for r in vwap_infos]
        sc.close()
        return {
            'columns': columns,
            'values': values,
        }

    @staticmethod
    def get_strategy_daily_slippage(s_id):
        sc = session()
        start_date = sc.query(Strategy.start_date).filter(
            Strategy.id == s_id
        ).first()
        start_date = start_date and start_date[0] or '21000101'
        slippages = sc.query(StrategyBackTestSlippage).filter(
            StrategyBackTestSlippage.strategy_id == s_id,
            StrategyBackTestSlippage.config_id == 0,
            StrategyBackTestSlippage.trading_date >= start_date,
        )
        columns = ['trading_date', 'slippage_avg', 'slippage_std', 'cash_value']
        values = [
            [r.trading_date.strftime('%Y-%m-%d'), float(r.slippage_avg), float(r.slippage_std), float(r.cash_value)]
            for r in slippages
        ]
        sc.close()
        return {
            'columns': columns,
            'values': values,
        }

    @staticmethod
    def get_strategy_slippage(s_id, cache=True):
        cache_key = 'vwap_strategy_back_test_slippage_%s' % s_id
        if cache:
            cache_data = get_cache(cache_key)
            if cache_data:
                return cache_data
        try:
            daily_slippages = StrategyBackTestSlippage.get_strategy_daily_slippage(s_id)
            daily_slippages_df = pd.DataFrame(daily_slippages['values'], columns=daily_slippages['columns'])
            slippage_avg = np.average(daily_slippages_df.slippage_avg, weights=daily_slippages_df.cash_value)
            slippage = {
                'avg': slippage_avg,
                'std': np.sqrt(np.average((daily_slippages_df.slippage_avg - slippage_avg) ** 2,
                                          weights=daily_slippages_df.cash_value)),
            }
        except Exception as e:
            return {
                'avg': None,
                'std': None,
            }
        if not (math.isnan(slippage['avg']) or math.isnan(slippage['std'])):
            set_cache(cache_key, slippage, 7200)
        if math.isnan(slippage['avg']):
            slippage['avg'] = None
        if math.isnan(slippage['std']):
            slippage['std'] = None
        return slippage


class VsBackTestSlippage(ModelBase):
    """
    盘后分析的vwap绩效
    """
    __tablename__ = 'vwap_vs_back_test_slippage'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vs_id = Column(BIGINT, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)
    slippage_avg = Column(DOUBLE, nullable=False)
    slippage_std = Column(DOUBLE, nullable=False)
    cash_value = Column(DOUBLE, nullable=True, default=0)

    @staticmethod
    def gen_vwap_slippage(vs_id, trading_date):
        sc = session()
        try:
            slippage = VsBackTestSlippage.calc_strategy_daily_slippage(vs_id, trading_date)
            if math.isnan(slippage['avg']) or math.isnan(slippage['std']) or math.isnan(slippage['total_value']):
                raise ValueError('slippage is nan %s %s' % (vs_id, trading_date))
            slippage_obj = sc.query(VsBackTestSlippage).filter(
                VsBackTestSlippage.vs_id == vs_id,
                VsBackTestSlippage.trading_date == trading_date,
            ).first()
            if slippage_obj:
                slippage_obj.slippage_avg = slippage['avg']
                slippage_obj.slippage_std = slippage['std']
                slippage_obj.cash_value = slippage['total_value']
            else:
                slippage_obj = VsBackTestSlippage(
                    vs_id=vs_id,
                    trading_date=trading_date,
                    slippage_avg=slippage['avg'],
                    slippage_std=slippage['std'],
                    cash_value=slippage['total_value'],
                )
                sc.add(slippage_obj)
            sc.commit()
        except Exception as e:
            sentry.captureException()

        sc.close()
        del_cache('vwap_vs_back_test_slippage_%s' % vs_id)
        return True

    @staticmethod
    def calc_strategy_daily_slippage(vs_id, date):
        vwap_results = VsBackTestSlippage.get_vwap_results(vs_id, date)
        vwap_results_df = pd.DataFrame(vwap_results['values'], columns=vwap_results['columns'])
        if vwap_results_df.empty:
            raise ValueError('%s, %s vwap_results is empty' % (vs_id, date))

        vwap_info = VsBackTestSlippage.get_vwap_info(vs_id, date)
        vwap_info_df = pd.DataFrame(vwap_info['values'], columns=vwap_info['columns'])
        return calc_strategy_daily_slippage(vwap_results_df=vwap_results_df, vwap_info_df=vwap_info_df)

    @staticmethod
    def get_vwap_results(vs_id, date):
        sc = session()
        vwap_results = sc.query(VsVwapResult).filter(
            VsVwapResult.vstrategy_id == vs_id,
            VsVwapResult.trading_date == date,
        )
        columns = ['vs_id', 'trading_date', 'parent_order_size', 'vwap_slippage', 'exec_vwap', 'filled_rate',
                   'symbol', 'direction']
        values = [
            [
                r.vstrategy_id, r.trading_date.strftime('%Y%m%d'),
                r.ParentOrderSize, float(r.VWAPslippage), float(r.ExecVWAP), float(r.FilledRate), r.symbol, r.Direction
            ] for r in vwap_results]
        sc.close()
        return {
            'columns': columns,
            'values': values,
        }

    @staticmethod
    def get_vwap_info(vs_id, date):
        sc = session()
        vwap_infos = sc.query(VsVwapInfo).filter(
            VsVwapInfo.vs_id == vs_id,
            VsVwapInfo.trading_date == date,
        )
        columns = ['vs_id', 'trading_date', 'symbol', 'direction', 'size', 'turnover']
        values = [
            [
                r.vs_id, r.trading_date.strftime('%Y%m%d'), r.symbol, r.direction, r.size, r.turnover
            ] for r in vwap_infos]
        sc.close()
        return {
            'columns': columns,
            'values': values,
        }

    @staticmethod
    def get_strategy_daily_slippage(vs_ids):
        sc = session()
        slippages = sc.query(VsBackTestSlippage).filter(
            VsBackTestSlippage.vs_id.in_(vs_ids)
        ).all()
        columns = ['trading_date', 'slippage_avg', 'slippage_std', 'cash_value']
        values = [
            [r.trading_date.strftime('%Y-%m-%d'), float(r.slippage_avg), float(r.slippage_std), float(r.cash_value)]
            for r in slippages
        ]
        sc.close()
        return {
            'columns': columns,
            'values': values,
        }

    @staticmethod
    def get_strategy_slippage(vs_ids, cache=True):
        cache_key = 'vwap_vs_back_test_slippage_%s' % ('_'.join([str(_i) for _i in sorted(set(vs_ids))]))
        if cache:
            cache_data = get_cache(cache_key)
            if cache_data:
                return cache_data
        try:
            daily_slippages = VsBackTestSlippage.get_strategy_daily_slippage(vs_ids)
            daily_slippages_df = pd.DataFrame(daily_slippages['values'], columns=daily_slippages['columns'])
            slippage_avg = np.average(daily_slippages_df.slippage_avg, weights=daily_slippages_df.cash_value)
            slippage = {
                'avg': slippage_avg,
                'std': np.sqrt(np.average((daily_slippages_df.slippage_avg - slippage_avg) ** 2,
                                          weights=daily_slippages_df.cash_value)),
            }
        except Exception as e:
            return {
                'avg': None,
                'std': None,
            }

        if not (math.isnan(slippage['avg']) or math.isnan(slippage['std'])):
            set_cache(cache_key, slippage, 7200)

        if math.isnan(slippage['avg']):
            slippage['avg'] = None
        if math.isnan(slippage['std']):
            slippage['std'] = None

        return slippage


class VwapInfo(ModelBase):
    """
    实盘vwap信息
    """
    __tablename__ = "vwap_info"

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vs_id = Column(BIGINT, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)
    symbol = Column(VARCHAR(128), nullable=False)
    direction = Column(INTEGER, nullable=False)
    size = Column(INTEGER, nullable=False)
    turnover = Column(FLOAT, nullable=False)

    @staticmethod
    def migrate():
        migrate(base_model=ModelBase, engine=engine, model=VwapInfo)


class VsVwapInfo(ModelBase):
    """
    盘后分析vwap信息
    """
    __tablename__ = "vs_vwap_info"

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vs_id = Column(BIGINT, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)
    symbol = Column(VARCHAR(128), nullable=False)
    direction = Column(INTEGER, nullable=False)
    size = Column(INTEGER, nullable=False)
    turnover = Column(FLOAT, nullable=False)

    @staticmethod
    def migrate():
        migrate(base_model=ModelBase, engine=engine, model=VsVwapInfo)


class StrategyVwapInfo(ModelBase):
    """
    回测vwap信息
    """
    __tablename__ = "strategy_vwap_info"

    id = Column(BIGINT(unsigned=True), primary_key=True)
    s_id = Column(BIGINT, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)
    symbol = Column(VARCHAR(128), nullable=False)
    direction = Column(INTEGER, nullable=False)
    size = Column(INTEGER, nullable=False)
    turnover = Column(FLOAT, nullable=False)

    @staticmethod
    def migrate():
        migrate(base_model=ModelBase, engine=engine, model=StrategyVwapInfo)


if __name__ == '__main__':
    # print(StrategyVwapResult.gen_vwap_result(s_id=218815, trading_date='20200529'))
    pass

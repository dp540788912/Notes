# -*-coding:utf-8-*-

from service.vwap.handlers import *

urls = [
    (r'/api/v1/platform/vwap/parent_orders$', ParentOrdersHandler),
    (r'/api/v1/platform/vwap/parent_orders2$', ParentOrders2Handler),
    (r'/api/v1/platform/vwap/orders$', Execution_IndicatorHandler),
    (r'/api/v1/platform/vwap/results$', VwapResultHandler),
    (r'/api/v1/platform/vwap/filter$', VwapFilterHandler),
    (r'/api/v1/platform/vwap/detail$', VwapDetailHandler),
    (r'/api/v1/platform/vwap/slippage$', VwapSlippageHandler),

    (r'/api/v1/platform/vwap/strategy/back_test/slippage$', StrategyBackTestSlippageHandler),
    (r'/api/v1/platform/vwap/vs/back_test/slippage$', VsBackTestSlippageHandler),

    (r'/api/v1/platform/vwap/strategy$', VwapStrategyHandler),

    (r'/api/v1/platform/vwap/back_test/result/(?P<id>\d+)$', VwapBackTestResultHandler),
]

# -*-coding:utf-8-*-

# import glob
# import pandas as pd


# def calc_slippage_from_files(directory, date):
#     dir1 = directory + '/*.csv'
#     filename = sorted(glob.glob(dir1))
#     print('vwap file len', len(filename))
#     res_list = []
#
#     for i in range(len(filename)):
#         file_name = filename[i].split('/')[-1]
#         if file_name.split('_')[0] != str(date):
#             continue
#         if 'ind' in file_name:
#             if file_name.split('_')[4] == filename[i - 1].split('/')[-1].split('_')[4] and file_name.split('_')[1] == \
#                     filename[i - 1].split('/')[-1].split('_')[1]:
#                 # Get information from filenames
#                 tmp_str_ls = file_name.split('_')
#                 date = tmp_str_ls[0]
#                 stockID = tmp_str_ls[1]
#                 parent_ord_size = tmp_str_ls[2]
#                 side = tmp_str_ls[3]
#                 if side == 'buy':
#                     int_side = 1
#                 # elif side == 'sell':
#                 else:
#                     int_side = -1
#
#                 # Get information from ADV file
#                 average_daily_volume = 0
#
#                 # Open the reports
#                 df_indi = pd.read_csv(filename[i])
#                 df_exec = pd.read_csv(filename[i - 1])
#                 if df_exec.empty or df_indi.empty:
#                     continue
#
#                 # Get StartTime and EndTime of Vwap order
#                 if (len(df_exec['ExecSize'].nonzero()[0]) == 0) or (
#                         len(df_exec[['ExecSize', 'ExecPrice']].product(axis=1).nonzero()[0]) == 0):
#                     start_time = 0
#                     end_time = 0
#                 else:
#                     start_idx = df_exec['ExecSize'].nonzero()[0][0]
#                     end_idx = df_exec[['ExecSize', 'ExecPrice']].product(axis=1).nonzero()[0][-1]
#                     start_time = df_exec.iloc[start_idx, 0]
#                     end_time = df_exec.iloc[end_idx, 0]
#
#                 # Calculate passive order rate and filled rate
#                 if ("Passive" in df_exec.loc[(df_exec.ExecPrice > 0) &
#                                              (df_exec.ExecSize > 0)]['Order_type'].value_counts().index):
#                     passive_rate = \
#                         df_exec.loc[(df_exec.ExecPrice > 0) & (df_exec.ExecSize > 0)]['Order_type'].value_counts().loc[
#                             'Passive'] / float(df_exec.loc[(df_exec.ExecPrice > 0) & (df_exec.ExecSize > 0)].count()[0])
#                 else:
#                     passive_rate = 0.0
#                 filled_rate = df_exec.loc[df_exec['ExecPrice'] != 0]['ExecSize'].sum() / float(
#                     df_exec['ParentOrderSize'][0])
#
#                 passive_filled_rate = 0
#                 if len(df_exec.loc[(df_exec['ExecPrice'] != 0) & (df_exec['Order_type'] == 'Passive')]) > 0:
#                     passive_filled_rate = \
#                         df_exec.loc[(df_exec['ExecPrice'] != 0) & (df_exec['Order_type'] == 'Passive')][
#                             'ExecSize'].sum() / float(df_exec['ParentOrderSize'][0])
#                 sig_order_num_ind_buy = len(df_indi.loc[df_indi['Signal'] == 1])
#                 sig_order_num_ind_sell = len(df_indi.loc[df_indi['Signal'] == -1])
#                 df_sig_info = df_exec[['ExecSize', 'ExecPrice', 'OrderSentTime']].merge(df_indi[['Time', 'Signal']],
#                                                                                         left_on='OrderSentTime',
#                                                                                         right_on='Time', how='left')
#                 df_same_sig_info = df_sig_info.loc[(df_sig_info['Signal'] == int_side)]
#                 signal_filled_rate = 0
#                 signal_cancel_rate = -9999
#                 if not df_same_sig_info.empty:
#                     signal_filled_rate = df_same_sig_info.loc[(df_same_sig_info['ExecPrice'] != 0)][
#                                              'ExecSize'].sum() / float(df_exec['ParentOrderSize'][0])
#                     signal_cancel_rate = len(
#                         df_same_sig_info.loc[(df_same_sig_info['ExecSize'] == 0)].OrderSentTime.unique().tolist()) \
#                                          / len(df_same_sig_info.OrderSentTime.unique().tolist())
#
#                 last_agg_rate = 0
#                 df_last_filled = df_exec.loc[(df_exec['ExecSize'] != 0) & (df_exec['ExecPrice'] != 0)].tail(1)
#                 if not df_last_filled.empty:
#                     if df_last_filled.iloc[0]['Order_type'] == 'Aggressive':
#                         last_agg_rate = df_last_filled.iloc[0]['ExecSize'] / float(df_exec['ParentOrderSize'][0])
#
#                 # Calculate ExecVWAP
#                 exec_vwap = -9999
#                 if df_exec.loc[df_exec['ExecPrice'] != 0]['ExecSize'].sum() > 0:
#                     # Not df_exec['ExecSize'].sum() because exec price is zero when upper/lower limit. Fixed
#                     exec_vwap = df_exec[['ExecSize', 'ExecPrice']].product(axis=1).sum() / \
#                                 df_exec.loc[df_exec['ExecPrice'] != 0][
#                                     'ExecSize'].sum()
#
#                 mkt_duration_volume = df_indi.iloc[len(df_indi) - 1]['Volume'] - df_indi.iloc[0]['Volume']
#                 if mkt_duration_volume == 0:
#                     continue
#                 mkt_duration_vwap = (df_indi.iloc[len(df_indi) - 1]['Amt'] - df_indi.iloc[0][
#                     'Amt']) / mkt_duration_volume
#
#                 # Calculate MktTWAP
#                 df_twap_tmp = df_indi.set_index('Time')
#                 df_twap_tmp.loc[df_twap_tmp.loc[:, 'BP1'] == 0, 'BP1'] = df_twap_tmp.loc[
#                     df_twap_tmp.loc[:, 'BP1'] == 0, 'SP1']
#                 df_twap_tmp.loc[df_twap_tmp.loc[:, 'SP1'] == 0, 'SP1'] = df_twap_tmp.loc[
#                     df_twap_tmp.loc[:, 'SP1'] == 0, 'BP1']
#                 twap_bpsp_mean = df_twap_tmp[['BP1', 'SP1']].mean(axis=1)
#                 mkt_duration_twap = twap_bpsp_mean[twap_bpsp_mean > 0].mean()
#
#                 # Calculate slippage
#                 if exec_vwap == -9999:
#                     vwap_slippage = 0
#                     twap_slippage = 0
#                 else:
#                     vwap_slippage = (mkt_duration_vwap - exec_vwap) / mkt_duration_vwap * 10000 * int_side
#                     twap_slippage = (mkt_duration_twap - exec_vwap) / mkt_duration_twap * 10000 * int_side
#
#                 # Construct a dictionary
#                 res_dict = {"Date": date, "StockID": stockID, "Direction": 0 if side == 'buy' else 1,
#                             "ParentOrderSize": parent_ord_size,
#                             "ADV": average_daily_volume, "MktDurationVolume": mkt_duration_volume,
#                             "MktDurationVWAP": mkt_duration_vwap, "MktDurationTWAP": mkt_duration_twap,
#                             "ExecVWAP": exec_vwap, "VWAPslippage": vwap_slippage, "TWAPslippage": twap_slippage,
#                             "StartTime": start_time, "EndTime": end_time, "PassiveRate": passive_rate,
#                             "FilledRate": filled_rate, "PassiveFilledRate": passive_filled_rate,
#                             "SignalNumIndBuy": sig_order_num_ind_buy, "SignalNumIndSell": sig_order_num_ind_sell,
#                             "SignalFilledRate": signal_filled_rate, "SignalCancelRate": signal_cancel_rate,
#                             "LastAggRate": last_agg_rate}
#                 res_list.append(res_dict)
#     return res_list

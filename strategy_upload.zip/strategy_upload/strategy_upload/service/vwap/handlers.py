# -*-coding:utf-8-*-

import itertools
import datetime
import pandas as pd
import numpy as np
from dateutil.parser import parse
from operator import itemgetter
from tornado import gen
from sqlalchemy import func
from sqlalchemy import or_

from db import session, session_context
from service.vwap.models import VwapOrder, VwapExecution, VwapIndicator, VwapResult, \
    StrategySlippage, StrategyBackTestSlippage, VsBackTestSlippage, StrategyVwapResult
from service.basehandler import BaseHandler, CurrentUserMixin, JsonPayloadMixin, DownloadMixin
from service.back_test.models import VStrategies, StrategyPortfolio, Strategy
from service.operation_deploy.models import VstrategyUpgrade

import consts


class ParentOrdersHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        size = int(self.get_argument('size', 300))
        max_order_id = int(self.get_argument('max_order_id', 0))
        sc = session()
        order2algorithm = sc.query(
            VwapOrder.id
        ).filter(
            VwapOrder.id > max_order_id,
            VwapOrder.r_create_time >= (datetime.datetime.today() - datetime.timedelta(days=3)).strftime('%Y-%m-%d'),
            VwapOrder.id.notin_(
                sc.query(VwapResult.order_id).filter(
                    VwapResult.r_create_time >= (datetime.datetime.today() - datetime.timedelta(days=5)).strftime(
                        '%Y-%m-%d')
                )
            ),
        ).order_by(
            VwapOrder.id
        ).limit(size)

        order2algorithm = {i[0]: 'vwap' for i in order2algorithm}
        order_ids = list(order2algorithm.keys())
        max_order_id = max(order_ids) if order_ids else 0
        if not order_ids:
            sc.close()
            self.json_response({
                'code': 0,
                'data': []
            })
            return
        exections = sc.query(func.min(VwapExecution.id)).filter(
            VwapExecution.order_id.in_(order_ids)
        ).group_by(VwapExecution.order_id)
        exe_ids = [exe[0] for exe in exections]
        exections = sc.query(VwapExecution).filter(
            VwapExecution.id.in_(exe_ids)
        )
        briefs = [exe.brief() for exe in exections]
        for b in briefs:
            b['algorithm'] = order2algorithm[b['OrderID']]
        keys = ['OrderID', 'ParentID', 'day_night', 'Symbol', 'Direction', 'ParentOrderSize', 'Account', 'algorithm']
        data = []
        for trading_date, orders in itertools.groupby(
                sorted(briefs, key=lambda b: b['trading_date']), key=lambda b: b['trading_date']):
            data.append({
                'max_order_id': max_order_id,
                'date': trading_date,
                'orders': {
                    'keys': keys,
                    'values': [[o[k] for k in keys] for o in orders],
                }
            })
        data = {
            'max_order_id': max_order_id,
            'code': 0,
            'data': data
        }
        sc.close()
        self.json_response(data)
        return


class ParentOrders2Handler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        size = int(self.get_argument('size', 300))
        max_order_id = int(self.get_argument('max_order_id', 0))
        now = datetime.datetime.now().strftime('%Y%m%d')
        start_date = parse(self.get_argument('startdate', now)).strftime('%Y%m%d')
        end_date = parse(self.get_argument('enddate', now)).strftime('%Y%m%d')
        vstrategy_id = self.get_argument('vstrategy_id', '0').zfill(6)
        sc = session()
        order2algorithm = sc.query(
            VwapOrder.id,
            VwapOrder.algorithm
        ).filter(
            VwapOrder.id > max_order_id,
            VwapOrder.trading_date >= start_date,
            VwapOrder.trading_date <= end_date,
        )
        if vstrategy_id != '000000':
            order2algorithm = order2algorithm.filter(VwapOrder.parent_order_id.like('%%%s' % vstrategy_id))
        order2algorithm = order2algorithm.limit(size)
        order2algorithm = {i[0]: i[1] for i in order2algorithm}
        order_ids = list(order2algorithm.keys())
        if not order_ids:
            sc.close()
            self.json_response({
                'code': 0,
                'data': []
            })
            return
        exections = sc.query(func.min(VwapExecution.id)).filter(
            VwapExecution.order_id.in_(order_ids)
        ).group_by(VwapExecution.order_id)
        exe_ids = [exe[0] for exe in exections]
        exections = sc.query(VwapExecution).filter(
            VwapExecution.id.in_(exe_ids)
        )
        briefs = [exe.brief() for exe in exections]
        for b in briefs:
            b['algorithm'] = order2algorithm[b['OrderID']]
        keys = ['OrderID', 'vstrategy_id', 'ParentID', 'day_night', 'Symbol', 'Direction', 'ParentOrderSize', 'Account',
                'algorithm']
        data = []
        for trading_date, orders in itertools.groupby(
                sorted(briefs, key=lambda b: b['trading_date']), key=lambda b: b['trading_date']):
            data.append({
                'date': trading_date,
                'orders': {
                    'keys': keys,
                    'values': [[o[k] for k in keys] for o in orders],
                }
            })
        data = {
            'code': 0,
            'data': data
        }
        sc.close()
        self.json_response(data)
        return


class Execution_IndicatorHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        order_ids = self.get_argument('order_ids')
        order_ids = [int(i) for i in order_ids.split(',')]
        sc = session()
        exections = sc.query(VwapExecution).filter(
            VwapExecution.order_id.in_(order_ids)
        )
        indicators = sc.query(VwapIndicator).filter(
            VwapIndicator.order_id.in_(order_ids)
        )
        exections = [e.detail() for e in exections]
        indicators = [i.detail() for i in indicators]
        orderid2exes = itertools.groupby(sorted(exections, key=itemgetter('OrderID')), key=itemgetter('OrderID'))
        orderid2inds = itertools.groupby(sorted(indicators, key=itemgetter('OrderID')), key=itemgetter('OrderID'))
        orderid2inds = {order_id: list(inds) for order_id, inds in orderid2inds}
        exe_keys = ['Time', 'ParentOrderSize', 'ChildOrderSize', 'ExecSize', 'ExecPrice', 'Order_type', 'Vtraded',
                    'Vtarget', 'Indicator', 'OrderSentTime']
        inds_keys = ['Time', 'BP1', 'SP1', 'BV1', 'SV1', 'FirstAmt', 'FirstVolume', 'Amt', 'Volume', 'Vtraded',
                     'Vtarget', 'Indicator', 'OutstandingQty', 'Signal']
        data = []
        for order_id, exes in orderid2exes:
            exes = list(exes)
            data.append({
                'OrderID': order_id,
                'ParentID': exes[0]['ParentID'],
                'date': exes[0]['trading_date'],
                'day_night': exes[0]['day_night'],
                'execution': {
                    'keys': exe_keys,
                    'values': [[exe[k] for k in exe_keys] for exe in exes]
                },
                'indicator': {
                    'keys': inds_keys,
                    'values': [[ind[k] for k in inds_keys] for ind in orderid2inds.get(order_id, [])]
                }
            })
        data = {
            'code': 0,
            'data': data
        }
        sc.close()
        self.json_response(data)
        return


class VwapResultHandler(JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        payload = self.get_payload()
        try:
            sc = session()
            paras_keys = {
                'order_id': 'OrderId',
                'parent_order_id': 'ParentID',
                'vstrategy_id': 'StratID',
                'account': 'Account',
                'trading_date': 'Date',
                'day_night': 'day_night',
                'symbol': 'Symbol',
                'direction': 'Direction',
                'parent_order_size': 'ParentOrderSize',
                'mkt_vol': 'MktVolume',
                'mkt_duration_vol': 'MktDurationVolume',
                'mkt_duration_vwap': 'MktDurationVWAP',
                'mkt_duration_twap': 'MktDurationTWAP',
                'exec_vwap': 'ExecVWAP',
                'vwap_slippage': 'VWAPslippage',
                'twap_slippage': 'TWAPslippage',
                'start_time': 'StartTime',
                'end_time': 'EndTime',
                'passive_rate': 'PassiveRate',
                'filled_rate': 'FilledRate',
            }
            paras_keys = {k: payload['keys'].index(v) for k, v in paras_keys.items()}
            vs_ids = list(set([v[paras_keys['vstrategy_id']] for v in payload['values']]))
            res = sc.query(StrategyPortfolio.r_create_user_id, VStrategies.id).join(VStrategies).filter(
                StrategyPortfolio.id == VStrategies.portfolio_id,
                VStrategies.id.in_(vs_ids)
            )
            vs_id2user_id = {r[1]: r[0] for r in res}
            res = sc.query(Strategy.id, Strategy.r_create_user_id).filter(Strategy.id.in_(vs_ids))
            strategy2user_id = {r[0]: r[1] for r in res}
            order_ids = list(set([v[paras_keys['order_id']] for v in payload['values']]))
            orders_detail = sc.query(VwapOrder.id, VwapOrder.algorithm, VwapOrder.status).filter(
                VwapOrder.id.in_(order_ids)
            )
            orders_detail = {
                i[0]: {
                    'algorithm': i[1],
                    'status': i[2]
                }
                for i in orders_detail
            }
            exists_order_ids = sc.query(VwapResult.order_id).filter(VwapResult.order_id.in_(order_ids))
            exists_order_ids = [i[0] for i in exists_order_ids]
            for v in payload['values']:
                if v[paras_keys['order_id']] in exists_order_ids:
                    continue
                paras = {k: v[index] for k, index in paras_keys.items()}
                paras['trading_date'] = parse(paras['trading_date'])
                paras['algorithm'] = orders_detail[v[paras_keys['order_id']]]['algorithm']
                paras['status'] = orders_detail[v[paras_keys['order_id']]]['status']
                if paras['status'] == 'real':
                    paras['user_id'] = vs_id2user_id[paras['vstrategy_id']]
                else:
                    paras['user_id'] = strategy2user_id[paras['vstrategy_id']]
                vwapr = VwapResult(
                    **paras
                )
                sc.add(vwapr)
            sc.commit()
        except Exception as e:
            sc.close()
            self.application.sentry.captureException()
            self.json_response({
                'code': 1102,
                'error': 'sava vwap result error: %s' % e
            })
            return
        sc.close()
        self.json_response({
            'code': 0
        })
        return

    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_id = int(self.get_argument('vs_id'))
        trading_date = parse(self.get_argument('trading_date')).strftime('%Y%m%d')
        sc = session()
        res = sc.query(
            VwapResult
        ).filter(
            VwapResult.vstrategy_id == vs_id,
            VwapResult.trading_date == trading_date,
        )
        columns = [
            'OrderId',
            'Account',
            'Date',
            'Direction',
            'EndTime',
            'ExecVWAP',
            'FilledRate',
            'MktDurationTWAP',
            'MktDurationVWAP',
            'MktDurationVolume',
            'MktVolume',
            'ParentID',
            'ParentOrderSize',
            'PassiveRate',
            'StartTime',
            'StratID',
            'Symbol',
            'TWAPslippage',
            'VWAPslippage',
            'day_night',
            'algorithm',
        ]

        values = [r.detail() for r in res]
        values = [[v[c] for c in columns] for v in values]
        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'columns': columns,
                'values': values
            }
        })
        return True


class VwapFilterHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        if self.is_stock_group():
            sp_create_user_id = consts.stock_user['id']
        else:
            sp_create_user_id = self.current_user['id']

        status = self.get_argument('status', 'real')
        startdate = self.get_argument('startdate')
        enddate = self.get_argument('enddate')
        day_night = int(self.get_argument('day_night'))
        algorithm = self.get_argument('algorithm', '')
        account = self.get_argument('account', '')
        portfolio = self.get_argument('portfolio', '')
        strategy = self.get_argument('strategy', '')
        symbol = self.get_argument('symbol', '')
        direction = self.get_argument('direction', '')
        if day_night == 2:
            day_night = [0, 1]
        else:
            day_night = [day_night]
        sc = session()
        vwapres = sc.query(VwapResult).filter(
            VwapResult.trading_date >= startdate,
            VwapResult.trading_date <= enddate,
            VwapResult.day_night.in_(day_night),
            # VwapResult.user_id == self.current_user['id'],
            VwapResult.status == status,
        )

        if algorithm and algorithm != 'all':
            vwapres = vwapres.filter(VwapResult.algorithm == algorithm)
        if account and account != 'all':
            vwapres = vwapres.filter(VwapResult.account == account)
        if symbol and symbol != 'all':
            vwapres = vwapres.filter(VwapResult.symbol == symbol)
        if direction and direction != 'all':
            direction_filter = {'buy': 0, 'sell': 1}[direction]
            vwapres = vwapres.filter(VwapResult.direction == direction_filter)

        if status == 'real':
            res = sc.query(VStrategies.id, StrategyPortfolio.name, Strategy.id_no).join(
                StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
            ).join(Strategy, Strategy.id == VStrategies.strategy_id)
            if not self.current_user['is_superuser']:
                res = res.filter(
                    or_(
                        StrategyPortfolio.r_create_user_id == sp_create_user_id,
                        Strategy.r_create_user_id == self.current_user['id'],
                        StrategyPortfolio.business == 'stock',
                    )
                )
            vs_detail = {r[0]: {
                'portfolio': r[1],
                'strategy': r[2]
            } for r in res}
        elif status == 'sim':
            res = sc.query(Strategy.id, Strategy.id_no)
            if not self.current_user['is_superuser']:
                res = res.filter(Strategy.r_create_user_id == self.current_user['id'])
            vs_detail = {r[0]: {
                'portfolio': '',
                'strategy': r[1]
            } for r in res}

        if vs_detail:
            vwapres = vwapres.filter(VwapResult.vstrategy_id.in_(list(vs_detail.keys())))
        else:
            vwapres = []

        data, vs_ids = [], []
        for r in vwapres:
            brief = r.brief()
            data.append(brief)
            vs_ids.append(brief['vstrategy_id'])
        for d in data:
            d['portfolio'] = vs_detail[d['vstrategy_id']]['portfolio']
            d['strategy'] = vs_detail[d['vstrategy_id']]['strategy']

        if (portfolio and portfolio != 'all') or (strategy and strategy != 'all'):
            def filter_data(d):
                flag = d['portfolio'] == portfolio if portfolio and portfolio != 'all' else True
                flag = flag and (d['strategy'] == strategy if strategy and strategy != 'all' else True)
                return flag

            data = filter(filter_data, data)

        if status == 'real':
            select_paras = [algorithm, account, portfolio, strategy, symbol, direction, None]
            indexs = ['algorithm', 'account', 'portfolio', 'strategy', 'symbol', 'direction', 'res_id']
        elif status == 'sim':
            select_paras = [algorithm, strategy, symbol, direction, None]
            indexs = ['algorithm', 'strategy', 'symbol', 'direction', 'res_id']

        for i, index in enumerate(indexs):
            if not select_paras[i]:
                select_data = {
                    'field': index,
                    'data': list(set([l[index] for l in data])),
                }
                break
        sc.close()
        self.json_response({
            'code': 0,
            'data': select_data,
        })
        return


class VwapDetailHandler(DownloadMixin, CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        if self.is_stock_group():
            sp_create_user_id = consts.stock_user['id']
        else:
            sp_create_user_id = self.current_user['id']

        res_ids = self.get_argument('res_ids', [])
        if res_ids:
            res_ids = [int(i) for i in res_ids.split(',')]
        status = self.get_argument('status', 'real')
        startdate = self.get_argument('startdate')
        enddate = self.get_argument('enddate')
        day_night = int(self.get_argument('day_night'))
        algorithm = self.get_argument('algorithm', '')
        account = self.get_argument('account', '')
        portfolio = self.get_argument('portfolio', '')
        strategy = self.get_argument('strategy', '')
        symbol = self.get_argument('symbol', '')
        direction = self.get_argument('direction', '')
        page = int(self.get_argument('page', 0))
        size = int(self.get_argument('size', 50))
        download = self.get_argument('download', '').lower()
        if download and download not in ('txt', 'csv'):
            self.json_response({
                'code': '1103',
                'error': 'download type (%s) not in (txt, csv)' % download
            })
            return

        if day_night == 2:
            day_night = [0, 1]
        else:
            day_night = [day_night]

        sc = session()
        vwapres = sc.query(VwapResult).filter(
            VwapResult.trading_date >= startdate,
            VwapResult.trading_date <= enddate,
            VwapResult.day_night.in_(day_night),
            # VwapResult.user_id == self.current_user['id'],
            VwapResult.status == status,
        )
        if res_ids:
            vwapres = vwapres.filter(VwapResult.id.in_(res_ids))
        if algorithm and algorithm != 'all':
            vwapres = vwapres.filter(VwapResult.algorithm == algorithm)
        if account and account != 'all':
            vwapres = vwapres.filter(VwapResult.account == account)
        if symbol and symbol != 'all':
            vwapres = vwapres.filter(VwapResult.symbol == symbol)
        if direction and direction != 'all':
            direction_filter = {'buy': 0, 'sell': 1}[direction]
            vwapres = vwapres.filter(VwapResult.direction == direction_filter)
        if status == 'real':
            vs_detail = sc.query(VStrategies.id, StrategyPortfolio.name, Strategy.id_no).join(
                StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
            ).join(Strategy, Strategy.id == VStrategies.strategy_id)
            if not self.current_user['is_superuser']:
                vs_detail = vs_detail.filter(
                    or_(
                        StrategyPortfolio.r_create_user_id == sp_create_user_id,
                        Strategy.r_create_user_id == self.current_user['id'],
                        StrategyPortfolio.business == 'stock',
                    )
                )
            if portfolio and portfolio != 'all':
                vs_detail = vs_detail.filter(StrategyPortfolio.name == portfolio)
            if strategy and strategy != 'all':
                vs_detail = vs_detail.filter(Strategy.id_no == strategy)
            vs_detail = {r[0]: {
                'portfolio': r[1],
                'strategy': r[2]
            } for r in vs_detail}
        elif status == 'sim':
            vs_detail = sc.query(Strategy.id, Strategy.id_no)
            if not self.current_user['is_superuser']:
                vs_detail = vs_detail.filter(Strategy.r_create_user_id == self.current_user['id'])
            if strategy and strategy != 'all':
                vs_detail.filter(Strategy.id_no == strategy)
            vs_detail = {r[0]: {
                'portfolio': '',
                'strategy': r[1]
            } for r in vs_detail}
        if vs_detail:
            vwapres = vwapres.filter(VwapResult.vstrategy_id.in_(vs_detail.keys()))
            total = vwapres.count()
            if not download:
                vwapres = vwapres.offset(page * size).limit(size)
        else:
            vwapres = []
            total = 0
        details = []
        for r in vwapres:
            r_d = r.detail()
            r_d['portfolio'] = vs_detail[r_d['StratID']]['portfolio']
            r_d['strategy'] = vs_detail[r_d['StratID']]['strategy']
            details.append(r_d)
        keys = [
            'OrderId', 'ParentID', 'StratID', 'Account', 'Date', 'day_night', 'Symbol', 'Direction',
            'ParentOrderSize', 'MktDurationVolume', 'MktDurationVWAP', 'MktDurationTWAP',
            'ExecVWAP', 'VWAPslippage', 'TWAPslippage', 'StartTime', 'EndTime', 'PassiveRate', 'FilledRate',
            'algorithm', 'portfolio', 'strategy'
        ]
        values = [[d[k] for k in keys] for d in details]
        if download:
            filename = '%s_%s_orders.%s' % (startdate, enddate, download)
            df = pd.DataFrame(values, columns=keys)
            sc.close()
            return self.downfile(df, filename)
        data = {
            'code': 0,
            'data': {
                'keys': keys,
                'values': values,
                'total': total,
            }
        }
        sc.close()
        self.json_response(data)
        return


class VwapSlippageHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        :param args:
        :param kwargs:
        :return:
        {
            'columns': ['DATE', 'SLIPPAGE', 'STDEV'],
            'values': values,
            'summary': {
                'avg': None,
                'std': None,
            }
        }
        """
        vs_id = int(self.get_argument('vs_id', 0))
        strategy_id = int(self.get_argument('strategy_id', 0))

        if vs_id:
            # handle vs upgrade
            upgrade_vs_info = VstrategyUpgrade.get_vs_upgrades()
            ids = [vs_id] + upgrade_vs_info.get(str(vs_id), [])
            id_type = 'vs'
        elif strategy_id:
            ids = [strategy_id]
            id_type = 's'
        else:
            self.json_response({
                'code': -1,
                'error': 'Both vs_id and strategy_id are null.',
            })
            return False

        daily_slippage = StrategySlippage.get_strategy_daily_slippage(ids, id_type)
        summary = StrategySlippage.get_strategy_slippage(ids, id_type)
        daily_slippage_df = pd.DataFrame(daily_slippage['values'], columns=daily_slippage['columns'])
        daily_slippage_avg = daily_slippage_df.groupby('trading_date').apply(
            lambda row: np.average(row.slippage_avg, weights=row.cash_value))
        daily_slippage_std = daily_slippage_df.groupby('trading_date').apply(
            lambda row: np.sqrt((row.slippage_std * row.slippage_std).mean())
        )
        slippage_values = []
        for i in range(len(daily_slippage_avg)):
            slippage_values.append({
                'DATE': daily_slippage_avg.index[i],
                'SLIPPAGE': round(daily_slippage_avg.iloc[i], 2),
                'STDEV': round(daily_slippage_std.iloc[i], 2),
            })

        data = {
            'columns': ['DATE', 'SLIPPAGE', 'STDEV'],
            'values': slippage_values,
            'summary': summary
        }

        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class VwapStrategyHandler(CurrentUserMixin, BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        if self.is_stock_group():
            sp_create_user_id = consts.stock_user['id']
        else:
            sp_create_user_id = self.current_user['id']

        sc = session()
        strategies = sc.query(
            Strategy.id.label('s_id'),
            Strategy.id_no.label('s_id_no'),
            Strategy.name.label('s_name'),
            VStrategies.id.label('vs_id'),
            Strategy.r_create_user_id.label('create_user_id'),
            StrategyPortfolio.r_create_user_id.label('sp_create_user_id'),
            StrategyPortfolio.name.label('sp_name'),
            StrategyPortfolio.username.label('sp_username'),
            StrategyPortfolio.id.label('sp_id'),
        ).join(
            VStrategies, VStrategies.strategy_id == Strategy.id
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            VStrategies.source == 'platform',
            StrategyPortfolio.source == 'platform',
            or_(
                Strategy.r_create_user_id == self.current_user['id'],
                StrategyPortfolio.r_create_user_id == sp_create_user_id,
                StrategyPortfolio.business == 'stock',
            )
        )

        vwap_startegies = sc.query(StrategySlippage.strategy_id, StrategySlippage.vstrategy_id).distinct()
        vwap_startegy_ids, vwap_vstartegy_ids = [], []
        for vwap_s in vwap_startegies:
            if vwap_s[0]:
                vwap_startegy_ids.append(vwap_s[0])
            if vwap_s[1]:
                vwap_vstartegy_ids.append(vwap_s[1])

        strategies = strategies.filter(
            or_(
                Strategy.id.in_(vwap_startegy_ids),
                VStrategies.id.in_(vwap_vstartegy_ids)
            )
        )

        data = {
            'my_strat': {},
            'my_invest': [],
        }
        for s in strategies:
            if s.create_user_id == self.current_user['id']:
                data['my_strat'][s.s_id] = {
                    'type': 'strategy',
                    'id': s.s_id,
                    'name': '%s_%s' % (s.s_id_no, s.s_name),
                    'strat_name': s.s_id_no,
                    'portfolio_name': 'all',
                }
                data['my_strat'][s.vs_id] = {
                    'type': 'vstrategy',
                    'id': s.vs_id,
                    'stratid': s.s_id,
                    'name': s.sp_username,
                    'strat_name': s.s_id_no,
                    'portfolio_name': s.sp_name,
                }
            if s.sp_create_user_id != self.current_user['id']:
                data['my_invest'].append({
                    'type': 'portfolio',
                    'portfolio_id': s.sp_id,
                    'portfolio_name': s.sp_name,
                    'id': s.vs_id,
                    'name': '%s_%s' % (s.s_id_no, s.s_name),
                    'strat_name': s.s_id_no,
                })
        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return


class StrategyBackTestSlippageHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        :param args:
        :param kwargs:
        :return:
        {
            'columns': ['DATE', 'SLIPPAGE', 'STDEV'],
            'values': values,
            'summary': {
                'avg': None,
                'std': None,
            }
        }
        """
        vs_id = int(self.get_argument('vs_id', 0))
        strategy_id = int(self.get_argument('strategy_id', 0))

        if not (vs_id or strategy_id):
            self.json_response({
                'code': 4001,
                'data': 'Both vs_id and strategy_id are null.',
                'error': 'Both vs_id and strategy_id are null.',
            })
            return False

        if (not strategy_id) and vs_id:
            sc = session()
            vs = sc.query(VStrategies.strategy_id).filter(VStrategies.id == vs_id).first()
            strategy_id = vs[0]
            sc.close()
            if not strategy_id:
                self.json_response({
                    'code': 4001,
                    'data': 'Both vs_id and strategy_id are null.',
                    'error': 'Both vs_id and strategy_id are null.',
                })
                return False
        daily_slippage = StrategyBackTestSlippage.get_strategy_daily_slippage(strategy_id)
        data = {'columns': ['DATE', 'SLIPPAGE', 'STDEV'],
                'values': [[v[0], round(v[1], 2), round(v[2], 2)] for v in daily_slippage['values']],
                'summary': StrategyBackTestSlippage.get_strategy_slippage(strategy_id)}
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class VsBackTestSlippageHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        :param args:
        :param kwargs:
        :return:
        {
            'columns': ['DATE', 'SLIPPAGE', 'STDEV'],
            'values': values,
            'summary': {
                'avg': None,
                'std': None,
            }
        }
        """
        vs_id = int(self.get_argument('vs_id', 0))

        if not vs_id:
            self.json_response({
                'code': 4001,
                'error': 'Both vs_id and strategy_id are null.',
            })
            return False

        # handler vs upgrade
        upgrade_vs_info = VstrategyUpgrade.get_vs_upgrades()
        vs_ids = [vs_id] + upgrade_vs_info.get(str(vs_id), [])

        daily_slippage = VsBackTestSlippage.get_strategy_daily_slippage(vs_ids)
        data = {'columns': ['DATE', 'SLIPPAGE', 'STDEV'],
                'values': [[v[0], round(v[1], 2), round(v[2], 2)] for v in daily_slippage['values']],
                'summary': VsBackTestSlippage.get_strategy_slippage(vs_ids), 'vs_trade_model': ''}

        sc = session()

        vs_trade_model = sc.query(
            VStrategies.trade_model,
            Strategy.detail
        ).join(
            Strategy, Strategy.id == VStrategies.strategy_id
        ).filter(
            VStrategies.id == vs_id,
        ).first()

        if vs_trade_model:
            data['vs_trade_model'] = vs_trade_model[0] or vs_trade_model[1].get('trade_model', '')

        sc.close()

        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class VwapBackTestResultHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        s_id = int(kwargs['id'])
        now_time = datetime.datetime.now()
        start_date = parse(self.get_argument('start_date', now_time.strftime('%Y0101'))).strftime('%Y%m%d')
        end_date = parse(self.get_argument('end_date', now_time.strftime('%Y%m%d'))).strftime('%Y%m%d')

        sc = session()
        columns = [
            'trading_date', 'symbol', 'direction', 'parent_order_size', 'vwap_slippage', 'exec_vwap', 'FilledRate'
        ]

        vwap_results = sc.query(StrategyVwapResult).filter(
            StrategyVwapResult.strategy_id == s_id,
            StrategyVwapResult.trading_date >= start_date,
            StrategyVwapResult.trading_date < end_date,
        )

        values = [
            [
                r.trading_date.strftime('%Y%m%d'), r.symbol, r.Direction,
                r.ParentOrderSize, r.VWAPslippage, r.ExecVWAP, r.FilledRate
            ] for r in vwap_results
        ]

        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'columns': columns,
                'values': values,
            },
        })
        return True

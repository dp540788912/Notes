# -*-coding:utf-8-*-

import os
import pandas as pd
import copy
import math

from my.data import meta_api
from constant import CommonPath

N_min = 60


def get_factor_score(factor_id, **kwargs):
    output_path = kwargs.get('output_path', CommonPath.new_factor_evaluation)
    try:
        res = {}
        df = pd.read_csv(os.path.join(output_path, str(factor_id), 'score.csv'))
        for i, row in df.iterrows():
            res[row['factor']] = {
                'N': row['N'],
                'score': row['score'] if row['N'] >= N_min else 0,
            }
        return res
    except Exception as e:
        return {}


def get_factor_score_df(factor_id, **kwargs):
    output_path = kwargs.get('output_path', CommonPath.new_factor_evaluation)
    df = pd.read_csv(os.path.join(output_path, str(factor_id), 'score.csv'))
    df['factor_id'] = factor_id
    return df


def get_factor_tcorr(factor_id, **kwargs):
    output_path = kwargs.get('output_path', CommonPath.new_factor_evaluation)
    try:
        res = {}
        df = pd.read_csv(os.path.join(output_path, str(factor_id), 'check22.csv'))
        for i, row in df.iterrows():
            res[row['factor']] = row['tcorr']
        return res
    except Exception as e:
        return {}


def get_factor_simu_summary(factor_id, r_type='df', **kwargs):
    output_path = kwargs.get('output_path', CommonPath.new_factor_evaluation)
    file_path = os.path.join(output_path, str(factor_id), 'summary.csv')
    df = pd.read_csv(file_path)
    df['factor'] = df['factor'].apply(lambda x: str(x))
    return df


def get_factor_score_inds(factor_id, **kwargs):
    summary = get_factor_simu_summary(factor_id)
    columns = list(set(summary['factor'].tolist()))
    ind = {
        'N': 0,
        'OS_IR': 0,
        'OS_RET': 0,
        'TVR': 0,
        'Tcorr': 0,
        'IS_IR': 0,
        'OS_POSRET': 0,
        'inxret': 0,
    }
    res = {c: copy.deepcopy(ind) for c in columns}
    factor_tcorr = get_factor_tcorr(factor_id, **kwargs)
    os_begin = ''
    os_end = ''
    for i, r in summary.iterrows():
        if r['date_range'] == 'os_date':
            os_begin = r['start_date']
            os_end = r['end_date']
            res[r['factor']]['OS_IR'] = r['ir']
            res[r['factor']]['OS_RET'] = r['ret']
            res[r['factor']]['TVR'] = r['tvr']
            res[r['factor']]['OS_POSRET'] = r['posret']
            res[r['factor']]['inxret'] = r['inxret']
        elif r['date_range'] == 'is_date':
            res[r['factor']]['IS_IR'] = r['ir']
    if os_begin != '':
        days = [int(d.replace('-', '')) for d in meta_api.get_trading_date_range(int(os_begin), int(os_end), 'SSE')]
    else:
        days = []
    n = len(days)
    for c, c_ind in res.items():
        c_ind['N'] = n
        c_ind['Tcorr'] = factor_tcorr.get(c, 0)
    return res


def gene_factor_score(factor_id, **kwargs):
    factor_summary_ind = get_factor_score_inds(factor_id, **kwargs)
    sq = math.sqrt
    scores = []
    for c, i in factor_summary_ind.items():
        if (i['OS_IR'] <= 0) or (i['OS_POSRET'] - i['inxret'] <= 10) or (i['IS_IR'] <= 0):
            s = 0
        else:
            s = sq(i['N']) * i['OS_IR'] * sq(1.0 / (i['TVR'] + 15.0)) / (math.log10(i['Tcorr'] + sq(10))) * \
                sq((float(i['OS_IR']) / i['IS_IR']) + 0.5) * \
                math.pow(i['OS_POSRET'] - i['inxret'] + 10, 0.75)

        scores.append([factor_id, c, i['N'], i['OS_IR'], i['OS_RET'], i['TVR'], i['Tcorr'], i['IS_IR'], i['OS_POSRET'],
                       i['inxret'], s])

    return scores


def generate_and_store_factor_score(factor_id, **kwargs):
    output_path = kwargs.get('output_path', CommonPath.new_factor_evaluation)
    file_path = os.path.join(output_path, str(factor_id), 'score.csv')
    scores = gene_factor_score(factor_id, **kwargs)
    columns = ['fid', 'factor', 'N', 'OS_IR', 'OS_RET', 'TVR', 'Tcorr', 'IS_IR', 'OS_POSRET', 'inxret', 'score']
    pd.DataFrame(scores, columns=columns).to_csv(file_path)


if __name__ == '__main__':
    # fidsets = pd.read_csv('./pool_score.csv')['factor_id'].unique()
    # print(len(fidsets), 'fids')
    # scores = []
    # count = 0
    # for fid in fidsets:
    #     scores += gene_factor_score(int(fid))
    #     count += 1
    #     print(fid, count)
    # score_columns = ['fid', 'factor', 'N', 'OS_IR', 'OS_RET', 'TVR', 'Tcorr', 'IS_IR', 'OS_POSRET', 'inxret', 'score']
    # pd.DataFrame(scores, columns=score_columns).to_csv(
    #     os.path.join('./', 'score2.csv')
    # )
    pass

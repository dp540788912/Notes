# -*-coding:utf-8-*-


import os
import subprocess
import json

def generate_cfg_json_file(cfg):
    tmp_file = '/home/rss/bss_server/strategy_upload/strategy_upload/service/stock_factor/factor_metric/scripts/metrics_calc/config.json'
    f = open(tmp_file, 'r')
    tmp = json.load(f)
    tmp.update(cfg)
    f.close()

    f_tmp_filename = os.path.join(os.path.dirname(tmp_file, '%s.json' % cfg['experiment_name']))
    f_tmp = open(f_tmp_filename, 'w')
    json.dump(tmp, f_tmp)
    f_tmp.close()

    return f_tmp_filename


def factor_eval(cfg):
    cfg_file_name = generate_cfg_json_file(cfg)
    cwd = '/home/rss/bss_server/strategy_upload/strategy_upload/service/stock_factor/factor_metric'
    com_list = [
        '/home/rss/bss_server/strategy_upload/venv/bin/python',
        'scripts/metrics_calc/metrics_calc.py',
        '--c',
        cfg_file_name,
    ]
    output_string = subprocess.check_output(com_list, universal_newlines=True, cwd=cwd, stderr=subprocess.STDOUT)
    return True


# -*-coding:utf-8-*-

import os
import datetime
import itertools
import math
import copy
import uuid
import json
import pandas as pd
from dateutil.parser import parse
from multiprocessing import Pool

from sqlalchemy.sql import func
from sqlalchemy.dialects.mysql import BIGINT, VARCHAR, FLOAT, BOOLEAN, DATETIME, INTEGER, JSON, DOUBLE, TEXT, DATE, TIME
from sqlalchemy import Column

import matplotlib

matplotlib.use('Agg')
import matplotlib.pyplot as plt

from db import ModelBase, session, session_context, engine
from extensions import sentry
from config import config
from kdb_query import KdbQuery
from utils import send_email
import consts
from constant import CompanyEmailGroup, CommonPath, RedisKeyConstant, StockFactorStrategyConstant
from config import RedisCache0
from utility.db_util import migrate


class StockFactor(ModelBase):
    __tablename__ = 'stock_factor'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=False)
    r_update_user_id = Column(INTEGER, nullable=True)
    username = Column(VARCHAR(32), nullable=False)
    name = Column(VARCHAR(32), nullable=True, unique=True)
    description = Column(VARCHAR(1024), nullable=True, default="")
    strategy_id = Column(INTEGER, nullable=True)
    is_publish = Column(BOOLEAN, nullable=True, default=False)
    is_delete = Column(BOOLEAN, nullable=True, default=False)
    factor_type = Column(VARCHAR(32), nullable=False, default='FACTOR')

    @staticmethod
    def stock_factor_publish(factor_id, strategy_id, **kwargs):
        pass

    @staticmethod
    def stock_factor_publish_delay(factor_id, strategy_id, **kwargs):
        pass


class StockFactorStrategy(ModelBase):
    __tablename__ = 'stock_factor_strategy'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(INTEGER, nullable=False, index=True, unique=True)
    username = Column(VARCHAR(32), nullable=False)
    name = Column(VARCHAR(32), nullable=True)
    description = Column(VARCHAR(1024), nullable=True, default="")
    is_publish = Column(BOOLEAN, nullable=True, default=False)
    is_delete = Column(BOOLEAN, nullable=True, default=False)
    factor_type = Column(VARCHAR(32), nullable=False, default='FACTOR_ALPHA')  # FACTOR_ALPHA| FACTOR_INDAY
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=False)
    r_update_user_id = Column(INTEGER, nullable=True)
    mem_size = Column(INTEGER, nullable=False, default=0)
    category = Column(VARCHAR(32), nullable=False, default='NORMAL')  # BASIC | NORMAL
    status = Column(VARCHAR(32), nullable=False, default='Upload')  # Upload, Judged, Pool, Deprecated
    status2 = Column(VARCHAR(32), nullable=False, default='Upload')  # Upload, Pool
    check_bias_status = Column(VARCHAR(32), nullable=False, default='UNINIT')
    check_bias_date = Column(VARCHAR(10), nullable=True)

    @staticmethod
    def copy_from_strategy(strategy_id):
        """
        For stock factors, here copy an item from 'back_test.models.Strategy' table into 
        stock_factor.models.StockFactorStrategy to save additional columns(factor type,category,..etc).
        
        """
        from service.back_test.models import Strategy
        sc = session()
        s = sc.query(Strategy).filter(
            Strategy.id == strategy_id,
            Strategy.strategy_type == '26',
        ).first()
        if not s:
            sc.close()
            return False
        if not (s.is_test == 0 and s.is_delete == 0):
            sc.close()
            return False
        f = sc.query(StockFactorStrategy).filter(
            StockFactorStrategy.strategy_id == strategy_id
        ).first()
        if not f:
            factor_type = 'FACTOR_ALPHA'
            if s.detail.get('factor_type') == 'DAY':
                factor_type = 'FACTOR_INDAY'

            category = 'NORMAL'
            if s.detail.get('factor_category', 0) == 1:
                category = 'BASIC'

            f = StockFactorStrategy(
                strategy_id=strategy_id,
                username=s.username,
                name=s.name,
                description=s.description,
                is_publish=True,
                is_delete=False,
                r_create_user_id=s.r_create_user_id,
                factor_type=factor_type,
                category=category,
            )
            sc.add(f)
            sc.commit()
        sc.close()
        return True

    @staticmethod
    def stock_factor_publish(factor_id, strategy_id, **kwargs):
        """
        publish stock factor,write into /data/280/meta/{st_id}.csv,
        and then convert it to npq

        :referred_task strategy_upload.cron.strategy_upload_task.stock_factor_publish_delay_task
        """
        from service.stock_factor.csv2npq import gen_factor
        from service.back_test.models import Strategy
        sc = session()
        s = sc.query(
            Strategy.r_create_user_id.label('user_id'),
            Strategy.username.label('username'),
            Strategy.start_date.label('start_date'),
        ).filter(
            Strategy.id == strategy_id
        ).first()
        if not s:
            sc.close()
            return False
        user_id, username, start_date = s.user_id, s.username, int(s.start_date or '20190101')
        if 'start_date' in kwargs:
            start_date = int(kwargs['start_date'])
        end_date = int(datetime.datetime.now().strftime('%Y%m%d'))
        if start_date > end_date:
            sc.close()
            return False
        sc.close()

        factor_columns = StockFactorStrategyColumns.get_factor_columns(factor_id)
        # write factor name into csv,like fac1,fac2,fac3.....
        with open('/data/280/meta/{st_id}.csv'.format(st_id=factor_id), 'w') as f:
            f.write(','.join(factor_columns))

        gen_factor(username, user_id, factor_id, start_date, end_date, 0)
        return True

    @staticmethod
    def gen_factor_from_csv(strategy_id, **kwargs):
        from service.back_test.models import Strategy
        from service.stock_factor.ev_factor2 import StockEvGenerateFactor
        sc = session()
        s = sc.query(
            Strategy
        ).filter(
            Strategy.id == strategy_id
        ).first()
        if not s:
            sc.close()
            return False
        csv_file = kwargs.get('csv_file')
        if not csv_file:
            csv_file = s.strategy_upload_file['abs_path']
        sc.close()

        df = pd.read_csv(csv_file, dtype={'date': str, 'ticker': str})
        columns = [c for c in df.columns.tolist() if
                   c not in ('fid', 'ticker', 'exch_time', 'local_time', 'elapsed_time', 'date', 'count', 'value')]
        if not columns:
            raise ValueError('columns is error')
        StockFactorStrategyColumns.set_factor_columns(strategy_id, columns)
        rows = []
        npq_columns = ['ticker', 'date', 'exch_time', 'local_time'] + columns
        df = df[npq_columns]
        for i, row in df.iterrows():
            rows.append(row.tolist())
        ev_generate_config = {
            'date': datetime.datetime.now().strftime('%Y%m%d'),
            'day_night': 0
        }
        factor = StockEvGenerateFactor(ev_generate_config)
        factor.send_factor_columns(strategy_id, columns)
        factor.send_factor_rows(strategy_id, rows)
        factor.write_npq()
        return True

    @staticmethod
    def stock_factor_publish_delay(factor_id, strategy_id, **kwargs):
        from cron.strategy_upload_task import stock_factor_publish_delay_task
        stock_factor_publish_delay_task.delay(factor_id, strategy_id, **kwargs)

    @staticmethod
    def stock_factor_publish_daily(trading_date, factor_id=None):
        sc = session()
        factors = sc.query(StockFactorStrategy).filter(
            StockFactorStrategy.is_delete == False,
            StockFactorStrategy.is_publish == True,
        )
        if factor_id:
            factors = factors.filter(
                StockFactorStrategy.strategy_id == factor_id
            )
        kw = {}
        if trading_date:
            kw['start_date'] = parse(trading_date).strftime('%Y%m%d')
        for fact in factors:
            try:
                StockFactorStrategy.stock_factor_publish(fact.strategy_id, fact.strategy_id, **kw)
            except Exception as e:
                sentry.captureException()
        sc.close()
        return True

    # @staticmethod
    # def factor_evalue_judge(factor_id, **kwargs):
    #     """
    #     call `my_factor.factor.factor_evalue_daily`,`my_factor.factor.factor_evalue_date_range`,`my_factor.factor.factor_evalue_judge`
    #     to output evalue judge result
    #     """
    #     from my_factor.factor import factor_evalue_daily, factor_evalue_date_range, factor_evalue_judge
    #     kdb = KdbQuery()
    #     begT = 20180101
    #     endT = 20190701
    #     datelist = kdb.get_trading_days(str(begT), str(endT))
    #     for date in datelist:
    #         cfg = {
    #             'date': date,
    #             'strategy_id': factor_id,
    #             'pool_range': 'top2000',
    #             'predict_cycle': 'v1',
    #             'basic_data_path': '/home/rss/jupyter_userworkspace/453_stock_team/app_working_dir/framework_sync/',
    #             'evalue_output_path': '/data/ev_alpha_evalue/',
    #         }
    #         try:
    #             factor_evalue_daily(cfg, redo=False)
    #         except Exception as e:
    #             sentry.captureException()
    #
    #     cfg = {
    #         'evalue_output_path': '/data/ev_alpha_evalue/',
    #         'strategy_id': factor_id,
    #         'pool_range': 'top2000',
    #         'predict_cycle': 'v1',
    #         'begT': begT,
    #         'endT': endT,
    #         'redo': True,
    #     }
    #     factor_evalue_date_range(cfg)
    #     cfg['_begT'] = cfg['_begT'].strftime('%Y%m%d')
    #     cfg['_endT'] = cfg['_endT'].strftime('%Y%m%d')
    #
    #     csv1 = os.path.join(
    #         cfg['evalue_output_path'],
    #         'factor_evalue_cycle',
    #         '{f_id}_top2000_v1'.format(f_id=factor_id),
    #         '{begT}_{endT}_icdaily.csv'.format(begT=cfg['_begT'], endT=cfg['_endT'])
    #     )
    #     csv2 = os.path.join(
    #         cfg['evalue_output_path'],
    #         'factor_evalue_cycle',
    #         '{f_id}_top2000_v1'.format(f_id=factor_id),
    #         '{begT}_{endT}_pnl.csv'.format(begT=cfg['_begT'], endT=cfg['_endT'])
    #     )
    #     if os.path.exists(csv1):
    #         csv1_tmp = os.path.join(
    #             cfg['evalue_output_path'],
    #             'factor_evalue_cycle',
    #             '{f_id}_top2000_v1'.format(f_id=factor_id),
    #             'judge_icdaily.csv'
    #         )
    #         shutil.copy2(csv1, csv1_tmp)
    #     if os.path.exists(csv2):
    #         csv2_tmp = os.path.join(
    #             cfg['evalue_output_path'],
    #             'factor_evalue_cycle',
    #             '{f_id}_top2000_v1'.format(f_id=factor_id),
    #             'judge_pnl.csv'
    #         )
    #         shutil.copy2(csv2, csv2_tmp)
    #
    #     judge_threshold_dict = dict()
    #     judge_threshold = dict()
    #     judge_threshold['ic'] = [0.01, -0.01]
    #     judge_threshold['ir'] = [0.05, None]
    #     judge_threshold['sr'] = [1, None]
    #     judge_threshold['cr'] = [0.8, None]
    #     judge_threshold['corr_max'] = [None, 0.80]
    #     judge_threshold_dict['judge1'] = judge_threshold
    #     judge_threshold = dict()
    #     judge_threshold['ac'] = [0.30, None]
    #     judge_threshold['fitness'] = [0.7, None]
    #     judge_threshold['cr'] = [0.8, None]
    #     judge_threshold['corr_max'] = [None, 0.80]
    #     judge_threshold_dict['judge2'] = judge_threshold
    #
    #     fidpool_list = [
    #         210289
    #     ]
    #
    #     fidpool_list = [
    #         211919,
    #         211934,
    #         211935,
    #         211936,
    #         211937,
    #         211938,
    #         211939,
    #     ]
    #
    #     cfg = {
    #         'evalue_output_path': '/data/ev_alpha_evalue/',
    #         'fid_pool_out_path': '/data/ev_alpha_evalue/',
    #         "strategy_id": factor_id,
    #         "fidpool": fidpool_list,
    #         "judge_threshold": judge_threshold_dict,
    #         "pool_range": 'top2000',
    #         "predict_cycle": 'v1',
    #         'begT': begT,
    #         'endT': endT,
    #         'parent_factor': [],
    #         'sibling_factor': [],
    #     }
    #     sc = session()
    #     s = sc.query(StockFactorVersion).filter(StockFactorVersion.newversion_s_id == factor_id).first()
    #     origin_ids = [factor_id]
    #     if s:
    #         cfg['parent_factor'].append(s.origin_s_id)
    #         origin_ids.append(s.origin_s_id)
    #     siblings = sc.query(StockFactorVersion).filter(StockFactorVersion.origin_s_id.in_(origin_ids))
    #     for s in siblings:
    #         cfg['sibling_factor'].append(s.origin_s_id)
    #         cfg['sibling_factor'].append(s.newversion_s_id)
    #
    #     cfg['sibling_factor'] = sorted(set([i for i in cfg['sibling_factor'] if i not in cfg['parent_factor']]))
    #     sc.close()
    #     factor_evalue_judge(cfg)
    #     StockFactorStrategy.factor_judge_result_check(factor_id)
    #     return True

    # @staticmethod
    # def factor_judge_result_check(factor_id):
    #     sc = session()
    #     factor = sc.query(StockFactorStrategy).filter(
    #         StockFactorStrategy.strategy_id == factor_id
    #     ).first()
    #     if factor.category == 'BASIC':
    #         sc.close()
    #         return True
    #     if factor.status in ('Pool', 'Deprecated'):
    #         sc.close()
    #         return True
    #     if factor.r_create_user_id in (692, 693, 694, 695, 696):
    #         sc.close()
    #         return False
    #
    #     passed_columns = StockFactorStrategyColumns.get_judge_passed_columns(factor_id)
    #     all_columns = StockFactorStrategyColumns.get_factor_columns(factor_id)
    #     if all_columns:
    #         pass_rate = float(len(passed_columns)) / len(all_columns)
    #         if pass_rate >= 0.5:
    #             factor.status = 'Pool'
    #             sc.commit()
    #     sc.close()
    #     return True

    @staticmethod
    def get_factor_evalue_judge(factor_id):
        """
        :referred_handler `strategy_upload.service.stock_factor.handlers.StockFactorjudgeDetailHandler`
        """
        from service.back_test.models import Strategy

        base_path = '/data/ev_alpha_evalue/factor_evalue_judge'
        csv_file1 = os.path.join(base_path, '{f_id}_top2000_v1.csv'.format(f_id=factor_id))
        csv_file2 = os.path.join(base_path, '{f_id}_top2000_v1_ind_judge.csv'.format(f_id=factor_id))
        columns = StockFactorStrategyColumns.get_factor_columns(factor_id)
        inds = ['cr', 'corr_max', 'sr', 'ic', 'ir', 'judge1', 'fitness', 'ac', 'judge2', 'judge_pool', 'fc', 'final']
        inds2 = ['ic', 'ir', 'cr', 'ret', 'mdd', 'sr', 'ac', 'tr', 'fitness', 'corr', 'corr_max', 'fc']
        default_res = {('%s_s' % c): False for c in inds}
        default_ind = {c: None for c in inds2}
        judge_res = {}
        judge_ind = {}

        if os.path.exists(csv_file1):
            df1 = pd.read_csv(csv_file1)
            df1['col'] = df1['Unnamed: 0']
            for i, r in df1.iterrows():
                judge_res[r['col']] = {('%s_s' % c): r.get(c, True) for c in inds}
        if os.path.exists(csv_file2):
            df2 = pd.read_csv(csv_file2)
            df2['col'] = df2['Unnamed: 0']
            for i, r in df2.iterrows():
                judge_ind[r['col']] = {c: r.get(c, 0) for c in inds2}
        sc = session()
        s = sc.query(Strategy).filter(
            Strategy.id == factor_id
        ).first()
        id_no = s.id_no
        sc.close()
        total = len(columns)
        success = 0
        rows = []
        for i, c in enumerate(columns):
            d = {
                'id': '%s_A%s' % (id_no, str(i + 1).zfill(3)),
                'factor_id': factor_id,
                'col': c,
                'col_index': i
            }
            d.update(judge_res.get(c, default_res))
            d.update(judge_ind.get(c, default_ind))
            if d['final_s']:
                success += 1
            rows.append(d)
        data = {
            'total': total,
            'success': success,
            'rows': rows
        }
        return data

    @staticmethod
    def get_factor_evalue_judge_daily(factor_id, col):
        """
        :referred_handler `strategy_upload.service.stock_factor.handlers.StockFactorjudgeDailyDetailHandler`
        """
        base_path = '/data/ev_alpha_evalue/'
        csv_file1 = os.path.join(
            base_path,
            'factor_evalue_cycle',
            '{f_id}_top2000_v1'.format(f_id=factor_id),
            'judge_icdaily.csv'
        )
        csv_file2 = os.path.join(
            base_path,
            'factor_evalue_cycle',
            '{f_id}_top2000_v1'.format(f_id=factor_id),
            'judge_pnl.csv'
        )
        ic_daily = {}
        pnl_daily = {}
        if os.path.exists(csv_file1):
            df1 = pd.read_csv(csv_file1)
            df1['col'] = df1['Unnamed: 0']
            df1 = df1.drop(columns=['Unnamed: 0'])
            columns = df1.columns
            for i, row in df1.iterrows():
                if row['col'] != col:
                    continue
                for c in columns:
                    if c == 'col':
                        continue
                    ic_daily[c] = row[c]
                break
        if os.path.exists(csv_file2):
            df2 = pd.read_csv(csv_file2)
            df2['col'] = df2['Unnamed: 0']
            df2 = df2.drop(columns=['Unnamed: 0'])
            columns = df2.columns
            for i, row in df2.iterrows():
                if row['col'] != col:
                    continue
                for c in columns:
                    if c == 'col':
                        continue
                    pnl_daily[c] = row[c]
                break
        dates = sorted(list(ic_daily.keys()) + list(pnl_daily.keys()))
        ic, pnl = [], []
        for d in dates:
            ic.append(ic_daily.get(d, 0))
            pnl.append(pnl_daily.get(d, 0))
        data = {
            'ic': ic,
            'pnl': pnl,
            'days': dates,
        }
        return data

    @staticmethod
    def factor_evalue(factor_id, **kwargs):
        from service.back_test.models import Strategy
        sc = session()
        s = sc.query(Strategy).filter(Strategy.id == factor_id).first()
        if not s:
            sc.close()
            return False
        if not (s.node == 'ev' and s.strategy_type == '26' and s.detail.get('factor_category', 1) == 0):
            sc.close()
            return False
        init_estimations = StockFactorEstimation.generate_factor_estimations(factor_id)
        if kwargs.get('initial', False) and (not init_estimations):
            sc.close()
            return False
        sc.close()

        stock_pool = ['ZZ500', 'TOP2000']
        for sp in stock_pool:
            StockFactorEstimation.generate_daily_indicator(factor_id, sp, **kwargs)

        for sp in stock_pool:
            StockFactorEstimation.generate_date_range_indicator(factor_id, sp, **kwargs)
        return True

    @staticmethod
    def daily_generate_factor_evalue(mutilprocess=False, **kwargs):
        """
        :referred_task `strategy_upload.bin.daily_generate_factor_pool_indicator.main`
        """
        from service.back_test.models import Strategy
        if kwargs.get('factor_ids'):
            factor_ids = []
        else:
            sc = session()
            factors = sc.query(
                StockFactorStrategy.strategy_id
            ).filter(
                StockFactorStrategy.is_publish == True,
                StockFactorStrategy.is_delete == False,
                StockFactorStrategy.factor_type == 'FACTOR_ALPHA',
                StockFactorStrategy.status == 'Pool',
                StockFactorStrategy.strategy_id >= 211715,
            )
            factor_ids = [f[0] for f in factors]
            if factor_ids:
                factors = sc.query(
                    Strategy.id
                ).filter(
                    Strategy.is_delete == 0,
                    Strategy.is_test == 0,
                    Strategy.id.in_(factor_ids)
                )
                factor_ids = [f[0] for f in factors]
            sc.close()
        endT = (datetime.datetime.now() - datetime.timedelta(days=5)).strftime('%Y%m%d')
        if mutilprocess:
            kw = {
                'redo': False,
                'endT': endT,
            }
            with Pool(processes=8) as pool:
                for f_id in factor_ids:
                    pool.apply_async(StockFactorStrategy.factor_evalue, [f_id], kwds=kw)
                pool.close()
                pool.join()
        else:
            for f_id in factor_ids:
                try:
                    StockFactorStrategy.factor_evalue(f_id, redo=False, endT=endT)
                except Exception as e:
                    sentry.captureException()
        return True

    @staticmethod
    def get_factor_pool2(factor_type_filters=None):
        from service.back_test.models import Strategy
        if factor_type_filters is None:
            factor_type_filters = list()
        sc = session()
        factors = sc.query(
            StockFactorStrategy.strategy_id.label('factor_id')
        ).filter(
            StockFactorStrategy.is_delete == False,
            StockFactorStrategy.is_publish == True,
            StockFactorStrategy.status2 == 'Pool',
            StockFactorStrategy.factor_type == 'FACTOR_ALPHA',
            StockFactorStrategy.category == 'NORMAL',
        )
        factor_ids = [f.factor_id for f in factors]
        strategies = sc.query(
            Strategy.id.label('id'),
            Strategy.detail.label('detail'),
        ).filter(
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.id.in_(factor_ids)
        )
        data = {}
        for s in strategies:
            f_type = s.detail.get('algorithm', '')
            if f_type not in factor_type_filters:
                continue

            s_id = s.id
            try:
                cols = StockFactorStrategyColumns.get_judge_passed_columns2(s_id)
                data[s_id] = {
                    'factors': cols
                }
            except Exception as e:
                sentry.captureException()

        sc.close()
        return data

    @staticmethod
    def get_factor_start_date(factor_id):
        kdb = KdbQuery()
        days = kdb.get_trading_days('20120101', '20140201')
        last_date = days[-1]
        for d in days:
            npq_path = '/data/280/{year}/{trading_date}/0/0/{factor_id}.npq'.format(
                year=d[:4],
                trading_date=d,
                factor_id=factor_id,
            )
            if os.path.exists(npq_path):
                return d
        return last_date

    @staticmethod
    def factor_pool_evaluation_v3(factor_id, start_date='20140101', **kwargs):
        """
        call `my_factor.factor.do_simulator` to simulate factor pool and then
        use `my_factor.factor.SimSummary.get_summary` to get summary

        :referred_task `strategy_upload.bin.daily_generate_factor_pool_indicator`
        """
        from service.back_test.models import Strategy
        from my_factor.factor import check_direction, get_factor_direction, do_simulator, SimSummary
        try:
            kwargs['redo'] = False
            # kwargs['created_date'] = '20190301'
            end_date = kwargs.get('end_date', '20191101')
            direction = get_factor_direction(factor_id)
            if not direction:
                check_direction(factor_id)
                direction = get_factor_direction(factor_id)
                if not direction:
                    raise ValueError('check direction error')

            sc = session()
            s = sc.query(StockFactorStrategy).filter(
                StockFactorStrategy.strategy_id == factor_id
            ).first()
            kwargs['created_date'] = s.r_create_time.strftime('%Y%m%d')

            s2 = sc.query(Strategy).filter(
                Strategy.id == factor_id
            ).first()

            if s2.start_date <= '20120101':
                start_date = '20120101'

            npq_start_date = StockFactorStrategy.get_factor_start_date(factor_id)
            start_date = max(start_date, npq_start_date)

            sc.close()
            if 'end_date' in kwargs:
                del kwargs['end_date']

            do_simulator(factor_id, start_date=start_date, end_date=end_date, **kwargs)
            SimSummary.get_summary(factor_id, start_date=start_date, end_date=end_date, **kwargs)
        except Exception as e:
            sentry.captureException()

        # generate simulation result graph
        try:
            StockFactorStrategy.generate_pnl_graph_v2(factor_id)
        except Exception as e:
            sentry.captureException()

    @staticmethod
    def get_factor_simu_summary(factor_id, **kwargs):
        output_path = kwargs.get('output_path', CommonPath.new_factor_evaluation)
        file_path = os.path.join(output_path, str(factor_id), 'summary.csv')
        df = pd.read_csv(file_path)
        df['factor'] = df['factor'].apply(lambda x: str(x))
        return df

    @staticmethod
    def factor_judge_v2(factor_id, start_date='20140101', end_date='20171231', **kwargs):
        from my_factor.factor import Isladder, IsladderLowTvr, correlation, do_sub_rank
        from service.back_test.models import Strategy

        sc = session()
        s = sc.query(Strategy).filter(Strategy.id == factor_id).first()
        if s.start_date <= '20120101':
            start_date = '20120101'
        sc.close()

        npq_start_date = StockFactorStrategy.get_factor_start_date(factor_id)
        start_date = max(start_date, npq_start_date)

        output_path = kwargs.get('output_path', CommonPath.new_factor_evaluation)
        check_file_path = os.path.join(output_path, str(factor_id), 'check.csv')
        columns = StockFactorStrategyColumns.get_factor_columns(factor_id)
        is_ladder = Isladder.simu(factor_id, start_date=start_date, end_date='20190110')
        rank_sub_test = do_sub_rank(factor_id, start_date=start_date, end_date=end_date, output_path=output_path)
        factor_pool = {}
        corr = correlation(factor_id, factor_pool)
        max_corr = corr['max_corr']
        summary_df = StockFactorStrategy.get_factor_simu_summary(factor_id)
        fitness = {c: 0 for c in columns}
        low_tvr_factors = []
        for i, row in summary_df.iterrows():
            if row['date_range'] == 'is_date':
                fitness[row['factor']] = row['fitness']
                if float(row['tvr']) <= 15:
                    low_tvr_factors.append(row['factor'])

        if low_tvr_factors:
            low_tvr_is_ladder = IsladderLowTvr.simu(factor_id)
            for _f in low_tvr_factors:
                if _f in low_tvr_is_ladder:
                    # is_ladder[_f] = low_tvr_is_ladder[_f]
                    is_ladder[_f]['ladder'] = is_ladder[_f]['ladder'] or low_tvr_is_ladder[_f]['ladder']

        check_res = {
            'factor': '',
            'Fitness': 0,
            'ind_Fitness': False,
            'Correlation': 0,
            'ind_Correlation': False,
            'ISLADDAR': False,
            'ind_ISLADDAR': False,
            'ind_RankTest': False,
            'ind_SubTest': False,
            'RankTest': 0,
            'SubTest': 0,
            'Sub2000Val': 0,
            'Sub1000Val': 0,
            'CheckBias': None,
            'ind_CheckBias': None,
            'final_s': True,
            'tcorr': 0,
        }

        check_columns = [
            'factor', 'Fitness', 'ind_Fitness', 'Correlation', 'ind_Correlation',
            'ISLADDAR', 'ind_ISLADDAR', 'ind_RankTest', 'ind_SubTest', 'RankTest',
            'SubTest', 'Sub2000Val', 'Sub1000Val', 'CheckBias', 'ind_CheckBias', 'final_s', 'tcorr',
        ]

        check_values = []

        for c in columns:
            c_check = copy.deepcopy(check_res)

            c_check['factor'] = c
            c_check['Fitness'] = fitness.get(c, 0)
            c_check['ind_Fitness'] = True if c_check['Fitness'] > 1.0 else False
            c_check['Correlation'] = max_corr.get(c, {}).get('val', 0)

            if c_check['Correlation'] <= 0.7:
                c_check['ind_Correlation'] = True
            else:
                max_corr_fitness = 999999
                try:
                    max_corr_factor_summary_df = StockFactorStrategy.get_factor_simu_summary(max_corr[c]['factor_id'])
                    for _i, _row in max_corr_factor_summary_df.iterrows():
                        if _row['date_range'] == 'is_date' and _row['factor'] == max_corr[c]['col']:
                            max_corr_fitness = _row['fitness']
                except Exception as e:
                    sentry.captureException()

                if c_check['Correlation'] > 0.7 and c_check['Fitness'] >= (1.2 * max_corr_fitness):
                    c_check['ind_Correlation'] = True
                elif c_check['Correlation'] >= 0.8 and c_check['Fitness'] >= (1.25 * max_corr_fitness):
                    c_check['ind_Correlation'] = True
                elif c_check['Correlation'] >= 0.9 and c_check['Fitness'] >= (1.3 * max_corr_fitness):
                    c_check['ind_Correlation'] = True

            c_check['ISLADDAR'] = is_ladder.get(c, {}).get('ladder', False)
            c_check['ind_ISLADDAR'] = c_check['ISLADDAR']

            c_rank_sub = rank_sub_test.get(c, {})

            c_check['ind_RankTest'] = c_rank_sub.get('rank_test', False)
            c_check['ind_SubTest'] = c_rank_sub.get('sub_test', False)
            c_check['RankTest'] = c_rank_sub.get('rank_val', 0)
            c_check['Sub2000Val'] = c_rank_sub.get('sub_2000_val', 0)
            c_check['Sub1000Val'] = c_rank_sub.get('sub_1000_val', 0)
            c_check['SubTest'] = '%s %s' % (round(c_check['Sub2000Val'], 2), round(c_check['Sub1000Val'], 2))
            c_check['final_s'] = c_check['ind_Fitness'] and c_check['ind_Correlation'] and c_check['ind_ISLADDAR'] and \
                                 c_check['ind_RankTest'] and c_check['ind_SubTest']

            check_values.append(c_check)

        df = pd.DataFrame(check_values, columns=check_columns)
        df.to_csv(check_file_path)
        return df

    @staticmethod
    def get_factor_is_date_fitness(factor_id):
        try:
            res = {}
            df = StockFactorStrategy.get_factor_simu_summary(factor_id)
            for i, row in df.iterrows():
                if row['date_range'] == 'is_date':
                    res[row['factor']] = row['fitness']
            return res
        except Exception as e:
            sentry.captureException()
        return {}

    @staticmethod
    def check_version_upgrade(factor_id):
        sc = session()
        version = sc.query(StockFactorVersion).filter(
            StockFactorVersion.newversion_s_id == factor_id
        ).first()
        if not version:
            sc.close()
            return True, 0
        old_factor_id = version.origin_s_id
        sc.close()
        old_passed_columns = StockFactorStrategyColumns.get_judge_passed_columns2(old_factor_id)
        old_fitness = StockFactorStrategy.get_factor_is_date_fitness(old_factor_id)
        new_fitness = StockFactorStrategy.get_factor_is_date_fitness(factor_id)
        new_passed_count = 0
        for c in old_passed_columns:
            old_fit = old_fitness[c]
            new_fit = new_fitness[c]
            if new_fit <= old_fit:
                continue
            new_passed_count += 1
        if new_passed_count <= len(old_passed_columns) * 0.7:
            return False, old_factor_id
        return True, old_factor_id

    # NO USE,REPLACED BY `strategy_upload.service.stock_factor.factor_judge_check.factor_judge_check_result_v22`
    # @staticmethod
    # def factor_judge_check_result_v2(factor_id, start_date='20140101', end_date='20171231', **kwargs):
    #     from my_factor.factor import FactorSubRankTestSimu, FactorCorrelation, Isladder, correlation
    #     output_path = kwargs.get('output_path', '/data/ev_alpha_evalue/new_factor_evalue')
    #     check_file_path = os.path.join(output_path, str(factor_id), 'check.csv')
    #     check2_file_path = os.path.join(output_path, str(factor_id), 'check2.csv')
    #     if not os.path.exists(check_file_path):
    #         return True
    #     check_df = pd.read_csv(check_file_path)
    #     check_df = check_df.drop(columns=['Unnamed: 0'])
    #     check_df = check_df.set_index(['factor'])
    #     check_df['tcorr'] = 0
    #
    #     version_check, old_factor_id = StockFactorStrategy.check_version_upgrade(factor_id)
    #     if not version_check:
    #         check_df['ind_Fitness'] = False
    #         check_df['final_s'] = False
    #         check_df.to_csv(check2_file_path)
    #         return check_df
    #
    #     check_df2 = check_df.sort_values(['Fitness'], ascending=False)
    #     factor_pool = {
    #         _f_id: _f_factors
    #         for _f_id, _f_factors in StockFactorStrategy.get_factor_pool2().items()
    #         if (_f_id < factor_id) and (_f_id != old_factor_id)
    #     }
    #
    #     corr = correlation(factor_id, factor_pool)
    #     pass_cols = []
    #
    #     factor_pool_fitness = {
    #         f_id: StockFactorStrategy.get_factor_is_date_fitness(f_id)
    #         for f_id in factor_pool.keys()
    #     }
    #     factor_pool_fitness[factor_id] = StockFactorStrategy.get_factor_is_date_fitness(factor_id)
    #
    #     for f, row in check_df2.iterrows():
    #         if not (row['ind_ISLADDAR'] and row['ind_Fitness'] and row['ind_RankTest'] and row['ind_SubTest']):
    #             continue
    #         max_corr = 0
    #         f_corr_detail = corr['detail_corr'][f]
    #         max_corr_keys = {
    #             '7': [],
    #             '8': [],
    #             '9': []
    #         }
    #         tcorr = 0
    #         for k, v in f_corr_detail.items():
    #             if (k[0] != factor_id) or (k[0] == factor_id and k[1] in pass_cols):
    #                 if v >= max_corr:
    #                     max_corr = v
    #                 if 0.7 < v < 0.8:
    #                     max_corr_keys['7'].append(k)
    #                 elif 0.8 <= v < 0.9:
    #                     max_corr_keys['8'].append(k)
    #                 elif 0.9 < v:
    #                     max_corr_keys['9'].append(k)
    #
    #                 if v > 0.25:
    #                     tcorr += v
    #         check_df.loc[f, 'Correlation'] = max_corr
    #         check_df.loc[f, 'tcorr'] = tcorr
    #         ind_Correlation = False
    #         if max_corr <= 0.7:
    #             ind_Correlation = True
    #         else:
    #             fitness_keys = []
    #
    #             if 0.7 < max_corr < 0.8:
    #                 fitness_keys = max_corr_keys['7']
    #             elif 0.8 <= max_corr < 0.9:
    #                 fitness_keys = max_corr_keys['8']
    #             elif 0.9 < max_corr:
    #                 fitness_keys = max_corr_keys['9']
    #
    #             max_corr_fitness = -999999
    #             for k in fitness_keys:
    #                 k_fitness = factor_pool_fitness[k[0]][k[1]]
    #                 if k_fitness > max_corr_fitness:
    #                     max_corr_fitness = k_fitness
    #
    #             if max_corr_fitness <= -99999:
    #                 max_corr_fitness = 999999
    #
    #             if (0.7 < max_corr < 0.8) and row['Fitness'] >= (1.2 * max_corr_fitness):
    #                 ind_Correlation = True
    #             elif (0.8 <= max_corr < 0.9) and row['Fitness'] >= (1.25 * max_corr_fitness):
    #                 ind_Correlation = True
    #             elif (0.9 < max_corr) and row['Fitness'] >= (1.3 * max_corr_fitness):
    #                 ind_Correlation = True
    #
    #         check_df.loc[f, 'ind_Correlation'] = ind_Correlation
    #         check_df.loc[f, 'final_s'] = ind_Correlation
    #
    #         if check_df.loc[f]['final_s']:
    #             pass_cols.append(f)
    #     columns = StockFactorStrategyColumns.get_factor_columns(factor_id)
    #     if columns:
    #         pass_rate = len(pass_cols) / len(columns)
    #         pass_rate_threshold = 0.5
    #         if factor_id <= 215216:
    #             pass_rate_threshold = 0.0001
    #         if pass_rate >= pass_rate_threshold:
    #             StockFactorStrategy.set_factor_pool_passed(factor_id)
    #     check_df.to_csv(check2_file_path)
    #     return check_df

    # @staticmethod
    # def send_check_direction_event(factor_id, *args, **kwargs):
    #     """
    #     notify task queue `consts.StockFactorEvaleQueue` to check
    #
    #     :referred_task `strategy_upload.cron.strategy_upload_task.factor_out_sample_done`
    #     """
    #     event = {
    #         'factor_id': factor_id,
    #         'event': StockFactorEvaluationQueueEvent.CheckFactorDirection.value,
    #         'args': args,
    #         'kwargs': kwargs,
    #     }
    #     rds = RedisCache0()
    #     rds.rpush(RedisKeyConstant.StockFactorEvaluationQueue.value, json.dumps(event))
    #     return True

    # @staticmethod
    # def send_simulator_event(factor_id, *args, **kwargs):
    #     """
    #      notify task queue `consts.StockFactorEvaleQueue` to simulate
    #
    #      :referred_task `strategy_upload.cron.strategy_upload_task.factor_task_done`
    #      :referred_task `strategy_upload.cron.strategy_upload_task.factor_upload_csv_done`
    #     """
    #     event = {
    #         'factor_id': factor_id,
    #         'event': StockFactorEvaluationQueueEvent.Simulator.value,
    #         'args': args,
    #         'kwargs': kwargs,
    #     }
    #     rds = RedisCache0()
    #     rds.rpush(RedisKeyConstant.StockFactorEvaluationQueue.value, json.dumps(event))
    #     return True

    # @staticmethod
    # def send_papertrading_event(factor_id, *args, **kwargs):
    #     if 'end_date' not in kwargs:
    #         kwargs['end_date'] = (datetime.datetime.now() - datetime.timedelta(days=3)).strftime('%Y%m%d')
    #     event = {
    #         'factor_id': factor_id,
    #         'event': StockFactorEvaluationQueueEvent.Papertrading.value,
    #         'args': args,
    #         'kwargs': kwargs,
    #     }
    #     rds = RedisCache0()
    #     rds.rpush(RedisKeyConstant.StockFactorEvaluationQueue.value, json.dumps(event))
    #     return True

    @staticmethod
    def send_event(factor_id, event, *args, **kwargs):
        """
        send event to stock factor evaluation queue
        :param factor_id: int, strategy id
        :param event: string, constant.StockFactorEvaluationQueueEvent
        :param args:
        :param kwargs:
        :return:
        """
        event = {
            'factor_id': factor_id,
            'event': event,
            'args': args,
            'kwargs': kwargs,
        }
        rds = RedisCache0()
        rds.rpush(RedisKeyConstant.StockFactorEvaluationQueue.value, json.dumps(event))
        return True

    @staticmethod
    def set_factor_pool_passed(factor_id):
        sc = session()
        f = sc.query(StockFactorStrategy).filter(
            StockFactorStrategy.strategy_id == factor_id
        ).first()
        if f.username in ('factor1', 'factor2', 'factor3', 'factor5', 'factor6', 'factor7'):
            sc.close()
            return True
        f.status2 = 'Pool'
        sc.commit()
        sc.close()
        return True

    # NO USE
    # @staticmethod
    # def get_check_summary(factor_id, **kwargs):
    #     from service.back_test.models import Strategy
    #     res = {
    #         'status': 'Upload',
    #         'columns': StockFactorStrategyColumns.get_factor_columns(factor_id),
    #         'passed': StockFactorStrategyColumns.get_judge_passed_columns2(factor_id),
    #         'corr': {},
    #         'semi_pass': [],
    #         'corr6': [],
    #         'corr65': [],
    #         'author': '',
    #         'algorithm': '',
    #     }
    #     if res['passed']:
    #         res['status'] = 'Pool'
    #     check_file1 = '/data/ev_alpha_evalue/new_factor_evalue/%s/check.csv' % factor_id
    #     check_file2 = '/data/ev_alpha_evalue/new_factor_evalue/%s/check22.csv' % factor_id
    #     check_file = check_file1
    #     if os.path.exists(check_file2):
    #         check_file = check_file2
    #     if not os.path.exists(check_file):
    #         return res
    #     check_df = pd.read_csv(check_file)
    #     for i, row in check_df.iterrows():
    #         semi_pass = bool(row['ind_ISLADDAR'] and row['ind_Fitness'] and row['ind_RankTest'] and row['ind_SubTest'])
    #         if semi_pass:
    #             res['semi_pass'].append(row['factor'])
    #         res['corr'][row['factor']] = row['Correlation']
    #         if res['status'] == 'Pool' and row['final_s']:
    #             if row['Correlation'] >= 0.6:
    #                 res['corr6'].append(row['factor'])
    #             if row['Correlation'] >= 0.65:
    #                 res['corr65'].append(row['factor'])
    #     sc = session()
    #     s = sc.query(Strategy).filter(Strategy.id == factor_id).first()
    #     res['author'] = s.username
    #     res['algorithm'] = s.detail.get('algorithm', 'other')
    #     sc.close()
    #     return res

    # NO USE
    # @staticmethod
    # def get_factor_simsummary_indicator(factor_id, **kwargs):
    #     from service.back_test.models import Strategy
    #     res = {
    #         'status': 'Upload',
    #         'columns': StockFactorStrategyColumns.get_factor_columns(factor_id),
    #         'passed': StockFactorStrategyColumns.get_judge_passed_columns2(factor_id),
    #         'author': '',
    #         'algorithm': '',
    #         'is_tvr': {},
    #         'semi_os_tvr': {},
    #     }
    #     if res['passed']:
    #         res['status'] = 'Pool'
    #     df = StockFactorStrategy.get_factor_simu_summary(factor_id)
    #     for i, row in df.iterrows():
    #         if row['date_range'] == 'is_date':
    #             res['is_tvr'][row['factor']] = row['tvr']
    #         elif row['date_range'] == 'semi_os_date':
    #             res['semi_os_tvr'][row['factor']] = row['tvr']
    #     sc = session()
    #     s = sc.query(Strategy).filter(Strategy.id == factor_id).first()
    #     res['author'] = s.username
    #     res['algorithm'] = s.detail.get('algorithm', 'other')
    #     sc.close()
    #     return res

    @staticmethod
    def generate_pnl_graph_v2(factor_id):
        factor_columns = StockFactorStrategyColumns.get_factor_columns(factor_id)
        values = []
        columns = ['factor', 'pnl_url']
        output_path = CommonPath.new_factor_evaluation
        graph_file_path = os.path.join(output_path, str(factor_id), 'pnl_graph.csv')
        daily_summary_pnl_path = os.path.join(output_path, 'daily_summary_pnl', str(factor_id))
        for c in factor_columns:
            try:
                daily_summary_pnl_file = os.path.join(daily_summary_pnl_path, '%s_pnl.csv' % c)
                pnl_df = pd.read_csv(daily_summary_pnl_file)
                pnl = list(pnl_df['pnl'].cumsum())
                pnl_file_name = '%s.png' % uuid.uuid4().hex
                StockFactorEstimation.generate_graph(list(range(len(pnl))), pnl, pnl_file_name)
                values.append([c, os.path.join(CommonPath.stock_factor_graph, pnl_file_name)])
            except Exception as e:
                sentry.captureException()
        pd.DataFrame(values, columns=columns).to_csv(graph_file_path, index=False)
        return True

    @staticmethod
    def get_pnl_graph_url_v2(factor_id):
        output_path = CommonPath.new_factor_evaluation
        graph_file_path = os.path.join(output_path, str(factor_id), 'pnl_graph.csv')
        factors = StockFactorStrategyColumns.get_factor_columns(factor_id)
        res = {f: '' for f in factors}
        try:
            df = pd.read_csv(graph_file_path)
            for i, row in df.iterrows():
                res[row['factor']] = row['pnl_url']
        except Exception as e:
            pass
        return res

    @staticmethod
    def get_factor_pool_estimation_indicator_v2(**kwargs):
        """
        integrate factor pool simulation result summary.csv,check22.csv,score.csv

        :referred_handler `strategy_upload.service.stock_factor.handlers.StockPoolEstimationIndicatorHandler`
        """
        from service.back_test.models import Strategy
        # filter conditions
        s_ids = kwargs.get('s_ids', [])
        users = kwargs.get('users', [])
        algorithms = kwargs.get('algorithms', [])
        is_my_factor = kwargs.get('is_my_factor', False)
        current_user_id = kwargs.get('current_user_id', 0)
        sc = session()

        factor_strategies = sc.query(
            StockFactorStrategy.strategy_id.label('factor_id')
        ).filter(
            StockFactorStrategy.factor_type == 'FACTOR_ALPHA',
            StockFactorStrategy.category == 'NORMAL',
        )

        if s_ids:
            factor_strategies = factor_strategies.filter(
                StockFactorStrategy.strategy_id.in_(s_ids)
            )

        if users:
            factor_strategies = factor_strategies.filter(
                StockFactorStrategy.username.in_(users)
            )

        if not (users or s_ids):
            factor_strategies = factor_strategies.filter(
                StockFactorStrategy.strategy_id.in_(s_ids)
            )

        if is_my_factor:
            factor_strategies = factor_strategies.filter(
                StockFactorStrategy.r_create_user_id == current_user_id
            )
        else:
            factor_strategies = factor_strategies.filter(
                StockFactorStrategy.status2 == 'Pool'
            )

        factor_ids = [f.factor_id for f in factor_strategies]

        strategies = sc.query(
            Strategy
        ).filter(
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.strategy_type == '26',
            Strategy.id.in_(
                factor_ids
            )
        )

        strategy_detail = {}
        # get file index
        for s in strategies:
            algo = s.detail.get('algorithm', 'other')
            if algorithms and (algo not in algorithms):
                continue
            strategy_detail[s.id] = {
                'id_no': s.id_no,
                'factors': {c: i for i, c in enumerate(StockFactorStrategyColumns.get_factor_columns(s.id), 1)},
                'pass_factors': {c: i for i, c in
                                 enumerate(StockFactorStrategyColumns.get_judge_passed_columns2(s.id), 1)},
                'algorithm': algo
            }
        sc.close()

        data = {}

        output_path = '/data/ev_alpha_evalue/new_factor_evalue/'

        for f_id in strategy_detail.keys():
            # try to find /data/ev_alpha_evalue/new_factor_evalue/{f_id}/summary.csv
            try:
                df = pd.read_csv(os.path.join(output_path, str(f_id), 'summary.csv'))
            except Exception as e:
                sentry.captureException()
                continue

            tcorr = {}
            # try to find /data/ev_alpha_evalue/new_factor_evalue/{f_id}/check22.csv
            try:
                tcorr_df = pd.read_csv(os.path.join(output_path, str(f_id), 'check22.csv'))
                for i, row in tcorr_df.iterrows():
                    tcorr[row['factor']] = row['tcorr']
            except Exception as e:
                pass

            # try to find /data/ev_alpha_evalue/new_factor_evalue/{f_id}/score.csv
            factor_score = dict()
            try:
                score_df = pd.read_csv(os.path.join(output_path, str(f_id), 'score.csv'))
                for i, row in score_df.iterrows():
                    score = row['score'] if row['N'] >= 60 else 0
                    factor_score[row['factor']] = score
            except Exception as e:
                pass

            df['direction'] = 1
            df['universe'] = 'ALL'
            df['is_date'] = '20171231'
            f_algorithm = strategy_detail[f_id]['algorithm']

            if is_my_factor:
                f_pass_factors = strategy_detail[f_id]['factors']
            else:
                f_pass_factors = strategy_detail[f_id]['pass_factors']

            factors_index = strategy_detail[f_id]['factors']
            f_id_no = strategy_detail[f_id]['id_no']

            pnl_urls = StockFactorStrategy.get_pnl_graph_url_v2(f_id)

            ind_cols = ['ret', 'shrp', 'fitness', 'tvr', 'dd', 'posret', 'bpmrgn', 'inxret', 'IC', 'Coverage']
            for i, row in df.iterrows():
                if row['factor'] not in f_pass_factors:
                    continue
                factor = row['factor']
                col_index = factors_index[factor]
                k = '%s_%s' % (f_id, factor)
                f_data = data.setdefault(k, {})
                f_data['strategy_id'] = f_id
                f_data['col_index'] = col_index
                f_data['factor_id'] = '%s_A%s' % (f_id_no, str(col_index).zfill(3))
                f_data['name'] = row['factor']
                f_data['direction'] = 1
                f_data['universe'] = row['universe']
                f_data['is_date'] = row['is_date']
                f_data['pnl_url'] = pnl_urls.get(factor, '')
                f_data['algorithm'] = f_algorithm
                # merge check22.csv result to data
                f_data['tcorr'] = round(tcorr.get(factor, 0), 2)
                # merge score.csv result to data
                f_data['factor_score'] = round(factor_score.get(factor, 0), 2)

                if row['date_range'] == 'is_date':
                    for c in ind_cols:
                        f_data['%s_is' % c] = row[c]
                elif (row['date_range'] == 'os_date') and (not is_my_factor):
                    for c in ind_cols:
                        f_data['%s_os' % c] = row[c]
                elif (row['date_range'] == 'semi_os_date') and (not is_my_factor):
                    for c in ind_cols:
                        f_data['%s_semi_os' % c] = row[c]
        return sorted(data.values(), key=lambda x: x['factor_id'])

    @staticmethod
    def get_factor_pnl_indicator_v2(factor_id, col_name, **kwargs):
        """
        get factor pnl indicator from /data/ev_alpha_evalue/new_factor_evalue/daily_summary_pnl/{factor_id}/{col_name}_pnl.csv
        get pnl summary `strategy_upload.service.stock_factor.models.StockFactorStrategy.get_factor_summary_v2`

        :referred_handler `strategy_upload.strategy_upload.service.stock_factor.handlers.StockFactorPnlIndicatorHandler`
        """
        from service.back_test.models import Strategy

        is_my_factor = kwargs.get('is_my_factor', False)

        sc = session()
        s = sc.query(Strategy.r_create_time.label('r_create_time')).filter(
            Strategy.id == factor_id
        ).first()
        create_date = s.r_create_time.strftime('%Y%m%d')
        sc.close()
        output_path = '/data/ev_alpha_evalue/new_factor_evalue'
        # TODO: IMPROVE : decrease join function call
        daily_summary_pnl_path = os.path.join(output_path, 'daily_summary_pnl', str(factor_id))
        daily_summary_pnl_file = os.path.join(daily_summary_pnl_path, '%s_pnl.csv' % col_name)
        pnl_df = pd.read_csv(daily_summary_pnl_file)
        pnl_df['trading_date'] = pnl_df['trading_date'].apply(lambda x: str(x))
        pnl_df['cum_pnl'] = pnl_df['pnl'].cumsum().round(2)
        dates = []
        cum_pnls = []
        papertrading_date = '20171229'
        papertrading_date_index = -1
        for i, row in pnl_df.iterrows():
            dates.append(row['trading_date'])
            cum_pnls.append(row['cum_pnl'])
            if (papertrading_date_index < 0) and row['trading_date'] >= papertrading_date:
                papertrading_date_index = i

        summaries = StockFactorStrategy.get_factor_summary_v2(factor_id, col_name=col_name, **kwargs)
        res = {
            'papertrading_date': papertrading_date,
            'create_date': create_date,
            'dates': dates,
            'cum_pnls': cum_pnls,
            'summaries': summaries,
        }

        if is_my_factor and papertrading_date_index > 0:
            res['dates'] = dates[:papertrading_date_index + 1]
            res['cum_pnls'] = cum_pnls[:papertrading_date_index + 1]
            res['summaries'] = [
                s for s in summaries
                if (s.get('date_range', '') not in ('semi_os_date', 'os_date')) and (not (s['end_date'] >= '20180101'))]
        return res

    @staticmethod
    def get_factor_summary_v2(factor_id, col_name='', **kwargs):
        """
        get factor summary from /data/ev_alpha_evalue/new_factor_evalue/factor_id/summary.csv

        :referred_function `strategy_upload.service.stock_factor.models.StockFactorStrategy.get_factor_pnl_indicator_v2`
        """
        output_path = '/data/ev_alpha_evalue/new_factor_evalue'
        summary_file = os.path.join(output_path, str(factor_id), 'summary.csv')
        res = []
        cols = [
            'date_range', 'start_date', 'end_date', 'long', 'short', 'pnl',
            'ret', 'tvr', 'shrp', 'dd', 'win', 'bpmrgn', 'fitness', 'Coverage', 'posret',
            'negret', 'sharpe', 'ir', 'poscov', 'negcov', 'IC', 'inxret'
        ]
        try:
            df = pd.read_csv(summary_file)
            df = df[df["date_range"] != "is_date2"]
            df['end_date'] = df['end_date'].apply(lambda x: str(x))
            df['start_date'] = df['start_date'].apply(lambda x: str(x))
            for i, row in df.iterrows():
                if col_name and col_name != row['factor']:
                    continue
                d = {}
                for c in cols:
                    d[c] = row[c]
                res.append(d)
        except Exception as e:
            pass
        return res

    @staticmethod
    def get_factor_checkbias(factor_id, col_name='', **kwargs):
        output_path = '/data/ev_alpha_evalue/new_factor_evalue'
        res = {}
        try:
            checkbias_file = os.path.join(output_path, str(factor_id), 'checkbias.csv')
            df = pd.read_csv(checkbias_file)
            for i, row in df.iterrows():
                res[row['factor']] = row['check_bias']
        except Exception as e:
            pass
        return res

    @staticmethod
    def get_factor_dump_trun_flag(factor_id, **kwargs):
        output_path = kwargs.get('output_path', '/data/ev_alpha_evalue/new_factor_evalue')
        columns = kwargs.get('columns', [])
        if not columns:
            columns = StockFactorStrategyColumns.get_factor_columns(factor_id)

        dump_trun_flag = {
            c: {
                'dumpflag': True,
                'truncateflag': True,
            } for c in columns
        }

        try:
            for i, row in pd.read_csv(os.path.join(output_path, str(factor_id), 'dump_truncate.csv')).iterrows():
                d_flag = bool(int(row['dumpflag']))
                t_flag = (not bool(int(row['truncateflag'])))
                dump_trun_flag[row['factor']] = {
                    'dumpflag': d_flag,
                    'truncateflag': t_flag,
                }
        except Exception as e:
            pass

        return dump_trun_flag

    @staticmethod
    def get_factor_evaluation_judge_v2(factor_id, **kwargs):
        """
        :referred_handler `strategy_upload.service.stock_factor.handlers.StockFactorPerformanceJudgeDetailHandler`
        """
        from service.back_test.models import Strategy
        output_path = kwargs.get('output_path', '/data/ev_alpha_evalue/new_factor_evalue')
        columns = StockFactorStrategyColumns.get_factor_columns(factor_id)
        inds = [
            'Correlation', 'Fitness', 'ISLADDAR', 'RankTest', 'SubTest', 'CheckBias'
        ]
        inds_status = ['ind_%s' % ind for ind in inds] + ['final_s']

        judge_res = {c: {ind: 0 for ind in inds} for c in columns}
        judge_ind = {c: {ind: False for ind in inds_status} for c in columns}
        dump_trun_flag = StockFactorStrategy.get_factor_dump_trun_flag(factor_id, columns=columns)
        check_bias_res = StockFactorStrategy.get_factor_checkbias(factor_id)

        try:
            check_file_path1 = os.path.join(output_path, str(factor_id), 'check.csv')
            check_file_path2 = os.path.join(output_path, str(factor_id), 'check22.csv')
            check_file_path = check_file_path1
            if os.path.exists(check_file_path2):
                check_file_path = check_file_path2
            df = pd.read_csv(check_file_path)
            df['RankTest'] = df['RankTest'].apply(lambda x: round(x, 3))
            df['Correlation'] = df['Correlation'].apply(lambda x: round(x, 3))
            df['SubTest'] = df.apply(lambda x: '%s / %s' % (round(x['Sub2000Val'], 2), round(x['Sub1000Val'], 2)),
                                     axis=1)
            for i, row in df.iterrows():
                if row['factor'] not in judge_res:
                    continue
                for ind in inds:
                    judge_res[row['factor']][ind] = row[ind]
                for ind in inds_status:
                    judge_ind[row['factor']][ind] = row[ind]
        except Exception as e:
            sentry.captureException()

        sc = session()
        s = sc.query(Strategy).filter(
            Strategy.id == factor_id
        ).first()
        id_no = s.id_no
        sc.close()
        total = len(columns)
        success = 0
        passed = 0
        rows = []
        for i, c in enumerate(columns):
            d = {}
            d['id'] = '%s_A%s' % (id_no, str(i + 1).zfill(3))
            d['factor_id'] = factor_id
            d['col'] = c
            d['col_index'] = i
            d.update(judge_res[c])
            d.update(judge_ind[c])
            d['CheckBias'] = check_bias_res.get(c, None)
            d['ind_CheckBias'] = d['CheckBias']
            if d['final_s']:
                success += 1
            if d['ind_ISLADDAR'] and d['ind_Fitness'] and d['ind_RankTest'] \
                    and d['ind_SubTest'] and dump_trun_flag[c]['dumpflag'] and dump_trun_flag[c]['truncateflag']:
                passed += 1
            d['dumpflag'] = dump_trun_flag[c]['dumpflag']
            d['truncateflag'] = dump_trun_flag[c]['truncateflag']
            rows.append(d)
        data = {
            'total': total,
            'success': success,
            'passed': passed,
            'rows': rows
        }
        return data


class StockFactorStrategyColumns(ModelBase):
    __tablename__ = 'stock_factor_strategy_columns'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    factor_id = Column(INTEGER, nullable=False, index=True)
    factor_column = Column(VARCHAR(40), nullable=False)

    @staticmethod
    def get_factor_columns(factor_id):
        """
        query factor name from factor_id
        """
        sc = session()
        columns = sc.query(StockFactorStrategyColumns.factor_column).filter(
            StockFactorStrategyColumns.factor_id == factor_id
        ).order_by(
            StockFactorStrategyColumns.id
        )
        columns = [c[0] for c in columns]
        sc.close()
        return columns

    @staticmethod
    def get_judge_passed_columns(factor_id):
        """
        :referred_handler `strategy_upload.service.stock_factor.handlers.StockFactorPoolHandler`
        """
        if factor_id in consts.factor_pool:
            return StockFactorStrategyColumns.get_factor_columns(factor_id)
        pass_columns = []
        try:
            base_path = '/data/ev_alpha_evalue/factor_evalue_judge'
            csv_file1 = os.path.join(base_path, '{f_id}_top2000_v1.csv'.format(f_id=factor_id))
            if os.path.exists(csv_file1):
                df1 = pd.read_csv(csv_file1)
                df1['col'] = df1['Unnamed: 0']
                for i, r in df1.iterrows():
                    if r['final']:
                        pass_columns.append(r['col'])
        except Exception as e:
            sentry.captureException()

        return pass_columns

    @staticmethod
    def get_judge_passed_columns2(factor_id):
        """
        :referred_handler `strategy_upload.service.stock_factor.handlers.StockFactorPoolHandler`
        """
        sc = session()
        f = sc.query(StockFactorStrategy).filter(
            StockFactorStrategy.strategy_id == factor_id,
            StockFactorStrategy.status2 == StockFactorStrategyConstant.Status2.Pool.value
        ).first()
        if not f:
            return []
        pass_columns = []
        try:
            base_path = CommonPath.new_factor_evaluation
            csv_file1 = os.path.join(base_path, str(factor_id), 'check.csv')
            csv_file2 = os.path.join(base_path, str(factor_id), 'check22.csv')
            if os.path.exists(csv_file2):
                csv_file1 = csv_file2
            df = pd.read_csv(csv_file1)
            for _, row in df.iterrows():
                if row['final_s']:
                    pass_columns.append(row['factor'])
        except Exception as e:
            sentry.captureException()
        sc.close()
        return pass_columns

    @staticmethod
    def set_factor_columns(factor_id, columns=None, **kwargs):
        if not columns:
            return True
        old_columns = StockFactorStrategyColumns.get_factor_columns(factor_id)
        if columns != old_columns:
            sc = session()
            sc.query(StockFactorStrategyColumns).filter(
                StockFactorStrategyColumns.factor_id == factor_id
            ).delete()
            for c in columns:
                f_c = StockFactorStrategyColumns(
                    factor_id=factor_id,
                    factor_column=c
                )
                sc.add(f_c)
            sc.commit()
            sc.close()
            if old_columns:
                message = """factor(id=%s) columns update, new_columns=%s""" % (factor_id, columns)
                send_email('factor columns update', message, CompanyEmailGroup.quant_dev)
            return True
        return True


class StockFactorEstimateStrategy(ModelBase):
    __tablename__ = 'stock_factor_estimate_strategy_cache'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    strategy_id = Column(INTEGER, nullable=False, unique=True)

    @staticmethod
    def get_estimate_strategy():
        from service.back_test.models import Strategy
        sc = session()
        s_ids = [s[0] for s in sc.query(StockFactorEstimateStrategy.strategy_id)]
        strategies = sc.query(
            Strategy.id.label('id'),
            Strategy.name.label('name'),
            Strategy.id_no.label('id_no'),
        ).filter(
            Strategy.id.in_(s_ids),
            Strategy.is_test == 0,
            Strategy.is_delete == 0,
        )
        data = [
            {
                'id': s.id,
                'name': s.name,
                'id_no': s.id_no,
            } for s in strategies
        ]
        sc.close()
        return data


class StockFactorEstimation(ModelBase):
    """
    this is old factor estimation model used for /api/v1/platform/stock_factor handler
    """
    __tablename__ = 'stock_factor_estimations'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    factor_id = Column(INTEGER, nullable=False, index=True)
    col = Column(VARCHAR(68), nullable=False)
    col_index = Column(INTEGER, nullable=False)
    estimate_strategy_id = Column(INTEGER, nullable=False)
    stock_pool = Column(VARCHAR(32), nullable=False)
    pnl_url = Column(VARCHAR(32), nullable=False)

    @staticmethod
    def get_factors_indicator(estimate_strategy_id, stock_pool, start_date, factor_type='DAY', **kwargs):

        if kwargs.get('factor_category') == 'TIME_SERIES':
            return StockFactorEstimation.get_time_series_factors_indicator(
                estimate_strategy_id, stock_pool, start_date, factor_type='DAY', **kwargs
            )

        from service.back_test.models import Strategy
        sc = session()
        start_date = parse(start_date).strftime('%Y%m01')
        factor_estimations = sc.query(
            StockFactorEstimation
        ).filter(
            StockFactorEstimation.estimate_strategy_id == estimate_strategy_id,
            StockFactorEstimation.stock_pool == stock_pool,
        )
        # assert where s_ids contains strategy id
        # if false,it will query all strategy which cause low load performce
        if kwargs.get('s_ids', []):
            factor_estimations = factor_estimations.filter(
                StockFactorEstimation.factor_id.in_(kwargs['s_ids'])
            )

        factor_estimation_map = {}
        s_ids = set()
        for f_es in factor_estimations:
            factor_estimation_map[f_es.id] = {
                'id': f_es.id,
                'strategy_id': f_es.factor_id,
                'name': f_es.col,
                'col_index': f_es.col_index + 1,
                'factor_id': '',
                'pnl_url': f_es.pnl_url,
            }
            s_ids.add(f_es.factor_id)

        factor_detail = {}

        if not kwargs.get('my_factor', False):
            factors = sc.query(
                StockFactorStrategy.strategy_id.label('factor_id')
            ).filter(
                StockFactorStrategy.strategy_id.in_(s_ids),
                StockFactorStrategy.is_delete == False,
                StockFactorStrategy.is_publish == True,
                StockFactorStrategy.status == 'Pool',
                StockFactorStrategy.factor_type == 'FACTOR_ALPHA',
                StockFactorStrategy.category == 'NORMAL',
            )
        else:
            factors = sc.query(
                StockFactorStrategy.strategy_id.label('factor_id')
            ).filter(
                StockFactorStrategy.strategy_id.in_(s_ids),
                StockFactorStrategy.is_delete == False,
                StockFactorStrategy.is_publish == True,
                StockFactorStrategy.factor_type == 'FACTOR_ALPHA',
                StockFactorStrategy.category == 'NORMAL',
                StockFactorStrategy.r_create_user_id == kwargs.get('current_user', {'id': 0})['id']
            )

        for f in factors:
            factor_detail[f.factor_id] = {
                'passed_columns': StockFactorStrategyColumns.get_judge_passed_columns(f.factor_id)
            }

        strategies = sc.query(
            Strategy.id.label('id'),
            Strategy.id_no.label('id_no'),
        ).filter(
            Strategy.id.in_(factor_detail.keys()),
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
        )

        strategy_detail = {}
        for s in strategies:
            strategy_detail[s.id] = {
                'id_no': s.id_no,
            }

        pass_factor_estimation_map = {}
        for k, v in factor_estimation_map.items():
            if v['name'] in factor_detail.get(v['strategy_id'], {}).get('passed_columns', []):
                pass_factor_estimation_map[k] = v

        indicators = sc.query(
            StockFactorEstimationIndicators
        ).filter(
            StockFactorEstimationIndicators.estimation_id.in_(pass_factor_estimation_map.keys()),
            StockFactorEstimationIndicators.start_date == start_date
        )

        data = []
        for ind in indicators:
            d = factor_estimation_map[ind.estimation_id]
            if d['strategy_id'] not in strategy_detail:
                continue
            d['sharpe'] = float(ind.sharp)
            d['annual_return'] = float(ind.annual_return)
            d['max_drawdown'] = float(ind.max_drawdown)
            d['ic'] = float(ind.ic)
            d['ir'] = float(ind.ir)
            d['cr'] = float(ind.cr)
            d['corr'] = float(ind.corr)
            d['ac'] = float(ind.ac)
            d['tr'] = float(ind.tr)
            d['fitness'] = float(ind.fitness)
            d['factor_id'] = '%s_A%s' % (strategy_detail[d['strategy_id']]['id_no'], str(d['col_index']).zfill(3))
            d['pnl_url'] = ind.pnl_url or ''
            d['daily_pnl_id'] = ind.id
            data.append(d)
        sc.close()
        return data

    @staticmethod
    def get_time_series_factors_indicator(estimate_strategy_id, stock_pool, start_date, factor_type='DAY', **kwargs):

        from service.back_test.models import Strategy

        home_path = '/home/rss/jupyter_userworkspace/453_stock_team/factor_metric'
        sc = session()
        files = sc.query(StockFactorEstimationTimeSeriesFilePath).filter(
            StockFactorEstimationTimeSeriesFilePath.estimate_strategy_id == estimate_strategy_id,
            StockFactorEstimationTimeSeriesFilePath.stock_pool == stock_pool
        )
        dfs = pd.DataFrame()
        s_ids = set()
        for f in files:
            try:
                csv_f = os.path.join(home_path, f.file_name, 'summary', 'all_feature_summary.csv')
                df = pd.read_csv(csv_f)
                df['strategy_id'] = f.strategy_id
                df['name'] = df['Unnamed: 0']
                df['corr'] = df['Non-nan Count']
                df['csv_file_name'] = f.id
                df = df.drop(columns=['Unnamed: 0', 'Non-nan Count'])
                dfs = dfs.append(df, ignore_index=True)
                s_ids.add(f.strategy_id)
            except Exception as e:
                sentry.captureException()

        strategies = sc.query(
            Strategy.id.label('id'),
            Strategy.id_no.label('id_no'),
        ).filter(
            Strategy.id.in_(s_ids)
        )

        strategy_detail = {}
        for s in strategies:
            strategy_detail[s.id] = {
                'id_no': s.id_no,
                'columns': StockFactorStrategyColumns.get_factor_columns(s.id)
            }
            strategy_detail[s.id]['columns_index'] = {
                c: i for i, c in enumerate(strategy_detail[s.id]['columns'], start=1)
            }
        sc.close()

        if dfs.empty:
            return {
                'columns': [],
                'values': [],
            }

        dfs['col_index'] = dfs.apply(lambda row: strategy_detail[row['strategy_id']]['columns_index'][row['name']],
                                     axis=1)
        dfs['factor_id'] = dfs.apply(
            lambda row: '%s_D%s' % (strategy_detail[row['strategy_id']]['id_no'], str(row['col_index']).zfill(3)),
            axis=1)
        dfs['id'] = dfs.apply(lambda row: '%s-%s-%s' % (row['strategy_id'], row['col_index'], row['csv_file_name']),
                              axis=1)
        return {
            'columns': dfs.columns.tolist(),
            'values': dfs.values.tolist(),
        }

    @staticmethod
    def get_factor_time_series_indicator_by_id(estimation_id, **kwargs):
        ids = estimation_id.split('-')
        s_id = int(ids[0])
        col_index = int(ids[1])
        file_id = int(ids[2])
        sc = session()
        home_path = '/home/rss/jupyter_userworkspace/453_stock_team/factor_metric'

        files = sc.query(StockFactorEstimationTimeSeriesFilePath).filter(
            StockFactorEstimationTimeSeriesFilePath.id == file_id,
        ).first()
        if not files:
            return {
                'columns': [],
                'values': [],
            }
        csv_file_path = files.file_name
        column = kwargs.get('column', 'IC_1_min')
        if column in ('IC_1_min', 'IR_1_min'):
            path_suffiex = 'l_wth_tsr__60000'
            file_name = 'corr.csv'
        elif column in ('IC_3_min', 'IR_3_min',):
            path_suffiex = 'l_wth_tsr__180000'
            file_name = 'corr.csv'
        elif column in ('IC_5_min', 'IR_5_min',):
            path_suffiex = 'l_wth_tsr__300000'
            file_name = 'corr.csv'
        elif column in ('IC_10_min', 'IR_10_min',):
            path_suffiex = 'l_wth_tsr__600000'
            file_name = 'corr.csv'
        elif column in ('IC_15_min', 'IR_15_min',):
            path_suffiex = 'l_wth_tsr__900000'
            file_name = 'corr.csv'
        elif column in ('IC_20_min', 'IR_20_min',):
            path_suffiex = 'l_wth_tsr__1200000'
            file_name = 'corr.csv'
        elif column in ('IC_30_min', 'IR_30_min',):
            path_suffiex = 'l_wth_tsr__1800000'
            file_name = 'corr.csv'
        elif column in ('corr',):
            path_suffiex = 'l_wth_tsr__60000'
            file_name = 'valid_count.csv'
        else:
            path_suffiex = 'l_wth_tsr__60000'
            file_name = 'corr.csv'

        factor_columns = StockFactorStrategyColumns.get_factor_columns(s_id)
        factor_col = factor_columns[col_index - 1]

        csv_file_name = os.path.join(
            home_path, csv_file_path, 'summary', '%s-%s' % (factor_col, path_suffiex), file_name
        )
        try:
            df = pd.read_csv(csv_file_name)
            df.rename(columns={'Unnamed: 0': 'Symbol'}, inplace=True)
            columns = df.columns.tolist()
            values = df.values.tolist()
        except Exception as e:
            sentry.captureException()
            sc.close()
            return {
                'columns': [],
                'values': [],
            }
        return {
            'columns': columns,
            'values': values,
        }

    @staticmethod
    def get_factor_daily_indicator_by_estimation_id(estimation_id, **kwargs):
        sc = session()
        rows = sc.query(
            StockFactorEstimationDailyIndicators
        ).filter(
            StockFactorEstimationDailyIndicators.estimation_id == estimation_id
        )
        data = {
            'columns': ['trading_date', 'ic', 'cr'],
            'values': [],
        }
        for r in rows:
            data['values'].append([
                r.trading_date.strftime('%Y-%m-%d'),
                round(float(r.ic), 4),
                round(float(r.cr), 4),
            ])
        return data

    @staticmethod
    def generate_factor_estimations(factor_id):
        columns = StockFactorStrategyColumns.get_factor_columns(factor_id)
        column_detail = {c: i for i, c in enumerate(columns)}
        # estimate_strategy_ids = [s['id'] for s in StockFactorEstimateStrategy.get_estimate_strategy()]
        estimate_strategy_ids = [210307]
        stock_pool = ['ZZ500', 'TOP2000']
        sc = session()
        e = sc.query(StockFactorEstimation).filter(StockFactorEstimation.factor_id == factor_id).first()
        if e:
            sc.close()
            return False

        for c, es_id, sp in itertools.product(columns, estimate_strategy_ids, stock_pool):
            e = StockFactorEstimation(
                factor_id=factor_id,
                col=c,
                col_index=column_detail[c],
                estimate_strategy_id=es_id,
                stock_pool=sp,
                pnl_url=''
            )
            sc.add(e)
        sc.commit()
        sc.close()
        return True

    @staticmethod
    def generate_daily_indicator(factor_id, pool_range, predict_cycle='v1', **kwargs):
        from my_factor.factor import factor_evalue_daily
        sc = session()

        estimations = sc.query(
            StockFactorEstimation
        ).filter(
            StockFactorEstimation.factor_id == factor_id,
            StockFactorEstimation.stock_pool == pool_range,
        )

        estimation_detail = {}
        col_detail = {}
        for es in estimations:
            estimation_detail[es.id] = {
                'col': es.col,
                'col_index': es.col_index,
            }
            col_detail[es.col] = {
                'id': es.id,
            }

        if pool_range.lower() == 'zz500':
            pool_range = '500expe'

        cfg = {
            'basic_data_path': '/home/rss/jupyter_userworkspace/453_stock_team/app_working_dir/framework_sync/',
            'evalue_output_path': '/data/ev_alpha_evalue/',
            'strategy_id': factor_id,
            'pool_range': pool_range.lower(),
            'predict_cycle': predict_cycle,
        }

        last_date = sc.query(func.max(StockFactorEstimationDailyIndicators.trading_date)).filter(
            StockFactorEstimationDailyIndicators.estimation_id.in_(estimation_detail.keys()),
        ).first()

        last_date = last_date and last_date[0] and last_date[0].strftime('%Y%m%d') or '20140102'

        kdb = KdbQuery()
        trading_dates = kdb.get_trading_days(last_date,
                                             (datetime.datetime.now() - datetime.timedelta(days=1)).strftime('%Y%m%d'))
        for d in trading_dates:
            if d == last_date:
                continue
            cfg['date'] = d
            try:
                factor_evalue_daily(cfg, **kwargs)
                csv_file = os.path.join(
                    cfg['evalue_output_path'],
                    'factor_evalue_daily/{strategy_id}_{pool_range}_{predict_cycle}/{date}.csv'.format(**cfg)
                )
                df = pd.read_csv(csv_file)
                df['col'] = df['Unnamed: 0']
                for i, r in df.iterrows():
                    if r['col'] not in col_detail:
                        continue
                    es_id = col_detail[r['col']]['id']
                    ic = r['ic'] if not math.isnan(r['ic']) else 0
                    cr = r['cr'] if not math.isnan(r['cr']) else 0
                    ret = r['ret'] if not math.isnan(r['ret']) else 0
                    ac = r['ac'] if not math.isnan(r['ac']) else 0
                    tr = r['tr'] if not math.isnan(r['tr']) else 0
                    es_d = StockFactorEstimationDailyIndicators(
                        estimation_id=es_id,
                        trading_date=d,
                        ic=ic,
                        cr=cr,
                        ret=ret,
                        ac=ac,
                        tr=tr,
                    )
                    sc.add(es_d)
                sc.commit()
            except Exception as e:
                sentry.captureException()
                continue
        sc.close()
        return True

    @staticmethod
    def generate_date_range_indicator(factor_id, pool_range, predict_cycle='v1', **kwargs):
        from my_factor.factor import factor_evalue_date_range
        sc = session()

        estimations = sc.query(
            StockFactorEstimation
        ).filter(
            StockFactorEstimation.factor_id == factor_id,
            StockFactorEstimation.stock_pool == pool_range,
        )

        estimation_detail = {}
        col_detail = {}
        for es in estimations:
            estimation_detail[es.id] = {
                'col': es.col,
                'col_index': es.col_index,
            }
            col_detail[es.col] = {
                'id': es.id,
            }

        if pool_range.lower() == 'zz500':
            pool_range = '500expe'

        sc.query(
            StockFactorEstimationIndicators
        ).filter(
            StockFactorEstimationIndicators.estimation_id.in_(estimation_detail.keys())
        ).delete(synchronize_session=False)

        kdb = KdbQuery()
        trading_dates = kdb.get_trading_days('20140101', datetime.datetime.now().strftime('%Y%m%d'))
        month_range = set()
        for d in trading_dates:
            month_range.add(d[:6] + '01')
        endT = parse(
            kwargs.get('endT', (datetime.datetime.now() - datetime.timedelta(days=3)).strftime('%Y%m%d'))).strftime(
            '%Y%m%d')
        for d in sorted(month_range):
            cfg = {
                'begT': d,
                'strategy_id': factor_id,
                'pool_range': pool_range.lower(),
                'predict_cycle': predict_cycle,
                'endT': endT,
                'evalue_output_path': '/data/ev_alpha_evalue/',
            }
            try:
                factor_evalue_date_range(cfg)
                cfg['_begT'] = cfg['_begT'].strftime('%Y%m%d')
                cfg['_endT'] = cfg['_endT'].strftime('%Y%m%d')
                csv_file = os.path.join(
                    cfg['evalue_output_path'],
                    'factor_evalue_cycle',
                    '{strategy_id}_{pool_range}_{predict_cycle}/{_begT}_{_endT}_indicator.csv'.format(**cfg)
                )
                df = pd.read_csv(csv_file)
                df['col'] = df['Unnamed: 0']
                # ic,ir,cr,ret,mdd
                pnl_file_path = os.path.join(
                    cfg['evalue_output_path'],
                    'factor_evalue_cycle',
                    '{strategy_id}_{pool_range}_{predict_cycle}/{_begT}_{_endT}_pnl.csv'.format(**cfg)
                )

                pnl_graphs = StockFactorEstimation.generate_factors_pnl_graph(factor_id, pool_range.lower(),
                                                                              pnl_file_path)

                for i, r in df.iterrows():
                    if r['col'] not in col_detail:
                        continue
                    es_id = col_detail[r['col']]['id']
                    ic = r['ic'] if not math.isnan(r['ic']) else 0
                    ir = r['ir'] if not math.isnan(r['ir']) else 0
                    cr = r['cr'] if not math.isnan(r['cr']) else 0
                    ret = r['ret'] if not math.isnan(r['ret']) else 0
                    mdd = r['mdd'] if not math.isnan(r['mdd']) else 0
                    sr = r['sr'] if not math.isnan(r['sr']) else 0
                    ac = r['ac'] if not math.isnan(r['ac']) else 0
                    tr = r['tr'] if not math.isnan(r['tr']) else 0
                    fitness = r['fitness'] if not math.isnan(r['fitness']) else 0
                    es_d = StockFactorEstimationIndicators(
                        estimation_id=es_id,
                        start_date=d,
                        sharp=sr,
                        annual_return=ret,
                        max_drawdown=mdd,
                        ic=ic,
                        ir=ir,
                        cr=cr,
                        ac=ac,
                        tr=tr,
                        fitness=fitness,
                        file_path=pnl_file_path,
                        pnl_url=pnl_graphs.get(r['col'], '')
                    )
                    sc.add(es_d)
                sc.commit()
            except Exception as e:
                sentry.captureException()
                continue
        sc.close()
        return True

    @staticmethod
    def get_factor_daily_pnl_by_id(ind_id):
        from service.back_test.models import Strategy
        sc = session()
        ind = sc.query(StockFactorEstimationIndicators).filter(
            StockFactorEstimationIndicators.id == ind_id
        ).first()
        if not ind:
            return {}
        estimation = sc.query(StockFactorEstimation).filter(
            StockFactorEstimation.id == ind.estimation_id
        ).first()
        col = estimation.col
        col_index = estimation.col_index
        stock_pool = estimation.stock_pool
        factor = sc.query(Strategy).filter(
            Strategy.id == estimation.factor_id,
        ).first()
        factor_id = '%s_A%s' % (factor.id_no, str(col_index + 1).zfill(3))
        data = {
            'factor_id': factor_id,
            'name': col,
            'stock_pool': stock_pool,
            'trading_date': [],
            'ret': [],
            'pnl': []
        }
        pnl_file = ind.file_path
        sc.close()

        pnl_df = pd.DataFrame()

        try:
            pnl_df = pd.read_csv(pnl_file)
            pnl_df.rename(columns={'Unnamed: 0': 'col'}, inplace=True)
        except Exception as e:
            sentry.captureException()

        if pnl_df.empty:
            return data
        columns = pnl_df.columns.tolist()
        x_arr = columns[1:]
        if not x_arr:
            return {}

        def change_date_format(x):
            x = str(x)
            return '%s-%s-%s' % (x[:4], x[4:6], x[6:])

        data['trading_date'] = [change_date_format(x) for x in x_arr]
        for i, row in pnl_df.iterrows():
            if row['col'] == col:
                data['pnl'] = [round(r, 4) for r in row.tolist()[1:]]
                break

        return data

    @staticmethod
    def generate_factors_pnl_graph(strategy_id, pool_range, pnl_file, **kwargs):
        pnl_df = pd.DataFrame()
        try:
            pnl_df = pd.read_csv(pnl_file)
            pnl_df.rename(columns={'Unnamed: 0': 'col'}, inplace=True)
        except Exception as e:
            sentry.captureException()
        if pnl_df.empty:
            return {}

        graphs = {}
        columns = pnl_df.columns.tolist()
        x_arr = columns[1:]
        if not x_arr:
            return {}
        # x_arr = [(parse(x_arr[0]) - datetime.timedelta(days=1)).strftime('%Y-%m-%d')] + x_arr
        for i, row in pnl_df.iterrows():
            col = row['col']
            pnl_file_name = '%s.png' % uuid.uuid4().hex
            y_arr = row.tolist()[1:]
            try:
                StockFactorEstimation.generate_graph(x_arr, y_arr, pnl_file_name)
                graphs[col] = '/media/stock_factor_graph/%s' % pnl_file_name
            except Exception as e:
                sentry.captureException()

        return graphs

    @staticmethod
    def generate_graph(x_data, y_data, filename):
        filename = os.path.join(config.media, 'stock_factor_graph', filename)
        fig = plt.figure(figsize=(1.2, 0.6), dpi=100)
        plt.plot(x_data, y_data, color='#4ad3e8', linewidth=1)
        plt.axis('off')
        plt.savefig(filename, transparent=True)
        plt.close(fig)
        plt.close('all')
        return True


class StockFactorEstimationIndicators(ModelBase):
    __tablename__ = 'stock_factor_estimation_indicator'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    estimation_id = Column(INTEGER, nullable=False, index=True)
    start_date = Column(DATE, nullable=False, default='20000101')

    sharp = Column(DOUBLE, nullable=False, default=0)
    annual_return = Column(DOUBLE, nullable=False, default=0)
    max_drawdown = Column(DOUBLE, nullable=False, default=0)

    ic = Column(DOUBLE, nullable=False, default=0)
    ir = Column(DOUBLE, nullable=False, default=0)
    cr = Column(DOUBLE, nullable=False, default=0)
    corr = Column(DOUBLE, nullable=False, default=0)
    ac = Column(DOUBLE, nullable=False, default=0)
    tr = Column(DOUBLE, nullable=False, default=0)
    # ic,ir,cr,ret,mdd,sr,ac,tr
    pnl_url = Column(VARCHAR(128), nullable=True)
    file_path = Column(VARCHAR(256), nullable=True)

    fitness = Column(DOUBLE, nullable=False, default=0)


class StockFactorEstimationDailyIndicators(ModelBase):
    __tablename__ = 'stock_factor_estimation_daily_indicator'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    estimation_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False)
    ic = Column(DOUBLE, nullable=False, default=0)
    cr = Column(DOUBLE, nullable=False, default=0)
    ret = Column(DOUBLE, nullable=False, default=0)
    ac = Column(DOUBLE, nullable=False, default=0)
    tr = Column(DOUBLE, nullable=False, default=0)


class StockFactorEstimationTimeSeriesFilePath(ModelBase):
    __tablename__ = 'stock_factor_estimation_time_series_file_path'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(INTEGER, nullable=False, index=True, unique=True)
    estimate_strategy_id = Column(INTEGER, nullable=False)
    stock_pool = Column(VARCHAR(32), nullable=False)
    start_date = Column(DATE, nullable=False, default='20000101')
    file_name = Column(VARCHAR(128), nullable=False)


class T0Subscriber(ModelBase):
    __tablename__ = 't0_subscriber'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    t0_vs_id = Column(INTEGER, nullable=False, index=True)
    alpha_vs_id = Column(INTEGER, nullable=False)
    share_resp = Column(BOOLEAN, nullable=False, default=False)  # 是否共享回报
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=False)
    r_update_user_id = Column(INTEGER, nullable=True)


class T0SubscriberHistory(ModelBase):
    __tablename__ = 't0_subscriber_history'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    t0_vs_id = Column(INTEGER, nullable=False, index=True)
    alpha_vs_id = Column(INTEGER, nullable=False)
    trading_date = Column(DATE, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=False)
    r_update_user_id = Column(INTEGER, nullable=True)


class StockFactorVersion(ModelBase):
    __tablename__ = 'stock_factor_version'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    origin_s_id = Column(INTEGER, nullable=False, index=True)
    newversion_s_id = Column(INTEGER, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=True)


class FactorCombinationRelation(ModelBase):
    __tablename__ = 'factor_combination_relation'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    main_factor_id = Column(INTEGER, nullable=True, index=True)
    sub_factor_id = Column(INTEGER, nullable=True, unique=True)

    @staticmethod
    def migrate():
        migrate(base_model=ModelBase, engine=engine, model=FactorCombinationRelation)

    @staticmethod
    def add_relations(main_factor_id, sub_factor_ids):
        sc = session()
        for factor_id in sub_factor_ids:
            record = FactorCombinationRelation(
                main_factor_id=main_factor_id,
                sub_factor_id=factor_id
            )
            sc.add(record)
        try:
            sc.commit()
        except Exception as e:
            sc.rollback()
            sc.close()
            return False
        sc.close()
        return True

    @staticmethod
    def is_factor_id_used(sub_factor_ids):
        with session_context() as sc:
            records = sc.query(FactorCombinationRelation).filter(
                FactorCombinationRelation.sub_factor_id.in_(sub_factor_ids)
            ).all()
            used = len(records) != 0
        return used


if __name__ == '__main__':
    pass

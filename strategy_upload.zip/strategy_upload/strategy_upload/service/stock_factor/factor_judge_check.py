# -*-coding:utf-8-*-

import os
import pandas as pd
from service.back_test.models import Strategy
from service.stock_factor.models import StockFactorStrategy, StockFactorStrategyColumns
from constant import StrategyConstant, CommonPath

from db import session


def get_factor_is_date_fitness22(factor_id):
    try:
        res = {}
        df = StockFactorStrategy.get_factor_simu_summary(factor_id)
        for i, row in df.iterrows():
            if row['date_range'] == 'is_date2':
                res[row['factor']] = row['fitness']
        return res
    except Exception as e:
        pass
    return {}


def get_factor_algorithm(factor_id):
    sc = session()
    s = sc.query(Strategy).filter(
        Strategy.id == factor_id
    ).first()
    if not s:
        sc.close()
        return ''
    algorithm = s.detail.get('algorithm', '')
    sc.close()
    return algorithm


def factor_judge_check_result_v22(factor_id, **kwargs):
    from my_factor.factor import correlation
    # check path
    output_path = kwargs.get('output_path', CommonPath.new_factor_evaluation)
    check_file_path = os.path.join(output_path, str(factor_id), 'check.csv')
    check2_file_path = os.path.join(output_path, str(factor_id), 'check22.csv')
    if not os.path.exists(check_file_path):
        return True

    check_df = pd.read_csv(check_file_path)
    check_df = check_df.drop(columns=['Unnamed: 0'])
    check_df = check_df.set_index(['factor'])
    check_df['tcorr'] = 0

    version_check, old_factor_id = StockFactorStrategy.check_version_upgrade(factor_id)
    if not version_check:
        check_df['ind_Fitness'] = False
        check_df['final_s'] = False
        check_df.to_csv(check2_file_path)
        return check_df

    # decide cal corr with which algorithm type
    algorithm = get_factor_algorithm(factor_id)
    if algorithm in StrategyConstant.DetailAlgorithm.manual_group():
        # manual group algorithm only calculate correlation with member in manual group
        factor_type_filters = StrategyConstant.DetailAlgorithm.manual_group()
    elif algorithm in StrategyConstant.DetailAlgorithm.zz500_group():
        # zz500 only calculate correlation with member in zz500 group
        factor_type_filters = StrategyConstant.DetailAlgorithm.zz500_group()
    elif algorithm == StrategyConstant.DetailAlgorithm.FactorCombination.value:
        # factor combination do not calculate correlation
        factor_type_filters = []
    else:
        # all other algorithm calculate correlation with all factor
        factor_type_filters = StrategyConstant.DetailAlgorithm.all()

    check_df2 = check_df.sort_values(['Fitness'], ascending=False)
    factor_pool = {
        _f_id: _f_factors
        for _f_id, _f_factors in StockFactorStrategy.get_factor_pool2(factor_type_filters=factor_type_filters).items()
        if (_f_id < factor_id) and (_f_id != old_factor_id)
    }

    corr_csv_file = os.path.join(output_path, str(factor_id), 'corrrlation22.csv')
    corr = correlation(factor_id, factor_pool, corr_csv_file=corr_csv_file)
    pass_cols = []

    factor_pool_fitness = {
        f_id: get_factor_is_date_fitness22(f_id)
        for f_id in factor_pool.keys()
    }
    factor_pool_fitness[factor_id] = get_factor_is_date_fitness22(factor_id)

    dump_trun_flag = StockFactorStrategy.get_factor_dump_trun_flag(factor_id)

    for f, row in check_df2.iterrows():
        if not (row['ind_ISLADDAR'] and row['ind_Fitness'] and row['ind_RankTest'] and row['ind_SubTest']):
            continue
        max_corr = 0
        f_corr_detail = corr['detail_corr'][f]
        max_corr_keys = {
            '7': [],
        }
        tcorr = 0
        for k, v in f_corr_detail.items():
            if (k[0] != factor_id) or (k[0] == factor_id and k[1] in pass_cols):
                if v >= max_corr:
                    max_corr = v
                if 0.7 < v:
                    max_corr_keys['7'].append(k)
                if v > 0.25:
                    tcorr += v
        check_df.loc[f, 'Correlation'] = max_corr
        check_df.loc[f, 'tcorr'] = tcorr
        ind_Correlation = False
        if max_corr <= 0.7:
            ind_Correlation = True
        else:
            fitness_keys = []

            if 0.7 < max_corr:
                fitness_keys = max_corr_keys['7']

            max_corr_fitness = -999999
            for k in fitness_keys:
                k_fitness = factor_pool_fitness[k[0]][k[1]]
                if k_fitness > max_corr_fitness:
                    max_corr_fitness = k_fitness

            if max_corr_fitness <= -99999:
                max_corr_fitness = 999999

            row_fitness = factor_pool_fitness[factor_id][f]

            if (0.7 < max_corr) and row_fitness >= (1.1 * max_corr_fitness):
                ind_Correlation = True

        check_df.loc[f, 'ind_Correlation'] = ind_Correlation
        f_d_flag = dump_trun_flag.get(f, {}).get('dumpflag', True)
        f_t_flag = dump_trun_flag.get(f, {}).get('truncateflag', True)
        check_df.loc[f, 'final_s'] = (ind_Correlation and f_d_flag and f_t_flag)

        if check_df.loc[f]['final_s']:
            pass_cols.append(f)
    columns = StockFactorStrategyColumns.get_factor_columns(factor_id)
    if columns:
        pass_rate = len(pass_cols) / len(columns)
        pass_rate_threshold = 0.5
        if factor_id <= 215216:
            pass_rate_threshold = 0.0001
        if pass_rate >= pass_rate_threshold:
            StockFactorStrategy.set_factor_pool_passed(factor_id)
    check_df.to_csv(check2_file_path)
    return check_df

# encodin: utf-8
# cython: language_level=3
import json
import sys
import shutil
import pandas as pd
import numpy as np
import datetime
import os
import requests
import time
from my.data import basic_func

def get_datelist(begT,endT,dback=0,dnext=0):
    sqlstr = "select date:TRADE_DT from Calendar where EXCHANGE=`SSE"
    database = 'FuturesBasicInfo'
    data = basic_func.get_kdb(sqlstr, database)

    beg_index = data[data['date']>=qdate(begT,False)].index[0]-dback
    end_index = data[data['date']<=qdate(endT,False)].index[-1]+dnext
    data = data.loc[beg_index:end_index, :].reset_index(drop=True)
    return data


def get_stocklist(endT):
    sqlstr = '`code xasc select code:SYMBOL,ipodate:S_INFO_LISTDATE from AShareDescription where S_INFO_LISTDATE <= ' + qdate(endT) + ' ,( (S_INFO_DELISTDATE > ' + qdate(endT) + ') or (S_INFO_DELISTDATE = 0Nd) ) '
    database = 'EquityFactor'
    data = basic_func.get_kdb(sqlstr, database)
    if not data.empty: data.loc[:,'code'] = data.loc[:,'code'].apply(lambda x:x.decode()).tolist()
    return data


def qdate(date, is_str=True, sep='.'):
    date = datetime.datetime.strptime(str(date), "%Y%m%d")
    if is_str: date = date.strftime("%Y" + sep + "%m" + sep + "%d")
    return date


def get_corr(DataPdX, DataPdY):
    DataNpXCopy = DataPdX.values.copy()
    DataNpYCopy = DataPdY.values.copy()

    indexlabel = DataPdX.columns
    columnslabel = DataPdY.columns

    num_x = len(indexlabel)
    num_y = len(columnslabel)
    result_np = np.zeros([num_x, num_y])
    for col_y_idx in range(num_y):
        DataNpY_col = DataNpYCopy[:, col_y_idx]

        for col_x_idx in range(num_x):
            DataNpX_col = DataNpXCopy[:, col_x_idx]
            result_np[col_x_idx, col_y_idx] = np.corrcoef(DataNpX_col, DataNpY_col)[0, 1]

    result_pd = pd.DataFrame(result_np, index=indexlabel, columns=columnslabel)
    return result_pd


#DataPdX, DataPdY = factor_icdaily, factor_pool_icdaily
def get_factor_correlation(DataPdX, DataPdY):

    indexlabel = DataPdX.columns
    num = len(indexlabel)
    corr_list = []
    for col_idx in range(num):
        DataPdX_sub = DataPdX.iloc[:,[col_idx]]
        corr = get_corr(DataPdX_sub, DataPdY)
        corr_list.append(corr.T.abs().quantile(0.9))
    corr_pd = pd.concat(corr_list, axis=0).to_frame('corr')
    return corr_pd


def get_judge_result(indicator, range):
    result = pd.Series(False, index=indicator.index)
    if range[0] is None:
        result = indicator <= range[1]
    elif range[1] is None:
        result = indicator >= range[0]
    elif range[1] >= range[0]:
        result = (indicator >= range[0]) & (indicator <= range[1])
    elif range[1] < range[0]:
        result = (indicator <= range[0]) | (indicator >= range[1])

    return result


def factor_evalue_judge(cfg):

    path = cfg['basic_data_path']

    datelist = get_datelist(cfg['begT'], cfg['endT'], 0, 0)

    begT = datelist.date.iloc[0]
    endT = datelist.date.iloc[-1]

    strategy_name = '{}_{}_{}'.format(cfg['strategy_id'], cfg['pool_range'], cfg['predict_cycle'])

    work_path = '{}factor_evalue_judge/'.format(path)
    if not os.path.exists(work_path): os.makedirs(work_path)
    output_path = '{}{}.csv'.format(work_path, strategy_name)
    indicator_judge_csv_file = '{}{}_ind_judge.csv'.format(work_path, strategy_name)

    factor_icdaily_path = '{}factor_evalue_cycle/{}/{}_{}_icdaily.csv'.format(path, strategy_name, begT.strftime("%Y%m%d"),endT.strftime("%Y%m%d"))
    factor_icdaily = pd.read_csv(factor_icdaily_path, index_col=0)
    factor_icdaily = factor_icdaily.T
    factor_indicator_path = '{}factor_evalue_cycle/{}/{}_{}_indicator.csv'.format(path, strategy_name, begT.strftime("%Y%m%d"),endT.strftime("%Y%m%d"))
    factor_indicator = pd.read_csv(factor_indicator_path, index_col=0)

    factor_pool_icdaily = []
    for fid in cfg['fidpool']:
        fid_name = '{}_{}_{}'.format(fid, cfg['pool_range'], cfg['predict_cycle'])
        fid_icdaily_path = '{}factor_evalue_cycle/{}/{}_{}_icdaily.csv'.format(path, fid_name, begT.strftime("%Y%m%d"), endT.strftime("%Y%m%d"))
        factor_pool_icdaily.append(pd.read_csv(fid_icdaily_path, index_col=0))
    factor_pool_icdaily = pd.concat(factor_pool_icdaily, axis=0)
    factor_pool_icdaily = factor_pool_icdaily.T

    factor_corr = get_factor_correlation(factor_icdaily, factor_pool_icdaily)
    factor_indicator = pd.concat([factor_indicator, factor_corr], axis=1)

    indicator_judge = []
    # judge = 'corr'
    for judge in cfg['judge_threshold']:
        indicator = factor_indicator[judge]
        range = cfg['judge_threshold'][judge]
        indicator_judge.append(get_judge_result(indicator, range))
    indicator_judge = pd.concat(indicator_judge, axis=1)
    indicator_judge['final'] = np.all(indicator_judge, axis=1)
    indicator_judge.to_csv(output_path)
    factor_indicator.to_csv(indicator_judge_csv_file)
    return (factor_indicator, indicator_judge)

"""
if __name__ == '__main__':
    # if len(sys.argv) == 1:
    #     # Command-line argument for testing
    #     cfg = '{"date": "2016.05.30", "output":"./sample_ev_output.txt"}'
    # else:
    #     # Command-line argument from the system
    #     cfg = sys.argv[1]
    # generate_strategy_config(json.loads(cfg))

    judge_threshold = dict()
    judge_threshold['ic'] = [0.015, -0.015]
    judge_threshold['ac'] = [0.30, None]
    judge_threshold['ir'] = [0.05, None]
    judge_threshold['sr'] = [1, None]
    judge_threshold['corr'] = [None, 0.7]

    fidpool_list = [
        210289
    ]

    factor_id = 210474

    begT = 20160201
    endT = 20171231

    cfg= {
          "log_file": 'framework_sync/'+str(factor_id)+'_cycle.log',
          "day_night": 0,
          "strategy_id": factor_id,
          "fidpool": fidpool_list,
          "judge_threshold": judge_threshold,
          "pool_range": 'top2000',
          "predict_cycle": 'v1',
          'begT': begT,
          'endT': endT
          }
    print(begT, endT)
    factor_evalue_judge(cfg)
"""


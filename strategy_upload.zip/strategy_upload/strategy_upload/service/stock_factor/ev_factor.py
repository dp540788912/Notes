# -*-coding:utf-8-*-
# This is a discarded module and was replaced by ev_factor2.py
# This is a discarded module and was replaced by ev_factor2.py
# This is a discarded module and was replaced by ev_factor2.py
# This is a discarded module and was replaced by ev_factor2.py
# This is a discarded module and was replaced by ev_factor2.py
# This is a discarded module and was replaced by ev_factor2.py
# TODO: REMOVE IT
import os
import requests


class StockEvGenerateFactor(object):

    def __init__(self, ev_generate_config, *args, **kwargs):
        self.ev_generate_config = ev_generate_config
        self.trading_date = ev_generate_config['date'].replace('.', '')
        self.day_night = int(ev_generate_config['day_night'])
        self.day_night_str = {
            0: 'day',
            1: 'night'
        }[self.day_night]

        self.factor_path = os.path.join(os.path.dirname(os.getcwd()), 'platform_data/factor/')

        self.factors = {}
        if not os.path.exists(self.factor_path):
            os.makedirs(self.factor_path)

        self.csv_delimiter = ','
        self.factor_csv_head = self.csv_delimiter.join(
            ['fid', 'ticker', 'date', 'time', 'count', 'value']
        )
        self.notify_api = ev_generate_config.get('notify_api', '')

    def send_factor(self, fid, ticker, date, time, factors=None):
        if factors is None or not isinstance(factors, list):
            return False
        f = [fid, ticker, date, time, len(factors)]
        f.extend(factors)
        fid_factors = self.factors.setdefault(fid, [])
        fid_factors.append(f)
        return True

    def send_factor_columns(self, fid, columns):
        if not self.notify_api:
            return True
        requests.post(self.notify_api, json={
            'event': 'SendFactorColumns',
            'content': {
                'fid': fid,
                'columns': columns,
            }
        })
        return True

    def write_csv(self):
        for f_id, fid_factors in self.factors.items():

            factor_path = os.path.join(self.factor_path, str(f_id))
            if not os.path.exists(factor_path):
                os.makedirs(factor_path)

            f_filename = os.path.join(
                self.factor_path, str(f_id),
                '{trading_date}_{day_night}.csv'.format(trading_date=self.trading_date, day_night=self.day_night_str)
            )

            with open(f_filename, 'w') as fator_csv:
                csv_lines = [self.factor_csv_head + '\n']
                for record in fid_factors:
                    csv_lines.append(self.csv_delimiter.join(map(str, record)) + '\n')
                fator_csv.writelines(csv_lines)
        return True


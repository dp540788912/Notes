import pandas as pd
import os
from constant import CommonPath, StockFactorStrategyConstant, StrategyConstant
from service.stock_factor.models import StockFactorStrategy, StockFactorStrategyColumns
from service.back_test.models import Strategy
from db import session_context
from extensions import sentry


def transfer_factor_pnl_file_to_public_pool(factor_id):
    with session_context() as sc:
        stock_factor_strategy = sc.query(StockFactorStrategy.strategy_id.label('factor_id')).filter(
            StockFactorStrategy.strategy_id == factor_id,
            StockFactorStrategy.status2 == StockFactorStrategyConstant.Status2.Pool.value
        ).first()
        if not stock_factor_strategy:
            return False
        s = sc.query(Strategy).filter(
            Strategy.id == factor_id
        ).first()
        if not s:
            return False
        pass_columns = StockFactorStrategyColumns.get_judge_passed_columns2(factor_id=factor_id)
        for c in pass_columns:
            pnl_file_path = os.path.join(CommonPath.stock_factor_daily_summary_pnl, str(factor_id),
                                         "{column_name}_pnl.csv".format(column_name=c))
            dst_file_name = "{factor_id}_{column_name}_pnl.csv".format(factor_id=factor_id, column_name=c)
            pool_manual_pnl_file_path = os.path.join(CommonPath.stock_factor_pool_manual_pnl, dst_file_name)
            pool_pnl_file_path = os.path.join(CommonPath.stock_factor_pool_pnl, dst_file_name)
            try:
                df = pd.read_csv(pnl_file_path)
                df = df[
                    ['trading_date', 'pnl', 'longsize', 'shortsize', 'ret', 'holdpnl', 'tradepnl', 'poscov', 'negcov',
                     'pospnl', 'negpnl', 'IC', 'indexret']
                ]
                algorithm = s.detail.get('algorithm', '')
                if algorithm in StrategyConstant.DetailAlgorithm.manual_group():
                    df.to_csv(pool_manual_pnl_file_path, header=None, index=None, sep=' ')
                if algorithm != StrategyConstant.DetailAlgorithm.AlphaFactorCombination.value:
                    df.to_csv(pool_pnl_file_path, header=None, index=None, sep=' ')
            except Exception as e:
                sentry.captureException()


if __name__ == '__main__':
    # transfer_factor_pnl_file_to_public_pool(factor_id=214875)
    pass

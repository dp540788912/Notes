# encodin: utf-8
# cython: language_level=3
import json
import sys
import shutil
import pandas as pd
import numpy as np
import datetime
import os
import time
import logging
from qpython import qconnection
from multiprocessing import Pool


def get_kdb(sql, pandas=True):
    # with qconnection.QConnection(host='192.168.1.41',
    with qconnection.QConnection(host='192.168.10.102',
                                 port=9000,
                                 username='user1',
                                 password='password') as q:
        q.async(sql)
        return q.receive(pandas=pandas)

def get_datelist(begT,endT,dback=0,dnext=0):
    # , TRADE_DT within ('+qdate(begT)+';'+qdate(endT)+')
    sqlstr = '.gw.asyncexec[" select date:TRADE_DT  from Calendar where EXCHANGE=`SSE";`FuturesBasicInfo]'
    data = get_kdb(sqlstr)

    beg_index = data[data['date']>=qdate(begT,False)].index[0]-dback
    end_index = data[data['date']<=qdate(endT,False)].index[-1]+dnext
    data = data.loc[beg_index:end_index, :].reset_index(drop=True)

    return data

def get_stocklist(endT):
    sqlstr = '.gw.asyncexec["`code xasc select code:SYMBOL,ipodate:S_INFO_LISTDATE from AShareDescription where S_INFO_LISTDATE <= '+qdate(endT)+' ,( (S_INFO_DELISTDATE > '+qdate(endT)+') or (S_INFO_DELISTDATE = 0Nd) ) " ; `EquityFactor]'
    data = get_kdb(sqlstr)
    if not data.empty: data.loc[:,'code'] = data.loc[:,'code'].apply(lambda x:x.decode()).tolist()
    return data

def qdate(date, is_str=True, sep='.'):
    date = datetime.datetime.strptime(str(date), "%Y%m%d")
    if is_str: date = date.strftime("%Y" + sep + "%m" + sep + "%d")
    return date

def logger_init(cfg):
    logger = logging.Logger(name=__name__, level=logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s', datefmt = '%Y-%m-%d %H:%M:%S')
    file_handler = logging.FileHandler(cfg['log_file'])
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    return logger

def iodata_to_df(stocklist, datelist, iodata):
    result = pd.DataFrame(index=stocklist.code.tolist())
    for date in datelist.date:
        result.loc[:, date] = 0
        mask = (iodata.loc[:, 'code'].isin(stocklist['code'])) & (iodata.loc[:, 'indate'] <= date) & (
        (iodata.loc[:, 'outdate'] > date) | pd.isnull(iodata.loc[:, 'outdate']))
        result.loc[iodata.loc[mask, 'code'], date] = iodata.loc[mask, 'obj'].tolist()
    return result.T

def sddata_to_df(stocklist,datelist,data,alpha):
    sddata = data.loc[:,['date','code',alpha]]
    result = sddata.pivot_table(index='date', columns='code', values=alpha)
    result = result.reindex(index = datelist['date'], columns = stocklist['code'])
    return result

def get_vwap_cycle(alpha_data_list,code, begT, endT, cycle):
    minute_map = {4: '3600', 8: '1800', 240: '60'}

    sqlstr = '.gw.asyncexec["GetMinuteBarPartyBySymbol[`ChinaAShareStock;`' + code + ';' + qdate(
        begT) + ';' + qdate(
        endT) + ';(0;' + minute_map[cycle] + ')]"; `MinuteBarDB]'
    data = get_kdb(sqlstr)
    if not isinstance(data, bytes):
        data = data[['TradingDate', 'Symbol', 'Time', 'ClosePrice', 'Turnover', 'Volume', 'BarIndex']]
        data['date'] = data['TradingDate'].apply(lambda x: qdate(x, is_str=False))

        data = data.merge(alpha_data_list[[code]], left_on=['date'], right_index=True, how='left').fillna(
            method='ffill')
        data['close'] = data['ClosePrice'] * data[code] / 10000
        data['vwap'] = (data['Turnover'] / data['Volume'] * data[code]).fillna(method='ffill')
        data = data[['date', 'Symbol', 'Time', 'close', 'vwap', 'BarIndex']]
        print(code)
    else:
        data = pd.DataFrame()
    return data

def get_vwap_intraday(alpha_data_list,stocklist,datelist,cycle):

    begT = int(datelist.iloc[0,0].strftime("%Y%m%d"))
    endT = int(datelist.iloc[-1,0].strftime("%Y%m%d"))

    # cycle = 4

    pool = Pool(10)
    MultiResult = []
    for code in stocklist.code:
    # code = stocklist.code[0]
    # code = '601313.SH'
        this_MultiResult = pool.apply_async(get_vwap_cycle, (alpha_data_list['adj'], code, begT, endT, cycle))
        MultiResult.append(this_MultiResult)
    pool.close()
    pool.join()

    cycle_data = []
    for this_MultiResult in MultiResult:
        data = this_MultiResult.get()
        cycle_data.append(data)

    data = pd.concat(cycle_data)
    data = data.loc[(data['BarIndex'] != 0),:]
    data['code'] = data['Symbol'].apply(lambda x: x.decode())
    data['name'] = data['BarIndex'].apply(lambda x: str(x)+"_"+str(cycle))

    i=0
    # for i in range(cycle):

    cycle_name = str(i+1)+"_"+str(cycle)
    this_data_cycle = data.loc[data['name'] == cycle_name].reset_index(drop=True)

    this_data_df = sddata_to_df(stocklist, datelist, this_data_cycle, 'vwap').fillna(method='ffill')
    alpha_data_list['vwap'+cycle_name]=this_data_df

    return alpha_data_list

def get_basicdata(stocklist, datelist):
    begT = int(datelist.iloc[0, 0].strftime("%Y%m%d"))
    endT = int(datelist.iloc[-1, 0].strftime("%Y%m%d"))
    cols = 'code:SYMBOL,date:TRADE_DT,open:S_DQ_OPEN,high:S_DQ_HIGH,low:S_DQ_LOW,close:S_DQ_CLOSE,vol:S_DQ_VOLUME,amount:S_DQ_AMOUNT,adj:S_DQ_ADJFACTOR,close_nr:S_DQ_CLOSE,preclose_nr:S_DQ_PRECLOSE,vwap:S_DQ_AVGPRICE'
    sqlstr = '.gw.asyncexec["select ' + cols + ' from AShareEODPrices where TRADE_DT within (' + qdate(
        begT) + ';' + qdate(endT) + ')" ; `EquityFactor]'
    data = get_kdb(sqlstr)

    if not data.empty:
        data.loc[:, 'code'] = data.loc[:, 'code'].apply(lambda x: x.decode()).tolist()
        data = data.loc[data['code'].isin(stocklist['code']), :]

        data = data.merge(stocklist, on=['code'], how='left')
        data['ipodate'] = (data['date'] - data['ipodate']).apply(lambda x: x.days)

        data['vol'] = data['vol'] / data['adj']
        data['iszt'] = (round(data['preclose_nr'] * 110 + 0.01) / 100 <= data['close_nr']).astype(int)  # 未验证
        data['isdt'] = (round(data['preclose_nr'] * 90 + 0.01) / 100 >= data['close_nr']).astype(int)  # 未验证
        data['iszt1'] = (data['preclose_nr'] * 1.095 <= data['vwap']).astype(int)  # 未验证
        data['isdt1'] = (data['preclose_nr'] * 0.905 >= data['vwap']).astype(int)  # 未验证
        data['istrade'] = (data['vol'] > 0).astype(int)
        data[['open', 'high', 'low', 'close', 'vwap']] = data[['open', 'high', 'low', 'close', 'vwap']].mul(data['adj'],
                                                                                                            axis=0)
        data = data[
            ['code', 'date', 'open', 'high', 'low', 'close', 'vwap', 'vol', 'amount', 'iszt', 'isdt', 'iszt1', 'isdt1',
             'istrade', 'close_nr', 'ipodate','adj']]

    alphalist = ['open', 'high', 'low', 'close', 'vwap', 'vol', 'amount', 'iszt', 'isdt', 'iszt1', 'isdt1', 'istrade',
                 'close_nr', 'ipodate','adj']
    alpha_data_list = {}
    for alpha in alphalist:
        print(alpha)
        alpha_data_list[alpha] = sddata_to_df(stocklist, datelist, data, alpha)

    alpha_data_list['isst'] = get_st(stocklist, datelist)
    alpha_data_list['ashare'] = get_ashare(stocklist, datelist)
    alpha_data_list['sw'] = get_sw(stocklist, datelist)
    alpha_data_list['profitttm'] = get_profitttm(stocklist, datelist)
    alpha_data_list['500'] = get_indexweight(stocklist, datelist, '000905.SH')
    alpha_data_list['300'] = get_indexweight(stocklist, datelist, '000300.SH')

    basic_data_list={}
    alphalist = ['close_nr','open','high','low','close','vwap','amount', 'vol', 'ashare','iszt','isdt','iszt1','isdt1','istrade','ipodate','isst','sw','zf20','lb5','500','pe','mv','adj']
    for alpha in alphalist:
        print(alpha)
        if alpha in alpha_data_list.keys() :
            alphadata = alpha_data_list[alpha]
        elif alpha == 'mv':#亿
            asharedata = alpha_data_list['ashare']
            close_nrdata = alpha_data_list['close_nr']
            alphadata = asharedata*close_nrdata/10000
        elif alpha == 'zf20':
            closedata = alpha_data_list['close']
            alphadata = 100 * (closedata / closedata.shift(21) - 1)
        elif alpha == 'lb5':
            voldata = alpha_data_list['vol']
            alphadata = voldata/voldata.rolling(5).mean()
        elif alpha == 'pe':
            asharedata = alpha_data_list['ashare']
            close_nrdata = alpha_data_list['close_nr']
            profitttm = alpha_data_list['profitttm']
            alphadata = asharedata * close_nrdata / 10000 / profitttm
        basic_data_list[alpha] = alphadata

    return basic_data_list

def get_st(stocklist, datelist):
    cols = 'code:SYMBOL,obj:STATUS,indate:BEGINDATE,outdate:ENDDATE'
    sqlstr = '.gw.asyncexec["select ' + cols + ' from AShareST" ; `EquityFactor]'
    print('isst')
    iodata = get_kdb(sqlstr)
    iodata.loc[:, 'code'] = iodata.loc[:, 'code'].apply(lambda x: x.decode()).tolist()
    iodata.loc[:, 'obj'] = 1
    result = iodata_to_df(stocklist, datelist, iodata)

    return result

def get_ashare(stocklist, datelist):
    cols = 'code:SYMBOL,date:CHANGE_DT,ashare:FLOAT_A_SHR,ANN_DT,CHANGE_DT1'
    data = get_kdb('.gw.asyncexec["select ' + cols + '  from AShareCapitalization" ; `EquityFactor]')
    data.loc[:, 'code'] = data.loc[:, 'code'].apply(lambda x: x.decode()).tolist()
    print('ashare')

    tmp = pd.DataFrame(1, index=datelist['date'], columns=stocklist['code'])
    tmp = tmp.stack().reset_index()
    result = data.merge(tmp, on=['code', 'date'], how='outer')
    result = result.sort_values(['code', 'date']).reset_index(drop=True)
    result = result.groupby(['code']).apply(lambda x: x.fillna(method='ffill'))
    result = result.loc[result.date.isin(datelist.date) & result.code.isin(stocklist.code), :].reset_index(drop=True)

    result = sddata_to_df(stocklist, datelist, result, 'ashare')
    return result

def get_profitttm(stocklist, datelist):
    begT = int(datelist.iloc[0, 0].strftime("%Y%m%d"))
    endT = int(datelist.iloc[-1, 0].strftime("%Y%m%d"))
    datelist_f = get_datelist(begT, endT, dback=240, dnext=0)
    print('profitttm')
    obj = 'S_FA_DEDUCTEDPROFIT_TTM'
    cols = 'code:S_INFO_WINDCODE,ANN_DT,REPORT_PERIOD,' + obj
    sqlstr = '.gw.asyncexec["select ' + cols + ' from AShareTTMHis where REPORT_PERIOD>=2010.01.01 "; `EquityFactor]'
    data = get_kdb(sqlstr)
    data.loc[:, 'code'] = data.loc[:, 'code'].apply(lambda x: x.decode()).tolist()
    data.loc[:, obj] = data.loc[:, obj] / 100000000

    result = pd.DataFrame(index=stocklist.code.tolist())
    for date in datelist_f.date:
        mask = data.loc[:, 'code'].isin(stocklist['code']) & (data.loc[:, 'ANN_DT'] == date)
        result.loc[data.loc[mask, 'code'], date] = data.loc[mask, obj].tolist()

    result = result.fillna(axis=1, method='ffill')
    result = result.T
    result = result.loc[datelist['date'], stocklist['code']]
    return result

def get_sw(stocklist, datelist):
    begT = int(datelist.iloc[0, 0].strftime("%Y%m%d"))
    endT = int(datelist.iloc[-1, 0].strftime("%Y%m%d"))
    cols = 'code:SYMBOL, date:TRADE_DT, hy:IndustrySWS01'
    data = get_kdb(
        '.gw.asyncexec["select ' + cols + ' from IndustrySWS01 where TRADE_DT within (' + qdate(begT) + ';' + qdate(
            endT) + ') " ; `EquityFactor]')
    data.loc[:, 'code'] = data.loc[:, 'code'].apply(lambda x: x.decode()).tolist()
    data = data.loc[data['code'].isin(stocklist['code']), :]
    data.loc[:, 'hy'] = data.loc[:, 'hy'].apply(lambda x: (x.decode())[0:6]).tolist()
    data.loc[:, 'hy'] = data.loc[:, 'hy'].apply(lambda x: (0 if (x == '') else int(x)))
    result = sddata_to_df(stocklist, datelist, data, 'hy')
    return result

def get_indexweight(stocklist,datelist,index_code):
    print(index_code)
    #000300.SH, 000905.SH, 000016.SH
    # datelist = get_datelist(begT, endT, dback=0, dnext=0)
    begT = int(datelist.iloc[0, 0].strftime("%Y%m%d"))
    endT = int(datelist.iloc[-1, 0].strftime("%Y%m%d"))
    if index_code in ['000905.SH', '000016.SH']:
        datelist_f = get_datelist(begT, endT, dback=30, dnext=0)
        _begT = int(datelist_f.iloc[0, 0].strftime("%Y%m%d"))
        _endT = int(datelist_f.iloc[-1, 0].strftime("%Y%m%d"))

        cols = 'code:SYMBOL,date:TRADE_DT,weight:I_WEIGHT,index:CODE'
        sqlstr = '.gw.asyncexec["select ' + cols + ' from AIndexFreeWeight where CODE=`'+index_code+', TRADE_DT within (' + qdate(_begT) + ';' + qdate(_endT) + ')"; `EquityFactor]'
        data = get_kdb(sqlstr)
        data.loc[:, 'code'] = data.loc[:, 'code'].apply(lambda x: x.decode()).tolist()

        cols = 'code:SYMBOL,date:TRADE_DT,close:S_DQ_CLOSE,adj:S_DQ_ADJFACTOR'
        sqlstr = '.gw.asyncexec["select ' + cols + ' from AShareEODPrices where TRADE_DT within (' + qdate(_begT) + ';' + qdate(_endT) + ')" ; `EquityFactor]'
        data_dq = get_kdb(sqlstr)
        data_dq.loc[:, 'code'] = data_dq.loc[:, 'code'].apply(lambda x: x.decode()).tolist()
        data_dq['weight_multi'] = data_dq['close'] * data_dq['adj']

        data = pd.merge(data, data_dq, on=['code', 'date'], how='left')
        data['weight_base'] = data['weight'] / data['weight_multi']
        result = data.pivot_table(index='date', columns='code', values='weight_base').reindex(columns = stocklist['code']).fillna(0)
        result = result.reindex(index=datelist_f['date']).fillna(method='ffill').reindex(index=datelist['date'])

        weight_multi = sddata_to_df(stocklist, datelist, data_dq, 'weight_multi')

        result = result*weight_multi
        result = result.div((result).sum(axis=1),axis=0)
    else:
        begT = int(datelist.iloc[0,0].strftime("%Y%m%d"))
        endT = int(datelist.iloc[-1,0].strftime("%Y%m%d"))
        cols = 'code:SYMBOL,date:TRADE_DT,weight:I_WEIGHT,index:CODE'
        sqlstr = '.gw.asyncexec["select '+cols+' from AIndexFreeCloseWeight where CODE=`000300.SH, TRADE_DT within ('+qdate(begT)+';'+qdate(endT)+')"; `EquityFactor]'
        data = get_kdb(sqlstr)
        data.loc[:, 'code'] = data.loc[:, 'code'].apply(lambda x: x.decode()).tolist()
        data.loc[:, 'weight'] = data.loc[:, 'weight']/100
        result = sddata_to_df(stocklist, datelist, data, 'weight').fillna(0)
    return result

def produce_basicroc(date, model_para, logger):

    datelist = get_datelist(model_para['begT'], int(date.strftime("%Y%m%d")))
    stocklist = get_stocklist(int(date.strftime("%Y%m%d")))

    begt = date #calc date by default
    # thisdate = datelist.date[0]
    for thisdate in datelist.date:
        basic_path = model_para['path'] + 'basic/basic' + str(thisdate)[:10] + '.csv'
        if not os.path.exists(basic_path):
            begt = thisdate
            break

    logger.info('produce_basicroc begin@'+begt.strftime("%Y%m%d"))

    datelist_basic = get_datelist(int(begt.strftime("%Y%m%d")), int(date.strftime("%Y%m%d")), 20)

    basic_data = get_basicdata(stocklist, datelist_basic)
    basic_data = get_vwap_intraday(basic_data, stocklist, datelist_basic, 4)

    roc_data_dict = {}
    vwapdata1 = basic_data['vwap']
    vwapdata2 = basic_data['vwap']
    roc_data = (vwapdata2.shift( -1 + model_para['nex'] ) / vwapdata1.shift(-1) - 1) * 100
    roc_data_dict[0] = roc_data
    vwapdata1 = basic_data['vwap1_4']
    vwapdata2 = basic_data['vwap1_4']
    roc_data = (vwapdata2.shift( -1 + model_para['nex'] ) / vwapdata1.shift(-1) - 1) * 100
    roc_data_dict[1] = roc_data

    for thisdate in datelist_basic.date:
    # thisdate = datelist_basic.date.iloc[-1]
        basic_path = model_para['path'] + 'basic/basic' + str(thisdate)[:10] + '.csv'
        if not os.path.exists(basic_path):
            logger.info(basic_path)
            this_basic_list = []
            # key = 'isst'
            for key in basic_data:
                logger.info(key)
                this_basic_list.append(basic_data[key].loc[thisdate].to_frame('basic '+key))
            this_basic = pd.concat(this_basic_list,axis=1)
            this_basic.to_csv(basic_path)

        roc_path = model_para['path'] + 'roc/roc' + str(thisdate)[:10] + '.csv'
        if not os.path.exists(roc_path):
            this_roc = roc_data_dict[0].loc[thisdate]
            if pd.isnull(this_roc).sum() < len(this_roc):
                this_roc = this_roc.to_frame('roc zfv1')
                this_roc_data = this_roc
                this_roc = roc_data_dict[1].loc[thisdate]
                this_roc = this_roc.to_frame('roc zfv1040104')
                this_roc_data = pd.concat([this_roc_data, this_roc], axis=1)

                if not this_roc_data.empty:
                    logger.info('output_rocdata @' + roc_path)
                    this_roc_data.to_csv(roc_path)

def generate_strategy_config(cfg):
    logger = logger_init(cfg)

    date_str = cfg['date']
    logger.info("start ev@" + date_str)

    ev_date = date_str.replace('.', '')
    endT = int(ev_date)

    path = 'framework_sync/factor_basic/'

    model_para = {
        'path': path,
        'begT': 20160101,
        'nex': -1,
    }

    if not os.path.exists(path): os.makedirs(path)
    if not os.path.exists(path + 'basic/'): os.makedirs(path + 'basic/')
    if not os.path.exists(path + 'roc/'): os.makedirs(path + 'roc/')

    datelist = get_datelist(model_para['begT'], endT, 20, 0)
    i = np.argwhere(datelist.date == qdate(endT, False))[0][0]
    date = datelist.date[i - 1]

    basic_path = model_para['path']+'basic/basic' + str(date)[:10] + '.csv'
    if not os.path.exists(basic_path):
        produce_basicroc(date, model_para, logger)

if __name__ == '__main__':
    # if len(sys.argv) == 1:
    #     # Command-line argument for testing
    #     cfg = '{"date": "2016.05.30", "output":"./sample_ev_output.txt"}'
    # else:
    #     # Command-line argument from the system
    #     cfg = sys.argv[1]
    # generate_strategy_config(json.loads(cfg))

    begT = 20160201
    # begT = 20180101
    # begT = 20180731
    # endT = 20180301
    endT = 20180930
    datelist = get_datelist(begT,endT,0,0)
    # date = datelist.date[0]
    # date = datelist.date.iloc[-200]

    for date in datelist.date:
        cfg= {"date": date.strftime("%Y.%m.%d"),
              "output":"output_tmp/"+date.strftime("%Y%m%d")+".csv",
              "log_file":'framework_sync/factor_basic/'+'alphadata_log.log',
        }
        print(date)
        generate_strategy_config(cfg)



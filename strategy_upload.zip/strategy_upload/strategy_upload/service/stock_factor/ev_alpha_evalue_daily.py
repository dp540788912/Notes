# encodin: utf-8
# cython: language_level=3
# @Author  : huajian

import json
import sys
import shutil
import pandas as pd
import numpy as np
import datetime
import os
import requests
import time
from qpython import qconnection
from my.data import quote
from my.data import basic_func

def get_datelist(begT,endT,dback=0,dnext=0):
    sqlstr = "select date:TRADE_DT from Calendar where EXCHANGE=`SSE"
    database = 'FuturesBasicInfo'
    data = basic_func.get_kdb(sqlstr, database)

    beg_index = data[data['date']>=qdate(begT,False)].index[0]-dback
    end_index = data[data['date']<=qdate(endT,False)].index[-1]+dnext
    data = data.loc[beg_index:end_index, :].reset_index(drop=True)
    return data


def get_stocklist(endT):
    sqlstr = '`code xasc select code:SYMBOL,ipodate:S_INFO_LISTDATE from AShareDescription where S_INFO_LISTDATE <= ' + qdate(endT) + ' ,( (S_INFO_DELISTDATE > ' + qdate(endT) + ') or (S_INFO_DELISTDATE = 0Nd) ) '
    database = 'EquityFactor'
    data = basic_func.get_kdb(sqlstr, database)
    if not data.empty: data.loc[:,'code'] = data.loc[:,'code'].apply(lambda x:x.decode()).tolist()
    return data

def qdate(date, is_str=True, sep='.'):
    date = datetime.datetime.strptime(str(date), "%Y%m%d")
    if is_str: date = date.strftime("%Y" + sep + "%m" + sep + "%d")
    return date

def gen_mask(thisbasic, mode_range):
    dt = thisbasic.loc[:, 'basic isdt']
    zt = thisbasic.loc[:, 'basic iszt']
    istrade = thisbasic.loc[:, 'basic istrade']
    st = thisbasic.loc[:, 'basic isst']
    sw = thisbasic.loc[:, 'basic sw']
    ipo = thisbasic.loc[:, 'basic ipodate']

    mask_s = (istrade == 1) & (dt == 0) & (zt == 0) & (st == 0) & pd.notnull(sw) & (sw != 0) & pd.notnull(ipo) & (ipo >= 400)
    mask = mask_s

    if mode_range == 'top2000':
        mask = mask_s & ( thisbasic.loc[mask_s, 'basic pe']>0 ) \
                      & ( thisbasic.loc[mask_s, 'basic mv'].rank(ascending=False)<=2000 )
    if mode_range == '500expe':
        tmp = thisbasic.loc[mask_s, ['basic pe','basic mv']]
        tmp['basic pe'] *= -1
        tmp = tmp.rank().sum(axis=1).rank(ascending=False)
        tmp = (tmp-(tmp[thisbasic.loc[:, 'basic 500'] > 0]).median()).abs().rank()
        mask = mask_s & ( tmp<=1500 ) & (thisbasic.loc[mask_s, 'basic pe']>0)

    mask = mask.loc[mask_s.index]

    return mask


def zscore(d):
    df_zscore = (d - d.mean())/d.std()
    df_zscore = np.clip(df_zscore, -3, 3)
    df_zscore = (df_zscore - df_zscore.mean()) / df_zscore.std()
    return df_zscore


def get_corr(DataPdX, DataPdY):
    DataNpXCopy = DataPdX.values.copy()
    DataNpYCopy = DataPdY.values.copy()

    indexlabel = DataPdX.columns
    columnslabel = DataPdY.columns

    num_x = len(indexlabel)
    num_y = len(columnslabel)
    result_np = np.zeros([num_x, num_y])
    for col_y_idx in range(num_y):
        DataNpY_col = DataNpYCopy[:, col_y_idx]

        for col_x_idx in range(num_x):
            DataNpX_col = DataNpXCopy[:, col_x_idx]
            result_np[col_x_idx, col_y_idx] = np.corrcoef(DataNpX_col, DataNpY_col)[0, 1]

    result_pd = pd.DataFrame(result_np, index=indexlabel, columns=columnslabel)
    return result_pd


#DataPdX1, DataPdX2 = thisalpha.fillna(0), lastalpha.fillna(0)
def get_autocorr(DataPdX1, DataPdX2):
    DataNpX1Copy = DataPdX1.values.copy()
    DataNpX2Copy = DataPdX2.values.copy()

    indexlabel = DataPdX1.columns
    num_x = len(indexlabel)
    result_np = np.zeros(num_x)

    for col_y_idx in range(num_x):
        DataNpX1_col = DataNpX1Copy[:, col_y_idx]
        DataNpX2_col = DataNpX2Copy[:, col_y_idx]
        result_np[col_y_idx] = np.corrcoef(DataNpX1_col, DataNpX2_col)[0, 1]

    result_s = pd.Series(result_np, index=indexlabel)
    return result_s

#DataPdX1, DataPdX2 = thisalpha_weight, thisalpha_l_weight
def get_turnover(DataPdX1, DataPdX2):
    DataNpX1Copy = DataPdX1.values.copy()
    DataNpX2Copy = DataPdX2.values.copy()

    indexlabel = DataPdX1.columns
    num_x = len(indexlabel)
    result_np = np.zeros(num_x)

    for col_y_idx in range(num_x):
        DataNpX1_col = DataNpX1Copy[:, col_y_idx]
        DataNpX2_col = DataNpX2Copy[:, col_y_idx]

        DataNpX1_col[DataNpX1_col < 0] = 0
        DataNpX2_col[DataNpX2_col < 0] = 0

        result_np[col_y_idx] = np.min([DataNpX1_col, DataNpX2_col], axis=0).sum()

    result_s = pd.Series(result_np, index=indexlabel)
    return result_s


def get_roc(roc_path, cfg):
    predict_cycle = cfg['predict_cycle']

    if predict_cycle == 'v1':
        thisroc = pd.read_csv(roc_path, index_col=0)['roc zfv1']
    if predict_cycle == 'v1_n':
        thisroc = pd.read_csv(roc_path, index_col=0)['roc_n zfv1']
    thisroc = thisroc.to_frame('roc')
    return thisroc


def get_alpha(factor_id, endT):

    thisalpha = quote.factor(endT, 280, factor_id, 0, 0, pandas=True)
    thisalpha = thisalpha.drop(columns=['fid', 'exch_time', 'local_time', 'date', 'elapsed', 'count'])
    thisalpha['ticker'] = [str(int(x.decode()) + 1000000)[1:] + (".SH" if (int(x.decode()) >= 600000) else ".SZ") for x in thisalpha['ticker']]
    thisalpha = thisalpha.set_index(['ticker'])

    return thisalpha


def factor_evalue_daily(cfg):

    date_str = cfg['date']
    ev_date = date_str.replace('.', '')
    # begT = int(ev_date)
    endT = int(ev_date)
    factor_id = cfg['strategy_id']

    path = cfg['basic_data_path']

    strategy_name = '{}_{}_{}'.format(cfg['strategy_id'],cfg['pool_range'],cfg['predict_cycle'])

    if not os.path.exists(path): os.makedirs(path)
    if not os.path.exists(path+'factor_evalue_daily/'): os.makedirs(path+'factor_evalue_daily/')
    if not os.path.exists(path + 'factor_evalue_daily/' + strategy_name  +'/'): os.makedirs(path + 'factor_evalue_daily/' + strategy_name  +'/')

    datelist = get_datelist(endT, endT, 20, 0)
    i = np.argwhere(datelist.date == qdate(endT, False))[0][0]
    date = datelist.date[i - 1]

    basic_path = path + 'factor_basic/basic/basic' + str(date)[:10] + '.csv'
    roc_path = path + 'factor_basic/roc/roc' + str(date)[:10] + '.csv'

    thisbasic = pd.read_csv(basic_path, index_col=0)
    thisroc = get_roc(roc_path, cfg)

    thisalpha = get_alpha(factor_id, endT)
    thisalpha_l = get_alpha(factor_id, int(date.strftime('%Y%m%d')))

    thismask = gen_mask(thisbasic, cfg['pool_range'])
    thismask = thismask[thismask].index

    thismask = thismask & thisroc.index & thisalpha.index
    thisroc = thisroc.loc[thismask]
    thisalpha = thisalpha.loc[thismask]

    cr = (pd.notnull(thisalpha).sum() / len(thisalpha)).to_frame('cr')
    thisalpha = thisalpha.fillna(0)
    thisalpha_l = thisalpha_l.reindex(index=thismask).fillna(0)

    ic = get_corr(thisalpha, thisroc)['roc'].to_frame('ic')
    ac = get_autocorr(thisalpha, thisalpha_l).to_frame('ac')

    thisalpha_zscore = zscore(thisalpha)
    thisalpha_weight = 2*thisalpha_zscore/np.abs(thisalpha_zscore).sum()

    thisalpha_l_zscore = zscore(thisalpha_l)
    thisalpha_l_weight = 2*thisalpha_l_zscore/np.abs(thisalpha_l_zscore).sum()

    tr = get_turnover(thisalpha_weight, thisalpha_l_weight).to_frame('tr')

    ret = (thisalpha_weight.T.dot(thisroc))['roc'].to_frame('ret')

    result = pd.concat([ic, ac, tr, cr, ret], axis=1)

    result.to_csv(path + 'factor_evalue_daily/' + strategy_name + '/' + ev_date + '.csv')


"""
factor_id = 210474

begT = 20160201
endT = 20180731
datelist = get_datelist(begT,endT,0,0)
# date = datelist.date[0]
# date = datelist.date.iloc[-1]
for date in datelist.date:
    cfg= {"date": date.strftime("%Y%m%d"),
          "strategy_id": factor_id,
          "pool_range": 'top2000',
          "predict_cycle": 'v1'
          }
    generate_strategy_config(cfg)
"""
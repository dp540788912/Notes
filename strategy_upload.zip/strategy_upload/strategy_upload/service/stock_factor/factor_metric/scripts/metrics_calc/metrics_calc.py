# -*- coding: utf-8 -*-


import argparse
import json
import logging
import pandas as pd
import numpy as np
import os
import time
import sys
import traceback

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))


import multiprocessing

from itertools import repeat
from importlib import reload
from datetime import datetime

from shennong.utils.misc import update_nested_dictionary
from shennong.utils.arg_helper import parse_args_json_config
from shennong.utils.metrics import preprocess_nda_idx_according_nda2, calc_corr
from shennong.my_adapter import symbol, date, data


def define_arg_parser():
    parser = argparse.ArgumentParser(
            formatter_class = argparse.RawDescriptionHelpFormatter,
            description=\
            '''
        Feature evaluation

            python feature_evaluation --c config.json
            ''')

    parser.add_argument(
        '--c',
        dest='json_config_path',
        type=str,
        help='json config path, if not given, will use fallback')

    return parser


def consumer(
        args,
        consumer_id,
        total_task_count,
        mp_finished_task_count,
        mp_lock):

    logger = initialize_subprocess_log(args, consumer_id)

    logger.info('Consumer:{} start'\
            .format(consumer_id))

    while mp_finished_task_count.value < total_task_count:

        corr = np.nan
        exception_mesage = None
        task = None

        try:
            task = mp_queue.get(True, 3)
            mp_array_index = task['mp_array_index']
            nda1 = task['nda1']
            nda2 = task['nda2']
            symbol = task['symbol']
            one_date = task['date']
            feature_label = task['feature-label']
            corr_mp_array = corr_mp_array_map[feature_label]
            valid_count_mp_array = valid_count_mp_array_map[feature_label]

            nda1, nda2, nda1_invalid_count = preprocess_nda_idx_according_nda2(nda1, nda2)
            corr = calc_corr(nda1, nda2)

            corr_mp_array[mp_array_index] = corr
            valid_count_mp_array[mp_array_index] = len(nda1) - nda1_invalid_count

            logger.info('symbol:{} date:{} feature-label:{} corr:{:<4}'\
                    .format(symbol, one_date, feature_label, corr))
        except:
            exception_message = sys.exc_info()[0]
            traceback_message = traceback.format_exc()

            if task is None:
                logger.info('Failed to get task exception:{}'\
                        .format(exception_message))
            else:
                logger.info('symbol:{} date:{} feature-label:{} exception:{} traceback:{}'\
                        .format(symbol, one_date, feature_label,
                            exception_message, traceback_message,))

            time.sleep(0.1)
        finally:
            if not task is None:
                # increase the count
                mp_lock.acquire()
                mp_finished_task_count.value += 1
                print('task progress:',  mp_finished_task_count.value, '/', total_task_count)
                mp_lock.release()

    logger.info('Consumer:{} finished'\
            .format(consumer_id))


def extract_label_time_span_minute(label):
    minute_count = int(int(label.split('__')[1]) / 60000)

    return minute_count


def dump_config(args):
    config_dict = args._asdict()

    file_folder = os.path.join(
        args.experiment_save_root,
        args.experiment_name)

    if not os.path.exists(file_folder):
        os.makedirs(file_folder)

    file_path = os.path.join(
        file_folder,
        'config.json')

    with open(file_path, 'w') as f:
        json.dump(config_dict, f, indent=4)


def initialize_main_log(args):
    # Initialize log
    log_file_folder = os.path.join(
        args.experiment_save_root,
        args.experiment_name,
        args.log.log_relative_save_root)

    if not os.path.exists(log_file_folder):
        os.makedirs(log_file_folder)

    log_file_path = os.path.join(
        log_file_folder,
        args.log.main_log_format_string)

    logging_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    logging.basicConfig(
            filename = log_file_path,
            filemode = 'a',
            level = logging.INFO,
            format = logging_format)
    logger = logging.getLogger(__name__)

    # Main also output to stdout
    logger.addHandler(logging.StreamHandler(sys.stdout))

    return logger

def initialize_subprocess_log(args, consumer_id):
    # Initializ the consumer log
    log_file_folder = os.path.join(
            args.experiment_save_root,
            args.experiment_name,
            args.log.log_relative_save_root)
    if not os.path.exists(log_file_folder):
        os.makedirs(log_file_folder)

    log_file_path = os.path.join(
            log_file_folder,
            args.log.subprocess_log_format_string.format(consumer_id))

    # If current process already called before,
    #    must shutdown and reload the logging
    logging.shutdown()
    reload(logging)
    logging_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    logging.basicConfig(
            filename = log_file_path,
            filemode = 'a',
            level = logging.INFO,
            format = logging_format)
    logger = logging.getLogger(__name__)

    return logger


def save_summary(
        feature_list,
        label_list,
        corr_mp_array_map,
        valid_count_mp_array_map):
    # Initialize all feature summary dict
    all_feature_summary_df = np.empty((len(feature_list), 2 * len(label_list) + 1))

    # Save all corr csv
    for feature_label, corr_mp_array in corr_mp_array_map.items():
        logger.info('Main() Start save {} corr summary'.format(feature_label))

        feature = feature_label.split('-')[0]
        label = feature_label.split('-')[1]
        feature_index = feature_list.index(feature)
        label_index = label_list.index(label)

        summary_np = np.empty((len(symbol_list) + 5, len(date_list) + 5))
        summary_np[:] = np.nan
        summary_np[:len(symbol_list) + 1,:len(date_list) + 1] =\
            np.frombuffer(corr_mp_array.get_obj()).\
            reshape((len(symbol_list) + 1, len(date_list) + 1))

        # Assign all symbol, all date
        summary_np[:, -1] = summary_np[:, -5]
        summary_np[-1, :] = summary_np[-5, :]

        # Assign valid count
        summary_np[-5, :-5] = np.sum(~np.isnan(summary_np[:-5, :-5]), axis = 0)
        summary_np[:-5, -5] = np.sum(~np.isnan(summary_np[:-5, :-5]), axis = 1)

        # Assign mean
        summary_np[-4, :-5] = np.nanmean(summary_np[:-5, :-5], axis = 0)
        summary_np[:-5, -4] = np.nanmean(summary_np[:-5, :-5], axis = 1)

        # Assign std
        summary_np[-3, :-5] = np.nanstd(summary_np[:-5, :-5], axis = 0)
        summary_np[:-5, -3] = np.nanstd(summary_np[:-5, :-5], axis = 1)

        # Assign mean / std
        summary_np[-2, :-5] = summary_np[-4, :-5] / summary_np[-3, :-5]
        summary_np[:-5, -2] = summary_np[:-5, -4] / summary_np[:-5, -3]

        # All date mean, std, mean / std
        summary_np[-4, -1] = np.nanmean(summary_np[:-5, -1])
        summary_np[-3, -1] = np.nanstd(summary_np[:-5, -1])
        summary_np[-2, -1] = summary_np[-4, -1] / summary_np[-3, -1]

        # All symbol mean, std, mean / std
        summary_np[-1, -4] = np.nanmean(summary_np[-1, :-5])
        summary_np[-1, -3] = np.nanstd(summary_np[-1, :-5])
        summary_np[-1, -2] = summary_np[-1, -4] / summary_np[-1, -3]

        # Assign all symbol-date mean
        summary_np[-4, -4] = np.nanmean(summary_np[:-5, :-5])

        # Update all feature summary df
        all_feature_summary_df[feature_index, 2 * label_index] =\
            summary_np[-1, -4]
        all_feature_summary_df[feature_index, 2 * label_index + 1] =\
            summary_np[-1, -2]

        df = pd.DataFrame(
            index = (symbol_list\
                + ['valid_symbol_count', 'avg', 'std', 'avg/std', 'all_symbol']),
            columns = (date_list\
                + ['valid_date_count', 'avg', 'std', 'avg/std', 'all_date']),
            data = summary_np)

        save_folder = os.path.join(
            args.experiment_save_root,
            args.experiment_name,
            'summary',
            feature_label)
        if not os.path.exists(save_folder):
            os.makedirs(save_folder)
        save_path = os.path.join(
            save_folder,
            'corr.csv')

        df.to_csv(save_path)

        logger.info('Main() Finish saved {} corr summary'.format(feature_label))

    # Save all valid count csv
    for feature_label, valid_count_mp_array in valid_count_mp_array_map.items():
        logger.info('Main() Start save {} valid count summary'.format(feature_label))

        summary_np = np.empty((len(symbol_list) + 3, len(date_list) + 3))
        summary_np[:] = np.nan
        summary_np[:len(symbol_list) + 1,:len(date_list) + 1] =\
            np.frombuffer(valid_count_mp_array.get_obj()).\
            reshape((len(symbol_list) + 1, len(date_list) + 1))

        # Assign all symbol, all date
        summary_np[:, -1] = summary_np[:, -3]
        summary_np[-1, :] = summary_np[-3, :]

        # Assign valid count
        summary_np[-3, :-3] = np.sum(~np.isnan(summary_np[:-3, :-3]), axis = 0)
        summary_np[:-3, -3] = np.sum(~np.isnan(summary_np[:-3, :-3]), axis = 1)

        # Assign mean
        summary_np[-2, :-3] = np.nanmean(summary_np[:-3, :-3], axis = 0)
        summary_np[:-3, -2] = np.nanmean(summary_np[:-3, :-3], axis = 1)

        # Assign global mean
        summary_np[-2, -2] = np.nanmean(summary_np[:-3, :-3])

        # Assign all date mean
        summary_np[-2, -1] = np.nanmean(summary_np[:-3, -1])

        # Assign all symbol mean
        summary_np[-1, -2] = np.nanmean(summary_np[-1, :-3])

        # Update all feature summary df
        # Only show 1minute non-nan rount
        feature = feature_label.split('-')[0]
        feature_index = feature_list.index(feature)
        label = feature_label.split('-')[1]
        minute_count = extract_label_time_span_minute(label)
        if minute_count == 1:
            print('feature_label:', feature_label, ' minute_count:1, nonnan_count:', summary_np[-2, -2])
            all_feature_summary_df[feature_index, 2 * len(label_list)] =\
                summary_np[-2, -2]

        df = pd.DataFrame(
            index = (symbol_list\
                + ['valid_symbol_count', 'avg', 'all_symbol']),
            columns = (date_list\
                + ['valid_date_count', 'avg', 'all_date']),
            data = summary_np)

        save_folder = os.path.join(
            args.experiment_save_root,
            args.experiment_name,
            'summary',
            feature_label)
        if not os.path.exists(save_folder):
            os.makedirs(save_folder)
        save_path = os.path.join(
            save_folder,
            'valid_count.csv')

        df.to_csv(save_path)

        logger.info('Main() Finish saved {} valid count summary'.format(feature_label))

    # Save all feature summary df
    column_list = []
    for label in label_list:
        minute_count = extract_label_time_span_minute(label)
        column_list.append('IC_{}_min'.format(minute_count))
        column_list.append('IR_{}_min'.format(minute_count))
    column_list.append('Non-nan Count')

    df = pd.DataFrame(
        index = feature_list,
        columns = column_list,
        data = all_feature_summary_df)

    save_path = os.path.join(
        args.experiment_save_root,
        args.experiment_name,
        'summary',
        'all_feature_summary.csv')

    df.to_csv(save_path)

    logger.info('Main() Finish saved all feature summary')


if __name__ == '__main__':

    # Parse input args
    args_parser = define_arg_parser()
    args = args_parser.parse_args()
    args = parse_args_json_config(
            args,
            ['experiment_name1'])

    # Initialize main log
    logger = initialize_main_log(args)

    # Dump the experiment config
    dump_config(args)

    # symbol
    symbol_list = symbol.load('CnAShare', args.symbol)

    # date
    date_list = date.load('CnAShare', args.date)

    # feature, label
    feature_list = args.feature_list
    label_list = args.label_list
    logger.info('Main() Finish parsed symbol date feature/label')

    # Initialize the shared memory array and task queue
    total_task_count =\
        ((len(symbol_list) + 1) * (len(date_list) + 1) - 1)\
                * (len(feature_list)* len(label_list))
    one_mp_array_size =\
        (len(symbol_list) + 1) * (len(date_list) + 1)

    logger.info('Main() total_task_count: ({} + 1) * ({} + 1) * {} * {}'.format(
            len(symbol_list),
            len(date_list),
            len(feature_list),
            len(label_list)))

    # Each feature-label has a multiprocess shared array
    corr_mp_array_map = {}
    valid_count_mp_array_map = {}
    for feature in feature_list:
        for label in label_list:
            mp_array_key = feature + '-' +  label

            corr_mp_array = multiprocessing.Array(
                    'd',
                    one_mp_array_size)
            for i in range(one_mp_array_size): corr_mp_array[i] = np.nan

            valid_count_mp_array = multiprocessing.Array(
                    'd',
                    one_mp_array_size)
            for i in range(one_mp_array_size): valid_count_mp_array[i] = np.nan

            corr_mp_array_map[mp_array_key] = corr_mp_array
            valid_count_mp_array_map[mp_array_key] = valid_count_mp_array

    mp_finished_task_count = multiprocessing.Value('i', 0)
    mp_queue = multiprocessing.Queue()
    mp_lock = multiprocessing.Lock()
    logger.info('Main() Finish initialized the share memory')

    # Start the consumer process
    consumer_processes = [multiprocessing.Process(
        target = consumer,
        args = (
            args,
            consumer_id,
            total_task_count,
            mp_finished_task_count,
            mp_lock))
        for consumer_id in range(args.multiprocess_count)]

    for p in consumer_processes:
        p.start()
    logger.info('Main() Finish started the share memory')

    # Since load all data into memory will exceed server memory limitation
    # We will iterate each <symbol,date> twice
    # The first time, iterate by date
    # The second time, iterate by symbol
    put_task_count = 0
    for date_index, one_date in enumerate(date_list):
        feature_np_list = []
        label_np_list = []

        for symbol_index, symbol in enumerate(symbol_list):
            feature_np =\
                    data.load_np(
                            args.feature_load_path_format_string.format(
                                one_date.replace('-',''),
                                symbol.replace('.SH','').replace('.SZ','')))
            label_np =\
                    data.load_np(
                            args.label_load_path_format_string.format(
                                one_date.replace('-',''),
                                symbol.replace('.SH','').replace('.SZ','')))

            # Special handle one symbol one date empty case
            if ((feature_np is None) or (label_np is None)):
                feature_np = np.empty((0, len(feature_list)))
                label_np = np.empty((0, len(label_list)))

                logger.info('Main() symbol:{} date:{} feature/label is None'\
                        .format(symbol, one_date))

            feature_np_list.append(feature_np)
            label_np_list.append(label_np)

            for f_index in range(len(feature_list)):
                for l_index in range(len(label_list)):
                    task = {}
                    task['symbol'] = symbol
                    task['date'] = one_date
                    task['nda1'] = feature_np[:, f_index]
                    task['nda2'] = label_np[:, l_index]
                    task['mp_array_index'] =\
                            symbol_index * (len(date_list) + 1) + date_index
                    mp_array_key =\
                            feature_list[f_index] + '-' + label_list[l_index]
                    task['feature-label'] = mp_array_key

                    mp_queue.put(task)
                    put_task_count += 1

        one_date_all_symbol_feature_np = np.concatenate(feature_np_list, axis=0)
        one_date_all_symbol_label_np = np.concatenate(label_np_list, axis=0)

        # No need handle one date all symbol empty case
        # Since one_date_all_symbol_feature/label_np shape is correct

        for f_index in range(len(feature_list)):
            for l_index in range(len(label_list)):
                task = {}
                task['symbol'] = 'AllSymbol'
                task['date'] = one_date
                task['nda1'] = one_date_all_symbol_feature_np[:, f_index]
                task['nda2'] = one_date_all_symbol_label_np[:, l_index]
                task['mp_array_index'] =\
                       len(symbol_list) * (len(date_list) + 1) + date_index
                mp_array_key =\
                        feature_list[f_index] + '-' + label_list[l_index]
                task['feature-label'] = mp_array_key

                mp_queue.put(task)
                put_task_count += 1

    logger.info('Main() Iterate by date, put task count:{}'.format(put_task_count))

    for symbol_index, symbol in enumerate(symbol_list):

        feature_np_list = []
        label_np_list = []

        for one_date in date_list:
            feature_np =\
                    data.load_np(
                            args.feature_load_path_format_string.format(
                                one_date.replace('-',''),
                                symbol.replace('.SH','').replace('.SZ','')))
            label_np =\
                    data.load_np(
                            args.label_load_path_format_string.format(
                                one_date.replace('-',''),
                                symbol.replace('.SH','').replace('.SZ','')))

            # Special handle one symbol one date empty case
            if ((feature_np is None) or (label_np is None)):
                feature_np = np.empty((0, len(feature_list)))
                label_np = np.empty((0, len(label_list)))

            feature_np_list.append(feature_np)
            label_np_list.append(label_np)

        one_symbol_all_date_feature_np = np.concatenate(feature_np_list, axis=0)
        one_symbol_all_date_label_np = np.concatenate(label_np_list, axis=0)

        # No need handle one symbol all date empty case
        # Since one_symbol_all_date_feature/label_np shape is correct

        for f_index in range(len(feature_list)):
            for l_index in range(len(label_list)):
                task = {}
                task['symbol'] = symbol
                task['date'] = 'AllDate'
                task['nda1'] = one_symbol_all_date_feature_np[:, f_index]
                task['nda2'] = one_symbol_all_date_label_np[:, l_index]
                task['mp_array_index'] =\
                        symbol_index * (len(date_list) + 1) + len(date_list)
                mp_array_key =\
                        feature_list[f_index] + '-' + label_list[l_index]
                task['feature-label'] = mp_array_key

                mp_queue.put(task)
                put_task_count += 1

    logger.info('Main() Iterate by symbol, put task count:{}'.format(put_task_count))
    logger.info('Main() Finish put all tasks to queue')

    # Waiting all consumer process
    for p in consumer_processes:
        p.join()
    logger.info('Main() Finish joined all consumer processes')

    # Save all summaries
    save_summary(
        feature_list,
        label_list,
        corr_mp_array_map,
        valid_count_mp_array_map)

#
# File Structure
#
# one experiment(with time-tag to be unique)
#    config file (symbol, date, key)
#    log folder
#        each thread a log file
#    feature-label folder
#        corr symbol-date table (use share memory to solve multiprocess issue)
#        valid_count symbol-date table (use share memory to solve multiprocess issue)
#    total summary file (feature-metrics, no symbol, no date)
#
# From big->small
#    Since one file cannot multi-process write
#       Method1: split the file to support threads parellel run
#                symbol count is bigger then date count, put symbol in the file is better
#       Method2: multiprocessing share memory, and finally dump
#
# From small->big
#    Each <feature_label pair, symbol, date> is a atmoic item, we need aggregate
#

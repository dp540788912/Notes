# -*- coding: utf-8 -*-

# from my.simu.components.data_factory.business import ContractParser
from my.data import tradelist_api

def load(*args):

    if (len(args) == 2):
        product = args[0]
        symbol = args[1]

        if (isinstance(symbol, list)):
            return symbol

        return load_by_product_symbol(
                product,
                symbol)

    elif (len(args) == 3):
        product = args[0]
        refer_date = args[1]
        group_name = args[2]

        return load_by_product_refer_date_group_name(
                product,
                refer_date,
                group_name)

    return []


def load_by_product_symbol(
        product,
        symbol):
    refer_date = symbol.refer_date
    group_name = symbol.group_name

    return load_by_product_refer_date_group_name(
            product,
            refer_date,
            group_name)


# refer_date: 2019-04-18
# group_name: HS300
# def load_by_product_refer_date_group_name(
#         product,
#         refer_date,
#         group_name):
#     print(product, refer_date, group_name)
#
#     tag = group_name + "|I|accountX"
#     refer_date = refer_date.replace('-', '')
#
#     symbol_info_list1, has_stock, symbol_info_list2, msg =\
#         ContractParser(refer_date, 0, [tag]).exec(False, [], [])
#
#     symbol_list = []
#
#     for symbol_info in symbol_info_list1:
#         if (len(symbol_info) >= 2):
#             code = symbol_info[0]
#             exchange = convert_exchange(symbol_info[1])
#             symbol = code + '.' + exchange
#             symbol_list.append(symbol)
#
#     symbol_list.sort()
#
#     return symbol_list


def load_by_product_refer_date_group_name(
        product,
        refer_date,
        group_name):
    refer_date = refer_date.replace('-', '')
    symbol_list = sorted([str(s, 'utf-8')for s in tradelist_api.get_con_stock(refer_date, group_name)])
    return symbol_list

def convert_exchange(exchange):
    if (exchange == 'SZSE'):
        return 'SZ'
    elif (exchange == 'SSE'):
        return 'SH'

    return exchange

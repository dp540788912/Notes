# -*- coding: utf-8 -*-


import numpy as np
import os

from my.data import my_types

def load_np(
        file_path,
        remove_not_trade_exchange_time = True):
    #print('load_np:', file_path)

    if not os.path.isfile(file_path):
        return None

    raw_np = np.fromfile(file_path, my_types.numpy_share_factor_dtype)

    real_count = raw_np[0][4][6]
    # exchange_time = raw_np[0][4][2]

    if remove_not_trade_exchange_time:
        np_list = []
        for r in raw_np:
            if ((r[4][2] >= 93000000 and r[4][2] <= 113000000) or
               (r[4][2] >= 130000000 and r[4][2] <= 150000000)):
                   np_list.append(r[4][7][:real_count])
    else:
        np_list = [r[4][7][:real_count] for r in raw_np]

    data_np = np.stack(np_list, axis=0)

    return data_np



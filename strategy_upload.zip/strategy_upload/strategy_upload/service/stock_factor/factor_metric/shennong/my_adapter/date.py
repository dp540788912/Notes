# -*- coding: utf-8 -*-



from my.data import meta_api
from dateutil.parser import parse

def load(*args):

    if (len(args) == 2):
        product = args[0]
        date = args[1]

        if (isinstance(date, list)):
            return date

        return load_by_product_date(
                product,
                date)

    elif (len(args) == 3):
        product = args[0]
        start_date = args[1]
        end_date = args[2]

        return load_by_product_refer_date_group_name(
                product,
                refer_date,
                group_name)

    return []


def load_by_product_date(
        product,
        date):
    start_date = date.start_date
    end_date = date.end_date

    return load_by_product_start_date_end_date(
            product,
            start_date,
            end_date)


# start_date: 2019-04-18
# end_date: 2019-05-18
def load_by_product_start_date_end_date(
        product,
        start_date,
        end_date):

    return meta_api.get_trading_date_range(
        int(parse(start_date).strftime('%Y%m%d')),
        int(parse(end_date).strftime('%Y%m%d')), 'SSE'
    )
    # import pandas as pd
    # date_list = pd.date_range(
    #     start = start_date,
    #     end = end_date,)
    # date_list = [d.strftime('%Y-%m-%d') for d in date_list]

    #return date_list

# -*- coding: utf-8 -*-

import logging
import math
import numpy as np

from .function_decorator import func_io_wraps

logger = logging.getLogger(__name__)

@func_io_wraps
def calc_cos(nda_1, nda_2):
    # Input already handle inf/nan

    if nda_1.shape[0] == 0 or nda_2.shape[0] ==0:
        return np.nan

    covariance = np.dot(nda_1, nda_2)
    norm_1 = math.sqrt(np.square(nda_1).sum())
    norm_2 = math.sqrt(np.square(nda_2).sum())

    if norm_1 == 0 or norm_2 == 0:
        return np.nan

    cosine = covariance / (norm_1 * norm_2)

    return cosine


@func_io_wraps
def calc_corr(nda_1, nda_2):
    # Input already handle inf/nan

    if nda_1.shape[0] == 0 or nda_2.shape[0] ==0:
        return np.nan

    centralized_nda_1 = nda_1 - np.mean(nda_1)
    centralized_nda_2 = nda_2 - np.mean(nda_2)

    corr = calc_cos(centralized_nda_1, centralized_nda_2)

    return corr


@func_io_wraps
def preprocess_series_idx(se1, se2):
    # The input se1, se2 may have different length

    # Find the common index of two series
    # Special handle time-index duplicated and time-reversed

    logger.debug('origin se1.shape:{} se2.shape:{}'\
            .format(se1.shape, se2.shape))

    se1 = se1[~se1.index.duplicated(keep='first')]
    se2 = se2[~se2.index.duplicated(keep='first')]

    logger.debug('after remove duplicated, se1.shape:{} se2.shape:{}'\
            .format(se1.shape, se2.shape))

    se1 = se1.replace([np.inf, -np.inf], np.nan)
    se1 = se1.dropna()
    se2 = se2.replace([np.inf, -np.inf], np.nan)
    se2 = se2.dropna()

    logger.debug('after drop nan/inf, se1.shape:{} se2.shape:{}'\
            .format(se1.shape, se2.shape))

    common_idx = se1.index.intersection(se2.index)
    se1 = se1.loc[common_idx]
    se2 = se2.loc[common_idx]

    logger.debug('after loc common idx, se1.shape:{} se2.shape:{}'\
            .format(se1.shape, se2.shape))

    return se1, se2


@func_io_wraps
def preprocess_nda_idx_according_nda2(nda1, nda2):

    # The input nda1 and nda2 should have same length

    logger.debug('origin nda1.shape:{} nda2.shape:{}'\
            .format(nda1.shape, nda2.shape))

    # Generate the nda2 mask
    mask  = np.isnan(nda2) | np.isinf(nda2) | np.isneginf(nda2)

    # Use nda2 mask filter nda1 and nda2
    nda2 = nda2[~mask]
    nda1 = nda1[~mask]

    # Handle nda1 remaining nan, inf, -inf
    nda1_mask = np.isnan(nda1) | np.isinf(nda1) | np.isneginf(nda1)
    nda1_invalid_count = np.sum(nda1_mask)

    nda1[np.isnan(nda1)] = 0
    nda1[np.isinf(nda1)] = 0
    nda1[np.isneginf(nda1)] = 0

    return nda1, nda2, nda1_invalid_count

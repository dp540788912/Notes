# -*- coding: utf-8 -*-

import inspect
import logging

from functools import wraps
from multiprocessing import Pool


logger = logging.getLogger(__name__)

def func_io_wraps(func):

    # @wraps(func) will rewrite func.__name__/__doc__/__module__ to function_wrapper
    @wraps(func)
    def function_wrapper(*args, **kwargs):
        # Since use decorator, inspect.stack()[0][3] will be 'function_wrapper'
        # logger.debug('[func name] {0}'.format(inspect.stack()[0][3]))

        logger.debug('[func_name] {0}'.format(func.__name__))

        # Attension, decorator function wrapper will always add one more level
        logger.debug('[depth]     {0}'.format(len(inspect.stack())))

        logger.debug('[args_spec] {0}'.format(inspect.getfullargspec(func).args))

        logger.debug('[args]      {0}'.format(args))

        logger.debug('[kwargs]    {0}'.format(kwargs))

        return_value = func(*args, **kwargs)

        logger.debug('[return]    {0}'.format(return_value))

        return return_value

    return function_wrapper

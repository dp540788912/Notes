# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
import pytz

from datetime import datetime, timedelta

def any_type_datetime_to_pd_timestamp(any_type_datetime):
    pd_timestamp = pd.to_datetime(any_type_datetime)

    # In [0]: dt = "2019-04-16 18:32:00 +09:00"
    # In [1]: pd_ts = pd.to_datetime(dt)
    # In [2]: print(pd_ts)
    # 2019-04-16 09:32:00
    # In [3]: print(pd_ts.tz)
    # None
    #
    # We manually add the tzinfo back because
    # pd.to_datetime has bug that tzinfo is None after conversion
    pd_timestamp = pd_timestamp.replace(tzinfo = pytz.utc)
    return pd_timestamp

def any_type_datetime_to_date_string(any_type_datetime):
    pd_timestamp = pd.to_datetime(any_type_datetime)
    return pd_timestamp.strftime('%Y-%m-%d')

def any_type_datetime_to_datetime_string(any_type_datetime):
    pd_timestamp = pd.to_datetime(any_type_datetime)
    return pd_timestamp.strftime('%Y-%m-%d %H:%M:%S')

def any_type_datetime_to_datetime_type(any_type_datetime):
    pd_timestamp = pd.to_datetime(any_type_datetime)
    return pd_timestamp.date()

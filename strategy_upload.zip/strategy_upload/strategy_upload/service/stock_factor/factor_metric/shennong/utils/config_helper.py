# -*- coding: utf-8 -*-

import logging
import json

logger = logging.getLogger(__name__)

#
# Recursively load json config
# All the inner json_file_path will be expanded
#
def load_json_config(json_file_path):

    root_json_dict = {}
    with open(json_file_path) as f:
       root_json_dict = json.load(f)

    dict_queue = []
    dict_queue.append(root_json_dict)

    while (len(dict_queue) > 0):
        current_json = dict_queue[0]

        if (isinstance(current_json, dict)):
            for k,v in current_json.items():
                if (isinstance(v, str)) and (v.endswith('.json')):
                    succeed, json_dict = load_json_config(v)
                    if not succeed:
                        logger.error('Failed to load json config file path:' + v)
                        return False, {}
                    print('v:',v, ' json:',json_dict)
                    current_json[k] = json_dict

                if (isinstance(v, dict)) or (isinstance(v, list)):
                    dict_queue.append(v)

        elif (isinstance(current_json, list)):
            for i in range(len(current_json)):
                v = current_json[i]
                if (isinstance(v, str)) and (v.endswith('.json')):
                    succeed, json_dict = load_json_config(v)
                    if not succeed:
                        logger.error('Failed to load json config file path:' + v)
                        return False, {}
                    print('v:',v, ' json:',json_dict)
                    current_json[i] = json_dict


                if (isinstance(v, dict)) or (isinstance(v, list)):
                    dict_queue.append(v)

        dict_queue = dict_queue[1:]

    return True, root_json_dict



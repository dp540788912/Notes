# -*- coding: utf-8 -*-

import logging
import json
import os

from datetime import datetime
from collections import namedtuple

FALLBACK_JSON_CONFIG_PATH = "./config.json"

logger = logging.getLogger(__name__)

#
# Load args json config to json_dict
# Use command line args update json_dict
# And finally generate a new args(object)
#
# not_to_object_property_key_list is used for following cases
#
# Case 1: key may contain &, cannot convert to variable
#
# Case 2: the user want a dict type, not object property,
#         no need recusive unpack to object property
#
def parse_args_json_config(
        args,
        add_datetime_tag_key_list = [],
        not_to_object_property_key_list=[]):

    json_config_path = args.json_config_path
    if not json_config_path:
        logger.info(
            'Parse_args_json_config()'
            ' empty command_line_arg.json_config_path, use fallback:{}'.\
                    format(FALLBACK_JSON_CONFIG_PATH))
        json_config_path = FALLBACK_JSON_CONFIG_PATH
    else:
        logger.info(
            'Parse_args_json_config()'
            ' json_config_path:{}'.format(json_config_path))


    if not os.path.isfile(json_config_path):
        logger.warning(
            'Parse_args_json_config()'
            ' file not exist, json_config_path:{}'.format(json_config_path))
        args_dict = {}
    else:
        with open(json_config_path) as f:
            args_dict = json.load(f)

    args = combine_args_with_json_dict(
            args,
            args_dict,
            add_datetime_tag_key_list,
            not_to_object_property_key_list)

    return args

#
# Use args(object) update json_dict
# And finally generate a new args(object)
#
# not_to_object_property_key_list is used for following cases
#
# Case 1: key may contain &, cannot convert to variable
#
# Case 2: the user want a dict type, not object property,
#         no need recusive unpack to object property
#
def combine_args_with_json_dict(
        args,
        json_dict,
        add_datetime_tag_key_list,
        not_to_object_property_key_list):

    # Generate the combined dict
    args_dict = vars(args)
    for key, value in args_dict.items():
        # Only update those not None value
        if value:
            logger.info(
                    'Update args key:{}, value:{} from command line'.\
                            format(key, value))
            json_dict[key] = value

    # Store the not to object dict values
    not_to_object_property_tmp_map = {}
    for key in not_to_object_property_key_list:
        not_to_object_property_tmp_map[key] = json_dict[key]
        json_dict[key] = None

    # Handle add datetime tag key list
    datetime_tag = datetime.today().strftime('%Y%m%d%H%M%S')
    for key in add_datetime_tag_key_list:
        if not json_dict[key] is None:
            json_dict[key] += '_' + datetime_tag

    # Generate the args object
    # Use json.loads to recursively generate the object
    args = json.loads(
            json.dumps(json_dict),
            object_hook=lambda d: namedtuple('X', d.keys())(*d.values()))

    # Assign back the special handle property
    # Since namedturple object is read-only, must replace
    for key in not_to_object_property_key_list:
        args = args._replace(key = not_to_object_property_tmp_map[key])

    return args


# -*- coding: utf-8 -*-

import inspect
import logging

from functools import wraps
from multiprocessing import Pool


logger = logging.getLogger(__name__)

def multiprocess_runner(
        func,
        multiprocess_count,
        param_turple_list):

    p = Pool(processes = multiprocess_count)
    result = p.starmap(
            func,
            param_turple_list)
    p.close()
    p.join()

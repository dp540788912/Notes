# -*- coding: utf-8 -*-

import logging
import collections

logger = logging.getLogger(__name__)

def update_nested_dictionary(d, u):
    for k, v in u.items():
        if isinstance(v, collections.Mapping):
            d[k] = update_nested_dictionary(d.get(k, {}), v)
        else:
            d[k] = v
    return d

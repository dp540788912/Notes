# -*-coding:utf-8-*-

import datetime
import os
import pandas as pd

from dateutil.parser import parse
from extensions import sentry
from db import session

from service.stock_factor.models import StockFactorStrategy


def get_alpha(factor_id, trading_date):
    from my.data import quote
    this_alpha = quote.factor(int(trading_date), 280, factor_id, 0, 0, pandas=True)
    this_alpha = this_alpha.drop(columns=['fid', 'exch_time', 'local_time', 'date', 'elapsed', 'count'])
    this_alpha['ticker'] = [str(int(x.decode()) + 1000000)[1:] + (".SH" if (int(x.decode()) >= 600000) else ".SZ") for x
                            in this_alpha['ticker']]
    this_alpha = this_alpha.set_index(['ticker'])
    return this_alpha


def get_check_bias_status(factor_id):
    res = {
        'status': '',
        'check_date': '',
    }

    sc = session()
    s = sc.query(StockFactorStrategy).filter(
        StockFactorStrategy.strategy_id == factor_id
    ).first()
    if not s:
        sc.close()
        return res

    res['status'] = s.check_bias_status
    res['check_date'] = s.check_bias_date
    sc.close()
    return res


def update_check_bias_status(factor_id, status, check_date=''):
    sc = session()
    s = sc.query(StockFactorStrategy).filter(
        StockFactorStrategy.strategy_id == factor_id
    ).first()
    if not s:
        sc.close()
        return False

    s.check_bias_status = status
    if check_date:
        s.check_bias_date = check_date
    sc.commit()
    sc.close()
    return True


def do_check_bias(factor_id, trading_date):
    check_status = get_check_bias_status(factor_id)
    s = check_status['status']

    if s in ['FINISHED', 'FAILED']:
        return True
    elif s == 'UNINIT':
        return check_bias_init(factor_id, trading_date)
    elif s == 'INITED':
        return check_bias_redo_check_date(factor_id, check_status['check_date'])
    elif s == 'REDO_CHECK_DATE' and trading_date == check_status['check_date']:
        try:
            return check_bias_compare(factor_id, check_status['check_date'])
        except Exception as e:
            sentry.captureException()
            update_check_bias_status(factor_id, 'FAILED')


def check_bias_init(factor_id, trading_date):
    now_date = datetime.datetime.now()
    now_date_str = now_date.strftime('%Y%m%d')

    if not ((trading_date > now_date_str) or (trading_date == now_date_str and now_date.hour <= 17)):
        return False

    npq_path = '/data/280/{year}/{trading_date}/0/0/{factor_id}.npq'.format(
        year=trading_date[:4],
        trading_date=trading_date,
        factor_id=factor_id,
    )

    if not os.path.exists(npq_path):
        return False

    dest = '/data/ev_alpha_evalue/new_factor_evalue/{factor_id}/checkbias'.format(factor_id=factor_id)
    if not os.path.exists(dest):
        os.makedirs(dest)

    dest_file = os.path.join(dest, '%s.csv' % trading_date)
    alpha = get_alpha(factor_id, trading_date)
    alpha.to_csv(dest_file)
    update_check_bias_status(factor_id, 'INITED', check_date=trading_date)
    return True


def check_bias_redo_check_date(factor_id, check_date):
    from cron.strategy_upload_task import redo_ev_task
    try:
        check_date = parse(check_date).strftime('%Y%m%d')
    except Exception as e:
        return False

    now_date = datetime.datetime.now().strftime('%Y%m%d')
    if now_date > check_date:
        redo_ev_task.delay(factor_id, check_date, end_date=check_date)
        update_check_bias_status(factor_id, 'REDO_CHECK_DATE')
    return True


def check_bias_compare(factor_id, check_date):
    check_date = parse(check_date).strftime('%Y%m%d')
    columns = ['factor', 'check_bias']
    values = []
    npq_path1 = '/data/ev_alpha_evalue/new_factor_evalue/{factor_id}/checkbias/{trading_date}.csv'.format(
        factor_id=factor_id,
        trading_date=check_date,
    )
    npq_path2 = '/data/280/{year}/{trading_date}/0/0/{factor_id}.npq'.format(
        year=check_date[:4],
        trading_date=check_date,
        factor_id=factor_id,
    )

    res_csv_file = '/data/ev_alpha_evalue/new_factor_evalue/{factor_id}/checkbias.csv'.format(
        factor_id=factor_id,
    )

    if not (os.path.exists(npq_path1) and os.path.exists(npq_path2)):
        return False

    df1 = pd.read_csv(npq_path1).set_index(['ticker']).fillna(0)
    df2 = get_alpha(factor_id, check_date).fillna(0)
    index = list(df1.index)

    for f in df1.columns:
        r = True
        for i in index:
            x1 = df1.loc[i][f]
            x2 = df2.loc[i][f]
            if (x1 == 0 or x2 == 0) and (abs(x1 - x2) > 0.0001):
                r = False
            else:
                x_diff = abs((x1 - x2) / x1)
                if x_diff > 0.0001:
                    r = False
        values.append([f, r])

    pd.DataFrame(values, columns=columns).to_csv(res_csv_file, index=False)
    update_check_bias_status(factor_id, 'FINISHED')

    try:
        output_path = '/data/ev_alpha_evalue/new_factor_evalue'
        check_file_path = os.path.join(output_path, str(factor_id), 'check22.csv')
        check_df = pd.read_csv(check_file_path)
        if 'Unnamed: 0' in check_df.columns:
            check_df = check_df.drop(columns=['Unnamed: 0'])

        check_df = check_df.set_index(['factor'])
        for v in values:
            if not v[1]:
                check_df.loc[v[0], 'final_s'] = False
        check_df.to_csv(check_file_path)
    except Exception as e:
        sentry.captureException()
    return True

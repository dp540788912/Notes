# -*-coding:utf-8-*-


from service.stock_factor.handlers import *

urls = [

    (r'/api/v1/platform/stock_factor$', GetStockFactorHandler),

    (r'/api/v1/platform/stock_factor/strategy$', GetStockFactorStrategyHandler),

    (r'/api/v1/platform/stock_factor/estimation/strategy$', GetStockFactorEstimationStrategyHandler),

    (r'/api/v1/platform/stock_factor/publish/(?P<id>\d+)$', StockFactorPublishHandler),
    (r'/api/v1/platform/stock_factor/columns/(?P<id>\d+)$', StockFactorColumnsHandler),

    (r'/api/v1/platform/stock_factor/estimation/indicator$', StockFactorEstimationIndicatorHandler),

    (r'/api/v1/platform/stock_factor/estimation/daily/indicator/(?P<id>\d+)$',
     StockFactorEstimationDailyIndicatorHandler),

    (r'/api/v1/platform/stock_factor/estimation/daily/pnl/(?P<id>\d+)$', StockFactorEstimationDailyPnlHandler),

    (r'/api/v1/platform/stock_factor/estimation/time-series/indicator$',
     StockFactorEstimationTimeSeriesIndicatorHandler),

    (r'/api/v1/platform/stock_factor/vstrategy/deploy/config$', VstrategyDeployConfig),

    (r'/api/v1/platform/factor/quote$', StockFactorQuoteHandler),
    # 因子上传页面
    (r'/api/v1/platform/factor/strategy$', StockFactorStrategyHandler),
    # 因子上传页面，开始生产按钮
    (r'/api/v1/platform/factor/strategy/(?P<id>\d+)$', StockFackotStrategyDetailHandler),
    (r'/api/v1/platform/factor/strategy/new_version/(?P<id>\d+)$', StockFactorStrategyNewVersionHandler),
    (r'/api/v1/platform/factor/strategy/judge/(?P<id>\d+)$', StockFactorjudgeDetailHandler),
    (r'/api/v1/platform/factor/strategy/judge/daily/(?P<id>\d+)$', StockFactorjudgeDailyDetailHandler),

    (r'/api/v1/platform/factor/strategy/judgeind$', StockFactorjudgeIndHandler),
    (r'/api/v1/platform/factor/evalue/alpha/strategy$', StockFactorEvalueStrategyHandler),
    (r'/api/v1/platform/factor/pool$', StockFactorPoolHandler),
    (r'/api/v1/platform/factor/pool/(?P<id>\d+)$', StockFactorPoolDetailHandler),

    (r'/api/v1/platform/factor/basic$', GetBasicFactorBriefHandler),

    # 因子评审2.0页面
    (r'/api/v1/platform/factor/performance/judge/(?P<id>\d+)$', StockFactorPerformanceJudgeDetailHandler),
    # 因子库2，评估按钮
    (r'/api/v1/platform/factor/pool/estimation/indicator$', StockPoolEstimationIndicatorHandler),

    (r'/api/v1/platform/factor/pool/pnl/indicator/(?P<id>\d+)$', StockFactorPnlIndicatorHandler),
    # 因子策略bias状态，重置check bias状态
    (r'/api/v1/platform/factor/strategy/bias_status$', StockFactorBiasStatusHandler),
]

# -*-coding:utf-8-*-
import json
import os
import datetime
import requests
import numpy as np

from my.data import meta_api, config, quote, my_types

strategy_factor_dtype_flatten = np.dtype([
    ('fid', 'i8'),
    ('ticker', 'S32'),
    ('exch_time', 'i8'),  # ms
    ('local_time', 'i8'), # us
    ('elapsed_time', 'i8'),
    ('date', 'i4'),
    ('count', 'i4'),
    ('value', 'f8', 300),
], align=True)

numpy_share_factor_dtype = np.dtype([
    ('serial', 'i4'),
    ('mi_type', 'i4'),
    ('local_time', 'i8'),
    ('exchange_time', 'i8'),     # exchange_time = local_time
    ('quote', strategy_factor_dtype_flatten),
], align=True)

def to_timestamp(in_date: str, in_time: str) -> int:
    dt = datetime.datetime.strptime('%s-%s000' % (in_date, in_time), '%Y%m%d-%H%M%S%f')
    return int(dt.timestamp() * 1000 * 1000)


def us_to_timestamp(in_date: str, in_time: str) -> int:
    dt = datetime.datetime.strptime('%s-%s' % (in_date, in_time), '%Y%m%d-%H%M%S%f')
    return int(dt.timestamp() * 1000 * 1000)


class StockEvGenerateFactor(object):

    def __init__(self, ev_generate_config, *args, **kwargs):
        self.ev_generate_config = ev_generate_config
        self.trading_date = ev_generate_config['date'].replace('.', '')
        self.day_night = int(ev_generate_config['day_night'])
        self.day_night_str = {
            0: 'day',
            1: 'night'
        }[self.day_night]

        self.factors = {}

        self.factor_head = ['fid', 'ticker', 'exch_time', 'local_time', 'elapsed_time', 'date', 'count', 'value']
        self.notify_api = ev_generate_config.get('notify_api', '')

    def send_factor(self, fid, ticker, date, exch_time, local_time, factors=None):
        if factors is None or not isinstance(factors, list):
            return False
        f = {
            'fid': fid,
            'ticker': ticker,
            'exch_time': exch_time,
            'local_time': local_time,
            'elapsed_time': 0,
            'date': date,
            'count': len(factors),
            'value': factors[:],
        }
        fid_factors = self.factors.setdefault(fid, {})
        fid_day_factors = fid_factors.setdefault(date, [])
        fid_day_factors.append(f)
        return True

    def send_factor_rows(self, fid, rows):
        fid_factors = self.factors.setdefault(fid, {})
        for r in rows:
            len_r = len(r)
            if len_r < 5:
                raise ValueError(
                    """factor error data error, must 'ticker, date, exch_time, local_time, v1, v2, v3...' """
                )
            f = {
                'fid': fid,
                'ticker': r[0],
                'exch_time': r[2],
                'local_time': r[3],
                'elapsed_time': 0,
                'date': r[1],
                'count': len_r - 4,
                'value': r[4:],
            }
            fid_day_factors = fid_factors.setdefault(f['date'], [])
            fid_day_factors.append(f)
        return True

    def send_factor_columns(self, fid, columns):
        try:
            if self.notify_api:
                requests.post(self.notify_api, json={
                    'event': 'SendFactorColumns',
                    'content': {
                        'fid': fid,
                        'columns': columns,
                    }
                })
        except Exception as e:
            pass
        with open('/data/280/meta/{st_id}.csv'.format(st_id=fid), 'w') as f:
            f.write(','.join(columns))
        return True

    def write_npq(self):
        for f_id, fid_factors in self.factors.items():
            for trading_date, lines in fid_factors.items():
                target = '{base_dir}/{mi_type}/{year}/{date}/{dn}/{source}/{fid}.npq'.format(**{
                    'base_dir': config.NpqData.base_path,
                    'mi_type': quote.MI_TYPE.MI_SHARE_FACTOR.new_book,
                    'year': int(str(trading_date)[0:4]),
                    'date': trading_date,
                    'dn': 0,
                    'source': 0,
                    'fid': f_id,
                })
                npq_data = np.zeros(shape=len(lines), dtype=numpy_share_factor_dtype)
                for idx, line in enumerate(lines):
                    npq_data['serial'][idx] = idx
                    npq_data['mi_type'][idx] = quote.MI_TYPE.MI_SHARE_FACTOR.value
                    exch_time_stamp = to_timestamp(line['date'], line['exch_time'])
                    local_time_stamp = us_to_timestamp(line['date'], line['local_time'])
                    npq_data['local_time'][idx] = local_time_stamp
                    npq_data['exchange_time'][idx] = exch_time_stamp
                    quote_ref = npq_data['quote'][idx]
                    quote_ref['fid'] = int(line['fid'])
                    quote_ref['ticker'] = line['ticker']
                    quote_ref['exch_time'] = int(line['exch_time'])
                    quote_ref['local_time'] = int(line['local_time'])
                    quote_ref['elapsed_time'] = int(line.get('elapsed_time', 0))
                    quote_ref['date'] = int(line['date'])
                    quote_ref['count'] = int(line['count'])
                    values = line['value']
                    for jdx in range(quote_ref['count']):
                        if values[jdx] in ['True', 'true']:
                            values[jdx] = 1.0
                        elif values[jdx] in ['False', 'false']:
                            values[jdx] = 0.0
                        else:
                            quote_ref['value'][jdx] = np.float(values[jdx])
                if not os.path.isdir(os.path.dirname(target)):
                    os.makedirs(os.path.dirname(target))
                npq_data.tofile(target)
        return True



def generate_strategy_config(cfg):
    start_date = cfg['start_date']
    end_date = cfg['end_date']
    factor_id = cfg['factor_id']
    # ===========User Code===========
    from my.data import tradelist_api
    from my.data import meta_api
    days = [d.replace('-', '') for d in meta_api.get_trading_date_range(int(start_date), int(end_date), 'SSE')]
    factor_columns = ['f_%s' % i for i in range(30)]
    columns = ['ticker', 'date', 'exch_time', 'local_time'] + factor_columns
    values = []
    for d in days:
        symbols = sorted([str(s, 'utf-8').split('.')[0] for s in tradelist_api.get_con_stock(d, 'HSA')])
        for s in symbols:
            values.append([
                s, d, 150000000,150000000
            ] + list(np.random.rand(30)))
    factor_generate = StockEvGenerateFactor(cfg)
    factor_generate.send_factor_columns(factor_id, factor_columns)
    factor_generate.send_factor_rows(factor_id, values)
    factor_generate.write_npq()
    return True


if __name__ == '__main__':
    import sys
    cfg = sys.argv[1]
    tradelist = generate_strategy_config(json.loads(cfg))

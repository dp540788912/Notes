# encodin: utf-8
# cython: language_level=3
import json
import sys
import shutil
import pandas as pd
import numpy as np
import datetime
import os
import requests
import time
from my.data import basic_func

def get_datelist(begT,endT,dback=0,dnext=0):
    sqlstr = "select date:TRADE_DT from Calendar where EXCHANGE=`SSE"
    database = 'FuturesBasicInfo'
    data = basic_func.get_kdb(sqlstr, database)

    beg_index = data[data['date']>=qdate(begT,False)].index[0]-dback
    end_index = data[data['date']<=qdate(endT,False)].index[-1]+dnext
    data = data.loc[beg_index:end_index, :].reset_index(drop=True)
    return data


def get_stocklist(endT):
    sqlstr = '`code xasc select code:SYMBOL,ipodate:S_INFO_LISTDATE from AShareDescription where S_INFO_LISTDATE <= ' + qdate(endT) + ' ,( (S_INFO_DELISTDATE > ' + qdate(endT) + ') or (S_INFO_DELISTDATE = 0Nd) ) '
    database = 'EquityFactor'
    data = basic_func.get_kdb(sqlstr, database)
    if not data.empty: data.loc[:,'code'] = data.loc[:,'code'].apply(lambda x:x.decode()).tolist()
    return data

def qdate(date, is_str=True, sep='.'):
    date = datetime.datetime.strptime(str(date), "%Y%m%d")
    if is_str: date = date.strftime("%Y" + sep + "%m" + sep + "%d")
    return date


def factor_evalue_date_range(cfg):

    path = cfg['basic_data_path']

    strategy_name = '{}_{}_{}'.format(cfg['strategy_id'],cfg['pool_range'],cfg['predict_cycle'])

    if not os.path.exists(path + 'factor_evalue_cycle/'): os.makedirs(path + 'factor_evalue_cycle/')
    if not os.path.exists(path + 'factor_evalue_cycle/' + strategy_name + '/'): os.makedirs(path + 'factor_evalue_cycle/' + strategy_name + '/')

    datelist = get_datelist(cfg['begT'], cfg['endT'], 0, 0)

    begT = datelist.date.iloc[0]
    endT = datelist.date.iloc[-1]
    cfg['_begT'] = begT
    cfg['_endT'] = endT

    output_path = path + 'factor_evalue_cycle/' + strategy_name + '/' + '{}_{}_indicator'.format(begT.strftime("%Y%m%d"),endT.strftime("%Y%m%d")) + '.csv'


    if not os.path.exists(output_path):
        evalue_dict = {'ic': [], 'ac': [], 'tr': [], 'cr': [], 'ret': []}
        # date = datelist.date.iloc[0]
        for date in datelist.date:
            print(date)
            date_int = date.strftime("%Y%m%d")
            daily_path = path + 'factor_evalue_daily/' + strategy_name  +'/' + date_int + '.csv'

            evalue_daily = pd.read_csv(daily_path, index_col=0)
            evalue_dict['ic'].append(evalue_daily['ic'].to_frame(date_int))
            evalue_dict['ac'].append(evalue_daily['ac'].to_frame(date_int))
            evalue_dict['tr'].append(evalue_daily['tr'].to_frame(date_int))
            evalue_dict['cr'].append(evalue_daily['cr'].to_frame(date_int))
            evalue_dict['ret'].append(evalue_daily['ret'].to_frame(date_int))

        evalue_dict['ic'] = pd.concat(evalue_dict['ic'], axis=1)
        evalue_dict['ac'] = pd.concat(evalue_dict['ac'], axis=1)
        evalue_dict['tr'] = pd.concat(evalue_dict['tr'], axis=1)
        evalue_dict['cr'] = pd.concat(evalue_dict['cr'], axis=1)
        evalue_dict['ret'] = pd.concat(evalue_dict['ret'], axis=1)

        ic = evalue_dict['ic'].mean(axis=1).to_frame('ic')
        _sign = np.sign(ic['ic'])
        ir = (ic / evalue_dict['ic'].std(axis=1).to_frame('ic')).rename(columns={'ic':'ir'})
        cr = evalue_dict['cr'].mean(axis=1).to_frame('cr')
        ac = evalue_dict['ac'].mean(axis=1).to_frame('ac')
        tr = evalue_dict['tr'].mean(axis=1).to_frame('tr')

        ret_table = evalue_dict['ret']
        pnl = pd.DataFrame(0, index = ret_table.index, columns = ret_table.columns)
        _max = pd.Series(0, index = ret_table.index)
        mdd = pd.Series(0, index = ret_table.index)

        for idx, key in enumerate(ret_table.columns):
            if idx==0: pnl.iloc[:,idx] = ret_table.iloc[:,idx]/100 * _sign.values
            else: pnl.iloc[:,idx] = pnl.iloc[:,idx-1] + ret_table.iloc[:,idx]/100 * _sign

            _max = pd.concat([_max, pnl.iloc[:,idx]], axis=1).max(axis=1)
            dd = _max - pnl.iloc[:,idx]
            mdd = pd.concat([dd, mdd], axis=1).max(axis=1)

        mdd = mdd.to_frame('mdd')
        ret = pnl.iloc[:,-1].to_frame('ret')/len(datelist)*250
        sr = (ret_table.mean(axis=1)/ret_table.std(axis=1)*np.sqrt(250)* _sign.values).to_frame('sr')
        ic = np.abs(ic)

        evalue_output = pd.concat([ic, np.abs(ir), cr, ret, mdd, sr, ac, tr], axis=1)

        evalue_output.to_csv(output_path)
        pnl.to_csv(output_path.replace('_indicator','_pnl'))
        ic.to_csv(output_path.replace('_indicator', '_ic'))
        evalue_dict['ic'].to_csv(output_path.replace('_indicator', '_icdaily'))

"""
factor_id = 210474

begT = 20160201
endT = 20171231

cfg= {
      "strategy_id": factor_id,
      "pool_range": 'top2000',
      "predict_cycle": 'v1',
      'begT': begT,
      'endT': endT
      }
factor_evalue_date_range(cfg)
"""



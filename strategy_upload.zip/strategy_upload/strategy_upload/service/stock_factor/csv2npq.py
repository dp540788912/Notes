# -*- coding: utf-8 -*-

import copy
import datetime
import os

import numpy as np
from my.data import meta_api, config, quote, my_types

HOMESPACE = '/home/rss/jupyter_userworkspace'
LOCAL_DIR = '.'
day_night_m = {0: 'day', 1: 'night'}


class TargetType:
    POSITION = 0
    FACTOR = 1

# factor
strategy_factor_dtype_flatten = np.dtype([
    ('fid', 'i8'),
    ('ticker', 'S32'),
    ('exch_time', 'i8'),  # ms
    ('local_time', 'i8'), # us
    ('elapsed_time', 'i8'),
    ('date', 'i4'),
    ('count', 'i4'),
    ('value', 'f8', 300),
], align=True)

numpy_share_factor_dtype = np.dtype([
    ('serial', 'i4'),
    ('mi_type', 'i4'),
    ('local_time', 'i8'),
    ('exchange_time', 'i8'),     # exchange_time = local_time
    ('quote', strategy_factor_dtype_flatten),
], align=True)

def to_timestamp(in_date: str, in_time: str) -> int:
    dt = datetime.datetime.strptime('%s-%s000' % (in_date, in_time), '%Y%m%d-%H%M%S%f')
    return int(dt.timestamp() * 1000 * 1000)


def us_to_timestamp(in_date: str, in_time: str) -> int:
    dt = datetime.datetime.strptime('%s-%s' % (in_date, in_time), '%Y%m%d-%H%M%S%f')
    return int(dt.timestamp() * 1000 * 1000)


def csv_to_npq(ttype: int, source: str, target: str) -> None:
    lines = []
    with open(source) as f:
        title_line = f.readline()
        titles = title_line.rstrip('\n').split(',')
        if 'date' not in titles or 'exch_time' not in titles or 'local_time' not in titles:
            print("the title is %s", titles)
            raise ValueError("csv title not valid")
        split_size = len(titles) - 1
        for data_line in f.readlines():
            data_line = data_line.rstrip('\n')
            values = data_line.split(',', split_size)
            line = dict(zip(titles, values))
            lines.append(line)

    if ttype == TargetType.FACTOR:
        npq_data = np.zeros(shape=len(lines), dtype=numpy_share_factor_dtype)
        for idx, line in enumerate(lines):
            # print(line)
            npq_data['serial'][idx] = idx
            npq_data['mi_type'][idx] = quote.MI_TYPE.MI_SHARE_FACTOR.value
            exch_time_stamp = to_timestamp(line['date'], line['exch_time'])
            local_time_stamp = us_to_timestamp(line['date'], line['local_time'])
            npq_data['local_time'][idx] = local_time_stamp
            npq_data['exchange_time'][idx] = exch_time_stamp
            quote_ref = npq_data['quote'][idx]
            quote_ref['fid'] = int(line['fid'])
            quote_ref['ticker'] = line['ticker']
            quote_ref['exch_time'] = int(line['exch_time'])
            quote_ref['local_time'] = int(line['local_time'])
            quote_ref['elapsed_time'] = int(line.get('elapsed_time', 0))
            quote_ref['date'] = int(line['date'])
            quote_ref['count'] = int(line['count'])
            values = line['value'].rstrip('\n').split(',')
            for jdx in range(quote_ref['count']):
                if values[jdx] in ['True', 'true']:
                    values[jdx] = 1.0
                elif values[jdx] in ['False', 'false']:
                    values[jdx] = 0.0
                else:
                    quote_ref['value'][jdx] = np.float(values[jdx])
        if not os.path.isdir(os.path.dirname(target)):
            os.makedirs(os.path.dirname(target))
        npq_data.tofile(target)
    elif ttype == TargetType.POSITION:
        npq_data = np.zeros(shape=len(lines), dtype=my_types.numpy_share_position_dtype)
        for idx, line in enumerate(lines):
            npq_data['serial'][idx] = idx
            npq_data['mi_type'][idx] = quote.MI_TYPE.MI_SHARE_POSITION.value
            exch_time_stamp = to_timestamp(line['date'], line['exch_time'])
            local_time_stamp = us_to_timestamp(line['date'], line['local_time'])
            npq_data['local_time'][idx] = local_time_stamp
            npq_data['exchange_time'][idx] = exch_time_stamp
            quote_ref = npq_data['quote']
            quote_ref['fid'][idx] = int(line['fid'])
            quote_ref['exch_time'][idx] = int(line['exch_time'])
            quote_ref['local_time'][idx] = int(line['local_time'])
            quote_ref['date'][idx] = int(line['date'])
            quote_ref['ticker'][idx] = line['ticker']
            quote_ref['volume'][idx] = int(line['volume'])
            quote_ref['account'][idx] = line['account']
            quote_ref['reserved'][idx] = line['reserved']
        if not os.path.isdir(os.path.dirname(target)):
            os.makedirs(os.path.dirname(target))
        npq_data.tofile(target)


def gen_factor(user: str, user_id: int, fid: int, start: int, end: int, daynight: int, source: str = '0') -> None:
    trading_dates = meta_api.get_new_trading_date_range(start, end)
    enum_dn = [daynight] if daynight in (0, 1) else [0, 1]
    for t_trading_date, has_night in trading_dates:
        if not has_night and 1 in enum_dn:
            enum_dn_t = copy.deepcopy(enum_dn).remove(1)
        else:
            enum_dn_t = enum_dn
        for dn in enum_dn_t:
            trading_date = int(t_trading_date.replace('-', ''))
            original = '{share_base}/{user_id}_{user}/platform_data/factor/{fid}/{trading_date}_{dn}.csv'.format(**{
                'user_id': user_id,
                'user': user,
                'trading_date': trading_date,
                'dn': day_night_m[dn],
                'fid': fid,
                'share_base': HOMESPACE
            })
            target = '{base_dir}/{mi_type}/{year}/{date}/{dn}/{source}/{fid}.npq'.format(**{
                'base_dir': config.NpqData.base_path,
                'mi_type': quote.MI_TYPE.MI_SHARE_FACTOR.new_book,
                'year': int(str(trading_date)[0:4]),
                'date': trading_date,
                'dn': dn,
                'source': source,
                'fid': fid,
            })
            if os.path.isfile(original):
                csv_to_npq(TargetType.FACTOR, original, target)
            else:
                print("factor path %s not exist" % original)


def gen_position(user: str, user_id: int, fid: int, start: int, end: int, daynight: int, source: str = '0') -> None:
    trading_dates = meta_api.get_new_trading_date_range(start, end)
    enum_dn = [daynight] if daynight in (0, 1) else [0, 1]
    for t_trading_date, has_night in trading_dates:
        if not has_night and 1 in enum_dn:
            enum_dn_t = copy.deepcopy(enum_dn).remove(1)
        else:
            enum_dn_t = enum_dn
        for dn in enum_dn_t:
            trading_date = int(t_trading_date.replace('-', ''))
            original = '{share_base}/{user_id}_{user}/platform_data/position/{fid}/{trading_date}_{dn}.csv'.format(
                **{
                    'user_id': user_id,
                    'user': user,
                    'trading_date': trading_date,
                    'dn': day_night_m[dn],
                    'fid': fid,
                    'share_base': HOMESPACE
                }
            )
            target = '{base_dir}/{mi_type}/{year}/{date}/{dn}/{source}/{fid}.npq'.format(**{
                'base_dir': config.NpqData.base_path,
                'mi_type': quote.MI_TYPE.MI_SHARE_POSITION.new_book,
                'year': int(str(trading_date)[0:4]),
                'date': trading_date,
                'dn': dn,
                'source': source,
                'fid': fid,
            })
            if os.path.exists(original):
                csv_to_npq(TargetType.POSITION, original, target)
            else:
                print("position path %s not exist" % original)


def local_gen_position(fid: int, start: int, end: int, daynight: int, path: str) -> None:
    trading_dates = meta_api.get_new_trading_date_range(start, end)
    enum_dn = [daynight] if daynight in (0, 1) else [0, 1]
    for t_trading_date, has_night in trading_dates:
        if not has_night and 1 in enum_dn:
            enum_dn_t = copy.deepcopy(enum_dn).remove(1)
        else:
            enum_dn_t = enum_dn
        for dn in enum_dn_t:
            trading_date = int(t_trading_date.replace('-', ''))
            original_url = path.replace('[DATE]', '{trading_date}')\
                               .replace('[DAYNIGHT]', '{dn}')\
                               .replace('[F_ID]', '{fid}')
            original = original_url.format(**{'trading_date': trading_date, 'dn': day_night_m[dn], 'fid': fid})
            target = '{base_dir}/{mi_type}/{year}/{date}/{dn}/{source}/{fid}.npq'.format(**{
                'base_dir': LOCAL_DIR,
                'mi_type': quote.MI_TYPE.MI_SHARE_POSITION.new_book,
                'year': int(str(trading_date)[0:4]),
                'date': trading_date,
                'dn': dn,
                'fid': fid,
                'source': '0'
            })
            print(original, " -> ", target)
            if os.path.exists(original):
                csv_to_npq(TargetType.POSITION, original, target)
            else:
                print("trading date %s not found position data" % trading_date)


def local_gen_factor(fid: int, start: int, end: int, daynight: int, path: str) -> None:
    trading_dates = meta_api.get_new_trading_date_range(start, end)
    enum_dn = [daynight] if daynight in (0, 1) else [0, 1]
    for t_trading_date, has_night in trading_dates:
        if not has_night and 1 in enum_dn:
            enum_dn_t = copy.deepcopy(enum_dn).remove(1)
        else:
            enum_dn_t = enum_dn
        for dn in enum_dn_t:
            trading_date = int(t_trading_date.replace('-', ''))
            original_url = path.replace('[DATE]', '{trading_date}') \
                               .replace('[DAYNIGHT]', '{dn}')
            original = original_url.format(**{'trading_date': trading_date, 'dn': day_night_m[dn]})
            target = '{base_dir}/{mi_type}/{year}/{date}/{dn}/{source}/{fid}.npq'.format(**{
                'base_dir': LOCAL_DIR,
                'mi_type': quote.MI_TYPE.MI_SHARE_FACTOR.new_book,
                'year': int(str(trading_date)[0:4]),
                'date': trading_date,
                'dn': dn,
                'source': '0',
                'fid': fid,
            })
            print(original, " -> ", target)
            if os.path.exists(original):
                csv_to_npq(TargetType.FACTOR, original, target)
            else:
                print("trading date %s not found factor data" % trading_date)


if __name__ == '__main__':
    # gen_factor('colin', 1, 1, 20190301, 20190301, 2)
    # gen_position('colin', 1, 1, 20190301, 20190301, 2)

    def test_read_pos(pos_file):
        data = np.fromfile(pos_file, dtype=my_types.numpy_share_position_dtype)
        #print(data)

    def test_read_factor(fat_file):
        data = np.fromfile(fat_file, dtype=numpy_share_factor_dtype)
        #print(data)

    # csv_to_npq(TargetType.POSITION, './live_data/20161010_day_position.csv', './pos.npq')
    # csv_to_npq(TargetType.FACTOR, './live_data/20161010_day_factor.csv', './factor.npq')
    # test_read_pos('./pos.npq')
    # test_read_factor('./factor.npq')
    local_gen_factor(100, 20161010, 20161013, 0, './live_data/[DATE]_[DAYNIGHT]_factor.csv')
    local_gen_position(100, 20161010, 20161013, 0, './live_data/[DATE]_[DAYNIGHT]_position.csv')


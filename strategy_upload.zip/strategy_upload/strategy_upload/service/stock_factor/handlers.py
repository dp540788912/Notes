# -*-coding:utf-8-*-

import json
import uuid
import time
import copy
import datetime
from dateutil.parser import parse
from sqlalchemy import or_
from tornado import gen

from db import session

from service.basehandler import BaseHandler, CurrentUserMixin, JsonPayloadMixin

from service.stock_factor.models import StockFactorStrategyColumns, StockFactorStrategy, \
    StockFactorEstimateStrategy, StockFactorEstimation, StockFactorVersion, FactorCombinationRelation
from service.stock_factor.factor_checkbias import check_bias_init
from service.back_test.models import Strategy, VStrategies, StrategyOwners, \
    StrategyUploadFile, StrategyResult, StockHedgeVs

from utils import send_email, notify_operation_wechat, del_cache

import consts
from constant import CompanyEmailGroup, StrategyConstant, APIResponseCode, StockFactorEvaluationQueueEvent
from utility.db_util import TradeCalendar
from config import config
from models.strategy import VsT0Relation


class GetStockFactorHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):

        sc = session()

        factors = sc.query(
            StockFactorStrategy
        ).filter(
            StockFactorStrategy.is_publish == True,
            StockFactorStrategy.is_delete == False,
            StockFactorStrategy.factor_type == 'FACTOR_INDAY',
            # StockFactorStrategy.strategy_id >= 211715,
        )

        data, factors_detail = [], {}

        for f in factors:
            factors_detail[f.strategy_id] = {
                'factor_id': f.strategy_id,
                'name': f.name,
                'columns': StockFactorStrategyColumns.get_factor_columns(f.strategy_id)
            }

        strategies = sc.query(
            Strategy.id.label('id'),
            Strategy.id_no.label('id_no'),

        ).filter(
            Strategy.id.in_(factors_detail.keys()),
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
        )
        strategy_detail = {}
        for s in strategies:
            strategy_detail[s.id] = {
                'id': s.id,
                'id_no': s.id_no,
            }

        for f_id, factor in sorted(factors_detail.items(), key=lambda _x: _x[0], reverse=True):
            if f_id not in strategy_detail:
                continue
            ticker = {
                'name': factor['name'],
                'children': [],
                'selectable': False,
            }
            ticker['children'].append({
                'type': 'stock_factor_FACTOR',
                'symbol': 'stock_factor_%s_ALL' % f_id,
                'name': 'ALL',
                'exch': 'SSE'
            })
            for c in factor['columns']:
                ticker['children'].append({
                    'type': 'stock_factor_FACTOR',
                    'symbol': 'stock_factor_%s_%s' % (f_id, c),
                    'name': c,
                    'exch': 'SSE'
                })
            data.append(ticker)
        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StockFactorQuoteHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        return factor detail to subscribe
        PAGE LOCATION: 因子研究->上传因子->新建->因子订阅
        """
        self.get_current_user()
        if not self.current_user:
            return False

        # assert request from ev-upload.html or factor-upload.html
        if 'ev-upload.html' in self.request.headers.get('Referer', ''):
            data = self.get_ev_quote()
            self.json_response({
                'code': 0,
                'data': data,
            })
            return True

        sc = session()

        factors = sc.query(
            StockFactorStrategy
        ).filter(
            StockFactorStrategy.is_publish == True,
            StockFactorStrategy.is_delete == False,
            StockFactorStrategy.strategy_id >= 211715,
        )

        data, factors_detail = [], {}

        basic_factor, user_factor = [], []
        for f in factors:
            factors_detail[f.strategy_id] = {
                'user_id': f.r_create_user_id,
                'factor_id': f.strategy_id,
                'name': f.name,
                'category': f.category,
                'columns': StockFactorStrategyColumns.get_factor_columns(f.strategy_id)
            }

        strategies = sc.query(
            Strategy.id.label('id'),
            Strategy.id_no.label('id_no'),

        ).filter(
            Strategy.id.in_(factors_detail.keys()),
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
        )
        strategy_detail = {}
        for s in strategies:
            strategy_detail[s.id] = {
                'id': s.id,
                'id_no': s.id_no,
            }

        for f_id, factor in sorted(factors_detail.items(), key=lambda _x: _x[0], reverse=True):
            if f_id not in strategy_detail:
                continue
            ticker = {
                'name': factor['name'],
                'children': [],
                'selectable': False,
            }
            ticker['children'].append({
                'type': 'stock_factor_FACTOR',
                'symbol': 'stock_factor_%s_ALL' % f_id,
                'name': 'ALL',
                'exch': 'SSE'
            })
            # for c in factor['columns']:
            #     ticker['children'].append({
            #         'type': 'stock_factor_FACTOR',
            #         'symbol': 'stock_factor_%s_%s' % (f_id, c),
            #         'name': c,
            #         'exch': 'SSE'
            #     })
            if factor['category'] == 'BASIC':
                basic_factor.append(ticker)
            elif factor['category'] == 'NORMAL' and factor['user_id'] == self.current_user['id']:
                user_factor.append(ticker)

        res = [
            {
                'name': '基础因子',
                'children': basic_factor,
                'selectable': False,
            },
            {
                'name': '我的因子',
                'children': user_factor,
                'selectable': False,
            }
        ]
        sc.close()
        self.json_response({
            'code': 0,
            'data': res,
        })
        return True

    def get_ev_quote(self, *args, **kwargs):
        sc = session()
        factors = sc.query(
            StockFactorStrategy
        ).filter(
            StockFactorStrategy.is_publish == True,
            StockFactorStrategy.is_delete == False,
            StockFactorStrategy.strategy_id >= 211715,
        )

        data, factors_detail = [], {}

        basic_factor, user_factor = [], []
        for f in factors:
            factors_detail[f.strategy_id] = {
                'user_id': f.r_create_user_id,
                'factor_id': f.strategy_id,
                'name': f.name,
                'category': f.category,
                'status': f.status,
                'columns': [],
            }

        strategies = sc.query(
            Strategy.id.label('id'),
            Strategy.id_no.label('id_no'),

        ).filter(
            Strategy.id.in_(factors_detail.keys()),
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
        )
        strategy_detail = {}
        for s in strategies:
            strategy_detail[s.id] = {
                'id': s.id,
                'id_no': s.id_no,
            }

        for f_id, factor in sorted(factors_detail.items(), key=lambda _x: _x[0], reverse=True):
            if f_id not in strategy_detail:
                continue
            ticker = {
                'name': factor['name'],
                'children': [],
                'selectable': False,
            }
            ticker['children'].append({
                'type': 'stock_factor_FACTOR',
                'symbol': 'stock_factor_%s_ALL' % f_id,
                'name': 'ALL',
                'exch': 'SSE'
            })
            if factor['category'] == 'BASIC':
                basic_factor.append(ticker)
            elif factor['category'] == 'NORMAL' and factor['status'] == 'Pool':
                user_factor.append(ticker)

        res = [
            {
                'name': '基础因子',
                'children': basic_factor,
                'selectable': False,
            },
            {
                'name': '普通因子',
                'children': user_factor,
                'selectable': False,
            }
        ]
        sc.close()
        return res


class GetStockFactorStrategyHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()

        if not self.current_user:
            return False

        sc = session()

        strategies = sc.query(Strategy).filter(
            Strategy.r_create_user_id == self.current_user['id'],
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.strategy_type == '26',
        )

        strategy_detail = {}
        for s in strategies:
            strategy_detail[s.id] = {
                'id': s.id,
                'name': s.name,
                'id_no': s.id_no,
                'is_publish': False,
                'factor_type': '',
                'columns': [],
            }

        data = []
        factors = sc.query(StockFactorStrategy).filter(
            StockFactorStrategy.strategy_id.in_(strategy_detail.keys()),
            StockFactorStrategy.r_create_user_id == self.current_user['id'],
            StockFactorStrategy.is_delete == False,
        )
        for f in factors:
            if f.strategy_id not in strategy_detail:
                continue
            d = strategy_detail[f.strategy_id]
            d['is_publish'] = f.is_publish
            d['factor_type'] = f.factor_type
            d['columns'] = StockFactorStrategyColumns.get_factor_columns(f.strategy_id)
            data.append(d)

        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class GetStockFactorEstimationStrategyHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        return factor estimation strategy

        PAGE LOCATION: 因子研究->我的因子->因子评估策略
        """
        data = StockFactorEstimateStrategy.get_estimate_strategy()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StockFactorPublishHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        f_id = int(kwargs['id'])
        # pay_load = self.get_payload()
        s_id = f_id
        sc = session()
        factor = sc.query(StockFactorStrategy).filter(
            StockFactorStrategy.r_create_user_id == self.current_user['id'],
            StockFactorStrategy.strategy_id == f_id
        ).first()
        if not factor:
            sc.close()
            self.json_response({
                'code': 3301,
                'data': 'can not find stock factor(id=%s)' % f_id,
                'error': 'can not find stock factor(id=%s)' % f_id,
            })
            return False

        if factor.is_publish and factor.strategy_id == s_id:
            sc.close()
            self.json_response({
                'code': 0,
                'data': {}
            })
            return True

        factor.is_publish = True
        sc.commit()
        sc.close()
        StockFactorStrategy.stock_factor_publish_delay(f_id, s_id)
        self.json_response({
            'code': 0,
            'data': {}
        })
        return True


class StockFactorColumnsHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        f_id = int(kwargs['id'])
        pay_load = self.get_payload()
        StockFactorStrategyColumns.set_factor_columns(f_id, pay_load['columns'])
        self.json_response({
            'code': 0,
            'data': {},
        })
        return True

    @gen.coroutine
    def get(self, *args, **kwargs):
        f_id = int(kwargs['id'])
        columns = StockFactorStrategyColumns.get_factor_columns(f_id)
        self.json_response({
            'code': 0,
            'data': {
                'columns': columns
            },
        })
        return True


class StockFactorEstimationIndicatorHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        """
        get factor estimation data

        PAGE LOCATION:因子研究->因子评估/我的因子->评估
        """

        self.get_current_user()
        if not self.current_user:
            return False
        is_my_factor = False
        # TODO: NEED TO ABSTRACT: assert if request from my_factor
        # assert if page from my factor
        if 'page=my_factor' in self.request.headers.get('referer', ''):
            is_my_factor = True
        if 'page%3Dmy_factor' in self.request.headers.get('referer', ''):
            is_my_factor = True

        pay_load = self.get_payload()
        factor_type = pay_load['factor_type']  # ALPHA | DAY
        stock_pool = pay_load['stock_pool']
        start_date = pay_load['start_date']
        estimate_strategy_id = pay_load['estimate_strategy_id']
        factor_category = pay_load.get('factor_category', '')
        s_ids = pay_load.get('strategy_ids', [])

        data = StockFactorEstimation.get_factors_indicator(
            estimate_strategy_id=estimate_strategy_id,
            stock_pool=stock_pool,
            start_date=start_date,
            factor_type=factor_type,
            factor_category=factor_category,
            s_ids=s_ids,
            current_user=self.current_user,
            my_factor=is_my_factor,
        )
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class StockFactorEstimationDailyIndicatorHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        get factor estimation daily data

        PAGE LOCATION:因子研究->因子评估->因子id图标
        """
        k_id = int(kwargs['id'])

        data = StockFactorEstimation.get_factor_daily_indicator_by_estimation_id(k_id)

        self.json_response({
            'code': 0,
            'data': data
        })

        return True


class StockFactorEstimationDailyPnlHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        k_id = int(kwargs['id'])

        data = StockFactorEstimation.get_factor_daily_pnl_by_id(k_id)

        self.json_response({
            'code': 0,
            'data': data
        })

        return True


class StockFactorEstimationTimeSeriesIndicatorHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        k_id = self.get_argument('id')
        column = self.get_argument('column', '')
        kw = {}
        data = StockFactorEstimation.get_factor_time_series_indicator_by_id(k_id, column=column, **kw)
        self.json_response({
            'code': 0,
            'data': data
        })

        return True


class VstrategyDeployConfig(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        data = {
            'factor': {},
            'position': {},
            'order': {}
        }
        h = self.get_argument('host', '')
        if not h:
            self.json_response({
                'code': 0,
                'data': data
            })
            return False

        data = self.get_deploy_config(h)

        self.json_response({
            'code': 0,
            'data': data
        })
        return True

    @staticmethod
    def get_deploy_config(h):
        """
        live strategy deploy config
        :param h: string, ip addr, strategy deploy ip
        :return:
        """
        data = {
            'factor': {},
            'position': {},
            'order': {},
            'vs_detail': {},
        }

        sc = session()
        sql = """select id, vstrategy_id from deploy_confs  
        where `host`='%s' and valid=1 and day_night=0 and vstrategy_id is not null""" % h

        vs2process_id = {}

        for r in sc.execute(sql):
            if r[1] in vs2process_id:
                sc.close()
                msg = 'deploy config error vs_id(%s) deploy config is duplicated' % r[1]
                notify_operation_wechat(msg)
                send_email(msg, msg, [CompanyEmailGroup.quant_dev])
                raise ValueError(msg)

            vs2process_id[r[1]] = r[0]

        strategies = sc.query(
            Strategy.id.label('s_id'),
            Strategy.id_no.label('id_no'),
            Strategy.products.label('s_products'),
            Strategy.strategy_type.label('s_type'),
            VStrategies.id.label('vs_id'),
        ).join(
            VStrategies, VStrategies.strategy_id == Strategy.id
        ).filter(
            VStrategies.id.in_(
                vs2process_id.keys()
            ),
            VStrategies.status.in_([13, 15])
        )

        all_factors = {}
        for r in sc.query(
                StockFactorStrategy.strategy_id.label('f_id'),
                StockFactorStrategy.mem_size.label('mem_size')
        ).filter(StockFactorStrategy.is_delete == 0):
            all_factors[r.f_id] = {
                'f_id': r.f_id,
                'size': r.mem_size or 100
            }

        all_factor_ids = list(all_factors.keys())

        vs_detail = {}
        factors = {}
        t0_strategies = {}
        s2vs_ids = {}
        order_vs = {}

        for s in strategies:
            vs_detail[s.vs_id] = {
                'vs_id': s.vs_id,
                's_id': s.s_id,
                'products': s.s_products,
                's_type': s.s_type,
                'factor_s_ids': [int(p['symbol'].split('_')[2]) for p in s.s_products[0] if
                                 p['type'] == 'stock_factor_FACTOR'],
                's_id_no': s.id_no,
            }
            if (s.s_type == '26') or (s.s_id in all_factor_ids):
                factors[s.vs_id] = {
                    'subscriber': [],
                }

            if s.s_type in consts.t0_stock_strategy_type:
                t0_strategies[s.vs_id] = {
                    'publisher': [],
                }

            if s.s_type != '26':
                order_vs[s.vs_id] = {
                    'subscriber': []
                }

            s_vs_ids = s2vs_ids.setdefault(s.s_id, [])
            s_vs_ids.append(s.vs_id)

            if s.vs_id in vs2process_id:
                data['vs_detail'][vs2process_id[s.vs_id]] = {
                    'vs_id': s.vs_id,
                    's_id': s.s_id,
                    's_type': s.s_type,
                    'factor_s_ids': vs_detail[s.vs_id]['factor_s_ids'],
                    's_id_no': s.id_no,
                }

        for vs_id, s_d in vs_detail.items():
            for f_s_id in s_d['factor_s_ids']:
                if not s2vs_ids[f_s_id]:
                    msg = 'deploy config error factor is not deployed vs_id(%s), factor_id(%s)' % (vs_id, f_s_id)
                    notify_operation_wechat(msg)
                    send_email(msg, msg, [CompanyEmailGroup.quant_dev])

                for f_s_vs_id in s2vs_ids.get(f_s_id, []):
                    if f_s_vs_id not in factors:
                        msg = 'deploy config error factor strategy type is error vs_id(%s), factor_id(%s)' % (
                            vs_id, f_s_vs_id)
                        notify_operation_wechat(msg)
                        send_email(msg, msg, [CompanyEmailGroup.quant_dev])
                        continue

                    factors[f_s_vs_id]['subscriber'].append(vs_id)

        # t0_vs_subscriber = sc.query(T0Subscriber).filter(
        #     T0Subscriber.t0_vs_id.in_(t0_strategies.keys())
        # )
        t0_records = sc.query(VsT0Relation).filter(
            VsT0Relation.vs_id.in_(t0_strategies.keys()),
            VsT0Relation.deleted == False
        ).all()

        t0_detail = {}
        # for t0 in t0_vs_subscriber:
        #     t0_d = t0_detail.setdefault(t0.t0_vs_id, [])
        #     t0_d.append(t0.alpha_vs_id)
        for t0_record in t0_records:
            t0_d = t0_detail.setdefault(t0_record.vs_id, [])
            t0_d.append(t0_record.link_vs_id)

        for t0_vs_id, t0_alpha_vs_ids in t0_detail.items():
            t0_strategies[t0_vs_id]['publisher'].extend(t0_alpha_vs_ids)

        for f_id, f_subscriber in factors.items():
            data['factor'][vs2process_id[f_id]] = {
                'subscriber': [vs2process_id[v_id] for v_id in set(f_subscriber['subscriber'])],
                'size': all_factors.get(vs_detail[f_id]['s_id'], {}).get('size', 100)
            }

        for t0_vs_id, t0_publisher in t0_strategies.items():
            if not t0_publisher['publisher']:
                msg = 'deploy config error t0 vs_id(%s) alpha vs_ids is Null' % t0_vs_id
                notify_operation_wechat(msg)
                send_email(msg, msg, [CompanyEmailGroup.quant_dev])

            for t0_pub_vs_id in set(t0_publisher['publisher']):
                if t0_pub_vs_id not in vs_detail:
                    # msg = 'deploy config error t0 vs_id(%s) publish alpha vs_id(%s) is not deployed' % (
                    #     t0_vs_id, t0_pub_vs_id)
                    # notify_operation_wechat(msg)
                    # send_email(msg, msg, [CompanyEmailGroup.quant_dev])
                    continue

                alpha_subscriber = data['position'].setdefault(vs2process_id[t0_pub_vs_id], {
                    'subscriber': []
                })
                alpha_subscriber['subscriber'].append(vs2process_id[t0_vs_id])

        # alpha - hedge relation
        alpha_hedge_records = sc.query(StockHedgeVs).filter(StockHedgeVs.stock_vs_id.in_(order_vs.keys())).all()
        alpha_hedge_relation = {r.stock_vs_id: r.future_vs_id for r in alpha_hedge_records}

        for order_vs_id, order_subscriber in order_vs.items():
            sql1 = """
                select id from deploy_confs where (`host`, vstrategy_id) in (
                select ser.ip, conf.merge_vstrategy_id from pre_strategy_confs conf, servers ser where
                conf.server_id = ser.id and conf.merge_vstrategy_id is not null and conf.vstrategy_id = {order_vs_id} 
                and ser.ip = '{h}') and valid = 1
            """.format(order_vs_id=order_vs_id, h=h)
            sub_process_ids = [r[0] for r in sc.execute(sql1)]
            if not sub_process_ids:
                sql = """
                    select id from deploy_confs where (`host`, deploy_path) in (
                    select ser.ip, conf.day_tunnel_conf from pre_strategy_confs conf, servers ser where
                    conf.server_id = ser.id and conf.vstrategy_id = {order_vs_id} and ser.ip = '{h}'
                    ) and valid = 1
                """.format(order_vs_id=order_vs_id, h=h)
                sub_process_ids = [r[0] for r in sc.execute(sql)]
            if not sub_process_ids:
                msg = 'deploy config error order vs_id(%s) has no tunnel_conf' % order_vs_id
                notify_operation_wechat(msg)
                send_email(msg, msg, [CompanyEmailGroup.quant_dev])

            # append alpha - hedge relation
            hedge_process_id = vs2process_id.get(alpha_hedge_relation.get(order_vs_id, -1))
            if hedge_process_id:
                sub_process_ids.append(hedge_process_id)

            data['order'][vs2process_id[order_vs_id]] = sub_process_ids

        a = set(vs2process_id.keys()) - set(vs_detail.keys())

        if a:
            msg = 'deploy config error vs_ids(%s) config is error' % a
            notify_operation_wechat(msg)
            send_email(msg, msg, [CompanyEmailGroup.quant_dev])

        sc.close()
        return data


class StockFactorStrategyHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        if user is superuser,return all strategy factor,
        else return user owned strategy factor
        PAGE LOCATION: 因子研究->上传因子
        """
        self.get_current_user()
        if not self.current_user:
            return False

        sc = session()
        node = 'ev'
        page = int(self.get_argument('page', 0))
        size = int(self.get_argument('size', 100))
        keyword = self.get_argument('keyword', '')
        strategies = sc.query(Strategy)
        if node:
            if self.current_user['is_superuser']:
                strategies = strategies.filter(
                    Strategy.node == node,
                    Strategy.is_test == 0,
                    Strategy.is_delete == 0,
                    Strategy.strategy_type == '26',
                )
            else:
                strategies = strategies.filter(
                    Strategy.r_create_user_id == self.current_user['id'],
                    Strategy.node == node,
                    Strategy.is_test == 0,
                    Strategy.is_delete == 0,
                    Strategy.strategy_type == '26',
                )

        if keyword:
            if keyword.isdigit():
                strategies = strategies.filter(
                    or_(
                        Strategy.id == int(keyword),
                        Strategy.id_no.ilike('%%%s%%' % keyword),
                    )
                )
            else:
                strategies = strategies.filter(Strategy.id_no.ilike('%%%s%%' % keyword))

        strategies = strategies.filter(
            Strategy.is_derive_strategy == False,
            Strategy.id >= 211715,
        )
        total = strategies.count()
        strategies = strategies.order_by(Strategy.id.desc()).offset(page * size).limit(size)

        # add factor status info
        s_ids = [s.id for s in strategies]
        factors = sc.query(StockFactorStrategy).filter(
            StockFactorStrategy.strategy_id.in_(s_ids)
        ).all()
        factor_info = {f.strategy_id: {
            'check_bias_status': f.check_bias_status,
            'check_bias_date': f.check_bias_date or ""
        } for f in factors}

        data = list()
        for s in strategies:
            info = s.to_dict_brief()
            info.update(factor_info.get(s.id, {}))
            data.append(info)

        self.json_response({
            'code': 0,
            'data': data,
            'total': total,
        })
        sc.close()
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        """
        upload stock factor

        PAGE LOCATION: 因子研究->上传因子->新建
        """
        self.get_current_user()
        if not self.current_user:
            return False

        node = 'ev'
        name = self.get_argument('name')
        strategy_id = self.get_argument('id', '')
        file_type = self.get_argument('file_type', '')
        file_md5 = self.get_argument('file_md5', '')
        dependency = json.loads(self.get_argument('dependency', '[]'))
        detail = json.loads(self.get_argument('detail', '{}'))
        products = json.loads(self.get_argument('products', '[]'))
        start = parse(self.get_argument('start', time.strftime('%Y-%m-%d'))).strftime('%Y%m%d')
        end = '20500101'
        test = json.loads(self.get_argument('test', 'false'))
        status = consts.TASK_NEW if not test else consts.TASK_RUNNING

        # AlphaFactorCombination can not contain same factor id used by other combination
        algorithm = detail.get('algorithm', '')
        dep_factor_ids = [int(p['symbol'].split('_')[2]) for p in products[0] if
                          p.get('type', '') == 'stock_factor_FACTOR']
        if algorithm == StrategyConstant.DetailAlgorithm.AlphaFactorCombination.value:
            if FactorCombinationRelation.is_factor_id_used(sub_factor_ids=dep_factor_ids):
                self.json_response({
                    'code': 10000,
                    'data': 'Factor Combination: factor used by other combination',
                })
                return False

        # save csv file with md5
        if str(file_type).lower() == 'csv' and file_md5:
            try:
                file_data = {
                    'user_id': self.current_user['id'],
                    'user_name': self.current_user['username'],
                    'file_md5': file_md5,
                    'file_type': 'ev'
                }
                # copy csv to ./platform_file_upload/{username}/{file_md5}/{filename}
                strategy_upload_file_id = StrategyUploadFile.copy_file(file_data)
                if strategy_upload_file_id < 0:
                    raise ValueError('upload file failed')
            except Exception as e:
                self.application.sentry.captureException()
                self.json_response({
                    'code': 1019,
                    'data': 'upload file failed',
                })
                return False
        else:
            if strategy_id and (not (self.request.files and self.request.files['file'])):
                strategy_upload_file_id = -1
            else:
                try:
                    upload_file = self.request.files['file'][0]
                    file_data = {
                        'user_id': self.current_user['id'],
                        'content': upload_file['body'],
                        'filename': upload_file['filename'],
                        'file_type': {
                            'ev': 'ev',
                            'back_test': 'st',
                        }[node]
                    }
                    # save file to {config.media}/strategy_upload/so_files/{filename}
                    strategy_upload_file_id = StrategyUploadFile.save_file(file_data)
                    if strategy_upload_file_id < 0:
                        raise ValueError('upload file failed')
                except Exception as e:
                    self.application.sentry.captureException()
                    self.json_response({
                        'code': 1019,
                        'data': 'upload file failed',
                    })
                    return False

        # parse post json data to `Strategy` and write it to database
        post_data = {
            'node': node,
            'name': name,
            'dependency': dependency,
            'products': products,
            'start': start,
            'end': end,
            'test': test,
            'file_type': file_type,
            'file_md5': file_md5,
        }
        for k, v in detail.items():
            post_data[k] = v

        post_data['desc'] = post_data.get('desc', '')[:100]
        post_data['max_pos'] = int(post_data.get('max_pos', 1000000))
        day, night = str(post_data.get('day', '')).lower(), str(post_data.get('night', '')).lower()

        if node == 'cash_manager':
            day, night = 'true', 'true'
        if day == 'true' and night == 'true':
            day_night = 2
        elif day == 'true':
            day_night = 0
        elif night == 'true':
            day_night = 1
        else:
            day_night = 0
        post_data['day_night'] = day_night

        detail['strategy_type'] = '26'
        post_data['strategy_type'] = '26'
        post_data['new_factor_strategy'] = True

        if (not strategy_id) and (not post_data['test']):
            strategy_type = post_data.get('strategy_type', '99')
            id_no = Strategy.generate_id_no(
                self.current_user['id'], strategy_type, time.strftime('%Y-%m-%d')
            )
        else:
            id_no = ''

        sc = session()

        if strategy_id and test:
            if strategy_upload_file_id < 0:
                strategy = sc.query(Strategy).filter(
                    Strategy.id == strategy_id,
                    Strategy.r_create_user_id == self.current_user['id'],
                ).first()
                if not strategy:
                    self.json_response({
                        'code': 1013,
                        'error': 'can not find strategy id=%s and created by %s' % (
                            strategy_id, self.current_user['username'])
                    })
                    sc.close()
                    return
                strategy_upload_file_id = strategy.strategy_upload_file_id
            strategy_id = None

        # write strategy detail to database
        if not strategy_id:
            strategy = Strategy(
                r_create_user_id=self.current_user['id'],
                r_update_user_id=self.current_user['id'],
                username=self.current_user['username'],
                name=post_data['name'],
                status=status,
                description=post_data['desc'],
                node=node,
                start_date=post_data['start'],
                end_date=post_data['end'],
                day_night=post_data['day_night'],
                products=post_data['products'],
                max_pos=post_data['max_pos'],
                dependency=post_data['dependency'],
                detail=post_data,
                st_uuid=uuid.uuid1().hex,
                strategy_type=post_data.get('strategy_type', ''),
                strategy_feature=post_data.get('strategy_feature', ''),
                strategy_underlying=post_data.get('strategy_underlying', ''),
                strategy_para_type=post_data.get('strategy_para_type', ''),
                strategy_status='NEW',
                id_no=id_no,
                code=id_no[-3:],
                is_test=1 if post_data['test'] else 0,
                strategy_upload_file_id=strategy_upload_file_id,
                hedge=post_data.get('hedge', ''),
                hedge_type=post_data.get('hedge_type', ''),
                paper_trading_date=datetime.datetime.now(),
                task_progress=0,
            )
            sc.add(strategy)
            sc.flush()

            # AlphaFactorCombination record used factor id
            if algorithm == StrategyConstant.DetailAlgorithm.AlphaFactorCombination.value:
                if not FactorCombinationRelation.add_relations(
                        main_factor_id=strategy.id,
                        sub_factor_ids=dep_factor_ids
                ):
                    self.json_response({
                        'code': 10000,
                        'data': 'Factor Combination: factor used by other combination',
                    })
                    return False

            strategy_owner = StrategyOwners(
                strategy_id=strategy.id,
                owner_id=self.current_user['id'],
                r_create_user_id=self.current_user['id'],
            )
            sc.add(strategy_owner)
            sc.commit()
        else:
            strategy = sc.query(Strategy).filter(
                Strategy.id == strategy_id,
                Strategy.r_create_user_id == self.current_user['id'],
            ).first()
            if not strategy:
                self.json_response({
                    'code': 1013,
                    'error': 'can not find strategy id=%s and created by %s' % (
                        strategy_id, self.current_user['username'])
                })
                sc.close()
                return

            if (strategy.strategy_type != '26') or (not strategy.detail.get('new_factor_strategy')):
                self.json_response({
                    'code': 4001,
                    'error': u'can not update old version factor strategy'
                })
                sc.close()
                return

            update_paper_trading = False
            if strategy_upload_file_id > 0 and strategy_upload_file_id != strategy.strategy_upload_file_id:
                update_paper_trading = True

            if sorted([d['id'] for d in (strategy.dependency or [])]) != sorted(
                    [d['id'] for d in (post_data['dependency'] or [])]):
                update_paper_trading = True

            old_products = []
            if strategy.products:
                old_products = sorted([p['symbol'] for p in strategy.products[0]])
            new_products = []
            if post_data['products']:
                new_products = sorted(p['symbol'] for p in post_data['products'][0])
            if old_products != new_products:
                update_paper_trading = True

            strategy.r_update_user_id = self.current_user['id']
            strategy.name = post_data['name']
            strategy.description = post_data['desc']
            strategy.day_night = post_data['day_night']
            strategy.products = post_data['products']
            strategy.dependency = post_data['dependency']
            strategy.detail = post_data
            strategy.strategy_type = post_data.get('strategy_type', '')
            strategy.strategy_feature = post_data.get('strategy_feature', '')
            strategy.strategy_underlying = post_data.get('strategy_underlying', '')
            strategy.strategy_para_type = post_data.get('strategy_para_type', '')
            strategy.strategy_status = 'NEW'

            if update_paper_trading:
                strategy.paper_trading_date = datetime.datetime.now()

            if strategy_upload_file_id > 0:
                strategy.strategy_upload_file_id = strategy_upload_file_id

            sc.commit()

        if strategy.strategy_type == '26':
            from service.stock_factor.models import StockFactorStrategy
            StockFactorStrategy.copy_from_strategy(strategy.id)

        data = strategy.to_dict_brief()
        data['start'] = parse(data['start']).strftime('%Y%m%d')
        data['end'] = time.strftime('%Y%m%d')

        self.json_response({
            'code': 0,
            'data': data,
        })
        sc.close()
        return True


class StockFactorStrategyNewVersionHandler(CurrentUserMixin, BaseHandler):
    @gen.coroutine
    def post(self, *args, **kwargs):
        """
        update strategy
        PAGE LOCATION: 因子研究->因子上传->更新版本->更新
        """
        self.get_current_user()
        if not self.current_user:
            return False
        node = 'ev'
        name = self.get_argument('name')
        origin_s_id = kwargs['id']

        try:
            upload_file = self.request.files['file'][0]
            file_data = {
                'user_id': self.current_user['id'],
                'content': upload_file['body'],
                'filename': upload_file['filename'],
                'file_type': {
                    'ev': 'ev',
                    'back_test': 'st',
                }[node]
            }
            # cover old file
            strategy_upload_file_id = StrategyUploadFile.save_file(file_data)
            if strategy_upload_file_id < 0:
                raise ValueError('upload file failed')
        except Exception as e:
            self.application.sentry.captureException()
            self.json_response({
                'code': 1019,
                'data': 'upload file failed',
            })
            return False

        dependency = json.loads(self.get_argument('dependency', '[]'))
        detail = json.loads(self.get_argument('detail', '{}'))
        products = json.loads(self.get_argument('products', '[]'))
        start = parse(self.get_argument('start', time.strftime('%Y-%m-%d'))).strftime('%Y%m%d')
        end = '20500101'
        test = json.loads(self.get_argument('test', 'false'))
        status = consts.TASK_NEW if not test else consts.TASK_RUNNING
        post_data = {
            'node': node,
            'name': name,
            'dependency': dependency,
            'products': products,
            'start': start,
            'end': end,
            'test': test,
        }
        for k, v in detail.items():
            post_data[k] = v
        post_data['desc'] = post_data.get('desc', '')[:100]
        post_data['max_pos'] = int(post_data.get('max_pos', 1000000))
        day, night = str(post_data.get('day', '')).lower(), str(post_data.get('night', '')).lower()
        if node == 'cash_manager':
            day, night = 'true', 'true'
        if day == 'true' and night == 'true':
            day_night = 2
        elif day == 'true':
            day_night = 0
        elif night == 'true':
            day_night = 1
        else:
            day_night = 0
        post_data['day_night'] = day_night

        detail['strategy_type'] = '26'
        post_data['strategy_type'] = '26'

        id_no = ''
        sc = session()

        origin_s = sc.query(Strategy).filter(Strategy.id == origin_s_id).first()

        post_data['new_factor_strategy'] = True
        post_data['is_root_strategy'] = False
        strategy = Strategy(
            r_create_user_id=self.current_user['id'],
            r_update_user_id=self.current_user['id'],
            username=self.current_user['username'],
            name=post_data['name'],
            status=status,
            description=post_data['desc'],
            node=node,
            start_date=post_data['start'],
            end_date=post_data['end'],
            day_night=post_data['day_night'],
            products=post_data['products'],
            max_pos=post_data['max_pos'],
            dependency=post_data['dependency'],
            detail=post_data,
            st_uuid=uuid.uuid1().hex,
            strategy_type=post_data.get('strategy_type', ''),
            strategy_feature=post_data.get('strategy_feature', ''),
            strategy_underlying=post_data.get('strategy_underlying', ''),
            strategy_para_type=post_data.get('strategy_para_type', ''),
            strategy_status='NEW',
            id_no=id_no,
            code=origin_s.code,
            is_test=1 if post_data['test'] else 0,
            strategy_upload_file_id=strategy_upload_file_id,
            hedge=post_data.get('hedge', ''),
            hedge_type=post_data.get('hedge_type', ''),
            paper_trading_date=datetime.datetime.now(),
            task_progress=0,
        )
        sc.add(strategy)
        sc.flush()
        strategy_owner = StrategyOwners(
            strategy_id=strategy.id,
            owner_id=self.current_user['id'],
            r_create_user_id=self.current_user['id'],
        )
        sc.add(strategy_owner)
        new_version = StockFactorVersion(
            origin_s_id=origin_s_id,
            newversion_s_id=strategy.id,
        )
        sc.add(new_version)
        sc.commit()
        version_counts = sc.query(StockFactorVersion.id).filter(
            StockFactorVersion.origin_s_id == origin_s_id,
            StockFactorVersion.id <= new_version.id
        ).count()
        id_no = '%s_V%s' % (origin_s.id_no, str(version_counts).zfill(2))
        strategy.id_no = id_no
        sc.commit()
        if strategy.strategy_type == '26':
            from service.stock_factor.models import StockFactorStrategy
            StockFactorStrategy.copy_from_strategy(strategy.id)
        data = strategy.to_dict_brief()
        data['start'] = parse(data['start']).strftime('%Y%m%d')
        data['end'] = time.strftime('%Y%m%d')
        self.json_response({
            'code': 0,
            'data': data,
        })
        sc.close()
        return True


class StockFackotStrategyDetailHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):

        self.get_current_user()
        if not self.current_user:
            return False

        strategy_id = int(kwargs['id'])

        sc = session()

        s = sc.query(Strategy).filter(
            Strategy.id == strategy_id
        ).first()

        if not s:
            self.json_response({
                'code': 1013,
                'error': 'can not find strategy id=%s' % strategy_id
            })
            sc.close()
            return True

        data = s.to_dict_brief()
        data['error_info'] = s.error_info()
        self.json_response({
            'code': 0,
            'data': data,
        })
        sc.close()
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        """
        PAGE LOCATION:因子研究->因子上传->开始生产/暂停
        """
        self.get_current_user()
        if not self.current_user:
            return False

        sc = session()
        s_id = int(kwargs['id'])
        if self.current_user['is_superuser']:
            s = sc.query(Strategy).filter(Strategy.id == s_id).first()
        else:
            s = sc.query(Strategy).filter(
                Strategy.id == s_id,
                Strategy.r_create_user_id == self.current_user['id']
            ).first()

        if not s:
            self.json_response({
                'code': 1013,
                'error': 'can not find strategy id=%s' % s_id
            })
            sc.close()
            return True
        else:
            post_data = self.get_payload()
            action = str(post_data.get('action', '')).lower()
            if action == 'stop':
                s.status = consts.TASK_STOPPED
                s.stop_task()
            # elif action == 'back_test':
            #     pass
            elif action == 'ev':
                if s.node == 'ev':
                    s.stop_task()
                    detail = copy.deepcopy(s.detail)
                    if detail.get('factor_category', 0) == 1:
                        s.start_date = '20070101'
                    else:
                        if detail.get('algorithm', '') == 'fundamental':
                            s.start_date = '20100101'
                        else:
                            s.start_date = '20111201'
                    detail['start'] = s.start_date
                    s.detail = detail
                    s.task_progress = 0
                    s.status = consts.TASK_RUNNING
                    s.st_uuid = uuid.uuid1().hex
                    if s.strategy_status not in ('LT', 'PT'):
                        s.strategy_status = 'BT'

                    sc.query(StrategyResult).filter(
                        StrategyResult.strategy_id == s.id,
                        StrategyResult.config_id == 0
                    ).delete()
                    sc.commit()

                    from cron.strategy_upload_task import start_strategy_task
                    start_strategy_task.delay(s.id)
            else:
                pass

            self.json_response({
                'code': 0,
                'data': s.to_dict_brief()
            })
            sc.commit()
            sc.close()
            return True

    @gen.coroutine
    def delete(self, *args, **kwargs):
        """
        delete strategy
        PAGE LOCATION: 因子研究->因子上传->更新版本->删除
        """
        self.get_current_user()
        if not self.current_user:
            return False
        sc = session()
        strategyid = int(kwargs['id'])
        # search strategy id
        if self.current_user['is_superuser']:
            s_obj = sc.query(Strategy).filter(
                Strategy.id == strategyid,
            )
            s = s_obj.first()
        else:
            s_obj = sc.query(Strategy).filter(
                Strategy.id == strategyid,
                Strategy.r_create_user_id == self.current_user['id']
            )
            s = s_obj.first()
        if not s:
            self.json_response({
                'code': 1013,
                'error': 'can not find strategy id=%s' % strategyid
            })
            sc.close()
            return True
        else:
            # do not delete deployed strategy
            if s.is_deployed:
                self.json_response({
                    'code': 1003,
                    'error': 'strategy is already deployed',
                })
                sc.commit()
                return True

            factor = sc.query(StockFactorStrategy).filter(
                StockFactorStrategy.strategy_id == strategyid,
                or_(
                    StockFactorStrategy.status == 'Pool',
                    StockFactorStrategy.status2 == 'Pool',
                ),
            ).first()
            # do not delete strategy factor in pool
            if factor:
                self.json_response({
                    'code': 1003,
                    'error': 'factor is already in Pool',
                })
                sc.commit()
                sc.close()
                return True

            depend_strategy = []
            strategies = sc.query(Strategy).filter(
                Strategy.r_create_user_id == self.current_user['id'],
                Strategy.is_test == 0,
                Strategy.is_delete == 0,
                Strategy.is_derive_strategy == False,
            ).all()
            for _s in strategies:
                if strategyid in _s.input_dependency_ids:
                    depend_strategy.append({
                        'id': _s.id,
                        'name': _s.name,
                    })
            # not delete strategy if this strategy depended on other task
            if depend_strategy:
                self.json_response({
                    'code': 1003,
                    'error': 'other task depende on this task',
                    'data': depend_strategy,
                })
                sc.commit()
                return True
            # start delete
            # update strategy data in database
            s.status = consts.TASK_FINISHED
            s.is_delete = 1
            sc.query(StrategyResult).filter(
                StrategyResult.strategy_id == s.id
            ).delete()
            sc.commit()
            # delete redis cache
            del_cache('platform_strategy_brief_%s' % s.id)
            del_cache('platform_strategy_detail_%s' % s.id)
            sc.close()
            self.json_response({
                'code': 0,
                'data': 'success',
            })
            return True


class StockFactorjudgeDetailHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        return factor judge result to web
        PAGE LOCATION: 因子研究->上传因子->评审结果
        """
        strategy_id = int(kwargs['id'])

        sc = session()

        s = sc.query(Strategy).filter(
            Strategy.id == strategy_id
        ).first()

        if not s:
            self.json_response({
                'code': 1013,
                'error': 'can not find strategy id=%s' % strategy_id
            })
            sc.close()
            return True

        self.json_response({
            'code': 0,
            'data': StockFactorStrategy.get_factor_evalue_judge(strategy_id),
        })
        sc.close()
        return True


class StockFactorjudgeDailyDetailHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        strategy_id = int(kwargs['id'])
        col = self.get_argument('col', '')

        self.json_response({
            'code': 0,
            'data': StockFactorStrategy.get_factor_evalue_judge_daily(strategy_id, col),
        })
        return True


class StockFactorjudgeIndHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        return threshold of factor judge to web
        PAGE LOCATION: 因子研究->上传因子->评审结果
        """
        judge_threshold = {}
        judge_threshold['ic'] = [0.015, -0.015]
        judge_threshold['ac'] = [0.30, None]
        judge_threshold['ir'] = [0.05, None]
        judge_threshold['sr'] = [1, None]
        judge_threshold['corr'] = [None, 0.7]

        judge_threshold['ic_msg'] = 'ic <= -0.015 or ic >= 0.015'
        judge_threshold['ac_msg'] = '0.30 <= ac'
        judge_threshold['ir_msg'] = '0.05 <= ir'
        judge_threshold['sr_msg'] = '1 <= sr'
        judge_threshold['corr_msg'] = 'corr <= 0.7'
        judge_threshold['judge_threshold'] = [
            'CR >= 0.8',
            'CORR_MAX <= 0.8',
            '(abs(IC) >= 0.01 and IR >= 0.05 and SR >= 1) or (AC >= 0.3 and Fitness >= 0.7)',
            'FC <= 0.8',
        ]

        self.json_response({
            'code': 0,
            'data': judge_threshold,
        })
        return True


class StockFactorEvalueStrategyHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        show user-owned strategy
        PAGE LOCATION ：因子研究->我的因子/我的因子2->因子生产策略
        """
        self.get_current_user()
        if not self.current_user:
            return False
        is_my_factor = False
        # TODO: NEED TO ABSTRACT: assert if request from my_factor
        # assert if page from my factor
        if 'page=my_factor' in self.request.headers.get('referer', ''):
            is_my_factor = True
        if 'page%3Dmy_factor' in self.request.headers.get('referer', ''):
            is_my_factor = True

        pool_version = 'v1'
        if 'equity/factor-pool.html' in self.request.headers.get('referer', ''):
            pool_version = 'v2'

        sc = session()

        if not is_my_factor:
            factors = sc.query(
                StockFactorStrategy
            ).filter(
                StockFactorStrategy.is_publish == True,
                StockFactorStrategy.is_delete == False,
                StockFactorStrategy.factor_type == 'FACTOR_ALPHA',
                StockFactorStrategy.strategy_id >= 211715,
                StockFactorStrategy.category == 'NORMAL',
            )
            if pool_version == 'v1':
                factors = factors.filter(StockFactorStrategy.status == 'Pool')
            else:
                factors = factors.filter(StockFactorStrategy.status2 == 'Pool')
        else:
            factors = sc.query(
                StockFactorStrategy
            ).filter(
                StockFactorStrategy.is_publish == True,
                StockFactorStrategy.is_delete == False,
                StockFactorStrategy.factor_type == 'FACTOR_ALPHA',
                StockFactorStrategy.strategy_id >= 211715,
                StockFactorStrategy.category == 'NORMAL',
                StockFactorStrategy.r_create_user_id == self.current_user['id'],
            )

        data, factors_detail = [], {}

        for f in factors:
            factors_detail[f.strategy_id] = {
                'factor_id': f.strategy_id,
                'name': f.name,
            }

        strategies = sc.query(
            Strategy.id.label('id'),
            Strategy.id_no.label('id_no'),
            Strategy.name.label('name'),
            Strategy.username.label('username')
        ).filter(
            Strategy.id.in_(factors_detail.keys()),
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
        )
        strategy_detail = {}
        for s in strategies:
            strategy_detail[s.id] = {
                's_id': s.id,
                'factor_id_no': s.id_no,
                'name': s.name,
                'username': s.username,
            }

        sc.close()
        data = sorted(strategy_detail.values(), key=lambda x: x['s_id'], reverse=True)

        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StockFactorPoolHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        show strategy detail

        :return json
            {
                "code":0,
                "data":[
                    {
                        "factors":[
                            {
                                "factor":"",
                                "factor_id": ""
                            },
                            ......
                        ],
                        "name": "",
                        "category": "",
                        "factor_s_id": ""
                    },
                    ......
                ]
            }
        """

        sc = session()

        pool_type = self.get_argument('type', '')

        factors = sc.query(
            StockFactorStrategy
        ).filter(
            StockFactorStrategy.is_publish == True,
            StockFactorStrategy.is_delete == False,
            StockFactorStrategy.factor_type == 'FACTOR_ALPHA',
            StockFactorStrategy.category == 'NORMAL',
            StockFactorStrategy.strategy_id >= 211715,
        )

        if pool_type:
            factors = factors.filter(
                StockFactorStrategy.status2 == 'Pool',
            )
        else:
            factors = factors.filter(
                StockFactorStrategy.status == 'Pool',
            )

        data, factors_detail = [], {}

        for f in factors:
            factors_detail[f.strategy_id] = {
                'factor_id': f.strategy_id,
                'name': f.name,
                'category': f.category
            }

        strategies = sc.query(
            Strategy.id.label('id'),
            Strategy.id_no.label('id_no'),
            Strategy.name.label('name'),
            Strategy.detail.label('detail'),
        ).filter(
            Strategy.id.in_(factors_detail.keys()),
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
        )
        strategy_detail = {}
        for s in strategies:
            algorithm = s.detail.get('algorithm', 'other')
            if not (pool_type == '' or pool_type == 'all' or pool_type == algorithm):
                continue
            columns = StockFactorStrategyColumns.get_factor_columns(s.id)
            # decide use get_judge_passed_columns or get_judge_passed_columns2 by pool_type
            if pool_type:
                pass_columns = StockFactorStrategyColumns.get_judge_passed_columns2(s.id)
                factors = [
                    {
                        'factor': c,
                        'factor_id': '%s_A%s' % (s.id_no, str(i).zfill(3))
                    } for i, c in enumerate(columns, 1) if c in pass_columns
                ]
            else:
                pass_columns = StockFactorStrategyColumns.get_judge_passed_columns(s.id)
                factors = [
                    {
                        'factor': c,
                        'factor_id': '%s_A%s' % (s.id_no, str(i).zfill(3))
                    } for i, c in enumerate(columns, 1) if ((s.id in consts.factor_pool) or (c in pass_columns))
                ]
            strategy_detail[s.id] = {
                'factor_s_id': s.id,
                'name': s.name,
                'category': factors_detail[s.id]['category'],
                'factors': factors,
            }

        sc.close()

        data = sorted(strategy_detail.values(), key=lambda x: x['factor_s_id'], reverse=True)

        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StockFactorPoolDetailHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):

        f_id = int(kwargs['id'])
        sc = session()

        s = sc.query(Strategy).filter(Strategy.id == f_id).first()
        if not s:
            sc.close()
            raise ValueError('get data error')
        category = 'NORMAL'
        if s.detail.get('factor_category', 0) == 1:
            category = 'BASIC'

        data = {
            'name': s.name,
            'username': s.username,
            'strategy_id': s.id_no,
            'category': category,
            'f_id': s.id,
            'rely_basicfactor': [],
            'rely_myfactor': [],
            'algorithm': s.detail.get('algorithm', 'other'),
            'create_date': s.r_create_time.strftime('%Y%m%d'),
        }

        f_ids = [int(p['symbol'].split('_')[2]) for p in s.products[0] if p['type'] == 'stock_factor_FACTOR']
        factors = sc.query(Strategy).filter(Strategy.id.in_(f_ids))
        for f in factors:
            d = {
                'name': f.name,
                'f_id': f.id,
                'strategy_id': f.id_no
            }
            if f.detail.get('factor_category', 0) == 1:
                data['rely_basicfactor'].append(d)
            else:
                data['rely_myfactor'].append(d)

        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class GetBasicFactorBriefHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        show basic factor detail
        PAGE LOCATION:因子研究->基础因子
        """
        sc = session()
        factors = sc.query(
            StockFactorStrategy
        ).filter(
            StockFactorStrategy.is_publish == True,
            StockFactorStrategy.is_delete == False,
            StockFactorStrategy.strategy_id >= 211715,
        )
        data, factors_detail = [], {}
        for f in factors:
            factors_detail[f.strategy_id] = {
                'user_id': f.r_create_user_id,
                'factor_id': f.strategy_id,
                'name': f.name,
                'category': f.category,
            }

        strategies = sc.query(
            Strategy
        ).filter(
            Strategy.id.in_(factors_detail.keys()),
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
        )
        strategy_detail = {}
        for s in strategies:
            strategy_detail[s.id] = {
                'id': s.id,
                'id_no': s.id_no,
                'name': s.name,
                'user_name': s.username,
                'doc_link': s.detail.get('doc_link', '')
            }

        res = []

        for f_id, factor in sorted(factors_detail.items(), key=lambda _x: _x[0], reverse=True):
            if f_id not in strategy_detail:
                continue
            if factor['category'] == 'BASIC':
                res.append(strategy_detail[f_id])

        sc.close()
        self.json_response({
            'code': 0,
            'data': res,
        })
        return True


class StockPoolEstimationIndicatorHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        """
        show factor pool simulation result from summary.csv,check22.csv,score.csv
        PAGE LOCATION: 因子研究->因子库2
        """
        # check login
        self.get_current_user()
        if not self.current_user:
            return False

        # decide page link from
        is_my_factor = False
        if 'page=my_factor' in self.request.headers.get('referer', ''):
            is_my_factor = True
        if 'page%3Dmy_factor' in self.request.headers.get('referer', ''):
            is_my_factor = True

        pay_load = self.get_payload()
        s_ids = pay_load.get('strategy_ids', [])
        users = pay_load.get('users', [])
        algorithms = pay_load.get('algorithms', [])

        data = StockFactorStrategy.get_factor_pool_estimation_indicator_v2(
            s_ids=s_ids, users=users, algorithms=algorithms, is_my_factor=is_my_factor,
            current_user_id=self.current_user['id']
        )

        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class StockFactorPnlIndicatorHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        show fact pnl indicator and pnl summary
        PAGE LOCATION: 因子研究->因子库2->因子盈利曲线图标
        """
        self.get_current_user()
        if not self.current_user:
            return False
        # decide is_my_factor
        is_my_factor = False
        if 'page=my_factor' in self.request.headers.get('referer', ''):
            is_my_factor = True
        if 'page%3Dmy_factor' in self.request.headers.get('referer', ''):
            is_my_factor = True

        factor_id = int(kwargs['id'])
        col_name = self.get_argument('name')
        data = StockFactorStrategy.get_factor_pnl_indicator_v2(factor_id, col_name, is_my_factor=is_my_factor)
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class StockFactorPerformanceJudgeDetailHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        show  factor pool simulation result summary.csv,check22.csv,score.csv
        PAGE LOCATION: 因子研究->因子上传->评审2.0
        """
        strategy_id = int(kwargs['id'])

        sc = session()

        s = sc.query(Strategy).filter(
            Strategy.id == strategy_id
        ).first()

        if not s:
            self.json_response({
                'code': 1013,
                'error': 'can not find strategy id=%s' % strategy_id
            })
            sc.close()
            return True

        self.json_response({
            'code': 0,
            'data': StockFactorStrategy.get_factor_evaluation_judge_v2(strategy_id),
        })
        sc.close()
        return True


class StockFactorBiasStatusHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        payload = self.get_payload()
        s_id = int(payload['s_id'])

        trading_calendar = TradeCalendar.init_from_kdb(**config.kdb_config)
        today = datetime.datetime.today().date()
        if not trading_calendar.is_trading_date(date=today):
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'error': 'today is not trading date'
            })
            return

        if not check_bias_init(factor_id=s_id, trading_date=today.strftime('%Y%m%d')):
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'error': 'today npq not ready or not the right hour'
            })
            return

        StockFactorStrategy.send_event(factor_id=s_id, event=StockFactorEvaluationQueueEvent.JudgeCheck.value)

        self.json_response({
            'code': APIResponseCode.OK.value,
            'data': {
                'success': True
            }
        })

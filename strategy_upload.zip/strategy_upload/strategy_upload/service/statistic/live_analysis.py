# -*-coding:utf-8-*-

import json
import os
import hashlib
import itertools
import random
import redis
import datetime
from sqlalchemy import or_, and_, func

import consts
from config import config
from db import session
from extensions import sentry
from service.statistic.baseservice import ServiceBaseService
from service.back_test.models import Users, Strategy, VStrategies, StrategyPortfolio, \
    VStrategyAccountDetail, StrategyPerfInput, StrategyRemark, TradeLogs, InvestMentShare, \
    NewStrategySet, NewStrategySetdetail, NewStrategySetShare, DefaulStrategySet, StockHedgeVs, StrategyOwners
from service.back_test.live_position_models import VsBase
from service.back_test.live_trading_models import VstrategyMarketMetric
from service.statistic.models import VsAggregationPnl
from utils import get_cache, set_cache, del_cache
from service.statistic.investment import BaseInvestmentServiceMixin, gen_hash_value, gen_str_hash_value


class LiveAnalysisPerformanceService(BaseInvestmentServiceMixin, ServiceBaseService):
    _lastday_position = {}
    _last_total_pnl = {}

    def __init__(self, current_user, id_list, **kwargs):
        self.current_user = current_user
        self.id_list = id_list
        self.kwargs = kwargs
        self.sc = session()
        self.trading_date, self.day_night = StrategyPerfInput.get_trading_date_day_night()
        self.cache_key = kwargs.get('cache_key', '')
        if not self.cache_key:
            self.cache_key = 'platform_live_analysis_basic_data_%s_%s' % (
                self.current_user['id'], gen_hash_value(self.id_list))
        self.vs_detail = {}
        self.trade_detail = {}
        super(LiveAnalysisPerformanceService, self).__init__()

    def __del__(self):
        self.sc.close()
        self.kdb.release()

    def investment_basic_data(self):
        strategies_detail = self.sc.query(
            VStrategies.id.label('vs_id'),
            VStrategies.status.label('strategy_status'),
            VStrategies.closing_out.label('close_status'),
            VStrategies.trade_model.label('vs_trade_model'),
            Strategy.id_no.label('id_no'),
            Strategy.id.label('s_id'),
            Strategy.r_create_user_id.label('s_user_id'),
            Strategy.username.label('creator'),
            Strategy.products.label('s_products'),
            Strategy.strategy_type.label('strategy_type'),
            Strategy.r_create_time.label('s_create_time'),
            Strategy.name.label('s_name'),
            StrategyPortfolio.id.label('sp_id'),
            StrategyPortfolio.name.label('portfolio_name'),
            StrategyPortfolio.r_create_user_id.label('p_user_id'),
            StrategyPortfolio.live_time.label('p_live_time'),
            StrategyPortfolio.r_create_time.label('p_create_time'),
            Strategy.strategy_feature.label('strategy_feature'),
            Strategy.strategy_para_type.label('strategy_para_type'),
            Strategy.description.label('desc'),
            Strategy.paper_trading_date.label('paper_trading_date'),
            Strategy.hedge.label('hedge'),
            Strategy.hedge_type.label('hedge_type'),
            Strategy.detail.label('s_detail'),
            Strategy.node.label('node'),
        ).join(
            Strategy, or_(
                and_(
                    Strategy.id == VStrategies.strategy_id,
                    VStrategies.group_id == 0
                ),
                Strategy.id == VStrategies.group_id
            )
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            StrategyPortfolio.r_create_user_id != 26,
            VStrategies.status >= consts.STRATEGY_LIVE,
            StrategyPortfolio.source == 'platform',
            VStrategies.source == 'platform'
        )

        my_vs_ids = self.sc.query(
            VStrategies.id
        ).join(
            Strategy, Strategy.id == VStrategies.strategy_id
        ).join(
            StrategyOwners,
            StrategyOwners.strategy_id == Strategy.id
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            or_(
                StrategyOwners.owner_id == self.current_user['id'],
                self.current_user['is_superuser'] == True,
            )
        )

        my_vs_hedge_vs_ids = self.sc.query(
            StockHedgeVs.future_vs_id
        ).filter(
            StockHedgeVs.stock_vs_id.in_(my_vs_ids),
            StockHedgeVs.valid == True
        )

        all_my_vs_ids = set([i[0] for i in my_vs_ids] + [i[0] for i in my_vs_hedge_vs_ids])

        strategies_detail = strategies_detail.filter(
            VStrategies.id.in_(all_my_vs_ids)
        )

        if len(self.id_list) > 0:
            if self.id_list[0] == 0:
                strategies_detail = strategies_detail.filter(
                    VStrategies.status == consts.STRATEGY_LIVE,
                )
            elif self.id_list[0] == -1:
                strategies_detail = strategies_detail.filter(
                    VStrategies.status == consts.STRATEGY_OFF_SHELF,
                )

        strategies_detail = strategies_detail.order_by(Strategy.id.desc())
        # strategy_user_ids = [self.current_user['id']]

        summary = {
            'vs_ids': [],
            'today_pnl': 0,
            'total_pnl': 0,
            'total_point': 0,
            'total_net_income': 0,
            'invest_funds': 0,
            'total_invest_cash': 0,
            'pnl_url': '',
            'pnl_args': {
                'summary': True,
            },
            'year_pnl': 0,
            'month_1_pnl': 0,
            'trading_days_20_pnl': 0,
            'trading_days_40_pnl': 0,
            'trading_days_60_pnl': 0,
        }

        strategies = {}
        vs_detail = {}
        group_detail = {}
        for s in strategies_detail:
            if s.s_id not in strategies:
                strategies[s.s_id] = {
                    'create_user_id': s.s_user_id,
                    'status': '',
                    'creator': s.creator,
                    'desc': s.desc,
                    'hedge': s.hedge,
                    'hedge_type': s.hedge_type,
                    'upload_type': s.node if s.node != 'back_test' else 'so_file',
                    'invest_funds': 0,
                    'name': s.s_name,
                    'papertrading_date': (s.paper_trading_date or s.s_create_time).strftime('%Y-%m-%d'),
                    'products': s.s_products,
                    'trade_model': s.s_detail.get('trade_model', ''),
                    'vs_trade_model': s.vs_trade_model or s.s_detail.get('trade_model', ''),
                    'realtime': '',
                    's_id': s.s_id,
                    'strategy_feature': s.strategy_feature,
                    'strategy_id': s.id_no,
                    'strategy_para_type': s.strategy_para_type,
                    'strategy_type': s.strategy_type,
                    'today_pnl': 0,
                    'total_net_income': 0,
                    'total_pnl': 0,
                    'total_point': 0,
                    'uptime': s.s_create_time.strftime('%Y%m%d'),
                    'ctime': s.s_create_time.strftime('%Y%m%d %X'),
                    'vwap_slippage': {
                        'avg': None,
                        'std': None
                    },
                    'accounts': [],
                    'notebook_links': [],
                    'p_user_id': s.p_user_id,
                    'year_pnl': 0,
                    'month_1_pnl': 0,
                    'trading_days_20_pnl': 0,
                    'trading_days_40_pnl': 0,
                    'trading_days_60_pnl': 0,
                }
                # strategy_user_ids.append(s.s_user_id)
            group_d = group_detail.setdefault((s.sp_id, s.s_id), {
                'vs_ids': []
            })
            group_d['vs_ids'].append(s.vs_id)
            group_d['portfolio_name'] = s.portfolio_name

            vs_d = vs_detail.setdefault(s.vs_id, {
                'invest_funds': 0,
                'accounts': [],
            })
            vs_d['realtime'] = (s.p_live_time or s.p_create_time).strftime('%Y%m%d')
            vs_d['status'] = s.strategy_status
            vs_d['close_status'] = s.close_status
            summary['vs_ids'].append(s.vs_id)
        summary['pnl_args']['vs_ids'] = summary['vs_ids']
        summary['pnl_url'] = self.get_pnl_graph_url(summary['pnl_args'])
        strategy_remarks = self.sc.query(StrategyRemark).filter(StrategyRemark.sid.in_(strategies.keys()))
        for r in strategy_remarks:
            if r.links:
                strategies[r.sid]['notebook_links'].extend(r.links)

        invest_funds = self.sc.query(
            VStrategyAccountDetail.vstrategy_id.label('vs_id'),
            VStrategyAccountDetail.account.label('account'),
            func.sum(VStrategyAccountDetail.amount).label('amount'),
            func.sum(VStrategyAccountDetail.actual_amount).label('actual_amount'),
        ).filter(
            VStrategyAccountDetail.vstrategy_id.in_(vs_detail.keys()),
        ).group_by(
            VStrategyAccountDetail.vstrategy_id,
            VStrategyAccountDetail.account
        )
        for r in invest_funds:
            vs_detail[r.vs_id]['accounts'].append(r.account)
            if vs_detail[r.vs_id]['status'] == consts.STRATEGY_LIVE:
                vs_detail[r.vs_id]['invest_funds'] += float(r.amount)
                summary['invest_funds'] += float(r.amount)
        summary['total_invest_cash'] = sum(VStrategyAccountDetail.get_vstrategy_cash2(summary['vs_ids']).values())

        for (sp_id, s_id), group_d in group_detail.items():
            group_d.update(strategies[s_id])
            group_d['realtime'] = min([vs_detail[v_id]['realtime'] for v_id in group_d['vs_ids']])
            group_d['accounts'] = list(set(itertools.chain.from_iterable(
                [vs_detail[v_id]['accounts'] for v_id in group_d['vs_ids']]
            )))

            if group_d['vs_ids']:
                group_d['vwap_slippage'] = Strategy.get_strategy_slippage(ids=group_d['vs_ids'], id_type='vs')
                group_d['status'] = VStrategies.get_status(
                    vs_detail[group_d['vs_ids'][0]]['status'],
                    vs_detail[group_d['vs_ids'][0]]['close_status'],
                    group_d['vs_ids'][0]
                )
                group_d['invest_funds'] = sum(
                    [vs_detail.get(v_id, {}).get('invest_funds', 0) for v_id in group_d['vs_ids']])
            group_d['id'] = '%s_%s' % (sp_id, s_id)
            group_d['pnl_args'] = {
                'summary': False,
                'vs_ids': group_d['vs_ids'],
                'strategy_id': group_d['s_id'],
            }
            group_d['pnl_url'] = self.get_pnl_graph_url(group_d['pnl_args'])
        return {
            'summary': summary,
            'rows': sorted(group_detail.values(), key=lambda d: d.get('realtime', ''), reverse=True)
        }

    def investment_pnl_data2(self):
        strategies_detail = self.sc.query(
            VStrategies.id.label('vs_id'),
            VStrategies.trade_model.label('vs_trade_model'),
            Strategy.id.label('s_id'),
            Strategy.paper_trading_date.label('paper_trading_date'),
            Strategy.r_create_time.label('s_create_time'),
            Strategy.hedge.label('hedge'),
            Strategy.hedge_type.label('hedge_type'),
            Strategy.strategy_type.label('strategy_type'),
            Strategy.detail.label('s_detail'),
            Strategy.node.label('node'),
            StrategyPortfolio.id.label('sp_id'),
            StrategyPortfolio.r_create_user_id.label('p_user_id'),
        ).join(
            Strategy, or_(
                and_(
                    Strategy.id == VStrategies.strategy_id,
                    VStrategies.group_id == 0
                ),
                Strategy.id == VStrategies.group_id
            )
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            StrategyPortfolio.r_create_user_id != 26,
            VStrategies.status >= consts.STRATEGY_LIVE,
            StrategyPortfolio.source == 'platform',
            VStrategies.source == 'platform',
        )

        strategies_detail = strategies_detail.filter(VStrategies.id.in_(self.id_list))

        strategies_detail = strategies_detail.order_by(Strategy.id.desc())

        group_detail = {}
        vs_ids = []
        total_live_pnls = []
        for s in strategies_detail:
            g_id = '%s_%s' % (s.sp_id, s.s_id)
            group_d = group_detail.setdefault(g_id, {
                's_id': s.s_id,
                'vs_ids': []
            })
            group_d['vs_ids'].append(s.vs_id)
            group_d['p_user_id'] = s.p_user_id
            group_d['papertrading_date'] = (s.paper_trading_date or s.s_create_time).strftime('%Y-%m-%d')
            group_d['hedge'] = s.hedge
            group_d['hedge_type'] = s.hedge_type
            group_d['strategy_type'] = s.strategy_type
            group_d['upload_type'] = s.node if s.node != 'back_test' else 'so_file'
            group_d['trade_model'] = s.s_detail.get('trade_model', '')
            group_d['vs_trade_model'] = s.vs_trade_model or s.s_detail.get('trade_model', '')
            vs_ids.append(s.vs_id)

        for _, group_d in group_detail.items():
            if not self.kwargs.get('is_summary'):
                group_d['events'] = Strategy.get_accident_events(group_d['vs_ids'])
            else:
                group_d['events'] = {}

            s_pnl = Strategy.investment_performance_net_pnl(
                group_d['s_id'], group_d['vs_ids'], trading_date=self.trading_date, day_night=self.day_night
            )
            group_d.update(s_pnl['back_test_paper_trading_net_line'])
            group_d.update(s_pnl['live_net_combine_line'])
            group_d.update(s_pnl['vs_back_test_combine_net'])
            total_live_pnls.append(s_pnl['live_net_combine_line']['pnl'])

        if self.kwargs.get('is_summary'):
            summary_live_pnl = Strategy.combine_pnls(
                total_live_pnls, mode='live'
            )
            return {
                'summary_live_pnl': summary_live_pnl,
            }
        return group_detail

    def get_investment_live_pnl(self):
        strategies_detail = self.sc.query(
            VStrategies.id.label('vs_id'),
            VStrategies.symbols_accounts_detail.label('symbols_accounts'),
            Strategy.id.label('s_id'),
            Strategy.r_create_user_id.label('create_user_id'),
            Strategy.strategy_type.label('strategy_type'),
            StrategyPortfolio.id.label('sp_id'),
        ).join(
            Strategy, or_(
                and_(
                    Strategy.id == VStrategies.strategy_id,
                    VStrategies.group_id == 0
                ),
                Strategy.id == VStrategies.group_id
            )
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            StrategyPortfolio.r_create_user_id != 26,
            VStrategies.status >= consts.STRATEGY_LIVE,
            StrategyPortfolio.status >= consts.STRATEGY_LIVE,
            StrategyPortfolio.source == 'platform',
            VStrategies.source == 'platform'
        )

        my_vs_ids = self.sc.query(
            VStrategies.id
        ).join(
            Strategy, Strategy.id == VStrategies.strategy_id
        ).join(
            StrategyOwners,
            StrategyOwners.strategy_id == Strategy.id
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            or_(
                StrategyOwners.owner_id == self.current_user['id'],
                self.current_user['is_superuser'] == True,
            )
        )

        my_vs_hedge_vs_ids = self.sc.query(
            StockHedgeVs.future_vs_id
        ).filter(
            StockHedgeVs.stock_vs_id.in_(my_vs_ids)
        )

        all_my_vs_ids = set([i[0] for i in my_vs_ids] + [i[0] for i in my_vs_hedge_vs_ids])

        strategies_detail = strategies_detail.filter(
            VStrategies.id.in_(all_my_vs_ids)
        )

        if len(self.id_list) > 0:
            if self.id_list[0] == 0:
                strategies_detail = strategies_detail.filter(
                    VStrategies.status == consts.STRATEGY_LIVE,
                )
            elif self.id_list[0] == -1:
                strategies_detail = strategies_detail.filter(
                    VStrategies.status == consts.STRATEGY_OFF_SHELF,
                )

        strategies_detail = strategies_detail.order_by(Strategy.id.desc())

        vs_agg_pnl = VsAggregationPnl.get_aggregation_pnl()

        agg_pnl_keys = ['year_pnl', 'month_1_pnl', 'trading_days_20_pnl', 'trading_days_40_pnl', 'trading_days_60_pnl']

        summary = {
            'today_pnl': 0,
            'total_pnl': 0,
            'total_point': 0,
            'total_net_income': 0,
            'fee': 0,
            'year_pnl': 0,
            'month_1_pnl': 0,
            'trading_days_20_pnl': 0,
            'trading_days_40_pnl': 0,
            'trading_days_60_pnl': 0,
        }

        group_detail = {}
        for s in strategies_detail:
            g_id = '%s_%s' % (s.sp_id, s.s_id)
            group_d = group_detail.setdefault(g_id, {
                's_id': s.s_id,
                'vs_ids': [],
                'create_user_id': s.create_user_id,
                'year_pnl': 0,
                'month_1_pnl': 0,
                'trading_days_20_pnl': 0,
                'trading_days_40_pnl': 0,
                'trading_days_60_pnl': 0,
            })
            group_d['vs_ids'].append(s.vs_id)
            acc_currency = {
                _acc_d['account']: consts.FOREGIN_ACCOUNT.get(_acc_d['account']) or _acc_d.get('currency',
                                                                                               'CNY') or 'CNY'
                for _acc_d in VStrategies.normalization_symbols_accounts(s.symbols_accounts)
            }
            acc_currency['20052121'] = 'CNY'
            vs_d = self.vs_detail.setdefault(s.vs_id, {})
            vs_d['acc_currency'] = acc_currency
            vs_d['strategy_type'] = s.strategy_type

        market_volumes = self.sc.query(
            VstrategyMarketMetric.vs_id,
            func.max(VstrategyMarketMetric.volume_percent),
        ).filter(
            VstrategyMarketMetric.trading_date == self.trading_date,
            VstrategyMarketMetric.vs_id.in_(self.vs_detail.keys())
        ).group_by(VstrategyMarketMetric.vs_id)

        market_volumes = {r[0]: float(r[1]) for r in market_volumes}

        if group_detail:
            if not self.trade_detail:
                self.trade_detail = self.get_current_day_trading_logs()
            for k, group_d in group_detail.items():
                pnl = self.get_current_day_pnl(group_d['vs_ids'])
                group_d['today_pnl'] = pnl['today_pnl']
                group_d['total_pnl'] = pnl['total_pnl']
                group_d['fee'] = pnl['fee']
                if any([self.vs_detail.get(v_id, {}).get('strategy_type') in consts.stock_strategy_type for v_id in
                        group_d['vs_ids']]):
                    group_d['market_volume'] = round(
                        max([market_volumes.get(v_id, 0) for v_id in group_d['vs_ids']] or [0]), 4)

                if group_d['total_pnl'] != 0:
                    group_d['total_point'] = round(
                        group_d['total_pnl'] * (
                            consts.TOTAL_POINT_RATIO if group_d['create_user_id'] != self.current_user['id'] else 0
                        ),
                        3
                    )
                    group_d['total_net_income'] = round(group_d['total_pnl'] - group_d['total_point'], 3)
                else:
                    group_d['total_net_income'] = round(group_d['total_pnl'], 3)
                    group_d['total_point'] = 0

                group_d_agg_pnl = VsAggregationPnl.get_vs_aggregation_pnl(group_d['vs_ids'], vs_agg_pnl)
                for k in agg_pnl_keys:
                    group_d[k] = group_d_agg_pnl.get(k, 0) + group_d['today_pnl']
                    summary[k] = summary.get(k, 0) + group_d[k]

                summary['today_pnl'] += group_d['today_pnl']
                summary['total_pnl'] += group_d['total_pnl']
                summary['total_point'] += group_d['total_point']
                summary['total_net_income'] += group_d['total_net_income']
                summary['fee'] += group_d['fee']

        group_detail['summary'] = summary
        return group_detail

    @staticmethod
    def clear_cache(current_user, **kwargs):
        cache_rds = redis.Redis(host=config.redis['host'], port=config.redis['port'], db=config.redis['db'])
        if current_user:
            cache_key = 'platform_live_analysis_basic_data_%s*' % current_user['id']
        else:
            cache_key = 'platform_live_analysis_basic_data_*'
        for key in cache_rds.keys(cache_key):
            cache_rds.delete(key)
        del_cache('platform_vstartegy_today_trading_data')
        del_cache('platform_vstartegy_lastday_position_data')
        del_cache('platform_vstartegy_last_settle_total_pnl')
        LiveAnalysisPerformanceService._last_total_pnl.clear()
        LiveAnalysisPerformanceService._lastday_position.clear()
        return True

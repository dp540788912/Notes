import pandas as pd
import numpy as np
import os
import copy
from qpython import qconnection
import pickle as pkl


def get_kdb(sql, database, pandas=True):
    with qconnection.QConnection(host='192.168.10.102',
                                 port=9000,
                                 username='user1',
                                 password='password') as q:
        q.async('.gw.asyncexec["' + sql + '"; `' + database + ']')
        return q.receive(pandas=pandas)


def datetostr(date):
    # date format: 'yyyy.mm.dd...', 'yyyy-mm-dd...'
    x = str(date)
    return x[:4] + '.' + x[5:7] + '.' + x[8:10]


def tradecalendar():
    y = get_kdb('select date:TRADE_DT  from Calendar where EXCHANGE in `SSE`SZSE', 'FuturesBasicInfo')
    y = sorted(y['date'].unique())
    y = [datetostr(x) for x in y]
    return y


calendar = tradecalendar()


def addition_tradeday(date, x):
    # date format: 'yyyy.mm.dd'
    # x: [int, ..., int]
    global calendar
    no_date = sum([1 for z in calendar if z < date])
    y = [calendar[no_date + z] for z in x]
    return y


def factor_return(date, risk_ev_path, buy='close', sell='close', hedging='zz500'):
    # date
    date_int = str(date)
    date_next = addition_tradeday(date_int[0:4] + '.' + date_int[4:6] + '.' + date_int[6:8], [1])[0]

    # riskfactor
    file = 'portfolio_optimization_ev_rtn_' + date_next.replace('.', '') + '.csv'
    ev = pkl.load(open(os.path.join(risk_ev_path, file), 'rb'))[1][hedging + '_gg']
    ev.columns = ['symbol', 'rtn']

    fct_default_orth = {'bt': 'bt_' + hedging + '_barra2_orth_' + hedging + '_gg',
                        'bd': 'bd_' + hedging + '_barra2_orth_' + hedging + '_gg',
                        'gg': 'gg_barra2_orth_' + hedging + '_gg',
                        'jz': 'jz_btop_barra2_orth_' + hedging + '_gg',
                        'ld': 'ld_barra2_orth_' + hedging + '_gg',
                        'mm': 'mm_rstr_barra2_orth_' + hedging + '_gg',
                        'mv': 'mv_lnfloat_barra2_orth_' + hedging + '_gg',
                        'yl': 'yl_barra2_orth_' + hedging + '_gg'}

    factor_rtn = {}
    for fct in ['mv', 'bt', 'bd', 'ld', 'mm', 'yl', 'jz', 'gg']:
        factor_rtn[fct] = list(ev.loc[ev['symbol'] == fct_default_orth[fct], 'rtn'])[0]

    return factor_rtn

# -*-coding:utf-8-*-

import os
import pandas as pd
import numpy as np
import datetime
from dateutil.parser import parse

import consts
from db import session
from service.back_test.models import TradeLogs
from config import config
from utility.func_util.decorator import retry, check_market_data_status
from errors import DataNotReadyException
# from concurrent.futures import ProcessPoolExecutor, as_completed


def get_time_range(time_range_minutes=15):
    _night_start_time = parse('20:57:00')
    _night_end_time = parse('02:33:00')
    _day_start_time = parse('08:57:00')
    _day_end_time = parse('15:03:00')

    night_start_time = parse('21:00:00')
    day_start_time = parse('09:00:00')

    night_mins = [night_start_time + datetime.timedelta(minutes=i) for i in range(331)]
    night_mins[0] = _night_start_time
    night_mins[-1] = _night_end_time
    night_time_range = [night_mins[i:i + time_range_minutes] for i in range(0, len(night_mins), time_range_minutes)]

    if night_time_range[-1][0].strftime('%H%M%S') >= '022500':
        night_time_range[-2].extend(night_time_range[-1])
        night_time_range.pop(-1)

    day_mins = [day_start_time + datetime.timedelta(minutes=i) for i in range(361)]
    day_mins[0] = _day_start_time
    day_mins[-1] = _day_end_time
    day_time_range = [day_mins[i:i + time_range_minutes] for i in range(0, len(day_mins), time_range_minutes)]
    if day_time_range[-1][0].strftime('%H%M%S') >= '145500':
        day_time_range[-2].extend(day_time_range[-1])
        day_time_range.pop(-1)

    time_ranges = night_time_range + day_time_range

    ranges = {}
    for i, r in enumerate(time_ranges, 1):
        ranges[i] = {
            'start': r[0].strftime('%H%M00'),
            'end': r[-1].strftime('%H%M59')
        }
    return ranges


def get_mkt_volume_ratio(trading_date, filter_account=None, **kwargs):
    if not filter_account:
        # account = list(consts.future_risk_accounts.keys())
        account = [
            '80002928',
            '80003702',
            '80001865',
            '21000092',
            '21000087',
            '85011366',
            '0380000868',
            '21000020',
            '27800662',
        ]
    else:
        account = filter_account

    sc = session()
    logs = sc.query(
        TradeLogs.symbol,
        TradeLogs.calendar_time,
        TradeLogs.trade_vol,
        TradeLogs.account,
    ).filter(
        TradeLogs.trading_date == trading_date,
        TradeLogs.log_type == '3',
        TradeLogs.account.in_(account),
    ).order_by(
        TradeLogs.calendar_date, TradeLogs.calendar_time, TradeLogs.calendar_microsec
    )

    time_range_minutes = int(kwargs.get('time_range_minutes', 15))
    time_ranges = get_time_range(time_range_minutes)
    max_time_range = max(time_ranges.keys())
    values = []
    last_time_range = 1
    for l in logs:
        t = l.calendar_time.strftime('%H%M%S')
        t_r = last_time_range
        for i in range(t_r, max_time_range + 1):
            if time_ranges[i]['start'] <= t <= time_ranges[i]['end']:
                t_r = i
                last_time_range = i
                break
        symbol = '%s_%s' % (l.symbol, consts.future_risk_accounts[l.account]['currency'])
        values.append([symbol, l.trade_vol, t_r])
    sc.close()

    df = pd.DataFrame(values, columns=['symbol', 'trade_vol', 'time_range'])
    df = df.groupby(['symbol', 'time_range']).sum().reset_index()

    # when df is null, return directly
    if df.empty:
        raise DataNotReadyException("fail to find trading log in mysql database")
    symbols = set(df['symbol'])
    symbol_mkt_trade_vol = {}

    # with ProcessPoolExecutor(max_workers=16) as executor:
    #     future_res = {}
    #     for s in symbols:
    #         sym, currency = s.split('_')
    #         fu = executor.submit(get_symbol_mkt_trade_vol, sym, trading_date, currency=currency)
    #         future_res[fu] = s
    #     for fu in as_completed(future_res.keys()):
    #         s = future_res[fu]
    #         if fu.exception() is not None:
    #             continue
    #         else:
    #             symbol_mkt_trade_vol[s] = fu.result()
    for s in symbols:
        sym, currency = s.split('_')
        symbol_mkt_trade_vol[s] = get_symbol_mkt_trade_vol(
            sym, trading_date, currency=currency, time_range_minutes=time_range_minutes
        )

    columns = ['symbol', 'time_range', 'start_time', 'end_time', 'currency', 'trade_vol', 'mkt_vol']
    values = []
    for i, row in df.iterrows():
        sym, currency = row['symbol'].split('_')
        mkt_vol = 0
        try:
            mkt_vol = symbol_mkt_trade_vol[row['symbol']][row['time_range']]['total_vol']
        except Exception as e:
            pass
        values.append([
            sym, row['time_range'], time_ranges[row['time_range']]['start'], time_ranges[row['time_range']]['end'],
            currency, row['trade_vol'], mkt_vol
        ])
    df = pd.DataFrame(values, columns=columns)

    # verify data integrity
    if any(df['mkt_vol'] < df['trade_vol']):
        # mkt vol missing, raise error
        raise DataNotReadyException("market volume is missing")

    df['volumn_ratio'] = df['trade_vol'] / df['mkt_vol']
    # deal with inf value
    df.loc[df["mkt_vol"] == 0, "volumn_ratio"] = 0

    file_name = '%s_%s_%s' % (
        trading_date,
        ''.join(sorted(filter_account)) if filter_account else 'all',
        time_range_minutes
    )
    csv_file_name = os.path.join(config.media, 'future_mkt_volumn_ratio', '%s.csv' % file_name)
    df.to_csv(csv_file_name)
    return df


def convert_future_quote_to_dataframe(arr_data):
    quote = arr_data['quote']
    INNER_ARRAY = ["ap_array", "av_array", "bp_array", "bv_array", "implied_bid_size", "implied_ask_size"]
    NAMES = [n for n in quote.dtype.names if n not in INNER_ARRAY]

    df1 = pd.DataFrame(quote[NAMES], columns=NAMES)
    pv_arr = np.concatenate([quote.__getitem__(f) for f in INNER_ARRAY[0:4]], axis=1)
    FLAT_ARRAY = [n + str(i) for n in INNER_ARRAY[0:4] for i in range(5)]

    df2 = pd.DataFrame(pv_arr, columns=FLAT_ARRAY)
    return pd.concat([df1, df2], axis=1)


def get_symbol_mkt_trade_vol(symbol, trading_date, currency='cny', **kwargs):
    from my.data import quote
    m_type = 212
    if currency.upper() == 'USD':
        m_type = 225

    time_range_minutes = kwargs.get('time_range_minutes', 15)
    time_ranges = get_time_range(time_range_minutes)
    time_range_vol = {}

    for i, t_r in time_ranges.items():
        time_range_vol[i] = {
            'start': 0,
            'end': 0,
        }
        t_r['start'] = int(t_r['start']) * 1000
        t_r['end'] = int(t_r['end']) * 1000
        if t_r['start'] <= 23400000:
            t_r['start'] += 240000000
        if t_r['end'] <= 23400000:
            t_r['end'] += 240000000
    try:
        night_df = convert_future_quote_to_dataframe(quote.data(int(trading_date), m_type, symbol, 1, 0))
        night_df = night_df[['int_time', 'total_vol']]
    except Exception as e:
        night_df = pd.DataFrame([], columns=['int_time', 'total_vol'])

    max_time_range = max(time_ranges.keys())

    last_time_range = 1
    for _, row in night_df.iterrows():
        t = row['int_time']
        if (t < 205700000) or (t > 263300000):
            continue
        for i in range(last_time_range, max_time_range + 1):
            if time_ranges[i]['start'] <= t <= time_ranges[i]['end']:
                last_time_range = i
                break
        time_range_vol[last_time_range]['end'] = row['total_vol']
        if not time_range_vol[last_time_range]['start']:
            time_range_vol[last_time_range]['start'] = row['total_vol']
    try:
        day_df = convert_future_quote_to_dataframe(quote.data(int(trading_date), m_type, symbol, 0, 0))
        day_df = day_df[['int_time', 'total_vol']]
    except Exception as e:
        day_df = pd.DataFrame([], columns=['int_time', 'total_vol'])

    last_time_range = 1
    for _, row in day_df.iterrows():
        t = row['int_time']
        if (t < 85700000) or (t > 150300000):
            continue
        for i in range(last_time_range, max_time_range + 1):
            if time_ranges[i]['start'] <= t <= time_ranges[i]['end']:
                last_time_range = i
                break
        time_range_vol[last_time_range]['end'] = row['total_vol']
        if not time_range_vol[last_time_range]['start']:
            time_range_vol[last_time_range]['start'] = row['total_vol']

    for i, t_v in time_range_vol.items():
        t_v['total_vol'] = (t_v['end'] - t_v['start'])

    return time_range_vol

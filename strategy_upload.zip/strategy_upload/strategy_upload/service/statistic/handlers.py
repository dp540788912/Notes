# -*-coding:utf-8-*-

import os
import base64
import json
import datetime
import uuid
import copy
import subprocess
import pandas as pd
from tornado import gen
from sqlalchemy import or_, distinct, func
from dateutil.parser import parse
from glob import glob
from config import config
import consts
from re import split
from service.basehandler import BaseHandler, CurrentUserMixin, JsonPayloadMixin, DownloadMixin
from service.statistic.investment import InvestmentPerformanceService, InvestmentPerformanceShareService, \
    InvestmentStrategyMetricService, InvestmentPerformanceGroupStrategyService, gen_str_hash_value, \
    InvestmentPerformanceServiceV1
from db import session
from service.back_test.models import Users, VStrategies, StrategyPortfolio, Strategy, \
    StrategyBackTestResultPerformance, VsBackTestOperationlogs, TradeLogs, MutilFactorStrategy, StrategyOwners, \
    StrategyResult, StrategyResultDetail, StrategyResultAccount, StockPortfolioOptimizationVersion, \
    StockSmartExecutionVersion, BackTestTradeLogs, ToBeDeletedStrategy, VsbBackTestPara, VsEventTrack, \
    StrategyEventTrack
from service.back_test.live_position_models import VsBase
from service.back_test.live_trading_models import VstrategyMarketMetric
from service.statistic.track import StrategyTrackService
from service.statistic.live_analysis import LiveAnalysisPerformanceService
from service.statistic.models import AnalysisStrategyList, StrategyEvaluation, StrategyStyleExposure, \
    VStrategyStyleExposure, \
    StrategyIncomeAttribution, VStrategyIncomeAttribution, StrategyVwapExecutimeTime, StockFactorReturn, \
    VsBacktestTradingVolumeRatioStatistic, StrategyTradingVolumeRatioStatistic, VsTradingVolumeRatioStatistic, \
    VsLiveRangePerformance, StrategyRiskAttribute, StrategyBackTestTradeIndicator, PortfolioRiskAttribute, \
    StrategyIncomeAttributionAdjusted
from service.vwap.models import StrategyBackTestSlippage
from service.statistic.performance import StrategyPortfolioPerformance, StrategyPerformance
from cron.strategy_upload_task import start_strategy_task, update_strategy_sorting_result, \
    redo_strategy_papertrading, gen_portfolio_daily_max_volume_ratio_delay, generate_strategy_portfolio_risk_delay, \
    generate_vs_portfolio_risk_delay, generate_future_mkt_volume_ratio_delay

from service.statistic.live_sim_diff_analysis import StockVsDiff
from service.statistic.live_log import get_live_log
from service.statistic.tmp_consts import SW_IndustryCategory, tmp_stock_ind
from service.statistic.performance import BackTestPerformance
from service.statistic.future_mkt_volumn_ratio import get_time_range
from utils import del_cache, get_cache, set_cache, get_hash_cache

from extensions import sentry
from constant import TradingTimeRange, StrategyEventTrackConstant, StrategyConstant, APIResponseCode, HedgeBenchmark, \
    RedisKeyConstant
from models.strategy import UnionSimuStrategyRelation


def split_initial_cash(total_initial_cash, stra_weights):
    stra_initial_cash = {}
    stra_ids = sorted(stra_weights.keys())
    num = len(stra_ids)
    for i, id in enumerate(stra_ids):
        if i == num - 1:
            stra_initial_cash[id] = total_initial_cash - sum(stra_initial_cash.values())
        else:
            stra_initial_cash[id] = int(stra_weights[id] * total_initial_cash)
    return stra_initial_cash


class InvestmentPerformanceBaseHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        user_role = self.user_role()
        business = self.get_argument("type", "")
        s_id_list = self.get_argument('s_id_list', '')
        id_list = self.parse_list(s_id_list)

        investment = InvestmentPerformanceServiceV1(
            self.current_user, id_list, user_role=user_role, business=business
        )
        data = investment.get_basic_data()
        # data = investment.investment_basic_data()
        investment.close()
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class InvestmentPerformanceDetailHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        user_role = self.user_role()
        business = self.get_argument("type", "")
        is_summary = True if self.get_argument('summary', 'false').lower() == 'true' else False
        s_id_list = self.get_argument('s_id_list', '')
        id_list = self.parse_list(s_id_list)

        investment = InvestmentPerformanceServiceV1(
            self.current_user, id_list, is_summary=is_summary, business=business, user_role=user_role
        )
        data = investment.investment_pnl_data()
        investment.close()
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class InvestmentPerformanceRealTimeHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        user_role = self.user_role()
        business = self.get_argument("type", "")
        s_id_list = self.get_argument('s_id_list', '')
        id_list = self.parse_list(s_id_list)

        investment = InvestmentPerformanceServiceV1(
            self.current_user, id_list, business=business, user_role=user_role
        )
        yield investment.async_get_live_quote()
        data = investment.get_investment_live_pnl()
        investment.close()
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class InvestmentPerformanceBasicHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        is_stock_page = self.is_stock_page()
        is_stock_group = self.is_stock_group() or self.is_manage_department()
        is_future_page = self.is_future_page()
        is_future_group = self.is_future_group()

        business = ''
        if is_stock_page and is_stock_group:
            business = 'stock'

        if is_future_page and is_future_group:
            business = 'future'

        s_id_list = self.get_argument('s_id_list', '')
        id_list = []
        if len(s_id_list) > 0:
            for x in s_id_list.split(','):
                try:
                    id_list.append(int(x))
                except Exception as e:
                    pass

        investment = InvestmentPerformanceService(
            self.current_user, id_list, business=business,
            is_stock_page=is_stock_page,
            is_stock_group=is_stock_group,
            is_future_page=is_future_page,
            is_future_group=is_future_group,
        )
        data = investment.get_basic_data()
        # data = investment.investment_basic_data()
        investment.close()
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class InvestmentPerformanceVsPnlHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        is_stock_page = self.is_stock_page()
        is_stock_group = self.is_stock_group()
        is_future_page = self.is_future_page()
        is_future_group = self.is_future_group()

        business = ''
        if is_stock_page and is_stock_group:
            business = 'stock'

        if is_future_page and is_future_group:
            business = 'future'

        s_id_list = self.get_argument('s_id_list', '')
        id_list = []
        if len(s_id_list) > 0:
            for x in s_id_list.split(','):
                try:
                    id_list.append(int(x))
                except Exception as e:
                    pass

        is_summary = True if self.get_argument('summary', 'false').lower() == 'true' else False
        investment = InvestmentPerformanceService(
            self.current_user, id_list, is_summary=is_summary, business=business,
            is_stock_page=is_stock_page,
            is_stock_group=is_stock_group,
            is_future_page=is_future_page,
            is_future_group=is_future_group,
        )
        data = investment.investment_pnl_data2()
        investment.close()
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class InvestmentPerformanceRTHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        is_stock_page = self.is_stock_page()
        is_stock_group = self.is_stock_group() or self.is_manage_department()
        is_future_page = self.is_future_page()
        is_future_group = self.is_future_group()

        business = ''
        if is_stock_page and is_stock_group:
            business = 'stock'

        if is_future_page and is_future_group:
            business = 'future'

        s_id_list = self.get_argument('s_id_list', '')
        id_list = []
        if len(s_id_list) > 0:
            for x in s_id_list.split(','):
                try:
                    id_list.append(int(x))
                except Exception as e:
                    pass

        investment = InvestmentPerformanceService(
            self.current_user, id_list, business=business,
            is_stock_page=is_stock_page,
            is_stock_group=is_stock_group,
            is_future_page=is_future_page,
            is_future_group=is_future_group,
        )
        yield investment.async_get_live_quote()
        data = investment.get_investment_live_pnl()
        investment.close()
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class InvestmentPerformanceGroupBasicHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        keys = kwargs['id'].split('_')
        portfolio_id = int(keys[0])
        strategy_id = int(keys[1])
        investment = InvestmentPerformanceGroupStrategyService(self.current_user, strategy_id, portfolio_id)
        data = investment.get_basic_data()
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class InvestmentPerformanceGroupPnlHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        keys = kwargs['id'].split('_')
        portfolio_id = int(keys[0])
        strategy_id = int(keys[1])
        investment = InvestmentPerformanceGroupStrategyService(self.current_user, strategy_id, portfolio_id)
        data = investment.investment_pnl_data()
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class InvestmentPerformanceGroupRTHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        keys = kwargs['id'].split('_')
        portfolio_id = int(keys[0])
        strategy_id = int(keys[1])
        investment = InvestmentPerformanceGroupStrategyService(self.current_user, strategy_id, portfolio_id)
        yield investment.async_get_live_quote()
        data = investment.get_investment_live_pnl()
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class InvestmentPerformanceCacheClearHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        user_id = self.check_login()
        if user_id:
            current_user = {
                'id': user_id
            }
        else:
            current_user = {}
        InvestmentPerformanceService.clear_cache(current_user)
        LiveAnalysisPerformanceService.clear_cache(current_user)  # not used, to be confirmed
        self.json_response({
            'code': 0,
            'data': '',
        })
        return True


class NewStrategySetHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        if self.is_stock_page():
            page = 'stock'
        elif self.is_future_page():
            page = 'future'
        else:
            page = ''

        is_stock_group = False
        is_future_group = False

        if self.is_stock_group():
            is_stock_group = True

        if self.is_future_group():
            is_future_group = True

        ss = InvestmentPerformanceShareService()

        self.json_response({
            'code': 0,
            'data': ss.get_all_strategy_set(self.current_user, page=page, is_stock_group=is_stock_group,
                                            is_future_group=is_future_group)
        })
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        if self.is_stock_page():
            page = 'stock'
        elif self.is_future_page():
            page = 'future'
        else:
            page = ''

        result = {}
        payload = self.get_payload()
        ss = InvestmentPerformanceShareService()
        if payload['type'] == 'add':
            payload['page'] = page
            result = ss.add_strategy_set(self.current_user, payload)
        elif payload['type'] == 'del':
            result = ss.delete_strategy_set(self.current_user, payload['id'])
        elif payload['type'] == 'set_def':
            ss.set_default2(self.current_user, payload)
        else:
            pass
        self.json_response({
            'code': 0,
            'data': result
        })
        return True


class InvestmentShareStatusHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        ss = InvestmentPerformanceShareService()

        self.json_response({
            'code': 0,
            'data': ss.get_share_status(self.current_user)
        })
        return True


class StrategyShareUsersHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        data = get_cache('investment_strategy_share_user')
        if not data:
            sc = session()
            data = [{
                'id': u[0],
                'name': u[1],
            } for u in sc.query(Users.id, Users.name).order_by(Users.id)]
            sc.close()
            set_cache('investment_strategy_share_user', data, 86400 * 3)
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class InvestmentVstrategyShareBatchHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        payload = self.get_payload()
        ss = InvestmentPerformanceShareService()
        result = ss.batch_share_vstrategies(self.current_user, payload)
        self.json_response({
            'code': 0,
            'data': result
        })
        return True


class InvestmentVstrategyShareHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        payload = self.get_payload()
        ss = InvestmentPerformanceShareService()
        result = ss.share_vstrategies(self.current_user, payload)
        self.json_response({
            'code': 0,
            'data': result
        })
        return True


class CancelInvestmentVstrategyShareHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        payload = self.get_payload()
        ss = InvestmentPerformanceShareService()
        result = ss.cancel_share_vstrategies(self.current_user, payload)
        self.json_response({
            'code': 0,
            'data': result
        })
        return True


class UnsubscribeInvestmentVstrategyShareHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        payload = self.get_payload()
        ss = InvestmentPerformanceShareService()
        result = ss.cancel_subscribe_vstrategies(self.current_user, payload)
        self.json_response({
            'code': 0,
            'data': result
        })
        return True


class InvestmentStrategySetShareHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        payload = self.get_payload()
        ss = InvestmentPerformanceShareService()
        success, msg = ss.share_strategy_set(self.current_user, payload)
        if not success:
            self.json_response({
                'code': 3001,
                'error': msg
            })
        else:
            self.json_response({
                'code': 0,
                'data': msg
            })
        return True


class InvestmentStrategySetShareBatchHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        payload = self.get_payload()
        ss = InvestmentPerformanceShareService()
        success, msg = ss.batch_share_strategy_set(self.current_user, payload)
        if not success:
            self.json_response({
                'code': 3001,
                'error': msg
            })
        else:
            self.json_response({
                'code': 0,
                'data': msg
            })
        return True


class CancelInvestmentStrategySetShareHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        payload = self.get_payload()
        ss = InvestmentPerformanceShareService()
        ss.cancel_share_strategy_set(self.current_user, payload)
        self.json_response({
            'code': 0,
            'data': ''
        })
        return True


class InvestmentStrategyMetricHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):

        ss = InvestmentStrategyMetricService()
        s_ids = self.get_argument('s_ids', '')
        if s_ids:
            s_ids = s_ids.split(',')
        else:
            s_ids = []

        self.json_response({
            'code': 0,
            'data': ss.get_strategy_metric(s_ids)
        })
        return True


class InvestmentVstrategyPositionHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_ids = self.get_argument('vs_ids')
        data = {}
        vs_ids = [int(v_id) for v_id in vs_ids.split(',')]

        if vs_ids:
            ss = InvestmentPerformanceService({'id': 1}, [])
            data = ss.get_current_day_realtime_trading_logs(vs_ids)
        self.json_response({
            'code': 0,
            'data': data
        })


class MarketVolumeVstrategiesHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        sc = session()
        strategies = sc.query(
            Strategy.id.label('s_id'),
            Strategy.id_no.label('s_id_no'),
            Strategy.name.label('s_name'),
            VStrategies.id.label('vs_id'),
            Strategy.r_create_user_id.label('create_user_id'),
            StrategyPortfolio.r_create_user_id.label('sp_create_user_id'),
            StrategyPortfolio.name.label('sp_name'),
            StrategyPortfolio.username.label('sp_username'),
            StrategyPortfolio.id.label('sp_id'),
        ).join(
            VStrategies, VStrategies.strategy_id == Strategy.id
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            VStrategies.source == 'platform',
            StrategyPortfolio.source == 'platform',
            or_(
                Strategy.r_create_user_id == self.current_user['id'],
                StrategyPortfolio.r_create_user_id == self.current_user['id'],
            ),
            Strategy.strategy_type.in_(consts.stock_strategy_type)
        )

        data = {
            'my_strat': {

            },
            'my_invest': {

            },
        }
        for s in strategies:
            if s.create_user_id == self.current_user['id']:
                data['my_strat'][s.vs_id] = {
                    'type': 'vstrategy',
                    'id': s.vs_id,
                    'stratid': s.s_id,
                    'strat_name': s.s_id_no,
                    'portfolio_name': s.sp_name,
                    'name': '%s_%s' % (s.sp_name, s.s_id_no),
                }
            if s.sp_create_user_id == self.current_user['id']:
                data['my_invest'][s.vs_id] = {
                    'type': 'vstrategy',
                    'id': s.vs_id,
                    'stratid': s.s_id,
                    'strat_name': s.s_id_no,
                    'portfolio_name': s.sp_name,
                    'name': '%s_%s' % (s.sp_name, s.s_id_no),
                }
        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class VsMarketVolumeHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_id = int(kwargs['id'])

        data = VstrategyMarketMetric.get_vstrategy_volume_percent(vs_id)

        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class MarketVolumeVstrategyDailyHandler(DownloadMixin, BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):

        vs_id = int(kwargs['id'])
        today = datetime.datetime.now().strftime('%Y%m%d')
        start_date = parse(str(self.get_argument('start_date', today)))
        end_date = parse(str(self.get_argument('end_date', today)))
        page = int(self.get_argument('page', 0))
        size = int(self.get_argument('size', 50))
        download = str(self.get_argument('download', 'false')).lower()
        if download == 'true':
            download = True
        else:
            download = False

        data, total = VstrategyMarketMetric.get_vstrategy_symbols_volume_percent(
            vs_id, start_date, end_date, page, size, download=download
        )

        if download:
            filename = 'market_volume_%s_%s_%s.csv' % (vs_id, start_date, end_date)
            columns = ['vs_id', 'trading_date', 'symbol', 'start_time', 'end_time', 'volume', 'market_volume',
                       'volume_percent']
            rows = [[d[c] for c in columns] for d in data]
            df = pd.DataFrame(columns=columns, data=rows)
            return self.downfile(df, filename)

        self.json_response({
            'code': 0,
            'total': total,
            'data': data,
        })
        return True


class StrategyPerformancenHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):

        self.get_current_user()
        if not self.current_user:
            return False

        period_month = self.get_argument('period_months', 'all')
        strategy_type = self.get_argument('strategy_type', 'all')

        sort_by = self.get_argument('sort_by', None)
        sort_reverse = self.get_argument('reverse', 'true')
        sort_reverse = True if sort_reverse == 'true' else False

        page_size = int(self.get_argument('page_size', 10))
        page_num = int(self.get_argument('page_num', 0))

        filter = self.get_argument('filter', '{}')
        filter_d = json.loads(filter)
        search = self.get_argument('search', '{}')
        search_d = json.loads(search)

        if sort_by not in ['sharpe', 'annual_return', 'bt_sharpe', 'bt_annual_return', 'pt_days']:
            sort_by = 'sharpe'

        strategy_type = filter_d.get('strategy_type', ['all'])

        if not isinstance(strategy_type, list):
            strategy_type = [strategy_type]

        strategy_id_no = search_d.get('strategy_id_no', '')
        username = search_d.get('creator', '')
        strategy_name = search_d.get('strategy_name', '')
        sc = session()
        strategies = sc.query(
            Strategy.id
        ).filter(
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.node.in_(['back_test', 'order_list', 'trademaster_order_list', 'group', 'union_simu'])
        )
        if strategy_id_no:
            strategies = strategies.filter(
                Strategy.id_no.ilike('%%%s%%' % strategy_id_no)
            )
        if username:
            strategies = strategies.filter(
                Strategy.username.ilike('%%%s%%' % username)
            )
        if strategy_name:
            strategies = strategies.filter(
                Strategy.name.ilike('%%%s%%' % strategy_name)
            )
        if strategy_type and ('all' not in strategy_type):
            strategies = strategies.filter(
                Strategy.strategy_type.in_(strategy_type)
            )

        if period_month != 'all':
            key = 'paper_trading_%s_month' % period_month
            strategies = sc.query(distinct(StrategyBackTestResultPerformance.strategy_id)).filter(
                StrategyBackTestResultPerformance.strategy_id.in_(strategies),
                StrategyBackTestResultPerformance.key == key
            )

        performances = sc.query(
            StrategyBackTestResultPerformance.strategy_id
        ).filter(
            StrategyBackTestResultPerformance.strategy_id.in_(strategies),
            StrategyBackTestResultPerformance.config_id == 0,
        )
        if sort_by in ['bt_sharpe', 'bt_annual_return', 'pt_days']:
            performances = performances.filter(
                StrategyBackTestResultPerformance.key == 'back_test_all'
            )
        else:
            performances = performances.filter(
                StrategyBackTestResultPerformance.key == 'paper_trading_all'
            )

        if 'sharpe' in sort_by:
            sort_key = StrategyBackTestResultPerformance.sharpe
        elif 'annual_return' in sort_by:
            sort_key = StrategyBackTestResultPerformance.annual_return
        elif 'pt_days' in sort_by:
            sort_key = StrategyBackTestResultPerformance.pt_days
        else:
            sort_key = StrategyBackTestResultPerformance.sharpe

        if sort_reverse:
            sort_key = sort_key.desc()
        count = performances.count()
        performances = performances.order_by(sort_key).offset(page_num * page_size).limit(page_size)
        s_ids = [p[0] for p in performances]

        data = {}
        strategies = sc.query(Strategy).filter(Strategy.id.in_(s_ids))
        for s in strategies:
            data[s.id] = s.rank_detail(self.current_user['id'])
            data[s.id]['s_id'] = s.id
            data[s.id]['strategy_id_no'] = s.id_no
            data[s.id]['strategy_name'] = s.name
            data[s.id]['strategy_type'] = s.strategy_type
            data[s.id]['utime'] = s.r_update_time.strftime('%Y%m%d %X')
            data[s.id]['bt_sharpe'] = 'N/A'
            data[s.id]['bt_annual_return'] = 'N/A'
            data[s.id]['sharpe'] = 'N/A'
            data[s.id]['annual_return'] = 'N/A'
            data[s.id]['pt_days'] = 0
            data[s.id]['avg_daily_rounds'] = 0
            data[s.id]['max_drawdown'] = 0
            data[s.id]['drawdown_earn_ratio'] = 'N/A'
            data[s.id]['pnl_url'] = '/media/strategy_pnl_graph/strategy_%s_0_%sthumbnail.png' % (
                s.id, 'hedge_' if s.hedge else '')
        performances = sc.query(
            StrategyBackTestResultPerformance.strategy_id.label('strategy_id'),
            StrategyBackTestResultPerformance.key.label('key'),
            StrategyBackTestResultPerformance.sharpe.label('sharpe'),
            StrategyBackTestResultPerformance.annual_return.label('annual_return'),
            StrategyBackTestResultPerformance.pt_days.label('pt_days'),
        ).filter(
            StrategyBackTestResultPerformance.strategy_id.in_(s_ids),
            StrategyBackTestResultPerformance.key.in_(['back_test_all', 'paper_trading_all'])
        )
        for p in performances:
            if p.strategy_id not in data:
                continue
            data[p.strategy_id]['pt_days'] = p.pt_days
            if p.key == 'back_test_all':
                data[p.strategy_id]['bt_sharpe'] = 'N/A' if abs(float(p.sharpe)) >= 99999 else float(p.sharpe)
                data[p.strategy_id]['bt_annual_return'] = 'N/A' if abs(float(p.annual_return)) >= 99999 else float(
                    p.annual_return)
            elif p.key == 'paper_trading_all':
                data[p.strategy_id]['sharpe'] = 'N/A' if abs(float(p.sharpe)) >= 99999 else float(p.sharpe)
                data[p.strategy_id]['annual_return'] = 'N/A' if abs(float(p.annual_return)) >= 99999 else float(
                    p.annual_return)

        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'sum': count,
                'list': [data[s_id] for s_id in s_ids if s_id in data],
            },
        })
        return True


class StrategyPerformancenIdicatorsHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        s_id = int(kwargs['id'])

        sc = session()
        s_hedge = sc.query(Strategy.hedge).filter(Strategy.id == s_id).first()
        s_hedge = s_hedge and s_hedge[0] or ''
        performances = sc.query(StrategyBackTestResultPerformance).filter(
            StrategyBackTestResultPerformance.strategy_id == s_id
        )
        suffiex = 'year'
        if s_hedge:
            suffiex = 'year_hedge'
        data = [p.to_dict() for p in performances if p.key.endswith(suffiex)]

        sc.close()

        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class AnalysisGraphHandler(CurrentUserMixin, BaseHandler):

    def list_path(self, path, root=False):

        data = []

        for froot, dirs, files in os.walk(path):

            for d in dirs:
                if d.startswith(('.', '__')):
                    continue
                data.append({
                    'name': d,
                    'type': 'dir'
                })

            for f in files:
                if f.startswith(('.', '__')):
                    continue

                if not f.endswith('.py'):
                    continue
                f_path = os.path.join(froot, f)
                app_id = base64.b64encode(f_path.encode('utf-8')).decode('utf-8')
                data.append({
                    'name': f,
                    'type': 'file',
                    'app_id': app_id,
                    'url': '/apps/%s' % app_id,
                })

            break
        if root:
            data.append({
                'name': 'public_apps',
                'type': 'dir'
            })

        return data

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        path = self.get_argument('path', '')
        path = path.lstrip('/')

        user_path = config.user_nb_dir_template % (self.current_user['username'], self.current_user['id'])
        user_path = user_path.rstrip('/')

        user_app_path = os.path.join(user_path, 'apps', path)

        if path == '':
            analysis_path = os.path.join(user_path, 'apps')
            data = self.list_path(analysis_path, root=True)
        elif path.startswith('public_apps'):
            analysis_path = os.path.join(os.path.dirname(user_path), path)
            data = self.list_path(analysis_path)
        else:
            analysis_path = os.path.join(user_path, 'apps', path)
            data = self.list_path(analysis_path)

        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class VsBackTestOperationLogsHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_ids = self.get_argument('vs_ids', '')
        vs_ids = [int(v_id) for v_id in vs_ids.split(',')]
        logs = []
        if vs_ids:
            sc = session()
            logs = sc.query(
                VsBackTestOperationlogs
            ).filter(
                VsBackTestOperationlogs.vs_id.in_(vs_ids)
            ).order_by(
                VsBackTestOperationlogs.id.desc()
            )
            logs = [l.to_dict() for l in logs]
            sc.close()
        self.json_response({
            'code': 0,
            'data': logs
        })
        return True


class VsStockHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):

        sc = session()

        stocks = sc.query(
            VStrategies.id,
            VStrategies.status,
        ).join(
            Strategy, Strategy.id == VStrategies.strategy_id
        ).filter(
            VStrategies.status.in_([15, 16]),
            Strategy.strategy_type.in_(consts.stock_strategy_type),
        )
        live = []
        offline = []
        for s in stocks:
            if s[1] == 15:
                live.append(s[0])
            elif s[1] == 16:
                offline.append(s[0])
        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'live': live,
                'offline': offline,
            },
        })
        return True


class VsTradingLogsHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_ids = self.get_argument('vs_ids')
        vs_ids = [int(v_id) for v_id in vs_ids.split(',')]
        trading_date = self.get_argument('trading_date')
        day_night = int(self.get_argument('day_night', '2'))
        if day_night == 2:
            day_nights = [0, 1]
        else:
            day_nights = [day_night]
        logs = []
        columns = [
            'symbol', 'direction', 'open_close', 'trade_vol', 'notional'
        ]
        if vs_ids:
            sc = session()
            tradelogs = sc.query(
                TradeLogs.symbol,
                TradeLogs.direction,
                TradeLogs.open_close,
                func.sum(TradeLogs.trade_vol),
                func.sum(TradeLogs.trade_vol * TradeLogs.trade_price),
            ).filter(
                TradeLogs.vstrategy_id.in_(vs_ids),
                TradeLogs.trading_date == trading_date,
                TradeLogs.day_night.in_(day_nights),
                TradeLogs.log_type == '3'
            ).group_by(
                TradeLogs.symbol, TradeLogs.direction, TradeLogs.open_close
            )
            for l in tradelogs:
                logs.append(list(l))
            sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'columns': columns,
                'values': logs,
            }
        })
        return True


class VsTradingLogs2Handler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_id = self.get_argument('vstrategy_id')
        trading_date = self.get_argument('trading_date')
        logs = []
        columns = [
            'trading_date', 'vstrategy_id', 'symbol', 'entrust_status', 'direction', 'open_close',
            'order_vol', 'order_price', 'trade_price', 'trade_vol'
        ]
        sc = session()
        tradelogs = sc.query(
            TradeLogs.trading_date,
            TradeLogs.vstrategy_id,
            TradeLogs.symbol,
            TradeLogs.entrust_status,
            TradeLogs.direction,
            TradeLogs.open_close,
            TradeLogs.order_vol,
            TradeLogs.order_price,
            TradeLogs.trade_price,
            TradeLogs.trade_vol,
        ).filter(
            TradeLogs.vstrategy_id == vs_id,
            TradeLogs.trading_date == trading_date,
            TradeLogs.entrust_status.in_(['a', 'p', 'c', 'd', 'e'])
        )
        for l in tradelogs:
            logs.append(list(l))
        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'columns': columns,
                'values': logs,
            }
        })
        return True


class VsTotalAssetHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_id = int(self.get_argument('vs_id'))
        trading_date = self.get_argument('trading_date')
        day_night = int(self.get_argument('day_night', '2'))
        if day_night == 1:
            day_night = 'NIGHT'
        else:
            day_night = 'DAY'
        total_asset = 0
        sc = session()
        vs_base = sc.query(
            VsBase.total_asset
        ).filter(
            VsBase.vstrategy_id == vs_id,
            VsBase.settle_date == trading_date,
            VsBase.daynight == day_night
        ).first()
        if vs_base:
            total_asset = float(vs_base.total_asset)
        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'total_asset': total_asset
            }
        })
        return True


class GetVsPositionClearTradelogsHandler(DownloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        from_vs_id = int(self.get_argument('from'))
        to_vs_id = int(self.get_argument('to', 0))

        sc = session()
        s_id_no = sc.query(
            Strategy.id_no.label('id_no')
        ).join(
            VStrategies, VStrategies.strategy_id == Strategy.id
        ).filter(
            VStrategies.id == from_vs_id
        ).first()
        if not s_id_no:
            sc.close()
            self.json_response({
                'code': 0,
                'data': {}
            })
            return
        s_id_no = s_id_no.id_no

        ss = StrategyTrackService(id_no=s_id_no)
        yield ss.async_get_live_quote()
        detail = ss.strategy_track()
        detail['position_data'] = ss.get_live_position()

        trading_date = datetime.datetime.now().strftime('%Y-%m-%d')
        trade_time = datetime.datetime.now().strftime('%Y-%m-%d,15:00:00')
        from_vs_id_str = str(from_vs_id)
        to_vs_id_str = str(to_vs_id)

        columns = [
            'account', 'daynight', 'direction', 'entrust_no', 'open_close', 'serial_no',
            'symbol', 'trade_price', 'trade_time', 'trade_vol', 'trading_date', 'vstrategy_id'
        ]

        close_data = []

        buy_data = []
        for l in detail['position_data']:
            for s in l['detail_info']:
                if int(s['vstrategy_id']) != from_vs_id:
                    continue

                if s['symbol'] in ('204001', '131810'):
                    continue

                if s['direction'] == 0:
                    d1, o1 = 'SELL', 'CLOSE'
                    d2, o2 = 'BUY', 'OPEN'
                elif s['direction'] == 1:
                    d1, o1 = 'BUY', 'CLOSE'
                    d2, o2 = 'SELL', 'OPEN'
                else:
                    continue

                trade_vol = s['total_position']
                trade_price = s['last_price']
                serial_no = ''.join([from_vs_id_str, s['symbol']])

                close_data.append([
                    s['account'], 'DAY', d1, serial_no, o1, serial_no,
                    s['symbol'], trade_price, trade_time, trade_vol, trading_date, from_vs_id
                ])

                if to_vs_id:
                    serial_no = ''.join([to_vs_id_str, s['symbol']])
                    buy_data.append([
                        s['account'], 'DAY', d2, serial_no, o2, serial_no,
                        s['symbol'], trade_price, trade_time, trade_vol, trading_date, to_vs_id
                    ])

        filename = '%s_%s_clear_trade_logs.csv' % (from_vs_id, trading_date)
        df = pd.DataFrame(
            sorted(close_data, key=lambda x: x[6]) + sorted(buy_data, key=lambda x: x[6]), columns=columns
        )
        return self.downfile2(df, filename)


class LiveAnalysisPerformanceBasicHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        s_id_list = self.get_argument('s_id_list', '')
        id_list = []
        if len(s_id_list) > 0:
            for x in s_id_list.split(','):
                try:
                    id_list.append(int(x))
                except Exception as e:
                    pass

        s = LiveAnalysisPerformanceService(self.current_user, id_list)
        data = s.get_basic_data()
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class LiveAnalysisPerformanceVsPnlHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        s_id_list = self.get_argument('s_id_list', '')
        id_list = []
        if len(s_id_list) > 0:
            for x in s_id_list.split(','):
                try:
                    id_list.append(int(x))
                except Exception as e:
                    pass

        is_summary = True if self.get_argument('summary', 'false').lower() == 'true' else False
        s = LiveAnalysisPerformanceService(self.current_user, id_list, is_summary=is_summary)
        data = s.investment_pnl_data2()

        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class LiveAnalysisPerformanceRTHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        s_id_list = self.get_argument('s_id_list', '')
        id_list = []
        if len(s_id_list) > 0:
            for x in s_id_list.split(','):
                try:
                    id_list.append(int(x))
                except Exception as e:
                    pass

        s = LiveAnalysisPerformanceService(self.current_user, id_list)
        yield s.async_get_live_quote()
        data = s.get_investment_live_pnl()
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class AnalysisStrategyListHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        if not (self.is_future_group() or self.is_stock_group()):
            self.json_response({
                'code': 0,
                'data': {
                    'key': '',
                    's_ids': [],
                }
            })
            return True

        key = self.get_argument('key', '')
        if not key:
            if self.is_future_page():
                key = 'future'
            else:
                key = 'stock'

        sc = session()
        strategy_ids = sc.query(AnalysisStrategyList.strategy_id).filter(
            AnalysisStrategyList.r_create_user_id == self.current_user['id']
        )
        if key:
            strategy_ids = strategy_ids.filter(
                AnalysisStrategyList.key == key
            )

        strategy_ids = [s_id[0] for s_id in strategy_ids]
        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'key': key,
                's_ids': strategy_ids,
            }
        })
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        payload = self.get_payload()
        key = payload.get('key', '')
        if not key:
            if self.is_future_page():
                key = 'future'
            else:
                key = 'stock'

        s_ids = [int(i) for i in payload['s_ids']]
        sc = session()
        delete_set = sc.query(
            AnalysisStrategyList
        ).filter(
            AnalysisStrategyList.r_create_user_id == self.current_user['id']
        )

        if key:
            delete_set = delete_set.filter(
                AnalysisStrategyList.key == key
            )

        delete_set.delete()

        factor_strategy_ids = [r[0] for r in sc.query(MutilFactorStrategy.strategy_id).filter(
            MutilFactorStrategy.factor_strategy_id.in_(s_ids)
        )]

        s_ids.extend(factor_strategy_ids)

        for s_id in s_ids:
            a = AnalysisStrategyList(
                key=key,
                strategy_id=s_id,
                r_create_user_id=self.current_user['id'],
            )
            sc.add(a)
        sc.commit()
        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'key': key,
                's_ids': s_ids,
            }
        })
        return True


class StockPortfolioOptimizationHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        PAGE LOCATION 股票交易->风险模块参数配置
        """

        self.get_current_user()
        if not self.current_user:
            return False

        sc = session()
        versions = sc.query(StockPortfolioOptimizationVersion)
        value = self.get_argument('value', '', strip=False)
        if (not self.is_stock_group()) and (not value):
            versions = versions.filter(
                StockPortfolioOptimizationVersion.r_create_user_id == self.current_user['id']
            )

        if value:
            versions = versions.filter(
                StockPortfolioOptimizationVersion.value == value
            )

        portfolio_optimization_versions = [
            {
                'id': r.id,
                'name': r.name,
                'value': r.value,
                'description': r.description,
                'paras': r.paras or {},
            } for r in versions if r.r_create_user_id and r.r_create_user_id > 0
        ]
        sc.close()

        data = portfolio_optimization_versions
        if value:
            data = data and data[0] or {}

        self.json_response({
            'code': 0,
            'data': data,
        })

        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        """
        Add a new portofolio optimization configuration item.
        """

        self.get_current_user()
        if not self.current_user:
            return False

        pay_load = self.get_payload()
        value = pay_load.get('value', '')
        description = value
        # if not (value and description):
        if not value:
            self.json_response({
                'code': 4001,
                'data': 'fields are required [value, description, paras]',
                'error': 'fields are required [value, description, paras]'
            })
            return False
        paras = pay_load.get('paras', None)
        if not isinstance(paras, dict):
            self.json_response({
                'code': 4002,
                'data': 'paras must be a dict',
                'error': 'paras must be a dict'
            })
            return False
        sc = session()
        v = sc.query(StockPortfolioOptimizationVersion).filter(
            or_(
                StockPortfolioOptimizationVersion.description == description,
                StockPortfolioOptimizationVersion.value == value,
            )
        ).first()
        if v:
            sc.close()
            self.json_response({
                'code': 4002,
                'data': 'description and value must be unique',
                'error': 'description and value must be unique',
            })
            return False
        v = StockPortfolioOptimizationVersion(
            strategy_id=0,
            name=value,
            value=value,
            description=description,
            paras=pay_load.get('paras', {}),
            r_create_user_id=self.current_user['id'],
        )
        sc.add(v)
        sc.commit()
        self.json_response({
            'code': 0,
            'data': {
                'id': v.id,
                'name': v.name,
                'value': v.value,
                'description': v.description,
                'paras': v.paras or {},
            },
        })
        sc.close()
        return True


class StockPortfolioOptimizationDetailHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):

        self.get_current_user()
        if not self.current_user:
            return False

        sc = session()
        v_id = int(kwargs['id'])
        v = sc.query(StockPortfolioOptimizationVersion).filter(
            StockPortfolioOptimizationVersion.id == v_id,
        ).first()
        portfolio_optimization_versions = {}
        if v:
            portfolio_optimization_versions = {
                'id': v.id,
                'name': v.name,
                'value': v.value,
                'description': v.description,
                'paras': v.paras or {},
            }

        sc.close()

        data = {
            'portfolio_optimization_so_version': portfolio_optimization_versions
        }

        self.json_response({
            'code': 0,
            'data': portfolio_optimization_versions,
        })

        return True

    @gen.coroutine
    def post(self, *args, **kwargs):

        self.get_current_user()
        if not self.current_user:
            return False

        sc = session()
        v_id = int(kwargs['id'])
        v = sc.query(StockPortfolioOptimizationVersion).filter(
            StockPortfolioOptimizationVersion.id == v_id,
        ).first()

        if not (v.r_create_user_id and v.r_create_user_id > 0):
            sc.close()
            self.json_response({
                'code': 4003,
                'data': 'can not update the base portfolio optimization',
                'error': 'can not update the base portfolio optimization',
            })
            return False
        pay_load = self.get_payload()
        description = pay_load.get('description', '')
        paras = pay_load.get('paras', None)
        if not isinstance(paras, dict):
            sc.close()
            self.json_response({
                'code': 4002,
                'data': 'paras must be a dict',
                'error': 'paras must be a dict'
            })
            return False
        if description:
            v.description = description
        v.paras = pay_load.get('paras', {})
        sc.commit()
        sc.close()
        self.json_response({
            'code': 0,
            'data': {},
        })
        return True

    @gen.coroutine
    def delete(self, *args, **kwargs):

        self.get_current_user()
        if not self.current_user:
            return False

        sc = session()
        v_id = int(kwargs['id'])
        v = sc.query(StockPortfolioOptimizationVersion).filter(
            StockPortfolioOptimizationVersion.id == v_id,
        ).first()

        if not (v.r_create_user_id and v.r_create_user_id > 0):
            sc.close()
            self.json_response({
                'code': 4003,
                'data': 'can not delete the base portfolio optimization',
                'error': 'can not update the base portfolio optimization',
            })
            return False

        if v.r_create_user_id != self.current_user['id']:
            sc.close()
            self.json_response({
                'code': 4003,
                'data': 'can not delete the portfolio optimization created by other user',
                'error': 'can not delete the portfolio optimization created by other user',
            })
            return False

        used_strategy = []
        strategies = sc.query(
            Strategy.id_no.label('s_id'),
            Strategy.detail.label('s_detail')
        ).filter(
            Strategy.node == 'back_test',
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.strategy_type.in_(consts.stock_strategy_type)
        )
        for s in strategies:
            if s.s_detail.get('portfolio_optimization_so_version', '') == v.value:
                used_strategy.append(s.s_id)

        if not used_strategy:
            sc.query(StockPortfolioOptimizationVersion).filter(
                StockPortfolioOptimizationVersion.id == v_id,
            ).delete()
            sc.commit()
            sc.close()
            self.json_response({
                'code': 0,
                'data': {},
            })
            return True
        else:
            sc.close()
            msg = 'the optimization is used by strategies: %s' % ','.join(used_strategy)
            self.json_response({
                'code': 4004,
                'data': msg,
                'error': msg,
            })
            return True


class AnalysisStockFactorHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        sc = session()

        # vwap_records = sc.query(StockSmartExecutionVersion).filter(StockSmartExecutionVersion.valid == True).all()
        # vwap_versions = [
        #     {
        #         'name': r.name,
        #         'value': r.value,
        #         'description': r.description,
        #     } for r in vwap_records
        # ]

        portfolio_optimization_versions = [
            {
                'id': r.id,
                'name': r.name,
                'value': r.value,
                'description': r.description,
            } for r in sc.query(StockPortfolioOptimizationVersion)
        ]
        sc.close()

        data = {
            # 'vwap_version': vwap_versions,
            'portfolio_optimization_so_version': portfolio_optimization_versions,
            # 'default_vwap_version': 'vwap_MFv29',
        }

        self.json_response({
            'code': 0,
            'data': data,
        })

        return True


class FactorStrategyPerformancenHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        s_ids = self.get_argument('s_ids', '')
        id_list = []
        if len(s_ids) > 0:
            for x in s_ids.split(','):
                try:
                    id_list.append(int(x))
                except Exception as e:
                    pass

        t0_strategy = str(self.get_argument('t0', '')).lower()

        sc = session()
        s_ids = id_list
        factor_s_ids = sc.query(
            MutilFactorStrategy.strategy_id,
            MutilFactorStrategy.factor_strategy_id,
        ).filter(
            or_(
                MutilFactorStrategy.strategy_id.in_(s_ids),
                MutilFactorStrategy.factor_strategy_id.in_(s_ids)
            )
        )

        s2factor_s = {}
        factor_ids = []
        for f_s in factor_s_ids:
            s_ids.append(f_s[0])
            s_ids.append(f_s[1])
            factor_ids.append(f_s[1])
            s2factor_s.setdefault(f_s[0], []).append(f_s[1])

        strategies = sc.query(
            Strategy
        ).filter(
            Strategy.id.in_(s_ids),
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.node.in_(['back_test', 'order_list', 'trademaster_order_list', 'group', 'union_simu'])
        )

        if t0_strategy == 'true':
            strategies = strategies.filter(Strategy.strategy_type.in_(consts.t0_stock_strategy_type))
        elif t0_strategy == 'false':
            strategies = strategies.filter(Strategy.strategy_type.notin_(consts.t0_stock_strategy_type))

        alpha_s_ids = set()
        data = {}
        # now_time = datetime.datetime.now()
        strategy_market_volume = StrategyTradingVolumeRatioStatistic.get_max_volume_ratio()
        for s in strategies:
            data[s.id] = {}  # s.rank_detail(self.current_user['id'])
            data[s.id]['accounts'] = s.detail.get('accounts', {})
            data[s.id]['vwap_version'] = s.detail.get('vwap_version', '')
            data[s.id]['se_cash_rate'] = s.detail.get('se_cash_rate', 0)
            data[s.id]['portfolio_optimization_so_version'] = s.detail.get('portfolio_optimization_so_version', '')
            data[s.id]['trade_model'] = s.detail.get('trade_model', '')
            data[s.id]['initial_cash'] = s.detail.get('initial_cash', 0)
            # data[s.id]['accounts'] = s.detail.get('accounts', {})
            data[s.id]['alpha_s_id'] = s.detail.get('alpha_s_id', None)
            data[s.id]['alpha_strategy_id'] = ''
            data[s.id]['income_attribution_base_s_id'] = s.detail.get('income_attribution_base_s_id', None)
            data[s.id]['income_attribution_base_strategy_id'] = ''
            data[s.id]['progress'] = s.task_progress
            data[s.id]['status'] = Strategy.get_run_status(s.status)
            data[s.id]['products'] = s.products
            data[s.id]['s_id'] = s.id
            data[s.id]['id'] = s.id
            data[s.id]['confidence'] = float(s.confidence)
            data[s.id]['strategy_id_no'] = s.id_no
            data[s.id]['strategy_name'] = s.name
            data[s.id]['strategy_type'] = s.strategy_type
            data[s.id]['start_date'] = s.start_date
            data[s.id]['hedge'] = s.hedge or ''
            if s.has_margin_hedge():
                data[s.id]['hedge'] = HedgeBenchmark.MarginHedgeList.value
            data[s.id]['hedge_type'] = s.hedge_type or ''
            data[s.id]['utime'] = s.r_update_time.strftime('%Y%m%d %X')
            data[s.id]['bt_sharpe'] = 'N/A'
            data[s.id]['bt_annual_return'] = 'N/A'
            data[s.id]['sharpe'] = 'N/A'
            data[s.id]['annual_return'] = 'N/A'
            data[s.id]['pt_days'] = 0
            data[s.id]['avg_daily_rounds'] = 0
            data[s.id]['max_drawdown'] = 0
            data[s.id]['drawdown_earn_ratio'] = 'N/A'
            # data[s.id]['pnl_url'] = '/media/strategy_pnl_graph/strategy_%s_0_%sthumbnail.png' % (
            #     s.id, 'hedge_' if s.hedge else '')
            data[s.id]['pnl_url'] = '/media/strategy_pnl_graph/strategy_%s_0_%sthumbnail.png' % (
                s.id, 'hedge_' if data[s.id]['hedge'] else '')
            data[s.id]['factor_strategies'] = []
            # data[s.id]['query_time'] = 0 if s.task_progress >= 1 \
            #     else min(20, max((now_time - s.r_update_time).seconds, 5))
            data[s.id]['query_time'] = s.get_query_time()
            data[s.id]['strategy_status'] = s.strategy_status
            data[s.id]['vwap_slippage'] = StrategyBackTestSlippage.get_strategy_slippage(s.id)
            data[s.id]['market_volume'] = 'N/A'
            if s.detail.get('alpha_s_id'):
                alpha_s_ids.add(s.detail['alpha_s_id'])
            if data[s.id]['income_attribution_base_s_id']:
                alpha_s_ids.add(data[s.id]['income_attribution_base_s_id'])

            s_id_str = str(s.id)
            if s_id_str in strategy_market_volume:
                data[s.id]['market_volume'] = '%s / %s' % (
                    strategy_market_volume[s_id_str]['trade_vol_percent_5'],
                    strategy_market_volume[s_id_str]['trade_vol_percent_10']
                )

            # _percent = int(s.task_progress * 10000)

        if alpha_s_ids:
            alpha_s_id_nos = {r[0]: r[1] for r in sc.query(Strategy.id, Strategy.id_no).filter(
                Strategy.id.in_(alpha_s_ids)
            )}
            for s_id, d in data.items():
                d['alpha_strategy_id'] = alpha_s_id_nos.get(d['alpha_s_id'], '')
                d['income_attribution_base_strategy_id'] = alpha_s_id_nos.get(d['income_attribution_base_s_id'], '')

        performances = sc.query(
            StrategyBackTestResultPerformance.strategy_id.label('strategy_id'),
            StrategyBackTestResultPerformance.key.label('key'),
            StrategyBackTestResultPerformance.sharpe.label('sharpe'),
            StrategyBackTestResultPerformance.annual_return.label('annual_return'),
            StrategyBackTestResultPerformance.max_drawdown_pnl.label('max_drawdown_pnl'),
            StrategyBackTestResultPerformance.pt_days.label('pt_days'),
        ).filter(
            StrategyBackTestResultPerformance.strategy_id.in_(s_ids),
            # StrategyBackTestResultPerformance.key.in_(['whole_back_test'])
            StrategyBackTestResultPerformance.key == 'whole_back_test'
        )
        for p in performances:
            if p.strategy_id not in data:
                continue
            data[p.strategy_id]['pt_days'] = p.pt_days
            # if p.key == 'whole_back_test':
            data[p.strategy_id]['bt_sharpe'] = 'N/A' if abs(float(p.sharpe)) >= 99999 else float(p.sharpe)
            data[p.strategy_id]['bt_annual_return'] = 'N/A' if abs(float(p.annual_return)) >= 99999 else float(
                p.annual_return)
            data[p.strategy_id]['max_drawdown'] = 'N/A' if abs(float(p.max_drawdown_pnl)) >= 99999 else float(
                p.max_drawdown_pnl)

        res = []
        for s_id in sorted(set(s_ids), reverse=True):
            if s_id in factor_ids:
                continue
            if s_id not in data:
                continue
            d = data[s_id]
            for f_id in s2factor_s.get(s_id, []):
                if f_id in data:
                    d['factor_strategies'].append(data[f_id])
            res.append(d)

        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'rows': res
            },
        })

        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        pay_load = self.get_payload()
        s_id = pay_load['s_id']
        sc = session()
        s = sc.query(
            Strategy
        ).filter(
            Strategy.id == s_id
        ).first()
        id_no = Strategy.generate_id_no(
            s.r_create_user_id, s.strategy_type or '99', (s.paper_trading_date or s.r_create_time).strftime('%Y-%m-%d')
        )
        detail = copy.deepcopy(s.detail)
        detail['start'] = parse(pay_load['start']).strftime('%Y%m%d')
        detail['trade_model'] = str(pay_load['trade_model'])
        detail['initial_cash'] = float(pay_load.get('initial_cash', 0))
        detail['se_cash'] = float(pay_load.get('se_cash', 0) or 0)
        detail['se_cash_rate'] = float(pay_load.get('se_cash_rate', 0) or 0)
        detail['accounts'] = pay_load.get('accounts', {})
        detail['log_level'] = pay_load.get('log_level', StrategyConstant.DetailLogLevel.Production.value)
        if detail['accounts']:
            initial_cash = 0
            for _, a_d in detail['accounts'].items():
                initial_cash += a_d['cash']
            detail['initial_cash'] = initial_cash

        detail['vwap_version'] = pay_load.get('vwap_version', '')
        detail['portfolio_optimization_so_version'] = pay_load.get('portfolio_optimization_so_version', '')
        detail['income_attribution_base_s_id'] = pay_load.get('income_attribution_base_s_id', 0)
        detail['name'] = s.name
        detail['desc'] = s.description + '(clone_from_%s)' % s.id

        if (s.strategy_type in consts.stock_strategy_type) and pay_load.get('alpha_s_id'):
            detail['alpha_s_id'] = pay_load['alpha_s_id']

        new_s = Strategy(
            r_create_time=s.r_create_time.strftime('%Y%m%d'),
            r_create_user_id=s.r_create_user_id,
            r_update_user_id=s.r_update_user_id,
            username=s.username,
            name=s.name,
            status=consts.TASK_RUNNING,
            description=detail['desc'],
            node=s.node,
            start_date=detail['start'],
            end_date=s.end_date,
            day_night=s.day_night,
            products=s.products,
            max_pos=s.max_pos,
            dependency=s.dependency,
            detail=detail,
            st_uuid=uuid.uuid1().hex,
            strategy_type=s.strategy_type,
            strategy_feature=s.strategy_feature,
            strategy_underlying=s.strategy_underlying,
            strategy_para_type=s.strategy_para_type,
            strategy_status='BT',
            id_no=id_no,
            code=id_no[-3:],
            is_test=0,
            strategy_upload_file_id=s.strategy_upload_file_id,
            hedge=s.hedge,
            hedge_type=s.hedge_type,
            paper_trading_date=(s.paper_trading_date or s.r_create_time).strftime('%Y%m%d'),
            confidence=1,
            task_progress=0,
            group_id=s.group_id,
            group_detail=s.group_detail,
            is_derive_strategy=True,
        )
        sc.add(new_s)
        sc.commit()

        strategy_owner = StrategyOwners(
            strategy_id=new_s.id,
            owner_id=new_s.r_create_user_id,
            r_create_user_id=new_s.r_create_user_id,
        )
        sc.add(strategy_owner)
        sc.commit()

        factor_s = MutilFactorStrategy(
            r_create_user_id=self.current_user['id'],
            strategy_id=s.id,
            factor_strategy_id=new_s.id,
        )
        sc.add(factor_s)
        sc.commit()

        if detail['income_attribution_base_s_id']:
            StrategyIncomeAttributionAdjusted.set_pair(new_s.id, detail['income_attribution_base_s_id'])

        start_strategy_task.delay(new_s.id)

        Strategy.add_strategy_event(
            new_s.id,
            s.start_date,
            TradingTimeRange.Day.value,
            StrategyEventTrackConstant.Event.AddStrategyBackTest.value,
            task_id=new_s.st_uuid,
        )

        s_exe_time = sc.query(StrategyVwapExecutimeTime).filter(
            StrategyVwapExecutimeTime.strategy_id == s.id
        ).order_by(
            StrategyVwapExecutimeTime.trading_date.desc()
        ).first()
        if s_exe_time:
            new_s_exe_time = StrategyVwapExecutimeTime(
                strategy_id=new_s.id,
                trading_date=datetime.datetime.now().strftime('%Y%m%d'),
                start_time=s_exe_time.start_time,
                end_time=s_exe_time.end_time
            )
            sc.add(new_s_exe_time)
            sc.commit()

        sc.close()
        self.json_response({
            'code': 0,
            'data': {},
        })
        return True


class FactorStrategyPerformancenDetailHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def delete(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        sc = session()
        s_id = int(kwargs['id'])
        s = sc.query(
            Strategy
        ).filter(
            Strategy.id == s_id
        ).first()

        if not s:
            self.json_response({
                'code': 1013,
                'error': 'can not find strategy id=%s' % s_id
            })
            sc.close()
            return False

        if s.is_deployed or s.strategy_status == 'LT':
            self.json_response({
                'code': 1003,
                'error': 'strategy is already deployed',
            })
            sc.close()
            return False

        dep = sc.query(Strategy.id).filter(
            Strategy.is_test == 0,
            Strategy.is_delete == 0,
            Strategy.id.in_(
                sc.query(
                    StrategyIncomeAttributionAdjusted.s_id
                ).filter(
                    StrategyIncomeAttributionAdjusted.unajusted_s_id == s_id
                )
            )
        )
        if dep.count():
            self.json_response({
                'code': 1003,
                'error': 'strategy is dependency by other',
            })
            sc.close()
            return False

        s.stop_task()
        s.status = consts.TASK_FINISHED
        s.is_delete = 1
        s.st_uuid = uuid.uuid4().hex

        sc.query(
            MutilFactorStrategy
        ).filter(
            MutilFactorStrategy.factor_strategy_id == s.id
        ).delete()

        del_cache('platform_strategy_brief_%s_0_0' % s.id)
        del_cache('platform_strategy_detail_%s_0_0' % s.id)
        del_cache('platform_strategy_output_%s_0' % s.id)

        sc.commit()
        sc.close()
        self.json_response({
            'code': 0,
            'data': {},
        })
        return True

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        s_id = int(kwargs['id'])
        sc = session()

        strategies = sc.query(
            Strategy
        ).filter(
            Strategy.id == s_id,
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.node.in_(['back_test', 'order_list', 'trademaster_order_list', 'group', 'union_simu'])
        )
        data = {}
        alpha_s_ids = set()
        # now_time = datetime.datetime.now()
        strategy_market_volume = StrategyTradingVolumeRatioStatistic.get_max_volume_ratio()
        for s in strategies:
            data[s.id] = {}  # s.rank_detail(self.current_user['id'])
            data[s.id]['accounts'] = s.detail.get('accounts', {})
            data[s.id]['vwap_version'] = s.detail.get('vwap_version', '')
            data[s.id]['se_cash_rate'] = s.detail.get('se_cash_rate', 0)
            data[s.id]['portfolio_optimization_so_version'] = s.detail.get('portfolio_optimization_so_version', '')
            data[s.id]['trade_model'] = s.detail.get('trade_model', '')
            data[s.id]['initial_cash'] = s.detail.get('initial_cash', 0)
            # data[s.id]['accounts'] = s.detail.get('accounts', {})
            data[s.id]['alpha_s_id'] = s.detail.get('alpha_s_id', None)
            data[s.id]['alpha_strategy_id'] = ''
            data[s.id]['income_attribution_base_s_id'] = s.detail.get('income_attribution_base_s_id', None)
            data[s.id]['income_attribution_base_strategy_id'] = ''
            data[s.id]['progress'] = s.task_progress
            data[s.id]['status'] = Strategy.get_run_status(s.status)
            data[s.id]['products'] = s.products
            data[s.id]['s_id'] = s.id
            data[s.id]['id'] = s.id
            data[s.id]['confidence'] = float(s.confidence)
            data[s.id]['strategy_id_no'] = s.id_no
            data[s.id]['strategy_name'] = s.name
            data[s.id]['strategy_type'] = s.strategy_type
            data[s.id]['start_date'] = s.start_date
            data[s.id]['hedge'] = s.hedge or ''
            if s.has_margin_hedge():
                data[s.id]['hedge'] = HedgeBenchmark.MarginHedgeList.value
            data[s.id]['hedge_type'] = s.hedge_type or ''
            data[s.id]['utime'] = s.r_update_time.strftime('%Y%m%d %X')
            data[s.id]['bt_sharpe'] = 'N/A'
            data[s.id]['bt_annual_return'] = 'N/A'
            data[s.id]['sharpe'] = 'N/A'
            data[s.id]['annual_return'] = 'N/A'
            data[s.id]['pt_days'] = 0
            data[s.id]['avg_daily_rounds'] = 0
            data[s.id]['max_drawdown'] = 0
            data[s.id]['drawdown_earn_ratio'] = 'N/A'
            # data[s.id]['pnl_url'] = '/media/strategy_pnl_graph/strategy_%s_0_%sthumbnail.png' % (
            #     s.id, 'hedge_' if s.hedge else '')
            data[s.id]['pnl_url'] = '/media/strategy_pnl_graph/strategy_%s_0_%sthumbnail.png' % (
                s.id, 'hedge_' if data[s.id]['hedge'] else '')
            data[s.id]['factor_strategies'] = []
            data[s.id]['query_time'] = s.get_query_time()
            data[s.id]['strategy_status'] = s.strategy_status
            data[s.id]['vwap_slippage'] = StrategyBackTestSlippage.get_strategy_slippage(s.id)
            data[s.id]['market_volume'] = 'N/A'
            if s.detail.get('alpha_s_id'):
                alpha_s_ids.add(s.detail['alpha_s_id'])
            if data[s.id]['income_attribution_base_s_id']:
                alpha_s_ids.add(data[s.id]['income_attribution_base_s_id'])

            s_id_str = str(s.id)
            if s_id_str in strategy_market_volume:
                data[s.id]['market_volume'] = '%s / %s' % (
                    strategy_market_volume[s_id_str]['trade_vol_percent_5'],
                    strategy_market_volume[s_id_str]['trade_vol_percent_10']
                )

            # _percent = int(s.task_progress * 10000)

        if alpha_s_ids:
            alpha_s_id_nos = {r[0]: r[1] for r in sc.query(Strategy.id, Strategy.id_no).filter(
                Strategy.id.in_(alpha_s_ids)
            )}
            for s_id, d in data.items():
                d['alpha_strategy_id'] = alpha_s_id_nos.get(d['alpha_s_id'], '')
                d['income_attribution_base_strategy_id'] = alpha_s_id_nos.get(d['income_attribution_base_s_id'], '')

        performances = sc.query(
            StrategyBackTestResultPerformance.strategy_id.label('strategy_id'),
            StrategyBackTestResultPerformance.key.label('key'),
            StrategyBackTestResultPerformance.sharpe.label('sharpe'),
            StrategyBackTestResultPerformance.annual_return.label('annual_return'),
            StrategyBackTestResultPerformance.max_drawdown_pnl.label('max_drawdown_pnl'),
            StrategyBackTestResultPerformance.pt_days.label('pt_days'),
        ).filter(
            StrategyBackTestResultPerformance.strategy_id == s_id,
            # StrategyBackTestResultPerformance.key.in_(['whole_back_test'])
            StrategyBackTestResultPerformance.key == 'whole_back_test'
        )
        for p in performances:
            if p.strategy_id not in data:
                continue
            data[p.strategy_id]['pt_days'] = p.pt_days
            # if p.key == 'whole_back_test':
            data[p.strategy_id]['bt_sharpe'] = 'N/A' if abs(float(p.sharpe)) >= 99999 else float(p.sharpe)
            data[p.strategy_id]['bt_annual_return'] = 'N/A' if abs(float(p.annual_return)) >= 99999 else float(
                p.annual_return)
            data[p.strategy_id]['max_drawdown'] = 'N/A' if abs(float(p.max_drawdown_pnl)) >= 99999 else float(
                p.max_drawdown_pnl)

        sc.close()
        self.json_response({
            'code': 0,
            'data': data.get(s_id, {}),
        })

        return True


class StrategyPortfolioPerformancenHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):

        self.get_current_user()
        if not self.current_user:
            return False

        pay_load = self.get_payload()
        s_ids = pay_load['s_ids']
        if not s_ids:
            self.json_response({
                'code': 0,
                'data': {},
            })
            return True

        business = ''
        if self.is_future_page():
            business = 'future'
        if self.is_stock_page():
            business = 'stock'

        p = StrategyPortfolioPerformance(s_ids, business=business)
        data = p.analysis()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StrategyPortfolioCorrelationHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):
    @gen.coroutine
    def post(self, *args, **kwargs):
        pay_load = self.get_payload()
        s_ids = pay_load['s_ids']
        if not s_ids:
            self.json_response({
                'code': 0,
                'data': {},
            })
            return True

        p = StrategyPortfolioPerformance(s_ids)
        data = p.correlation()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StrategyEvaluationHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        data = {}
        s_id = int(kwargs['id'])
        sc = session()
        s = sc.query(Strategy).filter(
            Strategy.id == s_id
        ).first()
        if not s:
            sc.close()
            self.json_response({
                'code': 3005,
                'data': 'can not find strategy',
                'error': 'can not find strategy',
            })
            return True
        data['name'] = s.name
        data['id'] = s.id
        data['strategy_id'] = s.id_no
        data['creator'] = s.username
        data['create_time'] = s.r_create_time.strftime('%Y%m%d')
        data['papertrading_date'] = (s.paper_trading_date or s.r_create_time).strftime('%Y%m%d')
        data['live_time'] = s.live_time and s.live_time.strftime('%Y%m%d') or ''
        data['strategy_type'] = s.strategy_type
        data['turnover'] = {}
        data['ic'] = {}
        data['std'] = {}

        evaluations = sc.query(
            StrategyEvaluation
        ).filter(
            StrategyEvaluation.strategy_id == s.id
        )
        ic1, ic2 = [], []
        std1, std2 = [], []
        for ev in evaluations:
            data['turnover'][ev.trading_date] = round(float(ev.turnover or 0) / 100000000, 2)
            data['ic'][ev.trading_date] = round(float(ev.ic or 0), 2)
            data['std'][ev.trading_date] = round(float(ev.std or 0), 2)
            if ev.trading_date < data['papertrading_date']:
                ic1.append(data['ic'][ev.trading_date])
                std1.append(data['std'][ev.trading_date])
            else:
                ic2.append(data['ic'][ev.trading_date])
                std2.append(data['std'][ev.trading_date])
        data['avg_ic1'] = 0 if not ic1 else round(sum(ic1) / len(ic1), 2)
        data['avg_ic2'] = 0 if not ic2 else round(sum(ic2) / len(ic2), 2)
        data['avg_std1'] = 0 if not std1 else round(sum(std1) / len(std1), 2)
        data['avg_std2'] = 0 if not std2 else round(sum(std2) / len(std2), 2)
        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StrategyStyleExposureHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        data = {}
        s_id = int(kwargs['id'])
        vs_id = int(self.get_argument('vs_id', 0))
        sc = session()
        s = sc.query(Strategy).filter(
            Strategy.id == s_id
        ).first()
        if not s:
            sc.close()
            self.json_response({
                'code': 3005,
                'data': 'can not find strategy',
                'error': 'can not find strategy',
            })
            return True
        data['name'] = s.name
        data['id'] = s.id
        data['strategy_id'] = s.id_no
        data['creator'] = s.username
        data['create_time'] = s.r_create_time.strftime('%Y%m%d')
        data['papertrading_date'] = (s.paper_trading_date or s.r_create_time).strftime('%Y%m%d')
        data['live_time'] = s.live_time and s.live_time.strftime('%Y%m%d') or ''
        data['strategy_type'] = s.strategy_type

        exposure = {}

        s_exposure = sc.query(StrategyStyleExposure).filter(
            StrategyStyleExposure.strategy_id == s_id,
            StrategyStyleExposure.trading_date >= s.start_date,
        )
        for ex in s_exposure:
            exposure[ex.trading_date] = {
                'bd': round(float(ex.bd), 4),
                'bt': round(float(ex.bt), 4),
                'gg': round(float(ex.gg), 4),
                'hy': round(float(ex.hy), 4),
                'jz': round(float(ex.jz), 4),
                'ld': round(float(ex.ld), 4),
                'mm': round(float(ex.mm), 4),
                'mv': round(float(ex.mv), 4),
                'yl': round(float(ex.yl), 4),

            }
        if vs_id:
            vs_exposure = sc.query(VStrategyStyleExposure).filter(VStrategyStyleExposure.vs_id == vs_id)
            for ex in vs_exposure:
                exposure[ex.trading_date] = {
                    'bd': round(float(ex.bd), 4),
                    'bt': round(float(ex.bt), 4),
                    'gg': round(float(ex.gg), 4),
                    'hy': round(float(ex.hy), 4),
                    'jz': round(float(ex.jz), 4),
                    'ld': round(float(ex.ld), 4),
                    'mm': round(float(ex.mm), 4),
                    'mv': round(float(ex.mv), 4),
                    'yl': round(float(ex.yl), 4),

                }

        days = sorted(exposure.keys())
        data['exposure_days'] = days
        data['exposure'] = {
            'bd': [],
            'bt': [],
            'gg': [],
            'hy': [],
            'jz': [],
            'ld': [],
            'mm': [],
            'mv': [],
            'yl': [],
        }
        keys = list(data['exposure'].keys())
        for d in days:
            for k in keys:
                data['exposure'][k].append(exposure[d][k])

        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StrategyHyStyleExposureHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        data = {}
        s_id = int(kwargs['id'])
        vs_id = int(self.get_argument('vs_id', 0))
        sc = session()
        s = sc.query(Strategy).filter(
            Strategy.id == s_id
        ).first()
        if not s:
            sc.close()
            self.json_response({
                'code': 3005,
                'data': 'can not find strategy',
                'error': 'can not find strategy',
            })
            return True
        data['name'] = s.name
        data['id'] = s.id
        data['strategy_id'] = s.id_no
        data['creator'] = s.username
        data['create_time'] = s.r_create_time.strftime('%Y%m%d')
        data['papertrading_date'] = (s.paper_trading_date or s.r_create_time).strftime('%Y%m%d')
        data['live_time'] = s.live_time and s.live_time.strftime('%Y%m%d') or ''
        data['strategy_type'] = s.strategy_type

        exposure = {}

        s_exposure = sc.query(StrategyStyleExposure).filter(
            StrategyStyleExposure.strategy_id == s_id,
            StrategyStyleExposure.trading_date >= s.start_date,
        )

        hy_keys = [
            'hy_sws_801010', 'hy_sws_801780', 'hy_sws_801150', 'hy_sws_801110', 'hy_sws_801740',
            'hy_sws_801170', 'hy_sws_801890', 'hy_sws_801120', 'hy_sws_801730', 'hy_sws_801030',
            'hy_sws_801880', 'hy_sws_801210', 'hy_sws_801230', 'hy_sws_801710', 'hy_sws_801720',
            'hy_sws_801790', 'hy_sws_801750', 'hy_sws_801080', 'hy_sws_801760', 'hy_sws_801130',
            'hy_sws_801140', 'hy_sws_801020', 'hy_sws_801040', 'hy_sws_801770', 'hy_sws_801180',
            'hy_sws_801050', 'hy_sws_801160', 'hy_sws_801200'
        ]

        for ex in s_exposure:
            exposure[ex.trading_date] = {k: round(float(getattr(ex, k, 0)), 6) for k in hy_keys}

        if vs_id:
            vs_exposure = sc.query(VStrategyStyleExposure).filter(VStrategyStyleExposure.vs_id == vs_id)
            for ex in vs_exposure:
                exposure[ex.trading_date] = {k: round(float(getattr(ex, k, 0)), 6) for k in hy_keys}

        days = sorted(exposure.keys())
        data['exposure_days'] = days
        data['exposure'] = {k: [] for k in hy_keys}
        for d in days:
            for k in hy_keys:
                data['exposure'][k].append(exposure[d][k])

        data['exposure_cn_name'] = {
            k: SW_IndustryCategory.get(k.split('_')[-1], k) for k in hy_keys
        }

        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StrategyPortfolioStyleExposureHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        s_ids = self.get_argument('s_ids', '')
        vs_ids = self.get_argument('vs_ids', '')
        if s_ids:
            s_ids = [int(s_id) for s_id in s_ids.split(',') if s_id]
        else:
            s_ids = []

        if vs_ids:
            vs_ids = [int(v_id) for v_id in vs_ids.split(',') if v_id]
        else:
            vs_ids = []

        sc = session()
        is_live = str(self.get_argument('is_live', False)).lower()
        if vs_ids and is_live == 'true':
            s_ids = [
                vs[0]
                for vs in sc.query(
                    VStrategies.strategy_id
                ).join(
                    Strategy, Strategy.id == VStrategies.strategy_id
                ).filter(
                    VStrategies.id.in_(vs_ids),
                    Strategy.strategy_type.in_(consts.alpha_stock_strategy_type),
                    VStrategies.status == consts.STRATEGY_LIVE
                )]
            s_ids = list(set(s_ids))

        data = {
            'strategies': {},
            'papertrading_date': '20190101'
        }
        strategies = sc.query(Strategy).filter(
            Strategy.id.in_(s_ids)
        )
        strategy_cash = {}
        for s in strategies:
            s_d = {}
            s_d['name'] = s.name
            s_d['id'] = s.id
            s_d['strategy_id'] = s.id_no
            s_d['creator'] = s.username
            s_d['create_time'] = s.r_create_time.strftime('%Y%m%d')
            s_d['start_date'] = s.start_date
            s_d['papertrading_date'] = (s.paper_trading_date or s.r_create_time).strftime('%Y%m%d')
            s_d['live_time'] = s.live_time and s.live_time.strftime('%Y%m%d') or ''
            s_d['strategy_type'] = s.strategy_type
            s_d['initial_cash'] = float(s.detail.get('initial_cash', 0))
            data['strategies'][s.id] = s_d
            strategy_cash[s.id] = s_d['initial_cash']
            data['papertrading_date'] = max(data['papertrading_date'], s_d['papertrading_date'])

        sum_cash = sum(strategy_cash.values())
        exposure = {}
        exposure_keys = [
            'bd', 'bt', 'gg', 'hy', 'jz', 'ld', 'mm', 'mv', 'yl',
        ]

        for s_id, s_cash in strategy_cash.items():
            s_w = float(s_cash) / sum_cash
            s_exposure = sc.query(StrategyStyleExposure).filter(
                StrategyStyleExposure.strategy_id == s_id,
                StrategyStyleExposure.trading_date >= data['strategies'][s_id]['start_date'],
            )
            _s_exposure = {}
            for ex in s_exposure:
                _s_exposure[ex.trading_date] = {}
                for k in exposure_keys:
                    _s_exposure[ex.trading_date][k] = float(getattr(ex, k, 0)) * s_w

            for d_t, v in _s_exposure.items():
                d_exposure = exposure.setdefault(d_t, {})
                for k in exposure_keys:
                    d_exposure[k] = d_exposure.get(k, 0) + v[k]

        data['strategies'] = sorted(data['strategies'].values(), key=lambda x: x['id'])
        days = sorted(exposure.keys())
        data['exposure_days'] = days
        data['exposure'] = {
            k: [] for k in exposure_keys
        }
        for d in days:
            for k in exposure_keys:
                data['exposure'][k].append(round(exposure[d][k], 4))

        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StrategyPortfolioHyStyleExposureHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        s_ids = self.get_argument('s_ids', '')
        if s_ids:
            s_ids = [int(s_id) for s_id in s_ids.split(',') if s_id]
        else:
            s_ids = []

        vs_ids = self.get_argument('vs_ids', '')
        if vs_ids:
            vs_ids = [int(v_id) for v_id in vs_ids.split(',') if v_id]
        else:
            vs_ids = []

        is_live = str(self.get_argument('is_live', False)).lower()
        sc = session()

        if vs_ids and is_live == 'true':
            s_ids = [
                vs[0]
                for vs in sc.query(
                    VStrategies.strategy_id
                ).join(
                    Strategy, Strategy.id == VStrategies.strategy_id
                ).filter(
                    VStrategies.id.in_(vs_ids),
                    Strategy.strategy_type.in_(consts.alpha_stock_strategy_type),
                    VStrategies.status == consts.STRATEGY_LIVE
                )]
            s_ids = list(set(s_ids))

        data = {
            'strategies': {},
            'papertrading_date': '20190101'
        }
        strategies = sc.query(Strategy).filter(
            Strategy.id.in_(s_ids)
        )
        strategy_cash = {}
        for s in strategies:
            s_d = {}
            s_d['name'] = s.name
            s_d['id'] = s.id
            s_d['strategy_id'] = s.id_no
            s_d['creator'] = s.username
            s_d['create_time'] = s.r_create_time.strftime('%Y%m%d')
            s_d['start_date'] = s.start_date
            s_d['papertrading_date'] = (s.paper_trading_date or s.r_create_time).strftime('%Y%m%d')
            s_d['live_time'] = s.live_time and s.live_time.strftime('%Y%m%d') or ''
            s_d['strategy_type'] = s.strategy_type
            s_d['initial_cash'] = float(s.detail.get('initial_cash', 0))
            data['strategies'][s.id] = s_d
            strategy_cash[s.id] = s_d['initial_cash']
            data['papertrading_date'] = max(data['papertrading_date'], s_d['papertrading_date'])

        sum_cash = sum(strategy_cash.values())

        exposure = {}

        hy_keys = [
            'hy_sws_801010', 'hy_sws_801780', 'hy_sws_801150', 'hy_sws_801110', 'hy_sws_801740',
            'hy_sws_801170', 'hy_sws_801890', 'hy_sws_801120', 'hy_sws_801730', 'hy_sws_801030',
            'hy_sws_801880', 'hy_sws_801210', 'hy_sws_801230', 'hy_sws_801710', 'hy_sws_801720',
            'hy_sws_801790', 'hy_sws_801750', 'hy_sws_801080', 'hy_sws_801760', 'hy_sws_801130',
            'hy_sws_801140', 'hy_sws_801020', 'hy_sws_801040', 'hy_sws_801770', 'hy_sws_801180',
            'hy_sws_801050', 'hy_sws_801160', 'hy_sws_801200'
        ]

        for s_id, s_cash in strategy_cash.items():
            s_w = float(s_cash) / sum_cash
            s_exposure = sc.query(StrategyStyleExposure).filter(
                StrategyStyleExposure.strategy_id == s_id,
                StrategyStyleExposure.trading_date >= data['strategies'][s_id]['start_date'],
            )
            _s_exposure = {}
            for ex in s_exposure:
                _s_exposure[ex.trading_date] = {}
                for k in hy_keys:
                    _s_exposure[ex.trading_date][k] = float(getattr(ex, k, 0)) * s_w

            for d_t, v in _s_exposure.items():
                d_exposure = exposure.setdefault(d_t, {})
                for k in hy_keys:
                    d_exposure[k] = d_exposure.get(k, 0) + v[k]

        data['strategies'] = sorted(data['strategies'].values(), key=lambda x: x['id'])
        days = sorted(exposure.keys())
        data['exposure_days'] = days
        data['exposure'] = {k: [] for k in hy_keys}
        for d in days:
            for k in hy_keys:
                data['exposure'][k].append(round(exposure[d][k], 6))
        data['exposure_cn_name'] = {
            k: SW_IndustryCategory.get(k.split('_')[-1], k) for k in hy_keys
        }
        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StrategyVsPortfolioStyleExposureHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_ids = self.get_argument('vs_ids', '')
        if vs_ids:
            vs_ids = [int(s_id) for s_id in vs_ids.split(',') if s_id]
        else:
            vs_ids = []
        data = VStrategyStyleExposure.get_vs_portfolio_style_exposure(vs_ids)
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StrategyVsPortfolioHyStyleExposureHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_ids = self.get_argument('vs_ids', '')
        if vs_ids:
            vs_ids = [int(s_id) for s_id in vs_ids.split(',') if s_id]
        else:
            vs_ids = []
        data = VStrategyStyleExposure.get_vs_portfolio_hy_style_exposure(vs_ids)
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StrategyIncomeAttributionHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        s_id = int(kwargs['id'])
        vs_id = int(self.get_argument('vs_id', 0))
        sc = session()
        s = sc.query(Strategy).filter(
            Strategy.id == s_id
        ).first()
        if not s:
            sc.close()
            self.json_response({
                'code': 3005,
                'data': 'can not find strategy',
                'error': 'can not find strategy',
            })
            return True

        data = {
            'name': s.name,
            'id': s.id,
            'strategy_id': s.id_no,
            'creator': s.username,
            'create_time': s.r_create_time.strftime('%Y%m%d'),
            'papertrading_date': (s.paper_trading_date or s.r_create_time).strftime('%Y%m%d'),
            'live_time': s.live_time and s.live_time.strftime('%Y%m%d') or '',
            'strategy_type': s.strategy_type
        }

        s_income_attribution = sc.query(StrategyIncomeAttribution).filter(
            StrategyIncomeAttribution.strategy_id == s_id,
            StrategyIncomeAttribution.trading_date >= s.start_date
        )
        income_attribution = {}
        total_income_attr = {}
        for income in s_income_attribution:
            d = income.trading_date
            income_attribution[d] = {
                'bd': round(float(income.bd), 6),
                'bt': round(float(income.bt), 6),
                'gg': round(float(income.gg), 6),
                'hy': round(float(income.hy), 6),
                'jz': round(float(income.jz), 6),
                'ld': round(float(income.ld), 6),
                'mm': round(float(income.mm), 6),
                'mv': round(float(income.mv), 6),
                'yl': round(float(income.yl), 6),
            }
            total_income_attr[d] = sum(income_attribution[d].values())

        if vs_id:
            vs_income_attribution = sc.query(VStrategyIncomeAttribution).filter(
                VStrategyIncomeAttribution.vs_id == vs_id)
            for income in vs_income_attribution:
                income_attribution[income.trading_date] = {
                    'bd': round(float(income.bd), 6),
                    'bt': round(float(income.bt), 6),
                    'gg': round(float(income.gg), 6),
                    'hy': round(float(income.hy), 6),
                    'jz': round(float(income.jz), 6),
                    'ld': round(float(income.ld), 6),
                    'mm': round(float(income.mm), 6),
                    'mv': round(float(income.mv), 6),
                    'yl': round(float(income.yl), 6),
                }

        days = sorted(income_attribution.keys())
        data['income_attribution_days'] = days
        data['income_attribution'] = {
            'bd': [],
            'bt': [],
            'gg': [],
            'hy': [],
            'jz': [],
            'ld': [],
            'mm': [],
            'mv': [],
            'yl': [],
        }
        keys = list(data['income_attribution'].keys())
        for d in days:
            for k in keys:
                data['income_attribution'][k].append(income_attribution[d][k])

        data['alpha'] = []
        try:
            alpha_hedge_ret = BackTestPerformance.get_strategy_hedge_performance_ret(s_id)
            for d in data['income_attribution_days']:
                data['alpha'].append(round(alpha_hedge_ret.get(d, 0) - total_income_attr.get(d, 0), 6))
        except Exception as e:
            sentry.captureException()

        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StrategyIncomeHyAttributionHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        data = {}
        s_id = int(kwargs['id'])
        vs_id = int(self.get_argument('vs_id', 0))
        sc = session()
        s = sc.query(Strategy).filter(
            Strategy.id == s_id
        ).first()
        if not s:
            sc.close()
            self.json_response({
                'code': 3005,
                'data': 'can not find strategy',
                'error': 'can not find strategy',
            })
            return True
        data['name'] = s.name
        data['id'] = s.id
        data['strategy_id'] = s.id_no
        data['creator'] = s.username
        data['create_time'] = s.r_create_time.strftime('%Y%m%d')
        data['papertrading_date'] = (s.paper_trading_date or s.r_create_time).strftime('%Y%m%d')
        data['live_time'] = s.live_time and s.live_time.strftime('%Y%m%d') or ''
        data['strategy_type'] = s.strategy_type

        income_attr = {}

        s_income_attr = sc.query(StrategyIncomeAttribution).filter(
            StrategyIncomeAttribution.strategy_id == s_id,
            StrategyIncomeAttribution.trading_date >= s.start_date,
        )

        hy_keys = [
            'hy_sws_801010', 'hy_sws_801780', 'hy_sws_801150', 'hy_sws_801110', 'hy_sws_801740',
            'hy_sws_801170', 'hy_sws_801890', 'hy_sws_801120', 'hy_sws_801730', 'hy_sws_801030',
            'hy_sws_801880', 'hy_sws_801210', 'hy_sws_801230', 'hy_sws_801710', 'hy_sws_801720',
            'hy_sws_801790', 'hy_sws_801750', 'hy_sws_801080', 'hy_sws_801760', 'hy_sws_801130',
            'hy_sws_801140', 'hy_sws_801020', 'hy_sws_801040', 'hy_sws_801770', 'hy_sws_801180',
            'hy_sws_801050', 'hy_sws_801160', 'hy_sws_801200'
        ]

        for attr in s_income_attr:
            income_attr[attr.trading_date] = {k: round(float(getattr(attr, k, 0)), 6) for k in hy_keys}

        if vs_id:
            vs_exposure = sc.query(StrategyIncomeAttribution).filter(StrategyIncomeAttribution.vs_id == vs_id)
            for ex in vs_exposure:
                income_attr[ex.trading_date] = {k: round(float(getattr(ex, k, 0)), 6) for k in hy_keys}

        days = sorted(income_attr.keys())
        data['income_attr_days'] = days
        data['income_attr'] = {k: [] for k in hy_keys}
        for d in days:
            for k in hy_keys:
                data['income_attr'][k].append(income_attr[d][k])

        data['income_attr_cn_name'] = {
            k: SW_IndustryCategory.get(k.split('_')[-1], k) for k in hy_keys
        }

        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StrategyRiskAttributionHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        data = {
            'daily_stock_number': 0,
            'turnover_rate': 0,
            'withdraw_rate': 0,
        }
        s_id = int(kwargs['id'])
        vs_id = int(self.get_argument('vs_id', 0))
        sc = session()
        s = sc.query(Strategy).filter(
            Strategy.id == s_id
        ).first()
        if not s:
            sc.close()
            self.json_response({
                'code': 3005,
                'data': 'can not find strategy',
                'error': 'can not find strategy',
            })
            return True
        data['name'] = s.name
        data['id'] = s.id
        data['strategy_id'] = s.id_no
        data['creator'] = s.username
        data['create_time'] = s.r_create_time.strftime('%Y%m%d')
        data['papertrading_date'] = (s.paper_trading_date or s.r_create_time).strftime('%Y%m%d')
        data['live_time'] = s.live_time and s.live_time.strftime('%Y%m%d') or ''
        data['strategy_type'] = s.strategy_type

        risk_attribution = {}
        s_risk_attribution = sc.query(StrategyRiskAttribute).filter(
            StrategyRiskAttribute.strategy_id == s_id,
            StrategyRiskAttribute.trading_date >= s.start_date
        )

        attr_keys = [
            'max_w_800', 'non800_max_w', 'non800_ratio', 'startup_w', 'FVbelow14_w', 'TolValue', 'FloatValue',
            'liquidity', 'withdraw_rate', 'non800_top30_max_w',
            'noncsi800_nontop30_max_w', 'top20_value_w', 'daily_stock_number', 'industry_max_w'
        ]

        attr_keys2 = {
            'wt_max': 'max_w_800',
            'wt_max_non_csi800': 'non800_max_w',
            'wt_total_non_csi800': 'non800_ratio',
            'wt_total_gem': 'startup_w',
            'wt_total_14b': 'FVbelow14_w',
            # 'TolValue': 'TolValue',
            'FloatValue': 'FloatValue',
            'turnover_rate': 'liquidity',
            'withdraw_rate': 'withdraw_rate',
            'non800_top30_max_w': 'non800_top30_max_w',
            'noncsi800_nontop30_max_w': 'noncsi800_nontop30_max_w',
            'top20_value_w': 'top20_value_w',
            'daily_stock_number': 'daily_stock_number',
            'industry_max_w': 'industry_max_w',
        }

        def get_k_weight(k):
            if k in ('max_w_800', 'non800_max_w', 'non800_ratio', 'startup_w', 'FVbelow14_w',
                     'non800_top30_max_w', 'noncsi800_nontop30_max_w', 'top20_value_w', 'industry_max_w'):
                return 100
            return 1

        for r in s_risk_attribution:
            risk_attribution[r.trading_date] = {k: round(float(getattr(r, k, 0)), 6) * get_k_weight(k) for k in
                                                attr_keys}

        stock_trade_inds = sc.query(
            StrategyBackTestTradeIndicator.trading_date.label('trading_date'),
            StrategyBackTestTradeIndicator.liquidity.label('liquidity'),
            StrategyBackTestTradeIndicator.withdraw_rate.label('withdraw_rate'),
            StrategyBackTestTradeIndicator.daily_stock_number.label('daily_stock_number'),
        ).filter(
            StrategyBackTestTradeIndicator.s_id == s_id,
            StrategyBackTestTradeIndicator.trading_date >= s.start_date
        )
        for l in stock_trade_inds:
            d = l.trading_date.strftime('%Y%m%d')
            if d not in risk_attribution:
                continue
            risk_attribution[d]['liquidity'] = float(l.liquidity)
            risk_attribution[d]['withdraw_rate'] = float(l.withdraw_rate)
            risk_attribution[d]['daily_stock_number'] = float(l.daily_stock_number)

        days = sorted(risk_attribution.keys())
        data['risk_attribution_days'] = days
        data['risk_attribution'] = {k: [] for k in attr_keys}
        for d in days:
            for k in attr_keys:
                data['risk_attribution'][k].append(risk_attribution[d][k])

        risk_attribution2 = {}
        for k1, k2 in attr_keys2.items():
            risk_attribution2[k1] = data['risk_attribution'][k2]

        data['risk_attribution'] = risk_attribution2
        for k in ('daily_stock_number', 'turnover_rate', 'withdraw_rate'):
            if data['risk_attribution'][k]:
                data[k] = round(sum(data['risk_attribution'][k]) / len(data['risk_attribution'][k]), 2)
        del data['risk_attribution']['daily_stock_number']
        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class PortfolioRiskAttributionHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        s_ids = self.get_argument('s_ids', '')
        if s_ids:
            s_ids = [int(s_id) for s_id in s_ids.split(',') if s_id]
        else:
            s_ids = []

        vs_ids = self.get_argument('vs_ids', '')
        if vs_ids:
            vs_ids = [int(v_id) for v_id in vs_ids.split(',') if v_id]
        else:
            vs_ids = []

        is_live = str(self.get_argument('is_live', False)).lower()
        sc = session()

        if vs_ids and is_live == 'true':
            s_ids = [
                vs[0]
                for vs in sc.query(
                    VStrategies.strategy_id
                ).join(
                    Strategy, Strategy.id == VStrategies.strategy_id
                ).filter(
                    VStrategies.id.in_(vs_ids),
                    Strategy.strategy_type.in_(consts.alpha_stock_strategy_type),
                    VStrategies.status == consts.STRATEGY_LIVE
                )]
            s_ids = list(set(s_ids))

        if s_ids:
            generate_strategy_portfolio_risk_delay.delay(s_ids)

        data = {
            'strategies': {},
            'daily_stock_number': 0,
            'turnover_rate': 0,
            'withdraw_rate': 0,
            'papertrading_date': '20190101'
        }
        s_ids_str = '_'.join(map(str, sorted(s_ids)))
        strategies = sc.query(Strategy).filter(
            Strategy.id.in_(s_ids)
        )
        strategy_cash = {}
        start_date = '20180101'
        for s in strategies:
            s_d = {}
            s_d['name'] = s.name
            s_d['id'] = s.id
            s_d['strategy_id'] = s.id_no
            s_d['creator'] = s.username
            s_d['create_time'] = s.r_create_time.strftime('%Y%m%d')
            s_d['start_date'] = s.start_date
            s_d['papertrading_date'] = (s.paper_trading_date or s.r_create_time).strftime('%Y%m%d')
            s_d['live_time'] = s.live_time and s.live_time.strftime('%Y%m%d') or ''
            s_d['strategy_type'] = s.strategy_type
            s_d['initial_cash'] = float(s.detail.get('initial_cash', 0))
            data['strategies'][s.id] = s_d
            strategy_cash[s.id] = s_d['initial_cash']
            start_date = min(start_date, s.start_date)
            data['papertrading_date'] = max(data['papertrading_date'], s_d['papertrading_date'])

        data['strategies'] = sorted(data['strategies'].values(), key=lambda x: x['id'])

        risk_attribution = {}
        s_risk_attribution = sc.query(PortfolioRiskAttribute).filter(
            PortfolioRiskAttribute.strategy_ids == s_ids_str,
            PortfolioRiskAttribute.trading_date >= start_date
        )

        attr_keys = [
            'max_w_800', 'non800_max_w', 'non800_ratio', 'startup_w', 'FVbelow14_w', 'TolValue', 'FloatValue',
            'liquidity', 'withdraw_rate', 'non800_top30_max_w', 'noncsi800_nontop30_max_w',
            'top20_value_w', 'daily_stock_number', 'industry_max_w',
        ]

        attr_keys2 = {
            'wt_max': 'max_w_800',
            'wt_max_non_csi800': 'non800_max_w',
            'wt_total_non_csi800': 'non800_ratio',
            'wt_total_gem': 'startup_w',
            'wt_total_14b': 'FVbelow14_w',
            # 'TolValue': 'TolValue',
            'FloatValue': 'FloatValue',
            'turnover_rate': 'liquidity',
            'withdraw_rate': 'withdraw_rate',
            'non800_top30_max_w': 'non800_top30_max_w',
            'noncsi800_nontop30_max_w': 'noncsi800_nontop30_max_w',
            'top20_value_w': 'top20_value_w',
            'daily_stock_number': 'daily_stock_number',
            'industry_max_w': 'industry_max_w',
        }

        def get_k_weight(k):
            if k in ('max_w_800', 'non800_max_w', 'non800_ratio', 'startup_w', 'FVbelow14_w',
                     'non800_top30_max_w', 'noncsi800_nontop30_max_w', 'top20_value_w', 'industry_max_w'):
                return 100
            return 1

        for r in s_risk_attribution:
            risk_attribution[r.trading_date] = {k: round(float(getattr(r, k, 0)), 6) * get_k_weight(k) for k in
                                                attr_keys}

        days = sorted(risk_attribution.keys())
        data['risk_attribution_days'] = days
        data['risk_attribution'] = {k: [] for k in attr_keys}
        for d in days:
            for k in attr_keys:
                data['risk_attribution'][k].append(risk_attribution[d][k])

        risk_attribution2 = {}
        for k1, k2 in attr_keys2.items():
            risk_attribution2[k1] = data['risk_attribution'][k2]

        data['risk_attribution'] = risk_attribution2

        for k in ('daily_stock_number', 'turnover_rate', 'withdraw_rate'):
            if data['risk_attribution'][k]:
                data[k] = round(sum(data['risk_attribution'][k]) / len(data['risk_attribution'][k]), 2)
        del data['risk_attribution']['daily_stock_number']
        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })


class VsPortfolioRiskAttributionHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_ids = self.get_argument('vs_ids', '')
        if vs_ids:
            vs_ids = [int(s_id) for s_id in vs_ids.split(',') if s_id]
        else:
            vs_ids = []
        sc = session()

        vs_ids = [
            vs[0]
            for vs in sc.query(
                VStrategies.id
            ).join(
                Strategy, Strategy.id == VStrategies.strategy_id
            ).filter(
                VStrategies.id.in_(vs_ids),
                Strategy.strategy_type.in_(consts.alpha_stock_strategy_type),
            )]
        vs_ids = list(set(vs_ids))

        if vs_ids:
            generate_vs_portfolio_risk_delay.delay(vs_ids)

        data = {
            'strategies': {},
            'daily_stock_number': 0,
            'turnover_rate': 0,
            'withdraw_rate': 0,
            'papertrading_date': '20190101'
        }
        s_ids_str = 'live_' + '_'.join(map(str, sorted(vs_ids)))
        risk_attribution = {}
        s_risk_attribution = sc.query(PortfolioRiskAttribute).filter(
            PortfolioRiskAttribute.strategy_ids == s_ids_str,
        )

        attr_keys = [
            'max_w_800', 'non800_max_w', 'non800_ratio', 'startup_w', 'FVbelow14_w', 'TolValue', 'FloatValue',
            'liquidity', 'withdraw_rate', 'non800_top30_max_w', 'noncsi800_nontop30_max_w',
            'top20_value_w', 'daily_stock_number', 'industry_max_w',
        ]

        attr_keys2 = {
            'wt_max': 'max_w_800',
            'wt_max_non_csi800': 'non800_max_w',
            'wt_total_non_csi800': 'non800_ratio',
            'wt_total_gem': 'startup_w',
            'wt_total_14b': 'FVbelow14_w',
            # 'TolValue': 'TolValue',
            'FloatValue': 'FloatValue',
            'turnover_rate': 'liquidity',
            'withdraw_rate': 'withdraw_rate',
            'non800_top30_max_w': 'non800_top30_max_w',
            'noncsi800_nontop30_max_w': 'noncsi800_nontop30_max_w',
            'top20_value_w': 'top20_value_w',
            'daily_stock_number': 'daily_stock_number',
            'industry_max_w': 'industry_max_w',
        }

        def get_k_weight(k):
            if k in ('max_w_800', 'non800_max_w', 'non800_ratio', 'startup_w', 'FVbelow14_w',
                     'non800_top30_max_w', 'noncsi800_nontop30_max_w', 'top20_value_w', 'industry_max_w'):
                return 100
            return 1

        for r in s_risk_attribution:
            risk_attribution[r.trading_date] = {k: round(float(getattr(r, k, 0)), 6) * get_k_weight(k) for k in
                                                attr_keys}

        days = sorted(risk_attribution.keys())
        data['risk_attribution_days'] = days
        data['risk_attribution'] = {k: [] for k in attr_keys}
        for d in days:
            for k in attr_keys:
                data['risk_attribution'][k].append(risk_attribution[d][k])

        risk_attribution2 = {}
        for k1, k2 in attr_keys2.items():
            risk_attribution2[k1] = data['risk_attribution'][k2]

        data['risk_attribution'] = risk_attribution2

        for k in ('daily_stock_number', 'turnover_rate', 'withdraw_rate'):
            if data['risk_attribution'][k]:
                data[k] = round(sum(data['risk_attribution'][k]) / len(data['risk_attribution'][k]), 2)
        del data['risk_attribution']['daily_stock_number']
        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })


class TradingProductHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        sc = session()
        now = datetime.datetime.now()
        if 6 <= now.hour < 17:
            day_night = 0
        else:
            day_night = 1

        strategies = sc.query(
            Strategy.products.label('products')
        ).join(
            VStrategies, VStrategies.strategy_id == Strategy.id
        ).filter(
            VStrategies.status == consts.STRATEGY_LIVE,
            Strategy.day_night.in_([2, day_night])
        )

        products = set()
        for s in strategies:
            for pp in s.products[:1]:
                for p in pp:
                    if p['exch'] not in consts.FOREIGN_EXCHANGE:
                        continue
                    products.add('%s@%s' % (p['symbol'], p['exch']))

        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'products': list(products),
            }
        })
        return True


class StrategyBackTestRedoHandler(JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        s_id = int(kwargs['id'])
        payload = self.get_payload()
        sc = session()
        s = sc.query(Strategy).filter(
            Strategy.id == s_id,
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.node.in_(['back_test', 'order_list', 'trademaster_order_list', 'ev', 'union_simu'])
        ).first()
        if not s:
            sc.close()
            self.json_response({
                'code': 3010,
                'error': 'can not find strategy',
            })
            return True
        action = payload['action'].lower()
        if action == 'redo':
            s.stop_task()
            detail = copy.deepcopy(s.detail)
            s.start_date = parse(str(payload['start'])).strftime('%Y%m%d')
            detail['start'] = s.start_date
            detail['initial_cash'] = int(payload.get('initial_cash', 0))
            if 'se_cash_rate' in payload:
                detail['se_cash_rate'] = float(payload.get('se_cash_rate', 0) or 0)
            detail['accounts'] = payload.get('accounts', {})
            if payload.get('trade_model'):
                detail['trade_model'] = str(payload['trade_model'])
            if detail['accounts']:
                initial_cash = 0
                for _, a_d in detail['accounts'].items():
                    initial_cash += a_d['cash']
                detail['initial_cash'] = initial_cash
            s.detail = detail
            s.st_uuid = uuid.uuid1().hex
            s.task_progress = 0
            s.status = consts.TASK_RUNNING

            if s.strategy_type == '34':
                union_s_ids = list(s.detail.get('union_stra_weight', {}).keys())
                union_stra_weight = {}
                for k, v in s.detail.get('union_stra_weight', {}).items():
                    union_stra_weight[int(k)] = float(v)
                union_initial_cash = split_initial_cash(s.detail['initial_cash'], union_stra_weight)
                all_sub_s_obj = sc.query(Strategy).filter(
                    Strategy.id.in_(union_s_ids)
                ).all()  # query return obj for updating initial cash
                for sub_s_obj in all_sub_s_obj:
                    # update initial cash for each sub strategy
                    sub_s_detail = copy.deepcopy(sub_s_obj.detail)
                    sub_s_detail['initial_cash'] = union_initial_cash[sub_s_obj.id]
                    sub_s_obj.detail = sub_s_detail

                    # delete history backtest data for sub strategy.
                    sc.query(
                        StrategyResult
                    ).filter(
                        StrategyResult.strategy_id == sub_s_obj.id,
                        StrategyResult.config_id == 0
                    ).delete(synchronize_session=False)

                    sc.query(
                        StrategyResultDetail
                    ).filter(
                        StrategyResultDetail.strategy_id == sub_s_obj.id,
                        StrategyResultDetail.config_id == 0
                    ).delete(synchronize_session=False)

                    sc.query(StrategyResultAccount).filter(
                        StrategyResultAccount.strategy_id == sub_s_obj.id,
                        StrategyResultAccount.config_id == 0
                    ).delete(synchronize_session=False)

            sc.query(
                StrategyResult
            ).filter(
                StrategyResult.strategy_id == s.id,
                StrategyResult.config_id == 0
            ).delete(synchronize_session=False)

            sc.query(
                StrategyResultDetail
            ).filter(
                StrategyResultDetail.strategy_id == s.id,
                StrategyResultDetail.config_id == 0
            ).delete(synchronize_session=False)

            sc.query(StrategyResultAccount).filter(
                StrategyResultAccount.strategy_id == s.id,
                StrategyResultAccount.config_id == 0
            ).delete(synchronize_session=False)
            sc.commit()

            start_strategy_task.delay(s.id, task_id=s.st_uuid)
            Strategy.add_strategy_event(
                s.id,
                s.start_date,
                0,
                'RedoStrategyBackTest',
                task_id=s.st_uuid,
                detail=payload
            )
        elif action == 'relay':
            if payload['start'] == 'max':
                start_date = sc.query(func.max(StrategyResult.date)).filter(
                    StrategyResult.strategy_id == s_id,
                    StrategyResult.config_id == 0
                ).first()
                if start_date:
                    start_date = start_date[0]
                if not start_date:
                    start_date = s.start_date
            else:
                start_date = str(payload['start'])

            start_date = parse(start_date).strftime('%Y%m%d')

            if s.strategy_type == '34':
                union_s_ids = list(s.detail.get('union_stra_weight', {}).keys())
                all_sub_s = sc.query(Strategy.id).filter(Strategy.id.in_(union_s_ids)).all()
                for sub_s in all_sub_s:
                    # delete history backtest data for sub strategy.
                    sc.query(StrategyResult).filter(
                        StrategyResult.strategy_id == sub_s.id,
                        StrategyResult.date >= start_date,
                        StrategyResult.config_id == 0,
                    ).delete(synchronize_session=False)

                    sc.query(StrategyResultDetail).filter(
                        StrategyResultDetail.strategy_id == sub_s.id,
                        StrategyResultDetail.trading_date >= start_date,
                        StrategyResultDetail.config_id == 0
                    ).delete(synchronize_session=False)

                    sc.query(StrategyResultAccount).filter(
                        StrategyResultAccount.strategy_id == sub_s.id,
                        StrategyResultAccount.trading_date >= start_date,
                        StrategyResultAccount.config_id == 0
                    ).delete(synchronize_session=False)

                    sc.query(BackTestTradeLogs).filter(
                        BackTestTradeLogs.strategy_id == sub_s.id,
                        BackTestTradeLogs.trading_date >= start_date,
                    ).delete(synchronize_session=False)

            sc.query(StrategyResult).filter(
                StrategyResult.strategy_id == s.id,
                StrategyResult.date >= start_date,
                StrategyResult.config_id == 0,
            ).delete(synchronize_session=False)

            sc.query(StrategyResultDetail).filter(
                StrategyResultDetail.strategy_id == s.id,
                StrategyResultDetail.trading_date >= start_date,
                StrategyResultDetail.config_id == 0
            ).delete(synchronize_session=False)

            sc.query(StrategyResultAccount).filter(
                StrategyResultAccount.strategy_id == s.id,
                StrategyResultAccount.trading_date >= start_date,
                StrategyResultAccount.config_id == 0
            ).delete(synchronize_session=False)

            sc.query(BackTestTradeLogs).filter(
                BackTestTradeLogs.strategy_id == s.id,
                BackTestTradeLogs.trading_date >= start_date,
            ).delete(synchronize_session=False)
            sc.commit()

            redo_strategy_papertrading.delay(s.id, start_date)
            s.r_update_time = datetime.datetime.now()
            s.status = consts.TASK_RUNNING
            sc.commit()

            Strategy.add_strategy_event(
                s.id,
                start_date,
                0,
                'RelayStrategyBackTest',
                task_id=s.st_uuid,
                detail=payload
            )
        elif action == 'stop':
            s.status = consts.TASK_STOPPED
            s.stop_task()
            sc.commit()
        else:
            sc.close()
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'error': 'action: {action} do not support'.format(action=action),
            })
            return False

        sc.close()
        update_strategy_sorting_result.delay(s_id)
        del_cache('platform_strategy_brief_%s_0_0' % s_id)
        del_cache('platform_strategy_detail_%s_0_0' % s_id)
        del_cache('platform_strategy_output_%s_0' % s_id)
        self.json_response({
            'code': APIResponseCode.OK.value,
            'data': 'success',
        })
        return True


class StockFactorReturnHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        sc = session()
        data = {}

        factor_return = {}
        for fr in sc.query(StockFactorReturn):
            factor_return[fr.trading_date] = {
                'bd': round(float(fr.bd), 6),
                'bt': round(float(fr.bt), 6),
                'gg': round(float(fr.gg), 6),
                'hy': round(float(fr.hy), 6),
                'jz': round(float(fr.jz), 6),
                'ld': round(float(fr.ld), 6),
                'mm': round(float(fr.mm), 6),
                'mv': round(float(fr.mv), 6),
                'yl': round(float(fr.yl), 6),

            }
        days = sorted(factor_return.keys())
        data['factor_return_days'] = days
        data['factor_return'] = {
            'bd': [],
            'bt': [],
            'gg': [],
            'jz': [],
            'ld': [],
            'mm': [],
            'mv': [],
            'yl': [],
        }
        keys = list(data['factor_return'].keys())
        for d in days:
            for k in keys:
                data['factor_return'][k].append(factor_return[d][k])

        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class VsTradingVolumeRatioHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_id = int(kwargs['id'])

        self.json_response({
            'code': 0,
            'data': VsTradingVolumeRatioStatistic.get_daily_max_volume_ratio(vs_id)
        })
        return True


class VsTradingVolumeRatioDailyHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_id = int(kwargs['id'])
        trading_date = parse(self.get_argument('trading_date', datetime.datetime.now().strftime('%Y%m%d'))).strftime(
            '%Y%m%d')
        self.json_response({
            'code': 0,
            'data': VsTradingVolumeRatioStatistic.get_daily_max_volume_ratio_detail(vs_id, trading_date)
        })
        return True


class VsBackTestTradingVolumeRatioHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_id = int(kwargs['id'])

        self.json_response({
            'code': 0,
            'data': VsBacktestTradingVolumeRatioStatistic.get_daily_max_volume_ratio(vs_id)
        })
        return True


class VsBackTestTradingVolumeRatioDailyHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_id = int(kwargs['id'])
        trading_date = parse(self.get_argument('trading_date', datetime.datetime.now().strftime('%Y%m%d'))).strftime(
            '%Y%m%d')
        self.json_response({
            'code': 0,
            'data': VsBacktestTradingVolumeRatioStatistic.get_daily_max_volume_ratio_detail(vs_id, trading_date)
        })
        return True


class StrategyTradingVolumeRatioHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        s_id = int(kwargs['id'])

        self.json_response({
            'code': 0,
            'data': StrategyTradingVolumeRatioStatistic.get_daily_max_volume_ratio(s_id)
        })
        return True


class StrategyTradingVolumeRatioDailyHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        s_id = int(kwargs['id'])
        trading_date = parse(self.get_argument('trading_date', datetime.datetime.now().strftime('%Y%m%d'))).strftime(
            '%Y%m%d')
        self.json_response({
            'code': 0,
            'data': StrategyTradingVolumeRatioStatistic.get_daily_max_volume_ratio_detail(s_id, trading_date)
        })
        return True


class StockVsDiffHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_id = int(kwargs['id'])
        trading_date = self.get_argument('trading_date', '')
        if not trading_date:
            now = datetime.datetime.now()
            week_day = now.weekday()
            if week_day == 0:
                trading_date = (now - datetime.timedelta(days=3)).strftime('%Y%m%d')
            elif week_day == 6:
                trading_date = (now - datetime.timedelta(days=2)).strftime('%Y%m%d')
            elif week_day == 5:
                trading_date = (now - datetime.timedelta(days=1)).strftime('%Y%m%d')
            else:
                if now.strftime('%H%M') <= '1945':
                    trading_date = (now - datetime.timedelta(days=1)).strftime('%Y%m%d')
                else:
                    trading_date = now.strftime('%Y%m%d')
        sc = session()
        obj = sc.query(VsbBackTestPara.use_last_live_position).filter(
            VsbBackTestPara.vstrategy_id == vs_id,
            VsbBackTestPara.trading_date == trading_date).first()
        use_last_live_position = obj.use_last_live_position if obj else False
        sc.close()
        data = StockVsDiff(vs_id, trading_date).get_diff()
        data['use_last_live_position'] = use_last_live_position
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class StockLiveLogHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_id = int(kwargs['id'])
        trading_date = self.get_argument('trading_date', '')
        if not trading_date:
            now = datetime.datetime.now()
            week_day = now.weekday()
            if week_day == 0:
                trading_date = (now - datetime.timedelta(days=3)).strftime('%Y%m%d')
            elif week_day == 6:
                trading_date = (now - datetime.timedelta(days=2)).strftime('%Y%m%d')
            elif week_day == 5:
                trading_date = (now - datetime.timedelta(days=1)).strftime('%Y%m%d')
            else:
                if now.strftime('%H%M') <= '1945':
                    trading_date = (now - datetime.timedelta(days=1)).strftime('%Y%m%d')
                else:
                    trading_date = now.strftime('%Y%m%d')
        try:
            df1, df2 = get_live_log(vs_id, trading_date)
            values1 = df1.values.tolist()
            values2 = df2.values.tolist()
        except Exception as e:
            values1 = []
            values2 = []
        data = {
            'symbols': {
                'columns': ['股票代码', '昨仓股数', '昨仓权重', '今仓股数', '今仓权重', '收益', '策略收益', '行业收益', '收益偏离', '申万行业', 'Wind概念'],
                'values': values1,
                'highlight': [8],
            },
            'industry_category': {
                'columns': ['行业', '策略权重', '基准权重', '权重偏离', '策略收益', '基准收益', '收益偏离'],
                # 'columns': ['行业', ['权重', '策略', '基准', '偏离'], ['收益', '策略', '行业']],
                'values': values2,
                'highlight': [3, 6],
            },
        }
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


""" old version
class FutureRiskHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        res = []
        for acc, acc_d in sorted(consts.future_risk_accounts.items(), key=lambda x: x[0]):
            acc_file = os.path.join(config.media, 'account_cash_risk/%s.json' % acc)
            if os.path.exists(acc_file):
                f = open(acc_file, 'r')
                try:
                    data = json.load(f)
                except Exception as e:
                    data = {
                        'values': []
                    }
                f.close()
            else:
                data = {
                    'values': []
                }
            acc_d['values'] = data['values']
            acc_d['columns'] = ['query_time', 'risk', 'available', 'total_asset']
            acc_d['risk'] = 0
            acc_d['available'] = 0
            acc_d['total_asset'] = 0
            if acc_d['values']:
                acc_d['risk'] = round(acc_d['values'][-1][1], 4)
                acc_d['available'] = acc_d['values'][-1][2]
                acc_d['total_asset'] = acc_d['values'][-1][3]
            res.append(acc_d)

        self.json_response({
            'code': 0,
            'data': res,
        })
        return True
"""


class FutureRiskHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        res = []

        # set field None, means get whole hashmap from redis
        redis_cache_all = get_hash_cache(RedisKeyConstant.redis_future_risk_key.value, None)

        for acc, acc_d in sorted(consts.future_risk_accounts.items(), key=lambda x: x[0]):

            # acc: account id
            # acc_d: account information

            # read account-related data from json file directly
            acc_file = os.path.join(config.media, 'account_cash_risk/%s.json' % acc)
            if os.path.exists(acc_file):
                f = open(acc_file, 'r')
                try:
                    data = json.load(f)
                except Exception as e:
                    data = {
                        'values': []
                    }
                f.close()
            else:
                data = {
                    'values': []
                }

            # fetch extra information from redis server and
            # update acc_d with required fields in redis_cache
            #
            # the English-Chinese mapping is:
            # ex_mar:         交易所保证金
            # ava_able:       可用资金
            # commis:         手续费
            # pos_profit:     持仓盈亏
            # close_profit:   平仓盈亏
            # total_asset:    总权益

            redis_cache = json.loads(redis_cache_all.get(acc) or '{}')
            # Set value to default if data is missing in redis
            default = 0
            acc_d.update({
                "ex_mar": redis_cache.get("ex_mar") or default,
                'ava_able': redis_cache.get("ava_able") or default,
                'commis': redis_cache.get("commis") or default,
                'pos_profit': redis_cache.get("pos_profit") or default,
                'close_profit': redis_cache.get("close_profit") or default
            })

            acc_d['values'] = data['values']
            acc_d['columns'] = ['query_time', 'risk', 'available', 'total_asset']
            acc_d['risk'] = 0
            acc_d['available'] = 0
            acc_d['total_asset'] = acc_d["ava_able"] + redis_cache.get("cur_mar", 0)
            if acc_d['values']:
                acc_d['risk'] = round(acc_d['values'][-1][1], 4)
                acc_d['available'] = acc_d['values'][-1][2]
                # acc_d['total_asset'] = acc_d['values'][-1][3]
            res.append(acc_d)

        self.json_response({
            'code': 0,
            'data': res,
        })
        return True


class VsLiveIdicatorsHandler(JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        pay_load = self.get_payload()

        vs_ids = pay_load.get('vs_ids', [])
        data = []
        if vs_ids:
            vs_ids_str = '_'.join(map(str, sorted(vs_ids)))
            vs_ids_str = gen_str_hash_value(vs_ids_str)
            sc = session()
            inds = sc.query(VsLiveRangePerformance).filter(VsLiveRangePerformance.vs_ids == vs_ids_str).order_by(
                VsLiveRangePerformance.start_date.desc()
            )
            for ind in inds:
                data.append({
                    'key': ind.group_key,
                    'start_date': ind.start_date and ind.start_date.strftime('%Y%m%d') or '',
                    'end_date': ind.end_date and ind.end_date.strftime('%Y%m%d') or '',
                    'sharpe': 'N/A' if abs(float(ind.sharpe)) >= 99999 else float(ind.sharpe),
                    'annual_return': 'N/A' if abs(float(ind.annual_return)) >= 99999 else float(ind.annual_return),
                    'profitrate': 'N/A' if abs(float(ind.profitrate)) >= 99999 else float(ind.profitrate),
                    'max_drawdown_pnl': 'N/A' if abs(float(ind.max_drawdown_pnl)) >= 99999 else float(
                        ind.max_drawdown_pnl),
                })
            sc.close()

        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class GetMyStrategyHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        sc = session()

        node = self.get_argument('node', 'back_test')
        refer = self.request.headers.get('Referer', '')
        if 'strategy/index.html' in refer:
            node = 'back_test'
        elif 'strategy/ev-upload.html' in refer:
            node = 'ev'
        else:
            pass

        status = self.get_argument('status', '')
        is_delete = 0 if str(status).upper() != 'DELETE' else 1
        page = int(self.get_argument('page', 0))
        size = int(self.get_argument('size', 500))
        is_group = self.get_argument('is_portfolio', 'false').lower()

        if is_group == 'true':
            sc.close()
            self.json_response({
                'code': 0,
                'data': [],
                'total': 0,
            })
            return True

        keyword = self.get_argument('keyword', '')

        if self.current_user['is_superuser']:
            if node == 'back_test':
                strategies = sc.query(Strategy).filter(
                    Strategy.node.in_([
                        'back_test', 'order_list', 'trademaster_order_list',
                    ]),
                    Strategy.is_test == 0,
                    Strategy.is_delete == is_delete,
                )
            else:
                strategies = sc.query(Strategy).filter(
                    Strategy.node == node,
                    Strategy.is_test == 0,
                    Strategy.is_delete == is_delete,
                )
        else:
            if node == 'back_test':
                strategies = sc.query(
                    Strategy
                ).filter(
                    Strategy.r_create_user_id == self.current_user['id'],
                    Strategy.node.in_(['back_test', 'order_list', 'trademaster_order_list']),
                    Strategy.is_test == 0,
                    Strategy.is_delete == is_delete,
                )
            else:
                strategies = sc.query(
                    Strategy
                ).filter(
                    Strategy.r_create_user_id == self.current_user['id'],
                    Strategy.node == node,
                    Strategy.is_test == 0,
                    Strategy.is_delete == is_delete,
                )

        if keyword:
            if keyword.isdigit():
                strategies = strategies.filter(
                    or_(
                        Strategy.id == int(keyword),
                        Strategy.id_no.ilike('%%%s%%' % keyword),
                    )
                )
            else:
                strategies = strategies.filter(Strategy.id_no.ilike('%%%s%%' % keyword))
        if is_delete == 1:
            group_ids = self.get_user_group()
            if consts.OPERATION_GROUP in group_ids:
                strategies = sc.query(
                    Strategy,
                ).join(
                    ToBeDeletedStrategy, ToBeDeletedStrategy.strategy_id == Strategy.id
                ).filter(
                    Strategy.is_delete == 1
                )

        strategies = strategies.filter(
            Strategy.is_derive_strategy == False
        )
        total = strategies.count()
        strategies = strategies.order_by(Strategy.id.desc()).offset(page * size).limit(size)

        self.json_response({
            'code': 0,
            'data': [s.to_dict_brief() for s in strategies],
            'total': total,
        })
        sc.close()
        return True


class GetMyStrategyDetailHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        strategy_id = int(kwargs['id'])

        sc = session()

        s = sc.query(Strategy).filter(
            Strategy.id == strategy_id
        ).first()

        if not s:
            self.json_response({
                'code': 1013,
                'error': 'can not find strategy id=%s' % strategy_id
            })
            sc.close()
            return True

        self.json_response({
            'code': 0,
            'data': s.to_dict_brief(),
        })
        sc.close()
        return True


class StrategyBackTestErrorLogHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        strategy_id = int(kwargs['id'])
        sc = session()
        s = sc.query(Strategy).filter(
            Strategy.id == strategy_id
        ).first()

        if not s:
            self.json_response({
                'code': 1013,
                'error': 'can not find strategy id=%s' % strategy_id
            })
            sc.close()
            return True

        log_file = 'strategy/log/simu/strategy_log/{s_id}/{task_uuid}/error.log'.format(s_id=s.id_no,
                                                                                        task_uuid=s.st_uuid or '123123')
        user_path = config.user_nb_dir_template % (s.r_create_user_id, s.username)
        sc.close()

        cmd = "tail -n 120 %s" % os.path.join(user_path, log_file)

        content = subprocess.getoutput(cmd)

        self.json_response({
            'code': 0,
            'data': content,
        })
        sc.close()
        return True


class StockIndicatorsHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        strategy_id = int(kwargs['id'])
        cache_key = 'platform_stock_indicators_%s' % strategy_id
        d = get_cache(cache_key)
        if not d:
            d = StrategyPerformance.update_stock_ind(strategy_id)

        data = copy.deepcopy(tmp_stock_ind)
        data[0]['rows'][0]['daily_stock_number'] = d.get('daily_stock_number', 0)
        data[0]['rows'][0]['liquidity'] = d.get('liquidity', 0)
        data[0]['rows'][0]['withdraw_rate'] = d.get('withdraw_rate', 0)
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class GetStockAlphaStrategyHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        sc = session()
        strategies = sc.query(
            Strategy.id.label('id'),
            Strategy.id_no.label('id_no'),
        ).filter(
            Strategy.node == 'back_test',
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.strategy_type.in_(consts.alpha_stock_strategy_type + consts.hedge_stock_strategy_type)
        ).order_by(Strategy.id.desc())
        data = [
            {
                'id': s.id,
                'id_no': s.id_no,
            } for s in strategies
        ]
        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StrategyPortfolioTradingVolumeRatioHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        s_ids = self.get_argument('s_ids', '')
        if s_ids:
            s_ids = [int(s_id) for s_id in s_ids.split(',') if s_id]
        else:
            s_ids = []

        self.json_response({
            'code': 0,
            'data': StrategyTradingVolumeRatioStatistic.get_portfolio_daily_max_volume_ratio(s_ids)
        })
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        pay_load = self.get_payload()
        s_ids = pay_load.get('s_ids', [])
        gen_portfolio_daily_max_volume_ratio_delay.delay(s_ids)
        self.json_response({
            'code': 0,
            'data': {}
        })
        return True


class StrategyPortfolioDailyTradingVolumeRatioHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        s_ids = self.get_argument('s_ids', '')
        if s_ids:
            s_ids = [int(s_id) for s_id in s_ids.split(',') if s_id]
        else:
            s_ids = []
        trading_date = parse(
            self.get_argument('trading_date', datetime.datetime.now().strftime('%Y%m%d'))
        ).strftime('%Y%m%d')

        self.json_response({
            'code': 0,
            'data': StrategyTradingVolumeRatioStatistic.get_portfolio_daily_max_volume_ratio_detail(s_ids, trading_date)
        })
        return True


class VsBackTestDepCheckHandler(JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_id = int(kwargs['id'])
        limit = int(self.get_argument('limit', 1))
        if not limit:
            limit = 1
        sc = session()
        events = sc.query(VsEventTrack).filter(
            VsEventTrack.vs_id == vs_id,
            VsEventTrack.event == 'VsBackTestDepCheck',
        ).order_by(
            VsEventTrack.id.desc()
        ).limit(limit)
        data = []
        for evt in events:
            d = {
                'trading_date': evt.trading_date.strftime('%Y%m%d'),
                'event': evt.event,
                'done_time': evt.done_time.strftime('%Y%m%d %X'),
                'status': 'SUCCESS' if evt.status == 0 else 'FAILED',
                'detail': evt.detail or {'error': []}
            }
            data.append(d)
        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class VsBackTestLogHandler(JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_id = int(kwargs['id'])
        sc = session()
        s = sc.query(Strategy).join(
            VStrategies, VStrategies.strategy_id == Strategy.id
        ).filter(
            VStrategies.id == vs_id
        ).first()

        if not s:
            self.json_response({
                'code': 1013,
                'error': 'can not find strategy vs_id=%s' % vs_id
            })
            sc.close()
            return True

        log_file = 'strategy/log/simu/strategy_log/{s_id}/v_strategy_id:{task_uuid}/error.log'.format(
            s_id=s.id_no, task_uuid=vs_id
        )
        user_path = config.user_nb_dir_template % (s.r_create_user_id, s.username)
        sc.close()

        log_file_path = os.path.join(user_path, log_file)
        if not os.path.exists(log_file_path):
            content = ''
        else:
            cmd = "tail -n 120 %s" % log_file_path
            content = subprocess.getoutput(cmd)

        self.json_response({
            'code': 0,
            'data': content,
        })
        return True


class StrategyBackTestDepCheckHandler(JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        s_id = int(kwargs['id'])
        limit = int(self.get_argument('limit', 1))
        if not limit:
            limit = 1
        sc = session()
        events = sc.query(StrategyEventTrack).filter(
            StrategyEventTrack.s_id == s_id,
            StrategyEventTrack.event == 'BackTestDepCheck',
        ).order_by(
            StrategyEventTrack.id.desc()
        ).limit(limit)
        data = []
        for evt in events:
            d = {
                'trading_date': evt.trading_date.strftime('%Y%m%d'),
                'event': evt.event,
                'done_time': evt.done_time.strftime('%Y%m%d %X'),
                'status': 'SUCCESS' if evt.status == 0 else 'FAILED',
                'detail': evt.detail or {'error': []}
            }
            data.append(d)
        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class VsBackTestEventTrackingHandler(JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_id = int(kwargs['id'])
        sc = session()
        events = sc.query(VsEventTrack).filter(
            VsEventTrack.vs_id == vs_id,
            VsEventTrack.event.in_(['AutoVsBackTest', 'RedoVsBackTest']),
        ).order_by(
            VsEventTrack.id.desc()
        ).first()
        if not events:
            sc.close()
            self.json_response({
                'code': 0,
                'data': [],
            })
            return True
        max_event_id = events.id
        events = sc.query(VsEventTrack).filter(
            VsEventTrack.vs_id == vs_id,
            VsEventTrack.id >= max_event_id,
        )
        events_msg = {
            'AutoVsBackTest': '开始盘后分析',
            'RedoVsBackTest': '开始盘后分析',
            'PrepareVsTask': '准备任务',
            'VsBackTestDepCheck': '数据检查',
            'SendVsTask': '发送任务',
            'CurrentTradingDateStart': '当前日期开始',
            'CurrentTradingDateEnd': '当前日期完成',
            'VsBackTestFinished': '盘后分析结束',
            'VsBackTestFailed': '盘后分析结束',
        }
        routes = [
            'AutoVsBackTest', 'RedoVsBackTest', 'PrepareVsTask',
            'VsBackTestDepCheck', 'SendVsTask',
            'CurrentTradingDateStart', 'CurrentTradingDateEnd',
            'VsBackTestFinished', 'VsBackTestFailed'
        ]
        vs_events = {}
        for evt in events:
            vs_event = {
                'event': evt.event,
                'done_time': evt.done_time.strftime('%Y%m%d %X'),
                'status': 'SUCCESS' if evt.status == 0 else 'FAILED',
                'detail': evt.detail,
            }

            if evt.event == 'VsBackTestFailed':
                vs_event['status'] = 'FAILED'

            if evt.event == 'VsBackTestDepCheck':
                vs_event['detail'] = evt.detail or {}
                if not vs_event['detail'].get('error'):
                    vs_event['detail'] = None

            if evt.event in ('CurrentTradingDateStart', 'CurrentTradingDateEnd'):
                vs_event['detail'] = {
                    'trading_date': evt.trading_date.strftime('%Y%m%d')
                }

            if evt.event not in vs_events:
                vs_events[evt.event] = vs_event
            elif vs_event['done_time'] > vs_events[evt.event]['done_time']:
                vs_events[evt.event] = vs_event

        if ('CurrentTradingDateEnd' in vs_events) and ('CurrentTradingDateStart' in vs_events) and (
                vs_events['CurrentTradingDateEnd']['detail']['trading_date'] <
                vs_events['CurrentTradingDateStart']['detail']['trading_date']):
            del vs_events['CurrentTradingDateEnd']

        if ('VsBackTestFinished' in vs_events) and ('VsBackTestFailed' in vs_events):
            del vs_events['VsBackTestFinished']

        data = []
        for evt in routes:
            vs_event = vs_events.get(evt)
            if vs_event:
                vs_event['event_msg'] = events_msg.get(evt, evt)
                if evt in ('AutoVsBackTest', 'RedoVsBackTest'):
                    vs_event['event'] = 'VsBackTestStart'

                if evt in ('VsBackTestFailed', 'VsBackTestFinished'):
                    vs_event['event'] = 'VsBackTestDone'
                data.append(vs_event)

        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class SetStrategyDocHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def put(self, *args, **kwargs):
        s_id = int(kwargs['id'])
        self.get_current_user()
        if not self.current_user:
            return False
        payload = self.get_payload()
        doc_link = payload.get('doc_link', '')
        sc = session()
        s = sc.query(Strategy).filter(
            Strategy.id == s_id
        ).first()
        if s:
            s_d = copy.deepcopy(s.detail)
            s_d['doc_link'] = doc_link
            s.detail = s_d
            sc.commit()
        sc.close()
        self.json_response({
            'code': 0,
            'data': {},
        })
        return True


class FutureTradingVolumeRatioHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        there are two modes now:
        1. live mode, always return the latest result <-- when "live" argument is 1
        2. regular mode, find data for certain trading day. If data is not found, send a celery task to calculate it.

        parameters in args
        - trading date: required in case that live live = 0
        - live: 1 represents live mode, 0 otherwise
        - period: default to 15, can be either 15, 30, 45 or 60
        """
        trading_date = parse(self.get_argument('trading_date')).strftime('%Y%m%d')

        live = int(self.get_argument('live', 0))

        period = int(self.get_argument('period', 15))
        file_name = '%s_%s_%s' % (
            trading_date, 'all', period
        )
        csv_file_name = os.path.join(config.media, 'future_mkt_volumn_ratio', '%s.csv' % file_name)
        data = {
            'ratio': {
                'columns': [],
                'values': [],
            },
            'time_period': get_time_range(period),
        }

        # prepare data based on csv file
        def delicate_data(data_, csv_file_name_):
            columns = ['symbol'] + sorted(data_['time_period'].keys())
            df = pd.read_csv(csv_file_name_)
            sym_data = {}
            for i, row in df.iterrows():
                if row['symbol'] not in sym_data:
                    v = [row['symbol']] + [0] * len(data_['time_period'])
                    sym_data[row['symbol']] = v
                else:
                    v = sym_data[row['symbol']]
                v[row['time_range']] = row['volumn_ratio']
            data_['ratio']['columns'] = columns
            data_['ratio']['values'] = sorted(sym_data.values(), key=lambda x: x[0])
            data_['trading_date'] = split("_|/", csv_file_name_)[-3]
            data_['latest_modified_time'] = datetime.datetime. \
                fromtimestamp(os.path.getmtime(csv_file_name_)).strftime('%Y-%m-%d, %H:%m')

        if os.path.exists(csv_file_name):
            delicate_data(data, csv_file_name)
        else:
            if live == 1:
                # live mode
                # find the latest created csv file
                csv_dir_name = os.path.join(config.media, 'future_mkt_volumn_ratio', "*{}.csv".format(period))
                paths = glob(csv_dir_name)
                paths.sort(key=os.path.getctime)
                if paths:
                    latest_csv = paths[-1]
                    delicate_data(data, latest_csv)

            generate_future_mkt_volume_ratio_delay.delay(
                trading_date, period
            )
        self.json_response({
            'code': APIResponseCode.OK.value,
            'data': data
        })
        return True


class GetStockMasterStrategyHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        sc = session()
        strategies = sc.query(
            Strategy.id.label('id'),
            Strategy.id_no.label('id_no'),
        ).filter(
            Strategy.node == 'back_test',
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.strategy_type.in_(['32'])
        ).order_by(Strategy.id.desc())
        data = [
            {
                'id': s.id,
                'id_no': s.id_no,
            } for s in strategies
        ]
        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        pay_load = self.get_payload()
        s_id = pay_load['master_s_id']
        sc = session()
        s = sc.query(
            Strategy
        ).filter(
            Strategy.id == s_id
        ).first()

        r_create_time = datetime.datetime.now()

        id_no = Strategy.generate_id_no(
            s.r_create_user_id, '33', r_create_time.strftime('%Y-%m-%d')
        )
        detail = copy.deepcopy(s.detail)
        detail['start'] = parse(pay_load['start']).strftime('%Y%m%d')
        detail['trade_model'] = str(pay_load['trade_model'])
        detail['initial_cash'] = float(pay_load.get('initial_cash', 0))
        detail['se_cash'] = float(pay_load.get('se_cash', 0) or 0)
        detail['se_cash_rate'] = float(pay_load.get('se_cash_rate', 0) or 0)
        detail['accounts'] = pay_load.get('accounts', {})
        if detail['accounts']:
            initial_cash = 0
            for _, a_d in detail['accounts'].items():
                initial_cash += a_d['cash']
            detail['initial_cash'] = initial_cash

        detail['vwap_version'] = pay_load.get('vwap_version', '')
        detail['portfolio_optimization_so_version'] = pay_load.get('portfolio_optimization_so_version', '')
        detail['name'] = pay_load.get('name', s.name) or s.name
        detail['desc'] = s.description
        detail['income_attribution_base_s_id'] = pay_load.get('income_attribution_base_s_id', 0)

        if (s.strategy_type in consts.t0_stock_strategy_type) and pay_load.get('alpha_s_id'):
            detail['alpha_s_id'] = pay_load['alpha_s_id']

        detail['predict_s_ids'] = pay_load['predict_s_ids']
        products = copy.deepcopy(s.products)
        old_products = [p['symbol'] for p in products[0]]
        for p_id in detail['predict_s_ids']:
            f_id_sym = 'stock_factor_%s_ALL' % p_id
            if f_id_sym in old_products:
                continue
            products[0].append({
                'exch': 'SSE',
                'name': 'ALL',
                'rank': [],
                'type': 'stock_factor_FACTOR',
                'symbol': f_id_sym,
            })

        detail['products'] = products
        detail['strategy_type'] = '33'
        detail['hedge'] = 'ZZ500'
        detail['hedge_type'] = 'full'

        new_s = Strategy(
            # r_create_time=r_create_time.strftime('%Y%m%d'),
            r_create_time=r_create_time,
            r_create_user_id=s.r_create_user_id,
            r_update_user_id=s.r_update_user_id,
            username=s.username,
            name=detail['name'],
            status=consts.TASK_RUNNING,
            description=detail['desc'],
            node=s.node,
            start_date=detail['start'],
            end_date=s.end_date,
            day_night=s.day_night,
            products=products,
            max_pos=s.max_pos,
            dependency=s.dependency,
            detail=detail,
            st_uuid=uuid.uuid1().hex,
            strategy_type=detail['strategy_type'],
            strategy_feature=s.strategy_feature,
            strategy_underlying=s.strategy_underlying,
            strategy_para_type=s.strategy_para_type,
            strategy_status='BT',
            id_no=id_no,
            code=id_no[-3:],
            is_test=0,
            strategy_upload_file_id=s.strategy_upload_file_id,
            hedge=detail['hedge'],
            hedge_type=detail['hedge_type'],
            # paper_trading_date=r_create_time.strftime('%Y%m%d'),
            paper_trading_date=r_create_time,
            confidence=1,
            task_progress=0,
            group_id=s.group_id,
            group_detail=s.group_detail,
            is_derive_strategy=False,
        )
        sc.add(new_s)
        sc.commit()

        strategy_owner = StrategyOwners(
            strategy_id=new_s.id,
            owner_id=new_s.r_create_user_id,
            r_create_user_id=new_s.r_create_user_id,
        )
        sc.add(strategy_owner)
        sc.commit()

        if detail['income_attribution_base_s_id']:
            StrategyIncomeAttributionAdjusted.set_pair(new_s.id, detail['income_attribution_base_s_id'])

        start_strategy_task.delay(new_s.id)
        Strategy.add_strategy_event(
            new_s.id,
            s.start_date,
            0,
            'AddStrategyBackTest',
            task_id=new_s.st_uuid,
        )

        l = AnalysisStrategyList(
            key='stock',
            strategy_id=new_s.id,
            r_create_user_id=self.current_user['id'],
        )

        sc.add(l)
        sc.commit()

        new_s_id = new_s.id

        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'id': new_s_id,
            },
        })
        return True


class UnionSimuStrategyHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def delete(self, *args, **kwargs):
        sc = session()
        try:
            st_id = int(kwargs['id'])
            # 如果是联合模拟策略，那么删除策略机器子策略，联合模拟只能通过母策略来删除
            st = sc.query(Strategy).filter(Strategy.id == st_id,
                                           Strategy.node == "union_simu").first()
            if not st:
                self.write({
                    'code': -1,
                    'error': "联合策略 %s 未找到" % st_id
                })
                return
            sub_st_ids = st.detail.get("sub_sts", None)
            if sub_st_ids:
                # 删除子策略
                sub_sts = sc.query(Strategy).filter(Strategy.id.in_(sub_st_ids), Strategy.is_derive_strategy == 1)
                for sub_st in sub_sts:
                    sub_st.is_delete = 1
            st.is_delete = 1
            sc.commit()
            self.write({
                'code': 0,
                'data': "策略删除成功"
            })
        except:  # noqa
            sentry.captureException()
            self.write({
                'code': -1,
                'error': "删除联合模拟策略，服务器内部错误"
            })
        finally:
            sc.close()

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        pay_load = self.get_payload()
        us_s_ids = pay_load['union_s_ids']
        # 从前端获取各策略的资金分配比例，数列与 union_s_ids 一一对应
        cash_rate = pay_load.get('cash_rate', [])
        new_union_s_ids = []

        # 目前这种模式仅支持一对一的 alpha & t0 的自动订阅
        new_sub_st_t0_ids = []
        new_sub_st_alpha_ids = []

        day_night = -1

        # 联合回测时设定的总资金
        union_initial_cash_sum = int(pay_load.get('initial_cash', 0))

        # 资金分配比例
        orig_stra_weight = {}

        # 如果联合回测没有设置资金分配比例，没有业务意义，结束
        if not cash_rate:
            self.json_response({
                'code': 0,
                'error': "没有设置资金分配比例"
            })
            return False
        else:
            orig_initial_cash_sum = sum(cash_rate)
            for index, s_id in enumerate(us_s_ids):
                orig_stra_weight[s_id] = cash_rate[index] / orig_initial_cash_sum

        orig_stra_new_initial_cash = split_initial_cash(union_initial_cash_sum, orig_stra_weight)

        union_stra_weight = {}

        r_create_time = datetime.datetime.now()
        start = parse(pay_load['start']).strftime('%Y%m%d')
        sc = session()

        for s_id in us_s_ids:
            s = sc.query(
                Strategy
            ).filter(
                Strategy.id == s_id
            ).first()

            # 这里 copy 的子策略的 id_no 使用的日期是被 copy 的子策略创建的日期
            id_no = Strategy.generate_id_no(
                s.r_create_user_id, s.strategy_type or '99', r_create_time.strftime('%Y-%m-%d')
            )

            detail = copy.deepcopy(s.detail)
            detail['start'] = start
            detail['trade_model'] = str(pay_load['trade_model'])
            detail['initial_cash'] = orig_stra_new_initial_cash[s_id]
            detail['se_cash'] = float(pay_load.get('se_cash', 0) or 0)
            detail['se_cash_rate'] = float(pay_load.get('se_cash_rate', 0) or 0)
            detail['accounts'] = pay_load.get('accounts', {})
            detail['vwap_version'] = pay_load.get('vwap_version', '')
            detail['portfolio_optimization_so_version'] = pay_load.get('portfolio_optimization_so_version', '')
            detail['name'] = s.name
            # 标记这是子策略
            detail['is_union'] = 1
            detail['desc'] = s.description + '(clone_from_%s)' % s.id
            detail['income_attribution_base_s_id'] = pay_load.get('income_attribution_base_s_id', 0)

            if (s.strategy_type in consts.t0_stock_strategy_type) and pay_load.get('alpha_s_id'):
                # 订阅的 alpha 策略 id 得更新，否则计算 T0 的收益计算是错的，这里先做个简单的自动更新
                detail['alpha_s_id'] = pay_load['alpha_s_id']

            new_s = Strategy(
                r_create_time=r_create_time.strftime('%Y%m%d'),  # 被copy的子策略的创建时间为创建联合策略的日期
                r_create_user_id=s.r_create_user_id,
                r_update_user_id=s.r_update_user_id,
                username=s.username,
                name=detail['name'],
                status=consts.TASK_STOPPED,
                description=detail['desc'],
                node='union_simu',
                start_date=detail['start'],  # 暂时保持一致，后续会更新
                end_date=s.end_date,
                day_night=s.day_night,
                products=s.products,
                max_pos=s.max_pos,
                dependency=s.dependency,
                detail=detail,
                st_uuid=uuid.uuid1().hex,
                strategy_type=s.strategy_type,
                strategy_feature=s.strategy_feature,
                strategy_underlying=s.strategy_underlying,
                strategy_para_type=s.strategy_para_type,
                strategy_status='BT',
                id_no=id_no,
                code=id_no[-3:],
                is_test=0,
                strategy_upload_file_id=s.strategy_upload_file_id,
                hedge=s.hedge,
                hedge_type=s.hedge_type,
                paper_trading_date=r_create_time.strftime('%Y%m%d'),
                confidence=1,
                task_progress=0,
                group_id=s.group_id,
                group_detail=s.group_detail,
                is_derive_strategy=True,
            )
            sc.add(new_s)
            sc.commit()

            new_union_s_ids.append(new_s.id)
            if s.strategy_type in consts.t0_stock_strategy_type:
                new_sub_st_t0_ids.append(new_s.id)
            elif s.strategy_type in consts.alpha_stock_strategy_type:
                new_sub_st_alpha_ids.append(new_s.id)

            union_stra_weight[new_s.id] = orig_stra_weight[s_id]
            if day_night == -1:
                day_night = s.day_night
            elif day_night != s.day_night:
                day_night = 2

            strategy_owner = StrategyOwners(
                strategy_id=new_s.id,
                owner_id=new_s.r_create_user_id,
                r_create_user_id=new_s.r_create_user_id,
            )
            sc.add(strategy_owner)
            sc.commit()

            # factor_s = MutilFactorStrategy(
            #     r_create_user_id=self.current_user['id'],
            #     strategy_id=s.id,
            #     factor_strategy_id=new_s.id,
            # )
            # sc.add(factor_s)
            # sc.commit()

            if detail['income_attribution_base_s_id']:
                StrategyIncomeAttributionAdjusted.set_pair(new_s.id, detail['income_attribution_base_s_id'])

        # 仅支持一对一的T0 & alpha策略的自动关联
        if len(new_sub_st_alpha_ids) == 1 and len(new_sub_st_t0_ids) == 1:
            rs = sc.query(Strategy).filter(Strategy.id == new_sub_st_t0_ids[0]).first()
            if rs:
                _detail = dict(rs.detail)
                _detail['alpha_s_id'] = new_sub_st_alpha_ids[0]
                rs.detail = _detail
                sc.commit()

        id_no = Strategy.generate_id_no(
            self.current_user['id'], '34', r_create_time.strftime('%Y-%m-%d')
        )

        # 组合策略无需用到单一子策略的信息，它仅用于关联联合模拟结果的绩效
        detail = {
            'sub_sts': new_union_s_ids,
            'start': start,
            'trade_model': str(pay_load['trade_model']),
            'initial_cash': union_initial_cash_sum,
            'se_cash': float(pay_load.get('se_cash', 0) or 0),
            'se_cash_rate': float(pay_load.get('se_cash_rate', 0) or 0),
            'accounts': pay_load.get('accounts', {}),
            'vwap_version': pay_load.get('vwap_version', ''),
            'portfolio_optimization_so_version': pay_load.get('portfolio_optimization_so_version', ''),
            'name': pay_load.get('name', ''),
            'desc': 'union simulation strategy',
            'income_attribution_base_s_id': pay_load.get('income_attribution_base_s_id', 0),
            'strategy_type': '34',
            'union_stra_weight': union_stra_weight,
        }

        union_s = Strategy(
            r_create_time=r_create_time.strftime('%Y%m%d'),
            r_create_user_id=self.current_user['id'],
            r_update_user_id=self.current_user['id'],
            username=self.current_user['username'],
            name=detail['name'],
            status=consts.TASK_RUNNING,
            description=detail['desc'],
            node='union_simu',
            start_date=detail['start'],
            end_date='20500101',
            day_night=day_night,
            products=[[]],
            detail=detail,
            st_uuid=uuid.uuid1().hex,
            strategy_type=detail['strategy_type'],
            strategy_status='BT',
            id_no=id_no,
            code=id_no[-3:],
            is_test=0,
            strategy_upload_file_id=-1,
            # hedge=detail['hedge'],
            # hedge_type=detail['hedge_type'],
            paper_trading_date=r_create_time.strftime('%Y%m%d'),
            confidence=1,
            task_progress=0,
            is_derive_strategy=False,
        )
        sc.add(union_s)
        sc.commit()

        strategy_owner = StrategyOwners(
            strategy_id=union_s.id,
            owner_id=union_s.r_create_user_id,
            r_create_user_id=union_s.r_create_user_id,
        )
        sc.add(strategy_owner)
        sc.commit()

        for s_id in new_union_s_ids:
            relation = UnionSimuStrategyRelation(
                main_s_id=union_s.id,
                link_s_id=s_id
            )
            sc.add(relation)
        sc.commit()

        # if detail['income_attribution_base_s_id']:
        #     StrategyIncomeAttributionAdjusted.set_pair(union_s.id, detail['income_attribution_base_s_id'])

        # 开始回测任务
        start_strategy_task.delay(union_s.id)
        Strategy.add_strategy_event(
            union_s.id,
            union_s.start_date,
            0,
            'AddStrategyBackTest',
            task_id=union_s.st_uuid,
        )

        l = AnalysisStrategyList(
            key='stock',
            strategy_id=union_s.id,
            r_create_user_id=self.current_user['id'],
        )
        sc.add(l)
        sc.commit()

        union_s_id = union_s.id
        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'id': union_s_id,
            },
        })
        return True


class UnionSimuStrategyPerformancenHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        union_s_id = int(kwargs['id'])
        sc = session()
        try:
            s = sc.query(Strategy).filter(Strategy.id == union_s_id).first()
            if s.strategy_type != '34':
                self.json_response({'code': 0, 'data': {}, })
                return True

            s_ids = list(s.detail.get('union_stra_weight', {}).keys())
            if not s_ids:
                self.json_response({'code': 0, 'data': {}})
                return True

            # 子策略内容
            sub_sts_inst = sc.query(Strategy).filter(Strategy.id.in_(s_ids)).all()
            sub_st_dict = {}
            for _st in sub_sts_inst:
                sub_st_dict[_st.id] = _st

            # 绩效汇总
            s_ids.append(union_s_id)
            performances = sc.query(
                StrategyBackTestResultPerformance.strategy_id.label('strategy_id'),
                StrategyBackTestResultPerformance.key.label('key'),
                StrategyBackTestResultPerformance.sharpe.label('sharpe'),
                StrategyBackTestResultPerformance.annual_return.label('annual_return'),
                StrategyBackTestResultPerformance.max_drawdown_pnl.label('max_drawdown_pnl'),
                StrategyBackTestResultPerformance.pt_days.label('pt_days'),
            ).filter(
                StrategyBackTestResultPerformance.strategy_id.in_(s_ids),
                StrategyBackTestResultPerformance.key.in_(['whole_back_test'])
            )
            perf_dict = {}
            for p in performances:
                perf_dict[p.strategy_id] = p
            rows = []
            summary = {}
            data = {'rows': rows, 'summary': summary}
            for st_id in s_ids:
                st_id = int(st_id)
                annual_return = 'N/A'
                sharpe = 'N/A'
                max_drawdown = 'N/A'
                p = perf_dict.get(st_id, None)
                if p:
                    annual_return = 'N/A' if abs(float(p.annual_return)) >= 99999 else float(p.annual_return)
                    sharpe = 'N/A' if abs(float(p.sharpe)) >= 99999 else float(p.sharpe)
                    max_drawdown = 'N/A' if abs(float(p.max_drawdown_pnl)) >= 99999 else float(p.max_drawdown_pnl)
                if st_id == union_s_id:
                    # 策略组合结果
                    summary.update({
                        "confidence": s.confidence,
                        "hedge": "",
                        "hedge_type": "",
                        "id": s.id,
                        "id_no": s.id_no,
                        "initial_cash": s.detail.get('initial_cash', 0),
                        "is_single_interest": s.detail.get('single_interest', True),
                        "market_volume": "N/A",
                        "name": s.name,
                        "node": s.node,
                        "paper_trading_date": s.paper_trading_date,
                        "pnl_url": "/media/strategy_pnl_graph/strategy_%s_0_thumbnail.png" % s.id,
                        "start_date": s.start_date,
                        "strategy_type": s.strategy_type,
                        "annual_return": annual_return,
                        "sharpe": sharpe,
                        "max_drawdown": max_drawdown,
                        "max_drawdown_pnl": max_drawdown,
                    })
                else:
                    # 子策略结果
                    _st = sub_st_dict[st_id]
                    rows.append({
                        "confidence": _st.confidence,
                        "hedge": _st.hedge,
                        "hedge_type": _st.hedge_type,
                        "id": _st.id,
                        "id_no": _st.id_no,
                        "initial_cash": _st.detail.get('initial_cash', 0),
                        "is_single_interest": _st.detail.get('single_interest', True),
                        "market_volume": "N/A",
                        "name": _st.name,
                        "node": _st.node,
                        "paper_trading_date": _st.paper_trading_date,
                        "pnl_url": "/media/strategy_pnl_graph/strategy_%s_0_%sthumbnail.png" %
                                   (_st.id, 'hedge_' if _st.hedge else ''),
                        "start_date": _st.start_date,
                        "strategy_type": _st.strategy_type,
                        "annual_return": annual_return,
                        "sharpe": sharpe,
                        "max_drawdown": max_drawdown,
                        "max_drawdown_pnl": max_drawdown,
                    })

            self.json_response({
                'code': 0,
                'data': data,
            })
        except:  # noqa
            sentry.captureException()
            self.json_response({
                'code': -1,
                'data': "服务器内部错误"
            })
        finally:
            sc.close()

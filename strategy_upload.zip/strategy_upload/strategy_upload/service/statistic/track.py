# -*-coding:utf-8-*-

import re
import random
import copy
import json
import requests
import datetime
from dateutil.parser import parse
from sqlalchemy import or_, and_, func
from tornado import gen
from tornado import httpclient
from service.back_test.models import Strategy, VStrategies, StrategyPortfolio, TradeLogs, TuringTradeLogs, \
    VStrategyAccountDetail, StrategyPerfInput, ParentOrder, ChildrenOrder, SettlementManualTradelog, \
    StrategyOrdersRejected, VsAccount, TuringLiveAccounts, TuringPositionLogs, SymbolMargin, DIMPreConfs
from service.back_test.live_position_models import VsBase, VsPosition

from service.statistic.baseservice import ServiceBaseService
from utils import get_cache, set_cache
from kdb_query import KdbQuery
from extensions import sentry
from db import session
from config import config
import consts


def track_filter_data(current_user, group_type, **kwargs):
    if not group_type in ['provider_strategy', 'provider_account', 'investment_strategy', 'investment_account']:
        return {
            'filter': []
        }
    history = kwargs.get('history', False)
    stock_data = kwargs.get('stock_data', False)
    future_data = kwargs.get('future_data', False)

    is_stock_group = kwargs.get('is_stock_group', False)
    is_stock_page = kwargs.get('is_stock_page', False)
    is_future_group = kwargs.get('is_future_group', False)
    is_future_page = kwargs.get('is_future_page', False)

    if history:
        cache_key = 'platform_track_filter_history_%s_%s_%s_%s' % (
            current_user['id'], group_type, stock_data, future_data)
    else:
        cache_key = 'platform_track_filter_%s_%s_%s_%s' % (current_user['id'], group_type, stock_data, future_data)

    cache_data = get_cache(cache_key)
    if cache_data:
        return cache_data

    sp_create_user_ids = [current_user['id']]

    business = ''
    if stock_data:
        # sp_create_user_ids.append(consts.stock_user['id'])
        business = 'stock'

    if future_data:
        # sp_create_user_ids.append(consts.future_user['id'])
        business = 'future'

    sc = session()
    live_strategies = sc.query(
        VStrategies.id.label('vs_id'), Strategy.id_no.label('id_no'), Strategy.id.label('s_id'),
        StrategyPortfolio.name.label('portfolio_name'), VStrategies.symbols_accounts_detail.label('symbols_accounts'),
        StrategyPortfolio.live_time.label('live_time'), StrategyPortfolio.r_create_time.label('sp_create_time'),
    ).join(
        Strategy, or_(
            and_(
                Strategy.id == VStrategies.strategy_id,
                VStrategies.group_id == 0
            ),
            Strategy.id == VStrategies.group_id
        )
    ).join(
        StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
    ).filter(
        StrategyPortfolio.source == 'platform',
        VStrategies.source == 'platform',
    )
    if history:
        live_strategies = live_strategies.filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            StrategyPortfolio.status >= consts.STRATEGY_LIVE,
        )
    else:
        live_strategies = live_strategies.filter(
            VStrategies.status == consts.STRATEGY_LIVE,
            StrategyPortfolio.status == consts.STRATEGY_LIVE,
        )

    if not current_user['is_superuser'] and \
            not any([_g in consts.LIVE_PERMISSION_GROUP for _g in current_user.get('group_ids', [])]):
        if group_type in ['provider_strategy', 'provider_account']:
            live_strategies = live_strategies.filter(
                Strategy.r_create_user_id == current_user['id']
            )
        elif group_type in ['investment_strategy', 'investment_account']:
            if not business:
                if is_stock_page:
                    live_strategies = live_strategies.filter(
                        StrategyPortfolio.business == 'stock',
                        Strategy.r_create_user_id == current_user['id']
                    )

                elif is_future_page:
                    live_strategies = live_strategies.filter(
                        StrategyPortfolio.business == 'future',
                        Strategy.r_create_user_id == current_user['id']
                    )
                else:
                    live_strategies = live_strategies.filter(
                        StrategyPortfolio.r_create_user_id.in_(sp_create_user_ids)
                    )
            else:
                live_strategies = live_strategies.filter(
                    StrategyPortfolio.business == business
                )
        else:
            return {
                'filter': []
            }
    columns = ['portfolio_name', 'strategy_id', 'account']
    portfolio_name_index, strategy_index, account_index = 0, 1, 2
    key_index = {
        'provider_strategy': {
            'parent_key': strategy_index,
            'children_key': account_index,
        },
        'provider_account': {
            'parent_key': account_index,
            'children_key': strategy_index,
        },
        'investment_strategy': {
            'parent_key': portfolio_name_index,
            'children_key': strategy_index,
        },
        'investment_account': {
            'parent_key': account_index,
            'children_key': strategy_index,
        },
    }

    filter_data, parent_key, children_key = {}, key_index[group_type]['parent_key'], key_index[group_type][
        'children_key']
    s_live_times = {}
    now = datetime.datetime.now().strftime('%Y%m%d')
    for l in live_strategies:
        vs_accounts = set([a['account'] for a in VStrategies.normalization_symbols_accounts(l.symbols_accounts)])
        for a in vs_accounts:
            v = [l.portfolio_name, l.id_no, a]
            if v[parent_key] not in filter_data:
                filter_data[v[parent_key]] = set()
            filter_data[v[parent_key]].add(v[children_key])
        s_live_times[l.id_no] = min(
            s_live_times.get(l.id_no, now),
            (l.live_time or l.sp_create_time).strftime('%Y%m%d')
        )

    filter_data = [
        {
            'name': parent,
            'children': [
                {
                    'name': c,
                    'live_time': s_live_times.get(c, now)
                } for c in children
            ]
        } for parent, children in sorted(filter_data.items(), key=lambda _d: _d[0])
    ]

    res = {
        'filter': filter_data
    }
    set_cache(cache_key, res, 300)
    return res


class StrategyTrackService(ServiceBaseService):

    def __init__(self, strategy_instance=None, s_id=None, id_no=None, **kwargs):
        self.strategy = strategy_instance
        self.sc = session()
        self.id_no = id_no
        self.portfolio_name = kwargs.get('portfolio_name', '')
        self.kwargs = kwargs
        self._basic_data = None
        super(StrategyTrackService, self).__init__()

    def __del__(self):
        self.sc.close()
        self.kdb.release()

    def track_basic_data(self):

        live_strategies = self.sc.query(
            VStrategies.id.label('vs_id'),
            Strategy.id_no.label('id_no'),
            Strategy.id.label('s_id'),
            StrategyPortfolio.name.label('portfolio_name'),
            Strategy.strategy_type.label('s_type'),
            Strategy.group_id.label('group_id'),
            Strategy.node.label('node'),
            VStrategies.symbols_accounts_detail.label('symbols_accounts')
        ).join(
            Strategy, or_(
                and_(
                    Strategy.id == VStrategies.strategy_id, VStrategies.group_id == 0
                ),
                Strategy.id == VStrategies.group_id
            )
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            VStrategies.status == consts.STRATEGY_LIVE,
            StrategyPortfolio.status == consts.STRATEGY_LIVE,
            StrategyPortfolio.source == 'platform',
            VStrategies.source == 'platform',
            Strategy.id_no == self.id_no,
        )
        if self.portfolio_name:
            live_strategies = live_strategies.filter(StrategyPortfolio.name == self.portfolio_name)

        strategy_detail, vs_detail, accounts, = {}, {}, []
        for s in live_strategies:
            if s.vs_id not in vs_detail:
                acc_currency = {
                    _acc_d['account']: consts.FOREGIN_ACCOUNT.get(_acc_d['account']) or _acc_d.get('currency',
                                                                                                   'CNY') or 'CNY'
                    for _acc_d in VStrategies.normalization_symbols_accounts(s.symbols_accounts)
                }
                vs_detail[s.vs_id] = {
                    'id': s.vs_id,
                    'strategy_type': s.s_type,
                    'accounts': list(set(acc_currency.keys())),
                    'group_name': s.portfolio_name,
                    'portfolio_name': s.portfolio_name,
                    'accounts_currency': acc_currency,
                }
                vs_detail[s.vs_id]['accounts_currency']['20052121'] = 'CNY'
                accounts.extend(vs_detail[s.vs_id]['accounts'])
            if not strategy_detail:
                strategy_detail = {
                    's_id': s.s_id,
                    'strategy_type': s.s_type,
                    'group_id': s.group_id,
                    'node': s.node,
                    'id_no': s.id_no,
                }

        vs_ids = list(vs_detail.keys())
        for vs_id_s in self.sc.query(
                Strategy.id_no.label('id_no'),
                VStrategies.id.label('vs_id'),
        ).join(
            VStrategies, VStrategies.strategy_id == Strategy.id
        ).filter(
            VStrategies.id.in_(vs_ids)
        ):
            vs_detail[vs_id_s.vs_id]['id_no'] = vs_id_s.id_no

        invest_funds = self.sc.query(
            VStrategyAccountDetail.vstrategy_id.label('vstrategy_id'),
            VStrategyAccountDetail.account.label('account'),
            func.sum(VStrategyAccountDetail.amount).label('amount')
        ).filter(
            VStrategyAccountDetail.vstrategy_id.in_(vs_ids),
            VStrategyAccountDetail.account.in_(accounts)
        ).group_by(VStrategyAccountDetail.vstrategy_id, VStrategyAccountDetail.account)

        invest_funds = {'%s|%s' % (r.vstrategy_id, r.account): float(r.amount) for r in invest_funds}

        trading_date, day_night = StrategyPerfInput.get_trading_date_day_night()
        pre_date_dict = self.kdb.get_nebor_trading_date(trading_date)

        pre_date = pre_date_dict['prev']

        trading_date = parse(trading_date)
        trading_date_str = trading_date.strftime('%Y-%m-%d')

        parent_orders = self.sc.query(ParentOrder).filter(
            ParentOrder.vstrategy_id.in_(vs_ids),
            ParentOrder.trading_date == trading_date_str,
        )
        parent_logs, parent_order_ids = {}, []
        for po in parent_orders:
            po_brief = po.brief()
            po_brief['strategy_id'] = self.id_no
            po_brief['s_id'] = strategy_detail['s_id']
            po_brief['id_no'] = vs_detail[po_brief['vstrategy_id']]['id_no']
            po_brief['strategy_type'] = vs_detail[po_brief['vstrategy_id']]['strategy_type']
            po_brief['group_name'] = vs_detail[po_brief['vstrategy_id']]['portfolio_name']
            po_brief['portfolio_name'] = vs_detail[po_brief['vstrategy_id']]['portfolio_name']
            parent_order_ids.append(po_brief['parent_order_id'])
            po_brief['parent_order_id'] = ''.join([
                {0: '2', 1: '1'}.get(po_brief['day_night'], 'X'), po_brief['parent_order_id']
            ])
            po_brief['parent_serial_no'] = po_brief['parent_order_id']
            po_brief['serial_no'] = po_brief['parent_order_id']
            parent_logs[po_brief['parent_order_id']] = po_brief

        children_orders = []
        if parent_order_ids:
            children_orders = self.sc.query(ChildrenOrder).filter(
                ChildrenOrder.vstrategy_id.in_(vs_ids),
                ChildrenOrder.trading_date == trading_date_str,
                ChildrenOrder.parent_order_id.in_(parent_order_ids),
            )

        children_logs, children_order_ids, children_serial_no = {}, [], []
        for co in children_orders:
            co_brief = co.brief()
            co_brief['strategy_id'] = self.id_no
            co_brief['s_id'] = strategy_detail['s_id']
            co_brief['id_no'] = vs_detail[co_brief['vstrategy_id']]['id_no']
            co_brief['strategy_type'] = vs_detail[co_brief['vstrategy_id']]['strategy_type']
            co_brief['group_name'] = vs_detail[co_brief['vstrategy_id']]['portfolio_name']
            co_brief['portfolio_name'] = vs_detail[co_brief['vstrategy_id']]['portfolio_name']
            children_order_ids.append(co_brief['child_order_id'])
            co_brief['child_order_id'] = ''.join(
                [{0: '2', 1: '1'}.get(co_brief['day_night'], 'X'), co_brief['child_order_id']]
            )
            co_brief['parent_order_id'] = ''.join(
                [{0: '2', 1: '1'}.get(co_brief['day_night'], 'X'), co_brief['parent_order_id']]
            )
            co_brief['serial_no'] = co_brief['child_order_id']
            co_brief['parent_serial_no'] = co_brief['parent_order_id']
            children_logs[co_brief['child_order_id']] = co_brief
            children_serial_no.append(co_brief['child_order_id'])

        trade_logs_query = self.sc.query(TradeLogs).filter(
            TradeLogs.trading_date == trading_date_str,
            TradeLogs.vstrategy_id.in_(vs_ids),
            TradeLogs.log_type.in_(['2', '3']),
        ).order_by(TradeLogs.calendar_date, TradeLogs.calendar_time, TradeLogs.calendar_microsec)

        trade_logs_send = self.sc.query(
            TradeLogs.serial_no,
            TradeLogs.calendar_time,
            TradeLogs.calendar_microsec,
            TradeLogs.day_night,
            TradeLogs.calendar_date,
        ).filter(
            TradeLogs.trading_date == trading_date_str,
            TradeLogs.vstrategy_id.in_(vs_ids),
            TradeLogs.log_type == '0',
        ).order_by(TradeLogs.calendar_date, TradeLogs.calendar_time, TradeLogs.calendar_microsec)
        trade_logs_send_time = {(r[0], r[3]): '%s %s.%s' % (r[4].strftime('%Y%m%d'), str(r[1]), str(r[2] or 0).zfill(6))
                                for r in trade_logs_send}

        symbol_trade_detail = {}

        trade_logs = []
        serial_no2accounts = {}
        for l in trade_logs_query:
            if l.log_type == '3' and l.entrust_status not in ('p', 'c'):
                continue

            l = l.brief()
            serial_no2accounts[l['serial_no']] = l['account']
            l['send_time'] = trade_logs_send_time.get((l['serial_no'], l['day_night']), l['send_time'])
            l['serial_no'] = ''.join([{0: '2', 1: '1'}.get(l['day_night'], 'X'), l['serial_no']])
            l['id_no'] = vs_detail[l['vstrategy_id']]['id_no']
            l['strategy_type'] = vs_detail[l['vstrategy_id']]['strategy_type']
            l['group_name'] = vs_detail[l['vstrategy_id']]['portfolio_name']
            l['portfolio_name'] = vs_detail[l['vstrategy_id']]['portfolio_name']
            l['strategy_id'] = self.id_no
            l['s_id'] = strategy_detail['s_id']
            trade_logs.append(l)

        manual_tradelogs = self.sc.query(SettlementManualTradelog).filter(
            SettlementManualTradelog.trading_date == trading_date_str,
            SettlementManualTradelog.vstrategy_id.in_(vs_ids),
        )
        for m_l in manual_tradelogs:
            m_l_breif = m_l.brief()
            m_l_breif['id_no'] = vs_detail[m_l_breif['vstrategy_id']]['id_no']
            m_l_breif['strategy_type'] = vs_detail[m_l_breif['vstrategy_id']]['strategy_type']
            m_l_breif['group_name'] = vs_detail[m_l_breif['vstrategy_id']]['portfolio_name']
            m_l_breif['portfolio_name'] = vs_detail[m_l_breif['vstrategy_id']]['portfolio_name']
            m_l_breif['strategy_id'] = self.id_no
            m_l_breif['s_id'] = strategy_detail['s_id']
            if m_l_breif['valid']:
                trade_logs.append(m_l_breif)

        orders_rejected = []
        strat_orders_rejected = self.sc.query(StrategyOrdersRejected).filter(
            StrategyOrdersRejected.vstrategy_id.in_(vs_ids),
            StrategyOrdersRejected.trading_date == trading_date_str,
        ).order_by(StrategyOrdersRejected.id.desc()).limit(800)
        for sor in strat_orders_rejected:
            sor = sor.to_dict()
            orders_rejected.append({
                'portfolio_name': vs_detail[sor['vstrategy_id']]['portfolio_name'],
                'group_name': vs_detail[sor['vstrategy_id']]['portfolio_name'],
                's_id': strategy_detail['s_id'],
                'strategy_id': self.id_no,
                'vstrategy_id': sor['vstrategy_id'],
                'id_no': vs_detail[sor['vstrategy_id']]['id_no'],
                'account': serial_no2accounts.get(sor['serial_no'], ''),
                'serial_no': sor['serial_no'],
                'cancel_serial_no': sor['cancel_serial_no'],
                'symbol': sor['symbol'],
                'direction': sor['direction'],
                'open_close': sor['open_close'],
                'price': float(sor['price']),
                'volume': sor['volume'],
                'order_type': sor['order_type'],
                'investor_type': sor['investor_type'],
                'time_in_force': sor['time_in_force'],
                'error_no': sor['error_no'],
                'error_msg': sor['error_msg'],
                'reject_time': '%s %s.%d' % (sor['calendar_date'], sor['calendar_time'], sor['calendar_microsec']),
            })

        pre_settle_date = parse(pre_date)
        pre_settle_date_str = pre_settle_date.strftime('%Y-%m-%d')

        vs_accounts_pnl = {}
        if (strategy_detail['strategy_type'] in consts.stock_strategy_type) and (day_night == 0):
            vs_accounts = self.sc.query(VsAccount).filter(
                VsAccount.vstrategy_id.in_(vs_ids),
                VsAccount.settle_date == trading_date_str,
                VsAccount.daynight == 'NIGHT'
            )
            for vs_acc in vs_accounts:
                vs_accounts_pnl['%s|%s' % (vs_acc.vstrategy_id, vs_acc.account)] = {
                    'accumulated_pnl': float(vs_acc.accumulated_pnl),
                    'pnl': 0,
                    'fee': 0,
                }
            position_data = {'%s|%s|%s' % (pos['vstrategy_id'], pos['account'], pos['symbol']): pos
                             for pos in StrategyPerfInput.get_position_data(
                    vs_ids, day_night=0, trading_date=trading_date_str)}
        else:
            vs_accounts = self.sc.query(VsAccount).filter(
                VsAccount.vstrategy_id.in_(vs_ids),
                VsAccount.settle_date == pre_settle_date_str,
                VsAccount.daynight == 'DAY'
            )
            for vs_acc in vs_accounts:
                vs_accounts_pnl['%s|%s' % (vs_acc.vstrategy_id, vs_acc.account)] = {
                    'accumulated_pnl': float(vs_acc.accumulated_pnl),
                    'pnl': 0,
                    'fee': 0,
                }
            position_data = {'%s|%s|%s' % (pos['vstrategy_id'], pos['account'], pos['symbol']): pos
                             for pos in StrategyPerfInput.get_position_data(
                    vs_ids, day_night=1, trading_date=pre_settle_date_str)}

        if not vs_accounts_pnl:
            vs_accounts_pnl = {
                '%s|%s' % (v_id, acc): {
                    'accumulated_pnl': 0,
                    'pnl': 0,
                    'fee': 0,
                } for v_id, vs_d in vs_detail.items() for acc in vs_d['accounts']
            }

        basic_data = {
            'trading_date': trading_date_str,
            'day_night': day_night,
            'strategy_detail': strategy_detail,
            'invest_funds': invest_funds,
            'vs_detail': vs_detail,
            'vs_accounts_pnl': vs_accounts_pnl,
            'parent_logs': parent_logs,
            'children_logs': children_logs,
            'trade_logs': trade_logs,
            'position_data': position_data,
            'orders_rejected': orders_rejected,
        }
        return basic_data

    def get_basic_data(self, cache=True):

        if self._basic_data:
            return self._basic_data

        cache_key = 'platform_track_basic_data_%s_%s' % (self.id_no, self.portfolio_name)
        if cache:
            data = get_cache(cache_key)
        else:
            data = None
        if data:
            return data
        data = self.track_basic_data()
        self._basic_data = data
        if data and (self.id_no[0:5] not in ('QZ201', 'PAN01')):
            set_cache(cache_key, data, 100 + random.randint(0, 50))
        return self._basic_data

    def strategy_track(self, basic_data=None, cache=True):
        cache_key = 'platform_track_detail_data_%s_%s' % (self.id_no, self.portfolio_name)
        if cache:
            data = get_cache(cache_key)
        else:
            data = None
        if data:
            return data
        if not basic_data:
            basic_data = self.get_basic_data()
        trade_logs = basic_data['trade_logs']
        parent_logs = basic_data['parent_logs']
        children_logs = basic_data['children_logs']
        orders_rejected = basic_data['orders_rejected']
        parent_array, children_array, deal_array, position_array = [], [], [], []

        if not basic_data:
            return {
                'parent_data': parent_array,
                'children_data': children_array,
                'deal_data': deal_array,
                'position_data': position_array,
                'orders_rejected': [],
            }

        for l in trade_logs:
            c_l = children_logs.get(l['serial_no'])
            if not c_l:
                c_l = {
                    'volume': l['volume'],
                    'business_volume': 0,
                    'remain_volume': 0,
                    'business_price': 0,
                    'send_time': '',
                    'transaction_time': '',
                    'cancel_time': '',
                    'day_night': l['day_night'],
                    'account': l['account'],
                    'strategy_id': l['strategy_id'],
                    's_id': l['s_id'],
                    'id_no': l['id_no'],
                    'portfolio_name': l['portfolio_name'],
                    'symbol': l['symbol'],
                    'direction': l['direction'],
                    'serial_no': l['serial_no'],
                    'parent_serial_no': l['serial_no'],
                    'price': l['price'],
                    'indicator': 0,
                    'trade_type': 0,
                    'total_notional': 0,
                }
                children_logs[c_l['serial_no']] = c_l
            p_l = parent_logs.get(c_l['parent_serial_no'])
            if not p_l:
                p_l = copy.deepcopy(c_l)
                p_l['algorithm'] = 0
                parent_logs[p_l['serial_no']] = p_l
            c_l['volume'] = l['volume']
            c_l['send_time'] = c_l['send_time'] or l['send_time']
            c_l['cancel_time'] = c_l['cancel_time'] or l['cancel_time']
            c_l['account'] = l['account']
            c_l['symbol'] = l['symbol']
            c_l['direction'] = l['direction']
            c_l['price'] = l['price']
            p_l['account'] = l['account']
            p_l['send_time'] = p_l['send_time'] or l['send_time']
            p_l['cancel_time'] = p_l['cancel_time'] or l['cancel_time']
            if l['msg_type'] == consts.trade_rtn:
                l['indicator'] = c_l['indicator']
                l['trade_type'] = c_l['trade_type']
                l['parent_serial_no'] = c_l['parent_serial_no']
                total_notional = l['trade_price'] * l['trade_vol']
                c_l['business_volume'] += l['trade_vol']
                c_l['total_notional'] += total_notional
                p_l['total_notional'] += total_notional
                p_l['business_volume'] += l['trade_vol']
                c_l['transaction_time'] = l['transaction_time']
                p_l['transaction_time'] = l['transaction_time']
                p_l['account'] = l['account']
                deal_array.append(l)

        children_array = list(children_logs.values())
        parent_array = list(parent_logs.values())

        for c_l in children_array:
            c_l['remain_volume'] = c_l['volume'] - c_l['business_volume']
            if c_l['business_volume'] != 0:
                c_l['business_price'] = round(c_l['total_notional'] / c_l['business_volume'], 4)
        for p_l in parent_array:
            p_l['remain_volume'] = p_l['volume'] - p_l['business_volume']
            if p_l['business_volume'] != 0:
                p_l['business_price'] = round(p_l['total_notional'] / p_l['business_volume'], 4)

        data = {
            'parent_data': parent_array,
            'children_data': children_array,
            'deal_data': deal_array,
            'position_data': position_array,
            'orders_rejected': orders_rejected,
        }
        if self.id_no[0:5] not in ('QZ201', 'PAN01'):
            set_cache(cache_key, data, 150)
        return data

    def get_live_position(self, quote_data=None, basic_data=None):
        if not basic_data:
            basic_data = self.get_basic_data()

        if not basic_data:
            return []

        if quote_data:
            self.quote_data = quote_data

        strategy_detail = basic_data['strategy_detail']
        vs_accounts_pnl = basic_data['vs_accounts_pnl']
        vs_detail = basic_data['vs_detail']
        vs_detail = {int(v_id): v_d for v_id, v_d in vs_detail.items()}
        invest_funds = basic_data['invest_funds']
        position_data = copy.deepcopy(basic_data['position_data'])
        trade_logs = basic_data['trade_logs']
        position_data_detail = {}
        now_time = datetime.datetime.now().strftime('%H%M')
        for v_id_acc_key, acc_pnl in vs_accounts_pnl.items():
            v_id_acc = v_id_acc_key.split('|')
            v_id = int(v_id_acc[0])
            acc = v_id_acc[1]
            key = (v_id, acc)
            _portfolio_name = vs_detail.get(v_id, {}).get('portfolio_name', '')
            id_no = vs_detail.get(v_id, {}).get('id_no', '')
            position_data_detail[key] = {
                'abstract_info': {
                    'total_asset': 0,
                    'total_pnl': acc_pnl['accumulated_pnl'],
                    'invest_funds': invest_funds.get(v_id_acc_key, 0),
                    'fee': acc_pnl['fee'],
                    'today_pnl': acc_pnl['pnl'],
                    'total_used_margin': 0,
                    'portfolio_name': _portfolio_name,
                    'strategy_id': self.id_no,
                    's_id': strategy_detail['s_id'],
                    'vstrategy_id': v_id,
                    'account': acc,
                    'id_no': id_no,
                },
                'detail_info': [],
                'strategy_id': self.id_no,
                's_id': strategy_detail['s_id'],
                'symbol_info': [],
                'vstrategy_id': v_id,
                'id_no': id_no,
                'account': acc,
                'portfolio_name': _portfolio_name,
            }

        long_avg_price_data = {}
        short_avg_price_data = {}
        position_categories = ('long_open_pos', 'short_open_pos', 'long_close_pos', 'short_close_pos', \
                               'long_open_amount', 'short_open_amount', 'long_close_amount', 'short_close_amount')

        for l in trade_logs:
            if str(l['msg_type']) != consts.trade_rtn:
                continue
            v_id = l['vstrategy_id']
            acc = l['account']
            symbol = l['symbol']
            d_flag = int(l['direction'])
            o_flag = int(l['open_close'])
            position_key = '|'.join([str(v_id), acc, symbol])
            symbol_position = position_data.get(position_key)
            if not symbol_position:
                symbol_position = {
                    'symbol': symbol,
                    'account': acc,
                    'vstrategy_id': v_id,
                    'today_long_pos': 0,
                    'today_short_pos': 0,
                    'today_long_avg_price': 0,
                    'today_short_avg_price': 0,
                }
                position_data[position_key] = symbol_position

            s_long_avg_price_data = long_avg_price_data.setdefault(position_key, {
                'open': [],
                'close': [],
            })

            s_short_avg_price_data = short_avg_price_data.setdefault(position_key, {
                'open': [],
                'close': [],
            })

            # symbol_position['long_open_pos'] = symbol_position.get('long_open_pos', 0)
            # symbol_position['short_open_pos'] = symbol_position.get('short_open_pos', 0)
            # symbol_position['long_close_pos'] = symbol_position.get('long_close_pos', 0)
            # symbol_position['short_close_pos'] = symbol_position.get('short_close_pos', 0)

            # symbol_position['long_open_amount'] = symbol_position.get('long_open_amount', 0)
            # symbol_position['short_open_amount'] = symbol_position.get('short_open_amount', 0)
            #   symbol_position['long_close_amount'] = symbol_position.get('long_close_amount', 0)
            # symbol_position['short_close_amount'] = symbol_position.get('short_close_amount', 0)           

            for i in position_categories:
                symbol_position[i] = symbol_position.get(i, 0)

            if d_flag == consts.Direction.buy.value and o_flag == consts.OpenClose.open.value:
                # buy open
                symbol_position['long_open_pos'] += l['trade_vol']
                symbol_position['long_open_amount'] += l['trade_vol'] * l['trade_price']
                s_long_avg_price_data['open'].extend([l['trade_price']] * int(l['trade_vol']))
            elif d_flag == consts.Direction.sell.value and o_flag == consts.OpenClose.open.value:
                # sell open
                symbol_position['short_open_pos'] += l['trade_vol']
                symbol_position['short_open_amount'] += l['trade_vol'] * l['trade_price']
                s_short_avg_price_data['open'].extend([l['trade_price']] * int(l['trade_vol']))
            elif d_flag == consts.Direction.sell.value:
                # sell close
                symbol_position['long_close_pos'] += l['trade_vol']
                symbol_position['long_close_amount'] += l['trade_vol'] * l['trade_price']
                s_long_avg_price_data['close'].extend([l['trade_price']] * int(l['trade_vol']))
            elif d_flag == consts.Direction.buy.value:
                # buy close
                symbol_position['short_close_pos'] += l['trade_vol']
                symbol_position['short_close_amount'] += l['trade_vol'] * l['trade_price']
                s_short_avg_price_data['close'].extend([l['trade_price']] * int(l['trade_vol']))

        for key, symbol_pos in position_data.items():
            vs_staretgy_type = vs_detail.get(int(symbol_pos['vstrategy_id']), {}).get('strategy_type', '')
            if (symbol_pos['vstrategy_id'], symbol_pos['account']) in position_data_detail:
                pos_data_detail = position_data_detail[(symbol_pos['vstrategy_id'], symbol_pos['account'])]
            else:
                v_id = symbol_pos['vstrategy_id']
                acc = symbol_pos['account']
                v_id_acc_key = '%s|%s' % (v_id, acc)
                _portfolio_name = vs_detail.get(v_id, {}).get('portfolio_name', '')
                id_no = vs_detail.get(v_id, {}).get('id_no', '')
                pos_data_detail = {
                    'abstract_info': {
                        'total_asset': 0,
                        'total_pnl': 0,
                        'invest_funds': invest_funds.get(v_id_acc_key, 0),
                        'fee': 0,
                        'today_pnl': 0,
                        'total_used_margin': 0,
                        'portfolio_name': _portfolio_name,
                        'strategy_id': self.id_no,
                        's_id': strategy_detail['s_id'],
                        'vstrategy_id': v_id,
                        'account': acc,
                        'id_no': id_no,
                    },
                    'detail_info': [],
                    'strategy_id': self.id_no,
                    's_id': strategy_detail['s_id'],
                    'symbol_info': [],
                    'vstrategy_id': v_id,
                    'id_no': id_no,
                    'account': acc,
                    'portfolio_name': _portfolio_name,
                }
                position_data_detail[(v_id, acc)] = pos_data_detail

            # if int(symbol_pos['vstrategy_id']) in consts.hk_stock_vs_ids:
            #     is_hk_stock = True
            # else:
            #     is_hk_stock = False
            is_hk_stock = bool(int(symbol_pos['vstrategy_id']) in consts.hk_stock_vs_ids)

            # symbol_pos['long_open_pos'] = symbol_pos.get('long_open_pos', 0)
            # symbol_pos['short_open_pos'] = symbol_pos.get('short_open_pos', 0)
            # symbol_pos['long_close_pos'] = symbol_pos.get('long_close_pos', 0)
            # symbol_pos['short_close_pos'] = symbol_pos.get('short_close_pos', 0)

            # symbol_pos['long_open_amount'] = symbol_pos.get('long_open_amount', 0)
            # symbol_pos['short_open_amount'] = symbol_pos.get('short_open_amount', 0)
            # symbol_pos['long_close_amount'] = symbol_pos.get('long_close_amount', 0)
            # symbol_pos['short_close_amount'] = symbol_pos.get('short_close_amount', 0)

            for i in position_categories:
                symbol_pos[i] = symbol_pos.get(i, 0)

            yest_net_long = symbol_pos['today_long_pos']
            yest_net_short = symbol_pos['today_short_pos']

            today_net_long = symbol_pos['long_open_pos']
            today_net_short = symbol_pos['short_open_pos']

            if symbol_pos['long_close_pos'] < yest_net_long:
                yest_net_long -= symbol_pos['long_close_pos']
            else:
                today_net_long -= (symbol_pos['long_close_pos'] - yest_net_long)
                yest_net_long = 0

            if symbol_pos['short_close_pos'] < yest_net_short:
                yest_net_short -= symbol_pos['short_close_pos']
            else:
                today_net_short -= (symbol_pos['short_close_pos'] - yest_net_short)
                yest_net_short = 0

            total_long = yest_net_long + today_net_long
            total_short = yest_net_short + today_net_short

            total_long_pos = symbol_pos['today_long_pos'] + symbol_pos['long_open_pos']
            total_short_pos = symbol_pos['today_short_pos'] + symbol_pos['short_open_pos']

            if total_long_pos == 0:
                long_avg_price = 0
            else:
                s_long_avg_price_data = long_avg_price_data.setdefault(key, {
                    'open': [],
                    'close': [],
                })
                if symbol_pos['today_long_pos']:
                    s_long_avg_price_data['open'] = [symbol_pos['today_long_avg_price']] * \
                                                    int(symbol_pos['today_long_pos']) + \
                                                    s_long_avg_price_data['open']

                len_open = len(s_long_avg_price_data['open'])
                len_close = len(s_long_avg_price_data['close'])
                if len_close >= len_open:
                    long_avg_price = 0
                else:
                    long_avg_price = sum(s_long_avg_price_data['open'][len_close:]) / (len_open - len_close)

            if total_short_pos == 0:
                short_avg_price = 0
            else:
                s_short_avg_price_data = short_avg_price_data.setdefault(key, {
                    'open': [],
                    'close': [],
                })
                if symbol_pos['today_short_pos']:
                    s_short_avg_price_data['open'] = [symbol_pos['today_short_avg_price']] * \
                                                     int(symbol_pos['today_short_pos']) + \
                                                     s_short_avg_price_data['open']

                len_open = len(s_short_avg_price_data['open'])
                len_close = len(s_short_avg_price_data['close'])
                if len_close >= len_open:
                    short_avg_price = 0
                else:
                    short_avg_price = sum(s_short_avg_price_data['open'][len_close:]) / (len_open - len_close)

            if symbol_pos['long_open_pos'] != 0:
                today_long_avg_price = symbol_pos['long_open_amount'] / float(symbol_pos['long_open_pos'])
            else:
                today_long_avg_price = 0

            if symbol_pos['short_open_pos'] != 0:
                today_short_avg_price = symbol_pos['short_open_amount'] / float(symbol_pos['short_open_pos'])
            else:
                today_short_avg_price = 0
            try:
                # 204001:国债回购, 131810:深市债券
                if symbol_pos['symbol'] in ('204001', '131810'):
                    last_price = 0
                # zz500 index
                elif symbol_pos['symbol'] in ('H00905', 'h00905'):
                    last_price = self.get_h00905_last_price()
                # 兼容指数
                elif symbol_pos['symbol'] in ('000905.sh', '000905.SH'):
                    last_price = self.quote_data[symbol_pos['symbol']]['LastPrice'] / 10000
                else:
                    last_price = self.quote_data[symbol_pos['symbol']]['LastPrice']

                if last_price < 0:
                    last_price = 0

                if symbol_pos['symbol'].isdigit() and ('0800' <= now_time <= '0925'):
                    last_price = 0

            except Exception as e:
                sentry.captureException()
                last_price = 0

            # 如果出现异常情况，last_price为0更容易发现和定位问题。去掉fall back的处理逻辑
            # last_price = last_price or long_avg_price or short_avg_price or today_long_avg_price or today_short_avg_price
            currency = vs_detail[symbol_pos['vstrategy_id']]['accounts_currency'].get(symbol_pos['account'], 'cny')
            if symbol_pos['account'] in consts.FOREGIN_ACCOUNT:
                currency = consts.FOREGIN_ACCOUNT[symbol_pos['account']]
            trade_unit = self.get_symbol_trade_unit(symbol_pos['symbol'], currency)
            exchange_rate = self.get_exchange_rate(currency)
            long_pnl = (
                    symbol_pos['long_close_amount']
                    + total_long * last_price
                    - symbol_pos['today_long_pos'] * symbol_pos['today_long_avg_price']
                    - symbol_pos['long_open_amount']
            )

            long_pnl = long_pnl * trade_unit * exchange_rate

            short_pnl = (
                    symbol_pos['today_short_pos'] * symbol_pos['today_short_avg_price']
                    + symbol_pos['short_open_amount']
                    - symbol_pos['short_close_amount']
                    - total_short * last_price
            )
            if vs_staretgy_type in consts.t0_stock_strategy_type:
                long_pnl -= (symbol_pos.get('today_long_freeze_pos', 0) * (
                        last_price - symbol_pos.get('today_settle_price', 0)))
                short_pnl -= (symbol_pos.get('today_short_freeze_pos', 0) * (
                        symbol_pos.get('today_settle_price', 0) - last_price))

            short_pnl = short_pnl * trade_unit * exchange_rate
            if symbol_pos['symbol'][:2].lower() == 'uc' and exchange_rate != 0:
                long_pnl = long_pnl / exchange_rate
                short_pnl = short_pnl / exchange_rate

            long_fee, short_fee = 0, 0

            if symbol_pos['long_open_pos']:
                long_fee_data = {
                    'symbol': symbol_pos['symbol'],
                    'currency': currency,
                    'direction': 0,
                    'open_close': 0,
                    'exchange_rate': exchange_rate,
                    'volume': symbol_pos['long_open_pos'],
                    'turnover': (symbol_pos['long_open_amount']) * trade_unit,
                    'trade_unit': trade_unit,
                    'is_hk_stock': is_hk_stock,
                }

                try:
                    long_fee += self.cal_fee(long_fee_data)
                except Exception as e:
                    sentry.captureException()

            if symbol_pos['short_open_pos']:
                long_fee_data = {
                    'symbol': symbol_pos['symbol'],
                    'currency': currency,
                    'direction': 1,
                    'open_close': 0,
                    'exchange_rate': exchange_rate,
                    'volume': symbol_pos['short_open_pos'],
                    'turnover': (symbol_pos['short_open_amount']) * trade_unit,
                    'trade_unit': trade_unit,
                    'is_hk_stock': is_hk_stock,
                }

                try:
                    long_fee += self.cal_fee(long_fee_data)
                except Exception as e:
                    sentry.captureException()

            if symbol_pos['long_close_pos']:
                short_fee_data = {
                    'symbol': symbol_pos['symbol'],
                    'currency': currency,
                    'direction': 1,
                    'open_close': 1,
                    'exchange_rate': exchange_rate,
                    'volume': symbol_pos['long_close_pos'],
                    'turnover': (symbol_pos['long_close_amount']) * trade_unit,
                    'trade_unit': trade_unit,
                    'is_hk_stock': is_hk_stock,
                }

                try:
                    short_fee += self.cal_fee(short_fee_data)
                except Exception as e:
                    sentry.captureException()

            if symbol_pos['short_close_pos']:
                short_fee_data = {
                    'symbol': symbol_pos['symbol'],
                    'currency': currency,
                    'direction': 0,
                    'open_close': 1,
                    'exchange_rate': exchange_rate,
                    'volume': symbol_pos['short_close_pos'],
                    'turnover': (symbol_pos['short_close_amount']) * trade_unit,
                    'trade_unit': trade_unit,
                    'is_hk_stock': is_hk_stock,
                }

                try:
                    short_fee += self.cal_fee(short_fee_data)
                except Exception as e:
                    sentry.captureException()

            fee = long_fee + short_fee
            pnl = long_pnl + short_pnl - fee
            if symbol_pos['symbol'] in ('204001', '131810'):
                pnl = 0
                fee = 0

            pos_data_detail['abstract_info']['total_pnl'] += pnl
            pos_data_detail['abstract_info']['today_pnl'] += pnl
            pos_data_detail['abstract_info']['fee'] += fee
            pos_data_detail['abstract_info']['total_asset'] = pos_data_detail['abstract_info']['total_pnl'] + \
                                                              pos_data_detail['abstract_info']['invest_funds']

            if total_long != 0:
                s_d = {
                    'vstrategy_id': symbol_pos['vstrategy_id'],
                    'account': symbol_pos['account'],
                    'symbol': symbol_pos['symbol'],
                    'parent_order_id': '',
                    'strategy_id': self.id_no,
                    'portfolio_name': vs_detail.get(symbol_pos['vstrategy_id'], {}).get('portfolio_name', ''),
                    's_id': strategy_detail['s_id'],
                    'id_no': vs_detail.get(symbol_pos['vstrategy_id'], {}).get('id_no', ''),
                    'pnl': 0,
                    'total_position': total_long,
                    'yest_position': yest_net_long,
                    'today_position': today_net_long,
                    'last_price': last_price,
                    'avg_price': long_avg_price,
                    'used_margin': total_long * last_price * trade_unit,
                    'today_avg_price': today_long_avg_price,
                    'direction': 0,

                }
                s_d['pnl'] = (s_d['last_price'] - s_d['avg_price']) * s_d['total_position'] * trade_unit
                if s_d['symbol'].lower()[:2] == 'uc':
                    s_d['used_margin'] = total_long * trade_unit
                pos_data_detail['abstract_info']['total_used_margin'] += s_d['used_margin']
                pos_data_detail['detail_info'].append(s_d)
            if total_short != 0:
                s_d = {
                    'vstrategy_id': symbol_pos['vstrategy_id'],
                    'account': symbol_pos['account'],
                    'symbol': symbol_pos['symbol'],
                    'parent_order_id': '',
                    'strategy_id': self.id_no,
                    'portfolio_name': vs_detail.get(symbol_pos['vstrategy_id'], {}).get('portfolio_name', ''),
                    's_id': strategy_detail['s_id'],
                    'id_no': vs_detail.get(symbol_pos['vstrategy_id'], {}).get('id_no', ''),
                    'pnl': 0,
                    'total_position': total_short,
                    'yest_position': yest_net_short,
                    'today_position': today_net_short,
                    'last_price': last_price,
                    'avg_price': short_avg_price,
                    'used_margin': total_short * last_price * trade_unit,
                    'today_avg_price': today_short_avg_price,
                    'direction': 1,
                }
                s_d['pnl'] = (s_d['avg_price'] - s_d['last_price']) * s_d['total_position'] * trade_unit
                if s_d['symbol'].lower()[:2] == 'uc':
                    s_d['used_margin'] = total_short * trade_unit
                pos_data_detail['abstract_info']['total_used_margin'] += s_d['used_margin']
                pos_data_detail['detail_info'].append(s_d)
        group_detail = {}
        # 聚合PO(Portfolio）,Group策略
        if strategy_detail['group_id'] > 0 or strategy_detail['node'] == 'group' or strategy_detail[
            'strategy_type'] == 'PO':
            for (v_id, acc), detail in position_data_detail.items():
                if acc not in group_detail:
                    group_detail[acc] = copy.deepcopy(detail)
                    group_detail[acc]['id_no'] = ''
                    group_detail[acc]['abstract_info']['id_no'] = ''
                    group_detail[acc]['detail_info'] = []
                    group_detail[acc]['symbol_info'] = []
                else:
                    group_detail[acc]['abstract_info']['invest_funds'] += detail['abstract_info']['invest_funds']
                    group_detail[acc]['abstract_info']['total_pnl'] += detail['abstract_info']['total_pnl']
                    group_detail[acc]['abstract_info']['fee'] += detail['abstract_info']['fee']
                    group_detail[acc]['abstract_info']['today_pnl'] += detail['abstract_info']['today_pnl']
                    group_detail[acc]['abstract_info']['total_used_margin'] += detail['abstract_info'][
                        'total_used_margin']
                    group_detail[acc]['abstract_info']['total_asset'] += detail['abstract_info']['total_asset']
                group_detail[(v_id, acc)] = detail
            position_data_detail = group_detail
        return sorted(position_data_detail.values(), key=lambda d: d.get('id_no', ''))


class HistoryStrategyTrackService(ServiceBaseService):

    def __init__(self, s_id=None, id_no=None, **kwargs):
        self.sc = session()
        self.id_no = id_no
        self.kwargs = kwargs
        self.basic_data = None
        super(HistoryStrategyTrackService, self).__init__()

    def __del__(self):
        self.sc.close()
        self.kdb.release()

    def init(self):
        self.trading_date = self.kdb.get_trading_date(calendar_date=self.kwargs['trading_date'], calendar_hour=15)
        self.day_night = 0
        self.pre_date_dict = self.kdb.get_nebor_trading_date(self.trading_date)

    def get_strategy_detail(self):
        live_strategies = self.sc.query(
            VStrategies.id.label('vs_id'),
            Strategy.id_no.label('id_no'),
            Strategy.id.label('s_id'),
            StrategyPortfolio.name.label('portfolio_name'),
            Strategy.strategy_type.label('s_type'),
            Strategy.group_id.label('group_id'),
            Strategy.node.label('node'),
            VStrategies.symbols_accounts_detail.label('symbols_accounts')
        ).join(
            Strategy, or_(
                and_(
                    Strategy.id == VStrategies.strategy_id, VStrategies.group_id == 0
                ),
                Strategy.id == VStrategies.group_id
            )
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            Strategy.id_no == self.id_no,
        )

        strategy_detail, vs_detail = {}, {}
        for s in live_strategies:
            if s.vs_id not in vs_detail:
                vs_detail[s.vs_id] = {
                    'id': s.vs_id,
                    'strategy_type': s.s_type,
                    'group_name': s.portfolio_name,
                    'portfolio_name': s.portfolio_name,
                    'accounts': set(),
                }
            if not strategy_detail:
                strategy_detail = {
                    's_id': s.s_id,
                    'strategy_type': s.s_type,
                    'group_id': s.group_id,
                    'node': s.node,
                    'id_no': s.id_no,
                }

        vs_ids = list(vs_detail.keys())
        for vs_id_s in self.sc.query(
                Strategy.id_no.label('id_no'),
                VStrategies.id.label('vs_id'),
        ).join(
            VStrategies, VStrategies.strategy_id == Strategy.id
        ).filter(
            VStrategies.id.in_(vs_ids)
        ):
            vs_detail[vs_id_s.vs_id]['id_no'] = vs_id_s.id_no

        self.strategy_detail = strategy_detail
        self.vs_detail = vs_detail
        self.vs_ids = vs_ids
        return True

    def get_parent_orders(self):

        parent_orders = self.sc.query(ParentOrder).filter(
            ParentOrder.vstrategy_id.in_(self.vs_ids),
            ParentOrder.trading_date == self.trading_date,
        )

        parent_logs, parent_order_ids = {}, []
        for po in parent_orders:
            po_brief = po.brief()
            po_brief['strategy_id'] = self.id_no
            po_brief['s_id'] = self.strategy_detail['s_id']
            po_brief['id_no'] = self.vs_detail[po_brief['vstrategy_id']]['id_no']
            po_brief['strategy_type'] = self.vs_detail[po_brief['vstrategy_id']]['strategy_type']
            po_brief['group_name'] = self.vs_detail[po_brief['vstrategy_id']]['portfolio_name']
            po_brief['portfolio_name'] = self.vs_detail[po_brief['vstrategy_id']]['portfolio_name']
            parent_order_ids.append(po_brief['parent_order_id'])
            po_brief['parent_order_id'] = ''.join([
                {0: '2', 1: '1'}.get(po_brief['day_night'], 'X'), po_brief['parent_order_id']
            ])
            po_brief['parent_serial_no'] = po_brief['parent_order_id']
            po_brief['serial_no'] = po_brief['parent_order_id']
            parent_logs[po_brief['parent_order_id']] = po_brief

        children_orders = []
        if parent_order_ids:
            children_orders = self.sc.query(ChildrenOrder).filter(
                ChildrenOrder.vstrategy_id.in_(self.vs_ids),
                ChildrenOrder.trading_date == self.trading_date,
                ChildrenOrder.parent_order_id.in_(parent_order_ids),
            )

        children_logs, children_order_ids = {}, []
        for co in children_orders:
            co_brief = co.brief()
            co_brief['strategy_id'] = self.id_no
            co_brief['s_id'] = self.strategy_detail['s_id']
            co_brief['id_no'] = self.vs_detail[co_brief['vstrategy_id']]['id_no']
            co_brief['strategy_type'] = self.vs_detail[co_brief['vstrategy_id']]['strategy_type']
            co_brief['group_name'] = self.vs_detail[co_brief['vstrategy_id']]['portfolio_name']
            co_brief['portfolio_name'] = self.vs_detail[co_brief['vstrategy_id']]['portfolio_name']
            children_order_ids.append(co_brief['child_order_id'])
            co_brief['child_order_id'] = ''.join(
                [{0: '2', 1: '1'}.get(co_brief['day_night'], 'X'), co_brief['child_order_id']]
            )
            co_brief['parent_order_id'] = ''.join(
                [{0: '2', 1: '1'}.get(co_brief['day_night'], 'X'), co_brief['parent_order_id']]
            )
            co_brief['serial_no'] = co_brief['child_order_id']
            co_brief['parent_serial_no'] = co_brief['parent_order_id']
            children_logs[co_brief['child_order_id']] = co_brief

        self.parent_logs = parent_logs
        self.children_logs = children_logs
        return True

    def get_trade_logs(self):
        trade_logs_query = self.sc.query(TradeLogs).filter(
            TradeLogs.trading_date == self.trading_date,
            TradeLogs.vstrategy_id.in_(self.vs_ids),
            TradeLogs.log_type.in_(['2', '3']),
        ).order_by(TradeLogs.calendar_date, TradeLogs.calendar_time, TradeLogs.calendar_microsec)

        trade_logs_send = self.sc.query(
            TradeLogs.serial_no,
            TradeLogs.calendar_time,
            TradeLogs.calendar_microsec,
            TradeLogs.day_night,
            TradeLogs.calendar_date,
        ).filter(
            TradeLogs.trading_date == self.trading_date,
            TradeLogs.vstrategy_id.in_(self.vs_ids),
            TradeLogs.log_type == '0',
        ).order_by(TradeLogs.calendar_date, TradeLogs.calendar_time, TradeLogs.calendar_microsec)
        trade_logs_send_time = {(r[0], r[3]): '%s %s.%s' % (r[4].strftime('%Y%m%d'), str(r[1]), str(r[2] or 0).zfill(6))
                                for r in trade_logs_send}

        trade_logs = []
        serial_no2accounts = {}
        for l in trade_logs_query:
            if l.log_type == '3' and l.entrust_status not in ('p', 'c'):
                continue
            l = l.brief()
            serial_no2accounts[l['serial_no']] = l['account']
            l['send_time'] = trade_logs_send_time.get((l['serial_no'], l['day_night']), l['send_time'])
            l['serial_no'] = ''.join([{0: '2', 1: '1'}.get(l['day_night'], 'X'), l['serial_no']])
            l['id_no'] = self.vs_detail[l['vstrategy_id']]['id_no']
            l['strategy_type'] = self.vs_detail[l['vstrategy_id']]['strategy_type']
            l['group_name'] = self.vs_detail[l['vstrategy_id']]['portfolio_name']
            l['portfolio_name'] = self.vs_detail[l['vstrategy_id']]['portfolio_name']
            l['strategy_id'] = self.id_no
            l['s_id'] = self.strategy_detail['s_id']
            trade_logs.append(l)

        manual_tradelogs = self.sc.query(SettlementManualTradelog).filter(
            SettlementManualTradelog.trading_date == self.trading_date,
            SettlementManualTradelog.vstrategy_id.in_(self.vs_ids),
        )
        for m_l in manual_tradelogs:
            m_l_breif = m_l.brief()
            m_l_breif['id_no'] = self.vs_detail[m_l_breif['vstrategy_id']]['id_no']
            m_l_breif['strategy_type'] = self.vs_detail[m_l_breif['vstrategy_id']]['strategy_type']
            m_l_breif['group_name'] = self.vs_detail[m_l_breif['vstrategy_id']]['portfolio_name']
            m_l_breif['portfolio_name'] = self.vs_detail[m_l_breif['vstrategy_id']]['portfolio_name']
            m_l_breif['strategy_id'] = self.id_no
            m_l_breif['s_id'] = self.strategy_detail['s_id']
            if m_l_breif['valid']:
                trade_logs.append(m_l_breif)
        self.trade_logs = trade_logs
        self.serial_no2accounts = serial_no2accounts
        return True

    def get_orders_rejected(self):
        orders_rejected = []
        strat_orders_rejected = self.sc.query(StrategyOrdersRejected).filter(
            StrategyOrdersRejected.vstrategy_id.in_(self.vs_ids),
            StrategyOrdersRejected.trading_date == self.trading_date,
        ).order_by(StrategyOrdersRejected.id.desc()).limit(800)
        for sor in strat_orders_rejected:
            sor = sor.to_dict()
            orders_rejected.append({
                'portfolio_name': self.vs_detail[sor['vstrategy_id']]['portfolio_name'],
                'group_name': self.vs_detail[sor['vstrategy_id']]['portfolio_name'],
                's_id': self.strategy_detail['s_id'],
                'strategy_id': self.id_no,
                'vstrategy_id': sor['vstrategy_id'],
                'id_no': self.vs_detail[sor['vstrategy_id']]['id_no'],
                'account': self.serial_no2accounts.get(sor['serial_no'], ''),
                'serial_no': sor['serial_no'],
                'cancel_serial_no': sor['cancel_serial_no'],
                'symbol': sor['symbol'],
                'direction': sor['direction'],
                'open_close': sor['open_close'],
                'price': float(sor['price']),
                'volume': sor['volume'],
                'order_type': sor['order_type'],
                'investor_type': sor['investor_type'],
                'time_in_force': sor['time_in_force'],
                'error_no': sor['error_no'],
                'error_msg': sor['error_msg'],
                'reject_time': '%s %s.%d' % (sor['calendar_date'], sor['calendar_time'], sor['calendar_microsec']),
            })
        self.orders_rejected = orders_rejected
        return True

    def get_position_data(self):
        invest_funds = self.sc.query(
            VStrategyAccountDetail.vstrategy_id.label('vstrategy_id'),
            VStrategyAccountDetail.account.label('account'),
            func.sum(VStrategyAccountDetail.amount).label('amount')
        ).filter(
            VStrategyAccountDetail.vstrategy_id.in_(self.vs_ids),
            or_(
                VStrategyAccountDetail.trading_date <= self.trading_date,
                VStrategyAccountDetail.trading_date.is_(None)
            )
        ).group_by(
            VStrategyAccountDetail.vstrategy_id,
            VStrategyAccountDetail.account,
        )

        vs_acc_invest_funds, vs_invest_funds = {}, {}
        for r in invest_funds:
            vs_acc_invest_funds[
                (r.vstrategy_id, r.account)
            ] = vs_acc_invest_funds.get((r.vstrategy_id, r.account), 0) + float(r.amount)

            vs_invest_funds[r.vstrategy_id] = vs_invest_funds.get(r.vstrategy_id, 0) + float(r.amount)

            self.vs_detail[r.vstrategy_id]['accounts'].add(r.account)

        vs_accounts = self.sc.query(
            VsAccount
        ).filter(
            VsAccount.settle_date == self.trading_date,
            VsAccount.vstrategy_id.in_(self.vs_ids),
            VsAccount.daynight == 'DAY',
        )

        account_currency = {}
        position_data_detail = {}
        for vs_acc in vs_accounts:
            v_id = vs_acc.vstrategy_id
            acc = vs_acc.account
            _portfolio_name = self.vs_detail[v_id]['portfolio_name']
            id_no = self.vs_detail[v_id]['id_no']
            key = (v_id, acc)
            _invest_funds = vs_invest_funds.get(key, 0)
            if (not _invest_funds) and len(self.vs_detail[v_id]['accounts']) <= 1:
                _invest_funds = vs_invest_funds.get(v_id, 0)
            position_data_detail[(v_id, acc)] = {
                'abstract_info': {
                    'total_asset': _invest_funds + float(vs_acc.accumulated_pnl),
                    'total_pnl': float(vs_acc.accumulated_pnl),
                    'invest_funds': _invest_funds,
                    'fee': float(vs_acc.fee),
                    'today_pnl': float(vs_acc.pnl),
                    'total_used_margin': float(vs_acc.position_cash),
                    'portfolio_name': _portfolio_name,
                    'strategy_id': self.id_no,
                    's_id': self.strategy_detail['s_id'],
                    'vstrategy_id': v_id,
                    'account': acc,
                    'id_no': id_no,
                },
                'detail_info': [],
                'strategy_id': self.id_no,
                's_id': self.strategy_detail['s_id'],
                'symbol_info': [],
                'vstrategy_id': v_id,
                'id_no': id_no,
                'account': acc,
                'portfolio_name': _portfolio_name,
            }
            account_currency[vs_acc.account] = vs_acc.currency

        if not position_data_detail:
            for key in vs_acc_invest_funds.keys():
                if key not in position_data_detail:
                    (v_id, acc) = key
                    _portfolio_name = self.vs_detail[v_id]['portfolio_name']
                    id_no = self.vs_detail[v_id]['id_no']
                    position_data_detail[key] = {
                        'abstract_info': {
                            'total_asset': vs_acc_invest_funds[key],
                            'total_pnl': 0,
                            'invest_funds': vs_acc_invest_funds[key],
                            'fee': 0,
                            'today_pnl': 0,
                            'total_used_margin': 0,
                            'portfolio_name': _portfolio_name,
                            'strategy_id': self.id_no,
                            's_id': self.strategy_detail['s_id'],
                            'vstrategy_id': v_id,
                            'account': acc,
                            'id_no': id_no,
                        },
                        'detail_info': [],
                        'strategy_id': self.id_no,
                        's_id': self.strategy_detail['s_id'],
                        'symbol_info': [],
                        'vstrategy_id': v_id,
                        'id_no': id_no,
                        'account': acc,
                        'portfolio_name': _portfolio_name,
                    }

        vs_positions = self.sc.query(
            VsPosition
        ).filter(
            VsPosition.settle_date == self.trading_date,
            VsPosition.vstrategy_id.in_(self.vs_ids),
            VsPosition.daynight == 'DAY',
            or_(
                VsPosition.today_long_pos > 0,
                VsPosition.today_short_pos > 0,
            )
        )
        for r in vs_positions:
            if r.today_long_pos != 0:
                trade_unit = self.get_symbol_trade_unit(r.symbol, account_currency.get(r.account, 'CNY'))
                s_d = {
                    'vstrategy_id': r.vstrategy_id,
                    'account': r.account,
                    'symbol': r.symbol,
                    'parent_order_id': '',
                    'strategy_id': self.id_no,
                    'portfolio_name': self.vs_detail[r.vstrategy_id]['portfolio_name'],
                    's_id': self.strategy_detail['s_id'],
                    'id_no': self.vs_detail[r.vstrategy_id]['id_no'],
                    'pnl': float(r.symbol_pnl),
                    'total_position': r.today_long_pos,
                    'yest_position': r.yest_long_pos,
                    'today_position': max(0, r.today_long_pos - r.yest_long_pos),
                    'last_price': float(r.today_settle_price),
                    'avg_price': float(r.today_long_avg_price),
                    'used_margin': r.today_long_pos * float(r.today_settle_price) * trade_unit,
                    'today_avg_price': float(r.today_long_avg_price),
                    'direction': 0,
                }
                position_data_detail[(r.vstrategy_id, r.account)]['detail_info'].append(s_d)

            if r.today_short_pos != 0:
                trade_unit = self.get_symbol_trade_unit(r.symbol, account_currency.get(r.account, 'CNY'))
                s_d = {
                    'vstrategy_id': r.vstrategy_id,
                    'account': r.account,
                    'symbol': r.symbol,
                    'parent_order_id': '',
                    'strategy_id': self.id_no,
                    'portfolio_name': self.vs_detail[r.vstrategy_id]['portfolio_name'],
                    's_id': self.strategy_detail['s_id'],
                    'id_no': self.vs_detail[r.vstrategy_id]['id_no'],
                    'pnl': float(r.symbol_pnl),
                    'total_position': r.today_short_pos,
                    'yest_position': r.yest_short_pos,
                    'today_position': max(0, r.today_short_pos - r.yest_short_pos),
                    'last_price': float(r.today_settle_price),
                    'avg_price': float(r.today_short_avg_price),
                    'used_margin': r.today_short_pos * float(r.today_settle_price) * trade_unit,
                    'today_avg_price': float(r.today_short_avg_price),
                    'direction': 1,
                }
                position_data_detail[(r.vstrategy_id, r.account)]['detail_info'].append(s_d)

        group_detail = {}
        if self.strategy_detail['group_id'] > 0 or self.strategy_detail['node'] == 'group' or self.strategy_detail[
            'strategy_type'] == 'PO':
            for (v_id, acc), detail in position_data_detail.items():
                if acc not in group_detail:
                    group_detail[acc] = copy.deepcopy(detail)
                    group_detail[acc]['id_no'] = ''
                    group_detail[acc]['abstract_info']['id_no'] = ''
                    group_detail[acc]['detail_info'] = []
                    group_detail[acc]['symbol_info'] = []
                else:
                    group_detail[acc]['abstract_info']['invest_funds'] += detail['abstract_info']['invest_funds']
                    group_detail[acc]['abstract_info']['total_pnl'] += detail['abstract_info']['total_pnl']
                    group_detail[acc]['abstract_info']['fee'] += detail['abstract_info']['fee']
                    group_detail[acc]['abstract_info']['today_pnl'] += detail['abstract_info']['today_pnl']
                    group_detail[acc]['abstract_info']['total_asset'] += detail['abstract_info']['total_asset']
                    group_detail[acc]['abstract_info']['total_used_margin'] += detail['abstract_info'][
                        'total_used_margin']
                group_detail[(v_id, acc)] = detail
            position_data_detail = group_detail
        self.position_data = sorted(position_data_detail.values(), key=lambda d: d.get('id_no', ''))
        return True

    def get_history_basic_data(self):
        self.init()
        self.get_strategy_detail()
        self.get_parent_orders()
        self.get_trade_logs()
        self.get_orders_rejected()
        self.get_position_data()
        self.basic_data = {
            'parent_logs': self.parent_logs,
            'children_logs': self.children_logs,
            'trade_logs': self.trade_logs,
            'orders_rejected': self.orders_rejected,
            'position_data': self.position_data,
        }
        return True

    def get_history_track_data(self):
        if not self.basic_data:
            self.get_history_basic_data()
        if not self.basic_data:
            return {
                'parent_data': [],
                'children_data': [],
                'deal_data': [],
                'position_data': [],
                'orders_rejected': [],
            }
        trade_logs = self.basic_data['trade_logs']
        parent_logs = self.basic_data['parent_logs']
        children_logs = self.basic_data['children_logs']
        orders_rejected = self.basic_data['orders_rejected']
        position_array = self.basic_data['position_data']
        parent_array, children_array, deal_array = [], [], []
        for l in trade_logs:
            c_l = children_logs.get(l['serial_no'])
            if not c_l:
                c_l = {
                    'volume': l['volume'],
                    'business_volume': 0,
                    'remain_volume': 0,
                    'business_price': 0,
                    'send_time': '',
                    'transaction_time': '',
                    'cancel_time': '',
                    'day_night': l['day_night'],
                    'account': l['account'],
                    'strategy_id': l['strategy_id'],
                    's_id': l['s_id'],
                    'id_no': l['id_no'],
                    'portfolio_name': l['portfolio_name'],
                    'symbol': l['symbol'],
                    'direction': l['direction'],
                    'serial_no': l['serial_no'],
                    'parent_serial_no': l['serial_no'],
                    'price': l['price'],
                    'indicator': 0,
                    'trade_type': 0,
                    'total_notional': 0,
                }
                children_logs[c_l['serial_no']] = c_l
            p_l = parent_logs.get(c_l['parent_serial_no'])
            if not p_l:
                p_l = copy.deepcopy(c_l)
                p_l['algorithm'] = 0
                parent_logs[p_l['serial_no']] = p_l
            c_l['volume'] = l['volume']
            c_l['send_time'] = c_l['send_time'] or l['send_time']
            c_l['cancel_time'] = c_l['cancel_time'] or l['cancel_time']
            c_l['account'] = l['account']
            c_l['symbol'] = l['symbol']
            c_l['direction'] = l['direction']
            c_l['price'] = l['price']
            p_l['account'] = l['account']
            p_l['send_time'] = p_l['send_time'] or l['send_time']
            p_l['cancel_time'] = p_l['cancel_time'] or l['cancel_time']
            if l['msg_type'] == consts.trade_rtn:
                l['indicator'] = c_l['indicator']
                l['trade_type'] = c_l['trade_type']
                l['parent_serial_no'] = c_l['parent_serial_no']
                total_notional = l['trade_price'] * l['trade_vol']
                c_l['business_volume'] += l['trade_vol']
                c_l['total_notional'] += total_notional
                p_l['total_notional'] += total_notional
                p_l['business_volume'] += l['trade_vol']
                c_l['transaction_time'] = l['transaction_time']
                p_l['transaction_time'] = l['transaction_time']
                p_l['account'] = l['account']
                deal_array.append(l)

        children_array = list(children_logs.values())
        parent_array = list(parent_logs.values())

        for c_l in children_array:
            c_l['remain_volume'] = c_l['volume'] - c_l['business_volume']
            if c_l['business_volume'] != 0:
                c_l['business_price'] = round(c_l['total_notional'] / c_l['business_volume'], 4)
        for p_l in parent_array:
            p_l['remain_volume'] = p_l['volume'] - p_l['business_volume']
            if p_l['business_volume'] != 0:
                p_l['business_price'] = round(p_l['total_notional'] / p_l['business_volume'], 4)

        data = {
            'parent_data': parent_array,
            'children_data': children_array,
            'deal_data': deal_array,
            'position_data': position_array,
            'orders_rejected': orders_rejected,
        }
        return data


class HistoryPositionTrackService(object):

    def __init__(self, s_ids, **kwargs):
        self.s_ids = s_ids
        today = datetime.datetime.now().strftime('%Y%m%d')
        self.start_date = kwargs.get('start', today)
        self.end_date = kwargs.get('end', today)
        self.page = int(kwargs.get('page', 0))
        self.size = int(kwargs.get('size', 20))
        self.sc = session()

    def __del__(self):
        self.sc.close()

    def get_history_position(self):

        live_strategies = self.sc.query(
            VStrategies.id.label('vs_id'),
            Strategy.id_no.label('id_no'),
            Strategy.id.label('s_id'),
            StrategyPortfolio.name.label('portfolio_name'),
        ).join(
            Strategy, or_(
                and_(
                    Strategy.id == VStrategies.strategy_id,
                    VStrategies.group_id == 0
                ),
                Strategy.id == VStrategies.group_id
            )
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            StrategyPortfolio.status >= consts.STRATEGY_LIVE,
            StrategyPortfolio.source == 'platform',
            VStrategies.source == 'platform',
            Strategy.id_no.in_(self.s_ids),
        )
        vs_detail = {}
        for s in live_strategies:
            if s.vs_id not in vs_detail:
                vs_detail[s.vs_id] = {
                    's_id': s.s_id,
                    'id_no': s.id_no,
                    'portfolio_name': s.portfolio_name,
                }
        positions = self.sc.query(
            VsPosition.vstrategy_id.label('vstrategy_id'),
            VsPosition.account.label('account'),
            VsPosition.symbol.label('symbol'),
            VsPosition.settle_date.label('settle_date'),
            VsPosition.today_long_pos.label('today_long_pos'),
            VsPosition.today_short_pos.label('today_short_pos'),
            VsPosition.yest_long_pos.label('yest_long_pos'),
            VsPosition.yest_short_pos.label('yest_short_pos'),
            VsPosition.today_long_avg_price.label('today_long_avg_price'),
            VsPosition.today_short_avg_price.label('today_short_avg_price'),
        ).filter(
            VsPosition.vstrategy_id.in_(vs_detail.keys()),
            VsPosition.daynight == 'DAY',
            and_(VsPosition.settle_date >= self.start_date,
                 VsPosition.settle_date <= self.end_date),
            or_(
                VsPosition.today_long_pos > 0,
                VsPosition.today_short_pos > 0,
            ),
        ).order_by(
            VsPosition.settle_date.desc(),
            VsPosition.vstrategy_id.asc(),
            VsPosition.symbol.asc(),
        )

        total = positions.count()
        positions = positions.offset(self.page * self.size).limit(self.size)
        position_data = []
        for r in positions:
            v_id = r.vstrategy_id
            v_detail = vs_detail[v_id]
            if r.today_long_pos > 0:
                d = {
                    'strategy_id': v_detail['id_no'],
                    'vstrategy_id': v_id,
                    'account': r.account,
                    'portfolio_name': v_detail['portfolio_name'],
                    's_id': v_detail['s_id'],
                    'symbol': r.symbol,
                    'direction': 0,
                    'total_position': r.today_long_pos,
                    'yest_position': r.yest_long_pos,
                    'today_position': r.today_long_pos - r.yest_long_pos,
                    'avg_price': float(r.today_long_avg_price or 0),
                    'trade_date': r.settle_date.strftime('%Y%m%d'),
                }
                position_data.append(d)
            if r.today_short_pos > 0:
                d = {
                    'strategy_id': v_detail['id_no'],
                    'vstrategy_id': v_id,
                    'account': r.account,
                    'portfolio_name': v_detail['portfolio_name'],
                    's_id': v_detail['s_id'],
                    'symbol': r.symbol,
                    'direction': 1,
                    'total_position': r.today_short_pos,
                    'yest_position': r.yest_short_pos,
                    'today_position': r.today_short_pos - r.yest_short_pos,
                    'avg_price': float(r.today_short_avg_price or 0),
                    'trade_date': r.settle_date.strftime('%Y%m%d'),
                }
                position_data.append(d)
        return {
            'data': position_data,
            'total': total,
        }

class TuringTrackService(ServiceBaseService):

    def __init__(self, *args, **kwargs):
        self.vstrategy_id = 1  # turing strategy use 1 as vstrategy id
        self.sc = session()
        super(TuringTrackService, self).__init__()

    def __del__(self):
        self.sc.close()
        self.kdb.release()

    def account_dict_to_list(self, data):
        ret = {}
        for k, v in data.items():
            if k == 'accounts':
                ret[k] = []
                for a, a_v in v.items():
                    tmp = {'account': a}
                    for k1, v1 in a_v.items():
                        if k1 == 'vids':
                            tmp[k1] = []
                            for k2, v2 in v1.items():
                                tmp1 = {'vid': k2, 'detail': []}
                                for k3, v3 in v2.items():
                                    if k3 == 'detail':
                                        for k4, v4 in v3.items():
                                            tmp2 = {'symbol': k4}
                                            for k5, v5 in v4.items():
                                                tmp2[k5] = v5
                                            tmp1['detail'].append(tmp2)
                                        tmp1['detail'].sort(key=lambda x: x['symbol'])
                                    else:
                                        tmp1[k3] = v3
                                tmp[k1].append(tmp1)
                            tmp[k1].sort(key=lambda x: int(x['vid']))
                        else:
                            tmp[k1] = v1
                    ret[k].append(tmp)
            else:
                ret[k] = v
        return ret

    def get_live_quote_turnover(self):
        try:
            turnover_data = requests.get("http://127.0.0.1:10010/api/v1/speedquote/future_total_volume").json()['data']
        except Exception as e:
            self.turnover_data = {}
            return {}
        self.turnover_data = turnover_data
        return turnover_data

    def calc_pnl_and_vol(self, category=1, trade_date=None, account_list=None, product=None):
        data = {}
        ret = {}

        if trade_date:
            trading_date = parse(trade_date)
        else:
            trading_date = self.kdb.get_trading_date(hour=21)
            trading_date = parse(trading_date)
        trading_date_str = trading_date.strftime('%Y-%m-%d')

        pre_trading_date = self.kdb.get_nebor_trading_date(trading_date_str)['prev']
        pre_trading_date = parse(pre_trading_date)
        pre_trading_date_str = pre_trading_date.strftime('%Y-%m-%d')

        trade_logs = self.sc.query(
            TuringTradeLogs.account.label('account'),
            TuringTradeLogs.vstrategy_id.label('vstrategy_id'),
            TuringTradeLogs.symbol.label('symbol'),
            TuringTradeLogs.direction.label('direction'),
            TuringTradeLogs.open_close.label('open_close'),
            func.sum(TuringTradeLogs.trade_vol).label('trade_vol'),
            func.sum(TuringTradeLogs.trade_vol * TuringTradeLogs.trade_price).label('trade_amount'),
        ).filter(
            TuringTradeLogs.log_type == '3',
            TuringTradeLogs.trading_date == trading_date_str,
        ).group_by(
            TuringTradeLogs.account,
            TuringTradeLogs.vstrategy_id,
            TuringTradeLogs.symbol,
            TuringTradeLogs.direction,
            TuringTradeLogs.open_close,
        )

        order_logs = self.sc.query(
            TuringTradeLogs.account.label('account'),
            TuringTradeLogs.symbol.label('symbol'),
            TuringTradeLogs.vstrategy_id.label('vstrategy_id'),
            TuringTradeLogs.entrust_status.label('entrust_status'),
            func.count('*').label('num'),
        ).filter(
            or_(
                and_(TuringTradeLogs.entrust_status == 's', TuringTradeLogs.log_type == '0'),
                and_(TuringTradeLogs.entrust_status == 'd', TuringTradeLogs.log_type == '2'),
            ),
            TuringTradeLogs.trading_date == trading_date_str,
        ).group_by(
            TuringTradeLogs.account,
            TuringTradeLogs.symbol,
            TuringTradeLogs.vstrategy_id,
            TuringTradeLogs.entrust_status,
        )

        if datetime.datetime.now().hour < 21 and datetime.datetime.now().hour >= 9:
            day_night = 0
        else:
            day_night = 1

        last_order_logs = self.sc.query(
            TuringTradeLogs.account.label('account'),
            TuringTradeLogs.symbol.label('symbol'),
            TuringTradeLogs.vstrategy_id.label('vstrategy_id'),
            func.max(func.concat(TuringTradeLogs.calendar_date, ' ', TuringTradeLogs.quote_trigger)).label('last_time'),
        ).filter(
            TuringTradeLogs.trading_date == trading_date_str,
            TuringTradeLogs.log_type == '0',
            TuringTradeLogs.day_night == day_night,
        ).group_by(
            TuringTradeLogs.account,
            TuringTradeLogs.symbol,
            TuringTradeLogs.vstrategy_id,
        )

        all_accounts = self.sc.query(TuringLiveAccounts.name.label('name')).filter()

        if category == 1:
            ret = {'total_pnl': 0, 'accounts': {}}
            total_pnl = 0
            total_fee = 0
            total_net = 0
            total_vol = 0

            if account_list:
                trade_logs = trade_logs.filter(TuringTradeLogs.account.in_(account_list))
                order_logs = order_logs.filter(TuringTradeLogs.account.in_(account_list))

            for record in trade_logs:
                account = record.account
                symbol = record.symbol
                vstrategy_id = record.vstrategy_id
                data.setdefault(account, {})
                data[account].setdefault(vstrategy_id, {})
                data[account][vstrategy_id].setdefault(symbol, [])
                data[account][vstrategy_id][symbol].append(record)

            for account, account_detail in data.items():

                dim_cfgs = {} 
                exchange = 'UNKNOWN'
                last_cfg = self.sc.query(DIMPreConfs).filter(
                    DIMPreConfs.day_night == day_night,
                    DIMPreConfs.account == account,
                    DIMPreConfs.status == 1,
                ).order_by(
                    DIMPreConfs.id.desc()
                ).first()
                if last_cfg:
                    uid = last_cfg.uid
                    for cfg in self.sc.query(DIMPreConfs).filter(
                            # DIMPreConfs.day_night == day_night,
                            DIMPreConfs.uid == uid, 
                            DIMPreConfs.account == account,
                    ):   
                        if cfg.account_id not in dim_cfgs:
                            dim_cfgs[cfg.account_id] = set()
                        dim_cfgs[cfg.account_id].add(cfg.alphamixer)
                        exchange = cfg.exchange

                history_position = {} 
                future_settleprice = {} 
                if exchange in ["SHFE", "DCE", "CZCE"]:
                    yesterday = pre_trading_date_str + " 20:00:00"
                    # yesterday_end = pre_trading_date_str + " 23:59:59"
                    yesterday_end = trading_date_str + " 14:59:59"
                    position_logs = self.sc.query(TuringPositionLogs).filter(
                        TuringPositionLogs.account == account,
                        TuringPositionLogs.r_create_time >= yesterday,
                        TuringPositionLogs.r_create_time <= yesterday_end,
                    ).order_by(TuringPositionLogs.id.asc())
                else:
                    today = trading_date_str + " 08:00:00"
                    today_end = trading_date_str + " 14:59:59"
                    position_logs = self.sc.query(TuringPositionLogs).filter(
                        TuringPositionLogs.account == account,
                        TuringPositionLogs.r_create_time >= today,
                        TuringPositionLogs.r_create_time <= today_end,
                    ).order_by(TuringPositionLogs.id.asc())
                for pos in position_logs:
                    if pos.td_long_pos == 0 and pos.td_short_pos == 0:
                        continue
                    key = (pos.account, pos.symbol, pos.vstrategy_id)
                    if key not in history_position:
                        history_position.setdefault(key, {'long': 0, 'short': 0, 'used': 0})
                        history_position[key]['long'] = pos.td_long_pos
                        history_position[key]['short'] = pos.td_short_pos

                    if pos.symbol not in future_settleprice:
                        if not pos.symbol.isdigit():
                            future_settleprice[pos.symbol] = self.kdb.get_symbol_settleprice(pre_trading_date_str,
                                                                                             pos.symbol).get(
                                'settle_price', 0)

                ret['accounts'].setdefault(account, {'pnl': 0, 'vids': {}, 'last_time': '', 'warn': 0})
                account_pnl = 0
                account_fee = 0
                account_net = 0
                account_pos = 0
                account_vol = 0
                for vstrategy_id, vid_detail in account_detail.items():
                    ret['accounts'][account]['vids'].setdefault(vstrategy_id, {'pnl': 0, 'detail': {}, 'last_time': ''})
                    vid_pnl = 0
                    vid_fee = 0
                    vid_net = 0
                    vid_pos = 0
                    vid_vol = 0
                    for symbol, details in vid_detail.items():
                        buy_open_vol = 0
                        buy_open_avg_price = 0
                        sell_close_vol = 0
                        sell_close_avg_price = 0
                        sell_open_vol = 0
                        sell_open_avg_price = 0
                        buy_close_vol = 0
                        buy_close_avg_price = 0
                        total_trade_vol = 0
                        total_trade_amount = 0
                        for d in details:
                            if d.open_close == 0 and d.direction == 0:
                                if int(d.trade_vol) == 0:
                                    continue
                                buy_open_vol = int(d.trade_vol)
                                buy_open_avg_price = float(d.trade_amount) / int(d.trade_vol)
                                total_trade_vol += int(d.trade_vol)
                                total_trade_amount += float(d.trade_amount)
                            elif d.open_close == 1 and d.direction == 1:
                                if int(d.trade_vol) == 0:
                                    continue
                                sell_close_vol = int(d.trade_vol)
                                sell_close_avg_price = float(d.trade_amount) / int(d.trade_vol)
                                total_trade_vol += int(d.trade_vol)
                                total_trade_amount += float(d.trade_amount)
                            elif d.open_close == 0 and d.direction == 1:
                                if int(d.trade_vol) == 0:
                                    continue
                                sell_open_vol = int(d.trade_vol)
                                sell_open_avg_price = float(d.trade_amount) / int(d.trade_vol)
                                total_trade_vol += int(d.trade_vol)
                                total_trade_amount += float(d.trade_amount)
                            elif d.open_close == 1 and d.direction == 0:
                                if int(d.trade_vol) == 0:
                                    continue
                                buy_close_vol = int(d.trade_vol)
                                buy_close_avg_price = float(d.trade_amount) / int(d.trade_vol)
                                total_trade_vol += int(d.trade_vol)
                                total_trade_amount += float(d.trade_amount)
                        if symbol.isdigit():
                            tradeprice_obj = self.sc.query(TuringTradeLogs.trade_price).filter(
                                TuringTradeLogs.log_type == '3',
                                TuringTradeLogs.trading_date == trading_date_str,
                                TuringTradeLogs.symbol == symbol,
                            ).order_by(TuringTradeLogs.id.desc()).first()
                            if tradeprice_obj:
                                last_price = float(tradeprice_obj.trade_price)
                            else:
                                last_price = 0
                            if len(symbol) == 6:
                                trade_unit = 1
                            else:
                                trade_unit = 10000
                        else:
                            last_price = self.quote_data[symbol]['LastPrice']
                            trade_unit = self.get_symbol_trade_unit(symbol)

                        pnl = (sell_close_vol * (sell_close_avg_price - buy_open_avg_price) + (
                                buy_open_vol - sell_close_vol) * (last_price - buy_open_avg_price)) + \
                              (buy_close_vol * (sell_open_avg_price - buy_close_avg_price) + (
                                      sell_open_vol - buy_close_vol) * (sell_open_avg_price - last_price))
                        pnl = pnl * trade_unit
                        vid_pos += ((buy_open_vol + buy_close_vol) - (sell_open_vol + sell_close_vol))
                        account_pos += ((buy_open_vol + buy_close_vol) - (sell_open_vol + sell_close_vol))
                        vid_vol += total_trade_vol
                        account_vol += total_trade_vol
                        if not symbol.isdigit() or len(symbol) != 6:
                            total_vol += total_trade_vol

                        history_long_vol = 0
                        history_short_vol = 0
                        if (account, symbol, vstrategy_id) in history_position:
                            history_position[(account, symbol, vstrategy_id)]['used'] = 1
                            history_long_vol = history_position[(account, symbol, vstrategy_id)].get('long', 0)
                            history_short_vol = history_position[(account, symbol, vstrategy_id)].get('short', 0)
                            vid_pos += (history_long_vol - history_short_vol)
                            account_pos += (history_long_vol - history_short_vol)
                            settle_price = future_settleprice.get(symbol, 0)
                            if settle_price != 0:
                                history_pnl = (last_price - settle_price) * (history_long_vol - history_short_vol)
                                pnl += history_pnl

                        vid_pnl += pnl
                        account_pnl += pnl
                        total_pnl += pnl

                        # FeeRate  j,jm:0.0000468, ma:0.129, bu:0.000078
                        # if re.findall(r'[A-Za-z]+|\d+', symbol)[0].lower() in ['j', 'jm'] and account in ['80003079',
                        #                                                                                  '96699956']:
                        #    fee_rate = 0.0000492
                        #    fee = self.get_symbol_simu_fee(symbol, trade_unit, total_trade_vol, total_trade_amount,
                        #                                   fee_rate=fee_rate)
                        # elif re.findall(r'[A-Za-z]+|\d+', symbol)[0].lower() in ['ma'] and account in ['96699967']:
                        #    fee_rate = 0.1545
                        #    fee = self.get_symbol_simu_fee(symbol, trade_unit, total_trade_vol, total_trade_amount,
                        #                                   fee_rate=fee_rate)
                        # else:
                        #    fee = self.get_symbol_simu_fee(symbol, trade_unit, total_trade_vol, total_trade_amount)
                        fee = self.get_symbol_simu_fee(symbol, trade_unit, total_trade_vol, total_trade_amount)
                        if symbol.isdigit() and len(symbol) == 6:
                            fee_info_d = {}
                            try:
                                self.kdb.get_cb_rank(trading_date_str, '%s.SZ' % symbol)
                                fee_info_d = self.future_simu_fee_data['CBSZ']
                            except:
                                try:
                                    self.kdb.get_cb_rank(trading_date_str, '%s.SH' % symbol)
                                    fee_info_d = self.future_simu_fee_data['CBSH']
                                except:
                                    pass
                            if fee_info_d:
                                if fee_info_d['FeeMode']:
                                    fee = total_trade_vol * fee_info_d.get('SimuFee', 0) * trade_unit
                                else:
                                    fee = total_trade_amount * fee_info_d.get('SimuFee', 0) * trade_unit

                        vid_fee += fee
                        account_fee += fee
                        total_fee += fee
                        net = pnl - fee
                        vid_net += net
                        account_net += net
                        total_net += net

                        ret['accounts'][account]['vids'][vstrategy_id]['detail'][symbol] = {
                            'long_vol': buy_open_vol - sell_close_vol + history_long_vol,
                            'short_vol': sell_open_vol - buy_close_vol + history_short_vol,
                            'place_order_num': 0,
                            'cancel_order_num': 0,
                            'trade_vol': total_trade_vol,
                            'pnl': round(pnl),
                            'fee': round(fee),
                            'net': round(net),
                        }

                    ret['accounts'][account]['vids'][vstrategy_id]['pnl'] = round(vid_pnl)
                    ret['accounts'][account]['vids'][vstrategy_id]['fee'] = round(vid_fee)
                    ret['accounts'][account]['vids'][vstrategy_id]['net'] = round(vid_net)
                    ret['accounts'][account]['vids'][vstrategy_id]['vol'] = vid_pos
                    ret['accounts'][account]['vids'][vstrategy_id]['trade_vol'] = vid_vol
                    ret['accounts'][account]['vids'][vstrategy_id]['place_order_num'] = 0
                    ret['accounts'][account]['vids'][vstrategy_id]['cancel_order_num'] = 0
                    v_account_id = None if vstrategy_id == 0 else vstrategy_id
                    # v_account_id = vstrategy_id
                    ret['accounts'][account]['vids'][vstrategy_id]['strategy'] = ','.join(
                        dim_cfgs.get(v_account_id, []))
                    ret['accounts'][account]['vids'][vstrategy_id]['exchange'] = exchange

                for key, item in history_position.items():
                    if account != key[0]:
                        continue
                    if item['used'] == 1:
                        continue
                    # if key[0] not in ret['accounts']:
                    #    continue

                    pnl = 0
                    settle_price = future_settleprice.get(key[1], 0)
                    if settle_price != 0:
                        pnl = (self.quote_data[key[1]]['LastPrice'] - settle_price) * (item['long'] - item['short'])

                    account_pnl += pnl
                    total_pnl += pnl
                    fee = 0
                    net = pnl - fee
                    account_net += net
                    total_net += net

                    if key[2] not in ret['accounts'][key[0]]['vids']:
                        ret['accounts'][key[0]]['vids'].setdefault(key[2], {'pnl': 0, 'detail': {}, 'last_time': '',
                                                                            'exchange': exchange})

                    ret['accounts'][key[0]]['vids'][key[2]]['detail'][key[1]] = {
                        'long_vol': item['long'],
                        'short_vol': item['short'],
                        'place_order_num': 0,
                        'cancel_order_num': 0,
                        'trade_vol': 0,
                        'pnl': round(pnl),
                        'fee': round(fee),
                        'net': round(net),
                    }

                ret['accounts'][account]['pnl'] = round(account_pnl)
                ret['accounts'][account]['fee'] = round(account_fee)
                ret['accounts'][account]['net'] = round(account_net)
                ret['accounts'][account]['vol'] = account_pos
                ret['accounts'][account]['trade_vol'] = account_vol
                ret['accounts'][account]['place_order_num'] = 0
                ret['accounts'][account]['cancel_order_num'] = 0
                ret['accounts'][account]['strategy'] = ''
                ret['accounts'][account]['exchange'] = exchange

            ret['total_pnl'] = round(total_pnl)
            ret['total_fee'] = round(total_fee)
            ret['total_net'] = round(total_net)
            ret['total_trade_vol'] = round(total_vol)

            for r in order_logs:
                if r.account not in ret['accounts'] or \
                        r.vstrategy_id not in ret['accounts'][r.account]['vids'] or \
                        r.symbol not in ret['accounts'][r.account]['vids'][r.vstrategy_id]['detail']:
                    continue
                if r.entrust_status == 's':
                    ret['accounts'][r.account]['vids'][r.vstrategy_id]['detail'][r.symbol]['place_order_num'] = r.num
                    ret['accounts'][r.account]['vids'][r.vstrategy_id]['place_order_num'] = \
                        ret['accounts'][r.account]['vids'][r.vstrategy_id].get('place_order_num', 0) + r.num
                    ret['accounts'][r.account]['place_order_num'] = ret['accounts'][r.account].get('place_order_num',
                                                                                                   0) + r.num
                elif r.entrust_status == 'd':
                    ret['accounts'][r.account]['vids'][r.vstrategy_id]['detail'][r.symbol]['cancel_order_num'] = r.num
                    ret['accounts'][r.account]['vids'][r.vstrategy_id]['cancel_order_num'] = \
                        ret['accounts'][r.account]['vids'][r.vstrategy_id].get('cancel_order_num', 0) + r.num
                    ret['accounts'][r.account]['cancel_order_num'] = ret['accounts'][r.account].get('cancel_order_num',
                                                                                                    0) + r.num

            for r in last_order_logs:
                if r.account not in ret['accounts'] or \
                        r.vstrategy_id not in ret['accounts'][r.account]['vids'] or \
                        r.symbol not in ret['accounts'][r.account]['vids'][r.vstrategy_id]['detail']:
                    continue
                if not r.last_time or ' ' not in r.last_time.strip():
                    l_time = ''
                else:
                    l_time = r.last_time.split(' ')[1]
                ret['accounts'][r.account]['vids'][r.vstrategy_id]['detail'][r.symbol]['last_time'] = l_time
                if l_time.split('.')[0] > ret['accounts'][r.account]['vids'][r.vstrategy_id].get('last_time', ''):
                    ret['accounts'][r.account]['vids'][r.vstrategy_id]['last_time'] = l_time.split('.')[0]
                if l_time.split('.')[0] > ret['accounts'][r.account].get('last_time', ''):
                    ret['accounts'][r.account]['last_time'] = l_time.split('.')[0]

                # check if now - last time > one hour
                if ret['accounts'][r.account]['vids'][r.vstrategy_id]['last_time']:
                    _now = datetime.datetime.now()
                    _l_time = parse(ret['accounts'][r.account]['vids'][r.vstrategy_id]['last_time'])
                    if (_now > _l_time and (_now - _l_time).seconds > 3600) or \
                            (_now < _l_time and (_l_time - _now).seconds > 30):
                        ret['accounts'][r.account]['vids'][r.vstrategy_id]['warn'] = 1
                    else:
                        ret['accounts'][r.account]['vids'][r.vstrategy_id]['warn'] = 0
                if ret['accounts'][r.account]['last_time']:
                    _now = datetime.datetime.now()
                    _l_time = parse(ret['accounts'][r.account]['last_time'])
                    if (_now > _l_time and (_now - _l_time).seconds > 3600) or \
                            (_now < _l_time and (_l_time - _now).seconds > 30):
                        ret['accounts'][r.account]['warn'] = 1
                    else:
                        ret['accounts'][r.account]['warn'] = 0

            warn_accounts = set()
            for _a, item in ret['accounts'].items():
                for _, m in item['vids'].items():
                    if m.get('warn', 0) == 1:
                        warn_accounts.add(_a)
                        break
            for _a in warn_accounts:
                ret['accounts'][_a]['warn'] = 1

            if account_list is None:
                for r in all_accounts:
                    last_cfg = self.sc.query(DIMPreConfs).filter(
                        DIMPreConfs.account == r.name,
                        DIMPreConfs.status == 1,
                    ).order_by(
                        DIMPreConfs.id.desc()
                    ).first()
                    if last_cfg:
                        exchange = last_cfg.exchange
                    else:
                        exchange = 'UNKNOWN'
                    if r.name not in ret['accounts'] and '_' not in r.name:
                        ret['accounts'][r.name] = {'vids': {}, 'pnl': 0, 'fee': 0, 'net': 0, 'last_time': '',
                                                   'trade_vol': 0, 'vol': 0, 'exchange': exchange}

            return self.account_dict_to_list(ret)

        
        elif category == 2:
            ret = {'total_pnl': 0, 'symbols': {}}
            total_pnl = 0
            total_fee = 0
            total_net = 0
            total_vol = 0

            self.get_live_quote_turnover()

            if product:
                trade_logs = trade_logs.filter(TuringTradeLogs.symbol.like(str(product) + "%"))
                order_logs = order_logs.filter(TuringTradeLogs.symbol.like(str(product) + "%"))

            for record in trade_logs:
                k = '%s-%s' % (record.account, record.vstrategy_id)
                data.setdefault(record.symbol, {})
                data[record.symbol].setdefault(k, [])
                data[record.symbol][k].append(record)

            exchg_cfg = {}
            last_cfg = self.sc.query(DIMPreConfs).filter(
                DIMPreConfs.day_night == day_night,
                DIMPreConfs.status == 1,
            ).order_by(
                DIMPreConfs.id.desc()
            ).first()
            if last_cfg:
                uid = last_cfg.uid
                for cfg in self.sc.query(DIMPreConfs).filter(
                        # DIMPreConfs.day_night == day_night,
                        DIMPreConfs.uid == uid,
                ):
                    exchg_cfg[cfg.product] = cfg.exchange

            for symbol, sym_detail in data.items():
                exchange = 'UNKNOWN'
                if symbol.isdigit():
                    if len(symbol) == 6:
                        product = "CB"
                    else:
                        product = "CP50ETF"
                else:
                    product = re.findall(r'[A-Za-z]+|\d+', symbol)[0]
                    if product.lower() in exchg_cfg:
                        exchange = exchg_cfg[product.lower()]
                    elif product.upper() in exchg_cfg:
                        exchange = exchg_cfg[product.upper()]

                history_position = {}
                future_settleprice = {}
                if exchange in ["SHFE", "DCE", "CZCE"]:
                    yesterday = pre_trading_date_str + " 20:00:00"
                    # yesterday_end = pre_trading_date_str + " 23:59:59"
                    yesterday_end = trading_date_str + " 14:59:59"
                    position_logs = self.sc.query(TuringPositionLogs).filter(
                        TuringPositionLogs.symbol == symbol,
                        TuringPositionLogs.r_create_time >= yesterday,
                        TuringPositionLogs.r_create_time <= yesterday_end,
                    )
                else:
                    today = trading_date_str + " 08:00:00"
                    today_end = trading_date_str + " 14:59:59"
                    position_logs = self.sc.query(TuringPositionLogs).filter(
                        TuringPositionLogs.symbol == symbol,
                        TuringPositionLogs.r_create_time >= today,
                        TuringPositionLogs.r_create_time <= today_end,
                    )

                for pos in position_logs:
                    if pos.td_long_pos == 0 and pos.td_short_pos == 0:
                        continue
                    key = (pos.account, pos.symbol, pos.vstrategy_id)
                    if key not in history_position:
                        history_position.setdefault(key, {'long': 0, 'short': 0, 'used': 0})
                        history_position[key]['long'] = pos.td_long_pos
                        history_position[key]['short'] = pos.td_short_pos

                    if pos.symbol not in future_settleprice:
                        if not pos.symbol.isdigit():
                            future_settleprice[pos.symbol] = self.kdb.get_symbol_settleprice(pre_trading_date_str,
                                                                                             pos.symbol).get(
                                'settle_price', 0)

                ret['symbols'].setdefault(symbol, {'pnl': 0, 'detail': {}})
                symbol_pnl = 0
                symbol_fee = 0
                symbol_net = 0
                symbol_pos = 0
                symbol_vol = 0
                if symbol.isdigit():
                    tradeprice_obj = self.sc.query(TuringTradeLogs.trade_price).filter(
                        TuringTradeLogs.log_type == '3',
                        TuringTradeLogs.trading_date == trading_date_str,
                        TuringTradeLogs.symbol == symbol,
                    ).order_by(TuringTradeLogs.id.desc()).first()
                    if tradeprice_obj:
                        last_price = float(tradeprice_obj.trade_price)
                    else:
                        last_price = 0
                    if len(symbol) == 6:
                        trade_unit = 1
                    else:
                        trade_unit = 10000
                else:
                    last_price = self.quote_data[symbol]['LastPrice']
                    trade_unit = self.get_symbol_trade_unit(symbol)
                for k, details in sym_detail.items():
                    account, vstrategy_id = k.split('-')
                    vstrategy_id = int(vstrategy_id)
                    buy_open_vol = 0
                    buy_open_avg_price = 0
                    sell_close_vol = 0
                    sell_close_avg_price = 0
                    sell_open_vol = 0
                    sell_open_avg_price = 0
                    buy_close_vol = 0
                    buy_close_avg_price = 0
                    total_trade_vol = 0
                    total_trade_amount = 0
                    for d in details:
                        if d.open_close == 0 and d.direction == 0:
                            if int(d.trade_vol) == 0:
                                continue
                            buy_open_vol = int(d.trade_vol)
                            buy_open_avg_price = float(d.trade_amount) / int(d.trade_vol)
                            total_trade_vol += int(d.trade_vol)
                            total_trade_amount += float(d.trade_amount)
                        elif d.open_close == 1 and d.direction == 1:
                            if int(d.trade_vol) == 0:
                                continue
                            sell_close_vol = int(d.trade_vol)
                            sell_close_avg_price = float(d.trade_amount) / int(d.trade_vol)
                            total_trade_vol += int(d.trade_vol)
                            total_trade_amount += float(d.trade_amount)
                        elif d.open_close == 0 and d.direction == 1:
                            if int(d.trade_vol) == 0:
                                continue
                            sell_open_vol = int(d.trade_vol)
                            sell_open_avg_price = float(d.trade_amount) / int(d.trade_vol)
                            total_trade_vol += int(d.trade_vol)
                            total_trade_amount += float(d.trade_amount)
                        elif d.open_close == 1 and d.direction == 0:
                            if int(d.trade_vol) == 0:
                                continue
                            buy_close_vol = int(d.trade_vol)
                            buy_close_avg_price = float(d.trade_amount) / int(d.trade_vol)
                            total_trade_vol += int(d.trade_vol)
                            total_trade_amount += float(d.trade_amount)
                    pnl = (sell_close_vol * (sell_close_avg_price - buy_open_avg_price) + (
                            buy_open_vol - sell_close_vol) * (last_price - buy_open_avg_price)) + \
                          (buy_close_vol * (sell_open_avg_price - buy_close_avg_price) + (
                                  sell_open_vol - buy_close_vol) * (sell_open_avg_price - last_price))
                    pnl = pnl * trade_unit
                    symbol_pos += ((buy_open_vol + buy_close_vol) - (sell_open_vol + sell_close_vol))
                    symbol_vol += total_trade_vol
                    if not symbol.isdigit() or len(symbol) != 6:
                        total_vol += total_trade_vol

                    history_long_vol = 0
                    history_short_vol = 0
                    if (account, symbol, vstrategy_id) in history_position:
                        history_position[(account, symbol, vstrategy_id)]['used'] = 1
                        history_long_vol = history_position[(account, symbol, vstrategy_id)].get('long', 0)
                        history_short_vol = history_position[(account, symbol, vstrategy_id)].get('short', 0)
                        symbol_pos += (history_long_vol - history_short_vol)
                        settle_price = future_settleprice.get(symbol, 0)
                        if settle_price != 0:
                            history_pnl = (last_price - settle_price) * (history_long_vol - history_short_vol)
                            pnl += history_pnl

                    symbol_pnl += pnl
                    total_pnl += pnl

                    # FeeRate  j,jm:0.0000468, ma:0.129, bu:0.000078
                    # if re.findall(r'[A-Za-z]+|\d+', symbol)[0].lower() in ['j', 'jm'] and account in ['80003079',
                    #                                                                                  '96699956']:
                    #    fee_rate = 0.0000492
                    #    fee = self.get_symbol_simu_fee(symbol, trade_unit, total_trade_vol, total_trade_amount,
                    #                                   fee_rate=fee_rate)
                    # elif re.findall(r'[A-Za-z]+|\d+', symbol)[0].lower() in ['ma'] and account in ['96699967']:
                    #    fee_rate = 0.1545
                    #    fee = self.get_symbol_simu_fee(symbol, trade_unit, total_trade_vol, total_trade_amount,
                    #                                   fee_rate=fee_rate)
                    # else:
                    #    fee = self.get_symbol_simu_fee(symbol, trade_unit, total_trade_vol, total_trade_amount)
                    fee = self.get_symbol_simu_fee(symbol, trade_unit, total_trade_vol, total_trade_amount)
                    if symbol.isdigit() and len(symbol) == 6:
                        fee_info_d = {}
                        try:
                            self.kdb.get_cb_rank(trading_date_str, '%s.SZ' % symbol)
                            fee_info_d = self.future_simu_fee_data['CBSZ']
                        except:
                            try:
                                self.kdb.get_cb_rank(trading_date_str, '%s.SH' % symbol)
                                fee_info_d = self.future_simu_fee_data['CBSH']
                            except:
                                pass
                        if fee_info_d:
                            if fee_info_d['FeeMode']:
                                fee = total_trade_vol * fee_info_d.get('SimuFee', 0) * trade_unit
                            else:
                                fee = total_trade_amount * fee_info_d.get('SimuFee', 0) * trade_unit

                    symbol_fee += fee
                    total_fee += fee
                    net = pnl - fee
                    symbol_net += net
                    total_net += net

                    ret['symbols'][symbol]['detail'][k] = {
                        'long_vol': buy_open_vol - sell_close_vol + history_long_vol,
                        'short_vol': sell_open_vol - buy_close_vol + history_short_vol,
                        'place_order_num': 0,
                        'cancel_order_num': 0,
                        'trade_vol': total_trade_vol,
                        'pnl': round(pnl),
                        'fee': round(fee),
                        'net': round(net),
                        'turnover_ratio': '%.4f' % (round(total_trade_vol / self.turnover_data[symbol],
                                                          4) if symbol in self.turnover_data else 0.0000),
                    }

                for key, item in history_position.items():
                    if symbol != key[1]:
                        continue
                    if item['used'] == 1:
                        continue
                    # if key[1] not in ret['symbols']:
                    #    continue

                    pnl = 0
                    settle_price = future_settleprice.get(key[1], 0)
                    if settle_price != 0:
                        pnl = (self.quote_data[key[1]]['LastPrice'] - settle_price) * (item['long'] - item['short'])

                    symbol_pnl += pnl
                    total_pnl += pnl
                    fee = 0
                    net = pnl - fee
                    symbol_net += net
                    total_net += net

                    ret['symbols'][key[1]]['detail']['%s-%s' % (key[0], key[2])] = {
                        'long_vol': item['long'],
                        'short_vol': item['short'],
                        'place_order_num': 0,
                        'cancel_order_num': 0,
                        'trade_vol': 0,
                        'pnl': round(pnl),
                        'fee': round(fee),
                        'net': round(net),
                        'turnover_ratio': '%.4f' % 0,
                    }
                if symbol.isdigit():
                    if len(symbol) == 6:
                        try:
                            symbol_rank = self.kdb.get_cb_rank(trading_date_str, '%s.SZ' % symbol)
                        except:
                            symbol_rank = self.kdb.get_cb_rank(trading_date_str, '%s.SH' % symbol)
                            
                    else:
                        symbol_rank = self.kdb.get_option_rank(trading_date_str, symbol)
                else:
                    symbol_rank = self.kdb.get_symbol_rank(trading_date_str, symbol)

                ret['symbols'][symbol]['pnl'] = round(symbol_pnl)
                ret['symbols'][symbol]['fee'] = round(symbol_fee)
                ret['symbols'][symbol]['net'] = round(symbol_net)
                ret['symbols'][symbol]['vol'] = symbol_pos
                ret['symbols'][symbol]['trade_vol'] = symbol_vol
                ret['symbols'][symbol]['place_order_num'] = 0
                ret['symbols'][symbol]['cancel_order_num'] = 0
                ret['symbols'][symbol]['turnover_ratio'] = '%.4f' % (
                    round(symbol_vol / self.turnover_data[symbol], 4) if symbol in self.turnover_data else 0.0000)
                ret['symbols'][symbol]['symbol_rank'] = 'R%s' % symbol_rank
            ret['total_pnl'] = round(total_pnl)
            ret['total_fee'] = round(total_fee)
            ret['total_net'] = round(total_net)
            ret['total_trade_vol'] = round(total_vol)

            for r in order_logs:
                k = '%s-%s' % (r.account, r.vstrategy_id)
                if r.symbol not in ret['symbols'] or k not in ret['symbols'][r.symbol]['detail']:
                    continue
                if r.entrust_status == 's':
                    ret['symbols'][r.symbol]['detail'][k]['place_order_num'] = r.num
                    ret['symbols'][r.symbol]['place_order_num'] = ret['symbols'][r.symbol].get('place_order_num',
                                                                                               0) + r.num
                elif r.entrust_status == 'd':
                    ret['symbols'][r.symbol]['detail'][k]['cancel_order_num'] = r.num
                    ret['symbols'][r.symbol]['cancel_order_num'] = ret['symbols'][r.symbol].get('cancel_order_num',
                                                                                                0) + r.num

            for r in last_order_logs:
                k = '%s-%s' % (r.account, r.vstrategy_id)
                if r.symbol not in ret['symbols'] or k not in ret['symbols'][r.symbol]['detail']:
                    continue
                if not r.last_time or ' ' not in r.last_time.strip():
                    l_time = ''
                else:
                    l_time = r.last_time.split(' ')[1]
                ret['symbols'][r.symbol]['detail'][k]['last_time'] = l_time

        return ret


    def get_reject_order(self, account=None):
        ret = []

        trading_date = self.kdb.get_trading_date(hour=21)
        trading_date = parse(trading_date)
        trading_date_str = trading_date.strftime('%Y-%m-%d')

        trade_logs = self.sc.query(TuringTradeLogs).filter(
            # TuringTradeLogs.vstrategy_id == self.vstrategy_id,
            TuringTradeLogs.entrust_status.in_(['e', 'i']),
            TuringTradeLogs.trading_date == trading_date_str,
        ).order_by(
            TuringTradeLogs.calendar_date,
            TuringTradeLogs.calendar_time,
            TuringTradeLogs.calendar_microsec,
        )

        if account:
            trade_logs = trade_logs.filter(TuringTradeLogs.account == account)

        for record in trade_logs:
            ret.append(record.to_dict())

        return ret

    def calc_order_delay(self, server, cpu_freq, delay, trade_date=None):
        if trade_date:
            trading_date = parse(trade_date)
        else:
            trading_date = self.kdb.get_trading_date(hour=21)
            trading_date = parse(trading_date)
        trading_date_str = trading_date.strftime('%Y-%m-%d')

        if datetime.datetime.now().hour < 21 and datetime.datetime.now().hour >= 9:
            day_night = 0
        else:
            day_night = 1

        trade_logs = self.sc.query(
            TuringTradeLogs.server.label('server'),
            TuringTradeLogs.account.label('account'),
            TuringTradeLogs.symbol.label('symbol'),
            TuringTradeLogs.serial_no.label('serial_no'),
            TuringTradeLogs.log_type.label('log_type'),
            TuringTradeLogs.quote_trigger.label('quote_trigger'),
            TuringTradeLogs.rdtsc.label('rdtsc'),
            TuringTradeLogs.entrust_no.label('entrust_no'),
        ).filter(
            # TuringTradeLogs.vstrategy_id == self.vstrategy_id,
            TuringTradeLogs.log_type.in_(['0', '2', '3']),
            TuringTradeLogs.serial_no != '00000000000000000000',
            TuringTradeLogs.entrust_status != 'e',
            TuringTradeLogs.trading_date == trading_date_str,
            TuringTradeLogs.day_night == day_night,
            TuringTradeLogs.server == server,
        ).group_by(
            TuringTradeLogs.serial_no,
            TuringTradeLogs.account,
            TuringTradeLogs.symbol,
            TuringTradeLogs.log_type,
            TuringTradeLogs.quote_trigger,
            TuringTradeLogs.rdtsc,
            TuringTradeLogs.entrust_no,
        )

        orders = {}
        for record in trade_logs:
            key = (record.server, record.account, record.serial_no)
            if key not in orders:
                orders[key] = {
                    'server': record.server,
                    'account': record.account,
                    'symbol': record.symbol,
                    'serial_no': record.serial_no,
                    'trigger': 0, 'entrust_no': 0,
                    't0': 0, 't1': 0, 't2': 0,
                    'delay': '0.00 ms',
                }
            if record.log_type == '0':
                orders[key]['trigger'] = record.quote_trigger
                orders[key]['t0'] = int(record.rdtsc)
            elif record.log_type == '2':
                if orders[key]['t1'] == 0:
                    orders[key]['entrust_no'] = record.entrust_no
                    orders[key]['t1'] = int(record.rdtsc)
                elif orders[key]['t1'] != 0 and record.rdtsc < orders[key]['t1']:
                    orders[key]['t1'] = int(record.rdtsc)
            elif record.log_type == '3':
                if orders[key]['t2'] == 0:
                    orders[key]['t2'] = int(record.rdtsc)
                elif orders[key]['t2'] != 0 and record.rdtsc < orders[key]['t2']:
                    orders[key]['t2'] = int(record.rdtsc)

        ret = []
        for k, v in orders.items():
            if v['t2'] == 0:
                v['t2'] = v['t0']

            # check if broker delay exceed threshold
            if (v['t1'] - v['t0']) / cpu_freq / 1000 >= delay:
                ret.append({
                    'server': v['server'],
                    'account': v['account'],
                    'symbol': v['symbol'],
                    'serial_no': v['serial_no'],
                    'entrust_no': v['entrust_no'],
                    'trigger': v['trigger'],
                    'delay': '%.2f ms' % ((v['t1'] - v['t0']) / cpu_freq / 1000),
                    'type': 'broker delay',
                })
            # else:
            #    # check if exchange delay exceed threshold
            #    if (v['t2'] - v['t0']) // cpu_freq >= delay:
            #        ret.append({
            #            'server': v['server'],
            #            'account': v['account'],
            #            'symbol': v['symbol'],
            #            'serial_no': v['serial_no'],
            #            'entrust_no': v['entrust_no'],
            #            'trigger': v['trigger'],
            #            'delay': '%s us' % ((v['t2'] - v['t0']) // cpu_freq),
            #            'type': 'exchange delay',
            #        })

        ret = sorted(ret, key=lambda x: float(x['delay'].replace(' ms', '')), reverse=True)
        return ret

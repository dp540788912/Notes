# -*-coding:utf-8-*-

from dateutil.parser import parse
from sqlalchemy import func

from service.back_test.live_position_models import VsPosition, VsBase, VsAccount
from service.back_test.models import VStrategyAccountDetail

from db import session
from kdb_query import KdbQuery

interest_reback = {
    '20190506': 49306.56,
    '20190603': 49297.32,
    '20190701': 70199.448,
    '20190801': 71398,
    '20190902': 54778,
    '20191008': 62857,
}


def cicc_interest(trading_date, account='0148PT0420'):
    sc = session()

    last_position = sc.query(
        VsPosition
    ).filter(
        VsPosition.settle_date == trading_date,
        VsPosition.account == account,
        VsPosition.daynight == 'NIGHT',
    )

    total_position = 0
    for l in last_position:
        total_position += (float(l.today_long_pos) * float(l.today_settle_price))

    sc.close()

    kdb = KdbQuery()

    nebor_trading_dates = kdb.get_nebor_trading_date(trading_date)
    prev_trading_date = nebor_trading_dates['prev']

    hibor_1m = kdb.get_hibor_1m(prev_trading_date)

    return interest_reback.get(trading_date, 0) - total_position * (hibor_1m / 100 + 0.01) * (
        (parse(trading_date) - parse(prev_trading_date)).days) / 365


def settle_cicc_interest_vs(vs_id, trading_date, day_night, account='0148PT0420'):
    kdb = KdbQuery()
    nebor_trading_dates = kdb.get_nebor_trading_date(trading_date)
    prev_trading_date = nebor_trading_dates['prev']
    next_trading_date = nebor_trading_dates['next']

    sc = session()

    last_settle = sc.query(VsBase).filter(
        VsBase.vstrategy_id == vs_id,
        VsBase.settle_date == prev_trading_date,
        VsBase.daynight == 'DAY'
    ).first()
    if last_settle:
        last_total_asset = float(last_settle.total_asset)
        accumulated_pnl = float(last_settle.accumulated_pnl)
    else:
        last_total_asset = float(sc.query(func.sum(VStrategyAccountDetail.amount)).filter(
            VStrategyAccountDetail.vstrategy_id == vs_id,
            VStrategyAccountDetail.trading_date.is_(None)
        ).first()[0])
        if not last_total_asset:
            last_total_asset = 0
        accumulated_pnl = 0

    if day_night == 0:
        interest = cicc_interest(trading_date, account)
        cash_io = sc.query(func.sum(VStrategyAccountDetail.amount)).filter(
            VStrategyAccountDetail.vstrategy_id == vs_id,
            VStrategyAccountDetail.trading_date == next_trading_date,
        ).first()[0]
        if not cash_io:
            cash_io = 0
        cash_io = float(cash_io)
    else:
        interest = 0
        cash_io = 0

    day_night_str = {
        0: 'DAY',
        1: 'NIGHT',
    }[day_night]

    old_vs_base = sc.query(VsBase).filter(
        VsBase.vstrategy_id == vs_id,
        VsBase.settle_date == trading_date,
        VsBase.daynight == day_night_str
    )
    old_vs_account = sc.query(VsAccount).filter(
        VsAccount.vstrategy_id == vs_id,
        VsAccount.settle_date == trading_date,
        VsAccount.daynight == day_night_str
    )
    old_vs_base.delete(synchronize_session=False)
    old_vs_account.delete(synchronize_session=False)

    today_total_asset = last_total_asset + interest + cash_io

    today_vs_base = VsBase(
        vstrategy_id=vs_id,
        cash=today_total_asset,
        accumulated_pnl=accumulated_pnl + interest,
        settle_date=trading_date,
        daynight=day_night_str,
        available_cash=today_total_asset,
        asset_cash=today_total_asset,
        defer_fee=0,
        fee=0,
        pnl=interest,
        position_cash=0,
        total_asset=today_total_asset,
        dividend=0,
    )
    today_vs_account = VsAccount(
        vstrategy_id=vs_id,
        account=account,
        settle_date=trading_date,
        cash=today_total_asset,
        accumulated_pnl=accumulated_pnl + interest,
        daynight=day_night_str,
        available_cash=today_total_asset,
        asset_cash=today_total_asset,
        defer_fee=0,
        fee=0,
        pnl=interest,
        position_cash=0,
        total_asset=today_total_asset,
        dividend=0,
        currency='CNY',
        forex_rate=1.0,
    )
    sc.add(today_vs_base)
    sc.add(today_vs_account)
    sc.commit()
    sc.close()

    return True

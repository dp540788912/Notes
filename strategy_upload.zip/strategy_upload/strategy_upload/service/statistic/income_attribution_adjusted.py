# -*-coding:utf-8-*-

import pandas as pd
import numpy as np
import base64
import json
import copy


def data_cleansing(rtn):
    tmp = copy.deepcopy(rtn)
    tmp.reset_index(drop=True, inplace=True)
    tmp.rename(columns={'trading_date': 'date',
                        'hy_sws_801010': '801010.SWS', 'hy_sws_801020': '801020.SWS', 'hy_sws_801030': '801030.SWS',
                        'hy_sws_801040': '801040.SWS', 'hy_sws_801050': '801050.SWS', 'hy_sws_801080': '801080.SWS',
                        'hy_sws_801110': '801110.SWS', 'hy_sws_801120': '801120.SWS', 'hy_sws_801130': '801130.SWS',
                        'hy_sws_801140': '801140.SWS', 'hy_sws_801150': '801150.SWS', 'hy_sws_801160': '801160.SWS',
                        'hy_sws_801170': '801170.SWS', 'hy_sws_801180': '801180.SWS', 'hy_sws_801200': '801200.SWS',
                        'hy_sws_801210': '801210.SWS', 'hy_sws_801230': '801230.SWS', 'hy_sws_801710': '801710.SWS',
                        'hy_sws_801720': '801720.SWS', 'hy_sws_801730': '801730.SWS', 'hy_sws_801740': '801740.SWS',
                        'hy_sws_801750': '801750.SWS', 'hy_sws_801760': '801760.SWS', 'hy_sws_801770': '801770.SWS',
                        'hy_sws_801780': '801780.SWS', 'hy_sws_801790': '801790.SWS', 'hy_sws_801880': '801880.SWS',
                        'hy_sws_801890': '801890.SWS'},
               inplace=True)
    hset = ['801010.SWS', '801020.SWS', '801030.SWS', '801040.SWS', '801050.SWS',
            '801080.SWS', '801110.SWS', '801120.SWS', '801130.SWS', '801140.SWS',
            '801150.SWS', '801160.SWS', '801170.SWS', '801180.SWS', '801200.SWS',
            '801210.SWS', '801230.SWS', '801710.SWS', '801720.SWS', '801730.SWS',
            '801740.SWS', '801750.SWS', '801760.SWS', '801770.SWS', '801780.SWS',
            '801790.SWS', '801880.SWS', '801890.SWS']
    sset = ['bt', 'bd', 'mm', 'yl', 'jz', 'gg', 'ld']

    tmp = tmp[['date'] + hset + sset]
    tmp['date'] = [str(int(x)) for x in list(tmp['date'])]
    tmp.sort_values(by='date', inplace=True)
    tmp.reset_index(drop=True, inplace=True)

    return tmp, hset, sset


def data_computing(rtn, hset, sset, days=21):
    tmp = rtn[-days:]
    tmp.reset_index(drop=True, inplace=True)

    hys_tr = []
    sty_tr = []
    for i in hset + sset:
        tmp_a = list(tmp[i])
        if len(tmp_a) > 20:
            tmp_b = [tmp_a[x] * tmp_a[x + 1] > 0 for x in range(len(tmp_a) - 1)]
            tmp_1 = sum(tmp_b[-5:]) / 5
            tmp_2 = sum(tmp_b[-10:-5]) / 5
            tmp_3 = sum(tmp_b[-15:-10]) / 5
            tmp_4 = sum(tmp_b[-20:-15]) / 5
            tmp_5 = tmp_1 * 8 / 15 + tmp_2 * 4 / 15 + tmp_3 * 2 / 15 + tmp_4 * 1 / 15
        else:
            tmp_1 = 0.5
            tmp_5 = 0.5

        if i in hset:
            hys_tr = hys_tr + [[i, float(tmp[-1:][i]), tmp_5, tmp_1]]
        else:
            sty_tr = sty_tr + [[i, float(tmp[-1:][i]), tmp_5, tmp_1]]

    hys = pd.DataFrame(hys_tr, columns=['symbol', 'v', 'p', 'p1'])
    hys = hys.loc[hys['v'] < 0]
    hys.reset_index(drop=True, inplace=True)
    sty = pd.DataFrame(sty_tr, columns=['symbol', 'v', 'p', 'p1'])
    sty = sty.loc[sty['v'] < 0]
    sty.reset_index(drop=True, inplace=True)

    return hys, sty


def choosing_best(df, col, getmin=True, n=1):
    if col == 'p':
        df = copy.deepcopy(df.loc[(df['p1'] > 0.5) & (df['p'] > 0.55)])
        df['p'] = -df['p']
        col = ['p', 'v']

    rst = df.sort_values(by=col, ascending=getmin)['symbol'].tolist()[:n]

    return rst


def neutralizing_set(hys, sty, vh=0, vs=0, ph=0, ps=0):
    tmp = choosing_best(hys, 'v', getmin=True, n=vh) + choosing_best(sty, 'v', getmin=True, n=vs)

    hys2 = hys.loc[[x not in tmp for x in list(hys['symbol'])]]
    hys2.reset_index(drop=True, inplace=True)

    sty2 = sty.loc[[x not in tmp for x in list(sty['symbol'])]]
    sty2.reset_index(drop=True, inplace=True)

    tmp = tmp + choosing_best(hys2, 'p', getmin=True, n=ph) + choosing_best(sty2, 'p', getmin=True, n=ps)

    return tmp


def setup_myrisk3_1v(hys, sty):
    tmp = sty.loc[[x in ['bt', 'bd', 'mm', 'yl', 'jz'] for x in list(sty['symbol'])]]
    new_setup = neutralizing_set(hys, tmp, vh=0, vs=2, ph=0, ps=0)
    return new_setup


def setup_myrisk3_2v(hys, sty):
    new_setup = neutralizing_set(hys, sty, vh=1, vs=1, ph=3, ps=1)
    return new_setup


def setup_myrisk3_3v(hys, sty):
    new_setup = neutralizing_set(hys, sty, vh=0, vs=0, ph=2, ps=2)
    return new_setup


def setup_adjusted(date, rtn, quick_setup):
    rtn, hset, sset = data_cleansing(rtn)
    rtn = rtn.loc[rtn['date'] < str(date)]
    if len(rtn) < 1:
        new_setup = []
        return new_setup
    hys, sty = data_computing(rtn, hset, sset, days=21)

    tmp_d = json.loads(base64.b64decode(quick_setup).decode())
    model = tmp_d['model']

    new_setup = []

    if model in ['myrisk3', 'myrisk3_1v']:
        new_setup = setup_myrisk3_1v(hys, sty)
    if model == 'myrisk3_2v':
        new_setup = setup_myrisk3_2v(hys, sty)
    if model == 'myrisk3_3v':
        new_setup = setup_myrisk3_3v(hys, sty)

    return new_setup

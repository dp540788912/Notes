# -*-coding:utf-8-*-

import pandas as pd
import numpy as np
import json
import copy
from datetime import datetime
from dateutil.parser import parse
from qpython import qconnection

from db import session
from config import config

from extensions import sentry

# addr, port, user, pwd = "192.168.10.102", 9000, "user1", "password"

addr, port, user, pwd = config.KDB_HOST, config.KDB_PORT, config.KDB_USER, config.KDB_PASSWD


def get_trading_dates(start_date, end_date):
    with qconnection.QConnection(host=addr, port=port, username=user, password=pwd) as q:
        q.async(".gw.asyncexec[(`GetTradeDate;`SSE`SZSE;(%04d.%02d.%02d;%04d.%02d.%02d;%d));`EquityFactor]" % (
            int(start_date / 10000), int(start_date % 10000 / 100), start_date % 100, int(end_date / 10000),
            int(end_date % 10000 / 100), end_date % 100, 0))
        train_dates = q.receive(pandas=True)
    return train_dates


def datetoint(date):
    return date.year * 10000 + date.month * 100 + date.day


def live_yes_pos(row):
    if np.isnan(row['open_pos_x']):
        return 0
    else:
        return row['open_pos_x']


def sim_yes_pos(row):
    if np.isnan(row['open_pos_y']):
        return 0
    else:
        return row['open_pos_y']


def yes_close(row):
    # today_close are nonzero
    if np.isnan(row['open_pos_x']) or row['open_pos_x'] == 0:
        return row['pre_close_y']
    else:
        return row['pre_close_x']


def today_close(row):
    if np.isnan(row['open_pos_x']):
        return row['close_y']
    else:
        return row['close_x']


def diff_yespos(row):
    f1 = 0
    f2 = 0
    if np.isnan(row['open_pos_x']):
        # f1 = (row['open_pos_y']) * (row['sell_price_y'] - row['close_y']) * (0 if row['sell_volume_y'] == 0 else 1)
        # f2 = (row['open_pos_y']) * (row['close_y'] - row['buy_price_y']) * (0 if row['buy_volume_y'] == 0 else 1)
        return round(-((row['open_pos_y']) * (row['close_y'] - row['pre_close_y']) + f1 - f2), 2)
    elif np.isnan(row['open_pos_y']):
        # f1 = (-row['open_pos_x']) * (row['sell_price_x'] - row['close_x']) * (0 if row['sell_volume_x'] == 0 else 1)
        # f2 = (-row['open_pos_x']) * (row['close_x'] - row['buy_price_x']) * (0 if row['buy_volume_x'] == 0 else 1)
        return round(-(-(row['open_pos_x']) * (row['close_x'] - row['pre_close_x']) + f1 - f2), 2)
    else:
        # f1 = (row['open_pos_y'] - row['open_pos_x']) * (row['sell_price_y'] - row['close_x']) * (
        # 0 if row['sell_volume_y'] == row['sell_volume_x'] else 1)
        # f2 = (row['open_pos_y'] - row['open_pos_x']) * (row['close_x'] - row['buy_price_y']) * (
        # 0 if row['buy_volume_y'] == row['buy_volume_x'] else 1)
        return round(-((row['open_pos_y'] - row['open_pos_x']) * (
                row['close_x'] - max(row['pre_close_x'], row['pre_close_y'])) + f1 - f2), 2)


def live_today_pos(row):
    if np.isnan(row['close_pos_x']):
        return 0
    else:
        return row['close_pos_x']


def sim_today_pos(row):
    if np.isnan(row['close_pos_y']):
        return 0
    else:
        return row['close_pos_y']


def diff_tradevol(row):
    f1 = 0
    f2 = 0
    if np.isnan(row['open_pos_x']):
        # f1 = (row['open_pos_y']) * (row['sell_price_y'] - row['close_y']) * (0 if row['sell_volume_y'] == 0 else 1)
        # f2 = (row['open_pos_y']) * (row['close_y'] - row['buy_price_y']) * (0 if row['buy_volume_y'] == 0 else 1)
        return round(-((row['sell_volume_y'] - 0) * (row['sell_price_y'] - row['close_y']) \
                       + (row['buy_volume_y'] - 0) * (row['close_y'] - row['buy_price_y']) - f1 + f2), 2)
    elif np.isnan(row['open_pos_y']):
        # f1 = (-row['open_pos_x']) * (row['sell_price_x'] - row['close_x']) * (0 if row['sell_volume_x'] == 0 else 1)
        # f2 = (-row['open_pos_x']) * (row['close_x'] - row['buy_price_x']) * (0 if row['buy_volume_x'] == 0 else 1)
        return round(-((0 - row['sell_volume_x']) * (row['sell_price_x'] - row['close_x']) \
                       + (0 - row['buy_volume_x']) * (row['close_x'] - row['buy_price_x']) - f1 + f2), 2)
    else:
        # print(row['open_pos_y'], row['close_y'], row['pre_close_y'])
        # f1 = (row['open_pos_y'] - row['open_pos_x']) * (row['sell_price_y'] - row['close_x']) * (
        # 0 if row['sell_volume_y'] == row['sell_volume_x'] else 1)
        # f2 = (row['open_pos_y'] - row['open_pos_x']) * (row['close_x'] - row['buy_price_y']) * (
        # 0 if row['buy_volume_y'] == row['buy_volume_x'] else 1)
        # return round(-((row['sell_volume_y'] - row['sell_volume_x']) * (row['sell_price_y'] - row['close_x']) \
        #          + (row['buy_volume_y'] - row['buy_volume_x']) * (row['close_x'] - row['buy_price_y']) - f1 + f2), 2)

        # f1 = (row['open_pos_y'] - row['open_pos_x']) * (row['sell_price_y'] - row['close_x']) * (
        # 0 if row['sell_volume_y'] == row['sell_volume_x'] else 1)
        # f2 = (row['open_pos_y'] - row['open_pos_x']) * (row['close_x'] - row['buy_price_y']) * (
        # 0 if row['buy_volume_y'] == row['buy_volume_x'] else 1)

        if row['sell_price_y'] == 0 and row['sell_price_x'] != 0:
            return round(-((row['sell_volume_y'] - row['sell_volume_x']) * (row['sell_price_x'] - row['close_x']) \
                           + (row['buy_volume_y'] - row['buy_volume_x']) * (
                                   row['close_x'] - row['buy_price_y']) - f1 + f2), 2)
        elif row['buy_price_y'] == 0 and row['buy_price_x'] != 0:
            return round(-((row['sell_volume_y'] - row['sell_volume_x']) * (row['sell_price_y'] - row['close_x']) \
                           + (row['buy_volume_y'] - row['buy_volume_x']) * (
                                   row['close_x'] - row['buy_price_x']) - f1 + f2), 2)
        else:
            return round(-((row['sell_volume_y'] - row['sell_volume_x']) * (row['sell_price_y'] - row['close_x']) \
                           + (row['buy_volume_y'] - row['buy_volume_x']) * (
                                   row['close_x'] - row['buy_price_y']) - f1 + f2), 2)


def live_mkt_px(row):
    if np.isnan(row['MktDurationVWAP_x']):
        return 0
    else:
        return row['MktDurationVWAP_x']


def live_trade_px(row):
    if np.isnan(row['close_pos_x']):
        return 0
    elif (row['buy_volume_x'] + row['sell_volume_x']) == 0:
        return 0
    else:
        return (row['buy_price_x'] * row['buy_volume_x'] + row['sell_price_x'] * row['sell_volume_x']) / (
                row['buy_volume_x'] + row['sell_volume_x'])


def live_vwap_slippage(row):
    if np.isnan(row['MktDurationVWAP_x']):
        return 0
    elif row['MktDurationVWAP_x'] == 0:
        return 0
    else:
        return (row['MktDurationVWAP_x'] - row['live_trade_px']) / row['MktDurationVWAP_x'] * 10000 * (
            1 if row['buy_volume_x'] > 0 else -1)


def sim_mkt_px(row):
    if np.isnan(row['MktDurationVWAP_y']):
        return 0
    else:
        return row['MktDurationVWAP_y']


def sim_trade_px(row):
    if np.isnan(row['close_pos_y']):
        return 0
    elif row['buy_volume_y'] + row['sell_volume_y'] == 0:
        return 0
    else:
        return (row['buy_price_y'] * row['buy_volume_y'] + row['sell_price_y'] * row['sell_volume_y']) / (
                row['buy_volume_y'] + row['sell_volume_y'])


def sim_vwap_slippage(row):
    if np.isnan(row['MktDurationVWAP_y']):
        return 0
    elif row['MktDurationVWAP_y'] == 0:
        return 0
    else:
        if row['sim_trade_px'] > 0:
            return (row['MktDurationVWAP_y'] - row['sim_trade_px']) / row['MktDurationVWAP_y'] * 10000 * (
                1 if row['buy_volume_y'] > 0 else -1)
        else:
            return 0


def trade_vol(row):
    if np.isnan(row['close_pos_x']):
        return 0
    else:
        return row['buy_volume_x'] - row['sell_volume_x']


def diff_tradepx(row):
    if np.isnan(row['open_pos_x']):
        # print(row['open_pos_y'], row['close_y'], row['pre_close_y'])
        return 0
    elif np.isnan(row['open_pos_y']):
        return 0
    elif row['sell_price_y'] == 0 and row['sell_price_x'] != 0:
        return round(-((row['sell_price_x'] - row['sell_price_x']) * (row['sell_volume_x']) \
                       - (row['buy_price_y'] - row['buy_price_x']) * (row['buy_volume_x'])), 2)
    elif row['buy_price_y'] == 0 and row['buy_price_x'] != 0:
        return round(-((row['sell_price_y'] - row['sell_price_x']) * (row['sell_volume_x']) \
                       - (row['buy_price_x'] - row['buy_price_x']) * (row['buy_volume_x'])), 2)
    else:
        # print(row['open_pos_y'], row['close_y'], row['pre_close_y'])
        return round(-((row['sell_price_y'] - row['sell_price_x']) * (row['sell_volume_x']) \
                       - (row['buy_price_y'] - row['buy_price_x']) * (row['buy_volume_x'])), 2)


def diff_fee(row):
    if np.isnan(row['open_pos_x']):
        # print(row['open_pos_y'], row['close_y'], row['pre_close_y'])
        return -(0 - row['fee_y'])
    elif np.isnan(row['open_pos_y']):
        return -row['fee_x']
    else:
        # print(row['open_pos_y'], row['close_y'], row['pre_close_y'])
        return round(-(row['fee_x'] - row['fee_y']), 2)


def diff_dividend(row):
    if np.isnan(row['open_pos_x']):
        # print(row['open_pos_y'], row['close_y'], row['pre_close_y'])
        return -(row['dividend_y'])
    elif np.isnan(row['open_pos_y']):
        return -(-row['dividend_x'])
    else:
        # print(row['open_pos_y'], row['close_y'], row['pre_close_y'])
        return round(-(row['dividend_y'] - row['dividend_x']), 2)


from sqlalchemy import func

from service.back_test.live_position_models import VsPosition, PositionCorpActionsTable
from service.back_test.models import Strategy, VStrategies, TradeLogs, SettlementManualTradelog, \
    VstrategyBackTestResultDetail, BackTestTradeLogs

from service.vwap.models import VwapResult, VsVwapResult

from kdb_query import KdbQuery
import consts


class StockVsDiff(object):

    def __init__(self, vs_id, trading_date, **kwargs):
        self.vs_id = vs_id
        self.trading_date = parse(trading_date)
        self.trading_date_str = self.trading_date.strftime('%Y%m%d')
        self.kwargs = kwargs
        self.sc = session()
        self.kdb = KdbQuery()

        self.strategy = self.sc.query(
            Strategy
        ).join(
            VStrategies, VStrategies.strategy_id == Strategy.id
        ).filter(
            VStrategies.id == vs_id
        ).first()

        self.stock_close_price = self.kdb.get_stock_close_price(self.trading_date_str, 0)

        self.all_columns = [
            'symbol', 'live_yespos', 'sim_yespos', 'yes_close', 'today_close', 'diff_yespos', 'live_today_pos',
            'today_live_target_pos',
            'sim_today_pos', 'today_sim_target_pos', 'diff_tradevol', 'live_mkt_px', 'live_trade_px',
            'live_vwap_slippage', 'sim_mkt_px',
            'sim_trade_px', 'sim_vwap_slippage', 'trade_vol', 'diff_tradepx', 'diff_fee', 'diff_dividend', 'total',
        ]

        self.headers = [
            "股票代码", "实盘昨收仓位", "盘后昨收仓位", "昨收价", "今收价", "昨收仓位PNL", "实盘收盘仓位", '今实盘目标仓位', "盘后收盘仓位", '今盘后目标仓位',
            "今收仓位PNL", "实盘市场价格", "实盘交易价格", "实盘slippage", "盘后市场价格", "盘后交易价格", "盘后slippage",
            "交易数量", "交易价格PNL", "手续费差异", "分红差异", "总差异"
        ]

        self.highlight = [i for i, c in enumerate(self.all_columns) if
                          c in ['diff_yespos', 'diff_tradevol', 'diff_tradepx', 'diff_fee', 'diff_dividend']]

        self.col_index = {c: i for i, c in enumerate(self.all_columns)}

        self.sym_tmp = {
            'symbol': '',
            'open_pos': 0,
            'pre_close': 0,
            'close_pos': 0,
            'close': 0,
            'buy_volume': 0,
            'buy_price': 0,
            'buy_amount': 0,
            'sell_volume': 0,
            'sell_price': 0,
            'sell_amount': 0,
            'fee': 0,
            'dividend': 0,
            'pnl': 0,
        }

    def __del__(self):
        self.sc.close()
        self.kdb.release()

    def get_vs_live_df(self):
        positions = self.sc.query(VsPosition).filter(
            VsPosition.vstrategy_id == self.vs_id,
            VsPosition.settle_date == self.trading_date_str
        )
        symbol_detail = {}
        for pos in positions:
            symbol_d = symbol_detail.setdefault(pos.symbol, copy.deepcopy(self.sym_tmp))
            symbol_d['symbol'] = pos.symbol
            if pos.daynight == 'NIGHT':
                symbol_d['open_pos'] = pos.today_long_pos - pos.today_short_pos
                symbol_d['pre_close'] = round(float(pos.today_settle_price), 12)
            if pos.daynight == 'DAY':
                symbol_d['close_pos'] = pos.today_long_pos - pos.today_short_pos
                symbol_d['close'] = round(float(pos.today_settle_price), 12)
                symbol_d['pnl'] = round(float(pos.symbol_pnl), 2)
                symbol_d['fee'] = round(float(pos.symbol_fee), 2)

        trading_detail = self.sc.query(
            TradeLogs.symbol.label('symbol'),
            TradeLogs.direction.label('direction'),
            func.sum(TradeLogs.trade_vol).label('trade_vol'),
            func.sum(TradeLogs.trade_vol * TradeLogs.trade_price).label('trade_sum'),
        ).filter(
            TradeLogs.vstrategy_id == self.vs_id,
            TradeLogs.trading_date == self.trading_date_str,
            TradeLogs.log_type == '3',
            TradeLogs.entrust_status.in_(['p', 'c'])
        ).group_by(
            TradeLogs.symbol, TradeLogs.direction
        )
        for l in trading_detail:
            s_d = symbol_detail.setdefault(l.symbol, copy.deepcopy(self.sym_tmp))
            s_d['symbol'] = l.symbol
            if int(l.direction) == 0:
                s_d['buy_volume'] += float(l.trade_vol)
                s_d['buy_amount'] += float(l.trade_sum)

            else:
                s_d['sell_volume'] += float(l.trade_vol)
                s_d['sell_amount'] += float(l.trade_sum)

        manual_trading_detail = self.sc.query(
            SettlementManualTradelog.symbol.label('symbol'),
            SettlementManualTradelog.direction.label('direction'),
            SettlementManualTradelog.trade_vol.label('trade_vol'),
            SettlementManualTradelog.trade_price.label('trade_price'),
        ).filter(
            SettlementManualTradelog.vstrategy_id == self.vs_id,
            SettlementManualTradelog.trading_date == self.trading_date
        )

        for l in manual_trading_detail:
            s_d = symbol_detail.setdefault(l.symbol, copy.deepcopy(self.sym_tmp))
            s_d['symbol'] = l.symbol
            if l.direction == 'BUY':
                s_d['buy_volume'] += float(l.trade_vol)
                s_d['buy_amount'] += (float(l.trade_vol) * float(l.trade_price))

            else:
                s_d['sell_volume'] += float(l.trade_vol)
                s_d['sell_amount'] += (float(l.trade_vol) * float(l.trade_price))

        dividends = self.sc.query(PositionCorpActionsTable).filter(
            PositionCorpActionsTable.vstrategy_id == self.vs_id,
            PositionCorpActionsTable.dividend_cash_payout_date == self.trading_date_str,
        )
        for divd in dividends:
            cash = float(divd.payout_cash)
            if cash > 0:
                s_d = symbol_detail.setdefault(divd.symbol, copy.deepcopy(self.sym_tmp))
                s_d['symbol'] = divd.symbol
                s_d['dividend'] = round(float(divd.payout_cash), 2)

        columns = [
            'symbol', 'open_pos', 'pre_close', 'close_pos', 'close', 'buy_volume', 'buy_price', 'sell_volume',
            'sell_price', 'fee', 'dividend', 'pnl'
        ]
        rows = []
        for s, s_d in symbol_detail.items():
            s_d['symbol'] = s
            if s_d['buy_volume']:
                s_d['buy_price'] = round(s_d['buy_amount'] / s_d['buy_volume'], 12)

            if s_d['sell_volume']:
                s_d['sell_price'] = round(s_d['sell_amount'] / s_d['sell_volume'], 12)
            rows.append([s_d[c] for c in columns])
        return pd.DataFrame(sorted(rows, key=lambda _x: _x[0]), columns=columns)

    def get_vs_back_test_df(self):

        positions = self.sc.query(VstrategyBackTestResultDetail).filter(
            VstrategyBackTestResultDetail.vstrategy_id == self.vs_id,
            VstrategyBackTestResultDetail.trading_date == self.trading_date_str
        )
        symbol_detail = {}
        for pos in positions:
            symbol_d = symbol_detail.setdefault(pos.symbol, copy.deepcopy(self.sym_tmp))
            symbol_d['symbol'] = pos.symbol
            day_night = int(pos.day_night)
            long_price = float(pos.long_price)
            short_price = float(pos.short_price)
            _price = round(long_price if long_price else short_price, 12)
            if day_night == 1:
                symbol_d['open_pos'] = pos.long_volume - pos.short_volume
                symbol_d['pre_close'] = _price
                symbol_d['pnl'] += round(float(pos.pnl), 2)
            elif day_night == 0:
                if not _price:
                    _price = self.stock_close_price.get(pos.symbol, 0)
                symbol_d['close_pos'] = pos.long_volume - pos.short_volume
                symbol_d['close'] = _price
                symbol_d['pnl'] += round(float(pos.pnl), 2)
                symbol_d['fee'] = round(float(pos.fee), 2)
                symbol_d['dividend'] = round(float(pos.dividend), 2)

        trading_detail = self.sc.query(
            BackTestTradeLogs.symbol.label('symbol'),
            BackTestTradeLogs.direction.label('direction'),
            func.sum(BackTestTradeLogs.trade_vol).label('trade_vol'),
            func.sum(BackTestTradeLogs.trade_vol * BackTestTradeLogs.trade_price).label('trade_sum'),
        ).filter(
            BackTestTradeLogs.vstrategy_id == self.vs_id,
            BackTestTradeLogs.trading_date == self.trading_date_str,
            BackTestTradeLogs.msg_type == '3',
            BackTestTradeLogs.entrust_status.in_(['p', 'c'])
        ).group_by(
            BackTestTradeLogs.symbol, BackTestTradeLogs.direction
        )
        for l in trading_detail:
            s_d = symbol_detail.setdefault(l.symbol, copy.deepcopy(self.sym_tmp))
            s_d['symbol'] = l.symbol
            if int(l.direction) == 0:
                s_d['buy_volume'] += float(l.trade_vol)
                s_d['buy_amount'] += float(l.trade_sum)

            else:
                s_d['sell_volume'] += float(l.trade_vol)
                s_d['sell_amount'] += float(l.trade_sum)

        columns = [
            'symbol', 'open_pos', 'pre_close', 'close_pos', 'close', 'buy_volume', 'buy_price', 'sell_volume',
            'sell_price', 'fee', 'dividend', 'pnl'
        ]
        rows = []
        for s, s_d in symbol_detail.items():
            s_d['symbol'] = s
            if s_d['buy_volume']:
                s_d['buy_price'] = round(s_d['buy_amount'] / s_d['buy_volume'], 12)

            if s_d['sell_volume']:
                s_d['sell_price'] = round(s_d['sell_amount'] / s_d['sell_volume'], 12)
            rows.append([s_d[c] for c in columns])
        return pd.DataFrame(sorted(rows, key=lambda _x: _x[0]), columns=columns)

    def get_vs_live_vwap_result(self):

        res = self.sc.query(
            VwapResult
        ).filter(
            VwapResult.vstrategy_id == self.vs_id,
            VwapResult.trading_date == self.trading_date_str,
        )
        columns = [
            'Symbol',
            'MktDurationVWAP',
            'parent_order_size',
            'direction',
        ]

        rows = [[r.symbol, float(r.mkt_duration_vwap), int(r.parent_order_size), r.direction * (-2) + 1] for r in res]

        return pd.DataFrame(sorted(rows, key=lambda _x: _x[0]), columns=columns)

    def get_vs_back_test_vwap_result(self):
        res = self.sc.query(
            VsVwapResult
        ).filter(
            VsVwapResult.vstrategy_id == self.vs_id,
            VsVwapResult.trading_date == self.trading_date_str,
        )
        columns = [
            'Symbol',
            'MktDurationVWAP',
            'parent_order_size',
            'direction',
        ]

        rows = [[r.symbol, float(r.MktDurationVWAP), float(r.ParentOrderSize), r.Direction * (-2) + 1] for r in res]

        return pd.DataFrame(sorted(rows, key=lambda _x: _x[0]), columns=columns)

    def get_diff(self):

        if self.strategy.strategy_type not in consts.stock_strategy_type:
            return {
                'columns': self.all_columns,
                'headers': self.headers,
                'rows': [],
                'highlight': self.highlight,
            }
        try:
            diff = self.generate_diff()
            return diff
        except Exception as e:
            sentry.captureException()
            return {
                'columns': self.all_columns,
                'headers': self.headers,
                'rows': [],
                'highlight': self.highlight,
            }

    def generate_diff(self):
        live_df = self.get_vs_live_df()
        liveana_df = self.get_vs_back_test_df()
        live_vwap_rs = self.get_vs_live_vwap_result()
        vs_vwap_rs = self.get_vs_back_test_vwap_result()
        live_vwap_rs.drop_duplicates(['Symbol'], inplace=True)
        vs_vwap_rs.drop_duplicates(['Symbol'], inplace=True)
        live = live_df.merge(live_vwap_rs[['Symbol', 'MktDurationVWAP', 'parent_order_size', 'direction']],
                             left_on='symbol', right_on='Symbol', how='left').fillna(0)
        ana = liveana_df.merge(vs_vwap_rs[['Symbol', 'MktDurationVWAP', 'parent_order_size', 'direction']],
                               left_on='symbol', right_on='Symbol', how='left').fillna(0)

        aftermerged = live.merge(ana, on='symbol', how='outer')

        for i in range(len(aftermerged)):
            if np.isnan(aftermerged.iloc[i]['close_pos_x']) or np.isnan(aftermerged.iloc[i]['close_pos_y']):
                continue
            # if (aftermerged.iloc[i]['close_pos_x'] - aftermerged.iloc[i]['open_pos_x']) * (
            #             aftermerged.iloc[i]['close_pos_y'] - aftermerged.iloc[i]['open_pos_y']) < 0:
            #     if aftermerged.iloc[i]['buy_volume_x'] > 0:
            #         aftermerged.at[i, 'buy_volume_y'] = -aftermerged.iloc[i]['sell_volume_y']
            #         aftermerged.at[i, 'buy_price_y'] = aftermerged.iloc[i]['sell_price_y']
            #         aftermerged.at[i, 'sell_volume_y'] = 0
            #         aftermerged.at[i, 'sell_price_y'] = 0
            #     if aftermerged.iloc[i]['sell_volume_x'] > 0:
            #         aftermerged.at[i, 'sell_volume_y'] = -aftermerged.iloc[i]['buy_volume_y']
            #         aftermerged.at[i, 'sell_price_y'] = aftermerged.iloc[i]['buy_price_y']
            #         aftermerged.at[i, 'buy_volume_y'] = 0
            #         aftermerged.at[i, 'buy_price_y'] = 0

        aftermerged['live_yespos'] = aftermerged.apply(live_yes_pos, axis=1)
        aftermerged['sim_yespos'] = aftermerged.apply(sim_yes_pos, axis=1)
        aftermerged['yes_close'] = aftermerged.apply(yes_close, axis=1)
        aftermerged['today_close'] = aftermerged.apply(today_close, axis=1)
        aftermerged['diff_yespos'] = aftermerged.apply(diff_yespos, axis=1)
        aftermerged['live_today_pos'] = aftermerged.apply(live_today_pos, axis=1)
        aftermerged['sim_today_pos'] = aftermerged.apply(sim_today_pos, axis=1)
        aftermerged['diff_tradevol'] = aftermerged.apply(diff_tradevol, axis=1)
        aftermerged['live_mkt_px'] = aftermerged.apply(live_mkt_px, axis=1)
        aftermerged['live_trade_px'] = aftermerged.apply(live_trade_px, axis=1)
        aftermerged['live_vwap_slippage'] = aftermerged.apply(live_vwap_slippage, axis=1)
        aftermerged['sim_mkt_px'] = aftermerged.apply(sim_mkt_px, axis=1)
        aftermerged['sim_trade_px'] = aftermerged.apply(sim_trade_px, axis=1)
        aftermerged['sim_vwap_slippage'] = aftermerged.apply(sim_vwap_slippage, axis=1)
        aftermerged['trade_vol'] = aftermerged.apply(trade_vol, axis=1)
        aftermerged['diff_tradepx'] = aftermerged.apply(diff_tradepx, axis=1)
        aftermerged['diff_fee'] = aftermerged.apply(diff_fee, axis=1)
        aftermerged['diff_dividend'] = aftermerged.apply(diff_dividend, axis=1)
        aftermerged['total'] = aftermerged['diff_yespos'] + aftermerged['diff_tradevol'] + aftermerged['diff_tradepx'] + \
                               aftermerged['diff_fee']
        aftermerged['total'] = aftermerged['total'].apply(lambda x: round(x, 2))

        aftermerged['today_live_target_pos'] = aftermerged.apply(
            lambda r: r['live_yespos'] + r['parent_order_size_x'] * r['direction_x'], axis=1)
        aftermerged['today_sim_target_pos'] = aftermerged.apply(
            lambda r: r['sim_yespos'] + r['parent_order_size_y'] * r['direction_y'], axis=1)

        summary = np.zeros(len(self.all_columns))
        sumls = summary.tolist()

        livetmp1 = (
                aftermerged['live_vwap_slippage'] * aftermerged['live_trade_px'] * aftermerged['parent_order_size_x']
        ).sum()

        livetmp2 = (
                aftermerged['live_trade_px'] * aftermerged['parent_order_size_x']
        ).sum()

        simtmp1 = (
                aftermerged['sim_vwap_slippage'] * aftermerged['sim_trade_px'] * aftermerged['parent_order_size_y']
        ).sum()

        simtmp2 = (
                aftermerged['sim_trade_px'] * aftermerged['parent_order_size_y']
        ).sum()

        sumls[0] = 'summary'
        sumls[self.col_index['diff_yespos']] = round(aftermerged['diff_yespos'].sum(), 2)
        sumls[self.col_index['diff_tradevol']] = round(aftermerged['diff_tradevol'].sum(), 2)
        sumls[self.col_index['live_vwap_slippage']] = round(livetmp1 / (livetmp2 or 1), 2)
        sumls[self.col_index['sim_vwap_slippage']] = round(simtmp1 / (simtmp2 or 1), 2)
        sumls[self.col_index['diff_tradepx']] = round(aftermerged['diff_tradepx'].sum(), 2)
        sumls[self.col_index['diff_fee']] = round(aftermerged['diff_fee'].sum(), 2)
        sumls[self.col_index['diff_dividend']] = round(aftermerged['diff_dividend'].sum(), 2)
        sumls[self.col_index['total']] = round(aftermerged['total'].sum(), 2)

        aftermerged['live_trade_px'] = aftermerged.apply(lambda x: round(x['live_trade_px'], 3), axis=1)
        aftermerged['sim_trade_px'] = aftermerged.apply(lambda x: round(x['sim_trade_px'], 3), axis=1)
        aftermerged['sim_vwap_slippage'] = aftermerged.apply(lambda x: round(x['sim_vwap_slippage'], 3), axis=1)
        aftermerged['live_vwap_slippage'] = aftermerged.apply(lambda x: round(x['live_vwap_slippage'], 3), axis=1)
        aftermerged['sim_mkt_px'] = aftermerged.apply(lambda x: round(x['sim_mkt_px'], 3), axis=1)
        aftermerged['live_mkt_px'] = aftermerged.apply(lambda x: round(x['live_mkt_px'], 3), axis=1)

        rows = []
        for i in range(len(aftermerged)):
            rows.append(aftermerged.iloc[i][self.all_columns].tolist())

        rows.insert(0, sumls)
        return {
            'columns': self.all_columns,
            'headers': self.headers,
            'rows': rows,
            'highlight': self.highlight,
        }

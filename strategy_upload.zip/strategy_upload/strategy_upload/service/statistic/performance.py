# -*-coding:utf-8-*-

import uuid
import os
import pandas as pd
import datetime
import simplejson
# from dateutil.parser import parse
import matplotlib

matplotlib.use('Agg')
import matplotlib.pyplot as plt

from service.back_test.models import Strategy, StrategyResult, StrategyResultDetail, \
    StrategyBackTestResultPerformance, ResearchStrategyPortfolio, ResearchStrategyPortfolioDetail

from service.back_test.t0_factors import get_t0_position
from analysis.performance_analysis import PerformanceAnalyzer

from service.statistic.models import StrategyTradingVolumeRatioStatistic
from db import session
from kdb_query import KdbQuery
from config import config
from extensions import sentry
from utils import set_cache, MyEncoder
from constant import HedgeBenchmark

import consts

null_pnl_detail = {
    'pnl': {},
    'back_test_pnl': {},
    'hedge_net': {},
    'origin_net': {},
    'sharpe': 0,
    'profitrate': 0,
    'annual_return': 0,
    'max_drawdown_pnl': 0,
    'max_drawdown_start': 0,
    'max_drawdown_end': 0,
    'back_test_sharpe': 0,
    'back_test_profitrate': 0,
    'back_test_annual_return': 0,
    'back_test_max_drawdown_pnl': 0,
    'back_test_max_drawdown_start': 0,
    'back_test_max_drawdown_end': 0,
    'return_over_drawdown': 0,
    'paper_trading_sharpe': 0,
    'paper_trading_profitrate': 0,
    'paper_trading_annual_return': 0,
    'paper_trading_max_drawdown_pnl': 0,
    'paper_trading_max_drawdown_start': 0,
    'paper_trading_max_drawdown_end': 0,
}


class BackTestPerformance(object):

    def __init__(self, s_id, config_id=0, **kwargs):
        self.sc = session()
        self.kdb = KdbQuery()
        self.strategy = self.sc.query(Strategy).filter(Strategy.id == s_id).first()
        self.s_id = self.strategy.id
        self.config_id = config_id
        self.kwargs = kwargs
        self.hedge = self.strategy.hedge
        self.hedge_type = self.strategy.hedge_type or 'position'
        # CEO需求，对于有融券对冲底仓的策略，默认使用融券对冲
        if self.strategy.has_margin_hedge():
            self.hedge = HedgeBenchmark.MarginHedgeList.value
        self.group_id = self.strategy.group_id
        self.paper_trading_date = (self.strategy.paper_trading_date or self.strategy.r_create_time).strftime('%Y-%m-%d')
        self._paper_trading_date = (self.strategy.paper_trading_date or self.strategy.r_create_time).strftime('%Y%m%d')
        self.detail = self.strategy.detail
        self.strategy_type = self.strategy.strategy_type
        self._confidence = float(self.strategy.confidence)
        self.union_rows = []
        self.back_test_result = {}

        s_name = (self.strategy.name or '').lower()
        if 'dt' in s_name:
            self.default_vwap_time = [
                93000000, 145500000
            ]
        elif 'im' in s_name:
            self.default_vwap_time = [
                93000000, 145500000
            ]
        elif 'da' in s_name:
            self.default_vwap_time = [
                93000000, 145500000
            ]
        elif 'hd' in s_name:
            self.default_vwap_time = [
                93000000, 113000000
            ]
        elif self.strategy.strategy_type in ('33',):
            self.default_vwap_time = [
                93000000, 145500000
            ]
        else:
            self.default_vwap_time = []

        self.get_back_test_pnl()

        now = datetime.datetime.now()
        if now.hour < 23:
            now = now - datetime.timedelta(days=1)
        self.now = now
        self.now_str = self.now.strftime('%Y%m%d')
        self.trading_days = self.kdb.get_trading_days('20030101', now.strftime('%Y%m%d'))
        self.count_days = lambda b, e: len([1 for r in self.trading_days if b <= r <= e])
        # self.pt_days = self.count_days(parse(self.paper_trading_date).strftime('%Y%m%d'), self.now.strftime('%Y%m%d'))
        self.pt_days = self.count_days(self._paper_trading_date, self.now.strftime('%Y%m%d'))
        self.pnls = []
        self.keys = kwargs.get('keys', ['whole', 'all', 1, 3, 6, 12])

    def __del__(self):
        self.sc.close()
        self.kdb.release()

    def close(self):
        self.sc.close()
        self.kdb.release()

    def get_back_test_merge_pnl(self):
        pnl_dict = {}
        sub_sts = self.detail['sub_sts']
        # 假设此时子策略结果已入库
        for sid in sub_sts:
            p = StrategyPortfolioPerformance([sid], business="stock")
            data = p.analysis()
            self.union_rows.append(data['rows'][0])
            for k, v in data['summary']['back_test_pnl'].items():
                pnl_dict.setdefault(k, 0)
                # pnl after hedge
                pnl_dict[k] += v[1]
        return pnl_dict

    def get_back_test_pnl(self):
        if self.group_id > 0:
            back_test_result = self.strategy.group_back_test_result(config_id=0)
            self.paper_trading_date = back_test_result['paper_trading_date']
            back_test_result['paper_trading_date'] = ''
            back_test_result['back_test_end_position_value'] = 0  # hedge
        else:
            res = self.sc.query(
                StrategyResult.date.label('date'),
                StrategyResult.pnl.label('pnl'),
                StrategyResult.position_cash.label('position_cash'),
                StrategyResult.total_asset.label('total_asset'),
            ).filter(
                StrategyResult.strategy_id == self.s_id,
                StrategyResult.config_id == self.config_id,
                StrategyResult.status == consts.TASK_FINISHED
            ).order_by(StrategyResult.date)

            back_test_result = {
                'live_date': [],
                'live_pnl': [],
                'live_asset': [],
                'live_position_value': [],
                'live_end_position_value': 0.0,
                'live_cash_io': [],
                'back_test_date': [],
                'back_test_asset': [],
                'back_test_pnl': [],
                'back_test_position_value': [],
                'back_test_cash_io': [],
                'back_test_end_position_value': 0.0,
                'paper_trading_date': '',
                'back_test_start_time': [],
                'back_test_end_time': [],
            }

            initial_cash = self.detail.get('initial_cash', 1000000) or 1000000
            if self.config_id > 0:
                initial_cash = Strategy.get_semi_info(self.config_id).get('initial_cash', 1000000) or 1000000

            alpha_position_cash = {}
            if (self.strategy_type in consts.t0_stock_strategy_type) and self.detail.get('alpha_s_id'):
                try:
                    if self.detail.get('is_union', 0):
                        # 对于联合模拟策略的T0，底仓是实时更新的
                        alpha_position_cash = get_t0_position(self.detail['alpha_s_id'], mode="new", cache=False)
                    else:
                        # 这里拿绑定的 alpha 策略的底仓
                        alpha_position_cash = get_t0_position(self.detail['alpha_s_id'], mode="new")
                except Exception as e:
                    alpha_position_cash = {}

            daily_open_asset = float(initial_cash)
            daily_position_cash = 0.0
            # 如果是联合模拟的父策略，则不能直接叠加 pnl，子策略对冲后的 pnl 再求和
            if self.strategy_type == "34" and self.detail.get("sub_sts", None):
                union_father = True
                # wait sub-strategy data fill into database before this one
                # time.sleep(3)
                merge_pnl = self.get_back_test_merge_pnl()
            else:
                union_father = False
                merge_pnl = {}

            for r in res:
                back_test_result['back_test_date'].append(r.date)
                back_test_result['back_test_asset'].append(daily_open_asset + alpha_position_cash.get(r.date, 0))
                # 如果子策略回报慢了，最后 back_test_done 也会刷新数据
                r_pnl = float(r.pnl) if not union_father else merge_pnl.get(r.date, 0)
                # CEO 需求，回测按 pnl 缩放
                if r.date < self._paper_trading_date and r_pnl > 0:
                    back_test_result['back_test_pnl'].append(r_pnl * self._confidence)
                else:
                    back_test_result['back_test_pnl'].append(r_pnl)
                back_test_result['back_test_position_value'].append(daily_position_cash)
                back_test_result['back_test_cash_io'].append(0)
                back_test_result['back_test_start_time'].append(0)
                back_test_result['back_test_end_time'].append(0)

                if r.total_asset:
                    daily_open_asset = float(r.total_asset)
                else:
                    daily_open_asset += float(r.pnl)
                daily_position_cash = float(r.position_cash or 0.0)

            # 最终的市值
            back_test_result['back_test_end_position_value'] = daily_position_cash

        if self.hedge:
            if len(back_test_result['back_test_position_value']) >= 2:
                # 第一天的交易也需要对冲
                back_test_result['back_test_position_value'][0] = back_test_result['back_test_position_value'][1]
            elif len(back_test_result['back_test_position_value']) == 1:
                back_test_result['back_test_position_value'][0] = back_test_result['back_test_end_position_value']

            if back_test_result['back_test_start_time'] and self.default_vwap_time:
                back_test_result['back_test_start_time'][0] = self.default_vwap_time[0]
                back_test_result['back_test_end_time'][0] = self.default_vwap_time[1]

        self.back_test_result = back_test_result

        if self.strategy.st_uuid and len(back_test_result['back_test_date']) > 10:
            # 每个 session & back_test_done 都会进入，方便附近读取能快一点
            fingerprint = 'pnl_%s_%s' % (self.strategy.id, self.strategy.st_uuid)
            file_path = os.path.join(
                config.media, 'back_test_performace', '%s.json' % fingerprint
            )
            f = open(file_path, 'w')
            simplejson.dump(back_test_result, f, cls=MyEncoder, ignore_nan=True)
            f.close()

        return True

    def cal_performance(self, start_date='20010101', end_date='21000101', paper_trading_date='', **kwargs):
        """

        :param start_date: '%Y%m%d'
        :param end_date: '%Y%m%d'
        :param paper_trading_date: '%Y-%m-%d'
        :return:
        """
        pnl_input = {
            'live_date': [],
            'live_pnl': [],
            'live_asset': [],
            'live_position_value': [],
            'live_end_position_value': 0.0,
            'live_cash_io': [],
            'back_test_date': [],
            'back_test_asset': [],
            'back_test_pnl': [],
            'back_test_position_value': [],
            'back_test_cash_io': [],
            'back_test_end_position_value': 0.0,
            'paper_trading_date': paper_trading_date,
            'back_test_start_time': [],
            'back_test_end_time': [],
        }

        end_index = 0
        for i, d in enumerate(self.back_test_result['back_test_date']):
            if start_date <= d <= end_date:
                pnl_input['back_test_date'].append(d)
                pnl_input['back_test_asset'].append(self.back_test_result['back_test_asset'][i])
                pnl_input['back_test_pnl'].append(self.back_test_result['back_test_pnl'][i])
                pnl_input['back_test_position_value'].append(self.back_test_result['back_test_position_value'][i])
                pnl_input['back_test_cash_io'].append(self.back_test_result['back_test_cash_io'][i])
                try:
                    pnl_input['back_test_start_time'].append(self.back_test_result['back_test_start_time'][i])
                    pnl_input['back_test_end_time'].append(self.back_test_result['back_test_end_time'][i])
                except KeyError as e:
                    pnl_input['back_test_start_time'].append(0)
                    pnl_input['back_test_end_time'].append(0)

                end_index = i

        if end_index < len(self.back_test_result['back_test_date']) - 1:
            pnl_input['back_test_end_position_value'] = self.back_test_result['back_test_position_value'][end_index + 1]
        else:
            pnl_input['back_test_end_position_value'] = self.back_test_result['back_test_end_position_value']

        if not self.hedge:
            if self.strategy.is_single_interest:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_stock_strategies_quest(pnl_input)
            else:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategies_quest(pnl_input)
        else:
            if not kwargs.get('hedge', True):
                pnl_input['hedge'] = ''
                pnl_input['hedge_type'] = ''
            else:
                pnl_input['hedge'] = self.hedge
                pnl_input['hedge_type'] = self.hedge_type
                if self.hedge == HedgeBenchmark.MarginHedgeList.value:
                    pnl_input['margin_hedge_s_id'] = self.strategy.detail['alpha_s_id']

            if self.strategy.is_single_interest:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_stock_strategy_hedge_quest(pnl_input)
            else:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategy_hedge_quest(pnl_input)

        if net_pnl[0]:
            null_pnl_detail = {
                'valid': True,
                'pnl': {},
                'hedge_net': {},
                'origin_net': {},
                'sharpe': 0,
                'profitrate': 0,
                'annual_return': 0,
                'max_drawdown_pnl': 0,
                'max_drawdown_start': 0,
                'max_drawdown_end': 0,
                'return_over_drawdown': 0,
                'paper_trading_sharpe': 0,
                'paper_trading_profitrate': 0,
                'paper_trading_annual_return': 0,
                'paper_trading_max_drawdown_pnl': 0,
                'paper_trading_max_drawdown_start': 0,
                'paper_trading_max_drawdown_end': 0,
                'paper_trading_return_over_drawdown': 0,
            }
            return null_pnl_detail

        detail = net_pnl[1]
        pnl_detail = {
            'valid': True,
            'pnl': {key.decode('utf-8'): value for key, value in detail['back_test_pnl'].items()},
            'hedge_net': {},
            'origin_net': {},
            'sharpe': detail['back_test_sharpe'],
            'profitrate': detail['back_test_profitrate'],
            'annual_return': detail['back_test_annual_return'],
            'max_drawdown_pnl': detail['back_test_max_drawdown_pnl'],
            'max_drawdown_start': detail['back_test_max_drawdown_start'],
            'max_drawdown_end': detail['back_test_max_drawdown_end'],
            'return_over_drawdown': detail.get('back_test_return_over_drawdown', 0),
            'paper_trading_sharpe': detail['paper_trading_sharpe'],
            'paper_trading_profitrate': detail['paper_trading_profitrate'],
            'paper_trading_annual_return': detail['paper_trading_annual_return'],
            'paper_trading_max_drawdown_pnl': detail['paper_trading_max_drawdown_pnl'],
            'paper_trading_max_drawdown_start': detail['paper_trading_max_drawdown_start'],
            'paper_trading_max_drawdown_end': detail['paper_trading_max_drawdown_end'],
            'paper_trading_return_over_drawdown': detail.get('paper_trading_return_over_drawdown', 0),
        }

        for k, v in pnl_detail['pnl'].items():
            if not v[0] > 0:
                pnl_detail['valid'] = False
                break

        for k, v in pnl_detail['pnl'].items():
            if v[6] > v[3] * 2:
                pnl_detail['valid'] = False
                break

        return pnl_detail

    def cal_range_performance(self):
        for k in self.keys:
            try:
                if k in ('all', 'whole'):
                    pt_date = self.paper_trading_date
                else:
                    pt_date = (self.now - datetime.timedelta(k * 30)).strftime('%Y-%m-%d')

                if k == 'whole':
                    pt_date = ''
                else:
                    if pt_date < self.paper_trading_date:
                        continue

                # if k == 'all' and self.strategy_type == '22':
                #     pnl = {
                #         'key': 'back_test_all',
                #         'start_date': pt_date,
                #         'end_date': self.now_str,
                #         'sharpe': -999999,
                #         'annual_return': -999999,
                #         'profitrate': -999999,
                #         'max_drawdown_pnl': -999999,
                #         'drawdown_earn_ratio': -999999,
                #         'pt_days': 0,
                #         'valid': True,
                #         'avg_daily_rounds': 0,
                #     }
                #     self.pnls.append(pnl)
                #     pnl = {
                #         'key': 'paper_trading_all',
                #         'start_date': pt_date,
                #         'end_date': self.now_str,
                #         'sharpe': -999999,
                #         'annual_return': -999999,
                #         'profitrate': -999999,
                #         'max_drawdown_pnl': -999999,
                #         'drawdown_earn_ratio': -999999,
                #         'pt_days': 0,
                #         'valid': True,
                #         'avg_daily_rounds': 0,
                #     }
                #     self.pnls.append(pnl)
                #     continue

                pnl_detail = self.cal_performance(paper_trading_date=pt_date)
                special_filtered = False
                if not pnl_detail['pnl']:
                    if k not in ('all', 'whole'):
                        continue
                    else:
                        special_filtered = True

                if not pnl_detail['valid']:
                    if k not in ('all', 'whole'):
                        continue
                    else:
                        special_filtered = True

                if not special_filtered:
                    if (max(pnl_detail['pnl']) < self.trading_days[-7]) and (k not in ('all', 'whole')):
                        continue

                if k in ('all', 'whole'):
                    if k == 'all':
                        _k = 'back_test_all'
                    elif k == 'whole':
                        _k = 'whole_back_test'
                    else:
                        _k = ''
                    pnl = {
                        'key': _k,
                        'start_date': pt_date or self.strategy.start_date,
                        'end_date': self.now_str,
                        'sharpe': pnl_detail['sharpe'] if (not special_filtered) else -999999,
                        'annual_return': pnl_detail['annual_return'] if (not special_filtered) else -999999,
                        'profitrate': pnl_detail['profitrate'] if (not special_filtered) else -999999,
                        'max_drawdown_pnl': pnl_detail['max_drawdown_pnl'] if (not special_filtered) else -999999,
                        'drawdown_earn_ratio': -999999 if (
                                special_filtered or pnl_detail['return_over_drawdown'] >= 10000) else pnl_detail[
                            'return_over_drawdown'],
                        'pt_days': self.pt_days,
                        'valid': pnl_detail['valid'],
                        'avg_daily_rounds': 0,
                    }
                    self.pnls.append(pnl)

                if k != 'whole':
                    pnl = {
                        'key': 'paper_trading_all' if k == 'all' else ('paper_trading_%s_month' % k),
                        'start_date': pt_date,
                        'end_date': self.now_str,
                        'sharpe': pnl_detail['paper_trading_sharpe'] if (not special_filtered) else -999999,
                        'annual_return': pnl_detail['paper_trading_annual_return'] if (
                            not special_filtered) else -999999,
                        'profitrate': pnl_detail['paper_trading_profitrate'] if (not special_filtered) else -999999,
                        'max_drawdown_pnl': pnl_detail['paper_trading_max_drawdown_pnl'] if (
                            not special_filtered) else -999999,
                        'drawdown_earn_ratio': -999999 if (
                                special_filtered or pnl_detail['paper_trading_return_over_drawdown'] >= 10000) else
                        pnl_detail['paper_trading_return_over_drawdown'],
                        'pt_days': self.pt_days,
                        'valid': pnl_detail['valid'],
                        'avg_daily_rounds': 0,
                    }
                    self.pnls.append(pnl)
            except Exception as e:
                sentry.captureException()

    def cal_years_performance(self):
        if not self.back_test_result['back_test_date']:
            return True
        years = range(
            int(min(self.back_test_result['back_test_date'])[:4]),
            int(max(self.back_test_result['back_test_date'])[:4]) + 1,
        )
        for year in years:
            end_date = '%s1231' % year
            pt_date = '%s0101' % year
            try:
                if self.hedge:
                    pnl_detail = self.cal_performance(end_date=end_date, paper_trading_date=pt_date)
                    if (not pnl_detail['pnl']) or (not pnl_detail['valid']):
                        continue
                    pnl = {
                        'key': 'back_test_%s_year_hedge' % year,
                        'start_date': pt_date,
                        'end_date': end_date,
                        'sharpe': pnl_detail['paper_trading_sharpe'],
                        'annual_return': pnl_detail['paper_trading_annual_return'],
                        'profitrate': pnl_detail['paper_trading_profitrate'],
                        'max_drawdown_pnl': pnl_detail['paper_trading_max_drawdown_pnl'],
                        'drawdown_earn_ratio': pnl_detail['paper_trading_return_over_drawdown'],
                        'pt_days': self.pt_days,
                        'valid': pnl_detail['valid'],
                        'avg_daily_rounds': 0,
                    }
                    self.pnls.append(pnl)

                pnl_detail = self.cal_performance(end_date=end_date, paper_trading_date=pt_date, hedge=False)
                if (not pnl_detail['pnl']) or (not pnl_detail['valid']):
                    continue
                pnl = {
                    'key': 'back_test_%s_year' % year,
                    'start_date': pt_date,
                    'end_date': end_date,
                    'sharpe': pnl_detail['paper_trading_sharpe'],
                    'annual_return': pnl_detail['paper_trading_annual_return'],
                    'profitrate': pnl_detail['paper_trading_profitrate'],
                    'max_drawdown_pnl': pnl_detail['paper_trading_max_drawdown_pnl'],
                    'drawdown_earn_ratio': pnl_detail['paper_trading_return_over_drawdown'],
                    'pt_days': self.pt_days,
                    'valid': pnl_detail['valid'],
                    'avg_daily_rounds': 0,
                }
                self.pnls.append(pnl)
            except Exception as e:
                sentry.captureException()
                continue
        return True

    def cal_default_analysis_performance(self):
        pnl_detail = self.cal_performance()
        if not pnl_detail['pnl']:
            return False

        fingerprint = 'pnl_default_net_%s_%s' % (self.strategy.id, self.strategy.st_uuid)
        cache_file_path = os.path.join(
            config.media, 'back_test_performace', '%s.json' % fingerprint
        )
        f = open(cache_file_path, 'w')
        simplejson.dump(pnl_detail, f, cls=MyEncoder, ignore_nan=True)
        f.close()
        return True

    def generate_pnl_graph(self, hedge=True):
        try:
            filepath = os.path.join(config.media, 'strategy_pnl_graph')
            if not os.path.exists(filepath):
                os.makedirs(filepath)

            filename = os.path.join(
                filepath, 'strategy_%s_%s_%sthumbnail.png' % (self.s_id, self.config_id, 'hedge_' if hedge else '')
            )
            pnl = self.cal_performance(paper_trading_date=self.paper_trading_date, hedge=hedge)
            x_data, y_data = [], []
            for d, d_pnl in sorted(pnl['pnl'].items(), key=lambda x: x[0]):
                x_data.append(d)
                y_data.append(d_pnl[0])
            fig = plt.figure(figsize=(1.2, 0.6), dpi=100)
            plt.plot(x_data, y_data, color='#4ad3e8', linewidth=1)
            plt.axis('off')
            plt.savefig(filename, transparent=True)
            plt.close(fig)
            return True
        except Exception as e:
            sentry.captureException()
            return False

    def generate_strategy_backtest_graph(self):
        self.generate_pnl_graph(hedge=False)
        if self.hedge:
            self.generate_pnl_graph(hedge=True)

    def set_performance(self):
        self.sc.query(StrategyBackTestResultPerformance).filter(
            StrategyBackTestResultPerformance.strategy_id == self.s_id,
            StrategyBackTestResultPerformance.config_id == self.config_id,
        ).delete(synchronize_session=False)

        for pnl in self.pnls:
            o = StrategyBackTestResultPerformance(
                strategy_id=self.s_id,
                config_id=self.config_id,
                key=pnl['key'],
                start_date=pnl['start_date'],
                end_date=pnl['end_date'],
                sharpe=pnl['sharpe'],
                annual_return=pnl['annual_return'],
                profitrate=pnl['profitrate'],
                max_drawdown_pnl=pnl['max_drawdown_pnl'],
                drawdown_earn_ratio=pnl['drawdown_earn_ratio'],
                pt_days=pnl['pt_days'],
                valid=bool(pnl['valid']),
                avg_daily_rounds=pnl['avg_daily_rounds'],
            )
            self.sc.add(o)

        self.sc.commit()
        return True

    def run(self):
        """
        这个函数会被 back_test_done 调用，用于回测后计算绩效，并存进数据库，以及画图
        :return:
        """
        self.cal_range_performance()
        self.cal_years_performance()
        self.cal_default_analysis_performance()
        # 上面是计算绩效，这里将计算所得的绩效信息存进数据库的StrategyBackTestResultPerformance表
        self.set_performance()
        self.generate_strategy_backtest_graph()
        return True

    # @staticmethod
    # def update_all_strategy():
    #     sc = session()
    #     strategies = sc.query(
    #         Strategy.id
    #     ).filter(
    #         Strategy.is_delete == 0,
    #         Strategy.is_test == 0,
    #         Strategy.node.in_(['back_test', 'order_list', 'trademaster_order_list', 'group', 'union_simu']),
    #     )
    #     for s in strategies:
    #         BackTestPerformance._update_strategy(s[0])
    #     sc.close()
    #     return True

    @staticmethod
    def update_all_strategy_multiprocess():
        from multiprocessing import Pool
        sc = session()
        s_ids = sc.query(
            ResearchStrategyPortfolioDetail.strategy_id
        ).join(
            ResearchStrategyPortfolio, ResearchStrategyPortfolioDetail.portfolio_id == ResearchStrategyPortfolio.id
        ).filter(
            ResearchStrategyPortfolio.create_type == 2,
        ).distinct()
        s_ids = [s[0] for s in s_ids]
        sc.close()

        with Pool(processes=16) as pool:
            for s_id in s_ids:
                pool.apply_async(BackTestPerformance._update_strategy, [s_id])
            pool.close()
            pool.join()
        return True

    @staticmethod
    def _update_strategy(s_id):
        try:
            p = BackTestPerformance(s_id=s_id)
        except Exception as e:
            sentry.captureException()
            return False
        try:
            p.run()
        except Exception as e:
            sentry.captureException()
        p.close()
        return True

    @staticmethod
    def update_strategy(s_id):
        sc = session()
        try:
            s = sc.query(Strategy.id).filter(
                Strategy.id == int(s_id),
                Strategy.is_delete == 0,
                Strategy.is_test == 0,
                Strategy.node.in_(['back_test', 'order_list', 'trademaster_order_list', 'group', 'union_simu']),
            ).first()
            if not s:
                sc.close()
                return False

            BackTestPerformance._update_strategy(s_id)
        except Exception as e:
            sentry.captureException()

        sc.close()
        return True

    # @staticmethod
    # def get_strategy_hedge_performace(s_id):
    #     p = BackTestPerformance(s_id=s_id)
    #     return p.cal_performance()

    @staticmethod
    def get_strategy_hedge_performance_ret(s_id):
        p = BackTestPerformance(s_id=s_id)
        pnl = p.cal_performance()
        ret = {}
        for d, d_pnl in pnl['pnl'].items():
            ret[d] = d_pnl[0] - d_pnl[4]
        return ret


class StrategyPerformance(object):

    def __init__(self, s_id, config_id=0, **kwargs):
        self.sc = session()
        self.kdb = KdbQuery()
        self.strategy = self.sc.query(Strategy).filter(Strategy.id == s_id).first()
        self.s_id = self.strategy.id
        self.id = self.strategy.id
        self.config_id = config_id
        self.kwargs = kwargs
        self.hedge = self.strategy.hedge
        self.hedge_type = self.strategy.hedge_type or 'position'
        self.group_id = self.strategy.group_id
        self.day_night = self.strategy.day_night
        self.paper_trading_date = (self.strategy.paper_trading_date or self.strategy.r_create_time).strftime('%Y-%m-%d')
        self._paper_trading_date = (self.strategy.paper_trading_date or self.strategy.r_create_time).strftime('%Y%m%d')
        self._confidence = float(self.strategy.confidence)
        self.detail = self.strategy.detail
        self.strategy_type = self.strategy.strategy_type
        self.node = self.strategy.node

    def __del__(self):
        self.sc.close()
        self.kdb.release()

    def close(self):
        self.sc.close()
        self.kdb.release()

    def get_live_performance_v2(self):
        return []
        # vs_id = None
        # pnls = []
        # if self.group_id > 0:
        #     s_vs = {}
        #     vs_ids = []
        #     vs_items = self.sc.query(
        #         VStrategies.id,
        #         VStrategies.status,
        #         VStrategies.strategy_id
        #     ).filter(
        #         VStrategies.group_id == self.s_id,
        #         VStrategies.status == consts.STRATEGY_LIVE
        #     )
        #     strategy_type = '02' if self.strategy_type in consts.stock_strategy_type else '01'
        #     for v_id, _, _ in vs_items:
        #         vs_ids.append(v_id)
        #
        #     if not vs_ids:
        #         return []
        #
        #     day_cum_pnl, day_position_cash = {}, {}
        #     vs_symbols = {}
        #     symbol_exchanges = {}
        #     vs_log_stats = self.calc_log_statsv2(vs_ids=vs_ids)
        #
        #     vs_bases = self.sc.query(
        #         VsBase.settle_date.label('settle_date'),
        #         VsBase.accumulated_pnl.label('accumulated_pnl'),
        #         VsBase.cash.label('available_cash'),
        #         VsBase.position_cash.label('position_cash'),
        #     ).filter(
        #         VsBase.vstrategy_id.in_(vs_ids),
        #         VsBase.daynight == 'DAY',
        #     )
        #     for vs_base in vs_bases:
        #         settle_date = vs_base.settle_date.strftime('%Y%m%d')
        #         day_cum_pnl[settle_date] = day_cum_pnl.get(settle_date, 0) + float(vs_base.accumulated_pnl)
        #         day_position_cash[settle_date] = day_position_cash.get(settle_date, 0) + (
        #                 vs_base.position_cash and float(vs_base.position_cash) or 0)
        #
        #     vs_positions_symbols = self.sc.query(
        #         VsPosition.settle_date.label('trading_date'),
        #         VsPosition.symbol.label('symbol'),
        #         VsPosition.exchange.label('exchange'),
        #     ).filter(
        #         VsPosition.vstrategy_id.in_(vs_ids)
        #     )
        #     for vs_pos_symbol in vs_positions_symbols:
        #         _d = vs_pos_symbol.trading_date.strftime('%Y%m%d')
        #         if _d not in vs_symbols:
        #             vs_symbols[_d] = set()
        #         vs_symbols[_d].add(vs_pos_symbol.symbol)
        #         symbol_exchanges[vs_pos_symbol.symbol] = vs_pos_symbol.exchange
        #
        #     for _d, value in vs_log_stats.items():
        #         if _d not in vs_symbols:
        #             vs_symbols[_d] = set()
        #         vs_symbols[_d].update(value.keys())
        #
        #     cash_io_record = VStrategies.vstratgies_account_invest_funds(
        #         VStrategies.vstrategies_invest_funds_detail(vs_ids), vs_ids, 'all'
        #     )
        #     day_cash = {d: 0 for d in day_cum_pnl}
        #     for d, _cash in cash_io_record.items():
        #         day_cash[d.replace('-', '')] = _cash
        #     day_cash = pd.Series(day_cash).shift(1).cumsum()
        #     day_cash = day_cash.dropna()
        #     day_cash = day_cash.to_dict()
        #
        #     prev_accumulate_pnl = 0.0
        #     last_symbol = []
        #
        #     hedge = self.hedge or ''
        #     hedge_type = self.hedge_type or 'position'
        #     position_cash = 0
        #     for r in sorted(day_cum_pnl.items(), key=lambda d: d[0]):
        #         d_symbols = vs_symbols.get(r[0], [])
        #         d_pnl = (r[1] - prev_accumulate_pnl) / (len(d_symbols or last_symbol) or 1)
        #         d_open_cash = prev_accumulate_pnl + day_cash.get(r[0], 0)
        #         for _symbol in (d_symbols or last_symbol or ['UNKNOWN']):
        #             exchange = symbol_exchanges.get(_symbol, 'UNKNOWN')
        #             if r[0] in vs_log_stats:
        #                 if _symbol in vs_log_stats[r[0]]:
        #                     _stats = vs_log_stats[r[0]][_symbol]
        #                 else:
        #                     _stats = list(vs_log_stats[r[0]].values())[0]
        #             else:
        #                 _stats = [0, 0, 0, 0]
        #             pnls.append([
        #                             self.strategy.id, self.strategy.id_no, r[0], _symbol, exchange, d_open_cash, d_pnl,
        #                             1, self.day_night, strategy_type, hedge, position_cash, hedge_type
        #                         ] + _stats)
        #         position_cash = day_position_cash[r[0]]
        #         prev_accumulate_pnl = r[1]
        #         if d_symbols:
        #             last_symbol = d_symbols
        #
        # else:
        #     vs_ids = self.sc.query(
        #         VStrategies.id,
        #     ).filter(
        #         or_(
        #             and_(
        #                 VStrategies.strategy_id == self.strategy.id,
        #                 VStrategies.group_id == 0,
        #             ),
        #             VStrategies.group_id == self.strategy.id
        #         ),
        #         VStrategies.status == consts.STRATEGY_LIVE,
        #     )
        #     vs_ids = [v_id[0] for v_id in vs_ids]
        #
        #     if not vs_ids:
        #         return []
        #
        #     strategy_type = '02' if self.strategy_type in consts.stock_strategy_type else '01'
        #     vs_bases = self.sc.query(
        #         VsBase.settle_date.label('settle_date'),
        #         VsBase.accumulated_pnl.label('accumulated_pnl'),
        #         VsBase.cash.label('available_cash'),
        #         VsBase.position_cash.label('position_cash'),
        #     ).filter(
        #         VsBase.daynight == 'DAY',
        #         VsBase.vstrategy_id.in_(vs_ids)
        #     )
        #     day_cum_pnl, day_available_cash, day_position_cash = {}, {}, {}
        #     for vs_base in vs_bases:
        #         settle_date = vs_base.settle_date.strftime('%Y%m%d')
        #         day_cum_pnl[settle_date] = day_cum_pnl.get(settle_date, 0) + float(vs_base.accumulated_pnl)
        #         day_available_cash[settle_date] = vs_base.available_cash and float(vs_base.available_cash) or 0
        #         day_position_cash[settle_date] = vs_base.position_cash and float(vs_base.position_cash) or 0
        #     cash_io_record = VStrategies.vstratgies_account_invest_funds(
        #         VStrategies.vstrategies_invest_funds_detail(vs_ids), vs_ids, 'all'
        #     )
        #     day_cash = {d: 0 for d in day_cum_pnl}
        #     for d, _cash in cash_io_record.items():
        #         day_cash[d.replace('-', '')] = _cash
        #     day_cash = pd.Series(day_cash).shift(1).cumsum()
        #     day_cash = day_cash.dropna()
        #     day_cash = day_cash.to_dict()
        #
        #     vs_symbols = {}
        #     symbol_exchanges = {}
        #     vs_positions_symbols = self.sc.query(
        #         VsPosition.settle_date.label('trading_date'),
        #         VsPosition.symbol.label('symbol'),
        #         VsPosition.exchange.label('exchange'),
        #     ).filter(
        #         VsPosition.vstrategy_id.in_(vs_ids)
        #     )
        #     for vs_pos_symbol in vs_positions_symbols:
        #         _d = vs_pos_symbol.trading_date.strftime('%Y%m%d')
        #         if _d not in vs_symbols:
        #             vs_symbols[_d] = set()
        #         vs_symbols[_d].add(vs_pos_symbol.symbol)
        #         symbol_exchanges[vs_pos_symbol.symbol] = vs_pos_symbol.exchange
        #
        #     vs_log_stats = self.calc_log_statsv2(vs_ids=vs_ids)
        #     for _d, value in vs_log_stats.items():
        #         if _d not in vs_symbols:
        #             vs_symbols[_d] = set()
        #         vs_symbols[_d].update(value.keys())
        #
        #     prev_accumulate_pnl = 0.0
        #     last_symbol = []
        #     hedge = self.hedge or ''
        #     hedge_type = self.hedge_type or 'position'
        #     position_cash = 0
        #     for r in sorted(day_cum_pnl.items(), key=lambda d: d[0]):
        #         d_symbols = vs_symbols.get(r[0], [])
        #         d_pnl = (r[1] - prev_accumulate_pnl) / (len(d_symbols or last_symbol) or 1)
        #         d_open_cash = prev_accumulate_pnl + day_cash.get(r[0], 0)
        #         for _symbol in (d_symbols or last_symbol or ['UNKNOWN']):
        #             exchange = symbol_exchanges.get(_symbol, 'UNKNOWN')
        #             if r[0] in vs_log_stats:
        #                 if _symbol in vs_log_stats[r[0]]:
        #                     _stats = vs_log_stats[r[0]][_symbol]
        #                 else:
        #                     _stats = list(vs_log_stats[r[0]].values())[0]
        #             else:
        #                 _stats = [0, 0, 0, 0]
        #             pnls.append([
        #                             self.strategy.id, self.strategy.id_no, r[0], _symbol, exchange, d_open_cash,
        #                             d_pnl, 1, self.day_night, strategy_type, hedge, position_cash, hedge_type
        #                         ] + _stats
        #                         )
        #         position_cash = day_position_cash[r[0]]
        #         prev_accumulate_pnl = r[1]
        #         if d_symbols:
        #             last_symbol = d_symbols
        # return pnls

    def calc_log_stats(self, is_backtest=False, vs_ids=None):
        return {}

    def calc_log_statsv3(self, is_backtest=False, vs_ids=None, **kwargs):
        return {}

    def calc_log_statsv2(self, is_backtest=False, vs_ids=None, **kwargs):
        """
        get trade_round(swap_ratio), order_num, cancel_num, transaction_volume from tradelogs
        """
        pnl_details = Strategy.pnl_detail(self.strategy.id)
        if is_backtest:
            if self.strategy_type in consts.stock_strategy_type:
                sql = """
                select trading_date,
                GROUP_CONCAT(DISTINCT symbol SEPARATOR ',') as symbol,
                sum(if(msg_type='3' and direction=1, trade_vol * trade_price, 0)) as short_notional,
                sum(if(msg_type='1' and entrust_status='a', 1, 0)) as total_order_num,
                sum(if(entrust_status='d', 1, 0)) as total_cancel_num,
                sum(if(msg_type='3', trade_vol, 0)) as total_trade_vol
                from backtest_trade_logs where  strategy_id={strategy_id} and symbol not in ('204001', '131810') GROUP BY trading_date;
                """.format(strategy_id=self.s_id)
            else:
                sql = """
                select trading_date, symbol,
                sum(if(msg_type='1' and entrust_status='a', 1, 0)) as total_order_num,
                sum(if(msg_type='3', 1, 0)) as total_order_num2,
                sum(if(entrust_status='d', 1, 0)) as total_cancel_num,
                sum(if(msg_type='3', trade_vol, 0)) as total_trade_vol,
                GROUP_CONCAT(open_close order by id) as open_close
                from backtest_trade_logs where  strategy_id={strategy_id} GROUP BY trading_date, symbol;
                """.format(strategy_id=self.s_id)

            pnls = pnl_details['back_test_pnl']
        else:
            vs_id = min(vs_ids)
            if self.strategy_type in consts.stock_strategy_type:
                sql = """select trading_date,
                GROUP_CONCAT(DISTINCT symbol SEPARATOR ',') as symbol,
                sum(if(log_type='3' and direction=1, trade_vol * trade_price, 0)) as short_notional,
                sum(if(entrust_status='a', 1, 0)) as total_order_num,
                sum(if(entrust_status='d', 1, 0)) as total_cancel_num,
                sum(if(log_type='3', trade_vol, 0)) as total_trade_vol
                from trade_logs where  vstrategy_id={vstrategy_id} and symbol not in ('204001', '131810') GROUP BY trading_date;
                """.format(vstrategy_id=vs_id)
            else:
                sql = """select
                trading_date, symbol,
                count(DISTINCT if(entrust_status='a', serial_no, NULL)) as total_order_num,
                sum(if(log_type='3', 1, 0)) as total_order_num2,
                sum(if(entrust_status='d', 1, 0)) as total_cancel_num,
                sum(if(log_type='3', trade_vol, 0)) as total_trade_vol,
                GROUP_CONCAT(open_close order by id) as open_close
                from trade_logs where  vstrategy_id={vstrategy_id} GROUP BY trading_date, symbol;
                """.format(vstrategy_id=vs_id)

            pnls = pnl_details['live_pnl'][vs_id]

        _MAP = {
            '0': 'OPEN',
            '1': 'CLOSE',
            '2': 'CLOSE',
            '3': 'CLOSE'
        }
        log_stats = {}
        for date in pnls.keys():
            log_stats[date] = {}
        rows = self.sc.execute(sql)
        if self.strategy_type in consts.stock_strategy_type:
            for row in rows:
                t_date = row[0].strftime('%Y%m%d')
                if t_date not in log_stats:
                    continue
                stats = log_stats[t_date]
                symbols = row[1].split(',')[:160]
                for sym in symbols:
                    stats[sym] = [
                        float(row[2]) / pnls[t_date][3], float(row[3]), float(row[4]), float(row[5])
                    ]
        else:
            for row in rows:
                t_date = row[0].strftime('%Y%m%d')
                if t_date not in log_stats:
                    continue
                stats = log_stats[t_date]
                if self.node in ('order_list', 'trademaster_order_list') and is_backtest:
                    order_num = int(row[3])
                else:
                    order_num = int(row[2])
                trade_round, _state = 0, ''
                for oc in row[6].split(','):
                    if oc not in _MAP:
                        continue
                    if _MAP[oc] != _state:
                        trade_round += 0.5
                        _state = _MAP[oc]
                stats[row[1]] = [
                    trade_round, order_num, float(row[4]), float(row[5])
                ]
        return log_stats

    def strategy_performance_v3(self, begin='20000101', end='21170101', config_id=0, cache=True):
        if (self.strategy.node not in ('back_test', 'order_list', 'group', 'trademaster_order_list')) \
                or (self.strategy.is_test != 0) or (self.strategy.is_delete != 0):
            return {}
        if config_id != 0:
            return {}
        data = {
            'index': [
                'strategy_id', 'strategy_name', 'date', 'symbol', 'exchange', 'open_cash', 'pnl', 'status',
                'day_night', 'strategy_type', 'hedge', 'position_cash', 'hedge_type', 'trade_round', 'order_num',
                'cancel_num', 'transaction_volume'
            ],
            'values': [],
        }
        strategy_type = '02' if self.strategy_type in consts.stock_strategy_type else '01'
        hedge = self.hedge or ''
        hedge_type = self.hedge_type or 'position'
        initial_cash = float(self.detail.get('initial_cash', 1000000) or 1000000)
        back_test_detail = {}
        symbol_exchanges = {}
        if self.group_id == 0:
            res = self.sc.query(
                StrategyResult.date.label('date'),
                StrategyResult.pnl.label('pnl'),
                StrategyResult.available_cash.label('available_cash'),
                StrategyResult.position_cash.label('position_cash')
            ).filter(
                StrategyResult.strategy_id == self.s_id,
                StrategyResult.config_id == config_id,
                StrategyResult.status == consts.TASK_FINISHED,
            ).order_by(StrategyResult.date)
            for r in res:
                confidence_pnl = float(r.pnl)
                if r.date < self._paper_trading_date and confidence_pnl > 0:
                    confidence_pnl *= self._confidence
                back_test_detail[r.date] = {
                    'confidence_pnl': confidence_pnl,
                    'pnl': float(r.pnl),
                    'symbols': set(),
                    'available_cash': r.available_cash and float(r.available_cash) or 0,
                    'position_cash': r.position_cash and float(r.position_cash) or 0,
                }
            symbols_res = self.sc.query(
                StrategyResultDetail.trading_date,
                StrategyResultDetail.symbol,
                StrategyResultDetail.exchange,
            ).filter(
                StrategyResultDetail.strategy_id == self.s_id,
                StrategyResultDetail.config_id == config_id,
            )
            for s_r in symbols_res:
                s_r_date = s_r[0].strftime('%Y%m%d')
                symbol_exchanges[s_r[1].lower()] = s_r[2]
                if s_r_date in back_test_detail:
                    back_test_detail[s_r_date]['symbols'].add(s_r[1])

        else:

            for s_id, w in self.strategy.group_detail.items():
                s = self.sc.query(Strategy).filter(
                    Strategy.id == s_id,
                ).first()
                s_paper_trading_date = (s.paper_trading_date or s.r_create_time).strftime('%Y%m%d')
                s_confidence = float(s.confidence)
                multiple = initial_cash / float(s.detail.get('initial_cash', 1000000) or 1000000)
                res = self.sc.query(
                    StrategyResult.date.label('date'),
                    StrategyResult.pnl.label('pnl'),
                    StrategyResult.available_cash.label('available_cash'),
                    StrategyResult.position_cash.label('position_cash')
                ).filter(
                    StrategyResult.strategy_id == s_id,
                    StrategyResult.config_id == config_id,
                    StrategyResult.status == consts.TASK_FINISHED,
                ).order_by(StrategyResult.date)
                for r in res:
                    r_pnl = float(r.pnl) * float(w) * multiple
                    confidence_pnl = r_pnl
                    if r.date < s_paper_trading_date and r_pnl > 0:
                        confidence_pnl *= s_confidence
                    if r.date not in back_test_detail:
                        back_test_detail[r.date] = {
                            'confidence_pnl': confidence_pnl,
                            'pnl': r_pnl,
                            'symbols': set(),
                            'available_cash': r.available_cash and float(r.available_cash) * float(w) * multiple or 0,
                            'position_cash': r.position_cash and float(r.position_cash) * float(w) * multiple or 0,
                        }
                    else:
                        back_test_detail[r.date]['pnl'] += r_pnl
                        back_test_detail[r.date]['confidence_pnl'] += confidence_pnl
                        back_test_detail[r.date]['available_cash'] += (
                                r.available_cash and float(r.available_cash) * float(w) * multiple or 0)
                        back_test_detail[r.date]['position_cash'] += (
                                r.position_cash and float(r.position_cash) * float(w) * multiple or 0)

            symbols_res = self.sc.query(
                StrategyResultDetail.trading_date,
                StrategyResultDetail.symbol,
                StrategyResultDetail.exchange,
            ).filter(
                StrategyResultDetail.strategy_id.in_([int(s_id) for s_id in self.strategy.group_detail.keys()]),
                StrategyResultDetail.config_id == config_id,
            )

            for s_r in symbols_res:
                s_r_date = s_r[0].strftime('%Y%m%d')
                symbol_exchanges[s_r[1].lower()] = s_r[2]
                if s_r_date in back_test_detail:
                    back_test_detail[s_r_date]['symbols'].add(s_r[1])

        open_cash, last_symbols, position_cash = initial_cash, [], 0
        if config_id == 0:
            backtest_log_stats = self.calc_log_statsv3(True, initial_cash=initial_cash)

        for d, d_detail in sorted(back_test_detail.items(), key=lambda _i: _i[0]):
            d_pnl = d_detail['confidence_pnl'] / ((len(d_detail['symbols'] or last_symbols)) or 1)
            for _symbol in (d_detail['symbols'] or last_symbols or ['']):
                exchange = consts.EXCHANGE.get(symbol_exchanges.get(_symbol.lower(), ''), 'UNKNOWN')
                if d in backtest_log_stats and _symbol in backtest_log_stats[d]:
                    _stats = backtest_log_stats[d][_symbol]
                else:
                    _stats = [0, 0, 0, 0]

                data['values'].append(
                    [
                        self.strategy.id, self.strategy.id_no, d, _symbol, exchange, open_cash, d_pnl, 0,
                        self.day_night, strategy_type, hedge, position_cash, hedge_type
                    ] + _stats
                )
            position_cash = d_detail['position_cash']
            if d_detail['symbols']:
                last_symbols = d_detail['symbols']
            open_cash += d_detail['pnl']

        live_pnls = self.get_live_performance_v2()
        live_dates = [l[2] for l in live_pnls]

        data['values'].extend(live_pnls)
        exchange_index = data['index'].index('exchange')
        status_index = data['index'].index('status')
        date_index = data['index'].index('date')
        pnl_index = data['index'].index('pnl')
        stock_values_back_test = [v for v in data['values'] if
                                  v[exchange_index] in ('SSE', 'SZSE') and v[status_index] == 0]
        stock_values_live = [v for v in data['values'] if v[exchange_index] in ('SSE', 'SZSE') and v[status_index] == 1]
        data['values'] = [v for v in data['values'] if v[exchange_index] not in ('SSE', 'SZSE')]

        back_test_values_tmp = {}
        for v in stock_values_back_test:
            if v[date_index] not in back_test_values_tmp:
                back_test_values_tmp[v[date_index]] = v
            else:
                back_test_values_tmp[v[date_index]][pnl_index] += v[pnl_index]

        live_values_tmp = {}
        for v in stock_values_live:
            if v[date_index] not in live_values_tmp:
                live_values_tmp[v[date_index]] = v
            else:
                live_values_tmp[v[date_index]][pnl_index] += v[pnl_index]

        if back_test_values_tmp:
            data['values'].extend(back_test_values_tmp.values())

        if live_values_tmp:
            data['values'].extend(live_values_tmp.values())
        data['values'] = sorted(data['values'], key=lambda v: v[data['index'].index('date')])
        if self.strategy_type in consts.stock_strategy_type:
            mean_trade_round = []
            trade_round_index = data['index'].index('trade_round')
            for v in data['values']:
                if v[trade_round_index] != 0:
                    mean_trade_round.append(v[trade_round_index])
            if mean_trade_round:
                mean_trade_round = sum(mean_trade_round) / len(mean_trade_round)
                for v in data['values']:
                    if v[trade_round_index] == 0:
                        v[trade_round_index] = mean_trade_round
        return data

    def run(self, cache=True, **kwargs):
        data = self.strategy_performance_v3()
        cache_key = 'strategy_performance_cache_%s' % self.id
        if cache and data['values']:
            set_cache(cache_key, data, 24 * 60 * 60)
        if data['values']:
            df = pd.DataFrame(data['values'], columns=data['index'])
            path = os.path.join(config.media, 'back_test_performace')
            if not os.path.exists(path):
                os.mkdir(path)
            df.to_pickle(os.path.join(path, '%s.pk' % cache_key))
        return True

    @staticmethod
    def get_strategy_performace(s_id):
        filepath = os.path.join(config.media, 'back_test_performace', 'strategy_performance_cache_%s.pk' % s_id)
        if not os.path.exists(filepath):
            StrategyPerformance._update_strategy(s_id)
        df = pd.read_pickle(filepath)
        return df

    @staticmethod
    def update_all_strategy():
        sc = session()
        strategies = sc.query(
            Strategy.id
        ).filter(
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.node.in_(['back_test', 'order_list', 'trademaster_order_list', 'group', 'union_simu']),
        )
        for s in strategies:
            StrategyPerformance._update_strategy(s[0])
        sc.close()
        return True

    @staticmethod
    def update_all_strategy_mutilprocess():
        from multiprocessing import Pool
        sc = session()
        strategies = sc.query(
            Strategy.id
        ).filter(
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.node.in_(['back_test', 'order_list', 'trademaster_order_list', 'group', 'union_simu']),
        )
        s_ids = [s[0] for s in strategies]
        sc.close()

        with Pool(processes=16) as pool:
            for s_id in s_ids:
                pool.apply_async(StrategyPerformance._update_strategy, [s_id])
            pool.close()
            pool.join()
        return True

    @staticmethod
    def _update_strategy(s_id):
        p = StrategyPerformance(s_id=s_id)
        try:
            p.run()
        except Exception as e:
            sentry.captureException()
        p.close()
        return True

    @staticmethod
    def update_strategy(s_id):
        sc = session()
        try:
            s = sc.query(
                Strategy.id.label('id'),
                Strategy.strategy_type.label('strategy_type')
            ).filter(
                Strategy.id == int(s_id),
                Strategy.is_delete == 0,
                Strategy.is_test == 0,
                Strategy.node.in_(['back_test', 'order_list', 'trademaster_order_list', 'group', 'union_simu']),
            ).first()
            if not s:
                return False

            StrategyPerformance._update_strategy(s_id)
            if s.strategy_type in consts.stock_strategy_type:
                StrategyPerformance.update_stock_ind(s_id)
        except Exception as e:
            sentry.captureException()
        sc.close()
        return True

    @staticmethod
    def update_stock_ind(s_id):
        sc = session()
        res = {
            'daily_stock_number': 0,
            'liquidity': 0,
            'withdraw_rate': 0,
        }
        try:
            s = sc.query(Strategy.detail.label('detail')).filter(
                Strategy.id == int(s_id),
                Strategy.is_delete == 0,
                Strategy.is_test == 0,
                Strategy.node.in_(['back_test', 'order_list', 'trademaster_order_list', 'group']),
            ).first()
            if not s:
                sc.close()
                return False

            sql1 = """
            select daily_stock_number, liquidity, withdraw_rate
            from strategy_back_test_trade_indicator where s_id={strategy_id};
            """.format(strategy_id=s_id)

            liquidity = []
            withdraw_rate = []
            sym_counts = []

            rows1 = sc.execute(sql1)
            for r in rows1:
                sym_counts.append(r[0])
                liquidity.append(r[1])
                withdraw_rate.append(r[2])

            if liquidity:
                res['liquidity'] = sum(liquidity) / len(liquidity)

            if withdraw_rate:
                res['withdraw_rate'] = sum(withdraw_rate) / len(withdraw_rate)

            if sym_counts:
                res['daily_stock_number'] = sum(sym_counts) / len(sym_counts)

            cache_key = 'platform_stock_indicators_%s' % s_id
            set_cache(cache_key, res, 86400)
        except Exception as e:
            sentry.captureException()

        sc.close()
        return res


class StrategyPortfolioPerformance(object):

    def __init__(self, s_ids, **kwargs):

        self.sc = session()
        self.kdb = KdbQuery()
        self.s_ids = [int(s_id) for s_id in s_ids]
        self.strategies = {}
        self.summary_dates = set()
        self.papertrading_dates = set()
        self.strategy_market_volume = {}
        self.start_dates = set()
        self.is_single_interest = False
        self.business = kwargs.get('business', '')
        self.total_init_cash = 0

    def __del__(self):
        self.sc.close()
        self.kdb.release()

    def get_back_test_pnl(self, s_id):

        s = self.sc.query(
            Strategy
        ).filter(
            Strategy.id == s_id
        ).first()
        if not s:
            return False

        s_detail = {
            'id': s.id,
            'id_no': s.id_no,
            'name': s.name,
            'st_uuid': s.st_uuid,
            'initial_cash': s.detail.get('initial_cash', 1000000) or 1000000,
            'strategy_type': s.strategy_type,
            'start_date': s.start_date,
            'paper_trading_date': (s.paper_trading_date or s.r_create_time).strftime('%Y-%m-%d'),
            'hedge': s.hedge,
            'hedge_type': s.hedge_type or 'position',
            'pnl_url': '/media/strategy_pnl_graph/strategy_%s_0_%sthumbnail.png' % (s.id, 'hedge_' if s.hedge else ''),
            'confidence': float(s.confidence),
            'annual_return': 'N/A',
            'sharpe': 'N/A',
            'max_drawdown': 'N/A',
            'back_test_pnl': {},
            'back_test_pnl_data': {},
            'is_single_interest': s.is_single_interest,
            'market_volume': 'N/A',
            'node': s.node
        }
        if s.is_single_interest:
            self.is_single_interest = True
        if s.strategy_type in consts.stock_strategy_type:
            self.business = 'stock'
        s_id_str = str(s.id)
        if s_id_str in self.strategy_market_volume:
            s_detail['market_volume'] = '%s / %s' % (
                self.strategy_market_volume[s_id_str]['trade_vol_percent_5'],
                self.strategy_market_volume[s_id_str]['trade_vol_percent_10']
            )

        self.papertrading_dates.add(s_detail['paper_trading_date'])
        self.start_dates.add(s_detail['start_date'])
        _pt_date = (s.paper_trading_date or s.r_create_time).strftime('%Y%m%d')
        _confidence = s_detail['confidence']

        fingerprint = 'pnl_%s_%s' % (s.id, s.st_uuid)
        cache_file_path = os.path.join(
            config.media, 'back_test_performace', '%s.json' % fingerprint
        )

        try:
            f = open(cache_file_path, 'r')
            data = simplejson.load(f)
            f.close()
            if data:
                s_detail['back_test_pnl_data'] = data
            self.strategies[s.id] = s_detail
            return True
        except Exception as e:
            pass

        if s.group_id > 0:
            back_test_result = s.group_back_test_result(config_id=0)
            back_test_result['paper_trading_date'] = ''
            back_test_result['back_test_end_position_value'] = 0
        else:
            res = self.sc.query(
                StrategyResult.date.label('date'),
                StrategyResult.pnl.label('pnl'),
                StrategyResult.position_cash.label('position_cash'),
                StrategyResult.total_asset.label('total_asset'),
            ).filter(
                StrategyResult.strategy_id == s.id,
                StrategyResult.config_id == 0,
                StrategyResult.status == consts.TASK_FINISHED
            ).order_by(StrategyResult.date)

            back_test_result = {
                'live_date': [],
                'live_pnl': [],
                'live_asset': [],
                'live_position_value': [],
                'live_end_position_value': 0.0,
                'live_cash_io': [],
                'back_test_date': [],
                'back_test_asset': [],
                'back_test_pnl': [],
                'back_test_position_value': [],
                'back_test_cash_io': [],
                'back_test_end_position_value': 0.0,
                'paper_trading_date': '',
            }

            initial_cash = s.detail.get('initial_cash', 1000000) or 1000000

            alpha_position_cash = {}
            if (s.strategy_type in consts.t0_stock_strategy_type) and s.detail.get('alpha_s_id'):
                try:
                    alpha_position_cash = get_t0_position(s.detail['alpha_s_id'], mode="new")
                except Exception as e:
                    alpha_position_cash = {}

            daily_open_asset = float(initial_cash)
            daily_position_cash = 0.0
            for r in res:
                back_test_result['back_test_date'].append(r.date)
                # back_test_result['back_test_asset'].append(daily_open_asset + alpha_position_cash.get(r.date, 0))
                back_test_result['back_test_asset'].append(daily_open_asset)
                r_pnl = float(r.pnl)
                if r.date < _pt_date and r_pnl > 0:
                    r_pnl *= _confidence
                back_test_result['back_test_pnl'].append(r_pnl)
                back_test_result['back_test_position_value'].append(daily_position_cash)
                back_test_result['back_test_cash_io'].append(0)

                if r.total_asset:
                    daily_open_asset = float(r.total_asset)
                else:
                    daily_open_asset += float(r.pnl)
                daily_position_cash = float(r.position_cash or 0.0)
            back_test_result['back_test_end_position_value'] = daily_position_cash

        if s.hedge:
            if len(back_test_result['back_test_position_value']) >= 2:
                back_test_result['back_test_position_value'][0] = back_test_result['back_test_position_value'][1]
            elif len(back_test_result['back_test_position_value']) == 1:
                back_test_result['back_test_position_value'][0] = back_test_result['back_test_end_position_value']

        if back_test_result['back_test_date']:
            s_detail['back_test_pnl_data'] = back_test_result
        self.strategies[s.id] = s_detail

        if s.st_uuid and len(back_test_result['back_test_date']) > 10:
            f = open(cache_file_path, 'w')
            simplejson.dump(back_test_result, f, cls=MyEncoder, ignore_nan=True)
            f.close()
        return True

    def cal_performance(self, s_id, start_date='20010101', end_date='21000101', paper_trading_date='', **kwargs):
        pnl_input = self.strategies[s_id]['back_test_pnl_data']
        hedge = self.strategies[s_id]['hedge']
        hedge_type = self.strategies[s_id]['hedge_type']
        is_single_interest = self.strategies[s_id].get('is_single_interest', False)
        if paper_trading_date:
            pnl_input['paper_trading_date'] = paper_trading_date
        if not hedge:
            if is_single_interest:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_stock_strategies_quest(pnl_input)
            else:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategies_quest(pnl_input)
        else:
            pnl_input['hedge'] = hedge
            pnl_input['hedge_type'] = hedge_type
            if is_single_interest:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_stock_strategy_hedge_quest(pnl_input)
            else:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategy_hedge_quest(pnl_input)

        if net_pnl[0]:
            return null_pnl_detail

        detail = net_pnl[1]

        pnl_index, opend_asset_index, close_asset_index = 1, 2, 3
        _pnl = {}
        if s_id == 'summary_data' and is_single_interest and (not hedge):
            _o_asset, _c_asset = 0, 0
            for i, (k, v) in enumerate(sorted(detail['back_test_pnl'].items(), key=lambda _x: _x[0])):
                if i == 0:
                    _pnl[k.decode('utf-8')] = v
                    continue
                if i == 1:
                    _o_asset = v[opend_asset_index]
                _c_asset = _o_asset + v[pnl_index]
                v[opend_asset_index] = _o_asset
                v[close_asset_index] = _c_asset
                _o_asset = _c_asset
                _pnl[k.decode('utf-8')] = v
        else:
            for k, v in detail['back_test_pnl'].items():
                _pnl[k.decode('utf-8')] = v

        pnl_detail = {
            'valid': True,
            'pnl': _pnl,
            'hedge_net': {},
            'origin_net': {},
            'sharpe': detail['back_test_sharpe'],
            'profitrate': detail['back_test_profitrate'],
            'annual_return': detail['back_test_annual_return'],  # 年化收益率
            'max_drawdown_pnl': detail['back_test_max_drawdown_pnl'],
            'max_drawdown_start': detail['back_test_max_drawdown_start'],
            'max_drawdown_end': detail['back_test_max_drawdown_end'],
            'return_over_drawdown': detail.get('back_test_return_over_drawdown', 0),
            'paper_trading_sharpe': detail['paper_trading_sharpe'],
            'paper_trading_profitrate': detail['paper_trading_profitrate'],
            'paper_trading_annual_return': detail['paper_trading_annual_return'],
            'paper_trading_max_drawdown_pnl': detail['paper_trading_max_drawdown_pnl'],
            'paper_trading_max_drawdown_start': detail['paper_trading_max_drawdown_start'],
            'paper_trading_max_drawdown_end': detail['paper_trading_max_drawdown_end'],
            'paper_trading_return_over_drawdown': detail.get('paper_trading_return_over_drawdown', 0),
        }

        if kwargs.get('graph'):

            try:
                filepath = os.path.join(config.media, 'strategy_pnl_graph')
                f_uuid = uuid.uuid4().hex
                self.strategies[s_id]['pnl_url'] = '/media/strategy_pnl_graph/strategy_%s.png' % f_uuid
                filename = os.path.join(
                    filepath, 'strategy_%s.png' % f_uuid
                )
                x_data, y_data = [], []
                for d, d_pnl in sorted(pnl_detail['pnl'].items(), key=lambda x: x[0]):
                    x_data.append(d)
                    y_data.append(d_pnl[0])
                fig = plt.figure(figsize=(1.2, 0.6), dpi=100)
                plt.plot(x_data, y_data, color='#4ad3e8', linewidth=1)
                plt.axis('off')
                plt.savefig(filename, transparent=True)
                plt.close(fig)
            except Exception as e:
                sentry.captureException()

        return pnl_detail

    def get_pnl_net_from_cache(self, s_id):
        try:
            fingerprint = 'pnl_default_net_%s_%s' % (s_id, self.strategies[s_id]['st_uuid'])
            cache_file_path = os.path.join(
                config.media, 'back_test_performace', '%s.json' % fingerprint
            )
            f = open(cache_file_path, 'r')
            data = simplejson.load(f)
            f.close()
            if data['pnl']:
                return data
        except Exception as e:
            return False

    def get_pnl_net(self, s_id):
        if not self.strategies.get(s_id, {}).get('back_test_pnl_data'):
            return False
        try:
            pnl = self.get_pnl_net_from_cache(s_id)
            if not pnl:
                pnl = self.cal_performance(s_id)
                fingerprint = 'pnl_default_net_%s_%s' % (s_id, self.strategies[s_id]['st_uuid'])
                cache_file_path = os.path.join(
                    config.media, 'back_test_performace', '%s.json' % fingerprint
                )
                f = open(cache_file_path, 'w')
                simplejson.dump(pnl, f, cls=MyEncoder, ignore_nan=True)
                f.close()
            self.strategies[s_id]['back_test_pnl'] = pnl
            self.strategies[s_id]['annual_return'] = pnl['annual_return']
            self.strategies[s_id]['sharpe'] = pnl['sharpe']
            self.strategies[s_id]['max_drawdown'] = pnl['max_drawdown_pnl']
            s_dates = sorted(pnl['pnl'].keys())
            if len(s_dates) >= 2:
                if not self.summary_dates:
                    self.summary_dates.update(s_dates[1:])
                else:
                    self.summary_dates &= set(s_dates[1:])
            return True
        except Exception as e:
            sentry.captureException()
            self.strategies[s_id]['back_test_pnl'] = null_pnl_detail
            return False

    def portfolio_analysis(self):

        self.strategy_market_volume = StrategyTradingVolumeRatioStatistic.get_max_volume_ratio()

        for s_id in self.s_ids:
            self.get_back_test_pnl(s_id)
            self.get_pnl_net(s_id)
            self.total_init_cash += self.strategies.get(s_id, {}).get('initial_cash', 0)

        summary_pnl_data = {
            'live_date': [],
            'live_pnl': [],
            'live_asset': [],
            'live_position_value': [],
            'live_end_position_value': 0.0,
            'live_cash_io': [],
            'back_test_date': [],
            'back_test_asset': [],
            'back_test_pnl': [],
            'back_test_position_value': [],
            'back_test_cash_io': [],
            'back_test_end_position_value': 0.0,
            'paper_trading_date': '',
        }
        daily_summary_pnl_data = {}
        sorted_summary_dates = sorted(self.summary_dates)
        s_back_test_end_position_value = {}
        d_index = 0
        for d in sorted_summary_dates:
            if d not in daily_summary_pnl_data:
                daily_summary_pnl_data[d] = {
                    'pnl': 0,
                    'open_asset': 0,
                    'back_test_position_value': 0,
                }

            for s_id in self.s_ids:
                s_pnl = self.strategies.get(s_id, {}).get('back_test_pnl', {}).get('pnl', {})
                daily_summary_pnl_data[d]['pnl'] += s_pnl[d][1]
                if self.business == 'stock':
                    daily_summary_pnl_data[d]['open_asset'] += self.strategies.get(s_id, {}).get('initial_cash', 0)
                else:
                    daily_summary_pnl_data[d]['open_asset'] += s_pnl[d][2]
                daily_summary_pnl_data[d]['back_test_position_value'] += s_pnl[d][5]
                s_back_test_end_position_value[s_id] = s_pnl[d][6]

            d_index += 1

        for d in sorted_summary_dates:
            summary_pnl_data['back_test_date'].append(d)
            summary_pnl_data['back_test_pnl'].append(daily_summary_pnl_data[d]['pnl'])
            summary_pnl_data['back_test_asset'].append(daily_summary_pnl_data[d]['open_asset'])
            summary_pnl_data['back_test_position_value'].append(daily_summary_pnl_data[d]['back_test_position_value'])
            summary_pnl_data['back_test_cash_io'].append(0)
        summary_pnl_data['back_test_end_position_value'] = sum(s_back_test_end_position_value.values())

        self.strategies['summary_data'] = {
            'id': 'summary_data',
            'id_no': 'summary_data',
            'strategy_status': 'PT',
            'name': 'summary_data',
            'initial_cash': '',
            'strategy_type': '',
            'start_date': '',
            'hedge': '',
            'hedge_type': '',
            'pnl_url': '/media/strategy_pnl_graph/strategy_%s_thumbnail.png' % uuid.uuid4().hex,
            'confidence': 1,
            'annual_return': 0,
            'sharpe': 0,
            'max_drawdown_pnl': 0,
            'max_drawdown_start': 0,
            'max_drawdown_end': 0,
            'pnl': {},
            'profitrate': 0,
            'back_test_pnl': {},
            'back_test_pnl_data': summary_pnl_data,
            'market_volume': '',
            'is_single_interest': self.is_single_interest,
        }
        if summary_pnl_data['back_test_date']:
            self.strategies['summary_data']['start_date'] = summary_pnl_data['back_test_date'][0]
            if self.business == 'stock':
                self.strategies['summary_data']['initial_cash'] = self.total_init_cash
            else:
                self.strategies['summary_data']['initial_cash'] = summary_pnl_data['back_test_asset'][0]

        pt_date = ''
        if self.papertrading_dates:
            pt_date = max(self.papertrading_dates)

        if self.start_dates:
            self.strategies['summary_data']['start_date'] = max(self.start_dates)

        self.strategies['summary_data']['papertrading_date'] = pt_date

        pnl = self.cal_performance('summary_data', graph=True, paper_trading_date=pt_date)
        self.strategies['summary_data']['back_test_pnl'] = pnl['pnl']

        self.strategies['summary_data']['back_test_pnl_data']['paper_trading_date'] = ''
        pnl2 = self.cal_performance('summary_data', graph=False, paper_trading_date='')

        self.strategies['summary_data']['annual_return'] = pnl2['annual_return']
        self.strategies['summary_data']['sharpe'] = pnl2['sharpe']
        self.strategies['summary_data']['max_drawdown_pnl'] = pnl2['max_drawdown_pnl']

        # self.strategies['summary_data']['hedge_net'] = pnl['hedge_net']
        # self.strategies['summary_data']['origin_net'] = pnl['origin_net']

        self.strategies['summary_data']['back_test_sharpe'] = pnl['sharpe']
        self.strategies['summary_data']['back_test_profitrate'] = pnl['profitrate']
        self.strategies['summary_data']['back_test_annual_return'] = pnl['annual_return']
        self.strategies['summary_data']['back_test_max_drawdown_pnl'] = pnl['max_drawdown_pnl']
        self.strategies['summary_data']['back_test_max_drawdown_start'] = pnl['max_drawdown_start']
        self.strategies['summary_data']['back_test_max_drawdown_end'] = pnl['max_drawdown_end']

        self.strategies['summary_data']['paper_trading_sharpe'] = pnl['paper_trading_sharpe']
        self.strategies['summary_data']['paper_trading_profitrate'] = pnl['paper_trading_profitrate']
        self.strategies['summary_data']['paper_trading_annual_return'] = pnl['paper_trading_annual_return']
        self.strategies['summary_data']['paper_trading_max_drawdown_pnl'] = pnl['paper_trading_max_drawdown_pnl']
        self.strategies['summary_data']['paper_trading_max_drawdown_start'] = pnl['paper_trading_max_drawdown_start']
        self.strategies['summary_data']['paper_trading_max_drawdown_end'] = pnl['paper_trading_max_drawdown_end']

        return True

    def analysis(self):
        self.portfolio_analysis()
        res = {
            'summary': {},
            'rows': [],
        }
        for k, s_d in self.strategies.items():
            if k == 'summary_data':
                res['summary'] = s_d
                del s_d['back_test_pnl_data']
            else:
                del s_d['back_test_pnl']
                del s_d['back_test_pnl_data']
                res['rows'].append(s_d)
        return res

    def correlation(self):
        self.portfolio_analysis()
        s_ids = []
        rows = []
        dates = []
        for k, s_d in self.strategies.items():
            if k != 'summary_data' and s_d['back_test_pnl'].get('pnl'):
                s_ids.append(s_d['id'])
                s_d['back_test_pnl'] = s_d['back_test_pnl']['pnl']
            elif k == 'summary_data':
                dates = sorted(s_d['back_test_pnl'].keys())[1:]

        s_ids.append('summary_data')
        for d in dates:
            rows.append(
                [float(self.strategies[s_id]['back_test_pnl'][d][0] / self.strategies[s_id]['back_test_pnl'][d][4]) - 1
                 for s_id in s_ids])

        columns = [self.strategies[s_id]['id_no'] for s_id in s_ids]

        columns[-1] = 'portfolio'

        df = pd.DataFrame(rows, columns=columns)
        ret = df.corr().round(4)
        res = {
            'columns': columns,
            'rows': ret.values,
        }
        return res

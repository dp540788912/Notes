# -*-coding:utf-8-*-

import os
import hashlib
import itertools
import random
import redis
import datetime
import copy
from sqlalchemy import or_, and_, func

import consts
from config import config
from db import session
from extensions import sentry
from service.statistic.baseservice import ServiceBaseService
from service.back_test.models import Users, Strategy, VStrategies, StrategyPortfolio, \
    VStrategyAccountDetail, StrategyPerfInput, StrategyRemark, InvestMentShare, \
    NewStrategySet, NewStrategySetdetail, NewStrategySetShare, DefaulStrategySet, StockHedgeVs
from service.back_test.live_position_models import VsBase
from service.statistic.live_pnl import VsPnlGraph
from service.statistic.models import VsAggregationPnl, VsTradingVolumeRatioStatistic, VsLiveRangePerformance
from service.operation_deploy.models import VstrategyUpgrade
from service.vwap.models import VsBackTestSlippage
from utils import get_cache, set_cache, del_cache
from utility.func_util import multi_sort
from constant import UserRoleConstant, StrategyPortfolioConstant


def gen_hash_value(data_list):
    data_list = sorted(data_list)
    md = hashlib.md5()
    for it in data_list:
        md.update(str(it).encode('utf8'))
    return md.hexdigest()


def gen_str_hash_value(s):
    md = hashlib.md5()
    md.update(str(s).encode('utf8'))
    return md.hexdigest()


class BaseInvestmentServiceMixin(object):

    def get_pnl_graph_url(self, pnl_args, **kwargs):
        if not pnl_args['vs_ids']:
            return ''
        vs_ids_str = '_'.join(map(str, sorted(pnl_args['vs_ids'])))
        vs_ids_str = gen_str_hash_value(vs_ids_str)
        summary = 'summary_' if pnl_args['summary'] else ''
        filename = summary + vs_ids_str + '_thumbnail.png'
        url = '/media/vs_pnl_graph/' + filename
        filename = os.path.join(config.media, 'vs_pnl_graph', filename)
        if not os.path.exists(filename):
            self.create_pnl_graph(pnl_args, filename)
        else:
            self.check_pnl_graph(pnl_args, filename)
        return url

    def create_pnl_graph(self, pnl_args, filename=''):
        try:
            vs_pnl = VsPnlGraph(vs_ids=pnl_args['vs_ids'], summary=pnl_args['summary'], filename=filename,
                                is_future=pnl_args.get('is_future'))
            vs_pnl.graph()
        except Exception as e:
            sentry.captureException()

    def check_pnl_graph(self, pnl_args, filename=''):
        from cron.strategy_upload_task import check_vs_pnl_graph
        check_vs_pnl_graph.delay(pnl_args, filename)
        return True

    def get_basic_data(self, cache=True):
        if cache:
            data = get_cache(self.cache_key)
        else:
            data = None
        if data:
            return data
        data = self.investment_basic_data()
        if data:
            set_cache(self.cache_key, data, 3600 * 8)
        return data

    def get_current_day_pnl(self, vs_ids):
        cache_key = 'platform_current_day_pnl_%s' % ('_'.join(map(str, sorted(vs_ids))))
        res = get_cache(cache_key)
        if res:
            return res
        total_pnl, today_pnl, fee = 0, 0, 0
        last_total_pnl = self.get_last_total_pnl()
        for v_id in vs_ids:
            pnl = self.get_vs_pnl(v_id)
            today_pnl += pnl['pnl']
            fee += pnl['fee']
            total_pnl += last_total_pnl.get(str(v_id), 0)

        res = {
            'today_pnl': today_pnl,
            'total_pnl': total_pnl + today_pnl,
            'fee': fee,
        }
        set_cache(cache_key, res, 8 + random.randint(2, 7))
        return res

    def get_vs_pnl(self, vs_id):
        vs_id_str = str(vs_id)

        if vs_id in consts.hk_stock_vs_ids:
            is_hk_stock = True
        else:
            is_hk_stock = False

        v_trade_d = self.trade_detail.get(vs_id_str, {})
        pnl, fee = 0, 0
        now_time = datetime.datetime.now().strftime('%H%M')
        vs_strategy_type = self.vs_detail.get(vs_id, {}).get('strategy_type')
        for k, s_trade_d in v_trade_d.items():
            if k in ('trading_date', 'day_night'):
                continue
            symbol = s_trade_d['symbol']
            if symbol in ('204001', '131810'):
                continue
            try:
                currency = self.vs_detail[vs_id]['acc_currency'][s_trade_d['account']]
            except Exception as e:
                sentry.captureException()
                currency = 'CNY'
            if s_trade_d['account'] in consts.FOREGIN_ACCOUNT:
                currency = consts.FOREGIN_ACCOUNT[s_trade_d['account']]
            trade_unit = self.get_symbol_trade_unit(symbol, currency)
            exchange_rate = self.get_exchange_rate(currency)
            long_fee, short_fee = 0, 0
            if s_trade_d['bov'] > 0:
                long_fee_data = {
                    'symbol': symbol,
                    'currency': currency,
                    'direction': 0,
                    'open_close': 0,
                    'exchange_rate': exchange_rate,
                    'volume': s_trade_d['bov'],
                    'turnover': (s_trade_d['bon']) * trade_unit,
                    'trade_unit': trade_unit,
                    'is_hk_stock': is_hk_stock,
                }
                try:
                    long_fee += self.cal_fee(long_fee_data)
                except Exception as e:
                    sentry.captureException()

            if s_trade_d['sov'] > 0:
                long_fee_data = {
                    'symbol': symbol,
                    'currency': currency,
                    'direction': 1,
                    'open_close': 0,
                    'exchange_rate': exchange_rate,
                    'volume': s_trade_d['sov'],
                    'turnover': (s_trade_d['son']) * trade_unit,
                    'trade_unit': trade_unit,
                    'is_hk_stock': is_hk_stock,
                }
                try:
                    long_fee += self.cal_fee(long_fee_data)
                except Exception as e:
                    sentry.captureException()

            if s_trade_d['scv'] > 0:
                short_fee_data = {
                    'symbol': symbol,
                    'currency': currency,
                    'direction': 1,
                    'open_close': 1,
                    'exchange_rate': exchange_rate,
                    'volume': s_trade_d['scv'],
                    'turnover': (s_trade_d['scn']) * trade_unit,
                    'trade_unit': trade_unit,
                    'is_hk_stock': is_hk_stock,
                }
                try:
                    short_fee += self.cal_fee(short_fee_data)
                except Exception as e:
                    sentry.captureException()

            if s_trade_d['bcv'] > 0:
                short_fee_data = {
                    'symbol': symbol,
                    'currency': currency,
                    'direction': 0,
                    'open_close': 1,
                    'exchange_rate': exchange_rate,
                    'volume': s_trade_d['bcv'],
                    'turnover': (s_trade_d['bcn']) * trade_unit,
                    'trade_unit': trade_unit,
                    'is_hk_stock': is_hk_stock,
                }
                try:
                    short_fee += self.cal_fee(short_fee_data)
                except Exception as e:
                    sentry.captureException()

            try:
                if symbol in ('204001', '131810'):
                    last_price = 0
                elif symbol in ('H00905', 'h00905'):
                    last_price = self.get_h00905_last_price()
                # 兼容股指
                elif symbol in ('000905.sh', '000905.SH'):
                    last_price = self.quote_data[symbol]['LastPrice'] / 10000
                else:
                    last_price = self.quote_data[symbol]['LastPrice']
                if last_price < 0:
                    raise ValueError('%s, %s, last price error' % (symbol, last_price))
                if symbol.isdigit() and ('0800' <= now_time <= '0925'):
                    last_price = 0
                    raise ValueError('%s, %s, last price error2' % (symbol, last_price))
            except Exception as e:
                # sentry.captureException()
                last_price = 0
                if s_trade_d['last_bov'] + s_trade_d['bov'] + s_trade_d['sov'] + s_trade_d['last_sov']:
                    last_price = (
                                         s_trade_d['last_bon'] + s_trade_d['bon'] + s_trade_d['son'] + s_trade_d[
                                     'last_son']
                                 ) / float(
                        s_trade_d['last_bov'] + s_trade_d['bov'] + s_trade_d['sov'] + s_trade_d['last_sov'])

            long_pnl = last_price * (
                    s_trade_d['last_bov'] + s_trade_d['bov'] - s_trade_d['scv']
            ) + s_trade_d['scn'] - (s_trade_d['last_bon'] + s_trade_d['bon'])

            short_pnl = (s_trade_d['last_son'] + s_trade_d['son']) - s_trade_d['bcn'] - last_price * (
                    s_trade_d['last_sov'] + s_trade_d['sov'] - s_trade_d['bcv']
            )

            if vs_strategy_type in consts.t0_stock_strategy_type:
                long_pnl -= s_trade_d['last_long_freeze'] * (last_price - s_trade_d['last_settle_price'])
                short_pnl -= s_trade_d['last_short_freeze'] * (s_trade_d['last_settle_price'] - last_price)
            if symbol[:2].lower() == 'uc':
                exchange_rate = 1
            fee += long_fee + short_fee
            pnl += ((long_pnl + short_pnl) * exchange_rate * trade_unit - long_fee - short_fee)
        return {
            'pnl': pnl,
            'fee': fee,
        }

    def get_current_day_trading_logs(self, cache=True):

        cache_key = 'platform_vstartegy_today_trading_data'

        trading_data = {}

        if cache:
            trading_data = get_cache(cache_key)

        if trading_data and trading_data['trading_date'] == self.trading_date:
            return trading_data
        trading_data = {
            'trading_date': self.trading_date,
        }

        sql = """select vstrategy_id, symbol, account, direction, open_close, sum(trade_vol), sum(trade_vol* trade_price) from
          ((select vstrategy_id, symbol, account, direction, open_close, trade_vol,  trade_price
          from trade_logs  where trading_date={trading_date} and log_type='3' and entrust_status in ('p', 'c'))
          UNION all (
           select vstrategy_id, symbol, account,
            case direction when 'BUY' then 0 when 'SELL' then 1 end as direction,
            case open_close when 'OPEN' then 0 when 'CLOSE' then 1 end as open_close,
           trade_vol,  trade_price
           from settlement_manual_tradelogs where trading_date={trading_date}
          )) as a
         group by vstrategy_id, symbol, account, direction, open_close
        """.format(trading_date=self.trading_date)
        for r in self.sc.execute(sql):
            v_id = str(r[0])
            sym = r[1]
            acc = r[2]
            d_flag = int(r[3])
            o_flag = int(r[4])
            qty = float(r[5])
            amount = float(r[6])
            v_trade = trading_data.setdefault(v_id, {})
            v_sym_trade = v_trade.setdefault('%s|%s' % (sym, acc), {
                'symbol': sym,
                'account': acc,
                'bov': 0,
                'bon': 0,
                'scv': 0,
                'scn': 0,
                'sov': 0,
                'son': 0,
                'bcv': 0,
                'bcn': 0,
                'last_bov': 0,
                'last_bon': 0,
                'last_sov': 0,
                'last_son': 0,
                'last_long_freeze': 0,
                'last_short_freeze': 0,
                'last_settle_price': 0,
            })
            if d_flag == consts.Direction.buy.value and o_flag == consts.OpenClose.open.value:
                # buy open
                v_sym_trade['bov'] += qty
                v_sym_trade['bon'] += amount
            elif d_flag == consts.Direction.sell.value and o_flag == consts.OpenClose.open.value:
                # sell open
                v_sym_trade['sov'] += qty
                v_sym_trade['son'] += amount
            elif d_flag == consts.Direction.sell.value:
                # sell close
                v_sym_trade['scv'] += qty
                v_sym_trade['scn'] += amount
            elif d_flag == consts.Direction.buy.value:
                # buy close
                v_sym_trade['bcv'] += qty
                v_sym_trade['bcn'] += amount
        for v_id, pos in self.lastday_position.items():
            if v_id in ('trading_date', 'day_night'):
                continue
            v_trade = trading_data.setdefault(v_id, {})
            for k, sym_pos in pos.items():
                v_sym_trade = v_trade.setdefault(k, {
                    'symbol': sym_pos['symbol'],
                    'account': sym_pos['account'],
                    'bov': 0,
                    'bon': 0,
                    'scv': 0,
                    'scn': 0,
                    'sov': 0,
                    'son': 0,
                    'bcv': 0,
                    'bcn': 0,
                    'last_bov': 0,
                    'last_bon': 0,
                    'last_sov': 0,
                    'last_son': 0,
                    'last_long_freeze': 0,
                    'last_short_freeze': 0,
                    'last_settle_price': 0,
                })
                v_sym_trade['last_bov'] += sym_pos['long_pos']
                v_sym_trade['last_bon'] += sym_pos['long_pos'] * sym_pos['settle_price']
                v_sym_trade['last_sov'] += sym_pos['short_pos']
                v_sym_trade['last_son'] += sym_pos['short_pos'] * sym_pos['settle_price']
                v_sym_trade['last_long_freeze'] = sym_pos.get('long_freeze', 0)
                v_sym_trade['last_short_freeze'] = sym_pos.get('short_freeze', 0)
                v_sym_trade['last_settle_price'] = sym_pos['settle_price']
        set_cache(cache_key, trading_data, 100 + random.randint(0, 50))
        return trading_data

    def get_lastday_position(self, cache=True):

        cache_key = 'platform_vstartegy_lastday_position_data'
        data = {}
        if cache:
            data = get_cache(cache_key)
        if data and data['trading_date'] == self.trading_date:
            return data
        data = {
            'trading_date': self.trading_date,
            'day_night': self.day_night,
        }

        sql = """
        select vstrategy_id, symbol, today_long_pos, today_short_pos, today_settle_price, account,
        today_long_freeze_pos, today_short_freeze_pos
        from vs_positions
        where settle_date = (select max(settle_date) from vs_base where daynight='DAY')
        and daynight='DAY' and (today_long_pos > 0 or today_short_pos >0)
        """
        for r in self.sc.execute(sql):
            v_id = str(r[0])
            sym = r[1]
            acc = r[5]
            v_pos = data.setdefault(v_id, {})
            v_pos['%s|%s' % (sym, acc)] = {
                'symbol': sym,
                'account': acc,
                'long_pos': float(r[2]),
                'short_pos': float(r[3]),
                'settle_price': float(r[4]),
                'long_freeze': float(r[6]),
                'short_freeze': float(r[7]),
            }
        if self.day_night == 0:
            sql = """
            select vstrategy_id, symbol, today_long_pos, today_short_pos, today_settle_price, account,
            today_long_freeze_pos, today_short_freeze_pos
            from vs_positions
            where settle_date = {settle_date} and daynight='NIGHT' and (today_long_pos > 0 or today_short_pos >0)
            and vstrategy_id in (select vs.id from vstrategies vs, strategy s where vs.status >= 15 and
            vs.strategy_id = s.id and s.strategy_type in {stock_strategy_type}
            )
            """.format(
                settle_date=self.trading_date, stock_strategy_type=str(consts.stock_strategy_type)
            )
            for r in self.sc.execute(sql):
                v_id = str(r[0])
                sym = r[1]
                acc = r[5]
                v_pos = data.setdefault(v_id, {})
                v_pos['%s|%s' % (sym, acc)] = {
                    'symbol': sym,
                    'account': acc,
                    'long_pos': float(r[2]),
                    'short_pos': float(r[3]),
                    'settle_price': float(r[4]),
                    'long_freeze': float(r[6]),
                    'short_freeze': float(r[7]),
                }
        set_cache(cache_key, data, 3600)
        return data

    def get_last_total_pnl(self, cache=True):
        cache_key = 'platform_vs_last_settle_total_pnl'
        data = {}
        if cache:
            data = get_cache(cache_key)
        if data and data['trading_date'] == self.trading_date:
            return data
        data = {
            'trading_date': self.trading_date,
            'day_night': self.day_night,
        }
        sql = """
        select vstrategy_id, accumulated_pnl from vs_base where daynight='DAY' and (vstrategy_id, settle_date) in
        (select vstrategy_id, max(settle_date) from vs_base where daynight='DAY' and settle_date<{trading_date} 
        group by vstrategy_id)
        """.format(trading_date=self.trading_date)
        for r in self.sc.execute(sql):
            data[str(r[0])] = float(r[1])
        set_cache(cache_key, data, 3600)
        return data

    @property
    def lastday_position(self):
        return self.get_lastday_position()

    @property
    def last_total_pnl(self):
        return self.get_last_total_pnl()

    def get_current_day_realtime_trading_logs(self, vs_ids):

        trading_data = {}
        vs_ids_str = list(map(str, vs_ids))
        where_str = 'vstrategy_id in (%s) and ' % ','.join(vs_ids_str)

        sql = """select vstrategy_id, symbol, direction, open_close, sum(trade_vol), sum(trade_vol* trade_price) from
          ((select vstrategy_id, symbol, direction, open_close, trade_vol,  trade_price
          from trade_logs  where {where_str} trading_date={trading_date} and log_type='3' and entrust_status in ('p', 'c'))
          UNION all (
           select vstrategy_id, symbol,
            case direction when 'BUY' then 0 when 'SELL' then 1 end as direction,
            case open_close when 'OPEN' then 0 when 'CLOSE' then 1 end as open_close,
           trade_vol,  trade_price
           from settlement_manual_tradelogs where {where_str} trading_date={trading_date}
          )) as a
         group by vstrategy_id, symbol, direction, open_close
        """.format(trading_date=self.trading_date, where_str=where_str)
        for r in self.sc.execute(sql):
            v_id = str(r[0])
            sym = r[1]
            d_flag = int(r[2])
            o_flag = int(r[3])
            qty = float(r[4])
            amount = float(r[5])
            v_trade = trading_data.setdefault(v_id, {})
            v_sym_trade = v_trade.setdefault('%s' % sym, {
                'symbol': sym,
                'bov': 0,
                'bon': 0,
                'scv': 0,
                'scn': 0,
                'sov': 0,
                'son': 0,
                'bcv': 0,
                'bcn': 0,
                'last_bov': 0,
                'last_bon': 0,
                'last_sov': 0,
                'last_son': 0,
                'last_settle_price': 0,
            })
            if d_flag == consts.Direction.buy.value and o_flag == consts.OpenClose.open.value:
                # buy open
                v_sym_trade['bov'] += qty
                v_sym_trade['bon'] += amount
            elif d_flag == consts.Direction.sell.value and o_flag == consts.OpenClose.open.value:
                # sell open
                v_sym_trade['sov'] += qty
                v_sym_trade['son'] += amount
            elif d_flag == consts.Direction.sell.value:
                # sell close
                v_sym_trade['scv'] += qty
                v_sym_trade['scn'] += amount
            elif d_flag == consts.Direction.buy.value:
                # buy close
                v_sym_trade['bcv'] += qty
                v_sym_trade['bcn'] += amount
        for v_id, pos in self.lastday_position.items():
            if vs_ids_str and (v_id not in vs_ids_str):
                continue
            if v_id in ('trading_date', 'day_night'):
                continue
            v_trade = trading_data.setdefault(v_id, {})
            for _, sym_pos in pos.items():
                v_sym_trade = v_trade.setdefault(sym_pos['symbol'], {
                    'symbol': sym_pos['symbol'],
                    'bov': 0,
                    'bon': 0,
                    'scv': 0,
                    'scn': 0,
                    'sov': 0,
                    'son': 0,
                    'bcv': 0,
                    'bcn': 0,
                    'last_bov': 0,
                    'last_bon': 0,
                    'last_sov': 0,
                    'last_son': 0,
                    'last_settle_price': sym_pos['settle_price'],
                })
                v_sym_trade['last_bov'] += sym_pos['long_pos']
                v_sym_trade['last_bon'] += sym_pos['long_pos'] * sym_pos['settle_price']
                v_sym_trade['last_sov'] += sym_pos['short_pos']
                v_sym_trade['last_son'] += sym_pos['short_pos'] * sym_pos['settle_price']
        return trading_data

    def get_current_day_realtime_position(self, vs_ids):
        trading_data = self.get_current_day_realtime_trading_logs(vs_ids)
        position = {}

        live_quote = self.get_live_quote()

        for v_id, vs_trade in trading_data.items():
            vs_pos = position.setdefault(v_id, {})
            for sym, sym_trade in vs_trade.items():
                vs_sym_pos = {
                    'long': sym_trade['last_bov'] + sym_trade['bov'] - sym_trade['scv'],
                    'short': sym_trade['last_sov'] + sym_trade['sov'] - sym_trade['bcv'],
                    'price': live_quote.get(sym, {}).get('LastPrice', sym_trade['last_settle_price'])
                }
                if vs_sym_pos['long'] > vs_sym_pos['short'] > 0:
                    vs_sym_pos['long'] = vs_sym_pos['long'] - vs_sym_pos['short']
                    vs_sym_pos['short'] = 0
                vs_pos[sym] = vs_sym_pos

        return position


class InvestmentPerformanceService(BaseInvestmentServiceMixin, ServiceBaseService):
    _lastday_position = {}
    _last_total_pnl = {}

    def __init__(self, current_user, id_list, **kwargs):
        self.current_user = current_user
        self.id_list = id_list
        self.kwargs = kwargs
        self.business = kwargs.get('business', '')
        self.sc = session()
        self.trading_date, self.day_night = StrategyPerfInput.get_trading_date_day_night()

        self.is_stock_page = kwargs.get('is_stock_page', False)
        self.is_stock_group = kwargs.get('is_stock_group', False)
        self.is_future_page = kwargs.get('is_future_page', False)
        self.is_future_group = kwargs.get('is_future_group', False)

        self.cache_key = kwargs.get('cache_key', '')
        if not self.cache_key:
            self.cache_key = 'platform_investment_basic_data_%s_%s' % (
                self.current_user['id'], gen_hash_value(self.id_list) + self.business + '_'.join(map(str, [
                    self.is_stock_page, self.is_stock_group, self.is_future_page, self.is_future_group
                ]))
            )
        self.vs_detail = {}
        self.trade_detail = {}

        self.share_strategy_set_business = ['stock', 'future', 'default']
        if self.business:
            self.share_strategy_set_business = [self.business]
        else:
            if self.is_stock_page:
                self.share_strategy_set_business = ['stock']
            elif self.is_future_page:
                self.share_strategy_set_business = ['future']

        super(InvestmentPerformanceService, self).__init__()

    def __del__(self):
        self.sc.close()
        self.kdb.release()

    def close(self):
        self.sc.close()
        self.kdb.release()

    def investment_basic_data(self):
        strategies_detail = self.sc.query(
            VStrategies.id.label('vs_id'),
            VStrategies.status.label('strategy_status'),
            VStrategies.closing_out.label('close_status'),
            VStrategies.trade_model.label('vs_trade_model'),
            VStrategies.deploy_server.label('vs_server'),
            Strategy.id_no.label('id_no'),
            Strategy.id.label('s_id'),
            Strategy.r_create_user_id.label('s_user_id'),
            Strategy.username.label('creator'),
            Strategy.products.label('s_products'),
            Strategy.strategy_type.label('strategy_type'),
            Strategy.r_create_time.label('s_create_time'),
            Strategy.name.label('s_name'),
            StrategyPortfolio.id.label('sp_id'),
            StrategyPortfolio.name.label('portfolio_name'),
            StrategyPortfolio.r_create_user_id.label('p_user_id'),
            StrategyPortfolio.live_time.label('p_live_time'),
            StrategyPortfolio.r_create_time.label('p_create_time'),
            Strategy.strategy_feature.label('strategy_feature'),
            Strategy.strategy_para_type.label('strategy_para_type'),
            Strategy.description.label('desc'),
            Strategy.paper_trading_date.label('paper_trading_date'),
            Strategy.hedge.label('hedge'),
            Strategy.hedge_type.label('hedge_type'),
            Strategy.detail.label('s_detail'),
            Strategy.node.label('node'),
        ).join(
            Strategy, or_(
                and_(
                    Strategy.id == VStrategies.strategy_id,
                    VStrategies.group_id == 0
                ),
                Strategy.id == VStrategies.group_id
            )
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            StrategyPortfolio.status >= consts.STRATEGY_LIVE,
            StrategyPortfolio.source == 'platform',
            VStrategies.source == 'platform'
        )

        # Filter for different strategy-set on live trading performance page.
        if len(self.id_list) > 0:
            if self.id_list[0] == 0:
                strategies_detail = strategies_detail.filter(
                    VStrategies.status == consts.STRATEGY_LIVE,
                )
            elif self.id_list[0] == -1:
                strategies_detail = strategies_detail.filter(
                    VStrategies.status == consts.STRATEGY_OFF_SHELF,
                )
            else:
                if self.id_list[0] > 200000:
                    strategies_detail = strategies_detail.filter(Strategy.id.in_(self.id_list))
                else:
                    strategies_detail = strategies_detail.filter(VStrategies.id.in_(self.id_list))

        if not self.current_user['is_superuser']:
            if self.business:
                strategies_detail = strategies_detail.filter(
                    StrategyPortfolio.business == self.business
                )
            else:
                if self.is_stock_page:
                    strategies_detail = strategies_detail.filter(
                        StrategyPortfolio.business == 'stock',
                        Strategy.r_create_user_id == self.current_user['id']
                    )
                elif self.is_future_page:
                    strategies_detail = strategies_detail.filter(
                        StrategyPortfolio.business == 'future',
                        Strategy.r_create_user_id == self.current_user['id']
                    )
                else:
                    # user id is 302(yinhuo2), then return all strategies
                    # created by fund/product users.
                    strategies_detail = strategies_detail.filter(
                        StrategyPortfolio.r_create_user_id.in_(
                            [self.current_user['id']] if self.current_user[
                                                             'id'] != 302 else consts.investment_user_ids)
                    )

        strategies_detail = strategies_detail.order_by(Strategy.id.desc())
        # strategy_user_ids = [self.current_user['id']]

        summary = {
            'vs_ids': [],
            'upgrade_vs_ids': [],
            'today_pnl': 0,
            'total_pnl': 0,
            'total_point': 0,
            'total_net_income': 0,
            'invest_funds': 0,
            'total_invest_cash': 0,
            'pnl_url': '',
            'pnl_args': {
                'summary': True,
            },
            'year_pnl': 0,
            'month_1_pnl': 0,
            'trading_days_20_pnl': 0,
            'trading_days_40_pnl': 0,
            'trading_days_60_pnl': 0,
            'season_1_pnl': 0,
        }

        strategies = {}
        vs_detail = {}
        group_detail = {}

        upgrade_vs_ids = VstrategyUpgrade.get_vs_upgrades()

        for s in strategies_detail:
            if s.s_id not in strategies:
                strategies[s.s_id] = {
                    'create_user_id': s.s_user_id,
                    'status': '',
                    'creator': s.creator,
                    'desc': s.desc,
                    'hedge': s.hedge,
                    'hedge_type': s.hedge_type,
                    'upload_type': s.node if s.node != 'back_test' else 'so_file',
                    'invest_funds': 0,
                    'name': s.s_name,
                    'display_name': s.s_name,
                    'papertrading_date': (s.paper_trading_date or s.s_create_time).strftime('%Y-%m-%d'),
                    'products': s.s_products,
                    'trade_model': s.s_detail.get('trade_model', ''),
                    'vs_trade_model': s.vs_trade_model or s.s_detail.get('trade_model', ''),
                    'server': s.vs_server or 'default',
                    'realtime': '',
                    's_id': s.s_id,
                    'strategy_feature': s.strategy_feature,
                    'strategy_id': s.id_no,
                    'strategy_para_type': s.strategy_para_type,
                    'strategy_type': s.strategy_type,
                    'today_pnl': 0,
                    'total_net_income': 0,
                    'total_pnl': 0,
                    'total_point': 0,
                    'uptime': s.s_create_time.strftime('%Y%m%d'),
                    'ctime': s.s_create_time.strftime('%Y%m%d %X'),
                    'vwap_slippage': {
                        'avg': None,
                        'std': None
                    },
                    'accounts': [],
                    'notebook_links': [],
                    'p_user_id': s.p_user_id,
                    'portfolio_optimization_so_version': s.s_detail.get('portfolio_optimization_so_version', '--'),
                    'vwap_version': s.s_detail.get('vwap_version', 'vwap_classic'),
                    'year_pnl': 0,
                    'month_1_pnl': 0,
                    'trading_days_20_pnl': 0,
                    'trading_days_40_pnl': 0,
                    'trading_days_60_pnl': 0,
                    'season_1_pnl': 0,
                    'vwap_slippage2': 'N/A'
                }
                if s.strategy_type in consts.stock_strategy_type:
                    strategies[s.s_id]['display_name'] = '/'.join([
                        s.s_name,
                        s.s_detail.get('portfolio_optimization_so_version', '--'),
                        s.s_detail.get('vwap_version', 'vwap_classic'),
                    ])
                # strategy_user_ids.append(s.s_user_id)
            group_d = group_detail.setdefault((s.sp_id, s.s_id), {
                'vs_ids': [],
                'upgrade_vs_ids': []
            })
            group_d['vs_ids'].append(s.vs_id)
            group_d['upgrade_vs_ids'].extend(upgrade_vs_ids.get(str(s.vs_id), []))
            group_d['portfolio_name'] = s.portfolio_name

            vs_d = vs_detail.setdefault(s.vs_id, {
                'invest_funds': 0,
                'accounts': [],
            })
            vs_d['realtime'] = (s.p_live_time or s.p_create_time).strftime('%Y%m%d')
            vs_d['status'] = s.strategy_status
            vs_d['close_status'] = s.close_status
            summary['vs_ids'].append(s.vs_id)
            summary['upgrade_vs_ids'].extend(upgrade_vs_ids.get(str(s.vs_id), []))

        summary['pnl_args']['vs_ids'] = summary['vs_ids'] + summary['upgrade_vs_ids']
        # TODO: 11111111 purpose ?
        # Confirmed information: 11111111 is not used by front end.
        # So may be it can be ignored.
        if 11111111 in self.id_list:
            summary['pnl_args']['vs_ids'].append(11111111)
            summary['vs_ids'].append(11111111)
        # summary['vs_ids'] = summary['vs_ids'] + [11111111] if 11111111 in self.id_list else summary['vs_ids']
        summary['pnl_args']['is_future'] = self.is_future_page
        summary['pnl_url'] = self.get_pnl_graph_url(summary['pnl_args'])
        # Strategy comment
        strategy_remarks = self.sc.query(StrategyRemark).filter(StrategyRemark.sid.in_(strategies.keys()))
        for r in strategy_remarks:
            if r.links:
                strategies[r.sid]['notebook_links'].extend(r.links)

        invest_funds = self.sc.query(
            VStrategyAccountDetail.vstrategy_id.label('vs_id'),
            VStrategyAccountDetail.account.label('account'),
            func.sum(VStrategyAccountDetail.amount).label('amount'),
            func.sum(VStrategyAccountDetail.actual_amount).label('actual_amount'),
        ).filter(
            VStrategyAccountDetail.vstrategy_id.in_(vs_detail.keys()),
        ).group_by(
            VStrategyAccountDetail.vstrategy_id,
            VStrategyAccountDetail.account
        )
        for r in invest_funds:
            vs_detail[r.vs_id]['accounts'].append(r.account)
            if vs_detail[r.vs_id]['status'] == consts.STRATEGY_LIVE:
                vs_detail[r.vs_id]['invest_funds'] += float(r.amount)
                summary['invest_funds'] += float(r.amount)

        summary['total_invest_cash'] = sum(VStrategyAccountDetail.get_vstrategy_cash2(
            summary['vs_ids'] + [11111111] if 11111111 in self.id_list else summary['vs_ids'],
            is_future=self.is_future_page
        ).values())

        for (sp_id, s_id), group_d in group_detail.items():
            group_d.update(strategies[s_id])
            group_d['realtime'] = min([vs_detail[v_id]['realtime'] for v_id in group_d['vs_ids']])
            if (self.current_user['id'] == strategies[s_id]['p_user_id']) or self.business:
                group_d['accounts'] = list(set(itertools.chain.from_iterable(
                    [vs_detail[v_id]['accounts'] for v_id in group_d['vs_ids']]
                )))
            else:
                group_d['accounts'] = []
            if group_d['vs_ids']:
                group_d['vwap_slippage'] = Strategy.get_strategy_slippage(ids=group_d['vs_ids'], id_type='vs')
                if self.is_stock_page:
                    try:
                        vwap_slippage_live = group_d['vwap_slippage'].get('avg', 0) or 0
                        vwap_slippage_bt = VsBackTestSlippage.get_strategy_slippage(group_d['vs_ids']).get('avg',
                                                                                                           0) or 0
                        group_d['vwap_slippage2'] = '%s / %s' % (
                            round(vwap_slippage_live, 2), round(vwap_slippage_bt, 2))
                    except Exception as e:
                        pass

                group_d['status'] = VStrategies.get_status(
                    vs_detail[group_d['vs_ids'][0]]['status'],
                    vs_detail[group_d['vs_ids'][0]]['close_status'],
                    group_d['vs_ids'][0]
                )
                group_d['vs_status_code'] = vs_detail[group_d['vs_ids'][0]]['status']
                group_d['invest_funds'] = sum(
                    [vs_detail.get(v_id, {}).get('invest_funds', 0) for v_id in group_d['vs_ids']])

            group_d['id'] = '%s_%s' % (sp_id, s_id)
            group_d['pnl_args'] = {
                'summary': False,
                'vs_ids': group_d['vs_ids'] + group_d['upgrade_vs_ids'],
                'strategy_id': group_d['s_id'],
            }
            group_d['pnl_url'] = self.get_pnl_graph_url(group_d['pnl_args'])

        if self.is_stock_page:
            rows = multi_sort(list(group_detail.values()), (('vs_status_code', 100, False),
                                                            ('invest_funds', 0, True),
                                                            ('realtime', '', True)))
        else:
            rows = sorted(group_detail.values(), key=lambda d: d.get('realtime', ''), reverse=True)

        return {
            'summary': summary,
            'rows': rows
        }

    def investment_pnl_data2(self):
        cache_key = self.cache_key
        same_cache_key = False
        if self.id_list:
            if self.id_list[0] not in (0, 1, -1):
                same_cache_key = True
            elif (self.is_stock_page and self.is_stock_group) or (self.is_future_page and self.is_future_group):
                same_cache_key = True

        if same_cache_key:
            cache_key = 'platform_investment_basic_data_%s_%s' % (
                15, gen_hash_value(self.id_list) + self.business + '_'.join(map(str, [
                    self.is_stock_page, self.is_stock_group, self.is_future_page, self.is_future_group
                ]))
            )

        self.pnl_data_cache_key = cache_key + 'pnl_data.json'
        is_summary = self.kwargs.get('is_summary')
        if is_summary:
            self.pnl_data_cache_key = cache_key + 'summary_pnl_data.json'

        cache_data = get_cache(self.pnl_data_cache_key)
        if cache_data:
            return cache_data

        strategies_detail = self.sc.query(
            VStrategies.id.label('vs_id'),
            VStrategies.trade_model.label('vs_trade_model'),
            VStrategies.deploy_server.label('vs_server'),
            Strategy.id.label('s_id'),
            Strategy.paper_trading_date.label('paper_trading_date'),
            Strategy.r_create_time.label('s_create_time'),
            Strategy.hedge.label('hedge'),
            Strategy.hedge_type.label('hedge_type'),
            Strategy.strategy_type.label('strategy_type'),
            Strategy.detail.label('s_detail'),
            Strategy.node.label('node'),
            StrategyPortfolio.id.label('sp_id'),
            StrategyPortfolio.r_create_user_id.label('p_user_id'),
        ).join(
            Strategy, or_(
                and_(
                    Strategy.id == VStrategies.strategy_id,
                    VStrategies.group_id == 0
                ),
                Strategy.id == VStrategies.group_id
            )
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            StrategyPortfolio.source == 'platform',
            VStrategies.source == 'platform',
        )

        if len(self.id_list) > 0:
            if self.id_list[0] == 0:
                strategies_detail = strategies_detail.filter(
                    VStrategies.status == consts.STRATEGY_LIVE,
                )
            elif self.id_list[0] == -1:
                strategies_detail = strategies_detail.filter(
                    VStrategies.status == consts.STRATEGY_OFF_SHELF,
                )
            else:
                strategies_detail = strategies_detail.filter(VStrategies.id.in_(self.id_list))

        if not self.current_user['is_superuser']:
            if self.business:
                strategies_detail = strategies_detail.filter(
                    StrategyPortfolio.business == self.business
                )
            else:
                if self.is_stock_page:
                    strategies_detail = strategies_detail.filter(
                        StrategyPortfolio.business == 'stock',
                        Strategy.r_create_user_id == self.current_user['id']
                    )
                elif self.is_future_page:
                    strategies_detail = strategies_detail.filter(
                        StrategyPortfolio.business == 'future',
                        Strategy.r_create_user_id == self.current_user['id']
                    )
                else:
                    strategies_detail = strategies_detail.filter(
                        StrategyPortfolio.r_create_user_id.in_(
                            [self.current_user['id']] if self.current_user['id'] != 302 else consts.investment_user_ids)
                    )

        strategies_detail = strategies_detail.order_by(Strategy.id.desc())

        group_detail = {}
        vs_ids = []
        total_live_pnls = []
        for s in strategies_detail:
            g_id = '%s_%s' % (s.sp_id, s.s_id)
            group_d = group_detail.setdefault(g_id, {
                's_id': s.s_id,
                'vs_ids': []
            })
            group_d['vs_ids'].append(s.vs_id)
            group_d['p_user_id'] = s.p_user_id
            group_d['papertrading_date'] = (s.paper_trading_date or s.s_create_time).strftime('%Y-%m-%d')
            group_d['hedge'] = s.hedge
            group_d['hedge_type'] = s.hedge_type
            group_d['strategy_type'] = s.strategy_type
            group_d['upload_type'] = s.node if s.node != 'back_test' else 'so_file'
            group_d['trade_model'] = s.s_detail.get('trade_model', '')
            group_d['vs_trade_model'] = s.vs_trade_model or s.s_detail.get('trade_model', '')
            group_d['server'] = s.vs_server or 'default'
            group_d['vwap_version'] = s.s_detail.get('vwap_version', '')
            group_d['portfolio_optimization_so_version'] = s.s_detail.get('portfolio_optimization_so_version', '')
            vs_ids.append(s.vs_id)

        upgrade_vs_ids = VstrategyUpgrade.get_vs_upgrades()
        for _, group_d in group_detail.items():
            if (group_d['p_user_id'] == self.current_user['id'] or self.business) and (
                    not self.kwargs.get('is_summary')):
                group_d['events'] = Strategy.get_accident_events(group_d['vs_ids'])
            else:
                group_d['events'] = {}

            # vs upgrade replacement info
            if self.is_stock_page and group_d['vs_ids'] and not is_summary:
                group_d['vs_replacement'] = VstrategyUpgrade.get_vs_replacement(vs_id=group_d['vs_ids'][0])

            up_vs_ids = []
            if self.is_stock_page and group_d['vs_ids'] and (not self.kwargs.get('is_summary')):
                up_vs_ids = upgrade_vs_ids.get(str(group_d['vs_ids'][0]), [])
            s_pnl = Strategy.investment_performance_net_pnl(
                group_d['s_id'], group_d['vs_ids'] + up_vs_ids, trading_date=self.trading_date, day_night=self.day_night
            )
            group_d.update(s_pnl['back_test_paper_trading_net_line'])
            group_d.update(s_pnl['live_net_combine_line'])
            group_d.update(s_pnl['vs_back_test_combine_net'])
            s_pnl['live_net_combine_line']['pnl']['strategy_type'] = s_pnl.get('strategy_type', '')
            total_live_pnls.append(copy.deepcopy(s_pnl['live_net_combine_line']['pnl']))
            group_d['pnl'].pop('strategy_type', '')

        if self.kwargs.get('is_summary'):
            actual_amount_cash = VStrategyAccountDetail.get_vstrategy_cash2(
                vs_ids + [11111111] if 11111111 in self.id_list else vs_ids, shift=False, dateformat='%Y%m%d',
                is_future=self.is_future_page
            )
            summary_live_pnl = Strategy.combine_pnls(
                total_live_pnls, mode='live', cash_io=actual_amount_cash
            )

            res = {
                'summary_live_pnl': summary_live_pnl,
            }
            res['summary_live_pnl']['indicators_args'] = {
                'vs_ids': vs_ids,
                'is_summary': True
            }

            set_cache(self.pnl_data_cache_key, res, 3600 * 3)

            InvestmentPerformanceService.check_or_generate_range_pnl_delay(vs_ids, self.pnl_data_cache_key,
                                                                           is_summary=True)
            return res

        set_cache(self.pnl_data_cache_key, group_detail, 3600 * 3)

        return group_detail

    def get_stock_market_volumes(self):
        if self.is_future_page:
            return {}

        cache_key = 'platform_stock_market_volumes2'
        data = get_cache(cache_key)
        if data:
            return {int(k): v for k, v in data.items()}

        if self.is_future_page:
            market_volumes = {}
        else:
            market_volumes = self.sc.query(
                VsTradingVolumeRatioStatistic.vs_id,
                func.max(VsTradingVolumeRatioStatistic.tenq_volume_percent),
                func.max(VsTradingVolumeRatioStatistic.trade_vol_percent_5),
                func.max(VsTradingVolumeRatioStatistic.trade_vol_percent_10),
            ).group_by(VsTradingVolumeRatioStatistic.vs_id)

            market_volumes = {r[0]: {
                'tenq_volume_percent': round(float(r[1]), 3),
                'trade_vol_percent_5': round(float(r[2]), 3),
                'trade_vol_percent_10': round(float(r[3]), 3),
            } for r in market_volumes}
        set_cache(cache_key, market_volumes, 7200)

        return market_volumes

    def get_investment_live_pnl(self):
        strategies_detail = self.sc.query(
            VStrategies.id.label('vs_id'),
            VStrategies.symbols_accounts_detail.label('symbols_accounts'),
            Strategy.id.label('s_id'),
            Strategy.r_create_user_id.label('create_user_id'),
            Strategy.strategy_type.label('strategy_type'),
            StrategyPortfolio.id.label('sp_id'),
        ).join(
            Strategy, or_(
                and_(
                    Strategy.id == VStrategies.strategy_id,
                    VStrategies.group_id == 0
                ),
                Strategy.id == VStrategies.group_id
            )
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            StrategyPortfolio.status >= consts.STRATEGY_LIVE,
            StrategyPortfolio.source == 'platform',
            VStrategies.source == 'platform'
        )

        # investment_share_vs_ids = self.sc.query(
        #     InvestMentShare.vstrategy_id.label('vstrategy_id')
        # ).filter(
        #     InvestMentShare.owner_id == self.current_user['id']
        # ).union_all(
        #     self.sc.query(
        #         NewStrategySetdetail.vs_id.label('vstrategy_id')
        #     ).join(
        #         NewStrategySet, NewStrategySetdetail.strategy_set_id == NewStrategySet.id
        #     ).join(
        #         NewStrategySetShare, NewStrategySetShare.strategy_set_id == NewStrategySet.id
        #     ).filter(
        #         NewStrategySetShare.owner_id == self.current_user['id'],
        #         NewStrategySet.page.in_(self.share_strategy_set_business)
        #     )
        # )

        if len(self.id_list) > 0:
            if self.id_list[0] == 0:
                strategies_detail = strategies_detail.filter(
                    VStrategies.status == consts.STRATEGY_LIVE,
                )
            elif self.id_list[0] == -1:
                strategies_detail = strategies_detail.filter(
                    VStrategies.status == consts.STRATEGY_OFF_SHELF,
                )
            else:
                if self.id_list[0] > 200000:
                    strategies_detail = strategies_detail.filter(Strategy.id.in_(self.id_list))
                else:
                    strategies_detail = strategies_detail.filter(VStrategies.id.in_(self.id_list))

        if not self.current_user['is_superuser']:
            if self.business:
                strategies_detail = strategies_detail.filter(
                    StrategyPortfolio.business == self.business
                    # or_(
                    #     StrategyPortfolio.business == self.business,
                    #     VStrategies.id.in_(investment_share_vs_ids)
                    # )
                )
            else:
                if self.is_stock_page:
                    strategies_detail = strategies_detail.filter(
                        StrategyPortfolio.business == 'stock',
                        Strategy.r_create_user_id == self.current_user['id']
                        # or_(
                        #     and_(
                        #         StrategyPortfolio.business == 'stock',
                        #         Strategy.r_create_user_id == self.current_user['id']
                        #     ),
                        #     VStrategies.id.in_(investment_share_vs_ids)
                        # )
                    )

                elif self.is_future_page:
                    strategies_detail = strategies_detail.filter(
                        StrategyPortfolio.business == 'future',
                        Strategy.r_create_user_id == self.current_user['id']
                        # or_(
                        #     and_(
                        #         StrategyPortfolio.business == 'future',
                        #         Strategy.r_create_user_id == self.current_user['id']
                        #     ),
                        #     VStrategies.id.in_(investment_share_vs_ids)
                        # )
                    )
                else:
                    strategies_detail = strategies_detail.filter(
                        StrategyPortfolio.r_create_user_id.in_(
                            [self.current_user['id']] if self.current_user[
                                                             'id'] != 302 else consts.investment_user_ids
                        ),
                        # or_(
                        #     StrategyPortfolio.r_create_user_id.in_(
                        #         [self.current_user['id']] if self.current_user[
                        #                                          'id'] != 302 else consts.investment_user_ids
                        #     ),
                        #     VStrategies.id.in_(investment_share_vs_ids)
                        # )
                    )
        strategies_detail = strategies_detail.order_by(Strategy.id.desc())

        vs_agg_pnl = VsAggregationPnl.get_aggregation_pnl()

        agg_pnl_keys = ['year_pnl', 'month_1_pnl', 'trading_days_20_pnl', 'trading_days_40_pnl', 'trading_days_60_pnl',
                        'season_1_pnl']

        summary = {
            'today_pnl': 0,
            'total_pnl': 0,
            'total_point': 0,
            'total_net_income': 0,
            'fee': 0,
            'year_pnl': 0,
            'month_1_pnl': 0,
            'trading_days_20_pnl': 0,
            'trading_days_40_pnl': 0,
            'trading_days_60_pnl': 0,
            'season_1_pnl': 0,
        }

        group_detail = {}
        for s in strategies_detail:
            g_id = '%s_%s' % (s.sp_id, s.s_id)
            group_d = group_detail.setdefault(g_id, {
                's_id': s.s_id,
                'vs_ids': [],
                'create_user_id': s.create_user_id,
                'year_pnl': 0,
                'month_1_pnl': 0,
                'trading_days_20_pnl': 0,
                'trading_days_40_pnl': 0,
                'trading_days_60_pnl': 0,
                'season_1_pnl': 0,
                'market_volume': '0 / 0'
            })
            group_d['vs_ids'].append(s.vs_id)
            acc_currency = {
                _acc_d['account']: consts.FOREGIN_ACCOUNT.get(_acc_d['account']) or _acc_d.get('currency',
                                                                                               'CNY') or 'CNY'
                for _acc_d in VStrategies.normalization_symbols_accounts(s.symbols_accounts)
            }
            acc_currency['20052121'] = 'CNY'
            vs_d = self.vs_detail.setdefault(s.vs_id, {})
            vs_d['acc_currency'] = acc_currency
            vs_d['strategy_type'] = s.strategy_type

        if self.is_future_page:
            market_volumes = {}
        else:
            market_volumes = self.get_stock_market_volumes()

        if group_detail:
            if not self.trade_detail:
                self.trade_detail = self.get_current_day_trading_logs()
            for k, group_d in group_detail.items():
                pnl = self.get_current_day_pnl(group_d['vs_ids'])
                group_d['today_pnl'] = pnl['today_pnl']
                group_d['total_pnl'] = pnl['total_pnl']
                group_d['fee'] = pnl['fee']
                if self.is_stock_page and group_d['vs_ids'] and (group_d['vs_ids'][0] in market_volumes):
                    group_d['market_volume'] = '%s / %s' % (
                        market_volumes[group_d['vs_ids'][0]]['trade_vol_percent_5'],
                        market_volumes[group_d['vs_ids'][0]]['trade_vol_percent_10']
                    )

                if group_d['total_pnl'] != 0:
                    group_d['total_point'] = round(
                        group_d['total_pnl'] * (
                            consts.TOTAL_POINT_RATIO if group_d['create_user_id'] != self.current_user['id'] else 0
                        ),
                        3
                    )
                    group_d['total_net_income'] = round(group_d['total_pnl'] - group_d['total_point'], 3)
                else:
                    group_d['total_net_income'] = round(group_d['total_pnl'], 3)
                    group_d['total_point'] = 0
                group_d_agg_pnl = VsAggregationPnl.get_vs_aggregation_pnl(group_d['vs_ids'], vs_agg_pnl)
                for k in agg_pnl_keys:
                    group_d[k] = group_d_agg_pnl.get(k, 0) + group_d['today_pnl']
                    summary[k] = summary.get(k, 0) + group_d[k]
                summary['today_pnl'] += group_d['today_pnl']
                summary['total_pnl'] += group_d['total_pnl']
                summary['total_point'] += group_d['total_point']
                summary['total_net_income'] += group_d['total_net_income']
                summary['fee'] += group_d['fee']

        group_detail['summary'] = summary
        return group_detail

    @staticmethod
    def clear_cache(current_user, **kwargs):
        cache_rds = redis.Redis(host=config.redis['host'], port=config.redis['port'], db=config.redis['db'])
        if current_user:
            cache_key = 'platform_investment_basic_data_%s*' % current_user['id']
        else:
            cache_key = 'platform_investment_basic_data_*'
        for key in cache_rds.keys(cache_key):
            cache_rds.delete(key)
        for key in cache_rds.keys('platform_live_analysis_basic_data_*'):
            cache_rds.delete(key)
        del_cache('platform_vstartegy_today_trading_data')
        del_cache('platform_vstartegy_lastday_position_data')
        del_cache('platform_vstartegy_last_settle_total_pnl')
        InvestmentPerformanceService._last_total_pnl.clear()
        InvestmentPerformanceService._lastday_position.clear()
        return True

    @staticmethod
    def get_stock_hedge_vs(cache=True):
        cache_key = 'platform_stock_hedge_vs'
        if cache:
            data = get_cache(cache_key)
            if data:
                return data

        sc = session()

        stock_vs = sc.query(
            VStrategies.id.label('vs_id'),
            Strategy.hedge_type.label('hedge_type'),
        ).join(
            Strategy, VStrategies.strategy_id == Strategy.id
        ).filter(
            VStrategies.status.in_([consts.STRATEGY_LIVE, consts.STRATEGY_OFF_SHELF]),
            Strategy.strategy_type.in_(consts.stock_strategy_type)
        )

        data = {}
        for s in stock_vs:
            data[s.vs_id] = {
                'hedge_type': s.hedge_type,
                'hedge_vs_id': 0,
                'hedge_vs_ids': [],
                'hedge_pnl': {},
            }

        stock2hedge = sc.query(
            StockHedgeVs
        )

        future_vs_ids = []
        for s in stock2hedge:
            if s.stock_vs_id in data:
                data[s.stock_vs_id]['hedge_vs_id'] = s.future_vs_id
                data[s.stock_vs_id]['hedge_vs_ids'].append(s.future_vs_id)
                future_vs_ids.append(s.future_vs_id)

        future_pnl = sc.query(
            VsBase.vstrategy_id.label('vs_id'),
            VsBase.settle_date.label('settle_date'),
            VsBase.pnl.label('pnl'),
        ).filter(
            VsBase.vstrategy_id.in_(future_vs_ids),
            VsBase.daynight == 'DAY'
        )

        hedge_vs_pnl = {}
        for pnl in future_pnl:
            h_vs_pnl = hedge_vs_pnl.setdefault(pnl.vs_id, {})
            h_vs_pnl[pnl.settle_date.strftime('%Y%m%d')] = float(pnl.pnl)

        cache_data = {}
        for k, v in data.items():
            hedge_pnl = {}
            for hedge_vs_id in v['hedge_vs_ids']:
                for date, pnl in hedge_vs_pnl.get(hedge_vs_id, {}).items():
                    hedge_pnl.setdefault(date, 0)
                    hedge_pnl[date] += pnl

            v['hedge_pnl'] = hedge_pnl
            cache_data[str(k)] = v

        set_cache(cache_key, cache_data, 900)
        sc.close()
        return data

    @staticmethod
    def get_hedge_vs_pnl(vs_ids):
        hedge_data = InvestmentPerformanceService.get_stock_hedge_vs()
        hedge_pnl = {
            'hedge_type': 'full',
            'hedge_pnl': {},
        }
        if len(vs_ids) == 1:
            d = hedge_data.get(vs_ids[0])
            if d:
                return d
        for vs_id in vs_ids:
            d = hedge_data.get(vs_id)
            if d:
                hedge_pnl['hedge_type'] = d['hedge_type']
                for day, d_pnl in d['hedge_pnl'].items():
                    hedge_pnl['hedge_pnl'][day] = hedge_pnl['hedge_pnl'].get(day, 0) + d_pnl
        return hedge_pnl

    @staticmethod
    def clear_basic_cache(current_user):
        cache_rds = redis.Redis(host=config.redis['host'], port=config.redis['port'], db=config.redis['db'])
        if current_user:
            cache_key = 'platform_investment_basic_data_%s*' % current_user['id']
        else:
            cache_key = 'platform_investment_basic_data_*'
        for key in cache_rds.keys(cache_key):
            cache_rds.delete(key)
        for key in cache_rds.keys('platform_live_analysis_basic_data_*'):
            cache_rds.delete(key)
        return True

    @staticmethod
    def check_or_generate_range_pnl(vs_ids, pnl_file, **kwargs):
        try:
            summary_pnl = get_cache(pnl_file)
            pnl = summary_pnl['summary_live_pnl']
        except Exception as e:
            return False

        from analysis.performance_analysis import PerformanceAnalyzer
        if not vs_ids:
            return True
        if not pnl['pnl']:
            return True
        vs_ids_key = '_'.join(map(str, sorted(vs_ids)))
        vs_ids_key = gen_str_hash_value(vs_ids_key)
        range_ind = {}
        dates = pnl['pnl'].keys()
        min_date, max_date = min(dates), max(dates)
        min_year = int(min_date[:4])
        max_year = int(max_date[:4])

        del pnl['pnl'][min_date]

        for y in range(min_year, max_year + 1):
            request_data = {
                'live_date': [],
                'live_pnl': [],
                'live_asset': [],
                'live_position_value': [],
                'live_cash_io': [],
                'live_end_position_value': 0,
                'back_test_date': [],
                'back_test_asset': [],
                'back_test_pnl': [],
                'back_test_position_value': [],
                'back_test_cash_io': [],
                'paper_trading_date': '',
                'back_test_end_position_value': 0,
            }

            y_key = 'summary_performance_%s' % y
            y_p_date = '' if y == min_year else '%s0101' % y
            y_end_date = '%s1231' % y

            request_data['paper_trading_date'] = y_p_date

            cash_io_index = -1

            for d, item in sorted(pnl['pnl'].items(), key=lambda x: x[0]):
                if d <= y_end_date:
                    request_data['back_test_date'].append(d)
                else:
                    break
                if cash_io_index < 0:
                    if len(item) == 8:
                        cash_io_index = 7
                    elif len(item) == 10:
                        cash_io_index = 9
                request_data['back_test_pnl'].append(item[1])
                request_data['back_test_asset'].append(item[2])
                request_data['back_test_position_value'].append(item[5])
                request_data['back_test_end_position_value'] = item[6]
                request_data['back_test_cash_io'].append(item[cash_io_index] if cash_io_index > 0 else 0)

            net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategies_quest(request_data)
            if not net_pnl[0]:
                detail = net_pnl[1]
            else:
                continue

            ind = {
                'start_date': '%s0101' % y,
                'end_date': '%s1231' % y,
                'key': y_key,
                'sharpe': 0,
                'annual_return': 0,
                'profitrate': 0,
                'max_drawdown_pnl': 0,
            }
            if y == min_year:
                ind['sharpe'] = detail['back_test_sharpe']
                ind['annual_return'] = detail['back_test_annual_return']
                ind['profitrate'] = detail['back_test_profitrate']
                ind['max_drawdown_pnl'] = detail['back_test_max_drawdown_pnl']
            else:
                ind['sharpe'] = detail['paper_trading_sharpe']
                ind['annual_return'] = detail['paper_trading_annual_return']
                ind['profitrate'] = detail['paper_trading_profitrate']
                ind['max_drawdown_pnl'] = detail['paper_trading_max_drawdown_pnl']
            range_ind[y_key] = ind

        sc = session()
        sc.query(VsLiveRangePerformance).filter(
            VsLiveRangePerformance.vs_ids == vs_ids_key,
        ).delete()

        for k, ind in range_ind.items():
            vs_ind = VsLiveRangePerformance(
                vs_ids=vs_ids_key,
                group_key=k,
                start_date=ind['start_date'],
                end_date=ind['end_date'],
                sharpe=ind['sharpe'],
                annual_return=ind['annual_return'],
                profitrate=ind['profitrate'],
                max_drawdown_pnl=ind['max_drawdown_pnl'],
            )
            sc.add(vs_ind)
        sc.commit()
        return True

    @staticmethod
    def check_or_generate_range_pnl_delay(vs_ids, pnl, **kwargs):
        from cron.strategy_upload_task import investment_check_or_generate_range_pnl_delay
        investment_check_or_generate_range_pnl_delay.delay(
            vs_ids, pnl, **kwargs
        )
        return True


class InvestmentPerformanceServiceV1(BaseInvestmentServiceMixin, ServiceBaseService):
    def __init__(self, current_user, id_list, **kwargs):
        self.current_user = current_user
        self.uid = current_user['id']
        self.id_list = id_list
        self.user_role = kwargs.get('user_role', '')
        self.business = kwargs.get('business', '')
        if not self.business:
            if self.user_role == UserRoleConstant.TraderFuture.value:
                self.business = StrategyPortfolioConstant.Business.Future.value
            elif self.user_role == UserRoleConstant.TraderStock.value:
                self.business = StrategyPortfolioConstant.Business.Stock.value
        self.is_future = self.business == StrategyPortfolioConstant.Business.Future.value
        self.is_summary = kwargs.get('is_summary', False)
        self.sc = session()
        self.trading_date, self.day_night = StrategyPerfInput.get_trading_date_day_night()
        self.cache_key = 'platform_investment_basic_data_{}'.format(gen_hash_value(self.id_list))
        self.vs_detail = {}
        self.trade_detail = {}

        super(InvestmentPerformanceServiceV1, self).__init__()

    def __del__(self):
        self.sc.close()
        self.kdb.release()

    def close(self):
        self.sc.close()
        self.kdb.release()

    def _strategies_detail_filter(self, strategies_detail):
        strategies_detail = strategies_detail.join(
            Strategy, or_(
                and_(
                    Strategy.id == VStrategies.strategy_id,
                    VStrategies.group_id == 0
                ),
                Strategy.id == VStrategies.group_id
            )
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            StrategyPortfolio.status >= consts.STRATEGY_LIVE,
            StrategyPortfolio.source == 'platform',
            VStrategies.source == 'platform'
        )

        if len(self.id_list) > 0:
            if self.id_list[0] == 0:
                strategies_detail = strategies_detail.filter(
                    VStrategies.status == consts.STRATEGY_LIVE,
                )
            elif self.id_list[0] == -1:
                strategies_detail = strategies_detail.filter(
                    VStrategies.status == consts.STRATEGY_OFF_SHELF,
                )
            else:
                if self.id_list[0] > 200000:
                    strategies_detail = strategies_detail.filter(Strategy.id.in_(self.id_list))
                else:
                    strategies_detail = strategies_detail.filter(VStrategies.id.in_(self.id_list))

        if self.user_role == UserRoleConstant.Manager.value:
            strategies_detail = strategies_detail.filter(
                StrategyPortfolio.business == self.business,
            )
        elif self.user_role == UserRoleConstant.TraderFuture.value:
            strategies_detail = strategies_detail.filter(
                StrategyPortfolio.business == StrategyPortfolioConstant.Business.Future.value,
                Strategy.r_create_user_id == self.uid
            )
        elif self.user_role == UserRoleConstant.TraderStock.value:
            strategies_detail = strategies_detail.filter(
                StrategyPortfolio.business == StrategyPortfolioConstant.Business.Stock.value,
            )
        else:
            strategies_detail = strategies_detail.filter(
                StrategyPortfolio.business == StrategyPortfolioConstant.Business.Empty.value,
            )

        strategies_detail = strategies_detail.order_by(Strategy.id.desc())
        return strategies_detail

    def investment_basic_data(self):
        strategies_detail = self.sc.query(
            VStrategies.id.label('vs_id'),
            VStrategies.status.label('strategy_status'),
            VStrategies.closing_out.label('close_status'),
            VStrategies.trade_model.label('vs_trade_model'),
            VStrategies.deploy_server.label('vs_server'),
            Strategy.id_no.label('id_no'),
            Strategy.id.label('s_id'),
            Strategy.r_create_user_id.label('s_user_id'),
            Strategy.username.label('creator'),
            Strategy.products.label('s_products'),
            Strategy.strategy_type.label('strategy_type'),
            Strategy.r_create_time.label('s_create_time'),
            Strategy.name.label('s_name'),
            Strategy.strategy_feature.label('strategy_feature'),
            Strategy.strategy_para_type.label('strategy_para_type'),
            Strategy.description.label('desc'),
            Strategy.paper_trading_date.label('paper_trading_date'),
            Strategy.hedge.label('hedge'),
            Strategy.hedge_type.label('hedge_type'),
            Strategy.detail.label('s_detail'),
            Strategy.node.label('node'),
            StrategyPortfolio.id.label('sp_id'),
            StrategyPortfolio.name.label('portfolio_name'),
            StrategyPortfolio.r_create_user_id.label('p_user_id'),
            StrategyPortfolio.live_time.label('p_live_time'),
            StrategyPortfolio.r_create_time.label('p_create_time'),
        )

        strategies_detail = self._strategies_detail_filter(strategies_detail)

        summary = {
            'vs_ids': [],
            'upgrade_vs_ids': [],
            'today_pnl': 0,
            'total_pnl': 0,
            'total_point': 0,
            'total_net_income': 0,
            'invest_funds': 0,
            'total_invest_cash': 0,
            'pnl_url': '',
            'pnl_args': {
                'summary': True,
            },
            'year_pnl': 0,
            'month_1_pnl': 0,
            'trading_days_20_pnl': 0,
            'trading_days_40_pnl': 0,
            'trading_days_60_pnl': 0,
            'season_1_pnl': 0,
        }

        strategies = {}
        vs_detail = {}
        group_detail = {}

        upgrade_vs_ids = VstrategyUpgrade.get_vs_upgrades()

        for s in strategies_detail:
            if s.s_id not in strategies:
                strategies[s.s_id] = {
                    'create_user_id': s.s_user_id,
                    'status': '',
                    'creator': s.creator,
                    'desc': s.desc,
                    'hedge': s.hedge,
                    'hedge_type': s.hedge_type,
                    'upload_type': s.node if s.node != 'back_test' else 'so_file',
                    'invest_funds': 0,
                    'name': s.s_name,
                    'display_name': s.s_name,
                    'papertrading_date': (s.paper_trading_date or s.s_create_time).strftime('%Y-%m-%d'),
                    'products': s.s_products,
                    'trade_model': s.s_detail.get('trade_model', ''),
                    'vs_trade_model': s.vs_trade_model or s.s_detail.get('trade_model', ''),
                    'server': s.vs_server or 'default',
                    'realtime': '',
                    's_id': s.s_id,
                    'strategy_feature': s.strategy_feature,
                    'strategy_id': s.id_no,
                    'strategy_para_type': s.strategy_para_type,
                    'strategy_type': s.strategy_type,
                    'today_pnl': 0,
                    'total_net_income': 0,
                    'total_pnl': 0,
                    'total_point': 0,
                    'uptime': s.s_create_time.strftime('%Y%m%d'),
                    'ctime': s.s_create_time.strftime('%Y%m%d %X'),
                    'vwap_slippage': {
                        'avg': None,
                        'std': None
                    },
                    'accounts': [],
                    'notebook_links': [],
                    'p_user_id': s.p_user_id,
                    'portfolio_optimization_so_version': s.s_detail.get('portfolio_optimization_so_version', '--'),
                    'vwap_version': s.s_detail.get('vwap_version', 'vwap_classic'),
                    'year_pnl': 0,
                    'month_1_pnl': 0,
                    'trading_days_20_pnl': 0,
                    'trading_days_40_pnl': 0,
                    'trading_days_60_pnl': 0,
                    'season_1_pnl': 0,
                    'vwap_slippage2': 'N/A'
                }
                if s.strategy_type in consts.stock_strategy_type:
                    strategies[s.s_id]['display_name'] = '/'.join([
                        s.s_name,
                        s.s_detail.get('portfolio_optimization_so_version', '--'),
                        s.s_detail.get('vwap_version', 'vwap_classic'),
                    ])
            group_d = group_detail.setdefault((s.sp_id, s.s_id), {
                'vs_ids': [],
                'upgrade_vs_ids': []
            })
            group_d['vs_ids'].append(s.vs_id)
            group_d['upgrade_vs_ids'].extend(upgrade_vs_ids.get(str(s.vs_id), []))
            group_d['portfolio_name'] = s.portfolio_name

            vs_d = vs_detail.setdefault(s.vs_id, {
                'invest_funds': 0,
                'accounts': [],
            })
            vs_d['realtime'] = (s.p_live_time or s.p_create_time).strftime('%Y%m%d')
            vs_d['status'] = s.strategy_status
            vs_d['close_status'] = s.close_status
            summary['vs_ids'].append(s.vs_id)
            summary['upgrade_vs_ids'].extend(upgrade_vs_ids.get(str(s.vs_id), []))

        summary['pnl_args']['vs_ids'] = summary['vs_ids'] + summary['upgrade_vs_ids']
        if 11111111 in self.id_list:
            summary['pnl_args']['vs_ids'].append(11111111)
            summary['vs_ids'].append(11111111)
        summary['pnl_args']['is_future'] = self.is_future
        summary['pnl_url'] = self.get_pnl_graph_url(summary['pnl_args'])
        # Strategy comment
        strategy_remarks = self.sc.query(StrategyRemark).filter(StrategyRemark.sid.in_(strategies.keys()))
        for r in strategy_remarks:
            if r.links:
                strategies[r.sid]['notebook_links'].extend(r.links)

        invest_funds = self.sc.query(
            VStrategyAccountDetail.vstrategy_id.label('vs_id'),
            VStrategyAccountDetail.account.label('account'),
            func.sum(VStrategyAccountDetail.amount).label('amount'),
            func.sum(VStrategyAccountDetail.actual_amount).label('actual_amount'),
        ).filter(
            VStrategyAccountDetail.vstrategy_id.in_(vs_detail.keys()),
        ).group_by(
            VStrategyAccountDetail.vstrategy_id,
            VStrategyAccountDetail.account
        )
        for r in invest_funds:
            vs_detail[r.vs_id]['accounts'].append(r.account)
            if vs_detail[r.vs_id]['status'] == consts.STRATEGY_LIVE:
                vs_detail[r.vs_id]['invest_funds'] += float(r.amount)
                summary['invest_funds'] += float(r.amount)

        summary['total_invest_cash'] = sum(VStrategyAccountDetail.get_vstrategy_cash2(
            summary['vs_ids'] + [11111111] if 11111111 in self.id_list else summary['vs_ids'],
            is_future=self.is_future
        ).values())

        for (sp_id, s_id), group_d in group_detail.items():
            group_d.update(strategies[s_id])
            group_d['realtime'] = min([vs_detail[v_id]['realtime'] for v_id in group_d['vs_ids']])
            if (self.current_user['id'] == strategies[s_id]['p_user_id']) or self.business:
                group_d['accounts'] = list(set(itertools.chain.from_iterable(
                    [vs_detail[v_id]['accounts'] for v_id in group_d['vs_ids']]
                )))
            else:
                group_d['accounts'] = []
            if group_d['vs_ids']:
                group_d['vwap_slippage'] = Strategy.get_strategy_slippage(ids=group_d['vs_ids'], id_type='vs')
                if not self.is_future:
                    try:
                        vwap_slippage_live = group_d['vwap_slippage'].get('avg', 0) or 0
                        vwap_slippage_bt = VsBackTestSlippage.get_strategy_slippage(group_d['vs_ids']).get('avg',
                                                                                                           0) or 0
                        group_d['vwap_slippage2'] = '%s / %s' % (
                            round(vwap_slippage_live, 2), round(vwap_slippage_bt, 2))
                    except Exception as e:
                        pass

                group_d['status'] = VStrategies.get_status(
                    vs_detail[group_d['vs_ids'][0]]['status'],
                    vs_detail[group_d['vs_ids'][0]]['close_status'],
                    group_d['vs_ids'][0]
                )
                group_d['vs_status_code'] = vs_detail[group_d['vs_ids'][0]]['status']
                group_d['invest_funds'] = sum(
                    [vs_detail.get(v_id, {}).get('invest_funds', 0) for v_id in group_d['vs_ids']])

            group_d['id'] = '%s_%s' % (sp_id, s_id)
            group_d['pnl_args'] = {
                'summary': False,
                'vs_ids': group_d['vs_ids'] + group_d['upgrade_vs_ids'],
                'strategy_id': group_d['s_id'],
            }
            group_d['pnl_url'] = self.get_pnl_graph_url(group_d['pnl_args'])

        if not self.is_future:
            rows = multi_sort(list(group_detail.values()), (('vs_status_code', 100, False),
                                                            ('invest_funds', 0, True),
                                                            ('realtime', '', True)))
        else:
            rows = sorted(group_detail.values(), key=lambda d: d.get('realtime', ''), reverse=True)

        return {
            'summary': summary,
            'rows': rows
        }

    def investment_pnl_data(self):
        pnl_data_cache_key = "{}_{}".format(self.cache_key, 'pnl_data')
        if self.is_summary:
            pnl_data_cache_key = "{}_{}".format(self.cache_key, 'summary_pnl_data')

        cache_data = get_cache(pnl_data_cache_key)
        if cache_data:
            return cache_data

        strategies_detail = self.sc.query(
            VStrategies.id.label('vs_id'),
            VStrategies.trade_model.label('vs_trade_model'),
            VStrategies.deploy_server.label('vs_server'),
            Strategy.id.label('s_id'),
            Strategy.paper_trading_date.label('paper_trading_date'),
            Strategy.r_create_time.label('s_create_time'),
            Strategy.hedge.label('hedge'),
            Strategy.hedge_type.label('hedge_type'),
            Strategy.strategy_type.label('strategy_type'),
            Strategy.detail.label('s_detail'),
            Strategy.node.label('node'),
            StrategyPortfolio.id.label('sp_id'),
            StrategyPortfolio.r_create_user_id.label('p_user_id'),
        )

        strategies_detail = self._strategies_detail_filter(strategies_detail)

        group_detail = {}
        vs_ids = []
        total_live_pnls = []
        for s in strategies_detail:
            g_id = '%s_%s' % (s.sp_id, s.s_id)
            group_d = group_detail.setdefault(g_id, {
                's_id': s.s_id,
                'vs_ids': []
            })
            group_d['vs_ids'].append(s.vs_id)
            group_d['p_user_id'] = s.p_user_id
            group_d['papertrading_date'] = (s.paper_trading_date or s.s_create_time).strftime('%Y-%m-%d')
            group_d['hedge'] = s.hedge
            group_d['hedge_type'] = s.hedge_type
            group_d['strategy_type'] = s.strategy_type
            group_d['upload_type'] = s.node if s.node != 'back_test' else 'so_file'
            group_d['trade_model'] = s.s_detail.get('trade_model', '')
            group_d['vs_trade_model'] = s.vs_trade_model or s.s_detail.get('trade_model', '')
            group_d['server'] = s.vs_server or 'default'
            group_d['vwap_version'] = s.s_detail.get('vwap_version', '')
            group_d['portfolio_optimization_so_version'] = s.s_detail.get('portfolio_optimization_so_version', '')
            vs_ids.append(s.vs_id)

        upgrade_vs_ids = VstrategyUpgrade.get_vs_upgrades()
        for _, group_d in group_detail.items():
            if (group_d['p_user_id'] == self.current_user['id'] or self.business) and (
                    not self.is_summary):
                group_d['events'] = Strategy.get_accident_events(group_d['vs_ids'])
            else:
                group_d['events'] = {}

            # vs upgrade replacement info
            if not self.is_future and group_d['vs_ids'] and not self.is_summary:
                group_d['vs_replacement'] = VstrategyUpgrade.get_vs_replacement(vs_id=group_d['vs_ids'][0])

            up_vs_ids = []
            if not self.is_future and group_d['vs_ids'] and (not self.is_summary):
                up_vs_ids = upgrade_vs_ids.get(str(group_d['vs_ids'][0]), [])

            s_pnl = Strategy.investment_performance_net_pnl(
                group_d['s_id'], group_d['vs_ids'] + up_vs_ids, trading_date=self.trading_date, day_night=self.day_night
            )
            group_d.update(s_pnl['back_test_paper_trading_net_line'])
            group_d.update(s_pnl['live_net_combine_line'])
            group_d.update(s_pnl['vs_back_test_combine_net'])
            s_pnl['live_net_combine_line']['pnl']['strategy_type'] = s_pnl.get('strategy_type', '')
            total_live_pnls.append(copy.deepcopy(s_pnl['live_net_combine_line']['pnl']))
            group_d['pnl'].pop('strategy_type', '')

        if self.is_summary:
            actual_amount_cash = VStrategyAccountDetail.get_vstrategy_cash2(
                vs_ids + [11111111] if 11111111 in self.id_list else vs_ids, shift=False, dateformat='%Y%m%d',
                is_future=self.is_future
            )
            summary_live_pnl = Strategy.combine_pnls(
                total_live_pnls, mode='live', cash_io=actual_amount_cash
            )

            res = {
                'summary_live_pnl': summary_live_pnl,
            }
            res['summary_live_pnl']['indicators_args'] = {
                'vs_ids': vs_ids,
                'is_summary': True
            }

            set_cache(pnl_data_cache_key, res, 3600 * 3)

            InvestmentPerformanceService.check_or_generate_range_pnl_delay(vs_ids, pnl_data_cache_key,
                                                                           is_summary=True)
            return res

        set_cache(pnl_data_cache_key, group_detail, 3600 * 3)

        return group_detail

    def get_stock_market_volumes(self):
        if self.is_future:
            return {}

        cache_key = 'platform_stock_market_volumes2'
        data = get_cache(cache_key)
        if data:
            return {int(k): v for k, v in data.items()}

        market_volumes = self.sc.query(
            VsTradingVolumeRatioStatistic.vs_id,
            func.max(VsTradingVolumeRatioStatistic.tenq_volume_percent),
            func.max(VsTradingVolumeRatioStatistic.trade_vol_percent_5),
            func.max(VsTradingVolumeRatioStatistic.trade_vol_percent_10),
        ).group_by(VsTradingVolumeRatioStatistic.vs_id)

        market_volumes = {r[0]: {
            'tenq_volume_percent': round(float(r[1]), 3),
            'trade_vol_percent_5': round(float(r[2]), 3),
            'trade_vol_percent_10': round(float(r[3]), 3),
        } for r in market_volumes}
        set_cache(cache_key, market_volumes, 3600 * 2)

        return market_volumes

    def get_investment_live_pnl(self):
        strategies_detail = self.sc.query(
            VStrategies.id.label('vs_id'),
            VStrategies.symbols_accounts_detail.label('symbols_accounts'),
            Strategy.id.label('s_id'),
            Strategy.r_create_user_id.label('create_user_id'),
            Strategy.strategy_type.label('strategy_type'),
            StrategyPortfolio.id.label('sp_id'),
        )

        strategies_detail = self._strategies_detail_filter(strategies_detail)

        vs_agg_pnl = VsAggregationPnl.get_aggregation_pnl()

        agg_pnl_keys = ['year_pnl', 'month_1_pnl', 'trading_days_20_pnl', 'trading_days_40_pnl', 'trading_days_60_pnl',
                        'season_1_pnl']

        summary = {
            'today_pnl': 0,
            'total_pnl': 0,
            'total_point': 0,
            'total_net_income': 0,
            'fee': 0,
            'year_pnl': 0,
            'month_1_pnl': 0,
            'trading_days_20_pnl': 0,
            'trading_days_40_pnl': 0,
            'trading_days_60_pnl': 0,
            'season_1_pnl': 0,
        }

        group_detail = {}
        for s in strategies_detail:
            g_id = '%s_%s' % (s.sp_id, s.s_id)
            group_d = group_detail.setdefault(g_id, {
                's_id': s.s_id,
                'vs_ids': [],
                'create_user_id': s.create_user_id,
                'year_pnl': 0,
                'month_1_pnl': 0,
                'trading_days_20_pnl': 0,
                'trading_days_40_pnl': 0,
                'trading_days_60_pnl': 0,
                'season_1_pnl': 0,
                'market_volume': '0 / 0'
            })
            group_d['vs_ids'].append(s.vs_id)
            acc_currency = {
                _acc_d['account']: consts.FOREGIN_ACCOUNT.get(_acc_d['account']) or _acc_d.get('currency',
                                                                                               'CNY') or 'CNY'
                for _acc_d in VStrategies.normalization_symbols_accounts(s.symbols_accounts)
            }
            acc_currency['20052121'] = 'CNY'
            vs_d = self.vs_detail.setdefault(s.vs_id, {})
            vs_d['acc_currency'] = acc_currency
            vs_d['strategy_type'] = s.strategy_type

        market_volumes = self.get_stock_market_volumes()

        if group_detail:
            if not self.trade_detail:
                self.trade_detail = self.get_current_day_trading_logs()
            for k, group_d in group_detail.items():
                pnl = self.get_current_day_pnl(group_d['vs_ids'])
                group_d['today_pnl'] = pnl['today_pnl']
                group_d['total_pnl'] = pnl['total_pnl']
                group_d['fee'] = pnl['fee']
                if not self.is_future and group_d['vs_ids'] and (group_d['vs_ids'][0] in market_volumes):
                    group_d['market_volume'] = '%s / %s' % (
                        market_volumes[group_d['vs_ids'][0]]['trade_vol_percent_5'],
                        market_volumes[group_d['vs_ids'][0]]['trade_vol_percent_10']
                    )

                if group_d['total_pnl'] != 0:
                    group_d['total_point'] = round(
                        group_d['total_pnl'] * (
                            consts.TOTAL_POINT_RATIO if group_d['create_user_id'] != self.current_user['id'] else 0
                        ),
                        3
                    )
                    group_d['total_net_income'] = round(group_d['total_pnl'] - group_d['total_point'], 3)
                else:
                    group_d['total_net_income'] = round(group_d['total_pnl'], 3)
                    group_d['total_point'] = 0
                group_d_agg_pnl = VsAggregationPnl.get_vs_aggregation_pnl(group_d['vs_ids'], vs_agg_pnl)
                for k in agg_pnl_keys:
                    group_d[k] = group_d_agg_pnl.get(k, 0) + group_d['today_pnl']
                    summary[k] = summary.get(k, 0) + group_d[k]

                summary['today_pnl'] += group_d['today_pnl']
                summary['total_pnl'] += group_d['total_pnl']
                summary['total_point'] += group_d['total_point']
                summary['total_net_income'] += group_d['total_net_income']
                summary['fee'] += group_d['fee']

        group_detail['summary'] = summary
        return group_detail

    @staticmethod
    def get_stock_hedge_vs(cache=True):
        cache_key = 'platform_stock_hedge_vs'
        if cache:
            data = get_cache(cache_key)
            if data:
                return data

        sc = session()

        stock_vs = sc.query(
            VStrategies.id.label('vs_id'),
            Strategy.hedge_type.label('hedge_type'),
        ).join(
            Strategy, VStrategies.strategy_id == Strategy.id
        ).filter(
            VStrategies.status.in_([consts.STRATEGY_LIVE, consts.STRATEGY_OFF_SHELF]),
            Strategy.strategy_type.in_(consts.stock_strategy_type)
        )

        data = {}
        for s in stock_vs:
            data[s.vs_id] = {
                'hedge_type': s.hedge_type,
                'hedge_vs_id': 0,
                'hedge_vs_ids': [],
                'hedge_pnl': {},
            }

        stock2hedge = sc.query(
            StockHedgeVs
        )

        future_vs_ids = []
        for s in stock2hedge:
            if s.stock_vs_id in data:
                data[s.stock_vs_id]['hedge_vs_id'] = s.future_vs_id
                data[s.stock_vs_id]['hedge_vs_ids'].append(s.future_vs_id)
                future_vs_ids.append(s.future_vs_id)

        future_pnl = sc.query(
            VsBase.vstrategy_id.label('vs_id'),
            VsBase.settle_date.label('settle_date'),
            VsBase.pnl.label('pnl'),
        ).filter(
            VsBase.vstrategy_id.in_(future_vs_ids),
            VsBase.daynight == 'DAY'
        )

        hedge_vs_pnl = {}
        for pnl in future_pnl:
            h_vs_pnl = hedge_vs_pnl.setdefault(pnl.vs_id, {})
            h_vs_pnl[pnl.settle_date.strftime('%Y%m%d')] = float(pnl.pnl)

        cache_data = {}
        for k, v in data.items():
            hedge_pnl = {}
            for hedge_vs_id in v['hedge_vs_ids']:
                for date, pnl in hedge_vs_pnl.get(hedge_vs_id, {}).items():
                    hedge_pnl.setdefault(date, 0)
                    hedge_pnl[date] += pnl

            v['hedge_pnl'] = hedge_pnl
            cache_data[str(k)] = v

        set_cache(cache_key, cache_data, 900)
        sc.close()
        return data

    @staticmethod
    def get_hedge_vs_pnl(vs_ids):
        hedge_data = InvestmentPerformanceService.get_stock_hedge_vs()
        hedge_pnl = {
            'hedge_type': 'full',
            'hedge_pnl': {},
        }
        if len(vs_ids) == 1:
            d = hedge_data.get(vs_ids[0])
            if d:
                return d
        for vs_id in vs_ids:
            d = hedge_data.get(vs_id)
            if d:
                hedge_pnl['hedge_type'] = d['hedge_type']
                for day, d_pnl in d['hedge_pnl'].items():
                    hedge_pnl['hedge_pnl'][day] = hedge_pnl['hedge_pnl'].get(day, 0) + d_pnl
        return hedge_pnl

    @staticmethod
    def check_or_generate_range_pnl(vs_ids, pnl_file, **kwargs):
        try:
            summary_pnl = get_cache(pnl_file)
            pnl = summary_pnl['summary_live_pnl']
        except Exception as e:
            return False

        from analysis.performance_analysis import PerformanceAnalyzer
        if not vs_ids:
            return True
        if not pnl['pnl']:
            return True
        vs_ids_key = '_'.join(map(str, sorted(vs_ids)))
        vs_ids_key = gen_str_hash_value(vs_ids_key)
        range_ind = {}
        dates = pnl['pnl'].keys()
        min_date, max_date = min(dates), max(dates)
        min_year = int(min_date[:4])
        max_year = int(max_date[:4])

        del pnl['pnl'][min_date]

        for y in range(min_year, max_year + 1):
            request_data = {
                'live_date': [],
                'live_pnl': [],
                'live_asset': [],
                'live_position_value': [],
                'live_cash_io': [],
                'live_end_position_value': 0,
                'back_test_date': [],
                'back_test_asset': [],
                'back_test_pnl': [],
                'back_test_position_value': [],
                'back_test_cash_io': [],
                'paper_trading_date': '',
                'back_test_end_position_value': 0,
            }

            y_key = 'summary_performance_%s' % y
            y_p_date = '' if y == min_year else '%s0101' % y
            y_end_date = '%s1231' % y

            request_data['paper_trading_date'] = y_p_date

            cash_io_index = -1

            for d, item in sorted(pnl['pnl'].items(), key=lambda x: x[0]):
                if d <= y_end_date:
                    request_data['back_test_date'].append(d)
                else:
                    break
                if cash_io_index < 0:
                    if len(item) == 8:
                        cash_io_index = 7
                    elif len(item) == 10:
                        cash_io_index = 9
                request_data['back_test_pnl'].append(item[1])
                request_data['back_test_asset'].append(item[2])
                request_data['back_test_position_value'].append(item[5])
                request_data['back_test_end_position_value'] = item[6]
                request_data['back_test_cash_io'].append(item[cash_io_index] if cash_io_index > 0 else 0)

            net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategies_quest(request_data)
            if not net_pnl[0]:
                detail = net_pnl[1]
            else:
                continue

            ind = {
                'start_date': '%s0101' % y,
                'end_date': '%s1231' % y,
                'key': y_key,
                'sharpe': 0,
                'annual_return': 0,
                'profitrate': 0,
                'max_drawdown_pnl': 0,
            }
            if y == min_year:
                ind['sharpe'] = detail['back_test_sharpe']
                ind['annual_return'] = detail['back_test_annual_return']
                ind['profitrate'] = detail['back_test_profitrate']
                ind['max_drawdown_pnl'] = detail['back_test_max_drawdown_pnl']
            else:
                ind['sharpe'] = detail['paper_trading_sharpe']
                ind['annual_return'] = detail['paper_trading_annual_return']
                ind['profitrate'] = detail['paper_trading_profitrate']
                ind['max_drawdown_pnl'] = detail['paper_trading_max_drawdown_pnl']
            range_ind[y_key] = ind

        sc = session()
        sc.query(VsLiveRangePerformance).filter(
            VsLiveRangePerformance.vs_ids == vs_ids_key,
        ).delete()

        for k, ind in range_ind.items():
            vs_ind = VsLiveRangePerformance(
                vs_ids=vs_ids_key,
                group_key=k,
                start_date=ind['start_date'],
                end_date=ind['end_date'],
                sharpe=ind['sharpe'],
                annual_return=ind['annual_return'],
                profitrate=ind['profitrate'],
                max_drawdown_pnl=ind['max_drawdown_pnl'],
            )
            sc.add(vs_ind)
        sc.commit()
        return True

    @staticmethod
    def check_or_generate_range_pnl_delay(vs_ids, pnl, **kwargs):
        from cron.strategy_upload_task import investment_check_or_generate_range_pnl_delay
        investment_check_or_generate_range_pnl_delay.delay(
            vs_ids, pnl, **kwargs
        )
        return True


class InvestmentPerformanceGroupStrategyService(BaseInvestmentServiceMixin, ServiceBaseService):
    _lastday_position = {}
    _last_total_pnl = {}

    def __init__(self, current_user, strategy_id, portfolio_id, **kwargs):
        self.current_user = current_user
        self.strategy_id = int(strategy_id)
        self.portfolio_id = int(portfolio_id)
        self.kwargs = kwargs
        self.sc = session()
        self.trading_date, self.day_night = StrategyPerfInput.get_trading_date_day_night()
        self.cache_key = kwargs.get('cache_key', '')
        if not self.cache_key:
            self.cache_key = 'platform_investment_group_basic_data_%s_%s' % (
                strategy_id, portfolio_id
            )
        self.vs_detail = {}
        self.trade_detail = {}
        super(InvestmentPerformanceGroupStrategyService, self).__init__()

    def __del__(self):
        self.sc.close()
        self.kdb.release()

    def investment_basic_data(self):
        strategies_detail = self.sc.query(
            VStrategies.id.label('vs_id'),
            VStrategies.status.label('strategy_status'),
            VStrategies.trade_model.label('vs_trade_model'),
            Strategy.id_no.label('id_no'),
            Strategy.id.label('s_id'),
            Strategy.strategy_type.label('strategy_type'),
            Strategy.r_create_time.label('s_create_time'),
            Strategy.name.label('s_name'),
            Strategy.paper_trading_date.label('paper_trading_date'),
            Strategy.hedge.label('hedge'),
            Strategy.hedge_type.label('hedge_type'),
            Strategy.detail.label('s_detail'),
            Strategy.node.label('node'),
        ).join(
            Strategy,
            and_(
                Strategy.id == VStrategies.strategy_id, VStrategies.group_id == self.strategy_id,
            )
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            VStrategies.source == 'platform',
            VStrategies.portfolio_id == self.portfolio_id
        )
        s_detail, vs_detail = {}, {}
        for s in strategies_detail:
            if s.id_no not in s_detail:
                s_detail[s.id_no] = {
                    'hedge': s.hedge,
                    'hedge_type': s.hedge_type,
                    'upload_type': s.node if s.node != 'back_test' else 'so_file',
                    'invest_funds': 0,
                    'name': s.s_name,
                    'trade_model': s.s_detail.get('trade_model', ''),
                    'vs_trade_model': s.vs_trade_model or s.s_detail.get('trade_model', ''),
                    's_id': s.s_id,
                    'id': '%s_%s' % (self.portfolio_id, s.s_id),
                    'strategy_id': s.id_no,
                    'strategy_type': s.strategy_type,
                    'today_pnl': 0,
                    'total_pnl': 0,
                    'vs_ids': [],
                    'uptime': s.s_create_time.strftime('%Y%m%d'),
                    'ctime': s.s_create_time.strftime('%Y%m%d %X'),
                    'papertrading_date': (s.paper_trading_date or s.s_create_time).strftime('%Y-%m-%d'),
                    'pnl_url': '',
                }
            s_detail[s.id_no]['vs_ids'].append(s.vs_id)
            vs_d = vs_detail.setdefault(s.vs_id, {
                'invest_funds': 0,
                'status': s.strategy_status,
            })

        invest_funds = self.sc.query(
            VStrategyAccountDetail.vstrategy_id.label('vs_id'),
            func.sum(VStrategyAccountDetail.amount).label('amount'),
        ).filter(
            VStrategyAccountDetail.vstrategy_id.in_(vs_detail.keys()),
        ).group_by(
            VStrategyAccountDetail.vstrategy_id,
        )
        for r in invest_funds:
            if vs_detail[r.vs_id]['status'] == consts.STRATEGY_LIVE:
                vs_detail[r.vs_id]['invest_funds'] += float(r.amount)

        strategy_name = self.sc.query(Strategy.name).filter(Strategy.id == self.strategy_id).first()[0]

        for _, s_d in s_detail.items():
            pnl_args = {
                'summary': False,
                'vs_ids': s_d['vs_ids'],
                'strategy_id': s_d['s_id'],
            }
            s_d['invest_funds'] = sum([vs_detail.get(v_id, {}).get('invest_funds', 0) for v_id in s_d['vs_ids']])
            s_d['pnl_url'] = self.get_pnl_graph_url(pnl_args)
        return {
            'rows': sorted(s_detail.values(), key=lambda d: d['strategy_id']),
            'strategy_name': strategy_name,
        }

    def get_investment_live_pnl(self):
        strategies_detail = self.sc.query(
            VStrategies.id.label('vs_id'),
            VStrategies.symbols_accounts_detail.label('symbols_accounts'),
            Strategy.id.label('s_id'),
        ).join(
            Strategy,
            and_(
                Strategy.id == VStrategies.strategy_id, VStrategies.group_id == self.strategy_id,
            )
        ).filter(
            VStrategies.status == consts.STRATEGY_LIVE,
            VStrategies.source == 'platform',
            VStrategies.portfolio_id == self.portfolio_id
        )

        group_detail = {}
        for s in strategies_detail:
            g_id = '%s_%s' % (self.portfolio_id, s.s_id)
            group_d = group_detail.setdefault(g_id, {
                's_id': s.s_id,
                'vs_ids': [],
            })
            group_d['vs_ids'].append(s.vs_id)
            acc_currency = {
                _acc_d['account']: _acc_d.get('currency', 'CNY') or 'CNY'
                for _acc_d in VStrategies.normalization_symbols_accounts(s.symbols_accounts)
            }
            acc_currency['20052121'] = 'CNY'
            vs_d = self.vs_detail.setdefault(s.vs_id, {})
            vs_d['acc_currency'] = acc_currency

        if group_detail:
            if not self.trade_detail:
                self.trade_detail = self.get_current_day_trading_logs()
            for k, group_d in group_detail.items():
                pnl = self.get_current_day_pnl(group_d['vs_ids'])
                group_d['today_pnl'] = pnl['today_pnl']
                group_d['total_pnl'] = pnl['total_pnl']
                group_d['fee'] = pnl['fee']

        return group_detail

    def investment_pnl_data(self):
        strategies_detail = self.sc.query(
            VStrategies.id.label('vs_id'),
            VStrategies.trade_model.label('vs_trade_model'),
            Strategy.id.label('s_id'),
            Strategy.paper_trading_date.label('paper_trading_date'),
            Strategy.r_create_time.label('s_create_time'),
            Strategy.hedge.label('hedge'),
            Strategy.hedge_type.label('hedge_type'),
            Strategy.strategy_type.label('strategy_type'),
            Strategy.detail.label('s_detail'),
            Strategy.node.label('node'),
            StrategyPortfolio.id.label('sp_id'),
            StrategyPortfolio.r_create_user_id.label('p_user_id'),
        ).join(
            Strategy,
            and_(
                Strategy.id == VStrategies.strategy_id, VStrategies.group_id == self.strategy_id,
            )
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            VStrategies.source == 'platform',
            VStrategies.portfolio_id == self.portfolio_id
        )

        group_detail = {}
        vs_ids = []
        for s in strategies_detail:
            g_id = '%s_%s' % (s.sp_id, s.s_id)
            group_d = group_detail.setdefault(g_id, {
                's_id': s.s_id,
                'vs_ids': []
            })
            group_d['vs_ids'].append(s.vs_id)
            group_d['p_user_id'] = s.p_user_id
            group_d['papertrading_date'] = (s.paper_trading_date or s.s_create_time).strftime('%Y-%m-%d')
            group_d['hedge'] = s.hedge
            group_d['hedge_type'] = s.hedge_type
            group_d['strategy_type'] = s.strategy_type
            group_d['upload_type'] = s.node if s.node != 'back_test' else 'so_file'
            group_d['trade_model'] = s.s_detail.get('trade_model', '')
            group_d['vs_trade_model'] = s.vs_trade_model or s.s_detail.get('trade_model', '')
            vs_ids.append(s.vs_id)

        for _, group_d in group_detail.items():
            # if group_d['p_user_id'] == self.current_user['id']:
            #     group_d['events'] = Strategy.get_accident_events(group_d['vs_ids'])
            # else:
            #     group_d['events'] = {}
            group_d['events'] = Strategy.get_accident_events(group_d['vs_ids'])
            s_pnl = Strategy.investment_performance_net_pnl(
                group_d['s_id'], group_d['vs_ids'], trading_date=self.trading_date, day_night=self.day_night
            )
            group_d.update(s_pnl['back_test_paper_trading_net_line'])
            group_d.update(s_pnl['live_net_combine_line'])
            group_d.update(s_pnl['vs_back_test_combine_net'])
        return group_detail


class InvestmentPerformanceShareService(object):

    def __init__(self):
        self.sc = session()

    def __del__(self):
        self.sc.close()

    def get_all_strategy_set(self, current_user, **kwargs):
        result = {}
        user_id = current_user['id']

        page = kwargs.get('page', '')
        is_stock_group = kwargs.get('is_stock_group', False)
        is_future_group = kwargs.get('is_future_group', False)
        if not page:
            page = ['stock', 'future', 'default']
            strateg_set_filter = and_(
                NewStrategySet.r_create_user_id == user_id,
            )
        else:
            if page == 'stock':
                filter_name = '%%%s%%' % 'DTO'
            else:
                filter_name = '%%%s%%' % 'DFT'
            page = [page]

            if (page[0] == 'stock' and is_stock_group) or (page[0] == 'future' and is_future_group):
                strateg_set_filter = and_(
                    or_(
                        NewStrategySet.r_create_user_id == user_id,
                        NewStrategySet.name.ilike(filter_name)
                    ),
                    NewStrategySet.page.in_(page),
                )
            else:
                strateg_set_filter = and_(
                    NewStrategySet.r_create_user_id == user_id,
                    NewStrategySet.page.in_(page),
                )

        s_sets = self.sc.query(
            NewStrategySet.id.label('id'),
            NewStrategySet.name.label('name'),
            NewStrategySet.is_default.label('is_default'),
            NewStrategySet.r_create_user_id.label('owner_id'),
            NewStrategySet.r_create_user_id.label('create_user_id'),
            NewStrategySet.username.label('username'),
        ).filter(
            strateg_set_filter
        ).union_all(self.sc.query(
            NewStrategySetShare.strategy_set_id.label('id'),
            NewStrategySet.name.label('name'),
            NewStrategySetShare.is_default.label('is_default'),
            NewStrategySetShare.owner_id.label('owner_id'),
            NewStrategySet.r_create_user_id.label('create_user_id'),
            NewStrategySetShare.username.label('username'),
        ).join(
            NewStrategySet, NewStrategySet.id == NewStrategySetShare.strategy_set_id
        ).filter(
            NewStrategySetShare.owner_id == user_id,
            NewStrategySet.page.in_(page)
        ))

        for item in s_sets:
            item_name = item.name
            item_name_upper = item_name.upper()
            if (item.create_user_id != user_id) and ('DTO' not in item_name_upper) and ('DFT' not in item_name_upper):
                item_name = '%s(%s)' % (item.name, item.username)
            result[item.id] = {
                'id': item.id,
                'set_name': item_name,
                'set_list': [],
                'last': 0,
                'default': item.is_default,
                'owner_id': item.owner_id,
                'shared': item.create_user_id != user_id,
            }
            if ('DTO' in item_name_upper) or ('DFT' in item_name_upper):
                result[item.id]['owner_id'] = user_id
                result[item.id]['shared'] = False

        strategy_set_detail = self.sc.query(
            NewStrategySetdetail.strategy_set_id.label('strategy_set_id'),
            NewStrategySetdetail.vs_id.label('vs_id'),
        ).filter(
            NewStrategySetdetail.strategy_set_id.in_(result.keys())
        )
        for s_d in strategy_set_detail:
            result[s_d.strategy_set_id]['set_list'].append(s_d.vs_id)
        default_id = 0
        default_set = self.sc.query(DefaulStrategySet).filter(DefaulStrategySet.r_create_user_id == user_id).first()
        if default_set:
            default_id = default_set.strategy_set_id
        data = {
            'rows': sorted(result.values(), key=lambda d: d['id']),
            'default_id': default_id
        }
        return data

    def delete_strategy_set(self, current_user, set_id):
        user_id = current_user['id']
        set_id = int(set_id)
        s_set = self.sc.query(NewStrategySet).filter(
            NewStrategySet.r_create_user_id == user_id,
            NewStrategySet.id == set_id
        )
        if s_set.count():
            s_set.delete(synchronize_session=False)
            self.sc.commit()
            for share_user in self.sc.query(NewStrategySetShare.owner_id.label('owner_id')).filter(
                    NewStrategySetShare.strategy_set_id == set_id
            ):
                InvestmentPerformanceService.clear_basic_cache(
                    {'id': share_user.owner_id}
                )
            return True
        else:
            s_set = self.sc.query(NewStrategySetShare).filter(
                NewStrategySetShare.strategy_set_id == set_id,
                NewStrategySetShare.owner_id == user_id
            )
            if s_set.count():
                s_set.delete(synchronize_session=False)
                self.sc.commit()
                InvestmentPerformanceService.clear_basic_cache(
                    {'id': user_id}
                )
                return True
        return False

    def add_strategy_set(self, current_user, payload):
        if 'id' in payload:
            s_set = self.sc.query(NewStrategySet).filter(
                NewStrategySet.id == payload['id']
            )
            if not (('DTO' in payload['strat_set_name']) or ('DFT' in payload['strat_set_name'])):
                s_set = s_set.filter(
                    NewStrategySet.r_create_user_id == current_user['id']
                )
            s_set = s_set.first()
            s_set.name = payload['strat_set_name']
        else:
            s_set = self.sc.query(NewStrategySet).filter(
                NewStrategySet.name == payload['strat_set_name']
            )
            if not (('DTO' in payload['strat_set_name']) or ('DFT' in payload['strat_set_name'])):
                s_set = s_set.filter(
                    NewStrategySet.r_create_user_id == current_user['id']
                )
            s_set = s_set.first()
            if not s_set:
                s_set = NewStrategySet(
                    r_create_user_id=current_user['id'],
                    name=payload['strat_set_name'],
                    username=current_user['username'],
                    is_default=0,
                    page=payload.get('page', 'default') or 'default',
                )
                self.sc.add(s_set)
                self.sc.flush()
        self.sc.query(NewStrategySetdetail).filter(NewStrategySetdetail.strategy_set_id == s_set.id).delete()
        for v_id in payload['strat_set_list']:
            n_s_d = NewStrategySetdetail(
                strategy_set_id=s_set.id,
                vs_id=int(v_id),
            )
            self.sc.add(n_s_d)
        self.sc.commit()
        data = {
            'id': s_set.id,
            'set_name': payload['strat_set_name'],
            'set_list': payload['strat_set_list'],
            'last': 0,
            'default': 0,
            'owner_id': current_user['id'],
            'shared': False,
        }

        share_user_ids = self.sc.query(NewStrategySetShare.owner_id).filter(
            NewStrategySetShare.strategy_set_id == s_set.id
        )
        for owner_id in share_user_ids:
            InvestmentPerformanceService.clear_basic_cache({'id': owner_id[0]})

        return data

    def set_default(self, current_user, payload):
        set_id = int(payload['id'])
        self.sc.query(
            NewStrategySet
        ).filter(
            NewStrategySet.id == int(set_id),
            NewStrategySet.r_create_user_id == current_user['id'],
        ).update(
            {'is_default': 1},
            synchronize_session=False
        )

        self.sc.query(
            NewStrategySetShare
        ).filter(
            NewStrategySetShare.strategy_set_id == int(set_id),
            NewStrategySetShare.owner_id == current_user['id'],
        ).update(
            {'is_default': 1},
            synchronize_session=False
        )

        self.sc.query(
            NewStrategySet
        ).filter(
            NewStrategySet.id != int(set_id),
            NewStrategySet.r_create_user_id == current_user['id'],
        ).update(
            {'is_default': 0},
            synchronize_session=False
        )

        self.sc.query(
            NewStrategySetShare
        ).filter(
            NewStrategySetShare.strategy_set_id != int(set_id),
            NewStrategySetShare.owner_id == current_user['id'],
        ).update(
            {'is_default': 0},
            synchronize_session=False
        )
        self.sc.commit()
        return True

    def set_default2(self, current_user, payload):
        set_id = int(payload['id'])
        s_set = self.sc.query(
            DefaulStrategySet
        ).filter(
            DefaulStrategySet.r_create_user_id == current_user['id'],
        ).first()
        if s_set:
            s_set.strategy_set_id = set_id
        else:
            s_set = DefaulStrategySet(
                strategy_set_id=int(payload['id']),
                r_create_user_id=current_user['id']
            )
            self.sc.add(s_set)
        self.sc.commit()
        return True

    def share_strategy_set(self, current_user, payload):
        s_set = self.sc.query(
            NewStrategySet
        ).filter(
            or_(
                NewStrategySet.r_create_user_id == current_user['id'],
                NewStrategySet.name.ilike('%%DFT%%'),
                NewStrategySet.name.ilike('%%DTO%%'),
            ),
            NewStrategySet.id == int(payload['id']),
            NewStrategySet.name.notin_(['实盘策略', '已下架策略', '所有策略'])
        ).first()
        if not s_set:
            return False, '只能分享自己创建的策略集(不包含,实盘策略、所有策略、已下架策略集等)'

        shared_vs = self.sc.query(
            NewStrategySetdetail.id
        ).join(
            VStrategies, VStrategies.id == NewStrategySetdetail.vs_id
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            NewStrategySetdetail.strategy_set_id == s_set.id,
            StrategyPortfolio.r_create_user_id.notin_(
                [current_user['id']] if current_user['id'] != 302 else consts.investment_user_ids
            )
        ).first()

        # if shared_vs:
        #     return False, '此策略集包含其他用户分享的策略'

        shared_user_ids = {r[0]: r[1] for r in self.sc.query(
            NewStrategySetShare.owner_id,
            NewStrategySetShare.id
        ).filter(
            NewStrategySetShare.strategy_set_id == s_set.id
        )}
        for owner_id in payload['user_ids']:
            if owner_id in shared_user_ids:
                continue
            share_set = NewStrategySetShare(
                strategy_set_id=s_set.id,
                name='',
                owner_id=owner_id,
                r_create_user_id=current_user['id'],
                username=current_user['username'],
                is_default=0,
            )
            self.sc.add(share_set)
        delete_ids = [k_id for k, k_id in shared_user_ids.items() if k not in payload['user_ids']]
        if delete_ids:
            self.sc.query(NewStrategySetShare).filter(NewStrategySetShare.id.in_(delete_ids)).delete(
                synchronize_session=False)
        self.sc.commit()
        for owner_id in payload['user_ids']:
            InvestmentPerformanceService.clear_basic_cache({'id': owner_id})
        return True, ''

    def batch_share_strategy_set(self, current_user, payload):
        for set_id, owner_id in itertools.product(payload['ids'], payload['user_ids']):
            share_set = NewStrategySetShare(
                strategy_set_id=set_id,
                name='',
                owner_id=owner_id,
                r_create_user_id=current_user['id'],
                username=current_user['username'],
                is_default=0,
            )
            self.sc.add(share_set)
        self.sc.commit()
        for owner_id in payload['user_ids']:
            InvestmentPerformanceService.clear_basic_cache({'id': owner_id})
        return True, ''

    def cancel_share_strategy_set(self, current_user, payload):
        self.sc.query(NewStrategySetShare).filter(
            NewStrategySetShare.strategy_set_id == int(payload['id']),
            NewStrategySetShare.owner_id.in_(payload['user_ids'])
        ).delete(synchronize_session=False)
        self.sc.commit()
        for owner_id in payload['user_ids']:
            InvestmentPerformanceService.clear_basic_cache({'id': owner_id})
        return True, ''

    def batch_share_vstrategies(self, current_user, payload):
        """
        payload = {
            'share_detail': {
                {
                   'vs_ids': [1, 2, 3],
                   'user_ids': [1, 2, 3]
                },
                {
                    'vs_ids': [4, 5, 6],
                    'user_ids': [3, 4]
                },
            }
        }
        """
        share_detail = payload['share_detail']
        vs_ids = itertools.chain.from_iterable([r['vs_ids'] for r in share_detail])
        shared_vs_ids = {
            (r[0], r[1]): r[2] for r in self.sc.query(
                InvestMentShare.vstrategy_id,
                InvestMentShare.owner_id,
                InvestMentShare.id,
            ).filter(InvestMentShare.vstrategy_id.in_(vs_ids))
        }
        user_ids = []
        for d in share_detail:
            user_ids.extend(d['user_ids'])
            for v_id, user_id in itertools.product(d['vs_ids'], d['user_ids']):
                key = (v_id, user_id)
                if key in shared_vs_ids:
                    continue

                if user_id == current_user['id']:
                    continue
                share_vs = InvestMentShare(
                    vstrategy_id=v_id,
                    owner_id=user_id,
                    r_create_user_id=current_user['id'],
                )
                self.sc.add(share_vs)
        self.sc.commit()
        for owner_id in user_ids:
            InvestmentPerformanceService.clear_basic_cache({'id': owner_id})
        return True

    def share_vstrategies(self, current_user, payload):
        """
        payload = {
            'share_detail': {
                {
                   'vs_ids': [1, 2, 3],
                   'user_ids': [1, 2, 3]
                },
                {
                    'vs_ids': [4, 5, 6],
                    'user_ids': [3, 4]
                },
            }
        }
        """
        share_detail = payload['share_detail']
        vs_ids = itertools.chain.from_iterable([r['vs_ids'] for r in share_detail])
        shared_vs_ids = {
            (r[0], r[1]): r[2] for r in self.sc.query(
                InvestMentShare.vstrategy_id,
                InvestMentShare.owner_id,
                InvestMentShare.id,
            ).filter(InvestMentShare.vstrategy_id.in_(vs_ids))
        }
        user_ids = []
        vs_user_pair = {}
        for d in share_detail:
            user_ids.extend(d['user_ids'])
            for v_id, user_id in itertools.product(d['vs_ids'], d['user_ids']):
                key = (v_id, user_id)
                vs_user_pair[key] = 1
                if key in shared_vs_ids:
                    continue

                if user_id == current_user['id']:
                    continue
                share_vs = InvestMentShare(
                    vstrategy_id=v_id,
                    owner_id=user_id,
                    r_create_user_id=current_user['id'],
                )
                self.sc.add(share_vs)
        delete_ids = [share_id for key, share_id in shared_vs_ids.items() if key not in vs_user_pair]
        if delete_ids:
            self.sc.query(InvestMentShare).filter(InvestMentShare.id.in_(delete_ids)).delete(synchronize_session=False)
        self.sc.commit()
        for owner_id in user_ids:
            InvestmentPerformanceService.clear_basic_cache({'id': owner_id})
        return True

    def cancel_share_vstrategies(self, current_user, payload):
        """
        payload = {
            'vs_ids': [],
            'user_ids': [],
        }
        """
        self.sc.query(
            InvestMentShare
        ).filter(
            InvestMentShare.vstrategy_id.in_(payload['vs_ids']),
            InvestMentShare.owner_id.in_(payload['user_ids']),
        ).delete(synchronize_session=False)
        self.sc.commit()
        for owner_id in payload['user_ids']:
            InvestmentPerformanceService.clear_basic_cache({'id': owner_id})
        return True

    def cancel_subscribe_vstrategies(self, current_user, payload):
        vs_ids = payload['vs_ids']
        self.sc.query(InvestMentShare).filter(
            InvestMentShare.owner_id == current_user['id'],
            InvestMentShare.vstrategy_id.in_(vs_ids)
        ).delete(synchronize_session=False)
        self.sc.commit()
        InvestmentPerformanceService.clear_basic_cache({'id': current_user['id']})
        return True

    def get_share_status(self, current_user):
        strategies_detail = self.sc.query(
            VStrategies.id.label('vs_id'),
            Strategy.id.label('s_id'),
            Strategy.id_no.label('id_no'),
            StrategyPortfolio.id.label('sp_id'),
            StrategyPortfolio.r_create_user_id.label('p_user_id'),
            StrategyPortfolio.username.label('p_user_name'),
        ).join(
            Strategy, or_(
                and_(
                    Strategy.id == VStrategies.strategy_id,
                    VStrategies.group_id == 0
                ),
                Strategy.id == VStrategies.group_id
            )
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            StrategyPortfolio.status >= consts.STRATEGY_LIVE,
            StrategyPortfolio.source == 'platform',
            VStrategies.source == 'platform',
        )
        investment_strategies_detail = strategies_detail.filter(
            StrategyPortfolio.r_create_user_id.in_(
                [current_user['id']] if current_user['id'] != 302 else consts.investment_user_ids
            )
        )
        subscribe_strategies_detail = strategies_detail.filter(
            VStrategies.id.in_(self.sc.query(
                InvestMentShare.vstrategy_id
            ).filter(
                InvestMentShare.owner_id == current_user['id']
            ))
        )

        publish_strategy_set_detail = self.sc.query(
            NewStrategySet.id.label('id'),
            NewStrategySet.name.label('name'),
            NewStrategySetShare.owner_id.label('owner_id'),
        ).join(
            NewStrategySetShare, NewStrategySetShare.strategy_set_id == NewStrategySet.id
        ).filter(NewStrategySetShare.r_create_user_id == current_user['id'])

        investment_share_strategies_detail = {}
        for s in self.sc.query(
                InvestMentShare.vstrategy_id.label('vs_id'),
                InvestMentShare.owner_id.label('owner_id'),
        ).filter(
            InvestMentShare.r_create_user_id == current_user['id']
        ):
            vs2user = investment_share_strategies_detail.setdefault(s.vs_id, [])
            vs2user.append(s.owner_id)

        subscribe_strategy_set_detail = self.sc.query(
            NewStrategySet.id.label('id'),
            NewStrategySet.name.label('name'),
            NewStrategySetShare.owner_id.label('owner_id'),
            NewStrategySetShare.username.label('username'),
        ).join(
            NewStrategySetShare, NewStrategySetShare.strategy_set_id == NewStrategySet.id
        ).filter(NewStrategySetShare.owner_id == current_user['id'])

        investment_strategies = {}
        subscribe_strategies = {}
        publish_strategy_set = {}
        subscribe_strategy_set = {}
        user_ids = list(itertools.chain.from_iterable(investment_share_strategies_detail.values()))
        for s in investment_strategies_detail:
            key = '%s_%s' % (s.sp_id, s.s_id)
            investment_s = investment_strategies.setdefault(key, {
                'id': key,
                's_id': s.s_id,
                'strategy_id': s.id_no,
                'vs_ids': [],
                'subscriber': [],
            })
            investment_s['vs_ids'].append(s.vs_id)

        for s in subscribe_strategies_detail:
            key = '%s_%s' % (s.sp_id, s.s_id)
            subscribe_s = subscribe_strategies.setdefault(key, {
                'id': key,
                's_id': s.s_id,
                'strategy_id': s.id_no,
                'vs_ids': [],
                'publisher': s.p_user_name,
            })
            subscribe_s['vs_ids'].append(s.vs_id)

        for s in publish_strategy_set_detail:
            key = s.id
            publish_s = publish_strategy_set.setdefault(key, {
                'id': key,
                'name': s.name,
                'subscriber': [],
                'subscribe_user_ids': [],
            })
            publish_s['subscribe_user_ids'].append(s.owner_id)
            user_ids.append(s.owner_id)

        for s in subscribe_strategy_set_detail:
            key = s.id
            subscribe_s = subscribe_strategy_set.setdefault(key, {
                'id': key,
                'name': s.name,
                'publisher': s.username,
            })

        user_detail = {u.id: {
            'id': u.id,
            'name': u.name,
        } for u in self.sc.query(Users.id.label('id'), Users.name.label('name')).filter(Users.id.in_(user_ids))}

        for _, s_d in investment_strategies.items():
            subscribe_user_ids = set(itertools.chain.from_iterable(
                investment_share_strategies_detail[v_id]
                for v_id in s_d['vs_ids'] if investment_share_strategies_detail.get(v_id)
            ))
            s_d['subscriber'] = [user_detail[u_id] for u_id in subscribe_user_ids if u_id in user_detail]

        for _, s_d in publish_strategy_set.items():
            s_d['subscriber'] = [user_detail[u_id] for u_id in set(s_d['subscribe_user_ids']) if u_id in user_detail]

        data = {
            'investment_strategies': sorted(investment_strategies.values(), key=lambda d: d.get('id', '')),
            'subscribe_strategies': sorted(subscribe_strategies.values(), key=lambda d: d.get('id', '')),
            'publish_strategy_set': sorted(publish_strategy_set.values(), key=lambda d: d.get('id', '')),
            'subscribe_strategy_set': sorted(subscribe_strategy_set.values(), key=lambda d: d.get('id', '')),
        }
        return data


class InvestmentStrategyMetricService(object):

    def __init__(self):
        self.sc = session()
        self.trading_date, self.day_night = StrategyPerfInput.get_trading_date_day_night()

    def __del__(self):
        self.sc.close()

    def get_strategy_metric(self, s_ids):

        if not s_ids:
            return {}
        s_ids = [int(s_id) if str(s_id).isdigit() else s_id for s_id in s_ids]
        strategies = self.sc.query(
            Strategy.id.label('s_id'),
            Strategy.products.label('products'),
        ).filter(
            or_(
                Strategy.id.in_(s_ids)
            )
        )
        data = {}
        for s in strategies:
            data[s.s_id] = {
                'id': s.s_id,
                'products': [],
                'position': {},
                'total_asset': 0,
                'vs_ids': [],
            }
            if s.products:
                data[s.s_id]['products'] = [p['symbol'] for p in s.products[0]]

        vstrategies = self.sc.query(
            VStrategies.id.label('vs_id'),
            VStrategies.strategy_id.label('s_id'),
            VStrategies.group_id.label('group_id'),
        ).join(
            Strategy, or_(
                and_(
                    Strategy.id == VStrategies.strategy_id,
                    VStrategies.group_id == 0
                ),
                Strategy.id == VStrategies.group_id
            )
        ).filter(
            VStrategies.status == consts.STRATEGY_LIVE,
            Strategy.id.in_(data.keys())
        )
        vs_ids = []
        for vs in vstrategies:
            vs_ids.append(vs.vs_id)
            if vs.group_id > 0:
                data[vs.group_id]['vs_ids'].append(vs.vs_id)
            else:
                data[vs.s_id]['vs_ids'].append(vs.vs_id)

        lastday_position = self.get_lastday_position(vs_ids)
        today_trading_data = self.get_current_day_trading_logs(vs_ids)
        lastday_total_asset = self.get_lastday_total_asset(vs_ids)

        for s_id, s_d in data.items():
            for v_id in s_d['vs_ids']:
                s_d['total_asset'] += lastday_total_asset[v_id]
                l_p = lastday_position.get(v_id, {})
                for sym, sym_d in l_p.items():
                    s_d_sym = s_d['position'].setdefault(sym, {
                        'long_pos': 0,
                        'short_pos': 0,
                    })
                    s_d_sym['long_pos'] += sym_d['long_pos']
                    s_d_sym['short_pos'] += sym_d['short_pos']

                t_t = today_trading_data.get(v_id, {})
                for sym, sym_d in t_t.items():
                    s_d_sym = s_d['position'].setdefault(sym, {
                        'long_pos': 0,
                        'short_pos': 0,
                    })
                    s_d_sym['long_pos'] += sym_d['long_pos']
                    s_d_sym['short_pos'] += sym_d['short_pos']
        return data

    def get_lastday_total_asset(self, vs_ids):
        if not vs_ids:
            return {}
        data = {}
        sql = """
        select vstrategy_id, total_asset
        from vs_base
        where settle_date = (select max(settle_date) from vs_base where daynight='DAY')
        and daynight='DAY' and vstrategy_id in ({vstrategy_id_str})
        """.format(vstrategy_id_str=','.join(map(str, vs_ids)))
        for r in self.sc.execute(sql):
            data[r[0]] = float(r[1])
        if not data:
            raise ValueError('get last total asset error')

        a = set(vs_ids)
        b = set(data.keys())
        diff = a - b
        if diff:
            sql = """
            select vstrategy_id, sum(amount) from vstrategy_account_detail
            where vstrategy_id in ({vstrategy_id_str}) GROUP BY vstrategy_id
            """.format(vstrategy_id_str=','.join(map(str, diff)))
            for r in self.sc.execute(sql):
                data[r[0]] = float(r[1])

        return data

    def get_lastday_position(self, vs_ids):
        if not vs_ids:
            return {}
        data = {}
        sql = """
        select vstrategy_id, symbol, today_long_pos, today_short_pos
        from vs_positions
        where settle_date = (select max(settle_date) from vs_base where daynight='DAY')
        and daynight='DAY' and (today_long_pos > 0 or today_short_pos >0) and vstrategy_id in ({vstrategy_id_str})
        """.format(vstrategy_id_str=','.join(map(str, vs_ids)))
        for r in self.sc.execute(sql):
            v_pos = data.setdefault(r[0], {})
            v_pos[r[1]] = {
                'long_pos': float(r[2]),
                'short_pos': float(r[3]),
            }
        return data

    def get_current_day_trading_logs(self, vs_ids):
        if not vs_ids:
            return {}

        sql = """select vstrategy_id, symbol, direction, open_close, sum(trade_vol) from
          ((select vstrategy_id, symbol, direction, open_close, trade_vol
          from trade_logs
          where trading_date={trading_date} and log_type='3' and entrust_status in ('p', 'c') and vstrategy_id in ({vstrategy_id_str}))
          UNION all (
           select vstrategy_id, symbol,
            case direction when 'BUY' then 0 when 'SELL' then 1 end as direction,
            case open_close when 'OPEN' then 0 when 'CLOSE' then 1 end as open_close,
           trade_vol
           from settlement_manual_tradelogs where trading_date={trading_date} and vstrategy_id in ({vstrategy_id_str})
          )) as a
         group by vstrategy_id, symbol, direction, open_close
        """.format(trading_date=self.trading_date, vstrategy_id_str=','.join(map(str, vs_ids)))

        trading_data = {}

        for r in self.sc.execute(sql):
            v_id = r[0]
            sym = r[1]
            d_flag = int(r[2])
            o_flag = int(r[3])
            qty = float(r[4])
            v_trade = trading_data.setdefault(v_id, {})
            v_sym_trade = v_trade.setdefault(sym, {
                'long_pos': 0,
                'short_pos': 0,
            })
            if d_flag == consts.Direction.buy.value and o_flag == consts.OpenClose.open.value:
                # buy open
                v_sym_trade['long_pos'] += qty
            elif d_flag == consts.Direction.sell.value and o_flag == consts.OpenClose.open.value:
                # sell open
                v_sym_trade['short_pos'] += qty
            elif d_flag == consts.Direction.sell.value:
                # sell close
                v_sym_trade['long_pos'] -= qty
            elif d_flag == consts.Direction.buy.value:
                # buy close
                v_sym_trade['short_pos'] -= qty
        return trading_data

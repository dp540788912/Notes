import pandas as pd
import numpy as np
import os
from my.data import basic_func
import base64
import json
import io
import copy


def datetostr(date):
    # date format: 'yyyy.mm.dd...', 'yyyy-mm-dd...'
    x = str(date)
    return x[:4] + '.' + x[5:7] + '.' + x[8:10]


def tradecalendar():
    y = basic_func.get_kdb('select date:TRADE_DT  from Calendar where EXCHANGE in `SSE`SZSE', 'FuturesBasicInfo')
    y = sorted(y['date'].unique())
    y = [datetostr(x) for x in y]
    return y


def addition_tradeday(date, x):
    # date format: 'yyyy.mm.dd'
    # x: [int, ..., int]
    calendar = tradecalendar()
    no_date = sum([1 for z in calendar if z < date])
    y = [calendar[no_date + z] for z in x]
    return y


def reading_log(file):
    tmp_file = open(file, 'r')
    lines = tmp_file.readlines()
    tmp_file.close()

    default_dict = {'predictions': None, 'hedging': None, 'risk_dict': None,
                    'quick_setup': None, 'infor': None,
                    'current_list': None, 'target_list': None}
    keys = list(default_dict.keys())

    allinfor = {}
    tmp_n = 0

    tmp_to = 0
    tmp_sig = ''
    tmp_str = ''

    for line in lines:
        lin = line[:-1]
        if lin == 'START_Portfolio_Optimization':
            tmp_to = 0

        if lin == 'START_Portfolio_Optimization':
            tmp_n = tmp_n + 1
            allinfor[tmp_n] = copy.deepcopy(default_dict)
            tmp_to = 1
            tmp_sig = ''
            tmp_str = ''
        elif (tmp_to == 1) & ((lin[1:-1] in keys) | (lin == 'END_Portfolio_Optimization')):
            if tmp_sig in ['predictions', 'current_list', 'target_list']:
                if tmp_str[:4] == 'None':
                    allinfor[tmp_n][tmp_sig] = None
                else:
                    allinfor[tmp_n][tmp_sig] = pd.read_csv(io.StringIO(tmp_str), sep='\s+')
                    allinfor[tmp_n][tmp_sig].iloc[:, 0] = allinfor[tmp_n][tmp_sig].iloc[:, 0].\
                        apply(lambda x: str(x).zfill(6)).tolist()
            elif tmp_sig in ['risk_dict']:
                if tmp_str[:4] == 'None':
                    allinfor[tmp_n][tmp_sig] = None
                else:
                    allinfor[tmp_n][tmp_sig] = eval(tmp_str)
            elif tmp_sig in ['quick_setup', 'infor']:
                allinfor[tmp_n][tmp_sig] = tmp_str
            elif tmp_sig == 'hedging':
                if tmp_str in ['sh50', 'hs300', 'zz500']:
                    allinfor[tmp_n][tmp_sig] = tmp_str
                else:
                    if tmp_str[:4] == 'None':
                        allinfor[tmp_n][tmp_sig] = None
                    else:
                        allinfor[tmp_n][tmp_sig] = pd.read_csv(io.StringIO(tmp_str), sep='\s+')
                        allinfor[tmp_n][tmp_sig].iloc[:, 0] = allinfor[tmp_n][tmp_sig].iloc[:, 0]. \
                            apply(lambda x: str(x).zfill(6)).tolist()
            
            tmp_str = ''
            if lin == 'END_Portfolio_Optimization':
                tmp_to = 0
                tmp_sig = ''
            else:
                tmp_sig = lin[1:-1]
        elif tmp_to == 1:
            if tmp_sig in ['predictions', 'current_list', 'target_list']:
                tmp_str = tmp_str + line
            elif tmp_sig == 'hedging':
                if ('sh50' in line) | ('hs300' in line) | ('zz500' in line):
                    tmp_str = tmp_str + lin
                else:
                    tmp_str = tmp_str + line
            else:
                tmp_str = tmp_str + lin

    allinfor['number'] = tmp_n

    return allinfor


def factor_default(hedging):
    fct_default = {'hy': 'hy_sw1',
                   'bt': 'bt_' + hedging + '_barra2',
                   'bd': 'bd_' + hedging + '_barra2',
                   'jz': 'jz_btop_barra2',
                   'ld': 'ld_barra2',
                   'mm': 'mm_rstr_barra2',
                   'mv': 'mv_lnfloat_barra2',
                   'mu': 'mv_lnfloat_cubed_barra2',
                   'yl': 'yl_barra2',
                   'gg': 'gg_barra2'}

    fct_default_orth = {'bt': 'bt_' + hedging + '_barra2_orth_' + hedging + '_gg',
                        'bd': 'bd_' + hedging + '_barra2_orth_' + hedging + '_gg',
                        'gg': 'gg_barra2_orth_' + hedging + '_gg',
                        'jz': 'jz_btop_barra2_orth_' + hedging + '_gg',
                        'ld': 'ld_barra2_orth_' + hedging + '_gg',
                        'mm': 'mm_rstr_barra2_orth_' + hedging + '_gg',
                        'mv': 'mv_lnfloat_barra2_orth_' + hedging + '_gg',
                        'mu': 'mv_lnfloat_cubed_barra2_orth_' + hedging + '_gg',
                        'yl': 'yl_barra2_orth_' + hedging + '_gg'}

    return fct_default, fct_default_orth


def style_exposure(long_volume, date, risk_ev_path, strategy_path):
    # long_volume: a dataframe, columns = ['symbol', 'size'],  symbol: str or int '000023', 'size': int
    long_volume = copy.deepcopy(long_volume)
    long_volume.columns = ['symbol', 'size']

    date = str(int(date))

    allfiles = os.listdir(strategy_path)
    allfiles = sorted([x for x in allfiles if (x[:8] <= date) & (x[-4:] == '.log')])
    # if len(allfiles) > 1:
    #     myfile = allfiles[-1]
    # else:
    #     myfile = date + '_000001_000002_day.log'

    w = {}
    for i in range(-1, -len(allfiles) - 1, -1):
        w = reading_log(os.path.join(strategy_path, allfiles[i]))
        if w['number'] > 0.5:
            break

    restriction = {}
    if w['number'] > 0.5:
        hedging = w[w['number']]['hedging']
        quick_setup = w[w['number']]['quick_setup']

        # hedging
        idx_sig = False
        idx_weight = pd.DataFrame()
        if type(hedging) == pd.DataFrame:
            idx_sig = True
            idx_weight = copy.deepcopy(hedging)
            idx_weight.columns = ['symbol', 'idx_weight']
            if idx_weight['idx_weight'].sum() < 0:
                idx_weight['idx_weight'] = - idx_weight['idx_weight']
            hedging = 'zz500'
        else:
            if type(hedging) != str:
                hedging = 'zz500'
            else:
                if hedging not in ['sh50', 'hs300', 'zz500']:
                    hedging = 'zz500'

        dict_tmp = json.loads(base64.b64decode(quick_setup).decode())

        if 'hy' in list(dict_tmp.keys()):
            if dict_tmp['hy'][3] is True:
                tmp = [None, None]
                if dict_tmp['hy'][4] not in [None, '']:
                    if dict_tmp['hy'][4] >= 0:
                        tmp[0] = dict_tmp['hy'][4]
                if dict_tmp['hy'][5] not in [None, '']:
                    if dict_tmp['hy'][5] >= 0:
                        tmp[1] = dict_tmp['hy'][5]
                if (tmp[0] is not None) & (tmp[1] is not None):
                    restriction['hy'] = tmp

        for key in ['mv', 'bt', 'bd', 'ld', 'mm', 'yl', 'jz', 'gg']:
            if key in list(dict_tmp.keys()):
                if dict_tmp[key][3] is True:
                    if (dict_tmp[key][4] is None) & (dict_tmp[key][5] not in [None, '']):
                        restriction[key] = [None, dict_tmp[key][5]]
                    elif (dict_tmp[key][5] is None) & (dict_tmp[key][4] not in [None, '']):
                        restriction[key] = [dict_tmp[key][4], None]
                    elif (dict_tmp[key][4] not in [None, '']) & (dict_tmp[key][5] not in [None, '']):
                        if dict_tmp[key][4] <= dict_tmp[key][5]:
                            restriction[key] = [dict_tmp[key][4], dict_tmp[key][5]]
    else:
        hedging = 'zz500'

        # hedging
        idx_sig = False
        idx_weight = pd.DataFrame()

        for key in ['hy', 'mv', 'bt', 'bd', 'ld', 'mm', 'yl', 'jz', 'gg']:
            restriction[key] = [None, None]

    position = long_volume.sort_values(by='symbol')
    position.reset_index(drop=True, inplace=True)
    position.loc[:, 'symbol'] = [str(x)[:6].zfill(6) for x in position['symbol']]
    position = position[['symbol', 'size']]

    date_int = str(date)
    date_dot = date_int[0:4] + '.' + date_int[4:6] + '.' + date_int[6:8]

    file = 'portfolio_optimization_ev_plus_' + date_int + '.csv'

    ev = pd.read_csv(os.path.join(risk_ev_path, file))
    ev.loc[:, 'symbol'] = ev.loc[:, 'symbol'].apply(lambda x: x[:6]).tolist()
    
    weight = 'wt_' + hedging

    mv = 'mv_lnfloat_barra2_orth_' + hedging + '_gg'

    hy = 'hy_sw1'
    bt = 'bt_' + hedging + '_barra2_orth_' + hedging + '_gg'

    bd = 'bd_' + hedging + '_barra2_orth_' + hedging + '_gg'
    gg = 'gg_barra2_orth_' + hedging + '_gg'
    jz = 'jz_btop_barra2_orth_' + hedging + '_gg'
    ld = 'ld_barra2_orth_' + hedging + '_gg'
    mm = 'mm_rstr_barra2_orth_' + hedging + '_gg'
    yl = 'yl_barra2_orth_' + hedging + '_gg'
    
    fct_name = {mv: 'mv', hy: 'hy', bt: 'bt', bd: 'bd', ld: 'ld', mm: 'mm', yl: 'yl', jz: 'jz', gg: 'gg'}
    
    if idx_sig:
        if '999905' in list(idx_weight['symbol']):
            tmp_wt = idx_weight.loc[idx_weight['symbol'] == '999905', 'idx_weight'].tolist()[0]

            idx_weight = idx_weight.loc[idx_weight['symbol'] != '999905']
            tmp_ev = ev.loc[ev['wt_zz500'] > 0, ['symbol', 'wt_zz500']]

            idx_weight = pd.merge(idx_weight, tmp_ev, how='outer', on='symbol')
            idx_weight['idx_weight'].fillna(0, inplace=True)
            idx_weight['wt_zz500'].fillna(0, inplace=True)

            idx_weight['idx_weight'] = idx_weight['idx_weight'] + tmp_wt * idx_weight['wt_zz500']
            idx_weight = idx_weight[['symbol', 'idx_weight']]
        
        ev = pd.merge(idx_weight, ev, how='outer', on='symbol')
        ev['wt_zz500'] = ev['idx_weight']

    ev = ev[['symbol', weight, mv, hy, bt, bd, ld, mm, yl, jz, gg]]

    cols = 'symbol:SYMBOL, close:S_DQ_CLOSE'
    data_close = basic_func.get_kdb('select ' + cols + ' from AShareEODPrices where TRADE_DT=' + date_dot, 
                                    'EquityFactor')
    data_close.loc[:, 'symbol'] = data_close.loc[:, 'symbol'].apply(lambda x: x.decode()[:6]).tolist()
    
    tmp_a = pd.merge(position, data_close, how='outer', on='symbol')
    tmp_a.loc[~(tmp_a['size'] > 0), 'size'] = 0
    tmp_a = tmp_a.loc[tmp_a['close'] > 0]
    tmp_a['amount'] = tmp_a['size'] * tmp_a['close']
    tmp_a['weight'] = tmp_a['amount'] / sum(tmp_a['amount'])
    
    alldata = pd.merge(tmp_a[['symbol', 'weight']], ev, how='outer', on='symbol')
    alldata = alldata.sort_values(by='symbol')
    alldata.reset_index(drop=True, inplace=True)
    alldata['hy_sw1'].fillna('no', inplace=True)
    alldata = alldata.loc[alldata[hy] != 'no']
    alldata.fillna(0, inplace=True)
    
    hy_data = alldata.loc[:, ['symbol', 'weight', weight, hy]]
    hy_data['value'] = 1
    tmp_b = hy_data[['symbol', hy, 'value']].pivot_table(index=hy, columns='symbol', values='value').fillna(0)
    tmp_b_mat = np.mat(tmp_b)

    tmp_c = tmp_b_mat * (np.mat(hy_data[['weight']]) - np.mat(hy_data[[weight]]))
    tmp_b['rtn'] = tmp_c.T.tolist()[0]
    bias = tmp_b['rtn'].T.to_dict()
    bias[fct_name[hy]] = 1 - sum((tmp_b_mat * np.mat(hy_data[['weight', weight]])).min(axis=1))[0, 0]

    for fct in [mv, bt, bd, ld, mm, yl, jz, gg]:
        tmp_b = alldata.loc[:, ['symbol', 'weight', weight, fct]]
        tmp_b = tmp_b.loc[~(tmp_b[fct].isna())]
        bias[fct_name[fct]] = sum(tmp_b['weight'] * tmp_b[fct]) - sum(tmp_b[weight] * tmp_b[fct])
    
    restriction_keys = list(restriction.keys())
    bias_keys = list(bias.keys())
    for i in bias_keys:
        bias[i] = [bias[i], None, None]
        if '.SWS' in i:
            if 'hy' in restriction_keys:
                if restriction['hy'][0] is not None:
                    bias[i] = [bias[i][0], restriction['hy'][0], -restriction['hy'][0]]
        elif i == 'hy':
            if 'hy' in restriction_keys:
                if restriction['hy'][1] is not None: 
                    bias[i] = [bias[i][0], restriction['hy'][1], 0]
        else:
            if i in restriction_keys:
                bias[i] = [bias[i][0], restriction[i][1], restriction[i][0]]
        
    return bias

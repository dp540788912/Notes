# -*-coding:utf-8-*-


# 复盘表
from dateutil.parser import parse
import pandas as pd
from qpython import qconnection
import requests
import json

from db import session
from service.back_test.live_position_models import VsPosition
from service.statistic.tmp_consts import SW_IndustryCategory, WD_IndustryCategory

def get_index_weight(date):
    with qconnection.QConnection(host='192.168.10.102',port=9000,username='user1',password='password') as q:
        lsql = '.gw.asyncexec["select from AIndexFreeWeight where CODE=`000905.SH, TRADE_DT<=%04d.%02d.%02d,TRADE_DT =max TRADE_DT"; `EquityFactor]' %(int(date/10000),int(date%10000/100), date%100)
                #.gw.asyncexec["select from MinuteBar where date=2017.01.05,Symbol=`j1705,Category=1 ";`CTP]
        q.async(lsql)
        index = q.receive(pandas=True)
    index['code'] = index['CODE'].apply(lambda x:x.decode('utf-8').split('.')[0])
    index['symbol'] = index['SYMBOL'].apply(lambda x:x.decode('utf-8').split('.')[0])
    return index

def get_vs_position(v_id, settle_date, day_night='DAY'):
    sc = session()
    positions = sc.query(
        VsPosition
    ).filter(
        VsPosition.vstrategy_id == v_id,
        VsPosition.settle_date == settle_date,
        VsPosition.daynight == day_night,
    )
    res = {}
    for row in positions:
        res[row.symbol] = {
            'yest_long_pos': int(row.yest_long_pos),
            'yest_long_avg_price': float(row.yest_long_avg_price),
            'yest_short_pos': int(row.yest_short_pos),
            'yest_short_avg_price': float(row.yest_short_avg_price),
            'today_long_pos': int(row.today_long_pos),
            'today_long_avg_price': float(row.today_long_avg_price),
            'today_short_pos': int(row.today_short_pos),
            'today_short_avg_price': float(row.today_short_avg_price),
            'account': row.account,
            'symbol_pnl': float(row.symbol_pnl),
            'symbol_fee': float(row.symbol_fee),
        }
    sc.close()
    return res

def getStockRets(constitute, date):
    with qconnection.QConnection(host='192.168.10.102',port=9000,username='user1',password='password') as q:
        #sql =  ".gw.asyncexec[(`GetConditionsStockFactorData;`ADJFACTOR`ClosePrice`Volume;(`%s;`NUL);(%04d.%02d.%02d;%04d.%02d.%02d));`EquityFactor]" %(constitute,start_date/10000, start_date%10000/100, start_date%100,end_date/10000, end_date%10000/100, end_date%100 )
        sql =  '.gw.asyncexec["select SYMBOL,ret:S_DQ_PCTCHANGE from AShareEODPrices where TRADE_DT = %04d.%02d.%02d" ; `EquityFactor]' %(int(date/10000),int(date%10000/100), date%100)
        q.async(sql)
        all_stock =q.receive(pandas=True)
        #all_stock = all_stock.dropna()
        all_stock['symbol'] = [i.decode('utf-8').split('.')[0] for i in all_stock['SYMBOL'].tolist()]
        return all_stock


def get_live_log(v_id, settle_date, day_night='DAY'):
    settle_date = int(parse(str(settle_date)).strftime('%Y%m%d'))

    with qconnection.QConnection(host='192.168.10.102', port=9000, username='user1', password='password') as q:
        lsql = '.gw.asyncexec["select from AIndustryMembers where  TITLE=`SWS,LEVLE=1, S_CON_INDATE<=%04d.%02d.%02d,%04d.%02d.%02d<=S_CON_OUTDATE";`EquityFactor]' % (
            int(settle_date / 10000), \
            int(settle_date % 10000 / 100), settle_date % 100, int(settle_date / 10000), int(settle_date % 10000 / 100),
            settle_date % 100)
        q.async(lsql)
        industry = q.receive(pandas=True)
    industry['hy_code'] = industry['CODE'].apply(lambda x: x.decode('utf-8').split('.')[0])
    industry['symbol'] = industry['SYMBOL'].apply(lambda x: x.decode('utf-8').split('.')[0])

    with qconnection.QConnection(host='192.168.10.102', port=9000, username='user1', password='password') as q:
        lsql = '.gw.asyncexec["select from AIndustryMembers where  TITLE=`WINDCP,LEVLE=1, S_CON_INDATE<=%04d.%02d.%02d,%04d.%02d.%02d<=S_CON_OUTDATE";`EquityFactor]' % (
            int(settle_date / 10000), \
            int(settle_date % 10000 / 100), settle_date % 100, int(settle_date / 10000), int(settle_date % 10000 / 100),
            settle_date % 100)
        q.async(lsql)
        subject = q.receive(pandas=True)
    subject['zt_code'] = subject['CODE'].apply(lambda x: x.decode('utf-8').split('.')[0])
    subject['symbol'] = subject['SYMBOL'].apply(lambda x: x.decode('utf-8').split('.')[0])
    # keep first subject
    subject = subject.drop_duplicates('symbol')

    with qconnection.QConnection(host='192.168.10.102', port=9000, username='user1', password='password') as q:
        q.async(".gw.asyncexec[(`GetTradeDate;`SSE`SZSE;(2019.01.02;%04d.%02d.%02d;%d));`EquityFactor]"
                % (int(settle_date / 10000), int(settle_date % 10000 / 100), int(settle_date % 100), 0))
        trade_date = q.receive(pandas=True)
    pre_date = trade_date.loc[trade_date['TRADE_DT'] < settle_date].iloc[-1]['TRADE_DT']

    vs_pos = get_vs_position(v_id, settle_date, day_night)
    res_ls = []
    for sym, value in vs_pos.items():
        value['symbol'] = sym
        res_ls.append(value)
    aa = pd.DataFrame(res_ls, columns=['symbol', 'today_long_pos', 'today_long_avg_price', 'symbol_pnl'])

    vs_pos_p = get_vs_position(v_id, pre_date, day_night)
    vs_pos_p2 = get_vs_position(v_id, settle_date, 'NIGHT')
    for sym, s_d in vs_pos_p2.items():
        vs_pos_p[sym] = s_d
    res_ls_p = []
    for sym, value in vs_pos_p.items():
        value['symbol'] = sym
        res_ls_p.append(value)
    pre = pd.DataFrame(res_ls_p, columns=['symbol', 'today_long_pos', 'today_long_avg_price', 'symbol_pnl'])
    pre.columns = ['symbol', 'yest_long_pos', 'yest_long_avg_price', 'symbol_pnl']

    # 表1
    aa = aa.merge(pre[['symbol', 'yest_long_pos', 'yest_long_avg_price']], left_on='symbol', right_on='symbol',
                  how='left').fillna(0)
    aa['yest_weight'] = (aa['yest_long_pos'] * aa['yest_long_avg_price']) / (
        aa['yest_long_pos'] * aa['yest_long_avg_price']).sum()
    aa['today_weight'] = (aa['today_long_pos'] * aa['today_long_avg_price']) / (
        aa['today_long_pos'] * aa['today_long_avg_price']).sum()
    aa = aa.merge(industry[['symbol', 'hy_code']], left_on='symbol', right_on='symbol', how='left')
    aa = aa.merge(subject[['symbol', 'zt_code']], left_on='symbol', right_on='symbol', how='left')
    res_df1 = aa[['symbol', 'yest_long_pos', 'yest_weight', 'today_long_pos', 'today_weight', 'symbol_pnl', 'hy_code',
                  'zt_code']].sort_values('symbol')

    # 表2
    index_weight = get_index_weight(settle_date)
    index_weight['weight'] = index_weight['I_WEIGHT'] / 100
    index_weight_hy = index_weight[['symbol', 'weight']].merge(industry[['symbol', 'hy_code']], left_on='symbol',
                                                               right_on='symbol', how='left')
    hy_idx_weight = index_weight_hy.groupby('hy_code').sum()
    hy_idx_weight = hy_idx_weight.join(res_df1.groupby('hy_code')['today_weight'].sum()).fillna(0)
    hy_idx_weight['diff'] = hy_idx_weight['today_weight'] - hy_idx_weight['weight']
    hy_idx_weight = hy_idx_weight[['today_weight', 'weight', 'diff']]
    hy_idx_weight.columns = ['strategy_weight', 'bench_weight', 'diff']

    aa['rets'] = aa.apply(
        lambda x: x['symbol_pnl'] / (x['today_long_pos'] * x['today_long_avg_price']) if (x['today_long_pos'] * x[
            'today_long_avg_price']) > 0 else 0, axis=1
    )
    aa['rets_w'] = aa['rets'] * aa['today_weight']
    strategy_ret = (aa.groupby('hy_code')['rets_w'].sum() / aa.groupby('hy_code')['today_weight'].sum()).fillna(0)
    strategy_ret.name = 'strat_rets'
    stock_rets = getStockRets('hsa', settle_date)
    index_weight_hy_ret = index_weight_hy.merge(stock_rets[['symbol', 'ret']], left_on='symbol', right_on='symbol',
                                                how='left')
    index_weight_hy_ret['ret_w'] = index_weight_hy_ret['ret'] / 100 * index_weight_hy_ret['weight']
    hy_bench_ret = index_weight_hy_ret.groupby('hy_code')['ret_w'].sum() / index_weight_hy_ret.groupby('hy_code')[
        'weight'].sum()
    hy_bench_ret.name = 'hy_rets'
    res_df2 = hy_idx_weight.join(strategy_ret).fillna(0).join(hy_bench_ret).fillna(0).reset_index()
    res_df2['hy_code'] = res_df2['hy_code'].apply(lambda x: SW_IndustryCategory.get(x.lower(), x))

    res_df1['hy_code'] = res_df1['hy_code'].apply(lambda x: SW_IndustryCategory.get(x.lower(), x))
    res_df1['zt_code'] = res_df1['zt_code'].apply(lambda x: WD_IndustryCategory.get(str(x).lower(), x))

    res_df1['yest_weight'] = res_df1['yest_weight'].apply(lambda x: round(x, 6))
    res_df1['today_weight'] = res_df1['today_weight'].apply(lambda x: round(x, 6))
    res_df1['symbol_pnl'] = res_df1['symbol_pnl'].apply(lambda x: round(x, 2))
    res_df1 = res_df1.merge(aa[['symbol', 'rets']], how='left')
    res_df1 = res_df1.merge(res_df2[['hy_code', 'hy_rets']], how='left')
    res_df1['ret_diff'] = (res_df1['rets'] - res_df1['hy_rets']).apply(lambda x: round(x, 6))
    res_df1['rets'] = res_df1['rets'].apply(lambda x: round(x, 6))
    res_df1['hy_rets'] = res_df1['hy_rets'].apply(lambda x: round(x, 6))
    res_df1 = res_df1[['symbol', 'yest_long_pos', 'yest_weight', 'today_long_pos', 'today_weight', 'symbol_pnl', 'rets', 'hy_rets','ret_diff', 'hy_code', 'zt_code']]


    res_df2['strategy_weight'] = res_df2['strategy_weight'].apply(lambda x: round(x, 6))
    res_df2['bench_weight'] = res_df2['bench_weight'].apply(lambda x: round(x, 6))
    res_df2['diff'] = res_df2['diff'].apply(lambda x: round(x, 6))
    res_df2['strat_rets'] = res_df2['strat_rets'].apply(lambda x: round(x, 6))
    res_df2['hy_rets'] = res_df2['hy_rets'].apply(lambda x: round(x, 6))
    res_df2['ret_diff'] = (res_df2['strat_rets'] - res_df2['hy_rets']).apply(lambda x: round(x, 6))

    return res_df1, res_df2

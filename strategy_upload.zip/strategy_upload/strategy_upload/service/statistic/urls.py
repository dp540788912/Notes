# -*-coding:utf-8-*-


from service.statistic.handlers import *
from service.statistic.investment_portfolio_handlers import *

urls = [
    # 实盘绩效列表
    (r'/api/v1/platform/investment_performance/basic$', InvestmentPerformanceBasicHandler),
    (r'/api/v1/platform/investment_performance/new_realtime$', InvestmentPerformanceRTHandler),
    (r'/api/v1/platform/investment_performance/vs/pnl$', InvestmentPerformanceVsPnlHandler),

    (r'/api/v1/platform/investment/performance/base$', InvestmentPerformanceBaseHandler),
    (r'/api/v1/platform/investment/performance/realtime$', InvestmentPerformanceRealTimeHandler),
    (r'/api/v1/platform/investment/performance/detail$', InvestmentPerformanceDetailHandler),

    (r'/api/v1/platform/investment_performance/cache/clear', InvestmentPerformanceCacheClearHandler),
    (r'/api/v1/platform/investment_performance/group/basic/(?P<id>\w+)$', InvestmentPerformanceGroupBasicHandler),
    (r'/api/v1/platform/investment_performance/group/pnl/(?P<id>\w+)$', InvestmentPerformanceGroupPnlHandler),
    (r'/api/v1/platform/investment_performance/group/realtime/(?P<id>\w+)$', InvestmentPerformanceGroupRTHandler),
    (r'/api/v1/platform/investment/users', StrategyShareUsersHandler),
    (r'/api/v1/platform/investment/strategy_set$', NewStrategySetHandler),
    (r'/api/v1/platform/investment/vstrategy/share$', InvestmentVstrategyShareHandler),
    (r'/api/v1/platform/investment/vstrategy/share/batch$', InvestmentVstrategyShareBatchHandler),
    (r'/api/v1/platform/investment/vstrategy/share/cancel$', CancelInvestmentVstrategyShareHandler),
    (r'/api/v1/platform/investment/vstrategy/share/unsubscribe$', UnsubscribeInvestmentVstrategyShareHandler),
    (r'/api/v1/platform/investment/strategy_set/share$', InvestmentStrategySetShareHandler),
    (r'/api/v1/platform/investment/strategy_set/share/batch$', InvestmentStrategySetShareBatchHandler),
    (r'/api/v1/platform/investment/strategy_set/share/cancel$', CancelInvestmentStrategySetShareHandler),
    (r'/api/v1/platform/investment/share/status$', InvestmentShareStatusHandler),
    (r'/api/v1/platform/investment/strategy/metric', InvestmentStrategyMetricHandler),
    (r'/api/v1/platform/investment/vstrategy/position', InvestmentVstrategyPositionHandler),

    (r'/api/v1/platform/investment/market_volume/vstrategies$', MarketVolumeVstrategiesHandler),
    (r'/api/v1/platform/investment/market_volume/vstrategy/(?P<id>\d+)$', VsMarketVolumeHandler),
    (r'/api/v1/platform/investment/market_volume/vstrategy/daily/(?P<id>\d+)$', MarketVolumeVstrategyDailyHandler),

    (r'/api/v1/platform/statistic/performance/strategy$', StrategyPerformancenHandler),
    (r'/api/v1/platform/statistic/performance/strategy/indicators/(?P<id>\d+)$', StrategyPerformancenIdicatorsHandler),

    (r'/api/v1/platform/statistic/analysis/graph$', AnalysisGraphHandler),

    (r'/api/v1/platform/statistic/vs/backtest/operation/logs$', VsBackTestOperationLogsHandler),

    (r'/api/v1/platform/statistic/vstrategy/tradelogs$', VsTradingLogsHandler),
    (r'/api/v1/platform/statistic/vs/tradelogs$', VsTradingLogs2Handler),
    (r'/api/v1/platform/statistic/vstrategy/stock$', VsStockHandler),
    (r'/api/v1/platform/statistic/vstrategy/totalasset$', VsTotalAssetHandler),
    (r'/api/v1/platform/statistic/vstrategy/position/tradelogs/clear', GetVsPositionClearTradelogsHandler),

    (r'/api/v1/platform/statistic/investment/portfolio', AllInvestmentPortfolioHandler),
    (r'/api/v1/platform/statistic/investment/portfolio/performance/(?P<id>\d+)', InvestmentPortfolioPerformanceHandler),
    (r'/api/v1/platform/statistic/investment/portfolio/plan', AllInvestmentPortfolioPlanHandler),
    (r'/api/v1/platform/statistic/investment/portfolio/plan/(?P<id>\d+)', InvestmentPortfolioPlanDetailHandler),
    (r'/api/v1/platform/statistic/investment/portfolio/plan/calculate', InvestmentPortfolioPlanCalculateHandler),
    (r'/api/v1/platform/statistic/investment/portfolio/plan/default/(?P<id>\d+)',
     SetInvestmentPortfolioPlanDefaultHandler),

    (r'/api/v1/platform/statistic/live_analysis/basic$', LiveAnalysisPerformanceBasicHandler),
    (r'/api/v1/platform/statistic/live_analysis/realtime$', LiveAnalysisPerformanceRTHandler),
    (r'/api/v1/platform/statistic/live_analysis/vs/pnl$', LiveAnalysisPerformanceVsPnlHandler),

    # 获取/配置用户策略分析列表
    (r'/api/v1/platform/statistic/analysis/strategy$', AnalysisStrategyListHandler),

    # 股票风险模块，股票算法交易模块信息
    (r'/api/v1/platform/statistic/analysis/stock/backtestfactor$', AnalysisStockFactorHandler),

    # 获取t0/其他策略绩效
    (r'/api/v1/platform/statistic/performance/factor/strategy$', FactorStrategyPerformancenHandler),
    (r'/api/v1/platform/statistic/performance/factor/strategy/(?P<id>\d+)$', FactorStrategyPerformancenDetailHandler),
    (r'/api/v1/platform/statistic/portfolio/performance/$', StrategyPortfolioPerformancenHandler),  # 获取组合策略的绩效
    (r'/api/v1/platform/statistic/portfolio/correlation/$', StrategyPortfolioCorrelationHandler),  # 查看组合之间的相关性数据

    (r'/api/v1/platform/statistic/evaluation/strategy/(?P<id>\d+)$', StrategyEvaluationHandler),

    (r'/api/v1/platform/statistic/style_exposure/strategy/(?P<id>\d+)$', StrategyStyleExposureHandler),
    (r'/api/v1/platform/statistic/style_exposure/strategy/hy/(?P<id>\d+)$', StrategyHyStyleExposureHandler),
    (r'/api/v1/platform/statistic/style_exposure/portfolio$', StrategyPortfolioStyleExposureHandler),
    (r'/api/v1/platform/statistic/style_exposure/portfolio/hy$', StrategyPortfolioHyStyleExposureHandler),
    (r'/api/v1/platform/statistic/style_exposure/vs/portfolio$', StrategyVsPortfolioStyleExposureHandler),
    (r'/api/v1/platform/statistic/style_exposure/vs/portfolio/hy$', StrategyVsPortfolioHyStyleExposureHandler),
    (r'/api/v1/platform/statistic/income_attribution/strategy/(?P<id>\d+)$', StrategyIncomeAttributionHandler),
    (r'/api/v1/platform/statistic/income_attribution/strategy/hy/(?P<id>\d+)$', StrategyIncomeHyAttributionHandler),
    (r'/api/v1/platform/statistic/attr_attribution/strategy/(?P<id>\d+)$', StrategyRiskAttributionHandler),
    (r'/api/v1/platform/statistic/attr_attribution/portfolio$', PortfolioRiskAttributionHandler),
    (r'/api/v1/platform/statistic/attr_attribution/vs/portfolio$', VsPortfolioRiskAttributionHandler),
    (r'/api/v1/platform/statistic/stock/portfolio_optimization$', StockPortfolioOptimizationHandler),

    (r'/api/v1/platform/statistic/stock/portfolio_optimization/(?P<id>\d+)$', StockPortfolioOptimizationDetailHandler),

    (r'/api/v1/platform/statistic/trading/product$', TradingProductHandler),

    # 策略回测重做接口
    (r'/api/v1/platform/statistic/strategy/backtest/(?P<id>\d+)$', StrategyBackTestRedoHandler),

    (r'/api/v1/platform/statistic/stock/factor_return$', StockFactorReturnHandler),

    (r'/api/v1/platform/statistic/stock/vs/trading_volume_ratio/(?P<id>\d+)$', VsTradingVolumeRatioHandler),
    (r'/api/v1/platform/statistic/stock/strategy/trading_volume_ratio/(?P<id>\d+)$', StrategyTradingVolumeRatioHandler),
    (r'/api/v1/platform/statistic/stock/vs_back_test/trading_volume_ratio/(?P<id>\d+)$',
     VsBackTestTradingVolumeRatioHandler),

    (r'/api/v1/platform/statistic/stock/vs/trading_volume_ratio/daily/(?P<id>\d+)$', VsTradingVolumeRatioDailyHandler),
    (r'/api/v1/platform/statistic/stock/strategy/trading_volume_ratio/daily/(?P<id>\d+)$',
     StrategyTradingVolumeRatioDailyHandler),
    (r'/api/v1/platform/statistic/stock/vs_back_test/trading_volume_ratio/daily/(?P<id>\d+)$',
     VsBackTestTradingVolumeRatioDailyHandler),

    (r'/api/v1/platform/statistic/stock/vs/diff/(?P<id>\d+)$', StockVsDiffHandler),

    (r'/api/v1/platform/statistic/stock/vs/live/log/(?P<id>\d+)$', StockLiveLogHandler),

    (r'/api/v1/platform/statistic/future/risk$', FutureRiskHandler),

    (r'/api/v1/platform/statistic/performance/vs/live/indicators$', VsLiveIdicatorsHandler),

    (r'/api/v1/platform/statistic/strategy$', GetMyStrategyHandler),
    (r'/api/v1/platform/statistic/strategy/(?P<id>\d+)$', GetMyStrategyDetailHandler),

    (r'/api/v1/platform/statistic/strategy/log/error/(?P<id>\d+)$', StrategyBackTestErrorLogHandler),

    (r'/api/v1/platform/statistic/stock/indicators/(?P<id>\d+)$', StockIndicatorsHandler),

    # 获取所有股票Alpha类型的策略
    (r'/api/v1/platform/statistic/stock/alpha/strategy$', GetStockAlphaStrategyHandler),

    (r'/api/v1/platform/statistic/stock/portfolio/trading_volume_ratio$', StrategyPortfolioTradingVolumeRatioHandler),
    (r'/api/v1/platform/statistic/stock/portfolio/daily/trading_volume_ratio$',
     StrategyPortfolioDailyTradingVolumeRatioHandler),

    (r'/api/v1/platform/statistic/vs/back_test/dep/check/(?P<id>\d+)$', VsBackTestDepCheckHandler),
    (r'/api/v1/platform/statistic/vs/back_test/error/log/(?P<id>\d+)$', VsBackTestLogHandler),
    (r'/api/v1/platform/statistic/strategy/back_test/dep/check/(?P<id>\d+)$', StrategyBackTestDepCheckHandler),
    (r'/api/v1/platform/statistic/vs/back_test/events/track/(?P<id>\d+)$', VsBackTestEventTrackingHandler),

    (r'/api/v1/platform/statistic/strategy/doc/(?P<id>\d+)$', SetStrategyDocHandler),

    (r'/api/v1/platform/statistic/future/live/trading_volume_ratio$', FutureTradingVolumeRatioHandler),

    # 获取股票Master配置策略，设置股票Master交易策略
    (r'/api/v1/platform/statistic/stock/master/strategy$', GetStockMasterStrategyHandler),

    # 联合模拟回测接口
    (r'/api/v1/platform/statistic/stock/union_simulation', UnionSimuStrategyHandler),
    # 删除了联合模拟策略
    (r'/api/v1/platform/statistic/stock/union_simulation/(?P<id>\d+)$', UnionSimuStrategyHandler),
    # 联合策略绩效
    (r'/api/v1/platform/statistic/union_simulation/performance/(?P<id>\d+)$', UnionSimuStrategyPerformancenHandler)
]

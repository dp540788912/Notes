# -*-coding:utf-8-*-

import os
import shutil
import datetime
from dateutil.parser import parse

import pandas as pd
from service.back_test.models import Strategy, BackTestTradeLogs
from service.statistic.models import StrategyBackTestTradeIndicator
from kdb_query import KdbQuery
from extensions import sentry

from db import session, engine
from config import config

import consts


def tradelogs2dataframe(s_id, trading_date, filepath='', redo=False, **kwargs):
    strategy_type = kwargs.get('strategy_type', '')
    if not filepath:
        sc = session()
        s = sc.query(
            Strategy.id.label('id'),
            Strategy.username.label('username'),
            Strategy.start_date.label('start_date'),
            Strategy.st_uuid.label('st_uuid'),
            Strategy.strategy_type.label('strategy_type'),
        ).filter(
            Strategy.id == s_id
        ).first()
        filepath = os.path.join(
            config.media,
            'strategy_back_test_logs',
            s.username,
            str(s.id),
            s.st_uuid,
        )
        strategy_type = s.strategy_type
        sc.close()
        if not os.path.exists(filepath):
            os.makedirs(filepath)

    csv_file = os.path.join(filepath, '%s.pkl' % trading_date)
    if os.path.exists(csv_file):
        if redo:
            os.remove(csv_file)
        else:
            return True
    sql = """select * from backtest_trade_logs where strategy_id={s_id} and trading_date='{t_date}'""".format(
        s_id=s_id,
        t_date=trading_date,
    )
    df = pd.read_sql_query(sql, engine)
    if df.empty and (not redo):
        return True
    df.to_pickle(csv_file)
    if strategy_type in consts.stock_strategy_type:
        try:
            StrategyBackTestTradeIndicator.cal_daily_ind(s_id, trading_date)
        except Exception as e:
            sentry.captureException()
        sc = session()
        try:
            sc.query(
                BackTestTradeLogs
            ).filter(
                BackTestTradeLogs.strategy_id == s_id,
                BackTestTradeLogs.trading_date == trading_date
            ).delete(synchronize_session=False)
            sc.commit()
        except Exception as e:
            sentry.captureException()
        sc.close()
    return True


def convert_strategy_backtest_tradelogs(s_id, redo=False):
    sc = session()
    s = sc.query(
        Strategy.id.label('id'),
        Strategy.username.label('username'),
        Strategy.start_date.label('start_date'),
        Strategy.st_uuid.label('st_uuid'),
        Strategy.strategy_type.label('strategy_type'),
    ).filter(
        Strategy.id == s_id
    ).first()
    filepath = os.path.join(
        config.media,
        'strategy_back_test_logs',
        s.username,
        str(s.id),
        s.st_uuid,
    )
    if not os.path.exists(filepath):
        os.makedirs(filepath)
    s_start_date = parse(s.start_date).strftime('%Y.%m.%d')
    s_type = s.strategy_type
    sc.close()
    kdb = KdbQuery()
    dates = kdb.get_trading_days(s_start_date, datetime.datetime.now().strftime('%Y%m%d'))
    for d in dates:
        try:
            tradelogs2dataframe(s_id, d, filepath=filepath, redo=redo, strategy_type=s_type)
        except Exception as e:
            sentry.captureException()
    return True
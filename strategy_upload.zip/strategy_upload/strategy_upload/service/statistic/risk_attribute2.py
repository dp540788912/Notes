# -*-coding:utf-8-*-

import pandas as pd
import numpy as np
import datetime
import requests
import json
from dateutil.parser import parse

from qpython import qconnection
addr, port, user, pwd = "192.168.10.102", 9000, "user1", "password"

def getConstituteStocks(constitute, start_date, end_date):
    with qconnection.QConnection(host=addr,port=port,username=user,password=pwd) as q:
        #sql =  ".gw.asyncexec[(`GetConditionsStockFactorData;`ADJFACTOR`ClosePrice`Volume;(`%s;`NUL);(%04d.%02d.%02d;%04d.%02d.%02d));`EquityFactor]" %(constitute,start_date/10000, start_date%10000/100, start_date%100,end_date/10000, end_date%10000/100, end_date%100 )
        sql =  ".gw.asyncexec[(`GetConditionsStockFactorData;`Volume;(`%s;`NUL);(%04d.%02d.%02d;%04d.%02d.%02d));`EquityFactor]" %(constitute,start_date/10000, start_date%10000/100, start_date%100,end_date/10000, end_date%10000/100, end_date%100 )
        q.async(sql)
        all_stock =q.receive(pandas=True)
        all_stock = all_stock.dropna()
        all_stock['Date'] = all_stock['TRADE_DT'].apply(lambda row: row.year * 10000 + row.month * 100 + row.day)
        all_stock['TradeStatus'] = all_stock['TradeStatus'].apply(lambda s: str(s, 'utf-8'))
        all_stock['Symbol'] = [i.decode('utf-8').split('.')[0] for i in all_stock['SYMBOL'].tolist()]
        return all_stock[['Date','Symbol','TradeStatus','Volume']]

def getConstituteStocksFloat(constitute, start_date, end_date):
    with qconnection.QConnection(host=addr,port=port,username=user,password=pwd) as q:
        #sql =  ".gw.asyncexec[(`GetConditionsStockFactorData;`ADJFACTOR`ClosePrice`Volume;(`%s;`NUL);(%04d.%02d.%02d;%04d.%02d.%02d));`EquityFactor]" %(constitute,start_date/10000, start_date%10000/100, start_date%100,end_date/10000, end_date%10000/100, end_date%100 )
        sql =  ".gw.asyncexec[(`GetConditionsStockFactorData;`ClosePrice`FloatShare`TolShare;(`%s;`NUL);(%04d.%02d.%02d;%04d.%02d.%02d));`EquityFactor]" %(constitute,start_date/10000, start_date%10000/100, start_date%100,end_date/10000, end_date%10000/100, end_date%100 )
        q.async(sql)
        all_stock =q.receive(pandas=True)
        all_stock = all_stock.dropna()
        all_stock['Date'] = all_stock['TRADE_DT'].apply(lambda row: row.year * 10000 + row.month * 100 + row.day)
        all_stock['Symbol'] = [i.decode('utf-8').split('.')[0] for i in all_stock['SYMBOL'].tolist()]
        return all_stock[['Date','Symbol','ClosePrice','FloatShare','TolShare']]


def get_index_weight(date):
    with qconnection.QConnection(host='192.168.10.102',port=9000,username='user1',password='password') as q:
        lsql = '.gw.asyncexec["select from AIndexFreeWeight where CODE=`000905.SH, TRADE_DT<=%04d.%02d.%02d,TRADE_DT =max TRADE_DT"; `EquityFactor]' %(int(date/10000),int(date%10000/100), date%100)
                #.gw.asyncexec["select from MinuteBar where date=2017.01.05,Symbol=`j1705,Category=1 ";`CTP]
        q.async(lsql)
        index = q.receive(pandas=True)
    index['code'] = index['CODE'].apply(lambda x:x.decode('utf-8').split('.')[0])
    index['symbol'] = index['SYMBOL'].apply(lambda x:x.decode('utf-8').split('.')[0])
    return index



def risk_attribute2(position_df, top_n_sum_weight=20, float_value_limit=14, **kwargs):
    output_result = pd.DataFrame()

    allres_df = position_df
    allres_df['trading_date'] = allres_df['trading_date'].apply(lambda x: int(x))
    month_start_date = position_df['trading_date'].min()
    month_end_date = position_df['trading_date'].max()

    # industry
    with qconnection.QConnection(host='192.168.10.102', port=9000, username='user1', password='password') as q:
        lsql = '.gw.asyncexec["select from AIndustryMembers where  TITLE=`SWS,LEVLE=1, S_CON_INDATE<=%04d.%02d.%02d,%04d.%02d.%02d<=S_CON_OUTDATE";`EquityFactor]' % (
        int(month_end_date / 10000), \
        int(month_end_date % 10000 / 100), month_end_date % 100, int(month_end_date / 10000),
        int(month_end_date % 10000 / 100), month_end_date % 100)
        q.async(lsql)
        industry = q.receive(pandas=True)
    industry['hy_code'] = industry['CODE'].apply(lambda x: x.decode('utf-8').split('.')[0])
    industry['symbol'] = industry['SYMBOL'].apply(lambda x: x.decode('utf-8').split('.')[0])

    # Suspended value
    allstock = getConstituteStocks('HSA', month_start_date, month_end_date)
    allres_df1 = allres_df.merge(allstock,left_on = ['trading_date','symbol'],right_on = ['Date','Symbol'],how = 'left')
    total_value_by_date = pd.DataFrame(allres_df1.groupby('trading_date').apply(lambda x : (x['long_volume']*x['long_price']).sum()),columns =['value']).reset_index()
    Suspend_by_date = pd.DataFrame(allres_df1.loc[allres_df1['TradeStatus'] == 'SUSPENDED'].groupby('trading_date').apply(lambda x : (x['long_volume']*x['long_price']).sum()),columns =['s_value']).reset_index()
    suspends_ratio_df = total_value_by_date.merge(Suspend_by_date,on = ['trading_date'])
    suspends_ratio_df['s_ratio'] = suspends_ratio_df['s_value']/suspends_ratio_df['value']

    #non csi800 max
    csi300_df = getConstituteStocks('HS300',month_start_date, month_end_date)
    csi500_df = getConstituteStocks('ZZ500',month_start_date, month_end_date)
    allres_df_csi800 = allres_df.merge(csi300_df.append(csi500_df),left_on = ['trading_date','symbol'],right_on = ['Date','Symbol'],how = 'left')
    noncsi800_max_by_date = allres_df_csi800.loc[allres_df_csi800['TradeStatus'].isnull()].groupby('trading_date').apply(lambda x : (x['long_volume']*x['long_price']).max())
    noncsi800_max_by_date= pd.DataFrame(noncsi800_max_by_date,columns = ['noncsi800_max']).reset_index().merge(total_value_by_date)
    noncsi800_max_by_date['non800_max_w'] = noncsi800_max_by_date['noncsi800_max'] / noncsi800_max_by_date['value']
    csi800_max_by_date = allres_df_csi800.loc[~allres_df_csi800['TradeStatus'].isnull()].groupby('trading_date').apply(lambda x : (x['long_volume']*x['long_price']).max())
    csi800_max_by_date= pd.DataFrame(csi800_max_by_date,columns = ['csi800_max']).reset_index().merge(total_value_by_date)
    csi800_max_by_date['max_w_800'] = csi800_max_by_date['csi800_max'] / csi800_max_by_date['value']

    #non csi800 sum
    allres_df300 = allres_df.merge(csi300_df,left_on = ['trading_date','symbol'],right_on = ['Date','Symbol'],how = 'left').dropna()
    allres_df500 = allres_df.merge(csi500_df,left_on = ['trading_date','symbol'],right_on = ['Date','Symbol'],how = 'left').dropna()
    csi300_by_date = pd.DataFrame(allres_df300.groupby('trading_date').apply(lambda x : (x['long_volume']*x['long_price']).sum()),columns = ['300_value']).reset_index()
    csi500_by_date = pd.DataFrame(allres_df500.groupby('trading_date').apply(lambda x : (x['long_volume']*x['long_price']).sum()),columns = ['500_value']).reset_index()
    csi800_by_date = csi300_by_date.merge(csi500_by_date)
    csi800_by_date['800_value'] = csi800_by_date['300_value']+csi800_by_date['500_value']
    csi800_by_date = csi800_by_date.merge(total_value_by_date)
    csi800_by_date['non800_ratio'] = 1-csi800_by_date['800_value']/csi800_by_date['value']

    #startups
    startup_df = allres_df.loc[allres_df['symbol'].apply(lambda x: True if x[0] == '3' else False)]
    startup_value_by_date = pd.DataFrame(startup_df.groupby('trading_date').apply(lambda x : (x['long_volume']*x['long_price']).sum()),columns = ['start_value']).reset_index()
    startup_value_by_date = startup_value_by_date.merge(total_value_by_date)
    startup_value_by_date['startup_w'] = startup_value_by_date['start_value'] / startup_value_by_date['value']

    # Float share mkt value
    allstock_float = getConstituteStocksFloat('HSA',month_start_date, month_end_date)
    allstock_float['FloatValue'] = allstock_float['ClosePrice'] * allstock_float['FloatShare'] / 10000
    allstock_float['TolValue'] = allstock_float['ClosePrice'] * allstock_float['TolShare'] / 10000
    floatvalue_df = allres_df.merge(allstock_float,left_on = ['trading_date','symbol'],right_on = ['Date','Symbol'],how = 'left')
    floatvalue_by_date1 = floatvalue_df.groupby('trading_date')[['TolValue','FloatValue']].apply(min).reset_index()
    floatvalue_by_date1 = floatvalue_by_date1.merge(total_value_by_date)
    floatvalue_by_date = pd.DataFrame(floatvalue_df.loc[floatvalue_df['FloatValue']<float_value_limit].groupby('trading_date').apply(lambda x : (x['long_volume']*x['long_price']).sum()), columns = ['FVbelow14']).reset_index()
    floatvalue_by_date = floatvalue_by_date.merge(total_value_by_date)
    floatvalue_by_date['FVbelow14_w'] = floatvalue_by_date['FVbelow14'] / floatvalue_by_date['value']

    # max weight for top 30 non-CSI names
    noncsi800_top30_max_by_date = allres_df_csi800.loc[allres_df_csi800['TradeStatus'].isnull()].groupby('trading_date').apply(lambda x : (x['long_volume']*x['long_price']).max())
    noncsi800_top30_max_by_date= pd.DataFrame(noncsi800_top30_max_by_date,columns = ['noncsi800_top30_max']).reset_index().merge(total_value_by_date)
    noncsi800_top30_max_by_date['non800_top30_max_w'] = noncsi800_top30_max_by_date['noncsi800_top30_max'] / noncsi800_top30_max_by_date['value']

    # max weight for non-top 30 non-CSI names
    noncsi800_nontop30_max_by_date = allres_df_csi800.loc[allres_df_csi800['TradeStatus'].isnull()].groupby('trading_date').apply(lambda x : (x['long_volume']*x['long_price']).nlargest(31).tail(1).values[0])
    noncsi800_nontop30_max_by_date= pd.DataFrame(noncsi800_nontop30_max_by_date,columns = ['noncsi800_nontop30_max']).reset_index().merge(total_value_by_date)
    noncsi800_nontop30_max_by_date['noncsi800_nontop30_max_w'] = noncsi800_nontop30_max_by_date['noncsi800_nontop30_max'] / noncsi800_nontop30_max_by_date['value']

    # top 20 aggregate exposure
    top_20_by_date = allres_df.groupby('trading_date').apply(lambda x : (x['long_volume']*x['long_price']).nlargest(top_n_sum_weight).sum())
    top_20_by_date= pd.DataFrame(top_20_by_date,columns = ['top20_value']).reset_index().merge(total_value_by_date)
    top_20_by_date['top20_value_w'] = top_20_by_date['top20_value'] / top_20_by_date['value']

    # industry max weight
    industry_df = allres_df.merge(industry[['symbol', 'hy_code']], left_on='symbol', right_on='symbol', how='left')
    industry_df['value'] = industry_df['long_volume'] * industry_df['long_price']
    industry_max_by_date = industry_df.groupby('trading_date').apply(
        lambda x: x.groupby('hy_code')['value'].sum().max())
    industry_max_by_date = pd.DataFrame(industry_max_by_date, columns=['industry_max']).reset_index().merge(
        total_value_by_date)
    industry_max_by_date['industry_max_w'] = industry_max_by_date['industry_max'] / industry_max_by_date['value']

    month_result = total_value_by_date.merge(csi800_max_by_date, how='left').merge(noncsi800_max_by_date, how='left').merge(
        csi800_by_date, how='left').merge(startup_value_by_date, how='left').merge(
        floatvalue_by_date, how='left').merge(floatvalue_by_date1, how='left').merge(noncsi800_top30_max_by_date,
                                                                                     how='left').merge(
        noncsi800_nontop30_max_by_date, how='left').merge(top_20_by_date,
                                                          how='left').merge(industry_max_by_date, how='left').fillna(0)[
        ['trading_date', 'max_w_800', 'non800_max_w', 'non800_ratio', 'startup_w', 'FVbelow14_w', 'TolValue',
         'FloatValue', 'non800_top30_max_w', 'noncsi800_nontop30_max_w', 'top20_value_w', 'industry_max_w']]

    if output_result.empty:
        output_result = month_result
    else:
        output_result = output_result.append(month_result, ignore_index=True)
    return output_result

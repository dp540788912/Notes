# -*-coding:utf-8-*-

import time
import requests
import json
from tornado import gen
from tornado import httpclient

import consts
from kdb_query import KdbQuery
from config import config
from extensions import sentry
from utils import set_cache, get_cache


class ServiceBaseService(object):
    _futures_basic_info = {}
    _futures_feerate = {}
    _foreign_futures_basic_info = {}
    _foreign_futures_feerate = {}
    _futures_simu_feerate = {}

    def __init__(self, *args, **kwargs):
        self.kdb = KdbQuery()

    def get_live_quote(self):
        url = 'http://%s/%s' % (config.quote_api_host, config.quote_api_url)
        try:
            quote_data = requests.get(url).json()['data']
        except Exception as e:
            sentry.captureException()
            self.quote_data = {}
            return {}
        self.quote_data = quote_data
        return quote_data

    @gen.coroutine
    def async_get_live_quote(self):
        url = 'http://%s/%s' % (config.quote_api_host, config.quote_api_url)
        try:
            http_client = httpclient.AsyncHTTPClient()
            response = yield gen.Task(http_client.fetch, url)
            quote_data = json.loads(str(response.body, 'utf-8'))['data']
        except Exception as e:
            sentry.captureException()
            self.quote_data = {}
            return {}
        self.quote_data = quote_data
        return quote_data

    def cal_fee(self, data):
        symbol = data['symbol']
        currency = data['currency']
        if currency.upper() not in ('CNY', 'CNH'):
            return self.foreign_future_fee(data)

        if symbol.isdigit():
            return self.stock_fee(data)

        if symbol in ('H00905', 'h00905'):
            return self.get_h00905_fee(data)

        return self.future_fee(data)

    def get_h00905_fee(self, data):
        if data['open_close'] == 0:
            fee = 0.00155
        else:
            fee = 0.00055
        return data['turnover'] * fee

    def stock_fee(self, data):
        symbol = data['symbol']
        d_flag = data['direction']
        exchange_fee = 0
        broker_fee = 0.00012
        acc_transfer_fee = 0
        if symbol[:2] == '60':
            acc_transfer_fee = 0.00002

        if data.get('is_hk_stock'):
            broker_fee = 0.00025
            acc_transfer_fee = 0

        stamp_tax = 0
        if d_flag == consts.Direction.sell.value:
            stamp_tax = 0.001
        feerate = exchange_fee + broker_fee + acc_transfer_fee + stamp_tax
        return data['turnover'] * feerate

    def future_fee(self, data):
        symbol = data['symbol']
        try:
            product = self.futures_basic_info[symbol.lower()]['product']
            fee_info_d = self.future_fee_data[product]
        except Exception as e:
            sentry.captureException()
            return 0
        if fee_info_d['FeeMode']:
            _charge = data['volume'] * fee_info_d.get('MyIntraSimuFee', 0) * data['trade_unit']
        else:
            _charge = data['turnover'] * fee_info_d.get('MyIntraSimuFee', 0)
        return _charge

    def foreign_future_fee(self, data):
        symbol = data['symbol']
        try:
            f_s_d = self.foreign_futures_basic_info[symbol.lower()]
            _k = '%s@%s' % (f_s_d['product'], f_s_d['exchange'])
            fee_info_d = self.foreign_futures_feerate[_k]
        except Exception as e:
            fee_info_d = {}
        fee_rate = fee_info_d.get('ExchIntraOpenFee', 0)
        if data['open_close'] == 0:  # open position
            fee_rate = fee_info_d.get('ExchInterOpenFee', 0)
        if data['open_close'] >= 1:
            fee_rate = fee_info_d.get('ExchIntraCloseFee', 0)
            open_close_flg = data['open_close']
            if open_close_flg == 3 or open_close_flg == 4:
                fee_rate = fee_info_d.get('ExchInterCloseFee', 0)
        _charge = data['turnover'] * fee_rate  # by turnover
        if fee_info_d['FeeMode']:  # by vol
            _charge = data['volume'] * fee_rate
        if data['open_close'] == 0:
            _charge *= (1 + fee_info_d.get('MyBrokerOpenFee', 0))
        else:
            _charge *= (1 + fee_info_d.get('MyBrokerCloseFee', 0))
        _charge = _charge * data['exchange_rate']
        return _charge

    def get_symbol_trade_unit(self, symbol, currency='CNY'):
        # 兼容股指
        if symbol.isdigit() or (symbol in ('H00905', 'h00905', '000905.SH', '000905.sh')):
            return 1

        if currency.upper() in ('CNY', 'CNH'):
            pp = self.futures_basic_info.get(symbol.lower())
            if pp:
                return pp['contractmultiplier']
        else:
            pp = self.foreign_futures_basic_info.get(symbol.lower())
            if pp:
                key = '%s@%s' % (pp['product'], pp['exchange'])
                fee_data = self.foreign_futures_feerate.get(key)
                if fee_data:
                    return fee_data['TradeUnit']
        sentry.captureMessage('can not find trade unit symbol=%s, currency=%s' % (symbol, currency))
        return 1

    def get_exchange_rate(self, currency):
        currency = currency.upper()
        if currency not in ('CNY', 'CNH'):
            currency_key = '%s.CNHCNH-IDEALPRO' % currency
            if currency_key in self.quote_data:
                return self.quote_data[currency_key].get('LastPrice', 0) or 1
            else:
                currency_key = 'CNH%s-IDEALPRO' % currency
                if currency_key in self.quote_data:
                    return 1 / (self.quote_data[currency_key].get('LastPrice', 0) or 1)
        return 1

    def get_futures_info(self):
        if (time.time() - self._futures_basic_info.get('time', 0)) < 86400:
            return self._futures_basic_info
        data = self.kdb.get_futures_info()
        data['time'] = time.time()
        self._futures_basic_info.update(data)
        return data

    @property
    def futures_basic_info(self):
        return self.get_futures_info()

    def get_future_fee_data(self):
        if (time.time() - self._futures_feerate.get('time', 0)) < 86400:
            return self._futures_feerate
        data = self.kdb.get_future_fee_data()
        data['time'] = time.time()
        self._futures_feerate.update(data)
        return data

    @property
    def future_fee_data(self):
        return self.get_future_fee_data()

    def get_foreign_futures_info(self):
        if (time.time() - self._foreign_futures_basic_info.get('time', 0)) < 86400:
            return self._foreign_futures_basic_info
        data = self.kdb.get_foreign_symbols()
        data['time'] = time.time()
        self._foreign_futures_basic_info.update(data)
        return data

    @property
    def foreign_futures_basic_info(self):
        return self.get_foreign_futures_info()

    def get_foreign_future_fee_data(self):
        if (time.time() - self._foreign_futures_feerate.get('time', 0)) < 86400:
            return self._foreign_futures_feerate
        data = self.kdb.get_foreign_symbols_feerate()
        data['time'] = time.time()
        self._foreign_futures_feerate.update(data)
        return data

    @property
    def foreign_futures_feerate(self):
        return self.get_foreign_future_fee_data()

    def get_future_simu_fee_data(self):
        if (time.time() - self._futures_simu_feerate.get('time', 0)) < 86400:
            return self._futures_simu_feerate
        data = self.kdb.get_future_simu_fee_data()
        data['time'] = time.time()
        self._futures_simu_feerate.update(data)
        return data

    @property
    def future_simu_fee_data(self):
        return self.get_future_simu_fee_data()

    def get_symbol_simu_fee(self, symbol, trade_unit, total_trade_vol, total_trade_amount, fee_rate=None):
        try:
            # if option symbol, product = CP50ETF
            if symbol.isdigit():
                product = 'CP50ETF'
            else:
                product = self.futures_basic_info[symbol.lower()]['product']
            fee_info_d = self.future_simu_fee_data[product]
        except Exception as e:
            sentry.captureException()
            return 0
        if fee_rate is None:
            if fee_info_d['FeeMode']:
                _charge = total_trade_vol * fee_info_d.get('SimuFee', 0) * trade_unit
            else:
                _charge = total_trade_amount * fee_info_d.get('SimuFee', 0) * trade_unit
        else:
            if fee_info_d['FeeMode']:
                _charge = total_trade_vol * fee_rate * trade_unit
            else:
                _charge = total_trade_amount * fee_rate * trade_unit
        return _charge

    def get_h00905_last_price(self):
        key = 'h00905_close_price_base'
        base_price = get_cache(key)
        if not base_price:
            base_price = self.kdb.get_index_settle_price()
            set_cache(key, base_price, 3600)
        price = base_price['h00905.CSI'] * self.quote_data['000905.SH']['LastPrice'] / base_price['000905.SH'] / 10000
        return price

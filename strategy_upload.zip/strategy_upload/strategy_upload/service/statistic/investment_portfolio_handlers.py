# -*-coding:utf-8-*-

import os
import base64
import json
import datetime
import pandas as pd
from tornado import gen
from sqlalchemy import or_, distinct, func
from dateutil.parser import parse

from config import config
import consts

from service.basehandler import BaseHandler, CurrentUserMixin, JsonPayloadMixin, DownloadMixin

from service.statistic.models import InvestmentPortfolio, InvestmentPortfolioPlan, \
    InvestmentPortfolioPlanEntry, DefaultInvestmentPortfolioPlan, \
    InvestmentPortfolioPerformance, InvestmentPortfolioPerformanceDaily

from db import session

class AllInvestmentPortfolioHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        data = InvestmentPortfolio.get_all_portfolio()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class InvestmentPortfolioPerformanceHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        p_id = int(kwargs['id'])
        data = InvestmentPortfolioPerformance.get_portfolio_performance_by_id(p_id, **kwargs)
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True

class AllInvestmentPortfolioPlanHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        data = InvestmentPortfolioPlan.get_all_portfolio(self.current_user)
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        pay_load = self.get_payload()
        sc = session()
        if pay_load.get('id') is not None:
            p = sc.query(
                InvestmentPortfolioPlan
            ).filter(
                InvestmentPortfolioPlan.id == pay_load['id']
            ).first()
            sc.query(
                InvestmentPortfolioPlanEntry
            ).filter(
                InvestmentPortfolioPlanEntry.investment_portfolio_plan_id == p.id
            ).delete()
            if pay_load.get('portfolio_name'):
                p.portfolio_name = pay_load['portfolio_name']
        else:
            p = sc.query(InvestmentPortfolioPlan).filter(
                InvestmentPortfolioPlan.portfolio_name == pay_load['portfolio_name']
            ).first()
            if p:
                sc.close()
                self.json_response({
                    'code': 3001,
                    'data': '新建组合错误:组合名称已存在，请修改',
                    'error': '新建组合错误:组合名称已存在，请修改',
                })
                return False
            p = InvestmentPortfolioPlan(
                portfolio_name=pay_load['portfolio_name'],
                cash=0,
                leverage=0,
                r_create_user_id=self.current_user['id']
            )
            sc.add(p)
            sc.flush()
        cash, sum_cash, leverage = 0, 0, 0
        for en in pay_load['entries']:
            entry = InvestmentPortfolioPlanEntry(
                investment_portfolio_plan_id=p.id,
                investment_portfolio_id=en['id'],
                cash=float(en['cash']),
                leverage=float(en['leverage']),
            )
            cash += float(en['cash'])
            sum_cash += float(en['cash']) * float(en['leverage'])
            sc.add(entry)
        p.cash = cash
        p.leverage = cash and round(sum_cash / cash, 3) or 1
        p_id = p.id
        sc.commit()
        sc.close()
        InvestmentPortfolioPlan.update_performance(p_id, pay_load)

        data = InvestmentPortfolioPlan.get_portfolio_plan_summary_by_id(p_id)

        self.json_response({
            'code': 0,
            'data': data,
        })
        return True




class InvestmentPortfolioPlanDetailHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        p_id = int(kwargs['id'])
        data = InvestmentPortfolioPlan.get_portfolio_plan_by_id(p_id, **kwargs)
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True

    @gen.coroutine
    def delete(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        p_id = int(kwargs['id'])
        sc = session()
        sc.query(InvestmentPortfolioPlan).filter(
            InvestmentPortfolioPlan.id == p_id
        ).delete()
        sc.query(InvestmentPortfolioPlanEntry).filter(
            InvestmentPortfolioPlanEntry.investment_portfolio_plan_id == p_id
        ).delete()
        sc.commit()
        sc.close()
        self.json_response({
            'code': 0,
            'data': {},
        })
        return True


class SetInvestmentPortfolioPlanDefaultHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        p_id = int(kwargs['id'])
        sc = session()
        d = sc.query(DefaultInvestmentPortfolioPlan).filter(
            DefaultInvestmentPortfolioPlan.r_create_user_id == self.current_user['id']
        ).first()
        if d:
            d.investment_portfolio_plan_id = p_id
        else:
            d = DefaultInvestmentPortfolioPlan(
                investment_portfolio_plan_id=p_id,
                r_create_user_id=self.current_user['id'],
            )
            sc.add(d)
        sc.commit()
        sc.close()
        self.json_response({
            'code': 0,
            'data': {},
        })
        return True

class InvestmentPortfolioPlanCalculateHandler(JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):

        pay_load = self.get_payload()

        data = InvestmentPortfolioPlan.calculate_performance(pay_load)

        self.json_response({
            'code': 0,
            'data': data,
        })
        return True
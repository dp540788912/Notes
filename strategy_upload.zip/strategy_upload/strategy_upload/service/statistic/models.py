# -*-coding:utf-8-*-


import uuid
import os
import datetime
import copy

import matplotlib

matplotlib.use('Agg')

import matplotlib.pyplot as plt

import math
import pandas as pd
import numpy as np
from dateutil.parser import parse
from sqlalchemy import or_, and_
from sqlalchemy import distinct
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from sqlalchemy import Column, ForeignKey, UniqueConstraint
from sqlalchemy.dialects.mysql import BIGINT, VARCHAR, FLOAT, BOOLEAN, DATETIME, INTEGER, JSON, DOUBLE, TEXT, DATE, TIME
from sqlalchemy import BigInteger, Column, Date, DateTime, Enum, Float, Index, Integer, String, Time, text, JSON

from service.back_test.models import Strategy, VStrategies, NewStrategySetdetail, StrategyResultDetail, ParentOrder, \
    TradeLogs, BackTestTradeLogs, VStrategyAccountDetail, StrategyResult, \
    VstrategyBackTestResult, StockPortfolioOptimizationVersion, StrategyPortfolio
from service.back_test.live_position_models import VsBase, VsPosition
from service.statistic.tmp_consts import SW_IndustryCategory
from db import ModelBase, engine, session
from extensions import sentry, sentry_mod
from config import config
from kdb_query import KdbQuery
from utils import get_cache, set_cache, del_cache
import consts

from analysis.performance_analysis import PerformanceAnalyzer

null_pnl_detail = {
    'pnl': {},
    'back_test_pnl': {},
    'hedge_net': {},
    'origin_net': {},
    'sharpe': 0,
    'profitrate': 0,
    'annual_return': 0,
    'max_drawdown_pnl': 0,
    'max_drawdown_start': 0,
    'max_drawdown_end': 0,
    'back_test_sharpe': 0,
    'back_test_profitrate': 0,
    'back_test_annual_return': 0,
    'back_test_max_drawdown_pnl': 0,
    'back_test_max_drawdown_start': 0,
    'back_test_max_drawdown_end': 0,
    'return_over_drawdown': 0,
    'paper_trading_sharpe': 0,
    'paper_trading_profitrate': 0,
    'paper_trading_annual_return': 0,
    'paper_trading_max_drawdown_pnl': 0,
    'paper_trading_max_drawdown_start': 0,
    'paper_trading_max_drawdown_end': 0,
}


class InvestmentPortfolio(ModelBase):
    __tablename__ = 'investment_portfolio'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    portfolio_name = Column(VARCHAR(32), nullable=False, unique=True)
    portfolio_type = Column(VARCHAR(32), nullable=False)

    strategy_set_id = Column(INTEGER, nullable=True)

    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=True)

    @staticmethod
    def get_all_portfolio():
        sc = session()

        portfolios = sc.query(
            InvestmentPortfolio.id.label('id'),
            InvestmentPortfolio.portfolio_name.label('portfolio_name'),
            InvestmentPortfolio.portfolio_type.label('portfolio_type'),
        )
        data = {p[0]: {
            'id': p.id,
            'portfolio_name': p.portfolio_name,
            'portfolio_type': p.portfolio_type,
            'cash': 0,
            'leverage': 1,
            'annual_return': 0,
            'sharpe': 0,
            'pnl_graph_url': '',
            'performance_id': 0,
        } for p in portfolios}
        if data:
            portfolio_performance = sc.query(
                InvestmentPortfolioPerformance
            ).filter(
                InvestmentPortfolioPerformance.investment_portfolio_id.in_(data.keys())
            )
            for p in portfolio_performance:
                data[p.investment_portfolio_id]['performance_id'] = p.id
                data[p.investment_portfolio_id]['annual_return'] = float(p.annual_return)
                data[p.investment_portfolio_id]['sharpe'] = float(p.sharpe)
                data[p.investment_portfolio_id]['pnl_graph_url'] = p.pnl_graph_url

        sc.close()
        return {
            'summary': {},
            'rows': sorted(data.values(), key=lambda d: d['id'])
        }

    @staticmethod
    def generate_performance():
        sc = session()
        portfolios = sc.query(
            InvestmentPortfolio.id.label('id'),
            InvestmentPortfolio.strategy_set_id.label('strategy_set_id'),
            InvestmentPortfolio.portfolio_type.label('portfolio_type'),
        )
        for p in portfolios:
            InvestmentPortfolio.generate_performance_to_db(p.id, p.strategy_set_id, p.portfolio_type)
        sc.close()
        return True

    @staticmethod
    def generate_performance_to_db(portfolio_id, strategy_set_id, portfolio_type, **kwargs):
        sc = session()
        try:
            if strategy_set_id:
                data = InvestmentPortfolio.generate_strategy_set_performance(strategy_set_id)
            elif portfolio_type == '高频':
                data = InvestmentPortfolio.generate_high_frequency_performance()
            else:
                raise ValueError('data error, %s, %s, %s' % (portfolio_id, strategy_set_id, portfolio_type))

            p_performace = sc.query(
                InvestmentPortfolioPerformance
            ).filter(
                InvestmentPortfolioPerformance.investment_portfolio_id == portfolio_id
            ).first()
            if not p_performace:
                p_performace = InvestmentPortfolioPerformance(
                    investment_portfolio_id=portfolio_id,
                    sharpe=data['sharpe'],
                    annual_return=data['annual_return'],
                    profitrate=data['profitrate'],
                    max_drawdown_pnl=data['max_drawdown_pnl'],
                    max_drawdown_end=data['max_drawdown_end'],
                    max_drawdown_start=data['max_drawdown_start'],
                    pnl_graph_url=data['pnl_graph_url'],
                )
                sc.add(p_performace)
                sc.flush()
            else:
                p_performace.sharpe = data['sharpe']
                p_performace.annual_return = data['annual_return']
                p_performace.profitrate = data['profitrate']
                p_performace.max_drawdown_pnl = data['max_drawdown_pnl']
                p_performace.max_drawdown_end = data['max_drawdown_end']
                p_performace.max_drawdown_start = data['max_drawdown_start']
                p_performace.pnl_graph_url = data['pnl_graph_url']

            sc.query(InvestmentPortfolioPerformanceDaily).filter(
                InvestmentPortfolioPerformanceDaily.investment_portfolio_performance_id == p_performace.id
            ).delete()
            for d, pnl in sorted(data['pnl'].items(), key=lambda _x: _x[0]):
                dp = InvestmentPortfolioPerformanceDaily(
                    investment_portfolio_performance_id=p_performace.id,
                    trading_date=d,
                    ret=pnl[2],
                    net=pnl[0],
                    open_cash=0,
                    pnl=0,
                    confidence=pnl[1],
                )
                sc.add(dp)
            sc.commit()
        except Exception as e:
            sentry.captureException()
            pass
        sc.close()
        return True

    @staticmethod
    def generate_strategy_set_performance(strategy_set_id, **kwargs):

        back_test_start = kwargs.get('back_test_start', '20180101')

        sc = session()

        vs_details = sc.query(
            VStrategies.id.label('vs_id'),
            Strategy.id.label('s_id'),
            Strategy.strategy_type.label('s_type'),
            Strategy.hedge.label('hedge'),
            Strategy.hedge_type.label('hedge_type'),
        ).join(
            Strategy, VStrategies.strategy_id == Strategy.id
        ).join(
            NewStrategySetdetail, NewStrategySetdetail.vs_id == VStrategies.id
        ).filter(
            NewStrategySetdetail.strategy_set_id == strategy_set_id
        )

        vs_detail, strategy_detail = {}, {}
        back_test_s_ids = set()
        for vs in vs_details:
            vs_detail[vs.vs_id] = {
                's_id': vs.s_id
            }
            strategy_detail[vs.s_id] = {
                'id': vs.s_id,
                's_type': vs.s_type,
                'hedge': vs.hedge,
                'hedge_type': vs.hedge_type,
            }

            if not vs.s_type in ('20',):
                back_test_s_ids.add(vs.s_id)

        sc.close()

        pnls = []
        split_dates = []
        for vs_id, s_id in vs_detail.items():
            s_id = s_id['s_id']
            pnl = InvestmentPortfolio.generate_strategy_net(
                s_id, [vs_id],
                strategy_detail[s_id]['s_type'],
                strategy_detail[s_id]['hedge'],
                strategy_detail[s_id]['hedge_type'],
                back_test_start,
            )
            if pnl:
                pnls.append(pnl)
                split_dates.append(pnl['min_live_date'])
        if split_dates:
            min_split_date = min(split_dates)
            max_split_date = max(split_dates)

        daily_data = {}
        for pnl in pnls:
            for d, d_pnl in pnl['pnl'].items():
                d_data = daily_data.setdefault(d, {
                    'pnl': 0,
                    'open_cash': 0,
                })
                d_data['pnl'] += d_pnl[1]
                d_data['open_cash'] += d_pnl[2]

        dates = sorted(daily_data.keys())
        daily_open_cash = []
        daily_pnls = []
        for d in dates:
            daily_open_cash.append(daily_data[d]['open_cash'])
            daily_pnls.append(daily_data[d]['pnl'])

        back_test_result = {
            'live_date': [],
            'live_pnl': [],
            'live_asset': [],
            'live_position_value': [],
            'live_cash_io': [],
            'live_end_position_value': 0.0,
            'back_test_date': dates,
            'back_test_asset': daily_open_cash,
            'back_test_pnl': daily_pnls,
            'back_test_position_value': [0] * len(dates),
            'back_test_end_position_value': 0.0,
            'back_test_cash_io': [0] * len(dates),
            'paper_trading_date': '',
        }
        net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategies_quest(back_test_result)

        if net_pnl[0]:
            detail = null_pnl_detail
        else:
            detail = net_pnl[1]

        pnl = {}
        x_data = []
        y_data = []
        for d, v in sorted(detail['back_test_pnl'].items(), key=lambda x: x[0]):
            d = d.decode()
            if d < min_split_date:
                c = 'back_test'
            elif d >= max_split_date:
                c = 'live'
            else:
                c = 'combine'

            pnl[d] = [v[0], c, float(v[0]) / float(v[4]) - 1]
            x_data.append(d)
            y_data.append(v[0])

        pnl_graph_url = 'vs_pnl_graph/%s.png' % uuid.uuid4().hex

        data = {
            'annual_return': detail['back_test_annual_return'],
            'sharpe': detail['back_test_sharpe'],
            'profitrate': detail['back_test_profitrate'],
            'max_drawdown_pnl': detail['back_test_max_drawdown_pnl'],
            'max_drawdown_end': detail['back_test_max_drawdown_end'],
            'max_drawdown_start': detail['back_test_max_drawdown_start'],
            'pnl_columns': ['net', 'confidence', 'ret', ],
            'pnl_graph_url': '/media/%s' % pnl_graph_url,
            'pnl': pnl,
        }

        fig = plt.figure(figsize=(1.2, 0.6), dpi=100)
        plt.plot(x_data, y_data, color='red', linewidth=1)
        plt.axis('off')
        plt.savefig(os.path.join(config.media, pnl_graph_url), transparent=True)
        plt.close(fig)
        return data

    @staticmethod
    def generate_strategy_net(strategy_id, vs_id, strategy_type, hedge, hedge_type, back_test_start, **kwargs):
        from service.statistic.performance import BackTestPerformance
        if strategy_type == '20':
            back_test_pnl = {}
        else:
            bt_per = BackTestPerformance(strategy_id)
            back_test_pnl = bt_per.cal_performance()['pnl']

        if back_test_pnl:
            min_date = min(back_test_pnl.keys())
            del back_test_pnl[min_date]

        pnl_details = Strategy.vs_live_pnl_detail(None, _vs_ids=[vs_id])
        live_combine_detail = {}
        for vs_id, live_detail in pnl_details['live_pnl'].items():
            for d, _pnl in live_detail.items():
                if d not in live_combine_detail:
                    live_combine_detail[d] = _pnl
                else:
                    live_combine_detail[d] = [live_combine_detail[d][i] + v for i, v in enumerate(_pnl)]
        live_net_combine_line = Strategy.live_net_line(
            live_combine_detail, ''
        )
        live_pnl = live_net_combine_line['pnl']
        if live_pnl:
            min_date = min(live_pnl.keys())
            del live_pnl[min_date]

        if live_pnl:
            min_live_date = min(live_pnl.keys())
            max_live_date = max(live_pnl.keys())
        else:
            return {}

        if back_test_pnl:
            min_bt_date = max(min(back_test_pnl.keys()), back_test_start)
        else:
            min_bt_date = ''

        bt_pnl_ret = {}
        for d, d_pnl in back_test_pnl.items():
            if back_test_start <= d < min_live_date:
                bt_pnl_ret[d] = [
                    float(d_pnl[0]) / float(d_pnl[4]) - 1, 0, 0
                ]

        live_pnl_tmp = {}
        for d, d_pnl in live_pnl.items():
            live_pnl_tmp[d] = [
                float(d_pnl[0]) / float(d_pnl[4]) - 1, d_pnl[1], d_pnl[2]
            ]

        close_cash = live_pnl_tmp[min_live_date][2]
        back_test_days = sorted(bt_pnl_ret.keys(), reverse=True)
        for i, d in enumerate(back_test_days):
            open_cash = close_cash / (1 + bt_pnl_ret[d][0])
            bt_pnl_ret[d][2] = open_cash
            bt_pnl_ret[d][1] = close_cash - open_cash
            close_cash = open_cash
        bt_pnl_ret.update(live_pnl_tmp)
        pnl = {
            'pnl': bt_pnl_ret,
            'min_bt_date': min_bt_date,
            'min_live_date': min_live_date,
            'max_live_date': max_live_date,
        }
        return pnl

    @staticmethod
    def generate_high_frequency_performance():
        from service.statistic.tmp_consts import day_close_asset
        q_sql = """.gw.asyncexec["
        select sum live_net_amt by date from simu_vs_live_pnl_rounds where date>=2018.04.01"; `PostTradeReportsDB]"""
        kdb = KdbQuery()
        df = kdb.async_query(q_sql, pandas=True)
        daily_pnl = {r[0].strftime('%Y%m%d'): float(r[1]) for r in df.itertuples()}
        kdb.release()

        day_open_asset = {}

        days = sorted(set(list(daily_pnl.keys()) + list(day_close_asset.keys())))

        init_cash = day_close_asset[min(day_close_asset.keys())]
        last_close_asset = init_cash

        for d in days:
            day_open_asset[d] = last_close_asset
            if d in day_close_asset:
                last_close_asset = day_close_asset[d]
            else:
                last_close_asset += daily_pnl.get(d, 0)

        dates = sorted(daily_pnl.keys())
        daily_open_cash = []
        daily_pnls = []
        for d in dates:
            daily_open_cash.append(day_open_asset[d])
            daily_pnls.append(daily_pnl[d])

        back_test_result = {
            'live_date': [],
            'live_pnl': [],
            'live_asset': [],
            'live_position_value': [],
            'live_cash_io': [],
            'live_end_position_value': 0.0,
            'back_test_date': dates,
            'back_test_asset': daily_open_cash,
            'back_test_pnl': daily_pnls,
            'back_test_position_value': [0] * len(dates),
            'back_test_end_position_value': 0.0,
            'back_test_cash_io': [0] * len(dates),
            'paper_trading_date': '',
        }
        net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategies_quest(back_test_result)

        if net_pnl[0]:
            detail = null_pnl_detail
        else:
            detail = net_pnl[1]

        pnl = {}
        x_data = []
        y_data = []
        for d, v in sorted(detail['back_test_pnl'].items(), key=lambda x: x[0]):
            d = d.decode()
            c = 'live'
            pnl[d] = [v[0], c, float(v[0]) / float(v[4]) - 1]
            x_data.append(d)
            y_data.append(v[0])

        pnl_graph_url = 'vs_pnl_graph/%s.png' % uuid.uuid4().hex

        data = {
            'annual_return': detail['back_test_annual_return'],
            'sharpe': detail['back_test_sharpe'],
            'profitrate': detail['back_test_profitrate'],
            'max_drawdown_pnl': detail['back_test_max_drawdown_pnl'],
            'max_drawdown_end': detail['back_test_max_drawdown_end'],
            'max_drawdown_start': detail['back_test_max_drawdown_start'],
            'pnl_columns': ['net', 'confidence', 'ret', ],
            'pnl_graph_url': '/media/%s' % pnl_graph_url,
            'pnl': pnl,
        }

        fig = plt.figure(figsize=(1.2, 0.6), dpi=100)
        plt.plot(x_data, y_data, color='red', linewidth=1)
        plt.axis('off')
        plt.savefig(os.path.join(config.media, pnl_graph_url), transparent=True)
        plt.close(fig)
        return data


class InvestmentPortfolioPlan(ModelBase):
    __tablename__ = 'investment_portfolio_plan'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    portfolio_name = Column(VARCHAR(32), nullable=False, unique=True)

    cash = Column(DOUBLE, nullable=False)
    leverage = Column(DOUBLE, nullable=False)

    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=True)

    @staticmethod
    def get_all_portfolio(current_user):
        sc = session()
        portfolios = sc.query(
            InvestmentPortfolioPlan.id.label('id'),
            InvestmentPortfolioPlan.portfolio_name.label('portfolio_name'),
        ).filter(
            InvestmentPortfolioPlan.r_create_user_id == current_user['id']
        )
        data = {p.id: {
            'id': p.id,
            'portfolio_name': p.portfolio_name,
            'is_default': 0
        } for p in portfolios}
        if data:
            default_p = sc.query(
                DefaultInvestmentPortfolioPlan.investment_portfolio_plan_id
            ).filter(
                DefaultInvestmentPortfolioPlan.r_create_user_id == current_user['id']
            ).first()
            if default_p and default_p[0] in data:
                data[default_p[0]]['is_default'] = 1
        sc.close()
        return sorted(data.values(), key=lambda d: d['id'])

    @staticmethod
    def get_portfolio_plan_by_id(p_id, **kwargs):
        sc = session()
        portfolio_entries = {}
        entries = sc.query(
            InvestmentPortfolioPlanEntry
        ).filter(
            InvestmentPortfolioPlanEntry.investment_portfolio_plan_id == p_id
        )
        for en in entries:
            portfolio_entries[en.investment_portfolio_id] = {
                'id': en.investment_portfolio_id,
                'portfolio_name': '',
                'portfolio_type': '',
                'cash': float(en.cash),
                'leverage': float(en.leverage),
                'annual_return': 0,
                'sharpe': 0,
                'pnl_graph_url': '',
                'performance_id': 0,
            }

        portfolios = sc.query(
            InvestmentPortfolio.id.label('id'),
            InvestmentPortfolio.portfolio_name.label('portfolio_name'),
            InvestmentPortfolio.portfolio_type.label('portfolio_type'),
        ).filter(
            InvestmentPortfolio.id.in_(portfolio_entries.keys())
        )
        for p in portfolios:
            portfolio_entries[p.id]['portfolio_name'] = p.portfolio_name
            portfolio_entries[p.id]['portfolio_type'] = p.portfolio_type

        portfolio_performance = sc.query(
            InvestmentPortfolioPerformance
        ).filter(
            InvestmentPortfolioPerformance.investment_portfolio_id.in_(portfolio_entries.keys())
        )
        for p in portfolio_performance:
            portfolio_entries[p.investment_portfolio_id]['performance_id'] = p.id
            portfolio_entries[p.investment_portfolio_id]['annual_return'] = float(p.annual_return)
            portfolio_entries[p.investment_portfolio_id]['sharpe'] = float(p.sharpe)
            portfolio_entries[p.investment_portfolio_id]['pnl_graph_url'] = p.pnl_graph_url

        p_summary = sc.query(
            InvestmentPortfolioPlan
        ).filter(
            InvestmentPortfolioPlan.id == p_id
        ).first()

        p_summary_performance = sc.query(
            InvestmentPortfolioPerformance
        ).filter(
            InvestmentPortfolioPerformance.investment_portfolio_plan_id == p_id
        ).first()

        summary = {}
        if p_summary_performance:
            summary = {
                'performance_id': p_summary_performance.id,
                'cash': float(p_summary.cash),
                'leverage': float(p_summary.leverage),
                'annual_return': float(p_summary_performance.annual_return),
                'sharpe': float(p_summary_performance.sharpe),
                'pnl_graph_url': p_summary_performance.pnl_graph_url,
            }

        sc.close()
        return {
            'summary': summary,
            'rows': sorted(portfolio_entries.values(), key=lambda d: d['id'])
        }

    @staticmethod
    def get_portfolio_plan_summary_by_id(p_id, **kwargs):
        sc = session()
        p_summary = sc.query(
            InvestmentPortfolioPlan
        ).filter(
            InvestmentPortfolioPlan.id == p_id
        ).first()

        p_summary_performance = sc.query(
            InvestmentPortfolioPerformance
        ).filter(
            InvestmentPortfolioPerformance.investment_portfolio_plan_id == p_id
        ).first()

        summary = {}

        if p_summary_performance:
            summary = {
                'id': p_summary.id,
                'performance_id': p_summary_performance.id,
                'cash': float(p_summary.cash),
                'leverage': float(p_summary.leverage),
                'annual_return': float(p_summary_performance.annual_return),
                'sharpe': float(p_summary_performance.sharpe),
                'pnl_graph_url': p_summary_performance.pnl_graph_url,
            }

        sc.close()
        return summary

    @staticmethod
    def daily_genarate_investment_plan_performance():
        sc = session()
        plan_ids = [p[0] for p in sc.query(InvestmentPortfolioPlan.id)]
        sc.close()
        for plan_id in plan_ids:
            try:
                InvestmentPortfolioPlan.daily_update_investment_plan_performance(plan_id)
            except Exception as e:
                sentry.captureException()
        return True

    @staticmethod
    def daily_update_investment_plan_performance(plan_id, **kwargs):
        sc = session()
        entries = sc.query(InvestmentPortfolioPlanEntry).filter(
            InvestmentPortfolioPlanEntry.investment_portfolio_plan_id == plan_id
        )
        data = {
            'entries': []
        }
        for en in entries:
            data['entries'].append({
                'id': en.investment_portfolio_id,
                'cash': float(en.cash),
                'leverage': float(en.leverage),
            })
        sc.close()
        if not data['entries']:
            return False
        InvestmentPortfolioPlan.update_performance(plan_id, data)
        return True

    @staticmethod
    def update_performance(p_id, pay_load, **kwargs):
        data = InvestmentPortfolioPlan.calculate_performance(pay_load)
        sc = session()
        p = sc.query(InvestmentPortfolioPerformance).filter(
            InvestmentPortfolioPerformance.investment_portfolio_plan_id == p_id
        ).first()
        if not p:
            p = InvestmentPortfolioPerformance(
                investment_portfolio_plan_id=p_id,
                sharpe=data['sharpe'],
                annual_return=data['annual_return'],
                profitrate=data['profitrate'],
                max_drawdown_pnl=data['max_drawdown_pnl'],
                max_drawdown_end=data['max_drawdown_end'],
                max_drawdown_start=data['max_drawdown_start'],
                pnl_graph_url=data['pnl_graph_url'],
            )
            sc.add(p)
            sc.flush()
        else:
            p.sharpe = data['sharpe']
            p.annual_return = data['annual_return']
            p.profitrate = data['profitrate']
            p.max_drawdown_pnl = data['max_drawdown_pnl']
            p.max_drawdown_end = data['max_drawdown_end']
            p.max_drawdown_start = data['max_drawdown_start']
        sc.query(InvestmentPortfolioPerformanceDaily).filter(
            InvestmentPortfolioPerformanceDaily.investment_portfolio_performance_id == p.id
        ).delete()
        for d, pnl in data['pnl'].items():
            dp = InvestmentPortfolioPerformanceDaily(
                investment_portfolio_performance_id=p.id,
                trading_date=d,
                ret=0,
                net=pnl[0],
                open_cash=0,
                pnl=0,
                confidence=pnl[1],
            )
            sc.add(dp)
        sc.commit()
        sc.close()
        return True

    @staticmethod
    def calculate_performance(payload):
        cash, sum_cash, leverage = 0, 0, 0
        entry_cash = {}
        for en in payload['entries']:
            _cash = float(en['cash'])
            leverage_cash = _cash * float(en['leverage'])
            cash += _cash
            sum_cash += leverage_cash
            entry_cash[en['id']] = leverage_cash

        entry_daily_pnls = {}
        sc = session()

        entry_days = sc.query(
            InvestmentPortfolioPerformanceDaily.net.label('net'),
            InvestmentPortfolioPerformanceDaily.ret.label('ret'),
            InvestmentPortfolioPerformanceDaily.trading_date.label('trading_date'),
            InvestmentPortfolioPerformanceDaily.confidence.label('confidence'),
            InvestmentPortfolioPerformance.investment_portfolio_id.label('portfolio_id'),
        ).join(
            InvestmentPortfolioPerformance,
            InvestmentPortfolioPerformance.id == InvestmentPortfolioPerformanceDaily.investment_portfolio_performance_id
        ).filter(
            InvestmentPortfolioPerformance.investment_portfolio_id.in_(entry_cash.keys())
        )
        for en in entry_days:
            portfolio_en_daily = entry_daily_pnls.setdefault(en.portfolio_id, {})
            portfolio_en_daily[en.trading_date] = [
                float(en.net) * entry_cash[en.portfolio_id] * (float(en.ret) / (1 + float(en.ret))), en.confidence
            ]
        sc.close()

        del_keys = [[p_id, min(p_en_day.keys())] for p_id, p_en_day in entry_daily_pnls.items()]
        for k in del_keys:
            del entry_daily_pnls[k[0]][k[1]]

        day_pnls = {}
        day_confidence = {}
        for _, p_daily_pnl in entry_daily_pnls.items():
            for d, pnl in p_daily_pnl.items():
                day_pnls[d] = day_pnls.get(d, 0) + pnl[0]
                d_confidence = day_confidence.setdefault(d, [])
                d_confidence.append(pnl[1])

        dates = sorted(day_pnls.keys())
        open_cash = []
        pnls = []

        close_cash = cash
        for d in dates:
            open_cash.append(close_cash)
            d_pnl = day_pnls.get(d, 0)
            pnls.append(d_pnl)
            close_cash += d_pnl

        back_test_result = {
            'live_date': [],
            'live_pnl': [],
            'live_asset': [],
            'live_position_value': [],
            'live_cash_io': [],
            'live_end_position_value': 0.0,
            'back_test_date': dates,
            'back_test_asset': open_cash,
            'back_test_pnl': pnls,
            'back_test_position_value': [0] * len(dates),
            'back_test_end_position_value': 0.0,
            'back_test_cash_io': [0] * len(dates),
            'paper_trading_date': '',
        }
        net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategies_quest(back_test_result)

        if net_pnl[0]:
            detail = null_pnl_detail
        else:
            detail = net_pnl[1]

        pnl = {}
        x_data = []
        y_data = []
        for d, v in sorted(detail['back_test_pnl'].items(), key=lambda x: x[0]):
            d = d.decode()
            pnl[d] = [v[0], InvestmentPortfolioPlan.change_confidence(day_confidence.get(d, ['back_test'])), 0]
            x_data.append(d)
            y_data.append(v[0])

        pnl_graph_url = 'vs_pnl_graph/%s.png' % uuid.uuid4().hex

        data = {
            'cash': cash,
            'leverage': cash and round(sum_cash / cash, 3) or 1,
            'annual_return': detail['back_test_annual_return'],
            'sharpe': detail['back_test_sharpe'],
            'profitrate': detail['back_test_profitrate'],
            'max_drawdown_pnl': detail['back_test_max_drawdown_pnl'],
            'max_drawdown_end': detail['back_test_max_drawdown_end'],
            'max_drawdown_start': detail['back_test_max_drawdown_start'],
            'pnl_columns': ['net', 'confidence', 'ret', ],
            'pnl_graph_url': '/media/%s' % pnl_graph_url,
            'pnl': pnl,
        }

        fig = plt.figure(figsize=(1.2, 0.6), dpi=100)
        plt.plot(x_data, y_data, color='red', linewidth=1)
        plt.axis('off')
        plt.savefig(os.path.join(config.media, pnl_graph_url), transparent=True)
        plt.close(fig)
        return data

    @staticmethod
    def change_confidence(confidence):
        confidence = list(set(confidence))
        len_confidence = len(confidence)
        if len_confidence == 1:
            return confidence[0]
        elif len_confidence == 0:
            return 'back_test'
        else:
            return 'combine'


class InvestmentPortfolioPlanEntry(ModelBase):
    __tablename__ = 'investment_portfolio_plan_entry'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    investment_portfolio_plan_id = Column(INTEGER, nullable=False)
    investment_portfolio_id = Column(INTEGER, nullable=False)
    cash = Column(DOUBLE, nullable=False)
    leverage = Column(DOUBLE, nullable=False)


class DefaultInvestmentPortfolioPlan(ModelBase):
    __tablename__ = 'investment_portfolio_plan_default'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    investment_portfolio_plan_id = Column(INTEGER, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_create_user_id = Column(INTEGER, nullable=True, unique=True)


class InvestmentPortfolioPerformance(ModelBase):
    __tablename__ = 'investment_portfolio_performance'

    id = Column(BIGINT(unsigned=True), primary_key=True)

    investment_portfolio_id = Column(INTEGER, nullable=True)
    investment_portfolio_plan_id = Column(INTEGER, nullable=True)

    sharpe = Column(DOUBLE, nullable=False)
    annual_return = Column(DOUBLE, nullable=False)
    profitrate = Column(DOUBLE, nullable=False)
    max_drawdown_pnl = Column(DOUBLE, nullable=False)
    max_drawdown_end = Column(VARCHAR(10), nullable=False)
    max_drawdown_start = Column(VARCHAR(10), nullable=False)

    pnl_graph_url = Column(VARCHAR(128), nullable=False, default='')

    @staticmethod
    def get_portfolio_performance_by_id(p_id, **kwargs):
        data = {}
        sc = session()
        p = sc.query(InvestmentPortfolioPerformance).filter(
            InvestmentPortfolioPerformance.id == p_id
        ).first()
        if not p:
            sc.close()
            return data
        data['annual_return'] = float(p.annual_return)
        data['sharpe'] = float(p.sharpe)
        data['profitrate'] = float(p.profitrate)
        data['max_drawdown_pnl'] = float(p.max_drawdown_pnl)
        data['max_drawdown_end'] = p.max_drawdown_end
        data['max_drawdown_start'] = p.max_drawdown_start

        day_pnl = sc.query(
            InvestmentPortfolioPerformanceDaily
        ).filter(
            InvestmentPortfolioPerformanceDaily.investment_portfolio_performance_id == p.id
        )
        data['pnl_columns'] = ['net', 'confidence', 'ret', ]
        data['pnl'] = {
            d.trading_date: [float(d.net), d.confidence, float(d.ret), ]
            for d in day_pnl
        }
        sc.close()
        return data


class InvestmentPortfolioPerformanceDaily(ModelBase):
    __tablename__ = 'investment_portfolio_performance_daily'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    investment_portfolio_performance_id = Column(INTEGER, nullable=True, index=True)
    trading_date = Column(VARCHAR(10), nullable=False)
    ret = Column(DOUBLE, nullable=False)
    net = Column(DOUBLE, nullable=False)
    open_cash = Column(DOUBLE, nullable=False, default=0)
    pnl = Column(DOUBLE, nullable=False, default=0)
    confidence = Column(VARCHAR(32), nullable=False, default='live')


class AnalysisStrategyList(ModelBase):
    """
    存储用户选择的策略列表
    股票交易 --> 策略及组合分析 --> 策略分析
    """
    __tablename__ = 'analysis_strategy_list'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    key = Column(VARCHAR(64), nullable=False)
    strategy_id = Column(INTEGER, nullable=False)
    r_create_user_id = Column(INTEGER, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())


class StrategyEvaluation(ModelBase):
    __tablename__ = 'strategy_evaluation'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(INTEGER, nullable=False, index=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    trading_date = Column(VARCHAR(10), nullable=False)
    turnover = Column(DOUBLE, nullable=False, default=0)
    ic = Column(DOUBLE, nullable=False, default=0)
    std = Column(DOUBLE, nullable=False, default=0)


class StrategyRiskAttribute(ModelBase):
    """
    股票风格偏离数据
    股票交易 --> 实盘绩效 --> 点击策略ID
    由曾毅提供脚本计算
    """
    __tablename__ = 'strategy_risk_attribute'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(VARCHAR(10), nullable=False, index=True)
    max_w_800 = Column(DOUBLE, nullable=False, default=0)
    non800_max_w = Column(DOUBLE, nullable=False, default=0)
    non800_ratio = Column(DOUBLE, nullable=False, default=0)
    startup_w = Column(DOUBLE, nullable=False, default=0)
    FVbelow14_w = Column(DOUBLE, nullable=False, default=0)
    TolValue = Column(DOUBLE, nullable=False, default=0)
    FloatValue = Column(DOUBLE, nullable=False, default=0)
    non800_top30_max_w = Column(DOUBLE, nullable=False, default=0)
    noncsi800_nontop30_max_w = Column(DOUBLE, nullable=False, default=0)
    top20_value_w = Column(DOUBLE, nullable=False, default=0)
    industry_max_w = Column(DOUBLE, nullable=False, default=0)

    @staticmethod
    def import_strategy_risk_attribute(s_id):
        from service.statistic.risk_attribute import risk_attribute
        sc = session()
        try:
            s = sc.query(Strategy).filter(Strategy.id == s_id).first()
            if s.strategy_type not in consts.stock_strategy_type:
                sc.close()
                return False
            optimization_paras = {}
            if s.detail.get('portfolio_optimization_so_version', ''):
                optimization_paras = sc.query(StockPortfolioOptimizationVersion).filter(
                    StockPortfolioOptimizationVersion.value == s.detail.get('portfolio_optimization_so_version', '')
                ).first()
                optimization_paras = optimization_paras and optimization_paras.paras or {}

            top_n_sum_weight = optimization_paras.get('num_top_weight', 20)
            float_value_limit = optimization_paras.get('mv_threshold', 14)

            last_date = sc.query(
                func.max(StrategyRiskAttribute.trading_date)
            ).filter(StrategyRiskAttribute.strategy_id == s_id).first()
            last_date = last_date and last_date[0] or s.start_date

            df_attr = risk_attribute(s_id, last_date, datetime.datetime.now().strftime('%Y%m%d'),
                                     top_n_sum_weight=top_n_sum_weight, float_value_limit=float_value_limit)

            for i, row in df_attr.iterrows():
                s_attrs = {}
                s_attrs['trading_date'] = str(int(row['trading_date']))
                s_attrs['max_w_800'] = row['max_w_800']
                s_attrs['non800_max_w'] = row['non800_max_w']
                s_attrs['non800_ratio'] = row['non800_ratio']
                s_attrs['startup_w'] = row['startup_w']
                s_attrs['FVbelow14_w'] = row['FVbelow14_w']
                s_attrs['TolValue'] = row['TolValue']
                s_attrs['FloatValue'] = row['FloatValue']
                s_attrs['non800_top30_max_w'] = row['non800_top30_max_w']
                s_attrs['noncsi800_nontop30_max_w'] = row['noncsi800_nontop30_max_w']
                s_attrs['top20_value_w'] = row['top20_value_w']
                s_attrs['industry_max_w'] = row['industry_max_w']
                b = StrategyRiskAttribute(
                    strategy_id=s_id,
                    **s_attrs,
                )
                sc.add(b)
            sc.commit()
        except Exception as e:
            sentry.captureException()
            sc.close()
            return False
        sc.close()
        return True


class StrategyStyleExposure(ModelBase):
    """
    股票风格偏离数据
    股票交易 --> 实盘绩效 --> 点击策略ID
    由张龙提供脚本计算
    """
    __tablename__ = 'strategy_style_exposure'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(VARCHAR(10), nullable=False, index=True)
    bd = Column(DOUBLE, nullable=False, default=0)
    bt = Column(DOUBLE, nullable=False, default=0)
    gg = Column(DOUBLE, nullable=False, default=0)
    hy = Column(DOUBLE, nullable=False, default=0)
    jz = Column(DOUBLE, nullable=False, default=0)
    ld = Column(DOUBLE, nullable=False, default=0)
    mm = Column(DOUBLE, nullable=False, default=0)
    mv = Column(DOUBLE, nullable=False, default=0)
    yl = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801010 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801780 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801150 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801110 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801740 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801170 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801890 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801120 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801730 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801030 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801880 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801210 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801230 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801710 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801720 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801790 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801750 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801080 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801760 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801130 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801140 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801020 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801040 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801770 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801180 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801050 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801160 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801200 = Column(DOUBLE, nullable=False, default=0)

    @staticmethod
    def import_strategy_style_exposure(s_id):
        from service.statistic.style_exposure import style_exposure
        sc = session()
        try:
            s = sc.query(Strategy).filter(Strategy.id == s_id).first()
            if s.strategy_type not in consts.alpha_stock_strategy_type:
                sc.close()
                return False

            keys1 = [
                'bd', 'bt', 'gg', 'hy', 'jz', 'ld', 'mm', 'mv', 'yl',
            ]

            keys2 = [
                '801010.SWS', '801020.SWS', '801030.SWS', '801040.SWS', '801050.SWS',
                '801080.SWS', '801110.SWS', '801120.SWS', '801130.SWS', '801140.SWS',
                '801150.SWS', '801160.SWS', '801170.SWS', '801180.SWS', '801200.SWS',
                '801210.SWS', '801230.SWS', '801710.SWS', '801720.SWS', '801730.SWS',
                '801740.SWS', '801750.SWS', '801760.SWS', '801770.SWS', '801780.SWS',
                '801790.SWS', '801880.SWS', '801890.SWS'
            ]

            keys2 = {k: 'hy_sws_%s' % k.split('.')[0] for k in keys2}

            last_date = sc.query(
                func.max(StrategyStyleExposure.trading_date)
            ).filter(StrategyStyleExposure.strategy_id == s_id).first()
            last_date = last_date and last_date[0] or '20080101'
            hedging = s.hedge.lower()
            back_test_position = sc.query(StrategyResultDetail).filter(
                StrategyResultDetail.strategy_id == s.id,
                StrategyResultDetail.trading_date >= last_date,
            )
            back_test_day_position = {}

            for p in back_test_position:
                if p.day_night != 0:
                    continue
                d = p.trading_date.strftime('%Y%m%d')
                if d <= last_date:
                    continue
                long_pos = p.long_volume
                if long_pos > 0:
                    bt_d_p = back_test_day_position.setdefault(d, {})
                    bt_d_p[p.symbol] = long_pos
            s_bias = {}

            strategy_log_path = '{user_id}_{username}/strategy/log/simu/strategy_log/{strategy_id}/{task_id}'.format(
                user_id=s.r_create_user_id,
                username=s.username,
                strategy_id=s.id_no,
                task_id=s.st_uuid
            )
            strategy_log_path = os.path.join(
                '/home/rss/jupyter_userworkspace/', strategy_log_path
            )
            risk_ev_path = os.path.join(config.media, 'portfolio_optimization_ev')
            for d, d_pos in back_test_day_position.items():
                long_volume = pd.DataFrame(sorted(d_pos.items(), key=lambda x: x[0]), columns=['symbol', 'size'])
                # bias1 = style_exposure(long_volume, hedging, d, path)
                bias1 = style_exposure(long_volume, d, risk_ev_path, strategy_log_path)
                bias = {}
                for k in keys1:
                    bias[k] = float(bias1.get(k, [0])[0])

                for k1, k2 in keys2.items():
                    bias[k2] = float(bias1.get(k1, [0])[0])
                s_bias[d] = bias

            if s_bias:
                for d, bias in s_bias.items():
                    b = StrategyStyleExposure(
                        strategy_id=s_id,
                        trading_date=d,
                        **bias,
                    )
                    sc.add(b)
                sc.commit()

            for vs_id in sc.query(VStrategies.id).filter(VStrategies.strategy_id == s_id):
                VStrategyStyleExposure.import_vs_style_exposure(vs_id[0], hedging)

        except Exception as e:
            sentry_mod.captureException()
            sc.close()
            return False
        sc.close()
        StrategyRiskAttribute.import_strategy_risk_attribute(s_id)
        return True


class VStrategyStyleExposure(ModelBase):
    __tablename__ = 'vs_style_exposure'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vs_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(VARCHAR(10), nullable=False, index=True)
    bd = Column(DOUBLE, nullable=False, default=0)
    bt = Column(DOUBLE, nullable=False, default=0)
    gg = Column(DOUBLE, nullable=False, default=0)
    hy = Column(DOUBLE, nullable=False, default=0)
    jz = Column(DOUBLE, nullable=False, default=0)
    ld = Column(DOUBLE, nullable=False, default=0)
    mm = Column(DOUBLE, nullable=False, default=0)
    mv = Column(DOUBLE, nullable=False, default=0)
    yl = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801010 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801780 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801150 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801110 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801740 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801170 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801890 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801120 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801730 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801030 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801880 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801210 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801230 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801710 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801720 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801790 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801750 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801080 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801760 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801130 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801140 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801020 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801040 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801770 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801180 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801050 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801160 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801200 = Column(DOUBLE, nullable=False, default=0)

    @staticmethod
    def import_vs_style_exposure(vs_id, hedging, **kwargs):
        from service.statistic.style_exposure import style_exposure
        sc = session()
        try:
            last_date = sc.query(
                func.max(VStrategyStyleExposure.trading_date)
            ).filter(VStrategyStyleExposure.vs_id == vs_id).first()
            last_date = last_date and last_date[0] or '20080101'

            vs_positions = sc.query(VsPosition).filter(
                VsPosition.vstrategy_id == vs_id,
                VsPosition.daynight == 'DAY',
                VsPosition.settle_date >= last_date,
            )

            day_positions = {}
            for vs_p in vs_positions:
                d = vs_p.settle_date.strftime('%Y%m%d')
                if d <= last_date:
                    continue
                long_pos = int(vs_p.today_long_pos)
                if long_pos > 0:
                    vs_d_p = day_positions.setdefault(d, {})
                    vs_d_p[vs_p.symbol] = long_pos

            s = sc.query(Strategy).join(
                VStrategies, VStrategies.strategy_id == Strategy.id
            ).filter(VStrategies.id == vs_id).first()
            s_bias = {}
            risk_ev_path = os.path.join(config.media, 'portfolio_optimization_ev')
            strategy_log_path = '{user_id}_{username}/strategy/log/simu/strategy_log/{strategy_id}/{task_id}'.format(
                user_id=s.r_create_user_id,
                username=s.username,
                strategy_id=s.id_no,
                task_id="v_strategy_id:%s" % vs_id
            )
            strategy_log_path = os.path.join(
                '/home/rss/jupyter_userworkspace/', strategy_log_path
            )

            for d, d_pos in day_positions.items():
                long_volume = pd.DataFrame(sorted(d_pos.items(), key=lambda x: x[0]), columns=['symbol', 'size'])
                # bias1 = style_exposure(long_volume, hedging, d, path)
                bias1 = style_exposure(long_volume, d, risk_ev_path, strategy_log_path)
                bias = {}
                for _k, v in bias1.items():
                    if '.SWS' in _k:
                        _k = 'hy_sws_%s' % _k.split('.')[0]
                    bias[_k] = v[0]
                s_bias[d] = bias

            if s_bias:
                for d, bias in s_bias.items():
                    b = VStrategyStyleExposure(
                        vs_id=vs_id,
                        trading_date=d,
                        **bias,
                    )
                    sc.add(b)
                sc.commit()
        except Exception as e:
            sentry_mod.captureException()
            sc.close()
            return False
        sc.close()
        return True

    @staticmethod
    def get_vs_daily_weight(vs_ids, **kwargs):
        sc = session()
        strategies = sc.query(
            Strategy.id.label('s_id'),
            VStrategies.id.label('vs_id'),
            StrategyPortfolio.live_time.label('live_time'),
        ).join(
            VStrategies, VStrategies.strategy_id == Strategy.id
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            VStrategies.id.in_(vs_ids),
            Strategy.strategy_type.in_(consts.alpha_stock_strategy_type)
        )
        vs_detail = {}
        for s in strategies:
            vs_detail[s.vs_id] = {
                'vs_id': s.vs_id,
                's_id': s.s_id,
                'live_time': s.live_time.strftime('%Y%m%d'),
            }

        vs_cash = {}
        vs_bases = sc.query(VsBase).filter(VsBase.vstrategy_id.in_(vs_detail.keys()), VsBase.daynight == 'DAY')
        for l in vs_bases:
            d = l.settle_date.strftime('%Y%m%d')
            _cash = float(l.total_asset)
            if d not in vs_cash:
                vs_cash[d] = {
                    'total': _cash,
                    'detail': {},
                }
            else:
                vs_cash[d]['total'] += _cash

            vs_cash[d]['detail'][l.vstrategy_id] = _cash

        vs_weight = {}
        for d, d_t in vs_cash.items():
            vs_weight[d] = {}
            if d_t['total']:
                for v_id, v_cash in d_t['detail'].items():
                    if d >= vs_detail[v_id]['live_time']:
                        vs_weight[d][v_id] = v_cash / d_t['total']
        sc.close()
        return {
            'vs_weight': vs_weight,
            'vs_detail': vs_detail,
        }

    @staticmethod
    def get_vs_portfolio_style_exposure(vs_ids, **kwargs):
        sc = session()
        data = {
            'strategies': {},
            'papertrading_date': '20190101'
        }

        vs_detail = VStrategyStyleExposure.get_vs_daily_weight(vs_ids, **kwargs)
        vs_weight = vs_detail['vs_weight']
        vs_detail = vs_detail['vs_detail']

        exposure = {}
        exposure_keys = [
            'bd', 'bt', 'gg', 'hy', 'jz', 'ld', 'mm', 'mv', 'yl',
        ]

        for vs_id in vs_detail.keys():
            s_exposure = sc.query(VStrategyStyleExposure).filter(
                VStrategyStyleExposure.vs_id == vs_id,
                VStrategyStyleExposure.trading_date >= vs_detail[vs_id]['live_time'],
            )
            _s_exposure = {}
            for ex in s_exposure:
                _s_exposure[ex.trading_date] = {}
                vs_d_w = vs_weight.get(ex.trading_date, {}).get(vs_id, 0)
                for k in exposure_keys:
                    _s_exposure[ex.trading_date][k] = float(getattr(ex, k, 0)) * vs_d_w

            for d_t, v in _s_exposure.items():
                d_exposure = exposure.setdefault(d_t, {})
                for k in exposure_keys:
                    d_exposure[k] = d_exposure.get(k, 0) + v[k]

        days = sorted(exposure.keys())
        data['exposure_days'] = days
        data['exposure'] = {
            k: [] for k in exposure_keys
        }
        for d in days:
            for k in exposure_keys:
                data['exposure'][k].append(round(exposure[d][k], 4))
        sc.close()
        return data

    @staticmethod
    def get_vs_portfolio_hy_style_exposure(vs_ids, **kwargs):
        sc = session()
        data = {
            'strategies': {},
            'papertrading_date': '20190101'
        }
        vs_detail = VStrategyStyleExposure.get_vs_daily_weight(vs_ids, **kwargs)
        vs_weight = vs_detail['vs_weight']
        vs_detail = vs_detail['vs_detail']

        exposure = {}

        hy_keys = [
            'hy_sws_801010', 'hy_sws_801780', 'hy_sws_801150', 'hy_sws_801110', 'hy_sws_801740',
            'hy_sws_801170', 'hy_sws_801890', 'hy_sws_801120', 'hy_sws_801730', 'hy_sws_801030',
            'hy_sws_801880', 'hy_sws_801210', 'hy_sws_801230', 'hy_sws_801710', 'hy_sws_801720',
            'hy_sws_801790', 'hy_sws_801750', 'hy_sws_801080', 'hy_sws_801760', 'hy_sws_801130',
            'hy_sws_801140', 'hy_sws_801020', 'hy_sws_801040', 'hy_sws_801770', 'hy_sws_801180',
            'hy_sws_801050', 'hy_sws_801160', 'hy_sws_801200'
        ]

        for vs_id in vs_detail.keys():
            s_exposure = sc.query(VStrategyStyleExposure).filter(
                VStrategyStyleExposure.vs_id == vs_id,
                VStrategyStyleExposure.trading_date >= vs_detail[vs_id]['live_time'],
            )
            _s_exposure = {}
            for ex in s_exposure:
                _s_exposure[ex.trading_date] = {}
                vs_d_w = vs_weight.get(ex.trading_date, {}).get(vs_id, 0)
                for k in hy_keys:
                    _s_exposure[ex.trading_date][k] = float(getattr(ex, k, 0)) * vs_d_w

            for d_t, v in _s_exposure.items():
                d_exposure = exposure.setdefault(d_t, {})
                for k in hy_keys:
                    d_exposure[k] = d_exposure.get(k, 0) + v[k]

        days = sorted(exposure.keys())
        data['exposure_days'] = days
        data['exposure'] = {k: [] for k in hy_keys}
        for d in days:
            for k in hy_keys:
                data['exposure'][k].append(round(exposure[d][k], 6))
        data['exposure_cn_name'] = {
            k: SW_IndustryCategory.get(k.split('_')[-1], k) for k in hy_keys
        }
        sc.close()
        return data


class StrategyVwapExecutimeTime(ModelBase):
    """
    股票策略的交易时间
    股票策略的交易时间 9:30 到 15:00 或者9:30 到 10:00 或者其他
    """
    __tablename__ = 'strategy_vwap_execution_time'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(VARCHAR(10), nullable=False, index=True)
    start_time = Column(VARCHAR(10), nullable=False)
    end_time = Column(VARCHAR(10), nullable=False)


class VsVwapExecutimeTime(ModelBase):
    """
    股票策略的交易时间
    股票策略的交易时间 9:30 到 15:00 或者9:30 到 10:00 或者其他
    """
    __tablename__ = 'vs_vwap_execution_time'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vs_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(VARCHAR(10), nullable=False, index=True)
    start_time = Column(VARCHAR(10), nullable=False)
    end_time = Column(VARCHAR(10), nullable=False)


class StrategyIncomeAttribution(ModelBase):
    """
    股票策略收益归因
    股票交易 --> 实盘绩效 -->收益归因
    股票交易 --> 策略及组合分析 --> 收益归因
    由张龙提供脚本计算
    """
    __tablename__ = 'strategy_income_attribution'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(VARCHAR(10), nullable=False, index=True)
    bd = Column(DOUBLE, nullable=False, default=0)
    bt = Column(DOUBLE, nullable=False, default=0)
    gg = Column(DOUBLE, nullable=False, default=0)
    hy = Column(DOUBLE, nullable=False, default=0)
    jz = Column(DOUBLE, nullable=False, default=0)
    ld = Column(DOUBLE, nullable=False, default=0)
    mm = Column(DOUBLE, nullable=False, default=0)
    mv = Column(DOUBLE, nullable=False, default=0)
    yl = Column(DOUBLE, nullable=False, default=0)
    adjusted = Column(JSON, nullable=True)
    hy_sws_801010 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801780 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801150 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801110 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801740 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801170 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801890 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801120 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801730 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801030 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801880 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801210 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801230 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801710 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801720 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801790 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801750 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801080 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801760 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801130 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801140 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801020 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801040 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801770 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801180 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801050 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801160 = Column(DOUBLE, nullable=False, default=0)
    hy_sws_801200 = Column(DOUBLE, nullable=False, default=0)

    @staticmethod
    def import_strategy_income_attribution(s_id, clear_history=False):
        from service.statistic.income_attribution2 import income_attribution as income_attribution2
        sc = session()
        path = os.path.join(config.media, 'portfolio_optimization_ev')
        s = sc.query(Strategy).filter(
            Strategy.id == s_id
        ).first()
        if s.strategy_type not in consts.alpha_stock_strategy_type:
            sc.close()
            return False

        try:
            if clear_history:
                sc.query(StrategyIncomeAttribution).filter(
                    StrategyIncomeAttribution.strategy_id == s_id
                ).delete()
                sc.commit()

            last_date = sc.query(
                func.max(StrategyIncomeAttribution.trading_date)
            ).filter(StrategyIncomeAttribution.strategy_id == s_id).first()
            last_date = last_date and last_date[0] or '20080101'
            hedging = s.hedge.lower()
            back_test_position = sc.query(StrategyResultDetail).filter(
                StrategyResultDetail.strategy_id == s.id,
                StrategyResultDetail.trading_date >= last_date,
            )
            back_test_day_position = {}
            back_test_night_position = {}

            for p in back_test_position:
                d = p.trading_date.strftime('%Y%m%d')
                if d <= last_date:
                    continue
                long_pos = p.long_volume
                if long_pos > 0:
                    if p.day_night == 0:
                        bt_d_p = back_test_day_position.setdefault(d, {})
                        bt_d_p[p.symbol] = long_pos
                    elif p.day_night == 1:
                        bt_n_p = back_test_night_position.setdefault(d, {})
                        bt_n_p[p.symbol] = long_pos

            s_bias = {}
            strategy_log_path = '{user_id}_{username}/strategy/log/simu/strategy_log/{strategy_id}/{task_id}'.format(
                user_id=s.r_create_user_id,
                username=s.username,
                strategy_id=s.id_no,
                task_id=s.st_uuid
            )
            strategy_log_path = os.path.join(
                '/home/rss/jupyter_userworkspace/', strategy_log_path
            )

            for d, d_pos in back_test_day_position.items():
                stock_list_open = pd.DataFrame(sorted(back_test_night_position.get(d, {}).items(), key=lambda x: x[0]),
                                               columns=['symbol', 'size'])
                stock_list_close = pd.DataFrame(sorted(d_pos.items(), key=lambda x: x[0]), columns=['symbol', 'size'])
                try:
                    bias = income_attribution2(
                        d, path, strategy_log_path, stocklist_open=stock_list_open, stocklist_close=stock_list_close
                    )
                    s_bias[d] = bias
                except Exception as e:
                    sentry.captureException()
                    continue

            if s_bias:
                for d, bias1 in s_bias.items():
                    bias = {}
                    for _k, v in bias1.items():
                        if '.SWS' in _k:
                            _k = 'hy_sws_%s' % _k.split('.')[0]
                        bias[_k] = v

                    b = StrategyIncomeAttribution(
                        strategy_id=s_id,
                        trading_date=d,
                        **bias,
                    )
                    sc.add(b)
                sc.commit()

            for vs_id in sc.query(VStrategies.id).filter(VStrategies.strategy_id == s_id):
                VStrategyIncomeAttribution.import_strategy_income_attribution(vs_id[0], hedging)

        except Exception as e:
            sentry_mod.captureException()
            sc.close()
            return False

        sc.close()
        return True

    @staticmethod
    def get_income_attribution_adjusted(s_id, trading_date, **kwargs):
        from service.statistic.income_attribution_adjusted import setup_adjusted
        sc = session()
        unadjusted_s = sc.query(StrategyIncomeAttributionAdjusted).filter(
            StrategyIncomeAttributionAdjusted.s_id == s_id
        ).first()
        if not unadjusted_s:
            sc.close()
            return []

        unajusted_s_id = unadjusted_s.unajusted_s_id
        sql1 = """
            select * from strategy_income_attribution
            where strategy_id={strategy_id}
        """.format(strategy_id=unajusted_s_id)
        prev_income_df = pd.read_sql_query(sql1, engine)
        s = sc.query(Strategy).filter(Strategy.id == s_id).first()
        portfolio_opt = StockPortfolioOptimizationVersion.get_paras(
            s.detail.get('portfolio_optimization_so_version', '')
        )
        sc.close()
        try:
            ajusted_income = setup_adjusted(str(trading_date), prev_income_df, portfolio_opt)
        except Exception as e:
            return []
        return ajusted_income

    @staticmethod
    def get_back_test_income_attribution_adjusted(s_id, start_date='20010101', end_date='21000101', **kwargs):
        from service.statistic.income_attribution_adjusted import setup_adjusted
        sc = session()
        kdb = KdbQuery()
        unadjusted_s = sc.query(StrategyIncomeAttributionAdjusted).filter(
            StrategyIncomeAttributionAdjusted.s_id == s_id
        ).first()
        if not unadjusted_s:
            sc.close()
            return {}

        start_date = (parse(start_date) - datetime.timedelta(days=15)).strftime('%Y%m%d')

        unajusted_s_id = unadjusted_s.unajusted_s_id

        sql1 = """
            select * from strategy_income_attribution
            where strategy_id={strategy_id}
        """.format(strategy_id=unajusted_s_id)
        prev_income_df = pd.read_sql_query(sql1, engine)

        s = sc.query(Strategy).filter(Strategy.id == s_id).first()
        portfolio_opt = StockPortfolioOptimizationVersion.get_paras(
            s.detail.get('portfolio_optimization_so_version', '')
        )
        sc.close()
        days = [str(d) for d in prev_income_df['trading_date'] if d >= start_date]
        if not days:
            return {}
        start_date = min(days)
        days = kdb.get_trading_days(start_date, datetime.datetime.now().strftime('%Y%m%d'))
        daily_adjusted_income = {}
        for d in days:
            try:
                daily_adjusted_income[d] = setup_adjusted(d, prev_income_df.copy(), portfolio_opt)
            except Exception as e:
                sentry.captureException()
        return daily_adjusted_income

    @staticmethod
    def get_strategy_income_attribution(s_id, start_date='20010101', end_date='21000101', **kwargs):
        sc = session()
        rows = sc.query(StrategyIncomeAttribution).filter(
            StrategyIncomeAttribution.strategy_id == s_id,
            StrategyIncomeAttribution.trading_date >= start_date,
            StrategyIncomeAttribution.trading_date <= end_date
        )
        data = {}
        keys1 = [
            'bd', 'bt', 'gg', 'hy', 'jz', 'ld', 'mm', 'mv', 'yl',
        ]

        keys2 = [
            '801010.SWS', '801020.SWS', '801030.SWS', '801040.SWS', '801050.SWS',
            '801080.SWS', '801110.SWS', '801120.SWS', '801130.SWS', '801140.SWS',
            '801150.SWS', '801160.SWS', '801170.SWS', '801180.SWS', '801200.SWS',
            '801210.SWS', '801230.SWS', '801710.SWS', '801720.SWS', '801730.SWS',
            '801740.SWS', '801750.SWS', '801760.SWS', '801770.SWS', '801780.SWS',
            '801790.SWS', '801880.SWS', '801890.SWS'
        ]

        keys2 = {k: 'hy_sws_%s' % k.split('.')[0] for k in keys2}

        for r in rows:
            d_data = {}
            for k in keys1:
                d_data[k] = float(getattr(r, k))

            for k1, k2 in keys2.items():
                d_data[k1] = float(getattr(r, k2))
            data[r.trading_date] = d_data
        sc.close()
        return data


class StrategyIncomeAttributionAdjusted(ModelBase):
    """
    某个策略可能会使用 其他策略的收益归因数据作为交易的参数
    在组合分析页面添加回测的时候可以配置
    """
    __tablename__ = 'strategy_income_attribution_adjusted'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    s_id = Column(INTEGER, nullable=False, unique=True)
    unajusted_s_id = Column(INTEGER, nullable=False)

    @staticmethod
    def set_pair(s_id, unajusted_s_id, **kwargs):
        sc = session()
        r = sc.query(StrategyIncomeAttributionAdjusted).filter(
            StrategyIncomeAttributionAdjusted.s_id == s_id
        ).first()
        if r:
            r.unajusted_s_id = unajusted_s_id
        else:
            r = StrategyIncomeAttributionAdjusted(
                s_id=s_id,
                unajusted_s_id=unajusted_s_id,
            )
            sc.add(r)
        sc.commit()
        sc.close()
        return True


class VStrategyIncomeAttribution(ModelBase):
    __tablename__ = 'vs_income_attribution'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vs_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(VARCHAR(10), nullable=False, index=True)
    bd = Column(DOUBLE, nullable=False, default=0)
    bt = Column(DOUBLE, nullable=False, default=0)
    gg = Column(DOUBLE, nullable=False, default=0)
    hy = Column(DOUBLE, nullable=False, default=0)
    jz = Column(DOUBLE, nullable=False, default=0)
    ld = Column(DOUBLE, nullable=False, default=0)
    mm = Column(DOUBLE, nullable=False, default=0)
    mv = Column(DOUBLE, nullable=False, default=0)
    yl = Column(DOUBLE, nullable=False, default=0)

    @staticmethod
    def import_strategy_income_attribution(vs_id, hedging, **kwargs):
        from service.statistic.income_attribution import income_attribution
        sc = session()
        path = os.path.join(config.media, 'portfolio_optimization_ev')

        vwap_time = sc.query(VsVwapExecutimeTime).filter(
            VsVwapExecutimeTime.vs_id == vs_id
        ).order_by(VsVwapExecutimeTime.id.desc()).first()
        if vwap_time:
            vwap_start = int(vwap_time.start_time) * 1000
            vwap_end = int(vwap_time.end_time) * 1000
        else:
            vwap_time = sc.query(StrategyVwapExecutimeTime).filter(
                StrategyVwapExecutimeTime.strategy_id.in_(
                    sc.query(
                        VStrategies.strategy_id
                    ).filter(
                        VStrategies.id == vs_id
                    )
                )
            ).order_by(StrategyVwapExecutimeTime.id.desc()).first()

            if vwap_time:
                vwap_start = int(vwap_time.start_time) * 1000
                vwap_end = int(vwap_time.end_time) * 1000
            else:
                sc.close()
                return False

        try:
            last_date = sc.query(
                func.max(VStrategyIncomeAttribution.trading_date)
            ).filter(VStrategyIncomeAttribution.vs_id == vs_id).first()
            last_date = last_date and last_date[0] or '20080101'

            vs_positions = sc.query(VsPosition).filter(
                VsPosition.vstrategy_id == vs_id,
                VsPosition.settle_date >= last_date,
            )

            day_positions = {}
            night_positions = {}
            for vs_p in vs_positions:
                d = vs_p.settle_date.strftime('%Y%m%d')
                if d <= last_date:
                    continue
                long_pos = int(vs_p.today_long_pos)
                if long_pos > 0:
                    if vs_p.daynight == 'DAY':
                        vs_d_p = day_positions.setdefault(d, {})
                        vs_d_p[vs_p.symbol] = long_pos
                    elif vs_p.daynight == 'NIGHT':
                        vs_n_p = night_positions.setdefault(d, {})
                        vs_n_p[vs_p.symbol] = long_pos

            s_bias = {}
            for d, d_pos in day_positions.items():
                stocklist_open = pd.DataFrame(sorted(night_positions.get(d, {}).items(), key=lambda x: x[0]),
                                              columns=['symbol', 'size'])
                stocklist_close = pd.DataFrame(sorted(d_pos.items(), key=lambda x: x[0]), columns=['symbol', 'size'])
                bias = income_attribution(
                    d, vwap_start, vwap_end, path, hedging, stocklist_open=stocklist_open,
                    stocklist_close=stocklist_close
                )
                s_bias[d] = bias

            if s_bias:
                for d, bias in s_bias.items():
                    bias = {
                        k: v for k, v in bias.items()
                        if k in ('bd', 'bt', 'gg', 'hy', 'jz', 'ld', 'mm', 'mv', 'yl', 'adjusted')
                    }
                    b = VStrategyIncomeAttribution(
                        vs_id=vs_id,
                        trading_date=d,
                        **bias,
                    )
                    sc.add(b)
                sc.commit()
        except Exception as e:
            sentry_mod.captureException()
            sc.close()
            return False

        sc.close()
        return True


class StockFactorReturn(ModelBase):
    """
    股票市场因子收益
    股票交易 --> 因子收益
    由张龙提供脚本计算
    """
    __tablename__ = 'stock_factor_return'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    trading_date = Column(VARCHAR(10), nullable=False, index=True)
    bd = Column(DOUBLE, nullable=False, default=0)
    bt = Column(DOUBLE, nullable=False, default=0)
    gg = Column(DOUBLE, nullable=False, default=0)
    hy = Column(DOUBLE, nullable=False, default=0)
    jz = Column(DOUBLE, nullable=False, default=0)
    ld = Column(DOUBLE, nullable=False, default=0)
    mm = Column(DOUBLE, nullable=False, default=0)
    mv = Column(DOUBLE, nullable=False, default=0)
    yl = Column(DOUBLE, nullable=False, default=0)

    @staticmethod
    def import_stock_factor_return(trading_date):
        from service.statistic.factor_return import factor_return
        sc = session()
        path = os.path.join(config.media, 'portfolio_optimization_ev')
        try:
            factors = factor_return(trading_date, path)

            sc.query(StockFactorReturn).filter(StockFactorReturn.trading_date == trading_date).delete()

            factor = StockFactorReturn(
                trading_date=trading_date,
                **factors,
            )
            sc.add(factor)
            sc.commit()

        except Exception as e:
            sentry.captureException()
            sc.close()
            return False
        sc.close()
        return True

    @staticmethod
    def import_stock_history_factor_return():
        kdb = KdbQuery()
        sc = session()
        last_trading_date = sc.query(func.max(StockFactorReturn.trading_date)).first()
        if last_trading_date:
            last_trading_date = last_trading_date[0]
        if not last_trading_date:
            last_trading_date = '20180101'
        sc.close()
        days = kdb.get_trading_days(last_trading_date, datetime.datetime.now().strftime('%Y%m%d'))
        for d in days:
            StockFactorReturn.import_stock_factor_return(d)
        return True


class VsAggregationPnl(ModelBase):
    """
    实盘策略收益统计，实盘绩效页面使用
    """
    __tablename__ = 'vs_aggregation_pnl'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vs_id = Column(INTEGER, nullable=False, index=True)
    agg_key = Column(VARCHAR(64), nullable=False, index=True)
    pnl = Column(DOUBLE, nullable=False, default=0)

    @staticmethod
    def update_aggregation_pnl():
        sc = session()
        kdb = KdbQuery()
        now = datetime.datetime.now()
        trading_days = kdb.get_trading_days((now - datetime.timedelta(days=200)).strftime('%Y%m%d'),
                                            now.strftime('%Y%m%d'))
        year = now.strftime('%Y0101')
        month_1 = now.strftime('%Y%m01')
        now_month = now.strftime('%m')
        if '01' <= now_month <= '03':
            season_1_date = now.strftime('%Y0101')
        elif '04' <= now_month <= '06':
            season_1_date = now.strftime('%Y0401')
        elif '07' <= now_month <= '09':
            season_1_date = now.strftime('%Y0701')
        else:
            season_1_date = now.strftime('%Y1001')
        trading_days_20 = trading_days[-20]
        trading_days_40 = trading_days[-40]
        trading_days_60 = trading_days[-60]
        vs_ids = [vs[0] for vs in sc.query(VStrategies.id).filter(
            VStrategies.status.in_([15, 16])
        )]

        dates = {
            'year': year,
            'month_1': month_1,
            'trading_days_20': trading_days_20,
            'trading_days_40': trading_days_40,
            'trading_days_60': trading_days_60,
            'season_1': season_1_date,

        }

        vs_agg_pnl = {}
        for k, d in dates.items():
            vs_pnls = sc.query(
                VsBase.vstrategy_id.label('vs_id'),
                func.sum(VsBase.pnl).label('pnl'),
            ).filter(
                VsBase.vstrategy_id.in_(vs_ids),
                VsBase.settle_date >= d,
                VsBase.daynight == 'DAY',
            ).group_by(
                VsBase.vstrategy_id
            )
            for p in vs_pnls:
                vs_p = vs_agg_pnl.setdefault(p.vs_id, {})
                vs_p[k] = float(p.pnl)

        sc.query(VsAggregationPnl).filter(
            VsAggregationPnl.vs_id.in_(vs_ids)
        ).delete(
            synchronize_session=False
        )
        for vs_id, vs_pnl in vs_agg_pnl.items():
            for k, _pnl in vs_pnl.items():
                p = VsAggregationPnl(
                    vs_id=vs_id,
                    agg_key=k,
                    pnl=_pnl
                )
                sc.add(p)
        sc.commit()
        sc.close()
        del_cache('vs_aggregation_pnl')
        return True

    @staticmethod
    def get_aggregation_pnl(cache=True):
        cache_key = 'vs_aggregation_pnl'
        if cache:
            data = get_cache(cache_key)
            if data:
                return data
        sc = session()
        res = {
            'default': {
                'year_pnl': 0,
                'month_1_pnl': 0,
                'trading_days_20_pnl': 0,
                'trading_days_40_pnl': 0,
                'trading_days_60_pnl': 0,
                'season_1_pnl': 0,

            }
        }
        rows = sc.query(VsAggregationPnl)
        for r in rows:
            vs_pnl = res.setdefault(str(r.vs_id), {})
            vs_pnl['%s_pnl' % r.agg_key] = float(r.pnl)
        sc.close()
        set_cache(cache_key, res, 3600 * 4)
        return res

    @staticmethod
    def get_vs_aggregation_pnl(vs_ids, vs_pnl):
        if not vs_pnl:
            vs_pnl = VsAggregationPnl.get_aggregation_pnl()
        res = {
            'year_pnl': 0,
            'month_1_pnl': 0,
            'trading_days_20_pnl': 0,
            'trading_days_40_pnl': 0,
            'trading_days_60_pnl': 0,
            'season_1_pnl': 0,
            'season_1_pnl_pnl': 0,
        }
        if len(vs_ids) == 1:
            return vs_pnl.get(str(vs_ids[0]), res)
        for v_id in vs_ids:
            s_v_id = str(v_id)
            v_pnl = vs_pnl.get(s_v_id, {})
            if v_pnl:
                for k, p in v_pnl.items():
                    res[k] += p
        return res


class VsTradingVolumeRatio(ModelBase):
    """
    实盘策略市场占比
    统计实盘策略每个交易日各个合约的交易量和市场交易量之比
    股票交易 --> 实盘绩效 --> 市场占比
    """
    __tablename__ = 'trading_volume_ratio_vs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    vs_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)
    symbol = Column(VARCHAR(32), nullable=False)
    volume = Column(DOUBLE, nullable=False)
    market_volume = Column(DOUBLE, nullable=False)
    volume_percent = Column(DOUBLE, nullable=False, default=0)
    trade_vol_percent = Column(DOUBLE, nullable=False, default=0)
    start_time = Column(INTEGER, nullable=False, default=0)
    end_time = Column(INTEGER, nullable=False, default=0)
    time_range = Column(INTEGER, nullable=False, default=0)

    @staticmethod
    def get_vwap_results(vs_id, trading_date):
        from service.vwap.models import VwapResult
        sc = session()
        rows = sc.query(VwapResult).filter(
            VwapResult.vstrategy_id == vs_id,
            VwapResult.trading_date == trading_date
        )

        columns = [
            'trading_date',
            'symbol',
            'ParentOrderSize',
            'FilledRate',
            'MktDurationVolume',
            'ExecVWAP',
            'start_time',
            'end_time',
        ]

        values = []
        for r in rows:
            values.append([
                trading_date,
                r.symbol,
                r.parent_order_size,
                float(r.filled_rate),
                float(r.mkt_duration_vol),
                float(r.exec_vwap),
                r.start_time,
                r.end_time,
            ])
        sc.close()
        return {
            'values': values,
            'columns': columns,
        }

    @staticmethod
    def genarate_mkt_volume_ratio(vs_id, trading_date):
        vwap_result = VsTradingVolumeRatio.get_vwap_results(vs_id, trading_date)
        vwap_result_df = pd.DataFrame(vwap_result['values'], columns=vwap_result['columns'])
        vwap_result_df['MktVolumeRatio'] = vwap_result_df['ParentOrderSize'] * vwap_result_df['FilledRate'] / \
                                           vwap_result_df['MktDurationVolume']
        tenquantile_ratio = vwap_result_df['MktVolumeRatio'].quantile(0.9)
        max_ratio = vwap_result_df['MktVolumeRatio'].max()
        if np.isnan(max_ratio) or np.isnan(tenquantile_ratio):
            return True
        sc = session()
        try:
            sc.query(VsTradingVolumeRatio).filter(
                VsTradingVolumeRatio.vs_id == vs_id,
                VsTradingVolumeRatio.trading_date == trading_date
            ).delete()
            sc.query(VsTradingVolumeRatioStatistic).filter(
                VsTradingVolumeRatioStatistic.vs_id == vs_id,
                VsTradingVolumeRatioStatistic.trading_date == trading_date
            ).delete()
            sc.commit()

            total_assets = sc.query(
                VsBase.daynight, VsBase.total_asset
            ).filter(
                VsBase.settle_date == trading_date,
                VsBase.vstrategy_id == vs_id
            )
            vs_total_asset = 0
            for t in total_assets:
                if t[0] == 'NIGHT':
                    vs_total_asset = float(t[1])
                    break
                vs_total_asset = float(t[1])

            if not vs_total_asset:
                vs_total_asset = float(sc.query(func.sum(VStrategyAccountDetail.amount)).filter(
                    VStrategyAccountDetail.vstrategy_id == vs_id
                ).first())
            trade_vol_percent_5 = 0
            trade_vol_percent_10 = 0
            for _, r in vwap_result_df.iterrows():
                s_t_percent = r['ParentOrderSize'] * r['FilledRate'] * r['ExecVWAP'] / vs_total_asset
                if r['MktVolumeRatio'] >= 0.05:
                    trade_vol_percent_5 += s_t_percent
                if r['MktVolumeRatio'] >= 0.1:
                    trade_vol_percent_10 += s_t_percent
                v = VsTradingVolumeRatio(
                    vs_id=vs_id,
                    trading_date=trading_date,
                    symbol=r['symbol'],
                    volume=float(r['ParentOrderSize'] * r['FilledRate']),
                    market_volume=r['MktDurationVolume'],
                    volume_percent=r['MktVolumeRatio'],
                    trade_vol_percent=s_t_percent,
                    start_time=r['start_time'],
                    end_time=r['end_time'],
                )
                sc.add(v)
            v_s = VsTradingVolumeRatioStatistic(
                vs_id=vs_id,
                trading_date=trading_date,
                max_volume_percent=float(max_ratio),
                tenq_volume_percent=float(tenquantile_ratio),
                trade_vol_percent_5=trade_vol_percent_5,
                trade_vol_percent_10=trade_vol_percent_10,
            )
            sc.add(v_s)
            sc.commit()
        except Exception as e:
            sentry.captureException()
        sc.close()
        return True

    @staticmethod
    def generate_history_data():
        from service.vwap.models import VwapResult
        sc = session()
        rows = sc.query(VwapResult.vstrategy_id, VwapResult.trading_date).order_by(
            VwapResult.vstrategy_id.desc(), VwapResult.trading_date.desc()
        ).distinct().all()
        sc.close()
        for r in rows:
            try:
                VsTradingVolumeRatio.genarate_mkt_volume_ratio(r[0], r[1].strftime('%Y%m%d'))
            except Exception as e:
                sentry.captureException()
        return True


class VsTradingVolumeRatioStatistic(ModelBase):
    """
    实盘策略市场占比
    统计实盘策略每个交易日各个合约的交易量和市场交易量之比
    股票交易 --> 实盘绩效 --> 市场占比
    """
    __tablename__ = 'trading_volume_ratio_statistic_vs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    vs_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)
    max_volume_percent = Column(DOUBLE, nullable=False, default=0)  # 市场占比最大值
    tenq_volume_percent = Column(DOUBLE, nullable=False, default=0)  # 市场占比10分位值
    trade_vol_percent_5 = Column(DOUBLE, nullable=False, default=0)  # 市场占比超过5%  的交易额合计占总交易额的比值
    trade_vol_percent_10 = Column(DOUBLE, nullable=False, default=0)  # 市场占比超过10% 的交易额合计占总交易额的比值

    @staticmethod
    def get_max_volume_ratio(cache=True):
        pass

    @staticmethod
    def get_daily_max_volume_ratio(vs_id):
        sc = session()
        rows = sc.query(VsTradingVolumeRatioStatistic).filter(
            VsTradingVolumeRatioStatistic.vs_id == vs_id
        ).order_by(
            VsTradingVolumeRatioStatistic.trading_date.desc()
        )
        data = {
            'columns': ['trading_date', 'max_volume_percent', 'tenq_volume_percent', 'trade_vol_percent_5',
                        'trade_vol_percent_10'],
            'values': []
        }
        for r in rows:
            data['values'].append(
                [r.trading_date.strftime('%Y%m%d'), round(float(r.max_volume_percent), 3),
                 round(float(r.tenq_volume_percent), 3),
                 round(float(r.trade_vol_percent_5), 3), round(float(r.trade_vol_percent_10), 3)]
            )
        sc.close()
        return data

    @staticmethod
    def get_daily_max_volume_ratio_detail(vs_id, trading_date):
        sc = session()
        rows = sc.query(VsTradingVolumeRatio).filter(
            VsTradingVolumeRatio.vs_id == vs_id,
            VsTradingVolumeRatio.trading_date == trading_date,
        )
        data = {
            'columns': ['symbol', 'volume', 'market_volume', 'volume_percent', 'trade_vol_percent'],
            'values': []
        }

        for r in rows:
            data['values'].append(
                [r.symbol, float(r.volume), float(r.market_volume), float(r.volume_percent), float(r.trade_vol_percent)]
            )
        sc.close()
        return data


class StrategyTradingVolumeRatio(ModelBase):
    """
    回测市场占比
    股票交易 --> 策略及组合分析 --> 市场占比
    """
    __tablename__ = 'trading_volume_ratio_strategy'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    s_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)
    symbol = Column(VARCHAR(32), nullable=False)
    volume = Column(DOUBLE, nullable=False)
    market_volume = Column(DOUBLE, nullable=False)
    volume_percent = Column(DOUBLE, nullable=False, default=0)
    trade_vol_percent = Column(DOUBLE, nullable=False, default=0)
    start_time = Column(INTEGER, nullable=False, default=0)
    end_time = Column(INTEGER, nullable=False, default=0)
    time_range = Column(INTEGER, nullable=False, default=0)

    @staticmethod
    def get_strategy_vwap_time_from_parent_orders(vs_id):
        sc = session()
        res = {}
        vwap_time = sc.query(
            ParentOrder.trading_date,
            func.max(ParentOrder.start_time),
            func.max(ParentOrder.end_time),
        ).filter(
            ParentOrder.vstrategy_id == vs_id
        ).group_by(
            ParentOrder.trading_date
        ).order_by(
            ParentOrder.trading_date.desc()
        )
        for v_time in vwap_time:
            res['vwap_start'] = int(v_time[1].strftime('%H%M%S')) * 1000
            res['vwap_end'] = int(v_time[2].strftime('%H%M%S')) * 1000
            vs_vwap_time = VsVwapExecutimeTime(
                vs_id=vs_id,
                trading_date=v_time[0].strftime('%Y%m%d'),
                start_time=v_time[1].strftime('%H%M%S'),
                end_time=v_time[2].strftime('%H%M%S'),
            )
            sc.add(vs_vwap_time)
        sc.commit()
        sc.close()
        return res

    @staticmethod
    def get_strategy_vwap_time(s_id=None, vs_id=None):
        sc = session()

        if vs_id and (not s_id):
            s_id = sc.query(VStrategies.strategy_id).filter(
                VStrategies.id == vs_id
            ).first()[0]

        if vs_id:
            vwap_time = sc.query(VsVwapExecutimeTime).filter(
                VsVwapExecutimeTime.vs_id == vs_id
            ).order_by(
                VsVwapExecutimeTime.id.desc()
            ).first()
            if vwap_time:
                vwap_start = int(vwap_time.start_time) * 1000
                vwap_end = int(vwap_time.end_time) * 1000
                sc.close()
                return {
                    'vwap_start': vwap_start,
                    'vwap_end': vwap_end,
                }

        if s_id:
            vwap_time = sc.query(StrategyVwapExecutimeTime).filter(
                StrategyVwapExecutimeTime.strategy_id == s_id
            ).order_by(StrategyVwapExecutimeTime.trading_date.desc()).first()
            if vwap_time:
                vwap_start = int(vwap_time.start_time) * 1000
                vwap_end = int(vwap_time.end_time) * 1000
                sc.close()
                return {
                    'vwap_start': vwap_start,
                    'vwap_end': vwap_end,
                }

            vwap_time = sc.query(VsVwapExecutimeTime).filter(
                VsVwapExecutimeTime.vs_id.in_(
                    sc.query(VStrategies.id).filter(
                        VStrategies.strategy_id == s_id
                    )
                )
            ).order_by(
                VsVwapExecutimeTime.id.desc()
            ).first()
            if vwap_time:
                vwap_start = int(vwap_time.start_time) * 1000
                vwap_end = int(vwap_time.end_time) * 1000
                sc.close()
                return {
                    'vwap_start': vwap_start,
                    'vwap_end': vwap_end,
                }

        if vs_id:
            vwap_time = StrategyTradingVolumeRatio.get_strategy_vwap_time_from_parent_orders(vs_id)
            if vwap_time:
                sc.close()
                return vwap_time

        s = sc.query(Strategy).filter(
            Strategy.id == s_id
        ).first()
        if s.r_create_user_id == 407:
            s_name = s.name[:2].upper()
            if s_name == 'I8':
                vwap_start = 142700000
                vwap_end = 145500000
            elif s_name == 'IM':
                vwap_start = 93000000
                vwap_end = 145500000
            elif s_name == 'I1':
                vwap_start = 94800000
                vwap_end = 113000000
            else:
                sc.close()
                return {}
            sc.close()
            return {
                'vwap_start': vwap_start,
                'vwap_end': vwap_end,
            }
        elif s.r_create_user_id == 453:
            sc.close()
            return {
                'vwap_start': 93000000,
                'vwap_end': 100000000,
            }

        sc.close()
        return {}

    @staticmethod
    def generate_strategy_vwap_time():
        sc = session()

        s_ids = sc.query(
            Strategy.id.label('id'),
        ).filter(
            Strategy.node == 'back_test',
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.strategy_type.in_(consts.stock_strategy_type)
        )

        s_ids2 = sc.query(distinct(StrategyVwapExecutimeTime.strategy_id))
        s_ids2 = [s_id[0] for s_id in s_ids2]
        strategy_vwap_time = {}
        for s_id in s_ids:
            s_id = s_id.id
            if s_id in s_ids2:
                continue
            try:
                s_vwap_time = StrategyTradingVolumeRatio.get_strategy_vwap_time(s_id)
                if s_vwap_time:
                    strategy_vwap_time[s_id] = s_vwap_time
            except Exception as e:
                pass

        trading_date = datetime.datetime.now().strftime('%Y%m%d')
        for s_id, s_vwap_time in strategy_vwap_time.items():
            if s_vwap_time.get('vwap_start') and s_vwap_time.get('vwap_end'):
                s_time = StrategyVwapExecutimeTime(
                    strategy_id=s_id,
                    trading_date=trading_date,
                    start_time=s_vwap_time['vwap_start'] / 1000,
                    end_time=s_vwap_time['vwap_end'] / 1000
                )
                sc.add(s_time)

        sc.commit()
        sc.close()
        return True

    @staticmethod
    def get_my_vwap_strategy_vwap_result(s_id, trading_date, **kwargs):
        file_path = kwargs['file_path']
        trading_date = trading_date.replace('-', '').replace('.', '')
        columns = [
            'trading_date',
            'symbol',
            'ParentOrderSize',
            'FilledRate',
            'MktDurationVolume',
            'ExecVWAP',
            'start_time',
            'end_time',
        ]
        values = []
        try:
            df = pd.read_csv(os.path.join(file_path, '%s_0.csv' % trading_date))
            df['ExecVWAP'] = df['mkt_amt'] / df['mkt_vol']
            df['symbol'] = df['symbol'].apply(lambda x: str(x).zfill(6))
            for i, r in df.iterrows():
                if (not r['mkt_vol']) or math.isnan(r['ExecVWAP']):
                    continue
                values.append(
                    [
                        trading_date, r['symbol'], int(r['trade_vol']), 1, float(r['mkt_vol']), float(r['ExecVWAP']),
                        int(r['start_time'] or 0), int(r['end_time'] or 0)
                    ]
                )
        except Exception as e:
            sentry.captureException()
        return {
            'values': values,
            'columns': columns,
        }

    @staticmethod
    def get_vwap_results(s_id, trading_date):
        from service.vwap.models import StrategyVwapResult
        sc = session()

        s = sc.query(
            Strategy.detail.label('detail'),
            Strategy.r_create_user_id.label('r_create_user_id'),
            Strategy.username.label('username'),
            Strategy.id_no.label('id_no'),
            Strategy.st_uuid.label('st_uuid'),
        ).filter(
            Strategy.id == s_id
        ).first()

        if s.detail.get('trade_model') in ('MY_VWAP', 'MY_VWAP_1MIN', 'MY_VWAP_TICK'):
            file_path = os.path.join(
                config.user_nb_dir_template % (s.r_create_user_id, s.username),
                'strategy/output',
                s.id_no,
                s.st_uuid,
                'VWAP'
            )
            sc.close()
            return StrategyTradingVolumeRatio.get_my_vwap_strategy_vwap_result(s_id, trading_date, file_path=file_path)

        rows = sc.query(StrategyVwapResult).filter(
            StrategyVwapResult.strategy_id == s_id,
            StrategyVwapResult.trading_date == trading_date,
            StrategyVwapResult.config_id == 0,
        )

        columns = [
            'trading_date',
            'symbol',
            'ParentOrderSize',
            'FilledRate',
            'MktDurationVolume',
            'ExecVWAP',
            'start_time',
            'end_time',
        ]

        values = []
        for r in rows:
            values.append([
                trading_date,
                r.symbol,
                r.ParentOrderSize,
                float(r.FilledRate),
                float(r.MktDurationVolume),
                float(r.ExecVWAP),
                r.StartTime,
                r.EndTime,
            ])
        sc.close()
        return {
            'values': values,
            'columns': columns,
        }

    @staticmethod
    def fix_strategy_vwap_time_range(s_id):
        sc = session()
        trading_dates = sc.query(
            distinct(StrategyTradingVolumeRatio.trading_date)
        ).filter(
            StrategyTradingVolumeRatio.s_id == s_id
        )
        trading_dates = [d[0].strftime('%Y%m%d') for d in trading_dates]
        for d in trading_dates:
            rows = sc.query(StrategyTradingVolumeRatio).filter(
                StrategyTradingVolumeRatio.s_id == s_id,
                StrategyTradingVolumeRatio.trading_date == d
            )
            for r in rows:
                r.time_range = StrategyTradingVolumeRatio.get_time_range(r.start_time, r.end_time)
            sc.commit()
        sc.close()
        return True

    @staticmethod
    def get_time_range(start_time, end_time):

        if 95400000 <= end_time <= 100600000:
            return 1
        elif 102400000 <= end_time <= 103600000:
            return 2
        elif 105400000 <= end_time <= 110600000:
            return 3
        elif 112400000 <= end_time <= 113500000:
            return 4
        elif 132400000 <= end_time <= 133600000:
            return 5
        elif 135600000 <= end_time <= 140600000:
            return 6
        elif 142600000 <= end_time <= 143600000:
            return 7
        elif 145000000 <= end_time <= 153600000:
            return 8

        if 91600000 <= start_time <= 93600000:
            return 1
        elif 95600000 <= start_time <= 101000000:
            return 2
        elif 102400000 <= start_time <= 103600000:
            return 3
        elif 105400000 <= start_time <= 111000000:
            return 4
        elif 125400000 <= start_time <= 131000000:
            return 5
        elif 132400000 <= start_time <= 133600000:
            return 6
        elif 135600000 <= start_time <= 140600000:
            return 7
        elif 142600000 <= start_time <= 143600000:
            return 8

        if (91600000 <= start_time) and (end_time <= 100600000):
            return 1
        elif (95600000 <= start_time) and (end_time <= 103600000):
            return 2
        elif (102400000 <= start_time) and (end_time <= 110600000):
            return 3
        elif (105400000 <= start_time) and (end_time <= 113500000):
            return 4
        elif (125400000 <= start_time) and (end_time <= 133600000):
            return 5
        elif (132400000 <= start_time) and (end_time <= 140600000):
            return 6
        elif (135600000 <= start_time) and (end_time <= 143600000):
            return 7
        elif (142600000 <= start_time) and (end_time <= 153600000):
            return 8

        return 0

    @staticmethod
    def genarate_mkt_volume_ratio(s_id, trading_date):
        try:
            vwap_result = StrategyTradingVolumeRatio.get_vwap_results(s_id, trading_date)
            vwap_result_df = pd.DataFrame(vwap_result['values'], columns=vwap_result['columns'])
            vwap_result_df['MktVolumeRatio'] = vwap_result_df['ParentOrderSize'] * vwap_result_df['FilledRate'] / \
                                               vwap_result_df['MktDurationVolume']
            tenquantile_ratio = vwap_result_df['MktVolumeRatio'].quantile(0.9)
            max_ratio = vwap_result_df['MktVolumeRatio'].max()
            if np.isnan(max_ratio) or np.isinf(max_ratio) or np.isnan(tenquantile_ratio):
                return True
        except Exception as e:
            sentry.captureException()
            return False
        sc = session()
        try:
            sc.query(StrategyTradingVolumeRatio).filter(
                StrategyTradingVolumeRatio.s_id == s_id,
                StrategyTradingVolumeRatio.trading_date == trading_date
            ).delete()
            sc.query(StrategyTradingVolumeRatioStatistic).filter(
                StrategyTradingVolumeRatioStatistic.s_id == s_id,
                StrategyTradingVolumeRatioStatistic.trading_date == trading_date
            ).delete()
            sc.commit()

            total_assets = sc.query(StrategyResult.total_asset).filter(
                StrategyResult.strategy_id == s_id,
                StrategyResult.date == trading_date,
            ).first()
            if total_assets:
                if total_assets[0]:
                    total_assets = float(total_assets[0])
                else:
                    total_assets = float('inf')
            else:
                total_assets = float('inf')

            trade_vol_percent_5 = 0
            trade_vol_percent_10 = 0

            for _, r in vwap_result_df.iterrows():
                s_t_percent = r['ParentOrderSize'] * r['FilledRate'] * r['ExecVWAP'] / total_assets
                if r['MktVolumeRatio'] >= 0.05:
                    trade_vol_percent_5 += s_t_percent
                if r['MktVolumeRatio'] >= 0.1:
                    trade_vol_percent_10 += s_t_percent

                time_range = StrategyTradingVolumeRatio.get_time_range(
                    r['start_time'], r['end_time']
                )

                v = StrategyTradingVolumeRatio(
                    s_id=s_id,
                    trading_date=trading_date,
                    symbol=r['symbol'],
                    volume=float(r['ParentOrderSize'] * r['FilledRate']),
                    market_volume=r['MktDurationVolume'],
                    volume_percent=r['MktVolumeRatio'],
                    trade_vol_percent=s_t_percent,
                    start_time=r['start_time'],
                    end_time=r['end_time'],
                    time_range=time_range,
                )
                sc.add(v)
            v_s = StrategyTradingVolumeRatioStatistic(
                s_id=s_id,
                trading_date=trading_date,
                max_volume_percent=float(max_ratio),
                tenq_volume_percent=float(tenquantile_ratio),
                trade_vol_percent_5=trade_vol_percent_5,
                trade_vol_percent_10=trade_vol_percent_10,
            )
            sc.add(v_s)
            sc.commit()
        except Exception as e:
            sentry.captureException()
        sc.close()
        StrategyTradingVolumeRatioStatistic.update_strategy_max_volume_ratio(s_id)
        return True

    @staticmethod
    def generate_history_data():
        from service.vwap.models import StrategyVwapResult
        sc = session()
        rows = sc.query(StrategyVwapResult.strategy_id, StrategyVwapResult.trading_date).order_by(
            StrategyVwapResult.strategy_id.desc(), StrategyVwapResult.trading_date.desc()
        ).distinct().all()
        sc.close()
        for r in rows:
            try:
                StrategyTradingVolumeRatio.genarate_mkt_volume_ratio(r[0], r[1].strftime('%Y%m%d'))
            except Exception as e:
                sentry.captureException()
        return True

    @staticmethod
    def generate_history_data_mutil_process():
        from service.vwap.models import StrategyVwapResult
        from multiprocessing import Pool
        sc = session()
        rows = sc.query(StrategyVwapResult.strategy_id, StrategyVwapResult.trading_date).order_by(
            StrategyVwapResult.strategy_id.desc(), StrategyVwapResult.trading_date.desc()
        ).distinct().all()
        sc.close()
        with Pool(processes=16) as pool:
            for r in rows:
                pool.apply_async(StrategyTradingVolumeRatio.genarate_mkt_volume_ratio, [r[0], r[1].strftime('%Y%m%d')])
            pool.close()
            pool.join()

        return True


class StrategyTradingVolumeRatioStatistic(ModelBase):
    """
    回测市场占比
    股票交易 --> 策略及组合分析 --> 市场占比
    """
    __tablename__ = 'trading_volume_ratio_statistic_strategy'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    s_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)
    max_volume_percent = Column(DOUBLE, nullable=False, default=0)
    tenq_volume_percent = Column(DOUBLE, nullable=False, default=0)
    trade_vol_percent_5 = Column(DOUBLE, nullable=False, default=0)
    trade_vol_percent_10 = Column(DOUBLE, nullable=False, default=0)

    @staticmethod
    def get_max_volume_ratio(cache=True):
        cache_key = 'trading_volume_ratio_statistic_strategy'
        if cache:
            data = get_cache(cache_key)
            if data:
                return data
        sc = session()
        rows = sc.query(
            StrategyTradingVolumeRatioStatistic.s_id,
            func.max(StrategyTradingVolumeRatioStatistic.tenq_volume_percent),
            func.max(StrategyTradingVolumeRatioStatistic.trade_vol_percent_5),
            func.max(StrategyTradingVolumeRatioStatistic.trade_vol_percent_10),
        ).group_by(
            StrategyTradingVolumeRatioStatistic.s_id
        )
        data = {
            str(r[0]): {
                'tenq_volume_percent': round(float(r[1]), 3),
                'trade_vol_percent_5': round(float(r[2]), 3),
                'trade_vol_percent_10': round(float(r[3]), 3),
            } for r in rows}
        if data:
            set_cache(cache_key, data, 86400)
        sc.close()
        return data

    @staticmethod
    def update_strategy_max_volume_ratio(s_id):
        cache_key = 'trading_volume_ratio_statistic_strategy'
        data = get_cache(cache_key) or {}
        sql = """
            select tenq_volume_percent, trade_vol_percent_5, trade_vol_percent_10
            from trading_volume_ratio_statistic_strategy
            where s_id={s_id};
        """.format(s_id=s_id)
        try:
            df1 = pd.read_sql_query(sql, engine)
            tenq_volume_percent = df1['tenq_volume_percent'].quantile(0.95)
            trade_vol_percent_5 = df1['trade_vol_percent_5'].quantile(0.95)
            trade_vol_percent_10 = df1['trade_vol_percent_10'].quantile(0.95)
            data[str(s_id)] = {
                'tenq_volume_percent': round(float(tenq_volume_percent), 3),
                'trade_vol_percent_5': round(float(trade_vol_percent_5), 3),
                'trade_vol_percent_10': round(float(trade_vol_percent_10), 3),
            }
        except Exception as e:
            sentry.captureException()
        if data:
            set_cache(cache_key, data, 86400 * 3)
        return True

    @staticmethod
    def get_daily_max_volume_ratio(s_id):
        sc = session()

        start_date = sc.query(Strategy.start_date).filter(
            Strategy.id == s_id
        ).first()

        start_date = start_date and start_date[0] or '21000101'

        rows = sc.query(StrategyTradingVolumeRatioStatistic).filter(
            StrategyTradingVolumeRatioStatistic.s_id == s_id,
            StrategyTradingVolumeRatioStatistic.trading_date >= start_date,
        ).order_by(
            StrategyTradingVolumeRatioStatistic.trading_date.desc()
        )
        data = {
            'columns': ['trading_date', 'max_volume_percent', 'tenq_volume_percent', 'trade_vol_percent_5',
                        'trade_vol_percent_10'],
            'values': []
        }
        for r in rows:
            data['values'].append(
                [r.trading_date.strftime('%Y%m%d'), round(float(r.max_volume_percent), 3),
                 round(float(r.tenq_volume_percent), 3),
                 round(float(r.trade_vol_percent_5), 3), round(float(r.trade_vol_percent_10), 3)]
            )
        sc.close()
        return data

    @staticmethod
    def get_daily_max_volume_ratio_detail(s_id, trading_date):
        sc = session()
        rows = sc.query(StrategyTradingVolumeRatio).filter(
            StrategyTradingVolumeRatio.s_id == s_id,
            StrategyTradingVolumeRatio.trading_date == trading_date,
        )
        data = {
            'columns': ['symbol', 'volume', 'market_volume', 'volume_percent', 'trade_vol_percent'],
            'values': []
        }

        for r in rows:
            data['values'].append(
                [r.symbol, float(r.volume), float(r.market_volume), float(r.volume_percent), float(r.trade_vol_percent)]
            )
        sc.close()
        return data

    @staticmethod
    def gen_portfolio_daily_max_volume_ratio(s_ids):
        if not s_ids:
            return True
        s_ids = sorted(s_ids)
        sc = session()
        trading_dates = sc.query(distinct(StrategyTradingVolumeRatio.trading_date)).filter(
            StrategyTradingVolumeRatio.s_id.in_(s_ids)
        )
        trading_dates = [d[0].strftime('%Y%m%d') for d in trading_dates]
        s_cash, s_weight = {}, {}
        for s in sc.query(Strategy).filter(Strategy.id.in_(s_ids)):
            s_cash[s.id] = s.detail.get('initial_cash', 1000000) or 1000000
        sum_cash = sum(s_cash.values())
        for s_id in s_ids:
            s_weight[s_id] = float(s_cash.get(s_id, 0)) / sum_cash
        sc.close()

        s_ids_str = ','.join(map(str, s_ids))

        data = {
            'columns': ['trading_date', 'max_volume_percent', 'tenq_volume_percent', 'trade_vol_percent_5',
                        'trade_vol_percent_10'],
            'values': []
        }
        res = pd.DataFrame(
            [],
            columns=data['columns']
        )
        pickle_file_path = os.path.join(
            config.media,
            'platform_strategy_volume_ratio'
        )
        if not os.path.exists(pickle_file_path):
            os.makedirs(pickle_file_path)

        pickle_file = os.path.join(pickle_file_path, '%s.pickle' % '_'.join(map(str, s_ids)))

        total_days = len(trading_dates)

        _update_weight = lambda row: row['tp'] * s_weight.get(row['s_id'], 0)
        _update_time_range = lambda x: str(int(x))

        for i, d in enumerate(trading_dates):
            try:

                sql = """
                    select s_id, symbol, time_range,
                           volume_percent as vp,
                           trade_vol_percent as tp
                           from trading_volume_ratio_strategy
                           where s_id in ({s_ids_str}) and trading_date={trading_date}
                """.format(s_ids_str=s_ids_str, trading_date=d)
                df = pd.read_sql_query(sql, engine)
                df['tp2'] = df.apply(_update_weight, axis=1)
                df['time_range'] = df['time_range'].apply(_update_time_range)
                df_group_by = df.groupby(['symbol', 'time_range'])
                df_group_by_sum = df_group_by['vp', 'tp2'].sum()
                tenquantile_ratio = round(float(df_group_by_sum['vp'].quantile(0.9)), 3)
                max_ratio = round(float(df_group_by_sum['vp'].max()), 3)
                trade_vol_percent_5 = 0
                trade_vol_percent_10 = 0
                for _, row in df_group_by_sum.iterrows():
                    if row['vp'] >= 0.05:
                        trade_vol_percent_5 += row['tp2']
                    if row['vp'] >= 0.1:
                        trade_vol_percent_10 += row['tp2']
                r = [d, max_ratio, tenquantile_ratio, round(float(trade_vol_percent_5), 3),
                     round(float(trade_vol_percent_10), 3)]
                data['values'].append(r)
                process = [['Process', round((i + 1) / total_days, 2), 0, 0, 0]]
                res = pd.DataFrame(
                    data['values'] + process,
                    columns=data['columns']
                )
                res.to_pickle(pickle_file)
            except Exception as e:
                sentry.captureException()
        return True

    @staticmethod
    def get_portfolio_daily_max_volume_ratio(s_ids):
        data = {
            'columns': ['trading_date', 'max_volume_percent', 'tenq_volume_percent', 'trade_vol_percent_5',
                        'trade_vol_percent_10'],
            'values': [],
            'process': 0,
        }
        s_ids = sorted(s_ids)
        if not s_ids:
            return data

        pickle_file_path = os.path.join(
            config.media,
            'platform_strategy_volume_ratio'
        )

        pickle_file = os.path.join(pickle_file_path, '%s.pickle' % '_'.join(map(str, s_ids)))
        try:
            df = pd.read_pickle(pickle_file)
            df = df[data['columns']]
            for i, row in df.iterrows():
                if row['trading_date'] not in ('Process', b'Process'):
                    data['values'].append(row.tolist())
                else:
                    data['process'] = row['max_volume_percent']
        except Exception as e:
            sentry.captureException()
        return data

    @staticmethod
    def get_portfolio_daily_max_volume_ratio_detail(s_ids, trading_date):
        sc = session()
        rows = sc.query(StrategyTradingVolumeRatio).filter(
            StrategyTradingVolumeRatio.s_id.in_(s_ids),
            StrategyTradingVolumeRatio.trading_date == trading_date,
        )
        data = {
            'columns': [
                'symbol', 's_id', 'start_time', 'end_time', 'volume',
                'market_volume', 'volume_percent', 'strategy_percent', 'portfolio_percent'
            ],
            'values': []
        }
        strategies = sc.query(
            Strategy.id.label('id'),
            Strategy.id_no.label('id_no'),
            Strategy.detail.label('detail')
        ).filter(
            Strategy.id.in_(s_ids)
        )
        s_detail = {}
        sum_cash = 0
        for s in strategies:
            s_detail[s.id] = {
                'id_no': s.id_no,
                'cash': s.detail.get('initial_cash', 1000000) or 1000000,
                'weight': 1,
            }
            sum_cash += s_detail[s.id]['cash']
        if sum_cash:
            for s_id, s_d in s_detail.items():
                s_d['weight'] = float(s_d['cash']) / sum_cash

        for r in rows:
            data['values'].append(
                [
                    r.symbol, s_detail[r.s_id]['id_no'], r.start_time, r.end_time, float(r.volume),
                    float(r.market_volume), round(float(r.volume_percent), 6), round(float(r.trade_vol_percent), 6),
                    round(float(r.trade_vol_percent) * s_detail[r.s_id]['weight'], 6)
                ]
            )
        sc.close()
        return data


class VsBacktestTradingVolumeRatio(ModelBase):
    """
    盘后分析市场占比
    """
    __tablename__ = 'trading_volume_ratio_vs_back_test'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    vs_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)
    symbol = Column(VARCHAR(32), nullable=False)
    volume = Column(DOUBLE, nullable=False)
    market_volume = Column(DOUBLE, nullable=False)
    volume_percent = Column(DOUBLE, nullable=False, default=0)
    trade_vol_percent = Column(DOUBLE, nullable=False, default=0)
    start_time = Column(INTEGER, nullable=False, default=0)
    end_time = Column(INTEGER, nullable=False, default=0)
    time_range = Column(INTEGER, nullable=False, default=0)

    @staticmethod
    def get_vwap_results(vs_id, trading_date):
        from service.vwap.models import VsVwapResult
        sc = session()
        rows = sc.query(VsVwapResult).filter(
            VsVwapResult.vstrategy_id == vs_id,
            VsVwapResult.trading_date == trading_date
        )

        columns = [
            'trading_date',
            'symbol',
            'ParentOrderSize',
            'FilledRate',
            'MktDurationVolume',
            'ExecVWAP',
            'start_time',
            'end_time',
        ]

        values = []
        for r in rows:
            values.append([
                trading_date,
                r.symbol,
                r.ParentOrderSize,
                float(r.FilledRate),
                float(r.MktDurationVolume),
                float(r.ExecVWAP),
                r.StartTime,
                r.EndTime,
            ])
        sc.close()
        return {
            'values': values,
            'columns': columns,
        }

    @staticmethod
    def genarate_mkt_volume_ratio(vs_id, trading_date):
        try:
            vwap_result = VsBacktestTradingVolumeRatio.get_vwap_results(vs_id, trading_date)
            vwap_result_df = pd.DataFrame(vwap_result['values'], columns=vwap_result['columns'])
            vwap_result_df['MktVolumeRatio'] = vwap_result_df['ParentOrderSize'] * vwap_result_df['FilledRate'] / \
                                               vwap_result_df['MktDurationVolume']
            tenquantile_ratio = vwap_result_df['MktVolumeRatio'].quantile(0.9)
            max_ratio = vwap_result_df['MktVolumeRatio'].max()
            if np.isnan(max_ratio) or np.isnan(tenquantile_ratio):
                return True
        except Exception as e:
            sentry.captureException()
            return False
        sc = session()
        try:
            sc.query(VsBacktestTradingVolumeRatio).filter(
                VsBacktestTradingVolumeRatio.vs_id == vs_id,
                VsBacktestTradingVolumeRatio.trading_date == trading_date
            ).delete()
            sc.query(VsBacktestTradingVolumeRatioStatistic).filter(
                VsBacktestTradingVolumeRatioStatistic.vs_id == vs_id,
                VsBacktestTradingVolumeRatioStatistic.trading_date == trading_date
            ).delete()
            sc.commit()

            # trade_vols = sc.query(
            #     BackTestTradeLogs.symbol.label('sym'),
            #     func.sum(
            #         BackTestTradeLogs.trade_vol * BackTestTradeLogs.trade_price
            #     ).label('trade_sum')
            # ).filter(
            #     BackTestTradeLogs.trading_date == trading_date,
            #     BackTestTradeLogs.vstrategy_id == vs_id,
            #     BackTestTradeLogs.msg_type == '3',
            #     BackTestTradeLogs.entrust_status.in_(['p', 'c'])
            # ).group_by(
            #     BackTestTradeLogs.symbol
            # )
            # symbol_trade_vol = {t.sym: float(t.trade_sum) for t in trade_vols}

            total_assets = sc.query(
                VstrategyBackTestResult.day_night,
                VstrategyBackTestResult.total_asset
            ).filter(
                VstrategyBackTestResult.vstrategy_id == vs_id,
                VstrategyBackTestResult.trading_date == trading_date,
            )

            vs_total_asset = 0
            for t in total_assets:
                if t[0] == 1:
                    vs_total_asset = float(t[1])
                    break
                vs_total_asset = float(t[1])

            if not vs_total_asset:
                vs_total_asset = float(sc.query(func.sum(VStrategyAccountDetail.amount)).filter(
                    VStrategyAccountDetail.vstrategy_id == vs_id
                ).first())

            trade_vol_percent_5 = 0
            trade_vol_percent_10 = 0

            for _, r in vwap_result_df.iterrows():
                s_t_percent = r['ParentOrderSize'] * r['FilledRate'] * r['ExecVWAP'] / vs_total_asset
                if r['MktVolumeRatio'] >= 0.05:
                    trade_vol_percent_5 += s_t_percent
                if r['MktVolumeRatio'] >= 0.1:
                    trade_vol_percent_10 += s_t_percent

                v = VsBacktestTradingVolumeRatio(
                    vs_id=vs_id,
                    trading_date=trading_date,
                    symbol=r['symbol'],
                    volume=float(r['ParentOrderSize'] * r['FilledRate']),
                    market_volume=r['MktDurationVolume'],
                    volume_percent=r['MktVolumeRatio'],
                    trade_vol_percent=s_t_percent,
                    start_time=r['start_time'],
                    end_time=r['end_time'],
                )
                sc.add(v)
            v_s = VsBacktestTradingVolumeRatioStatistic(
                vs_id=vs_id,
                trading_date=trading_date,
                max_volume_percent=float(max_ratio),
                tenq_volume_percent=float(tenquantile_ratio),
                trade_vol_percent_5=trade_vol_percent_5,
                trade_vol_percent_10=trade_vol_percent_10,
            )
            sc.add(v_s)
            sc.commit()
        except Exception as e:
            sentry.captureException()
        sc.close()
        return True

    @staticmethod
    def generate_history_data():
        from service.vwap.models import VsVwapResult
        sc = session()
        rows = sc.query(VsVwapResult.vstrategy_id, VsVwapResult.trading_date).order_by(
            VsVwapResult.vstrategy_id.desc(), VsVwapResult.trading_date.desc()
        ).distinct().all()
        sc.close()
        for r in rows:
            try:
                VsBacktestTradingVolumeRatio.genarate_mkt_volume_ratio(r[0], r[1].strftime('%Y%m%d'))
            except Exception as e:
                sentry.captureException()
        return True


class VsBacktestTradingVolumeRatioStatistic(ModelBase):
    """
    盘后分析市场占比
    """
    __tablename__ = 'trading_volume_ratio_statistic_vs_back_test'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    vs_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)
    max_volume_percent = Column(DOUBLE, nullable=False, default=0)
    tenq_volume_percent = Column(DOUBLE, nullable=False, default=0)
    trade_vol_percent_5 = Column(DOUBLE, nullable=False, default=0)
    trade_vol_percent_10 = Column(DOUBLE, nullable=False, default=0)

    @staticmethod
    def get_max_volume_ratio(cache=True):
        pass

    @staticmethod
    def get_daily_max_volume_ratio(vs_id):
        sc = session()
        rows = sc.query(VsBacktestTradingVolumeRatioStatistic).filter(
            VsBacktestTradingVolumeRatioStatistic.vs_id == vs_id
        ).order_by(
            VsBacktestTradingVolumeRatioStatistic.trading_date.desc()
        )
        data = {
            'columns': ['trading_date', 'max_volume_percent', 'tenq_volume_percent', 'trade_vol_percent_5',
                        'trade_vol_percent_10'],
            'values': []
        }
        for r in rows:
            data['values'].append(
                [r.trading_date.strftime('%Y%m%d'), round(float(r.max_volume_percent), 3),
                 round(float(r.tenq_volume_percent), 3),
                 round(float(r.trade_vol_percent_5), 3), round(float(r.trade_vol_percent_10), 3)]
            )
        sc.close()
        return data

    @staticmethod
    def get_daily_max_volume_ratio_detail(vs_id, trading_date):
        sc = session()
        rows = sc.query(VsBacktestTradingVolumeRatio).filter(
            VsBacktestTradingVolumeRatio.vs_id == vs_id,
            VsBacktestTradingVolumeRatio.trading_date == trading_date,
        )
        data = {
            'columns': ['symbol', 'volume', 'market_volume', 'volume_percent', 'trade_vol_percent'],
            'values': []
        }

        for r in rows:
            data['values'].append(
                [r.symbol, float(r.volume), float(r.market_volume), float(r.volume_percent), float(r.trade_vol_percent)]
            )
        sc.close()
        return data


class VsLiveRangePerformance(ModelBase):
    __tablename__ = 'vs_live_range_performance'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vs_ids = Column(VARCHAR(1024), nullable=False, index=True)
    group_key = Column(VARCHAR(255), nullable=False, index=True)
    start_date = Column(DATE, nullable=True)
    end_date = Column(DATE, nullable=True)

    sharpe = Column(DOUBLE, nullable=False)
    annual_return = Column(DOUBLE, nullable=False)
    profitrate = Column(DOUBLE, nullable=False)
    max_drawdown_pnl = Column(DOUBLE, nullable=False)

    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    valid = Column(BOOLEAN, nullable=False, default=True)


class StrategyBackTestTradeIndicator(ModelBase):
    __tablename__ = 'strategy_back_test_trade_indicator'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    s_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)

    daily_stock_number = Column(DOUBLE, nullable=False)
    liquidity = Column(DOUBLE, nullable=False)
    withdraw_rate = Column(DOUBLE, nullable=False)
    short_notional = Column(DOUBLE, nullable=False)
    n_trade = Column(DOUBLE, nullable=False)
    n_cancel = Column(DOUBLE, nullable=False)

    @staticmethod
    def cal_daily_ind(s_id, trading_date, **kwargs):
        sc = session()
        s = sc.query(
            Strategy.id.label('id'),
            Strategy.username.label('username'),
            Strategy.start_date.label('start_date'),
            Strategy.st_uuid.label('st_uuid'),
            Strategy.strategy_type.label('strategy_type'),
            Strategy.detail.label('detail'),
        ).filter(
            Strategy.id == s_id
        ).first()
        filepath = os.path.join(
            config.media,
            'strategy_back_test_logs',
            s.username,
            str(s.id),
            s.st_uuid,
        )
        pkl_file_path = os.path.join(filepath, '%s.pkl' % trading_date)
        init_cash = s.detail.get('initial_cash', 1000000) or 1000000
        try:
            df = pd.read_pickle(pkl_file_path)
        except Exception as e:
            sc.close()
            sentry.captureException()
            return False
        if df.empty:
            sc.close()
            return True
        short_notional, total_order_num, total_cancel_num = 0, 0, 0
        # liquidity = 0
        withdraw_rate = 0
        try:

            for i, r in df.iterrows():
                # 国债逆回购
                if r['symbol'] in ('204001', '131810'):
                    continue
                if r['msg_type'] == '3' and r['direction'] == 1:
                    short_notional += r['trade_vol'] * r['trade_price']
                if r['msg_type'] == '1' and r['entrust_status'] == 'a':
                    total_order_num += 1
                if r['entrust_status'] == 'd':
                    total_cancel_num += 1

            if total_order_num:
                withdraw_rate = float(total_cancel_num) / total_order_num

            liquidity = short_notional / init_cash

        except Exception as e:
            sc.close()
            sentry.captureException()
            return False

        daily_stock_number = 0
        sql2 = """select trading_date, count(1) from backtest_result_detail
        where strategy_id={strategy_id} and trading_date={trading_date}
        and day_night=0 and (long_volume> 0 or short_volume>0);
        """.format(strategy_id=s_id, trading_date=trading_date)
        rows2 = sc.execute(sql2)
        sym_counts = []
        for r in rows2:
            sym_counts.append(r[1])
        if sym_counts:
            daily_stock_number = sum(sym_counts) / len(sym_counts)

        ind = sc.query(
            StrategyBackTestTradeIndicator
        ).filter(
            StrategyBackTestTradeIndicator.s_id == s_id,
            StrategyBackTestTradeIndicator.trading_date == trading_date
        ).first()
        if not ind:
            ind = StrategyBackTestTradeIndicator(
                s_id=s_id,
                trading_date=trading_date,
                daily_stock_number=daily_stock_number,
                liquidity=liquidity,
                withdraw_rate=withdraw_rate,
                short_notional=short_notional,
                n_trade=total_order_num,
                n_cancel=total_cancel_num
            )
            sc.add(ind)
        else:
            ind.daily_stock_number = daily_stock_number
            ind.liquidity = liquidity
            ind.withdraw_rate = withdraw_rate
            ind.short_notional = short_notional
            ind.n_trade = total_order_num
            ind.n_cancel = total_cancel_num
        sc.commit()
        sc.close()
        return True


class PortfolioRiskAttribute(ModelBase):
    __tablename__ = 'portfolio_risk_attribute'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_ids = Column(VARCHAR(256), nullable=False, index=True)
    trading_date = Column(VARCHAR(10), nullable=False, index=True)
    max_w_800 = Column(DOUBLE, nullable=False, default=0)
    non800_max_w = Column(DOUBLE, nullable=False, default=0)
    non800_ratio = Column(DOUBLE, nullable=False, default=0)
    startup_w = Column(DOUBLE, nullable=False, default=0)
    FVbelow14_w = Column(DOUBLE, nullable=False, default=0)
    TolValue = Column(DOUBLE, nullable=False, default=0)
    FloatValue = Column(DOUBLE, nullable=False, default=0)
    non800_top30_max_w = Column(DOUBLE, nullable=False, default=0)
    noncsi800_nontop30_max_w = Column(DOUBLE, nullable=False, default=0)
    top20_value_w = Column(DOUBLE, nullable=False, default=0)
    daily_stock_number = Column(DOUBLE, nullable=False, default=0)
    liquidity = Column(DOUBLE, nullable=False, default=0)
    withdraw_rate = Column(DOUBLE, nullable=False, default=0)
    industry_max_w = Column(DOUBLE, nullable=False, default=0)

    @staticmethod
    def generate_strategy_portfolio_risk(s_ids, **kwargs):
        from service.statistic.portfolio_risk_attribute import PortfolioRisk
        try:
            p = PortfolioRisk(None, s_ids=s_ids)
            p.run()
        except Exception as e:
            sentry.captureException()

    @staticmethod
    def generate_vs_portfolio_risk(vs_ids, **kwargs):
        from service.statistic.portfolio_risk_attribute import VsPortfolioRisk
        try:
            p = VsPortfolioRisk(vs_ids=vs_ids)
            p.run()
        except Exception as e:
            sentry.captureException()

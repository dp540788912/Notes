# -*-coding:utf-8-*-

import os
import hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from service.back_test.models import Strategy, VStrategies, VStrategyAccountDetail



from config import config


def gen_str_hash_value(s):
    md = hashlib.md5()
    md.update(str(s).encode('utf8'))
    return md.hexdigest()


class VsPnlGraph(object):

    def __init__(self, vs_ids, *args, **kwargs):
        if not isinstance(vs_ids, (list, tuple)):
            self.vs_ids = [vs_ids]
        else:
            self.vs_ids = sorted(vs_ids)
        self.summary = kwargs.get('summary', False)
        self.filename = kwargs.get('filename', '')
        self.kwargs = kwargs
        if not self.filename:
            graph_path = os.path.join(config.media, 'vs_pnl_graph')
            if not os.path.exists(graph_path):
                os.makedirs(graph_path)
            vs_ids_str = gen_str_hash_value('_'.join(map(str, self.vs_ids)))
            self.filename = os.path.join(
                graph_path,
                'summary_' if self.summary else '',
                '%s_thumbnail.png' % vs_ids_str
            )

    def vs_live_pnl_net_line(self):
        pnl_details = Strategy.vs_live_pnl_detail(None, _vs_ids=self.vs_ids)
        live_combine_detail = {}
        for vs_id, live_detail in pnl_details['live_pnl'].items():
            for d, _pnl in live_detail.items():
                if d not in live_combine_detail:
                    live_combine_detail[d] = _pnl
                else:
                    live_combine_detail[d] = [live_combine_detail[d][i] + v for i, v in enumerate(_pnl)]

        live_net_combine_line = Strategy.live_net_line(
            live_combine_detail, ''
        )
        return live_net_combine_line['pnl']

    def vs_summary_live_pnl_net_line(self):
        live_pnls = [self.vs_live_pnl_net_line()]
        actual_amount_cash = VStrategyAccountDetail.get_vstrategy_cash2(
            self.vs_ids, shift=False, dateformat='%Y%m%d', is_future=self.kwargs.get('is_future')
        )
        summary_pnl = Strategy.combine_pnls(live_pnls, mode='live', cash_io=actual_amount_cash)['pnl']
        return summary_pnl

    def get_live_pnl_net(self):
        if not self.summary:
            return self.vs_live_pnl_net_line()
        else:
            return self.vs_summary_live_pnl_net_line()

    def graph(self):
        x_data, y_data = [], []
        for d, d_pnl in sorted(self.get_live_pnl_net().items(), key=lambda x: x[0]):
            x_data.append(d)
            y_data.append(d_pnl[0])
        fig = plt.figure(figsize=(1.2, 0.6), dpi=100)
        plt.plot(x_data, y_data, color='red', linewidth=1)
        plt.axis('off')
        plt.savefig(self.filename, transparent=True)
        plt.close(fig)
        return True


# -*-coding:utf-8-*-

import pandas as pd
import numpy as np
import os
import copy
from my.data import basic_func


def datetostr(date):
    # date format: 'yyyy.mm.dd...', 'yyyy-mm-dd...'
    x = str(date)
    return x[:4] + '.' + x[5:7] + '.' + x[8:10]


def tradecalendar():
    y = basic_func.get_kdb('select date:TRADE_DT  from Calendar where EXCHANGE in `SSE`SZSE', 'FuturesBasicInfo')
    y = sorted(y['date'].unique())
    y = [datetostr(x) for x in y]
    return y


calendar = tradecalendar()


def addition_tradeday(date, x):
    # date format: 'yyyy.mm.dd'
    # x: [int, ..., int]
    global calendar
    no_date = sum([1 for z in calendar if z < date])
    y = [calendar[no_date + z] for z in x]
    return y


def income_attribution(date, vwap_start, vwap_end, risk_ev_path,
                       hedging='zz500', stocklist_open=None, stocklist_close=None):
    rtn = {x: 0 for x in ['hy', 'mv', 'bt', 'bd', 'ld', 'mm', 'yl', 'jz', 'gg']}

    # date
    date_int = str(date)
    date_dot = date_int[0:4] + '.' + date_int[4:6] + '.' + date_int[6:8]

    [date_today, date_next] = addition_tradeday(date_dot, [0, 1])

    # riskfactor
    date_next_int = date_next[:4] + date_next[5:7] + date_next[8:10]
    file = 'portfolio_optimization_ev_plus_' + date_next_int + '.csv'

    ev = pd.read_csv(os.path.join(risk_ev_path, file))
    ev.loc[:, 'symbol'] = ev.loc[:, 'symbol'].apply(lambda x: x[:6]).tolist()

    weight = 'wt_' + hedging

    mv = 'mv_lnfloat_barra2_orth_' + hedging + '_gg'

    hy = 'hy_sw1'
    bt = 'bt_' + hedging + '_barra2_orth_' + hedging + '_gg'

    bd = 'bd_' + hedging + '_barra2_orth_' + hedging + '_gg'
    gg = 'gg_barra2_orth_' + hedging + '_gg'
    jz = 'jz_btop_barra2_orth_' + hedging + '_gg'
    ld = 'ld_barra2_orth_' + hedging + '_gg'
    mm = 'mm_rstr_barra2_orth_' + hedging + '_gg'
    yl = 'yl_barra2_orth_' + hedging + '_gg'

    sig_hy = [x[-3:] == 'SWS' for x in ev['hy_sw1'].tolist()]
    ev = ev.loc[sig_hy, ['symbol', weight, mv, hy, bt, bd, ld, mm, yl, jz, gg]]

    hy_columns = list(ev[hy].unique())
    hy_data = ev.loc[:, ['symbol', hy]]
    hy_data['hy_value'] = 1
    hy_data_d = hy_data.pivot_table(index='symbol', columns=hy, values='hy_value').fillna(0)
    hy_data_d.reset_index(drop=False, inplace=True)

    risk_columns = [mv, bt, bd, ld, mm, yl, jz, gg]
    exposure_matrix = pd.merge(hy_data_d, ev[['symbol', weight] + risk_columns], how='outer', on='symbol')

    exposure_matrix.fillna(0, inplace=True)

    # open price & close price
    data_close = basic_func.get_kdb('select symbol:SYMBOL, preclose:S_DQ_PRECLOSE, close:S_DQ_CLOSE ' +
                                    'from AShareEODPrices where TRADE_DT=' + date_today, 'EquityFactor')
    data_close['symbol'] = data_close.loc[:, 'symbol'].apply(lambda x: x.decode()[:6]).tolist()

    # open stock list
    if stocklist_open is None:
        list_open = pd.DataFrame(columns=['symbol', 'open_weight'])
    elif type(stocklist_open) == pd.DataFrame:
        if len(stocklist_open) > 0:
            tmp_list_open = copy.deepcopy(stocklist_open.iloc[:, :2])
            tmp_list_open.columns = ['symbol', 'size']
            tmp_list_open['symbol'] = [str(x).zfill(6) for x in list(tmp_list_open['symbol'])]
            list_open = pd.merge(tmp_list_open, data_close[['symbol', 'preclose']], how='left', on='symbol')
            list_open['money'] = list_open['size'] * list_open['preclose']
            list_open = list_open.loc[(list_open['preclose'] >= 0) & (list_open['size'] >= 0)]
            list_open['open_weight'] = list_open['money'] / sum(list_open['money'])
            list_open = list_open[['symbol', 'open_weight']]
        else:
            list_open = pd.DataFrame(columns=['symbol', 'open_weight'])
    else:
        list_open = pd.DataFrame(columns=['symbol', 'open_weight'])

    # close stock list
    if stocklist_close is None:
        list_close = pd.DataFrame(columns=['symbol', 'close_weight'])
    elif type(stocklist_close) == pd.DataFrame:
        if len(stocklist_close) > 0:
            tmp_list_close = copy.deepcopy(stocklist_close.iloc[:, :2])
            tmp_list_close.columns = ['symbol', 'size']
            tmp_list_close['symbol'] = [str(x).zfill(6) for x in list(tmp_list_close['symbol'])]
            list_close = pd.merge(tmp_list_close, data_close[['symbol', 'close']], how='left', on='symbol')
            list_close['money'] = list_close['size'] * list_close['close']
            list_close = list_close.loc[(list_close['close'] >= 0) & (list_close['size'] >= 0)]
            list_close['close_weight'] = list_close['money'] / sum(list_close['money'])
            list_close = list_close[['symbol', 'close_weight']]
        else:
            list_close = pd.DataFrame(columns=['symbol', 'close_weight'])
    else:
        list_close = pd.DataFrame(columns=['symbol', 'close_weight'])

    # return
    vwap = basic_func.get_kdb('select start:first Time, end:last Time, ' +
                              'V_start:first Volume, M_start:first Turnover, ' +
                              'V_end:last Volume, M_end:last Turnover, lastprice:last PreClosePrice ' +
                              'by symbol:WindSymbol from EquityDepth where date= ' + date_today + ' , Time within ' +
                              str(vwap_start) + ' ' + str(vwap_end), 'EquityDB')
    vwap.reset_index(inplace=True)
    vwap['symbol'] = vwap.loc[:, 'symbol'].apply(lambda x: x.decode()[:6]).tolist()
    vwap['V_diff'] = vwap['V_end'] - vwap['V_start']
    vwap['M_diff'] = vwap['M_end'] - vwap['M_start']

    sig_v_diff = (vwap['V_diff'] > 0)
    vwap['vwap'] = vwap['lastprice'] / 10000
    vwap.loc[sig_v_diff, 'vwap'] = vwap.loc[sig_v_diff, 'M_diff'] / vwap.loc[sig_v_diff, 'V_diff']

    alldata = pd.merge(data_close, vwap[['symbol', 'vwap']], how='left', on='symbol')

    sig_vwap = ~(alldata['vwap'] > 0)
    alldata.loc[sig_vwap, 'vwap'] = alldata.loc[sig_vwap, 'preclose']

    alldata['rtn_buy'] = 0
    sig_precls = (alldata['close'] > 0) & (alldata['vwap'] > 0)
    alldata.loc[sig_precls, 'rtn_buy'] = alldata.loc[sig_precls, 'close'] / alldata.loc[sig_precls, 'vwap'] - 1

    alldata['rtn_sell'] = 0
    sig_close = (alldata['preclose'] > 0) & (alldata['vwap'] > 0)
    alldata.loc[sig_close, 'rtn_sell'] = alldata.loc[sig_close, 'vwap'] / alldata.loc[sig_close, 'preclose'] - 1

    alldata = alldata[['symbol', 'rtn_buy', 'rtn_sell']]

    # combine
    alldata = pd.merge(alldata, list_close, how='outer', on='symbol')
    alldata = pd.merge(alldata, list_open, how='outer', on='symbol')
    alldata = pd.merge(alldata, exposure_matrix[['symbol', weight] + hy_columns + risk_columns],
                       how='outer', on='symbol')
    alldata.loc[~(alldata['close_weight'] > 0), 'close_weight'] = 0
    alldata.loc[~(alldata['open_weight'] > 0), 'open_weight'] = 0
    alldata.loc[~(alldata[weight] > 0), weight] = 0

    # risk factor return
    tmp_a = alldata.loc[:, ['symbol', 'rtn_buy', 'rtn_sell'] + hy_columns + risk_columns]
    tmp_a.dropna(axis=0, how='any', inplace=True)

    tmp_a['rtn_buy'] = tmp_a['rtn_buy'] - tmp_a['rtn_buy'].mean()
    tmp_a['rtn_sell'] = tmp_a['rtn_sell'] - tmp_a['rtn_sell'].mean()

    tmp_b = [x for x in hy_columns if tmp_a[x].sum() > 0.5] + risk_columns

    tmp_c = pd.DataFrame(columns=['risk_factor', 'rtn_buy_risk', 'rtn_sell_risk'])
    tmp_c['risk_factor'] = tmp_b
    tmp_x = np.mat(tmp_a[tmp_b])
    tmp_y = np.mat(tmp_a[['rtn_buy', 'rtn_sell']])
    try:
        tmp_c[['rtn_buy_risk', 'rtn_sell_risk']] = (tmp_x.T * tmp_x).I * tmp_x.T * tmp_y
    except Exception:
        for i in hy_columns:
            rtn[i] = 0
        return rtn

    risk_rtn = pd.DataFrame(columns=['risk_factor'])
    risk_rtn['risk_factor'] = hy_columns + risk_columns
    risk_rtn = pd.merge(risk_rtn, tmp_c, how='outer', on='risk_factor')
    risk_rtn.fillna(0, inplace=True)

    #
    alldata.fillna(0, inplace=True)
    alldata['close_weight_diff'] = alldata['close_weight'] - alldata[weight]
    alldata['open_weight_diff'] = alldata['open_weight'] - alldata[weight]

    risk_rtn['rtn_buy_str'] = 0
    risk_rtn['rtn_sell_str'] = 0
    for i in hy_columns + risk_columns:
        risk_rtn.loc[risk_rtn['risk_factor'] == i, 'rtn_buy_str'] = \
            sum(alldata['close_weight_diff'] * alldata[i]) * risk_rtn.loc[risk_rtn['risk_factor'] == i, 'rtn_buy_risk']
        risk_rtn.loc[risk_rtn['risk_factor'] == i, 'rtn_sell_str'] = \
            sum(alldata['open_weight_diff'] * alldata[i]) * risk_rtn.loc[risk_rtn['risk_factor'] == i, 'rtn_sell_risk']

    tmp_sig = [x[:2] in ['mv', 'bt', 'bd', 'ld', 'mm', 'yl', 'jz', 'gg'] for x in risk_rtn['risk_factor']]
    tmp_sig2 = [x is False for x in tmp_sig]
    str_rtn = risk_rtn.loc[tmp_sig, ['risk_factor', 'rtn_buy_str', 'rtn_sell_str']]
    str_rtn.loc[len(str_rtn)] = ['hy'] + risk_rtn.loc[tmp_sig2, ['rtn_buy_str', 'rtn_sell_str']].sum(axis=0).tolist()
    str_rtn['risk_factor'] = [x[:2] for x in str_rtn['risk_factor']]
    if len(list_open) < 1:
        str_rtn['rtn_sell_str'] = 0
    if len(list_close) < 1:
        str_rtn['rtn_buy_str'] = 0

    str_rtn['rtn'] = str_rtn['rtn_buy_str'] + str_rtn['rtn_sell_str']

    for i in ['hy', 'mv', 'bt', 'bd', 'ld', 'mm', 'yl', 'jz', 'gg']:
        rtn[i] = float(str_rtn.loc[str_rtn['risk_factor'] == i, 'rtn'])

    for i in hy_columns:
        rtn[i] = float(risk_rtn.loc[risk_rtn['risk_factor'] == i, ['rtn_buy_str', 'rtn_sell_str']].sum(axis=1))

    return rtn

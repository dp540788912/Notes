# -*-coding:utf-8-*-

import datetime
from sqlalchemy import or_, func
from dateutil.parser import parse

import consts
from db import session

from service.back_test.models import Strategy, VStrategies, StrategyPortfolio, \
    ResearchStrategyPortfolio, ResearchStrategyPortfolioDetail, \
    StrategyResultDetail, StockPortfolioOptimizationVersion, TradeLogs
from service.back_test.live_position_models import VsPosition, VsBase
from service.statistic.models import StrategyBackTestTradeIndicator, PortfolioRiskAttribute
from service.statistic.risk_attribute2 import risk_attribute2

import pandas as pd



class PortfolioRisk(object):

    def __init__(self, portfolio_id, **kwargs):
        self.portfolio_id = portfolio_id
        self.sc = session()
        if kwargs.get('s_ids'):
            self.s_ids = kwargs['s_ids']
        else:
            self.s_ids = [s.strategy_id for s in self.sc.query(
                ResearchStrategyPortfolioDetail
            ).filter(
                ResearchStrategyPortfolioDetail.portfolio_id == self.portfolio_id
            )]
        self.s_ids_str = '_'.join(map(str, sorted(self.s_ids)))
        strategies = self.sc.query(
            Strategy.id.label('id'),
            Strategy.detail.label('detail'),
            Strategy.start_date.label('start_date'),
            Strategy.strategy_type.label('strategy_type'),
        ).filter(
            Strategy.id.in_(self.s_ids)
        )
        self.s_detail = {}
        self.start_date = '20180101'
        alpha_s_ids = []
        optimization_version = set()
        for s in strategies:
            self.s_detail[s.id] = {
                'cash': s.detail.get('initial_cash', 1000000) or 1000000,
                'strategy_type': s.strategy_type,
                'optimization_version': s.detail.get('portfolio_optimization_so_version', ''),
            }
            if s.strategy_type not in consts.alpha_stock_strategy_type:
                continue
            alpha_s_ids.append(s.id)
            if s.detail.get('portfolio_optimization_so_version', ''):
                optimization_version.add(s.detail['portfolio_optimization_so_version'])
            self.start_date = min(self.start_date, s.start_date)
        self.s_ids = alpha_s_ids
        self.portfolio_risk = {}

        optimization_versions = self.sc.query(StockPortfolioOptimizationVersion).filter(
            StockPortfolioOptimizationVersion.value.in_(optimization_version)
        )
        top_n_sum_weight = []
        float_value_limit = []
        for v in optimization_versions:
            if v.paras:
                if v.paras.get('num_top_weight'):
                    top_n_sum_weight.append(v.paras['num_top_weight'])
                if v.paras.get('mv_threshold'):
                    float_value_limit.append(v.paras['mv_threshold'])
        if not top_n_sum_weight:
            self.top_n_sum_weight = 20
        else:
            self.top_n_sum_weight = min(top_n_sum_weight)

        if not float_value_limit:
            self.float_value_limit = 14
        else:
            self.float_value_limit = min(float_value_limit)

    def get_portfolio_position(self, s_ids, start_date):
        columns = ['trading_date', 'symbol', 'long_volume', 'long_price']
        back_test_position = self.sc.query(
            StrategyResultDetail.trading_date.label('trading_date'),
            StrategyResultDetail.symbol.label('symbol'),
            StrategyResultDetail.long_volume.label('long_volume'),
            StrategyResultDetail.long_price.label('long_price'),
        ).filter(
            StrategyResultDetail.strategy_id.in_(s_ids),
            StrategyResultDetail.trading_date >= start_date,
            StrategyResultDetail.day_night == 0,
            or_(
                StrategyResultDetail.long_volume > 0,
                StrategyResultDetail.short_volume > 0,
            )
        )
        data = {}
        for l in back_test_position:
            d = l.trading_date.strftime('%Y%m%d')
            k = (d, l.symbol)
            if k not in data:
                data[k] = [d, l.symbol, float(l.long_volume), float(l.long_price)]
            else:
                data[k][2] += float(l.long_volume)
                data[k][3] = max(data[k][3], float(l.long_price))
        return pd.DataFrame(sorted(data.values(), key=lambda _x: (_x[0], _x[1])), columns=columns)

    def get_portfolio_trade(self, s_ids, start_date):
        stock_trade_inds = self.sc.query(
            StrategyBackTestTradeIndicator.trading_date.label('trading_date'),
            StrategyBackTestTradeIndicator.short_notional.label('short_notional'),
            StrategyBackTestTradeIndicator.n_trade.label('n_trade'),
            StrategyBackTestTradeIndicator.n_cancel.label('n_cancel'),
        ).filter(
            StrategyBackTestTradeIndicator.s_id.in_(s_ids),
            StrategyBackTestTradeIndicator.trading_date >= start_date
        )
        columns = ['trading_date', 'short_notional', 'n_trade', 'n_cancel']
        data = {}
        for l in stock_trade_inds:
            d = l.trading_date.strftime('%Y%m%d')
            if d not in data:
                data[d] = [d, l.short_notional, l.n_trade, l.n_cancel]
            else:
                data[d][1] += l.short_notional
                data[d][2] += l.n_trade
                data[d][3] += l.n_cancel
        df = pd.DataFrame(sorted(data.values(), key=lambda x: x[0]), columns=columns)
        df['withdraw_rate'] = df.apply(
            lambda row: round(row['n_cancel'] / row['n_trade'], 4) if row['n_trade'] else 0, axis=1
        )
        sum_cash = sum([self.s_detail[s_id]['cash'] for s_id in s_ids])
        if sum_cash:
            df['liquidity'] = df['short_notional'] / sum_cash
        else:
            df['liquidity'] = 0
        return df

    def get_portfolio_risk_last_date(self, **kwargs):
        last_date = self.sc.query(
            func.max(PortfolioRiskAttribute.trading_date)
        ).filter(
            PortfolioRiskAttribute.strategy_ids == self.s_ids_str
        ).first()
        if last_date and last_date[0]:
            return (parse(last_date[0]) + datetime.timedelta(days=1)).strftime('%Y%m%d')
        else:
            return self.start_date

    def get_portfolio_risk(self):
        last_date = self.get_portfolio_risk_last_date()
        self.position = self.get_portfolio_position(self.s_ids, last_date)
        risk = risk_attribute2(self.position, top_n_sum_weight=self.top_n_sum_weight, float_value_limit=self.float_value_limit)
        daily_position = self.position.groupby('trading_date').count().reset_index()[['trading_date', 'symbol']]
        portfolio_trade = self.get_portfolio_trade(self.s_ids, last_date)
        daily_stock_number = {}
        for i, r in daily_position.iterrows():
            daily_stock_number[str(r['trading_date'])] = r['symbol']

        daily_withdraw_rate = {}
        for i, r in portfolio_trade.iterrows():
            daily_withdraw_rate[r['trading_date']] = {
                'liquidity': r['liquidity'],
                'withdraw_rate': r['withdraw_rate']
            }
        keys = [
            'max_w_800', 'non800_max_w', 'non800_ratio', 'startup_w', 'FVbelow14_w', 'TolValue',
            'FloatValue', 'non800_top30_max_w', 'noncsi800_nontop30_max_w', 'top20_value_w', 'industry_max_w'
        ]
        data = {}
        for i, r in risk.iterrows():
            d_t = str(int(r['trading_date']))
            data[d_t] = {
                'trading_date': d_t,
            }
            for k in keys:
                data[d_t][k] = r[k]
            data[d_t]['daily_stock_number'] = daily_stock_number.get(d_t, 0)
            if d_t in daily_withdraw_rate:
                data[d_t]['liquidity'] = float(daily_withdraw_rate[d_t]['liquidity'])
                data[d_t]['withdraw_rate'] = float(daily_withdraw_rate[d_t]['withdraw_rate'])
            else:
                data[d_t]['liquidity'] = 0
                data[d_t]['withdraw_rate'] = 0
        self.portfolio_risk = data
        return True

    def set_portfolio_risk(self):
        if not self.portfolio_risk:
            return True
        for v in sorted(self.portfolio_risk.values(), key=lambda x: x['trading_date']):
            r = PortfolioRiskAttribute(
                strategy_ids=self.s_ids_str,
                **v
            )
            self.sc.add(r)
        self.sc.commit()
        return True

    def run(self):
        self.get_portfolio_risk()
        self.set_portfolio_risk()

    def __del__(self):
        self.sc.close()


class VsPortfolioRisk(object):

    def __init__(self, vs_ids, **kwargs):
        self.sc = session()
        self.vs_ids = vs_ids
        self.vs_ids_str = 'live_' + '_'.join(map(str, sorted(self.vs_ids)))
        strategies = self.sc.query(
            Strategy.id.label('id'),
            Strategy.detail.label('detail'),
            Strategy.start_date.label('start_date'),
            Strategy.strategy_type.label('strategy_type'),
            VStrategies.id.label('vs_id'),
            StrategyPortfolio.live_time.label('live_time'),
        ).join(
            VStrategies, VStrategies.strategy_id == Strategy.id
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            VStrategies.id.in_(self.vs_ids)
        )
        self.s_detail = {}
        self.vs_detail = {}

        alpha_s_ids = []
        optimization_version = set()
        for s in strategies:
            self.s_detail[s.id] = {
                'strategy_type': s.strategy_type,
                'optimization_version': s.detail.get('portfolio_optimization_so_version', ''),
            }
            if s.strategy_type not in consts.alpha_stock_strategy_type:
                continue

            self.vs_detail[s.vs_id] = {
                's_id': s.id,
                'live_time': s.live_time.strftime('%Y%m%d')
            }

            alpha_s_ids.append(s.id)
            if s.detail.get('portfolio_optimization_so_version', ''):
                optimization_version.add(s.detail['portfolio_optimization_so_version'])
        self.s_ids = alpha_s_ids
        self.vs_ids = list(self.vs_detail.keys())
        self.portfolio_risk = {}

        optimization_versions = self.sc.query(StockPortfolioOptimizationVersion).filter(
            StockPortfolioOptimizationVersion.value.in_(optimization_version)
        )
        top_n_sum_weight = []
        float_value_limit = []
        for v in optimization_versions:
            if v.paras:
                if v.paras.get('num_top_weight'):
                    top_n_sum_weight.append(v.paras['num_top_weight'])
                if v.paras.get('mv_threshold'):
                    float_value_limit.append(v.paras['mv_threshold'])
        if not top_n_sum_weight:
            self.top_n_sum_weight = 20
        else:
            self.top_n_sum_weight = min(top_n_sum_weight)

        if not float_value_limit:
            self.float_value_limit = 14
        else:
            self.float_value_limit = min(float_value_limit)

        self.cash = {}
        self.get_vs_cash()

    def get_vs_cash(self):
        for vs_id in self.vs_ids:
            vs_bases = self.sc.query(VsBase).filter(
                VsBase.vstrategy_id == vs_id,
                VsBase.settle_date >= self.vs_detail[vs_id]['live_time'],
                VsBase.daynight == 'DAY',
            )
            for l in vs_bases:
                d = l.settle_date.strftime('%Y%m%d')
                if d not in self.cash:
                    self.cash[d] = float(l.total_asset)
                else:
                    self.cash[d] += float(l.total_asset)

    def get_portfolio_risk_last_date(self, **kwargs):
        last_date = self.sc.query(
            func.max(PortfolioRiskAttribute.trading_date)
        ).filter(
            PortfolioRiskAttribute.strategy_ids == self.vs_ids_str
        ).first()
        if last_date and last_date[0]:
            return (parse(last_date[0]) + datetime.timedelta(days=1)).strftime('%Y%m%d')
        else:
            return '20190101'

    def get_portfolio_position(self, vs_ids, start_date):
        columns = ['trading_date', 'symbol', 'long_volume', 'long_price']
        vs_position = self.sc.query(
            VsPosition.settle_date.label('trading_date'),
            VsPosition.symbol.label('symbol'),
            VsPosition.today_long_pos.label('long_volume'),
            VsPosition.today_settle_price.label('long_price'),
        ).filter(
            VsPosition.vstrategy_id.in_(vs_ids),
            VsPosition.settle_date >= start_date,
            VsPosition.daynight == 'DAY',
            VsPosition.today_long_pos > 0,
        )
        data = {}
        for l in vs_position:
            d = l.trading_date.strftime('%Y%m%d')
            k = (d, l.symbol)
            if k not in data:
                data[k] = [d, l.symbol, float(l.long_volume), float(l.long_price)]
            else:
                data[k][2] += float(l.long_volume)
                data[k][3] = max(data[k][3], float(l.long_price))
        return pd.DataFrame(sorted(data.values(), key=lambda _x: (_x[0], _x[1])), columns=columns)

    def get_portfolio_trade(self, vs_ids, start_date):

        sql = """select trading_date,
            sum(if(log_type='3' and direction=1, trade_vol * trade_price, 0)) as short_notional,
            sum(if(entrust_status='a', 1, 0)) as total_order_num,
            sum(if(entrust_status='d', 1, 0)) as total_cancel_num
        from trade_logs where  vstrategy_id in ({vstrategy_id_str}) GROUP BY trading_date;
        """.format(vstrategy_id_str=','.join(map(str, vs_ids)))

        columns = ['trading_date', 'short_notional', 'n_trade', 'n_cancel', 'cash']
        data = {}
        for l in self.sc.execute(sql):
            d = l[0].strftime('%Y%m%d')
            if d not in self.cash:
                continue
            data[d] = [d, float(l[1]), float(l[2]), float(l[3]), self.cash[d]]
        df = pd.DataFrame(sorted(data.values(), key=lambda x: x[0]), columns=columns)
        df['withdraw_rate'] = df.apply(
            lambda row: round(row['n_cancel'] / row['n_trade'], 4) if row['n_trade'] else 0, axis=1
        )
        df['liquidity'] = df['short_notional'] / df['cash']
        return df

    def get_portfolio_risk(self):
        last_date = self.get_portfolio_risk_last_date()
        self.position = self.get_portfolio_position(self.vs_ids, last_date)
        risk = risk_attribute2(self.position, top_n_sum_weight=self.top_n_sum_weight, float_value_limit=self.float_value_limit)
        daily_position = self.position.groupby('trading_date').count().reset_index()[['trading_date', 'symbol']]
        portfolio_trade = self.get_portfolio_trade(self.vs_ids, last_date)
        daily_stock_number = {}
        for i, r in daily_position.iterrows():
            daily_stock_number[str(r['trading_date'])] = r['symbol']

        daily_withdraw_rate = {}
        for i, r in portfolio_trade.iterrows():
            daily_withdraw_rate[r['trading_date']] = {
                'liquidity': r['liquidity'],
                'withdraw_rate': r['withdraw_rate']
            }
        keys = [
            'max_w_800', 'non800_max_w', 'non800_ratio', 'startup_w', 'FVbelow14_w', 'TolValue',
            'FloatValue', 'non800_top30_max_w', 'noncsi800_nontop30_max_w', 'top20_value_w', 'industry_max_w'
        ]
        data = {}
        for i, r in risk.iterrows():
            d_t = str(int(r['trading_date']))
            data[d_t] = {
                'trading_date': d_t,
            }
            for k in keys:
                data[d_t][k] = r[k]
            data[d_t]['daily_stock_number'] = daily_stock_number.get(d_t, 0)
            if d_t in daily_withdraw_rate:
                data[d_t]['liquidity'] = float(daily_withdraw_rate[d_t]['liquidity'])
                data[d_t]['withdraw_rate'] = float(daily_withdraw_rate[d_t]['withdraw_rate'])
            else:
                data[d_t]['liquidity'] = 0
                data[d_t]['withdraw_rate'] = 0
        self.portfolio_risk = data
        return True

    def set_portfolio_risk(self):
        if not self.portfolio_risk:
            return True
        for v in sorted(self.portfolio_risk.values(), key=lambda x: x['trading_date']):
            r = PortfolioRiskAttribute(
                strategy_ids=self.vs_ids_str,
                **v
            )
            self.sc.add(r)
        self.sc.commit()
        return True

    def run(self):
        self.get_portfolio_risk()
        self.set_portfolio_risk()

    def __del__(self):
        self.sc.close()

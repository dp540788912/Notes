import pandas as pd
import numpy as np
import os
import copy
from my.data import basic_func
import io


def datetostr(date):
    # date format: 'yyyy.mm.dd...', 'yyyy-mm-dd...'
    x = str(date)
    return x[:4] + '.' + x[5:7] + '.' + x[8:10]


def tradecalendar():
    y = basic_func.get_kdb('select date:TRADE_DT  from Calendar where EXCHANGE in `SSE`SZSE', 'FuturesBasicInfo')
    y = sorted(y['date'].unique())
    y = [datetostr(x) for x in y]
    return y


def addition_tradeday(date, x):
    # date format: 'yyyy.mm.dd'
    # x: [int, ..., int]
    # date has better be a trading day!
    calendar = tradecalendar()
    no_date = sum([1 for z in calendar if z < date])
    y = [calendar[min(no_date + z, len(calendar) - 1)] for z in x]
    return y


def reading_log(file):
    tmp_file = open(file, 'r')
    lines = tmp_file.readlines()
    tmp_file.close()

    default_dict = {'predictions': None, 'hedging': None, 'risk_dict': None,
                    'quick_setup': None, 'infor': None,
                    'current_list': None, 'target_list': None}
    keys = list(default_dict.keys())

    allinfor = {}
    tmp_n = 0

    tmp_to = 0
    tmp_sig = ''
    tmp_str = ''

    for line in lines:
        lin = line[:-1]
        if lin == 'START_Portfolio_Optimization':
            tmp_to = 0

        if lin == 'START_Portfolio_Optimization':
            tmp_n = tmp_n + 1
            allinfor[tmp_n] = copy.deepcopy(default_dict)
            tmp_to = 1
            tmp_sig = ''
            tmp_str = ''
        elif (tmp_to == 1) & ((lin[1:-1] in keys) | (lin == 'END_Portfolio_Optimization')):
            if tmp_sig in ['predictions', 'current_list', 'target_list']:
                if tmp_str[:4] == 'None':
                    allinfor[tmp_n][tmp_sig] = None
                else:
                    allinfor[tmp_n][tmp_sig] = pd.read_csv(io.StringIO(tmp_str), sep='\s+')
                    allinfor[tmp_n][tmp_sig].iloc[:, 0] = allinfor[tmp_n][tmp_sig].iloc[:, 0]. \
                        apply(lambda x: str(x).zfill(6)).tolist()
            elif tmp_sig in ['risk_dict']:
                if tmp_str[:4] == 'None':
                    allinfor[tmp_n][tmp_sig] = None
                else:
                    allinfor[tmp_n][tmp_sig] = eval(tmp_str)
            elif tmp_sig in ['quick_setup', 'infor']:
                allinfor[tmp_n][tmp_sig] = tmp_str
            elif tmp_sig == 'hedging':
                if tmp_str in ['sh50', 'hs300', 'zz500']:
                    allinfor[tmp_n][tmp_sig] = tmp_str
                else:
                    if tmp_str[:4] == 'None':
                        allinfor[tmp_n][tmp_sig] = None
                    else:
                        allinfor[tmp_n][tmp_sig] = pd.read_csv(io.StringIO(tmp_str), sep='\s+')
                        allinfor[tmp_n][tmp_sig].iloc[:, 0] = allinfor[tmp_n][tmp_sig].iloc[:, 0]. \
                            apply(lambda x: str(x).zfill(6)).tolist()

            tmp_str = ''
            if lin == 'END_Portfolio_Optimization':
                tmp_to = 0
                tmp_sig = ''
            else:
                tmp_sig = lin[1:-1]
        elif tmp_to == 1:
            if tmp_sig in ['predictions', 'current_list', 'target_list']:
                tmp_str = tmp_str + line
            elif tmp_sig == 'hedging':
                if ('sh50' in line) | ('hs300' in line) | ('zz500' in line):
                    tmp_str = tmp_str + lin
                else:
                    tmp_str = tmp_str + line
            else:
                tmp_str = tmp_str + lin

    allinfor['number'] = tmp_n

    return allinfor


def reading_riskev(date, risk_ev_path, hedging):
    code_set = {'sh50': '000016.SH',
                'hs300': '000300.SH',
                'zz500': '000905.SH',
                'zz800': '000906.SH',
                'zz1000': '000852.SH',
                'cybz': '399006.SZ',
                'cybr': '399606.SZ',
                'cybew': '399635.SZ',
                'cybg': '399667.SZ',
                'cybv': '399668.SZ',
                'cyb50': '399673.SZ'}

    hedgingcode = {'000905.SH': 1}

    idx_sig = False
    idx_weight = pd.DataFrame()

    if type(hedging) is str:

        if hedging in code_set:
            hedgingcode = {code_set[hedging]: 1}

    elif type(hedging) == pd.DataFrame:

        idx_sig = True

        indexweight = pd.read_csv(
            os.path.join(risk_ev_path, 'portfolio_optimization_ev_indexweight_' + str(date) + '.csv'))
        indexweight['symbol'] = indexweight['symbol'].apply(lambda z: z[:6]).tolist()

        idx_weight = copy.deepcopy(hedging)
        idx_weight.columns = ['symbol', 'hedging']
        idx_weight['hedging'] = - idx_weight['hedging']

        hedgingcode = {}

        tmp_set = list(idx_weight['symbol'])

        for i in ['999016', '999300', '999905', '999906', '999852',
                  '399006', '399606', '399635', '399667', '399668', '399673']:
            if i in tmp_set:
                if i[:3] == '999':
                    hedgingcode['000' + i[3:] + '.SH'] = \
                        idx_weight.loc[idx_weight['symbol'] == i, 'hedging'].tolist()[0]
                else:
                    hedgingcode[i + '.SZ'] = idx_weight.loc[idx_weight['symbol'] == i, 'hedging'].tolist()[0]

                idx_weight = idx_weight.loc[idx_weight['symbol'] != i]

        if len(hedgingcode) > 0:
            idx_weight = pd.merge(idx_weight, indexweight[['symbol'] + list(hedgingcode.keys())],
                                  how='outer', on='symbol')
            idx_weight.fillna(0, inplace=True)

            for i in hedgingcode:
                idx_weight['hedging'] = idx_weight['hedging'] + hedgingcode[i] * idx_weight[i]

            idx_weight = idx_weight[['symbol', 'hedging']]

    hedging = 'zz500'
    if len(hedgingcode) == 1:
        if '000016.SH' in hedgingcode:
            hedging = 'sh50'
        elif '000300.SH' in hedgingcode:
            hedging = 'hs300'

    ev = pd.read_csv(os.path.join(risk_ev_path, 'portfolio_optimization_ev_plus_' + date + '.csv'))
    ev.loc[:, 'symbol'] = ev.loc[:, 'symbol'].apply(lambda x: x[:6]).tolist()

    if idx_sig:
        ev = pd.merge(ev, idx_weight, how='outer', on='symbol')
    else:
        ev['hedging'] = ev['wt_' + hedging]

    mv = 'mv_lnfloat_barra2_orth_' + hedging + '_gg'

    hy = 'hy_sw1'
    bt = 'bt_' + hedging + '_barra2_orth_' + hedging + '_gg'

    bd = 'bd_' + hedging + '_barra2_orth_' + hedging + '_gg'
    gg = 'gg_barra2_orth_' + hedging + '_gg'
    jz = 'jz_btop_barra2_orth_' + hedging + '_gg'
    ld = 'ld_barra2_orth_' + hedging + '_gg'
    mm = 'mm_rstr_barra2_orth_' + hedging + '_gg'
    yl = 'yl_barra2_orth_' + hedging + '_gg'

    sig_hy = [str(x)[-3:] == 'SWS' for x in ev['hy_sw1'].tolist()]
    ev = ev.loc[sig_hy, ['symbol', 'hedging', mv, hy, bt, bd, ld, mm, yl, jz, gg]]
    ev.rename(columns={mv: 'mv', hy: 'hy', bt: 'bt', bd: 'bd', ld: 'ld', mm: 'mm', yl: 'yl', jz: 'jz', gg: 'gg'},
              inplace=True)
    ev.reset_index(drop=True, inplace=True)

    hy_columns = ['801010.SWS', '801020.SWS', '801030.SWS', '801040.SWS', '801050.SWS',
                  '801080.SWS', '801110.SWS', '801120.SWS', '801130.SWS', '801140.SWS',
                  '801150.SWS', '801160.SWS', '801170.SWS', '801180.SWS', '801200.SWS',
                  '801210.SWS', '801230.SWS', '801710.SWS', '801720.SWS', '801730.SWS',
                  '801740.SWS', '801750.SWS', '801760.SWS', '801770.SWS', '801780.SWS',
                  '801790.SWS', '801880.SWS', '801890.SWS']
    st_columns = ['mv', 'bt', 'bd', 'ld', 'mm', 'yl', 'jz', 'gg']
    for i in hy_columns:
        ev[i] = (ev['hy'] == i) + 0

    exposure_matrix = copy.deepcopy(ev[['symbol', 'hedging'] + st_columns + hy_columns])
    exposure_matrix.fillna(0, inplace=True)

    return exposure_matrix, hy_columns, st_columns


def list_openclose(date, stocklist_open=None, stocklist_close=None):
    data_close = basic_func.get_kdb('select symbol:SYMBOL, preclose:S_DQ_PRECLOSE, close:S_DQ_CLOSE, '
                                    'rtn:S_DQ_PCTCHANGE, sus: S_DQ_TRADESTATUS '
                                    'from AShareEODPrices where TRADE_DT=' + date, 'EquityFactor')
    data_close['symbol'] = data_close.loc[:, 'symbol'].apply(lambda x: x.decode()[:6]).tolist()
    data_close['sus'] = data_close.loc[:, 'sus'].apply(lambda x: x.decode()).tolist()
    data_close['sus'] = [(x not in ['SUSPENDED', 'suspended']) + 0 for x in list(data_close['sus'])]

    # open stock list
    if stocklist_open is None:
        list_open = pd.DataFrame(columns=['symbol', 'weight'])
    elif type(stocklist_open) == pd.DataFrame:
        if len(stocklist_open) > 0:
            tmp_list_open = copy.deepcopy(stocklist_open.iloc[:, :2])
            tmp_list_open.columns = ['symbol', 'size']
            tmp_list_open['symbol'] = [str(x).zfill(6) for x in list(tmp_list_open['symbol'])]
            list_open = pd.merge(tmp_list_open, data_close[['symbol', 'preclose']], how='left', on='symbol')
            list_open['money'] = list_open['size'] * list_open['preclose']
            list_open = list_open.loc[(list_open['preclose'] >= 0) & (list_open['size'] >= 0)]
            list_open['weight'] = list_open['money'] / sum(list_open['money'])
            list_open = list_open[['symbol', 'weight']]
        else:
            list_open = pd.DataFrame(columns=['symbol', 'weight'])
    else:
        list_open = pd.DataFrame(columns=['symbol', 'weight'])

    # close stock list
    if stocklist_close is None:
        list_close = pd.DataFrame(columns=['symbol', 'weight'])
    elif type(stocklist_close) == pd.DataFrame:
        if len(stocklist_close) > 0:
            tmp_list_close = copy.deepcopy(stocklist_close.iloc[:, :2])
            tmp_list_close.columns = ['symbol', 'size']
            tmp_list_close['symbol'] = [str(x).zfill(6) for x in list(tmp_list_close['symbol'])]
            list_close = pd.merge(tmp_list_close, data_close[['symbol', 'close']], how='left', on='symbol')
            list_close['money'] = list_close['size'] * list_close['close']
            list_close = list_close.loc[(list_close['close'] >= 0) & (list_close['size'] >= 0)]
            list_close['weight'] = list_close['money'] / sum(list_close['money'])
            list_close = list_close[['symbol', 'weight']]
        else:
            list_close = pd.DataFrame(columns=['symbol', 'weight'])
    else:
        list_close = pd.DataFrame(columns=['symbol', 'weight'])

    data = pd.merge(data_close[['symbol', 'rtn', 'sus']], list_open.rename(columns={'weight': 'w1'}),
                    how='left', on='symbol')
    data = pd.merge(data, list_close.rename(columns={'weight': 'w2'}), how='left', on='symbol')

    return data


def single_trading(alldata, hy_columns, st_columns):
    data = copy.deepcopy(alldata[['symbol', 'sus', 'hedging', 'rtn', 'w'] + hy_columns + st_columns])
    data.reset_index(drop=True, inplace=True)

    if sum(data['w']) < 0.01:
        rst = {x: 0 for x in hy_columns + st_columns}
        rst['hy'] = 0
        return rst

    # risk factor return
    tmp_a = copy.deepcopy(data.loc[(data['sus'] > 0.5), ['symbol', 'rtn'] + hy_columns + st_columns])
    tmp_a.dropna(axis=0, how='any', inplace=True)

    tmp_b = [x for x in hy_columns if tmp_a[x].sum() > 0.5] + st_columns

    tmp_c = pd.DataFrame(columns=['symbol', 'fct_rtn'])
    tmp_c['symbol'] = tmp_b
    tmp_x = np.mat(tmp_a[tmp_b])
    tmp_y = np.mat(tmp_a['rtn']).T
    tmp_c['fct_rtn'] = (tmp_x.T * tmp_x).I * tmp_x.T * tmp_y

    risk_rtn = pd.DataFrame(columns=['symbol', 'v'])
    risk_rtn['symbol'] = hy_columns + st_columns
    risk_rtn = pd.merge(risk_rtn, tmp_c, how='outer', on='symbol')
    risk_rtn.fillna(0, inplace=True)

    data.fillna(0, inplace=True)

    for i in st_columns + hy_columns:
        risk_rtn.loc[risk_rtn['symbol'] == i, 'v'] = \
            sum((data['w'] - data['hedging']) * data[i]) * risk_rtn.loc[risk_rtn['symbol'] == i, 'fct_rtn'] / 100

    rst = risk_rtn[['symbol', 'v']]

    rst = {rst.loc[x, 'symbol']: rst.loc[x, 'v'] for x in range(len(rst))}
    rst['hy'] = sum([rst[x] for x in hy_columns])

    return rst


def income_attribution(date, risk_ev_path, strategy_path, stocklist_open=None, stocklist_close=None):
    date = str(int(date))
    date_today = date[0:4] + '.' + date[4:6] + '.' + date[6:8]

    allfiles = os.listdir(strategy_path)
    allfiles = [x for x in allfiles if x[:8] == date]
    if len(allfiles) > 1:
        myfile = allfiles[0]
    else:
        myfile = date + '_000001_000002_day.log'
    w = reading_log(os.path.join(strategy_path, myfile))

    # exposure_matrix, hy_columns, st_columns = reading_riskev(date, risk_ev_path, hedging='zz500')

    if w['number'] > 0:
        exposure_matrix, hy_columns, st_columns = reading_riskev(date, risk_ev_path, hedging=w[1]['hedging'])
    else:
        exposure_matrix, hy_columns, st_columns = reading_riskev(date, risk_ev_path, hedging='zz500')

    data = list_openclose(date_today, stocklist_open=stocklist_open, stocklist_close=stocklist_close)

    # stock with 'sus' > 0 is not suspended!

    alldata = pd.merge(data, exposure_matrix, how='left', on='symbol')
    alldata.reset_index(drop=True, inplace=True)

    alldata.loc[~(alldata['hedging'] > 0), 'hedging'] = 0
    for i in hy_columns + st_columns:
        alldata[i].fillna(0, inplace=True)

    alldata['w1'].fillna(0, inplace=True)
    alldata['w2'].fillna(0, inplace=True)

    sum1 = alldata['w1'].sum()
    sum2 = alldata['w2'].sum()

    if (sum1 < 0.1) & (sum2 >= 0.1):

        alldata['w'] = alldata['w2'] / sum2

    elif (sum1 >= 0.1) & (sum2 < 0.1):

        alldata['w'] = alldata['w1'] / sum1

    elif (sum1 < 0.1) & (sum2 < 0.1):

        rst = {x: 0 for x in hy_columns + st_columns}
        rst['hy'] = 0
        return rst

    else:
        alldata['w'] = (alldata['w1'] + alldata['w2']) / (sum1 + sum2)

    alldata['rtn'].fillna(0, inplace=True)
    alldata['sus'].fillna(0, inplace=True)

    rst = single_trading(alldata, hy_columns, st_columns)

    return rst

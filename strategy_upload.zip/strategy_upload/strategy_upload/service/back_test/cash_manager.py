# # -*-coding:utf-8-*-
#
#
#
# def cash_manager_performance(cm_strategy_id, category):
#     """
#     :param cm_strategy_id: 'BT200156'|'LT956'
#     :param category: 'BT'|'LT'
#     :return:
#     """
#     category = category.upper()
#     strategy_id, vs_id = None, None
#
#     if cm_strategy_id.startswith('BT'):
#         strategy_id = int(cm_strategy_id.replace('BT', ''))
#     elif cm_strategy_id.startswith('LT'):
#         vs_id = int(cm_strategy_id.replace('LT', ''))
#     else:
#         raise ValueError('strategy_id(%s) error' % cm_strategy_id)
#
#     sc = session()
#
#     vs_ids = []
#     if vs_id:
#         strategy_id = sc.query(VStrategies.strategy_id).filter(VStrategies.id == vs_id).first()
#         if not strategy_id:
#             sc.close()
#             raise ValueError('strategy_id(%s) error' % cm_strategy_id)
#         else:
#             strategy_id = strategy_id[0]
#         vs_ids = [vs_id]
#
#     back_test_brief, back_test_detail, live_detail = {}, {}, {}
#     brief_columns = ['trading_date', 'ret', 'pnl', 'open_asset', 'open_position']
#     detail_columns = ['trading_date', 'symbol', 'close_short', 'close_long', 'settle_price']
#
#     if category == 'BT':
#         _back_test_data = Strategy.pnl_detail(strategy_id, _vs_ids=[-1])
#         back_test_net_line = Strategy.back_test_net_line(
#             _back_test_data['back_test_pnl'], _back_test_data['paper_trading_date'],
#             _back_test_data['hedge'], _back_test_data['hedge_type'], 'back_test_'
#         )['back_test_pnl']
#
#         _back_test_detail = sc.query(StrategyResultDetail).filter(
#             StrategyResultDetail.strategy_id == strategy_id,
#             StrategyResultDetail.day_night == 0,
#             or_(
#                 StrategyResultDetail.short_volume > 0,
#                 StrategyResultDetail.long_volume > 0
#             )
#         )
#
#         back_test_brief = {
#             'columns': brief_columns,
#             'values': [[d, v[0], v[1], v[2], v[5]] for d, v in
#                        sorted(back_test_net_line.items(), key=lambda _d: _d[0])[1:]]
#         }
#         back_test_detail = {
#             'columns': detail_columns,
#             'values': [
#                 [v.trading_date.strftime('%Y%m%d'), v.symbol, v.short_volume, v.long_volume,
#                  float(v.long_price or v.short_price or 0)]
#                 for v in _back_test_detail
#                 ]
#         }
#     elif category == 'LT':
#         if not vs_ids:
#             vs_ids = [vs[0] for vs in sc.query(VStrategies.id).filter(
#                 VStrategies.strategy_id == strategy_id, VStrategies.status == consts.STRATEGY_LIVE)]
#
#         if vs_ids:
#             pnl_details = Strategy.pnl_detail(strategy_id, _vs_ids=vs_ids)
#             vs_position_details = sc.query(VsPosition).filter(
#                 VsPosition.daynight == 'DAY',
#                 VsPosition.vstrategy_id.in_(pnl_details['live_pnl'].keys()),
#                 or_(
#                     VsPosition.today_long_pos > 0,
#                     VsPosition.today_short_pos > 0,
#                 )
#             ).order_by(VsPosition.settle_date)
#             live_position_details = {}
#             for l in vs_position_details:
#                 _vs_live_detail = live_position_details.setdefault(l.vstrategy_id, [])
#                 _vs_live_detail.append([
#                     l.settle_date.strftime('%Y%m%d'), l.symbol, l.today_short_pos, l.today_long_pos,
#                     float(l.today_settle_price)
#                 ])
#
#             for _vs_id, _live_detail in pnl_details['live_pnl'].items():
#                 _vs_pnl_net = Strategy.live_net_line(
#                     _live_detail, pnl_details['paper_trading_date'], pnl_details['hedge'], pnl_details['hedge_type']
#                 )['pnl']
#                 live_detail[_vs_id] = {
#                     'brief': {
#                         'columns': brief_columns,
#                         'values': [[d, v[0], v[1], v[2], v[5]] for d, v in
#                                    sorted(_vs_pnl_net.items(), key=lambda _d: _d[0])[1:]]
#                     },
#                     'detail': {
#                         'columns': detail_columns,
#                         'values': live_position_details.get(_vs_id, []),
#                     },
#                 }
#     else:
#         sc.close()
#         raise ValueError('category(%s) error' % category)
#     sc.close()
#     return {
#         'back_test': {
#             'brief': back_test_brief,
#             'detail': back_test_detail,
#         },
#         'live': live_detail
#     }
#
#
# def cash_manager_performance_trade_logs(cm_strategy_id, category):
#     """
#     :param cm_strategy_id: 'BT200156'|'LT956'
#     :param category: 'BT'|'LT'
#     :return:
#     """
#     category = category.upper()
#     strategy_id, vs_id = None, None
#
#     if cm_strategy_id.startswith('BT'):
#         strategy_id = int(cm_strategy_id.replace('BT', ''))
#     elif cm_strategy_id.startswith('LT'):
#         vs_id = int(cm_strategy_id.replace('LT', ''))
#     else:
#         raise ValueError('strategy_id(%s) error' % cm_strategy_id)
#
#     sc = session()
#
#     vs_ids = []
#     if vs_id:
#         strategy_id = sc.query(VStrategies.strategy_id).filter(VStrategies.id == vs_id).first()
#         if not strategy_id:
#             sc.close()
#             raise ValueError('strategy_id(%s) error' % cm_strategy_id)
#         else:
#             strategy_id = strategy_id[0]
#         vs_ids = [vs_id]
#
#     back_test_columns = [
#         'trading_date', 'calendar_time', 'day_night', 'account', 'strategy_id', 'serial_no',
#         'symbol', 'direction', 'open_close', 'trade_price', 'trade_vol', 'fee', 'entrust_status', 'msg_type'
#     ]
#
#     live_columns = back_test_columns
#
#     back_test_log = {
#         'columns': back_test_columns,
#         'values': []
#     }
#
#     live_log = {
#         'columns': live_columns,
#         'values': []
#     }
#
#     if category == 'BT':
#         sql = """
#         select trading_date, calendar_time, day_night, account, strategy_id, serial_no,
#         symbol, direction, open_close, trade_price,  trade_vol, fee, entrust_status, msg_type
#         from backtest_trade_logs where strategy_id = %s
#         """ % (strategy_id)
#         for row in sc.execute(sql):
#             back_test_log['values'].append(list(row))
#
#     elif category == 'LT':
#         if not vs_ids:
#             vs_ids = [vs[0] for vs in sc.query(VStrategies.id).filter(
#                 VStrategies.strategy_id == strategy_id, VStrategies.status == consts.STRATEGY_LIVE)]
#
#         if vs_ids:
#             sql = """
#             select trading_date,
#             concat(date_format(calendar_date, '%%%%Y%%%%m%%%%d'), ' ', date_format(calendar_time, '%%%%H:%%%%i:%%%%s'), '.', calendar_microsec),
#             day_night, account, vstrategy_id, serial_no,
#             symbol, direction, open_close, trade_price,  trade_vol, fee, entrust_status, log_type
#             from trade_logs where vstrategy_id in (%s)
#             """ % ','.join(['%s'] * len(vs_ids))
#
#         for row in engine.execute(sql, vs_ids):
#             live_log['values'].append(list(row))
#     else:
#         sc.close()
#         raise ValueError('category(%s) error' % category)
#     sc.close()
#     return {
#         'back_test': {
#             'trade_log': back_test_log,
#         },
#         'live': {
#             'trade_log': live_log
#         }
#     }
#
#
#
# def get_cash_weights(self, config_id=0):
#     sc = session()
#     weights = sc.query(CashManagerBackTestResult).filter(
#         CashManagerBackTestResult.cash_manager_id == self.id,
#         CashManagerBackTestResult.cm_group_id == self.st_uuid,
#     )
#     res = {}
#     for w in weights:
#         d = w.trading_date.strftime('%Y%m%d')
#         if d not in res:
#             res[d] = {}
#         res[d][w.strategy_id] = float(w.weight)
#     sc.close()
#     return res
#
#
#
# def get_cash_manager_back_test_result(self, config_id=0):
#
#     weights = self.get_cash_weights()
#     null_pnl_detail = {
#         'pnl': {},
#         'hedge_net': {},
#         'origin_net': {},
#         'sharpe': 0,
#         'profitrate': 0,
#         'annual_return': 0,
#         'max_drawdown_pnl': 0,
#         'max_drawdown_start': 0,
#         'max_drawdown_end': 0,
#         'return_over_drawdown': 0,
#         'paper_trading_sharpe': 0,
#         'paper_trading_profitrate': 0,
#         'paper_trading_annual_return': 0,
#         'paper_trading_max_drawdown_pnl': 0,
#         'paper_trading_max_drawdown_start': 0,
#         'paper_trading_max_drawdown_end': 0,
#     }
#     if not weights:
#         return null_pnl_detail
#
#     strategy_ids = list(set(itertools.chain.from_iterable([v.keys() for v in weights.values()])))
#
#     sc = session()
#
#     strategy_pnl = {}
#     papertrading_date = (self.paper_trading_date or self.r_create_time).strftime('%Y%m%d')
#
#     for s in sc.query(Strategy).filter(Strategy.id.in_(strategy_ids)):
#         strategy_pnl[s.id] = s.back_test_range_performance()
#     #    papertrading_date = max(papertrading_date, (s.paper_trading_date or s.r_create_time).strftime('%Y%m%d'))
#
#     init_cash = self.detail.get('initial_cash', 1000000) or 1000000
#
#     begin_date = min(weights.keys())
#
#     days = sorted(set(list(weights.keys()) + list(
#         itertools.chain.from_iterable([v.get('pnl', {}).keys()for v in strategy_pnl.values()])
#     )))
#
#     dates = []
#     pnls = []
#     open_cash = []
#     last_open_cash = init_cash
#     s_last_open_cash = {}
#     for d in days:
#         if d < begin_date:
#             continue
#
#         open_cash.append(last_open_cash)
#         dates.append(d)
#         day_pnl = 0
#
#         for s_id, s_pnl in strategy_pnl.items():
#             if s_id not in s_last_open_cash:
#                 s_last_open_cash[s_id] = last_open_cash * (weights.get(d, {}).get(s_id, 0))
#             if d in s_pnl.get('pnl', {}):
#                 s_d_pnls = s_pnl['pnl'][d]
#                 s_d_ret = s_d_pnls[0] / float(s_d_pnls[4]) - 1
#                 s_d_w = weights.get(d, {})
#                 if s_d_w:
#                     s_open_cash = last_open_cash * s_d_w.get(s_id, 0)
#                 else:
#                     s_open_cash = s_last_open_cash.get(s_id, 0)
#
#                 s_d_pnl = s_open_cash * s_d_ret
#                 day_pnl += s_d_pnl
#                 s_last_open_cash[s_id] = s_open_cash + s_d_pnl
#
#         last_open_cash += day_pnl
#         pnls.append(day_pnl)
#
#     if not dates:
#         return null_pnl_detail
#
#     back_test_result = {
#         'live_date': [],
#         'live_pnl': [],
#         'live_asset': [],
#         'live_position_value': [],
#         'live_cash_io': [],
#         'live_end_position_value': 0.0,
#         'back_test_date': dates,
#         'back_test_asset': open_cash,
#         'back_test_pnl': pnls,
#         'back_test_position_value': [0] * len(dates),
#         'back_test_end_position_value': 0.0,
#         'back_test_cash_io': [0] * len(dates),
#         'paper_trading_date': papertrading_date,
#     }
#
#     net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategies_quest(back_test_result)
#
#     if net_pnl[0]:
#         return null_pnl_detail
#
#     detail = net_pnl[1]
#     pnl_detail = {
#         'pnl': {key.decode("utf-8"):value for key,value in detail['back_test_pnl'].items()},
#         'hedge_net': {},
#         'origin_net': {},
#         'sharpe': detail['back_test_sharpe'],
#         'profitrate': detail['back_test_profitrate'],
#         'annual_return': detail['back_test_annual_return'],
#         'max_drawdown_pnl': detail['back_test_max_drawdown_pnl'],
#         'max_drawdown_start': detail['back_test_max_drawdown_start'],
#         'max_drawdown_end': detail['back_test_max_drawdown_end'],
#         'return_over_drawdown': detail.get('back_test_return_over_drawdown', 0),
#         'paper_trading_sharpe': detail['paper_trading_sharpe'],
#         'paper_trading_profitrate': detail['paper_trading_profitrate'],
#         'paper_trading_annual_return': detail['paper_trading_annual_return'],
#         'paper_trading_max_drawdown_pnl': detail['paper_trading_max_drawdown_pnl'],
#         'paper_trading_max_drawdown_start': detail['paper_trading_max_drawdown_start'],
#         'paper_trading_max_drawdown_end': detail['paper_trading_max_drawdown_end']
#     }
#     return pnl_detail
#
#
#
# def start_cash_manager_task(self, *args, **kwargs):
#     end_date = self.end_date
#     config_id = kwargs['config_id']
#     start_date = kwargs['start_date']
#     task_id = kwargs['task_id']
#     now = datetime.datetime.now()
#     if now.hour >= 17:
#         end_date = Strategy.get_trading_date(hour=17)
#         if kwargs.get('auto', False):
#             start_date = end_date
#     else:
#         end_date = now.strftime('%Y%m%d')
#
#     sc = session()
#     kdb = KdbQuery()
#     days = kdb.get_trading_days(start_date, end_date)
#     if self.is_test:
#         days = days[:10]
#     strategy = sc.query(Strategy).filter(Strategy.id == self.id).first()
#
#     out_put_path = 'strategy_upload/output/%s/%s' % (self.username, self.name.strip().replace(' ', ''))
#     if not os.path.exists(os.path.join(config.media, out_put_path)):
#         os.makedirs(os.path.join(config.media, out_put_path))
#     cwd = os.path.join(config.NOTEBOOK_HOME, '%s_%s/app_working_dir' % (self.r_create_user_id, self.username))
#     if not os.path.exists(cwd):
#         os.makedirs(cwd)
#         os.makedirs(os.path.join(cwd, 'output'))
#         os.symlink(os.path.join(config.renv, 'qserver.so'), os.path.join(cwd, 'qserver.so'))
#         os.symlink(os.path.join(config.renv, 'qserver.R'), os.path.join(cwd, 'qserver.R'))
#
#     rds = redis.Redis(host=config.redis['host'], port=config.redis['port'], db=config.redis['db'])
#     for index, d in enumerate(days):
#         status = str(rds.hget(consts.AGENT_TASK_STOP_MAP, task_id) or b'', 'utf-8')
#         if status == str(consts.AGENT_TASK_STOP):
#             logger.info('cash_manager_task stop!!')
#             break
#         file_ext = self.strategy_upload_file['filename'].rsplit('.', 1)[-1].lower()
#         if file_ext in ('py', 'so'):
#             output_file = os.path.join(
#                 config.media, out_put_path, 'cash_output_%s_%s_%s.csv' % (d, str(self.id), {0: 'day', 1: 'night'}[0])
#             )
#             initial_cash = self.detail.get('initial_cash', 1000000) or 1000000
#             cfg = {
#                 'trading_date': d,
#                 'day_night': 0,
#                 'asset': initial_cash,
#                 'pre_market_calculation': [],
#                 'config': {
#                     'strategies': [{'id': 'BT%s' % _s['id']} for _s in self.detail.get('managercontent', [])]
#                 },
#                 'output_file': output_file
#             }
#             try:
#                 data = []
#                 com_list = ['/usr/bin/python3', self.strategy_upload_file['abs_path'], json.dumps(cfg)]
#                 output_string = subprocess.check_output(com_list, universal_newlines=True, cwd=cwd)
#                 output_f = open(output_file, 'r')
#                 data = json.load(output_f)
#                 sc.query(CashManagerBackTestResult).filter(
#                     CashManagerBackTestResult.cash_manager_id == self.id,
#                     CashManagerBackTestResult.cm_group_id == task_id,
#                     CashManagerBackTestResult.trading_date == d,
#                 ).delete(synchronize_session=False)
#
#                 for s_w in data:
#                     cm = CashManagerBackTestResult(
#                         cash_manager_id=self.id,
#                         cm_group_id=task_id,
#                         trading_date=d,
#                         day_night=2,
#                         strategy_id=int(s_w['id'].replace('BT', '')),
#                         weight=float(s_w['weight']),
#                     )
#                     sc.add(cm)
#             except Exception as e:
#                 sentry.captureException()
#             progress = index / len(days)
#             strategy.task_progress = progress
#             sc.commit()
#     strategy.status = consts.TASK_FINISHED
#     sc.commit()
#     sc.close()
#     return True
#
#
# def back_test_range_performance(self, config_id=0, start_date='', end_date=''):
#
#     if self.group_id > 0:
#         back_test_result = self.group_back_test_result(start_date=start_date, end_date=end_date)
#         back_test_result['paper_trading_date'] = ''
#     else:
#         sc = session()
#         res = sc.query(
#             StrategyResult.date.label('date'),
#             StrategyResult.pnl.label('pnl'),
#             StrategyResult.position_cash.label('position_cash'),
#             StrategyResult.total_asset.label('total_asset'),
#         ).filter(
#             StrategyResult.strategy_id == self.id,
#             StrategyResult.config_id == config_id,
#             StrategyResult.status == consts.TASK_FINISHED
#         ).order_by(StrategyResult.date)
#
#         if start_date:
#             start_date = parse(start_date).strftime('%Y%m%d')
#         else:
#             start_date = '19900101'
#         if end_date:
#             end_date = parse(end_date).strftime('%Y%m%d')
#         else:
#             end_date = time.strftime('%Y%m%d')
#
#         paper_trading_date = (self.paper_trading_date or self.r_create_time).strftime('%Y%m%d')
#         confidence = float(self.confidence)
#
#         back_test_result = {
#             'live_date': [],
#             'live_pnl': [],
#             'live_asset': [],
#             'live_position_value': [],
#             'live_end_position_value': 0.0,
#             'live_cash_io': [],
#             'back_test_date': [],
#             'back_test_asset': [],
#             'back_test_pnl': [],
#             'back_test_position_value': [],
#             'back_test_cash_io': [],
#             'back_test_end_position_value': 0.0,
#             'paper_trading_date': '',
#         }
#
#         initial_cash = self.detail.get('initial_cash', 1000000) or 1000000
#         if config_id > 0:
#             initial_cash = Strategy.get_semi_info(config_id).get('initial_cash', 1000000) or 1000000
#
#         daily_open_asset = float(initial_cash)
#         daily_position_cash = 0.0
#         for r in res:
#             if start_date <= r.date <= end_date:
#                 back_test_result['back_test_date'].append(r.date)
#                 back_test_result['back_test_asset'].append(daily_open_asset)
#
#                 r_pnl = float(r.pnl)
#                 if r.date < paper_trading_date and r_pnl > 0:
#                     back_test_result['back_test_pnl'].append(r_pnl * confidence)
#                 else:
#                     back_test_result['back_test_pnl'].append(r_pnl)
#
#                 back_test_result['back_test_position_value'].append(daily_position_cash)
#                 back_test_result['back_test_cash_io'].append(0)
#
#             if r.total_asset:
#                 daily_open_asset = float(r.total_asset)
#             else:
#                 daily_open_asset += float(r.pnl)
#             daily_position_cash = float(r.position_cash or 0.0)
#         back_test_result['back_test_end_position_value'] = daily_position_cash
#         sc.close()
#     if not self.hedge:
#         net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategies_quest(back_test_result)
#     else:
#         back_test_result['hedge'] = '' #self.hedge
#         back_test_result['hedge_type'] = '' #self.hedge_type or 'position'
#         if len(back_test_result['back_test_position_value']) >= 2:
#             back_test_result['back_test_position_value'][0] = back_test_result['back_test_position_value'][1]
#         elif len(back_test_result['back_test_position_value']) == 1:
#             back_test_result['back_test_position_value'][0] = back_test_result['back_test_end_position_value']
#         net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategy_hedge_quest(back_test_result)
#
#     if net_pnl[0]:
#         null_pnl_detail = {
#             'pnl': {},
#             'hedge_net': {},
#             'origin_net': {},
#             'sharpe': 0,
#             'profitrate': 0,
#             'annual_return': 0,
#             'max_drawdown_pnl': 0,
#             'max_drawdown_start': 0,
#             'max_drawdown_end': 0,
#             'return_over_drawdown': 0,
#             'paper_trading_sharpe': 0,
#             'paper_trading_profitrate': 0,
#             'paper_trading_annual_return': 0,
#             'paper_trading_max_drawdown_pnl': 0,
#             'paper_trading_max_drawdown_start': 0,
#             'paper_trading_max_drawdown_end': 0,
#         }
#         return null_pnl_detail
#
#     detail = net_pnl[1]
#     pnl_detail = {
#         'pnl': {key.decode("utf-8"): value for key, value in detail['back_test_pnl'].items()},
#         'hedge_net': {},
#         'origin_net': {},
#         'sharpe': detail['back_test_sharpe'],
#         'profitrate': detail['back_test_profitrate'],
#         'annual_return': detail['back_test_annual_return'],
#         'max_drawdown_pnl': detail['back_test_max_drawdown_pnl'],
#         'max_drawdown_start': detail['back_test_max_drawdown_start'],
#         'max_drawdown_end': detail['back_test_max_drawdown_end'],
#         'return_over_drawdown': detail.get('back_test_return_over_drawdown', 0),
#         'paper_trading_sharpe': detail['paper_trading_sharpe'],
#         'paper_trading_profitrate': detail['paper_trading_profitrate'],
#         'paper_trading_annual_return': detail['paper_trading_annual_return'],
#         'paper_trading_max_drawdown_pnl': detail['paper_trading_max_drawdown_pnl'],
#         'paper_trading_max_drawdown_start': detail['paper_trading_max_drawdown_start'],
#         'paper_trading_max_drawdown_end': detail['paper_trading_max_drawdown_end']
#     }
#
#     # cond 1 : paper trading 绩效最后一天距离最新交易日7天以上
#     # 外层判断
#
#     # cond 2 : 有任何一天净值为0
#     for k, v in pnl_detail['pnl'].items():
#         if not v[0] > 0:
#             pnl_detail['invalid'] = 'net value is zero,date:%s' % (k)
#             break
#
#     # cond 3 :  有任何一天持仓市值超过2倍权益（均以当天值计算）
#     for k, v in pnl_detail['pnl'].items():
#         if v[6] > v[3]*2:
#             pnl_detail['invalid'] = 'position value > 2*(accounting value),date:%s' % (k)
#             break
#
#     return pnl_detail
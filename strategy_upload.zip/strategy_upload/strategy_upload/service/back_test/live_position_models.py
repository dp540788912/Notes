# coding: utf-8


from sqlalchemy import BigInteger, Column, Date, DateTime, Enum, Float, Index, Integer, String, Time, text
from sqlalchemy.dialects.mysql import DOUBLE

from db import ModelBase


class VsAccount(ModelBase):
    __tablename__ = 'vs_accounts'

    vstrategy_id = Column(BigInteger, primary_key=True, nullable=False)
    account = Column(String(256), primary_key=True, nullable=False)
    settle_date = Column(Date, primary_key=True, nullable=False)
    cash = Column(String(20), nullable=False)
    accumulated_pnl = Column(String(20), nullable=False)
    daynight = Column(String(12), primary_key=True, nullable=False)
    ctime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    utime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    available_cash = Column(String(20), nullable=False)
    asset_cash = Column(String(20), nullable=False, default='0')
    defer_fee = Column(DOUBLE, nullable=False, default=0)
    fee = Column(DOUBLE, nullable=False, default=0)
    pnl = Column(DOUBLE, nullable=False, default=0)
    position_cash = Column(DOUBLE, nullable=False, default=0)
    total_asset = Column(DOUBLE, nullable=False, default=0)
    dividend = Column(DOUBLE, nullable=False, default=0)
    currency = Column(String(20), nullable=False, default='CNY')
    forex_rate = Column(DOUBLE, nullable=False, default=1)


class VsBase(ModelBase):
    __tablename__ = 'vs_base'

    vstrategy_id = Column(BigInteger, primary_key=True, nullable=False)
    cash = Column(String(20), nullable=False)
    accumulated_pnl = Column(String(20), nullable=False)
    settle_date = Column(Date, primary_key=True, nullable=False)
    daynight = Column(String(12), primary_key=True, nullable=False)
    ctime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    utime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
    available_cash = Column(String(20), nullable=False)
    asset_cash = Column(String(20), nullable=False, default='0')
    defer_fee = Column(DOUBLE, nullable=False, default=0)
    fee = Column(DOUBLE, nullable=False, default=0)
    pnl = Column(DOUBLE, nullable=False, default=0)
    position_cash = Column(DOUBLE, nullable=False, default=0)
    total_asset = Column(DOUBLE, nullable=False, default=0)
    dividend = Column(DOUBLE, nullable=False, default=0)


class VsPosition(ModelBase):
    __tablename__ = 'vs_positions'

    vstrategy_id = Column(BigInteger, primary_key=True, nullable=False)
    symbol = Column(String(128), primary_key=True, nullable=False)
    settle_date = Column(Date, primary_key=True, nullable=False, index=True)
    symbol_type = Column(String(12), nullable=False)
    account = Column(String(32), nullable=False)
    yest_long_pos = Column(Integer, nullable=False)
    yest_long_avg_price = Column(String(20), nullable=False)
    yest_short_pos = Column(Integer, nullable=False)
    yest_short_avg_price = Column(String(20), nullable=False)
    today_long_pos = Column(Integer, nullable=False)
    today_long_avg_price = Column(String(20), nullable=False)
    today_short_pos = Column(Integer, nullable=False)
    today_short_avg_price = Column(String(20), nullable=False)
    today_settle_price = Column(String(20), nullable=False)
    exchange = Column(String(12), nullable=False)
    symbol_pnl = Column(String(20), nullable=False, default='0')
    symbol_fee = Column(String(20), nullable=False, default='0')
    today_max_pos = Column(Integer, nullable=False)
    daynight = Column(String(12), primary_key=True, nullable=False)
    ctime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    utime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))


class PositionCorpActionsTable(ModelBase):
    __tablename__ = 'position_corp_actions_table'

    id = Column(BigInteger, primary_key=True)
    vstrategy_id = Column(BigInteger, nullable=False)
    account = Column(String(20), nullable=False, server_default=text("''"))
    symbol = Column(String(20), nullable=False)
    today_long_pos = Column(Integer, nullable=False)
    today_short_pos = Column(Integer, nullable=False)
    eqy_record_date = Column(Date, nullable=False, index=True)
    ex_date = Column(Date, nullable=False, server_default=text("'1900-01-01'"))
    cash_dividend_per_share = Column(String(20), nullable=False)
    dividend_cash_payout_date = Column(Date, nullable=False, index=True, server_default=text("'1900-01-01'"))
    payout_cash = Column(String(20), nullable=False)
    share_bonus_rate = Column(String(20), nullable=False)
    share_conversederate_rate = Column(String(20), nullable=False)
    dividend_share_listing_date = Column(Date, nullable=False, index=True, server_default=text("'1900-01-01'"))
    payout_pos = Column(String(20), nullable=False)
    payout_short_pos = Column(String(20), nullable=False)
    ctime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    utime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))

    def to_dict(self):
        return {
            'vstrategy_id': self.vstrategy_id,
            'symbol': self.symbol,
            'account': self.account,
            'today_long_pos': int(self.today_long_pos),
            'today_short_pos': int(self.today_long_pos),
            'eqy_record_date': self.eqy_record_date.strftime('%Y-%m-%d'),
            'ex_date': self.ex_date.strftime('%Y-%m-%d'),
            'cash_dividend_per_share': float(self.cash_dividend_per_share),
            'dividend_share_listing_date': self.dividend_share_listing_date.strftime('%Y-%m-%d'),
            'share_bonus_rate': float(self.share_bonus_rate),
            'share_conversederate_rate': float(self.share_conversederate_rate),
            'payout_pos': float(self.payout_pos),
            'payout_short_pos': float(self.payout_short_pos),
            'payout_cash': float(self.payout_cash),
            'dividend_cash_payout_date': self.dividend_cash_payout_date.strftime('%Y-%m-%d'),
        }

    def to_brief(self):
        return {
            'symbol': self.symbol,
            'account': self.account,
            'today_long_pos': int(self.today_long_pos),
            'today_short_pos': int(self.today_long_pos),
            'eqy_record_date': self.eqy_record_date.strftime('%Y-%m-%d'),
            'ex_date': self.ex_date.strftime('%Y-%m-%d'),
            'cash_dividend_per_share': float(self.cash_dividend_per_share),
            'dividend_share_listing_date': self.dividend_share_listing_date.strftime('%Y-%m-%d'),
            'share_bonus_rate': float(self.share_bonus_rate),
            'share_conversederate_rate': float(self.share_conversederate_rate),
            'payout_pos': float(self.payout_pos),
            'payout_short_pos': float(self.payout_short_pos),
            'payout_cash': float(self.payout_cash),
            'dividend_cash_payout_date': self.dividend_cash_payout_date.strftime('%Y-%m-%d'),
        }


class StockVsAccountFee(ModelBase):
    __tablename__ = 'vs_stock_account_fee'
    id = Column(BigInteger, primary_key=True)
    account = Column(String(128), nullable=False)
    trading_date = Column(Date, nullable=False, index=True)
    fee_rate = Column(DOUBLE, nullable=False, default=0)

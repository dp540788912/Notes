# -*-coding:utf-8-*-

import copy
import datetime
import uuid
import queue

import pandas as pd

from db import session, session_context, engine
from utils import get_cache, set_cache
from service.back_test.models import Strategy, VStrategies, StrategyPortfolio


def get_all_dep_factor_ids(s_id):
    """
    Find all dependence factor id of a strategy recursively
    :param s_id: int: strategy id
    :return: set: factor id
    """
    sc = session()
    search_queue = queue.Queue()
    search_queue.put(s_id)
    all_dep_ids = set()
    while not search_queue.empty():
        strategy_id = search_queue.get()
        if strategy_id is None:
            break
        s = sc.query(Strategy).filter(Strategy.id == strategy_id).first()
        if s is None:
            continue
        dep_f_ids = s.direct_dep_factor_ids()
        for f_id in dep_f_ids:
            if f_id not in all_dep_ids:
                search_queue.put(f_id)
                all_dep_ids.add(f_id)
    sc.close()
    return all_dep_ids


def get_live_server_strategy_ids(ip_addr):
    """
    Find live strategy id from specific server
    :param ip_addr: string: server ip
    :return: set: strategy id
    """
    df_sql = """
    SELECT vstrategies.`strategy_id` as s_id
    FROM vstrategies
    JOIN deploy_confs ON deploy_confs.`vstrategy_id`=vstrategies.`id`
    WHERE vstrategies.`status`=15 AND deploy_confs.`host`='{host}' AND deploy_confs.`valid`=1
    """.format(**{
        'host': ip_addr
    })
    df = pd.read_sql_query(df_sql, engine)
    return set(df['s_id'])


def get_server_factor_id_change_info(old_s_id, new_s_id, ip_addr):
    """
    Find factor id need to be add and remove when deploying and removing strategy from specific server
    :param old_s_id: int: strategy id needed to remove from server, 0 for not need to be remove old
    :param new_s_id: int: strategy id needed to deploy to server, 0 for not need to be deploy new
    :param ip_addr: string: server ip
    :return: dict: info of factor id needed to be changed
    """
    old_dep_factor_ids = get_all_dep_factor_ids(s_id=old_s_id)
    new_dep_factor_ids = get_all_dep_factor_ids(s_id=new_s_id)

    live_server_s_ids = get_live_server_strategy_ids(ip_addr=ip_addr)
    live_server_dep_factor_ids_info = dict()
    for s_id in live_server_s_ids:
        if s_id != old_s_id:
            live_server_dep_factor_ids_info[s_id] = get_all_dep_factor_ids(s_id)

    middle_state = set()
    for k, v in live_server_dep_factor_ids_info.items():
        middle_state.add(k)
        middle_state.update(v)

    current_state = middle_state.union(old_dep_factor_ids).union({old_s_id})
    new_state = middle_state.union(new_dep_factor_ids).union({new_s_id})

    down_factor_ids = current_state.difference(new_state)
    up_factor_ids = new_state.difference(current_state)

    remove_factor_ids = [f_id for f_id in down_factor_ids if f_id > 0]
    deploy_factor_ids = [f_id for f_id in up_factor_ids if f_id > 0]

    return {
        'remove_factor_ids': remove_factor_ids,
        'deploy_factor_ids': deploy_factor_ids
    }


# deprecated
def get_dep_ev_id(s_id):
    sc = session()
    s = sc.query(Strategy).filter(Strategy.id == s_id).first()
    dep_s_ids = [dep['id'] for dep in s.dependency]
    factor_ids = [int(p['symbol'].split('_')[2]) for p in s.products[0] if p.get('type', '') == 'stock_factor_FACTOR']
    res = dep_s_ids + factor_ids
    dep_s_ids.extend(factor_ids)
    sc.close()
    for dep_id in dep_s_ids:
        res.extend(get_dep_ev_id(dep_id))
    return sorted(set(res))


# TODO: need improve
def get_live_ev_ids():
    sc = session()
    ev_ids = []
    strategies = sc.query(
        VStrategies.strategy_id
    ).join(
        Strategy, VStrategies.strategy_id == Strategy.id,
    ).join(
        StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
    ).filter(
        # consts.STRATEGY_LIVE 
        VStrategies.status == 15,
        StrategyPortfolio.business.in_(['stock', 'future'])
    )
    sc.close()
    for s in strategies:
        ev_ids.extend(get_dep_ev_id(s.strategy_id))
    # TODO: remove duplicated ev id
    # return list(set(ev_ids))
    return ev_ids


# TODO: need improve
def get_live_ev_ids_cache(cache=True):
    """
    Cache behavior should be changed to actively triggered.
    """
    cache_key = 'live_ev_ids_cache'
    if cache:
        data = get_cache(cache_key)
        if data:
            return data
    data = get_live_ev_ids()
    if data:
        data = sorted(set(data))
        set_cache(cache_key, data, 3600 * 4)
    return data


def cancel_ev_waiting(ev_id, **kwargs):
    sc = session()
    s = sc.query(Strategy).filter(
        Strategy.id == ev_id,
        Strategy.node == 'ev'
    ).first()
    if not s:
        sc.close()
        return True
    s.st_uuid = uuid.uuid1().hex
    sc.commit()
    sc.close()
    return True


def add_dependency(ev_id, dep_ids):
    sc = session()
    ev = sc.query(Strategy).filter(Strategy.id == ev_id).first()
    deps = copy.deepcopy(ev.dependency)
    old_dep_ids = [dep['id'] for dep in deps]
    for dep_id in sorted(set(dep_ids)):
        if dep_id in old_dep_ids:
            continue
        dep = sc.query(Strategy).filter(Strategy.id == dep_id).first()
        deps.append({
            "id": dep.id,
            "end": datetime.datetime.now().strftime('%Y%m%d'),
            "name": "%s_ev_output" % dep.name,
            "type": "ev",
            "start": dep.start_date,
            "value": dep.id,
            "products": [""],
            "selected": True
        })
    ev.dependency = deps
    s_d = copy.deepcopy(ev.detail)
    s_d['dependency'] = deps
    ev.detail = s_d
    sc.commit()
    sc.close()
    return True


def remove_dependency(ev_id, dep_ids):
    sc = session()
    ev = sc.query(Strategy).filter(Strategy.id == ev_id).first()
    deps = copy.deepcopy(ev.dependency)
    new_deps = list()
    for dep in deps:
        if dep['id'] not in dep_ids:
            new_deps.append(dep)
    ev.dependency = new_deps
    s_d = copy.deepcopy(ev.detail)
    s_d['dependency'] = new_deps
    ev.detail = s_d
    sc.commit()
    sc.close()
    return True


def add_factor_products(ev_id, factor_ids):
    sc = session()
    ev = sc.query(Strategy).filter(Strategy.id == ev_id).first()
    products = copy.deepcopy(ev.products)
    old_products = [p['symbol'] for p in products[0]]
    for f_id in sorted(set(factor_ids)):
        f_id_sym = 'stock_factor_%s_ALL' % f_id
        if f_id_sym in old_products:
            continue
        products[0].append(
            {
                "exch": "SSE",
                "name": "ALL",
                "type": "stock_factor_FACTOR",
                "symbol": f_id_sym,
                "_selected": True
            }
        )
    ev.products = products
    s_d = copy.deepcopy(ev.detail)
    s_d['products'] = products
    ev.detail = s_d
    sc.commit()
    sc.close()
    return True


def remove_factor_products(ev_id, factor_ids):
    sc = session()
    ev = sc.query(Strategy).filter(Strategy.id == ev_id).first()
    products = copy.deepcopy(ev.products)
    new_products = []
    for p in products[0]:
        if not (p.get('type', '') == 'stock_factor_FACTOR'):
            new_products.append(p)
        f_id = int(p['symbol'].split('_')[2])
        if f_id in factor_ids:
            continue
        else:
            new_products.append(p)
    new_products = [new_products]
    ev.products = new_products
    s_d = copy.deepcopy(ev.detail)
    s_d['products'] = new_products
    ev.detail = s_d
    sc.commit()
    sc.close()
    return True


if __name__ == '__main__':
    # add_factor_products(ev_id=216645, factor_ids=[216639, 216638, 216637, 216578, 216577, 216576, 216491])
    # s_id = 216423
    # with session_context() as sc:
    #     s = sc.query(Strategy).filter(
    #         Strategy.id == s_id
    #     ).first()
    #     print(s.direct_dep_ids())

    # print(remove_dependency(ev_id=s_id, dep_ids=[215783, 215745]))
    # print(add_dependency(ev_id=s_id, dep_ids=[217500]))
    # print(get_all_dep_factor_ids(s_id=215506))
    pass

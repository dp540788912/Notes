# -*-coding:utf-8-*-

import sys
import os

if 'GEN_DATA_TEST' in os.environ:
    sys.path.insert(0, '/home/rss/bss_server/strategy_upload/strategy_upload')

import json
import csv
import copy
import io
from sqlalchemy.orm import mapper
from sqlalchemy import or_
from sqlalchemy import Table, MetaData

if 'FACTOR_DATA_TEST' in os.environ:
    from models import *
else:
    from service.back_test.models import *

from db import ModelBase, engine, session, session_context as mysql_sc
from log import logger
from service.back_test.live_position_models import VsBase, VsAccount, VsPosition
import consts


def get_factor_data(strategy_id):
    data_d = {}

    sc = session()
    query_result = sc.query(StrategyResult).filter(StrategyResult.strategy_id == strategy_id).order_by(
        StrategyResult.date)
    for row in query_result:
        _date = row.date
        _detail = row.detail
        for item in _detail:
            # bt : seldom has night session's result , just skip
            if item['day_night'] == 1:
                continue

            is_stock = item['symbol'].isdigit()
            if not is_stock:
                continue

            if not (item['long_volume'] > 0 or item['short_volume'] > 0):
                continue

            k = '%s-%s' % (_date, item['symbol'])
            _l = [strategy_id, _date, item['symbol'], item['long_volume'], item['short_volume'],
                  item['long_price'] if item['long_price'] > 0 else item['short_price']]
            data_d[k] = _l

    query_result = sc.query(VStrategies).filter(VStrategies.strategy_id == strategy_id,
                                                VStrategies.source == 'platform').order_by(VStrategies.id).first()
    if query_result is None:
        print('no vstrategy id found of sid:%d' % (strategy_id))
        return data_d

    earliest_vid = query_result.id

    query_result = sc.query(VsPosition).filter(VsPosition.vstrategy_id == earliest_vid,
                                               VsPosition.daynight == 'DAY').order_by(VsPosition.settle_date)
    for row in query_result:
        is_stock = row.symbol.isdigit()
        if not is_stock:
            continue

        if not (row.today_long_pos > 0 or row.today_short_pos > 0):
            continue

        _date = row.settle_date.strftime('%Y%m%d')
        # _date = _date[:4] + _date[5:7] + _date[8:]
        k = '%s-%s' % (_date, row.symbol)
        _l = [strategy_id, _date, row.symbol, row.today_long_pos, row.today_short_pos,
              float(row.today_long_avg_price) if float(row.today_long_avg_price or 0) > 0 else float(
                  row.today_short_avg_price)]
        data_d[k] = _l

    sc.close()

    return data_d


def main():
    # ret_d = get_factor_data(201282)
    # _str = json.dumps(ret_d)
    # print('%s' % (_str))
    pass


if __name__ == '__main__':
    main()

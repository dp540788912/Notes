# -*-coding:utf-8-*-

import re
import hashlib
import simplejson

from collections import Counter
from tornado import gen, escape
from tornado import httpclient
from tornado.web import RequestHandler

from utils import get_stock_detail, MyEncoder
from service.order_list.models import OrderList
from service.basehandler import BaseHandler, CurrentUserMixin, JsonPayloadMixin, CurrentUserMixin_V2
from service.back_test.factor_data import *
from service.back_test.gen_data import *
from service.back_test.models import *
from service.statistic.track import track_filter_data, HistoryPositionTrackService
from service.statistic.investment import InvestmentPerformanceService
from service.statistic.models import StrategyVwapExecutimeTime, StrategyIncomeAttribution, \
    StrategyIncomeAttributionAdjusted
from cron.strategy_upload_task import update_strategy_performance, update_strategy_sorting_result
from my.data.futures import bar
from service.stock_factor.models import StockFactorStrategyColumns, StockFactorStrategy
from constant import StrategyConstant, APIResponseCode, HedgeBenchmark
from .helper import get_merge_vs_share_resp_info
from utility.db_util import TradeCalendar
from config import config


class Test(RequestHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        logger.info('test test !!!!!!!!!!!!!!!')
        res = yield self.get_res()
        self.write(json.dumps({
            'code': 0,
            'data': res
        }))

    @gen.coroutine
    def get_res(self):
        begin = time.time()
        yield gen.sleep(0.5)
        print('times:%s' % (time.time() - begin))
        return 'hello'


class StrategyHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        sc = session()
        node = self.get_argument('node', None)
        refer = self.request.headers.get('Referer', '')
        if ('strategy/index.html' in refer) or ('strategy/index2.html' in refer):
            node = 'back_test'
        elif 'strategy/ev-upload.html' in refer:
            node = 'ev'
        status = self.get_argument('status', '')
        is_delete = 0 if str(status).upper() != 'DELETE' else 1
        page = int(self.get_argument('page', 0))
        size = int(self.get_argument('size', 500))
        is_group = self.get_argument('is_portfolio', 'false').lower()
        keyword = self.get_argument('keyword', '')
        if node:
            if self.current_user['is_superuser']:
                if node == 'back_test':
                    if is_group == 'true':
                        strategies = sc.query(Strategy).filter(
                            Strategy.node.in_(['group']),
                            Strategy.is_test == 0,
                            Strategy.is_delete == is_delete,
                        )
                    else:
                        strategies = sc.query(Strategy).filter(
                            Strategy.node.in_([
                                'back_test', 'order_list', 'trademaster_order_list', 'cash_manager',
                            ]),
                            Strategy.is_test == 0,
                            Strategy.is_delete == is_delete,
                        )
                else:
                    strategies = sc.query(Strategy).filter(
                        Strategy.node == node,
                        Strategy.is_test == 0,
                        Strategy.is_delete == is_delete,
                    )
            else:
                if node == 'back_test':
                    if is_group == 'true':
                        strategies = sc.query(Strategy).join(
                            StrategyOwners,
                            StrategyOwners.strategy_id == Strategy.id
                        ).filter(
                            StrategyOwners.owner_id == self.current_user['id'],
                            Strategy.node.in_(['group']),
                            Strategy.is_test == 0,
                            Strategy.is_delete == is_delete,
                        )
                    else:
                        strategies = sc.query(Strategy).join(
                            StrategyOwners,
                            StrategyOwners.strategy_id == Strategy.id
                        ).filter(
                            StrategyOwners.owner_id == self.current_user['id'],
                            Strategy.node.in_([
                                'back_test', 'order_list', 'trademaster_order_list', 'cash_manager',
                            ]),
                            Strategy.is_test == 0,
                            Strategy.is_delete == is_delete,
                        )
                else:
                    strategies = sc.query(Strategy).join(
                        StrategyOwners,
                        StrategyOwners.strategy_id == Strategy.id
                    ).filter(
                        StrategyOwners.owner_id == self.current_user['id'],
                        Strategy.node == node,
                        Strategy.is_test == 0,
                        Strategy.is_delete == is_delete,
                    )
        else:
            if self.current_user['is_superuser']:
                strategies = sc.query(Strategy).filter(
                    Strategy.is_test == 0,
                    Strategy.is_delete == is_delete,
                )
            else:
                strategies = sc.query(Strategy).join(
                    StrategyOwners,
                    StrategyOwners.strategy_id == Strategy.id
                ).filter(
                    StrategyOwners.owner_id == self.current_user['id'],
                    Strategy.is_test == 0,
                    Strategy.is_delete == is_delete,
                )
            if is_group == "true":
                strategies = strategies.filter(
                    Strategy.node == "group"
                )
        if keyword:
            if keyword.isdigit():
                strategies = strategies.filter(
                    or_(
                        Strategy.id == int(keyword),
                        Strategy.id_no.ilike('%%%s%%' % keyword),
                    )
                )
            else:
                strategies = strategies.filter(Strategy.id_no.ilike('%%%s%%' % keyword))
        if is_delete == 1:
            group_ids = self.get_user_group()
            if consts.OPERATION_GROUP in group_ids:
                strategies = sc.query(
                    Strategy,
                ).join(
                    ToBeDeletedStrategy, ToBeDeletedStrategy.strategy_id == Strategy.id
                ).filter(
                    Strategy.is_delete == 1
                )
        strategies = strategies.filter(
            Strategy.is_derive_strategy == False
        )
        total = strategies.count()
        strategies = strategies.order_by(Strategy.id.desc()).offset(page * size).limit(size)
        if int(self.get_argument('size', -1)) < 0:
            self.json_response({
                'code': 0,
                'data': [s.to_dict_detail() for s in strategies],
            })
        else:
            self.json_response({
                'code': 0,
                'data': [s.to_dict_detail() for s in strategies],
                'total': total,
            })
        sc.commit()
        sc.close()
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        """
        The First entry when a strategy is been uploaded. 

        PAGE LOCATION:  Strategy research(Level 1 menu) -> Strategy creatation and management(Level 2 menu) -> Save(Button)

        """
        # check login
        self.get_current_user()
        if not self.current_user:
            return False

        # decide node
        node = self.get_argument('node')
        if self.get_argument('upload_type', 'so_file') == 'order_list':
            node = 'order_list'
        elif self.get_argument('upload_type', 'so_file') == 'trademaster_order_list':
            node = 'trademaster_order_list'
        elif self.get_argument('upload_type', 'so_file') == 'cash_manager':
            node = 'cash_manager'

        name = self.get_argument('name')
        strategy_id = self.get_argument('id', '')

        # decide if upload file exists
        if node == 'order_list':
            strategy_upload_file_id = -1
        elif strategy_id and (not (self.request.files and self.request.files['file'])):
            strategy_upload_file_id = -1
        else:
            try:
                upload_file = self.request.files['file'][0]
                file_data = {
                    'user_id': self.current_user['id'],
                    'content': upload_file['body'],
                    'filename': upload_file['filename'],
                    'file_type': {
                        'ev': 'ev',
                        'para': 'paras',
                        'back_test': 'st',
                        'trademaster_order_list': 'st',
                        'cash_manager': 'st',
                    }[node]
                }
                strategy_upload_file_id = StrategyUploadFile.save_file(file_data)
                if strategy_upload_file_id < 0:
                    raise ValueError('upload file failed')
            except Exception as e:
                self.application.sentry.captureException()
                self.json_response({
                    'code': 1019,
                    'data': 'upload file failed',
                })
                return False

        dependency = json.loads(self.get_argument('dependency', '[]'))
        detail = json.loads(self.get_argument('detail', '{}'))
        products = json.loads(self.get_argument('products', '[]'))
        start = format_date(self.get_argument('start', time.strftime('%Y-%m-%d')), '')
        end = '20500101'
        test = json.loads(self.get_argument('test', 'false'))

        # decide status
        status = consts.TASK_NEW if not test else consts.TASK_RUNNING
        if node in ('order_list', 'trademaster_order_list'):
            test = False
            status = consts.TASK_FINISHED
        elif node == 'ev':
            status = consts.TASK_RUNNING

        # decide post data
        post_data = {
            'node': node,
            'name': name,
            'dependency': dependency,
            'products': products,
            'start': start,
            'end': end,
            'test': test
        }
        for k, v in detail.items():
            post_data[k] = v
        post_data['desc'] = post_data.get('desc', '')[:100]
        post_data['max_pos'] = int(post_data.get('max_pos', 1000000))
        day, night = str(post_data.get('day', '')).lower(), str(post_data.get('night', '')).lower()
        if node == 'cash_manager':
            day, night = 'true', 'true'
        if day == 'true' and night == 'true':
            day_night = 2
        elif day == 'true':
            day_night = 0
        elif night == 'true':
            day_night = 1
        else:
            day_night = 0
        post_data['day_night'] = day_night

        # handle factor strategy
        if node == 'ev' and (detail.get('factor_type', '') in ('DAY', 'ALPHA')):
            detail['strategy_type'] = '26'
            post_data['strategy_type'] = '26'

        # decide id_no
        if (not strategy_id) and (not post_data['test']) and \
                (node in ('back_test', 'order_list', 'trademaster_order_list', 'cash_manager', 'ev')):
            strategy_type = post_data.get('strategy_type', '99')

            if node == 'ev' and strategy_type != '26':
                id_no = ''
            else:
                if node == 'cash_manager':
                    strategy_type = 'CM'
                id_no = Strategy.generate_id_no(
                    self.current_user['id'], strategy_type, time.strftime('%Y-%m-%d')
                )
        else:
            id_no = ''

        sc = session()

        # need comment why
        if strategy_id and test:
            if strategy_upload_file_id < 0:
                strategy = sc.query(Strategy).filter(
                    Strategy.id == strategy_id,
                    Strategy.r_create_user_id == self.current_user['id'],
                ).first()
                if not strategy:
                    self.json_response({
                        'code': 1013,
                        'error': 'can not find strategy id=%s and created by %s' % (
                            strategy_id, self.current_user['username'])
                    })
                    sc.close()
                    return False
                strategy_upload_file_id = strategy.strategy_upload_file_id
            strategy_id = None

        # handle new strategy
        if not strategy_id:
            strategy = Strategy(
                r_create_user_id=self.current_user['id'],
                r_update_user_id=self.current_user['id'],
                username=self.current_user['username'],
                name=post_data['name'],
                status=status,
                description=post_data['desc'],
                node=node,
                start_date=post_data['start'],
                end_date=post_data['end'],
                day_night=post_data['day_night'],
                products=post_data['products'],
                max_pos=post_data['max_pos'],
                dependency=post_data['dependency'],
                detail=post_data,
                st_uuid=uuid.uuid1().hex,
                strategy_type=post_data.get('strategy_type', ''),
                strategy_feature=post_data.get('strategy_feature', ''),
                strategy_underlying=post_data.get('strategy_underlying', ''),
                strategy_para_type=post_data.get('strategy_para_type', ''),
                strategy_status='BT' if node in ('order_list', 'trademaster_order_list') or post_data[
                    'test'] or node == 'ev' else 'NEW',
                id_no=id_no,
                code=id_no[-3:],
                is_test=1 if post_data['test'] else 0,
                strategy_upload_file_id=strategy_upload_file_id,
                hedge=post_data.get('hedge', ''),
                hedge_type=post_data.get('hedge_type', ''),
                paper_trading_date=datetime.datetime.now(),
                task_progress=0,
            )
            sc.add(strategy)
            sc.flush()
            strategy_owner = StrategyOwners(
                strategy_id=strategy.id,
                owner_id=self.current_user['id'],
                r_create_user_id=self.current_user['id'],
            )
            sc.add(strategy_owner)
            sc.commit()

            if post_data['test'] or node == 'ev':
                from cron.strategy_upload_task import start_strategy_task
                start_strategy_task.delay(strategy.id)
        else:
            # update strategy
            strategy = sc.query(Strategy).filter(
                Strategy.id == strategy_id,
                Strategy.r_create_user_id == self.current_user['id'],
            ).first()
            if not strategy:
                self.json_response({
                    'code': 1013,
                    'error': 'can not find strategy id=%s and created by %s' % (
                        strategy_id, self.current_user['username'])
                })
                sc.close()
                return False
            if not strategy.can_edit:
                self.json_response({
                    'code': 1011,
                    'error': u'已上传且未实盘的策略, 仅支持在一天内更新'
                })
                sc.close()
                return False

            # If strategy so file or dependencies have changed. 
            # Then we should reset paper trading date and start over again. 
            # decide if update paper trading
            update_paper_trading = False
            if strategy_upload_file_id > 0 and strategy_upload_file_id != strategy.strategy_upload_file_id:
                update_paper_trading = True
            if sorted([d['id'] for d in (strategy.dependency or [])]) != sorted(
                    [d['id'] for d in (post_data['dependency'] or [])]):
                update_paper_trading = True
            old_products = []
            if strategy.products:
                old_products = sorted([p['symbol'] for p in strategy.products[0]])
            new_products = []
            if post_data['products']:
                new_products = sorted(p['symbol'] for p in post_data['products'][0])
            if old_products != new_products:
                update_paper_trading = True

            strategy.r_update_user_id = self.current_user['id']
            strategy.name = post_data['name']
            strategy.description = post_data['desc']
            strategy.day_night = post_data['day_night']
            strategy.products = post_data['products']
            strategy.dependency = post_data['dependency']
            strategy.detail = post_data
            strategy.strategy_type = post_data.get('strategy_type', '')
            strategy.strategy_feature = post_data.get('strategy_feature', '')
            strategy.strategy_underlying = post_data.get('strategy_underlying', '')
            strategy.strategy_para_type = post_data.get('strategy_para_type', '')
            strategy.strategy_status = 'BT' if node in (
                'order_list', 'trademaster_order_list') or node == 'ev' else 'NEW'

            if update_paper_trading:
                strategy.paper_trading_date = datetime.datetime.now()

            if update_paper_trading and (not post_data['test']) and (
                    strategy.r_create_time.strftime('%Y%m%d') != strategy.paper_trading_date.strftime('%Y%m%d')):
                strategy.id_no = Strategy.generate_id_no(
                    self.current_user['id'],
                    strategy.strategy_type if strategy.node != 'cash_manager' else 'CM',
                    time.strftime('%Y-%m-%d')
                )
                strategy.code = strategy.id_no[-3:]

            # decide hedge
            if 'hedge' in post_data:
                strategy.hedge = post_data['hedge']
            if 'hedge_type' in post_data:
                strategy.hedge_type = post_data['hedge_type']

            # need comment why
            if strategy_upload_file_id > 0:
                strategy.strategy_upload_file_id = strategy_upload_file_id
                if strategy.node == 'trademaster_order_list':
                    sc.query(OrderList).filter(OrderList.strategy_id == strategy.id).delete()

            sc.commit()
            del_cache('platform_strategy_brief_%s' % strategy.id)
            del_cache('platform_strategy_detail_%s' % strategy.id)

        # NOTE:strategy_type 22(block chain) is deprecated,
        # can be deleted. (by xuxx)
        # if strategy.strategy_type == '22':
        # from cron.strategy_upload_task import btc_upload_done
        # btc_upload_done.delay(strategy.id)
        # self.json_response({
        #     'code': 1013,
        #     'error': 'Block chain strategy type has already been deprecated.'
        # })
        # sc.close()
        # return False

        # handle factor strategy
        if strategy.strategy_type == '26':
            from service.stock_factor.models import StockFactorStrategy
            StockFactorStrategy.copy_from_strategy(strategy.id)

        # handle api response
        data = strategy.to_dict()
        data['start'] = format_date(data['start'], '')
        data['end'] = time.strftime('%Y%m%d')
        self.json_response({
            'code': 0,
            'data': data,
        })

        sc.close()
        return True


class StrategyPatch(CurrentUserMixin, BaseHandler):
    @gen.coroutine
    def post(self, *args, **kwargs):
        """
        Only name and comments can be modified
        any other params will be ignored
        """
        self.get_current_user()
        if not self.current_user:
            return False

        # parse args 
        args = escape.json_decode(self.request.body)
        strategy_id = args.get("id", None)

        # id is required
        if not strategy_id:
            return False
        sc = session()

        # update name and description
        try:
            strategy_ = sc.query(Strategy).filter(
                Strategy.id == strategy_id,
                Strategy.r_create_user_id == self.current_user['id'],
            ).first()
            if not strategy_:
                # if the strategy doesn't exists
                self.json_response({
                    'code': APIResponseCode.DefaultError.value,
                    'error': 'can not find strategy id=%s and created by %s' % (
                        strategy_id, self.current_user['username'])
                })
                sc.close()
                return False

            # check if update name and description

            if strategy_.is_test == 0:
                # means is_test = 0 means back_test
                # check if update paper trading time
                node = args.get("node", "back_test")
                products = args.get("products", [])
                dependency = args.get("dependency", [])

                # check new so file
                if self.request.files and self.request.files['file']:
                    update_paper_trading_time = True
                    upload_file = self.request.files['file'][0]
                    file_data = {
                        'user_id': self.current_user['id'],
                        'content': upload_file['body'],
                        'filename': upload_file['filename'],
                        'file_type': {
                            'ev': 'ev',
                            'para': 'paras',
                            'back_test': 'st',
                            'trademaster_order_list': 'st',
                            'cash_manager': 'st',
                        }[node]
                    }
                    strategy_upload_file_id = StrategyUploadFile.save_file(file_data)
                    if strategy_upload_file_id < 0:
                        raise ValueError('upload file failed')
                    strategy_.strategy_upload_file_id = strategy_upload_file_id

                # check dependency
                if sorted([d['id'] for d in (strategy_.dependency or [])]) != sorted(
                        [d['id'] for d in (dependency or [])]):
                    strategy_.dependency = dependency
                    update_paper_trading_time = True

                # check product
                old_products = []
                if strategy_.products:
                    old_products = sorted([p['symbol'] for p in strategy_.products[0]])
                new_products = []
                if products:
                    new_products = sorted(p['symbol'] for p in products[0])
                if old_products != new_products:
                    update_paper_trading_time = True
                    strategy_.products = products

                # update paper trading time
                if update_paper_trading_time:
                    strategy_.paper_trading_date = datetime.datetime.now()

            else:
                # if it's on trading
                self.json_response({
                    "code": APIResponseCode.OK.value,
                    "data": "Only name and description can be edited"
                })
            sc.commit()
            strategy_.update_cache()
        except Exception as e:
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'error': "error occurred, transaction has been rolled back: <{}>".format(e.__str__())
            })
            sc.rollback()
            sc.close()
            return False

        self.json_response({
            "code": APIResponseCode.OK.value,
            "data": True
        })
        sc.close()
        return True


class StrategyViewHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        semi_lives = self.get_argument('semi_lives', 'false')
        semi_quantamental = self.get_argument('semi_quantamental', 'false')

        sc = session()
        try:
            sid = int(kwargs['id'])
        except Exception as e:
            sid = kwargs['id']

        s = sc.query(Strategy).filter(or_(
            Strategy.id == sid,
            Strategy.id_no == sid,
        )).first()

        if not s:
            self.write(json.dumps({
                'code': 1013,
                'error': 'can not find strategy id=%s' % sid
            }))
            sc.close()
            return True

        sid = s.id
        _data = {}
        uid = self.current_user['id']
        cfg_id, back_id = 0, 0

        if semi_lives == "true" and semi_quantamental == "true":
            cfg_info = BackTestConfig.get_config_id(uid, sid)
            if cfg_info["group_id"] == consts.STRAT_SINGLE:
                cfg_id = cfg_info["cfg_id"]
                _data = s.to_dict_detail(cfg_id, back_id)
                if 'quantamental' in _data:
                    if _data['quantamental'].get('status', 'NEW') != 'FINISHED':
                        _data['status'] = _data['quantamental'].get('status', 'NEW')
        elif semi_lives == "true":
            cfg_info = BackTestConfig.get_config_id(uid, sid)
            if cfg_info["group_id"] == consts.STRAT_SINGLE:
                cfg_id, back_id = cfg_info["cfg_id"], 0
            else:
                cfg_id, back_id = 0, cfg_info["cfg_id"]
            _data = s.to_dict_detail(config_id=cfg_id, back_id=back_id)
        elif semi_quantamental == 'true':
            cfg_info = BackTestConfig.get_config_id(uid, sid)
            config_id = cfg_info['cfg_id']
            q_cfg_obj = sc.query(BackTestConfig).filter(BackTestConfig.link_cfg_id == config_id).first()
            _data = s.to_dict_detail(config_id=q_cfg_obj.id)
        else:
            _data = s.to_dict_detail()

        need_return_accident = True
        if 'id' in _data:
            is_creator = StrategyUserRelation.is_creator(_data['id'], uid)
            is_investor = StrategyUserRelation.is_investor(_data['id'], uid)
            if uid != g_ROOT_ID and (not is_creator and not is_investor):
                need_return_accident = False

        if not need_return_accident:
            if 'live_pnl_detail' in _data:
                if 'events' in _data['live_pnl_detail']:
                    _data['live_pnl_detail']['events'] = {}

        self.json_response({
            'code': 0,
            'data': _data
        })

        sc.close()
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        """
        Start a strategy to back-testing
        Example:
            POST body
                {
                action: "back_test"
                start: "2020-2-24"
                initial_cash: 1000
                trade_model: "MY_ideal_matching"
                vwap_version: ""
                portfolio_optimization_so_version: ""
                se_cash_rate: 0.03
                }
        """
        self.get_current_user()
        if not self.current_user:
            return False
        sc = session()
        strategyid = int(kwargs['id'])
        if self.current_user['is_superuser']:
            s = sc.query(Strategy).filter(Strategy.id == strategyid).first()
        else:
            s = sc.query(Strategy).filter(
                Strategy.id == strategyid,
                Strategy.r_create_user_id == self.current_user['id']
            ).first()
        if not s:
            self.write(json.dumps({
                'code': 1013,
                'error': 'can not find strategy id=%s' % strategyid
            }))
            sc.close()
            return True
        else:
            post_data = self.get_payload()
            action = str(post_data.get('action', '')).lower()
            if action == 'stop':
                s.status = consts.TASK_STOPPED
                s.stop_task()
            elif action == 'recovery':
                from cron.strategy_upload_task import start_strategy_task
                s.status = consts.TASK_RUNNING
                s.is_delete = 0
                for dep in s.dependency:
                    dep_s = sc.query(Strategy).filter_by(id=dep['id']).first()
                    dep_s.status = consts.TASK_RUNNING
                    dep_s.is_delete = 0
                    start_strategy_task.delay(dep_s.id)
                start_strategy_task.delay(s.id)
            elif action == 'back_test':
                if s.node == 'cash_manager':
                    s.stop_task()
                    managercontent = post_data.get('managercontent', [])
                    detail = copy.deepcopy(s.detail)
                    s.start_date = format_date(post_data['start'], '')
                    detail['start'] = s.start_date
                    detail['managercontent'] = managercontent
                    detail['initial_cash'] = float(post_data.get('initial_cash', 1000000))
                    s.detail = detail
                    s.task_progress = 0
                    s.status = consts.TASK_RUNNING
                    if s.strategy_status not in ('LT', 'PT'):
                        s.strategy_status = 'BT'
                    sc.query(CashManagerBackTestResult).filter(
                        CashManagerBackTestResult.cash_manager_id == s.id,
                        CashManagerBackTestResult.cm_group_id == s.st_uuid,
                    ).delete(synchronize_session=False)
                    s.st_uuid = uuid.uuid1().hex
                    sc.commit()
                    from cron.strategy_upload_task import start_strategy_task
                    start_strategy_task.delay(s.id)
                else:
                    s.stop_task()
                    detail = copy.deepcopy(s.detail)
                    s.start_date = format_date(post_data['start'], '')
                    detail['start'] = s.start_date
                    detail['trade_model'] = str(post_data['trade_model'])
                    detail['initial_cash'] = float(post_data.get('initial_cash', 0))
                    detail['se_cash'] = float(post_data.get('se_cash', 0) or 0)
                    detail['se_cash_rate'] = float(post_data.get('se_cash_rate', 0) or 0)
                    detail['accounts'] = post_data.get('accounts', {})
                    if post_data.get('portfolio_optimization_so_version'):
                        detail['portfolio_optimization_so_version'] = post_data['portfolio_optimization_so_version']
                    if post_data.get('vwap_version'):
                        detail['vwap_version'] = post_data['vwap_version']
                    if detail['accounts']:
                        initial_cash = 0
                        for _, a_d in detail['accounts'].items():
                            initial_cash += a_d['cash']
                        detail['initial_cash'] = initial_cash
                    s.detail = detail
                    s.st_uuid = uuid.uuid1().hex
                    s.task_progress = 0
                    s.status = consts.TASK_RUNNING
                    if post_data.get('auto_paper_trading'):
                        s.auto_paper_trading = True
                        if not s.paper_trading_date:
                            s.paper_trading_date = datetime.datetime.now()
                    if s.strategy_status not in ('LT', 'PT'):
                        s.strategy_status = 'BT'
                    sc.query(StrategyResult).filter(StrategyResult.strategy_id == s.id,
                                                    StrategyResult.config_id == 0).delete(synchronize_session=False)
                    sc.query(StrategyResultDetail).filter(StrategyResultDetail.strategy_id == s.id,
                                                          StrategyResultDetail.config_id == 0).delete(
                        synchronize_session=False)
                    sc.query(StrategyResultAccount).filter(
                        StrategyResultAccount.strategy_id == s.id,
                        StrategyResultAccount.config_id == 0
                    ).delete(synchronize_session=False)
                    sc.commit()
                    from cron.strategy_upload_task import start_strategy_task
                    start_strategy_task.delay(s.id, task_id=s.st_uuid)
                    update_strategy_performance.delay(s.id)
                    update_strategy_sorting_result.delay(s.id)
                    Strategy.add_strategy_event(
                        s.id,
                        s.start_date,
                        0,
                        'AddStrategyBackTest',
                        task_id=s.st_uuid,
                        detail=post_data
                    )

            elif action == 'auto_paper_trading':
                s.auto_paper_trading = True
                if not s.paper_trading_date:
                    s.paper_trading_date = datetime.datetime.now()
                sc.commit()
            elif action == 'ev':
                if s.node == 'ev':
                    s.stop_task()
                    detail = copy.deepcopy(s.detail)
                    s.start_date = format_date(post_data['start'], '')
                    detail['start'] = s.start_date
                    s.detail = detail
                    s.task_progress = 0
                    s.status = consts.TASK_RUNNING
                    s.st_uuid = uuid.uuid1().hex
                    sc.query(StrategyResult).filter(StrategyResult.strategy_id == s.id,
                                                    StrategyResult.config_id == 0).delete()
                    sc.commit()
                    from cron.strategy_upload_task import start_strategy_task
                    start_strategy_task.delay(s.id)
                    Strategy.add_strategy_event(
                        s.id,
                        s.start_date,
                        0,
                        'AddEvTask',
                        task_id=s.st_uuid,
                        detail=post_data
                    )
            del_cache('platform_strategy_brief_%s_0_0' % s.id)
            del_cache('platform_strategy_detail_%s_0_0' % s.id)
            del_cache('platform_strategy_output_%s_0' % s.id)
            self.json_response({
                'code': 0,
                'data': s.to_dict_detail()
            })
            sc.commit()
            sc.close()
            return True

    @gen.coroutine
    def delete(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        sc = session()
        strategyid = int(kwargs['id'])
        if self.current_user['is_superuser']:
            s_obj = sc.query(Strategy).filter(
                Strategy.id == strategyid,
            )
            s = s_obj.first()
        else:
            s_obj = sc.query(Strategy).filter(
                Strategy.id == strategyid,
                Strategy.r_create_user_id == self.current_user['id']
            )
            s = s_obj.first()
        if not s:
            self.write(json.dumps({
                'code': 1013,
                'error': 'can not find strategy id=%s' % strategyid
            }))
            sc.close()
            return True
        else:
            if s.is_deployed:
                self.write(json.dumps({
                    'code': 1003,
                    'error': 'strategy is already deployed',
                }))
                sc.commit()
                return True

            factor = sc.query(StockFactorStrategy).filter(
                StockFactorStrategy.strategy_id == strategyid,
                StockFactorStrategy.status == 'Pool'
            ).first()

            if factor:
                self.json_response({
                    'code': 2003,
                    'error': 'factor is already in Pool',
                })
                sc.commit()
                sc.close()
                return True

            if s.group_id > 0:
                portfolio_id = s.group_id
                sc.query(ResearchStrategyPortfolioDetail).filter(
                    ResearchStrategyPortfolioDetail.portfolio_id == portfolio_id,
                ).delete()
                sc.query(ResearchStrategyPortfolio).filter(
                    ResearchStrategyPortfolio.id == portfolio_id,
                ).delete()
                s_obj.delete()
            else:
                depend_strategy = []
                strategies = sc.query(Strategy).filter(
                    Strategy.r_create_user_id == self.current_user['id'],
                    Strategy.is_test == 0,
                    Strategy.is_delete == 0,
                    Strategy.is_derive_strategy == False,
                ).all()
                for _s in strategies:
                    if strategyid in _s.input_dependency_ids:
                        depend_strategy.append({
                            'id': _s.id,
                            'name': _s.name,
                        })
                if depend_strategy:
                    self.write(json.dumps({
                        'code': 1003,
                        'error': 'other task depend on this task',
                        'data': depend_strategy,
                    }))
                    sc.commit()
                    return True

                dep = sc.query(Strategy.id).filter(
                    Strategy.is_test == 0,
                    Strategy.is_delete == 0,
                    Strategy.id.in_(
                        sc.query(
                            StrategyIncomeAttributionAdjusted.s_id
                        ).filter(
                            StrategyIncomeAttributionAdjusted.unajusted_s_id == strategyid
                        )
                    )
                )
                if dep.count():
                    self.json_response({
                        'code': 1003,
                        'error': 'strategy is dependency by other',
                    })
                    sc.close()
                    return False

                s.status = consts.TASK_FINISHED
                s.is_delete = 1
                s.stop_task()
            sc.commit()
            del_cache('platform_strategy_brief_%s' % s.id)
            del_cache('platform_strategy_detail_%s' % s.id)
            sc.close()
            self.write(json.dumps({
                'code': 0,
                'data': 'success',
            }))
            return True


class StrategyCloneHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        sc = session()
        try:
            s_id = int(kwargs['id'])
            s = sc.query(Strategy).filter(
                Strategy.id == s_id,
                Strategy.r_create_user_id == self.current_user['id'],
            ).first()
        except Exception as e:
            s_id = kwargs['id']
            s = sc.query(Strategy).filter(
                Strategy.id_no == s_id,
                Strategy.r_create_user_id == self.current_user['id'],
            ).first()

        if not s:
            sc.close()
            self.json_response({
                'code': 3006,
                'data': 'can not find strategy strategy_id=%s' % s_id,
                'error': 'can not find strategy strategy_id=%s' % s_id,
            })
            return False

        if s.node != 'back_test':
            sc.close()
            self.json_response({
                'code': 3006,
                'data': 'can not clone strategy strategy_id=%s' % s_id,
                'error': 'can not clone strategy strategy_id=%s' % s_id,
            })
            return False
        id_no = Strategy.generate_id_no(
            s.r_create_user_id, s.strategy_type or '99', time.strftime('%Y-%m-%d')
        )
        detail = copy.deepcopy(s.detail)
        detail['name'] = s.name + '(clone_from_%s)' % s.id
        detail['desc'] = s.description + '(clone_from_%s)' % s.id
        new_s = Strategy(
            r_create_user_id=s.r_create_user_id,
            r_update_user_id=s.r_update_user_id,
            username=s.username,
            name=detail['name'],
            status=consts.TASK_NEW,
            description=detail['desc'],
            node=s.node,
            start_date=detail['start'],
            end_date=s.end_date,
            day_night=s.day_night,
            products=s.products,
            max_pos=s.max_pos,
            dependency=s.dependency,
            detail=detail,
            st_uuid=uuid.uuid1().hex,
            strategy_type=s.strategy_type,
            strategy_feature=s.strategy_feature,
            strategy_underlying=s.strategy_underlying,
            strategy_para_type=s.strategy_para_type,
            strategy_status='NEW',
            id_no=id_no,
            code=id_no[-3:],
            is_test=0,
            strategy_upload_file_id=s.strategy_upload_file_id,
            hedge=s.hedge,
            hedge_type=s.hedge_type,
            paper_trading_date=(s.paper_trading_date or s.r_create_time).strftime('%Y%m%d'),
            confidence=1,
            task_progress=0,
            group_id=s.group_id,
            group_detail=s.group_detail,
        )
        sc.add(new_s)
        sc.commit()

        strategy_owner = StrategyOwners(
            strategy_id=new_s.id,
            owner_id=new_s.r_create_user_id,
            r_create_user_id=new_s.r_create_user_id,
        )
        sc.add(strategy_owner)
        sc.commit()
        new_s_id = new_s.id
        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'id': new_s_id,
                'id_no': id_no
            },
        })
        return True


class DependencyHandler(CurrentUserMixin, RequestHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        """
        get factor strategy dependency
        PAGE LOCATION: 因子研究->上传因子->新建->选择依赖
        """
        self.get_current_user()
        if not self.current_user:
            return False
        cache_key = 'platform_dependency_%s' % self.current_user['id']
        dependency = get_cache(cache_key)
        if dependency:
            self.write(json.dumps({
                'code': 0,
                'data': dependency
            }))
            return
        sc = session()
        strategies = sc.query(Strategy).filter(
            Strategy.node.in_(['ev', 'para']),
            Strategy.r_create_user_id == self.current_user['id'],
        ).order_by(Strategy.id.desc()).all()
        dependency = []
        for s in strategies:
            d = s.output_dependency()
            if d:
                dependency.extend(d)
        self.write(json.dumps({
            'code': 0,
            'data': dependency
        }))
        set_cache(cache_key, dependency, 30)
        sc.commit()
        sc.close()
        return True


class PerformanceHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        sc = session()
        strategyid = int(kwargs['id'])
        s = sc.query(Strategy).filter(Strategy.id == strategyid).first()
        if not s:
            self.json_response({
                'code': 1000,
                'data': 'can not find strategy strategy_id=%s' % strategyid
            })
            return False
        cache_key = 'strategy_performance_cache_%s' % s.id
        res = get_cache(cache_key)
        if not res:
            res = {
                'index': [
                    'strategy_id', 'strategy_name', 'date', 'symbol', 'exchange', 'open_cash', 'pnl', 'status',
                    'day_night', 'strategy_type', 'hedge', 'position_cash', 'hedge_type', 'trade_round', 'order_num',
                    'cancel_num', 'transaction_volume'
                ],
                'values': [],
            }
        if not res.get('values', []):
            from cron.strategy_upload_task import update_strategy_performance
            update_strategy_performance.delay(strategyid)
        self.json_response({
            'code': 0,
            'data': res,
        })
        # sc.commit()
        sc.close()
        return True


class PerformanceStrategyListHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        user_id = self.check_login()
        sc = session()
        strategies = sc.query(Strategy).filter(
            Strategy.node.in_(['back_test', 'order_list', 'trademaster_order_list', 'group']),
            Strategy.is_test == 0,
            Strategy.is_delete == 0,
        ).all()
        data = []
        for s in strategies:
            r = s.report(user_id)
            if r:
                data.append(r)
        self.json_response({
            'code': 0,
            'data': data
        })
        sc.commit()
        sc.close()
        return True


class GroupHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        cache_key = 'platform_strategy_group'
        group = get_cache(cache_key)
        if group:
            self.write(json.dumps({
                'code': 0,
                'data': group
            }))
            return
        data = []
        sc = session()
        groups = sc.query(StrategyPortfolio).filter(
            StrategyPortfolio.source == 'platform',
            StrategyPortfolio.status.notin_([-1, consts.STRATEGY_OFF_SHELF]),
        )
        for g in groups:
            try:
                data.append(g.analysis_detail())
            except Exception as e:
                sentry.captureExceptions()
        sc.close()
        set_cache(cache_key, data, 30)
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class PortfolioHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):
    """
        {
            'portfolio_id': 1111,
            'name': 'portfolio1',
            'gross': 10000,
            'desc': 'xxxxxxxxx',
            'weight': 'xxx',
            'date': '20170629',
            'str_weights': {
                1: 0.5,
                2: 0.3,
                3: 0.2,
            }
            'accounts': {
                1: {
                    'SHFE': {'account': 'futures_account', 'fund': 1000000, 'actual_fund': 1000000},
                    'SSE': {'account': 'stock_account', 'fund': 2000000, 'actual_fund': 1000000}},
                },
                2: {
                    'SHFE': {'account': 'futures_account2', 'fund': 1000000, 'actual_fund': 1000000}},
                    'LME': {'account': 'london_account', 'fund': 3000000, 'actual_fund': 1000000}},
                },
                3: {
                    'SHFE': {'account': 'futures_account3', 'fund': 1000000, 'actual_fund': 1000000}},
                    'DCE': {'account': 'account', 'fund': 3000000, 'actual_fund': 1000000}},
                }
            }
        }
    """

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        data = self.get_payload()
        sc = session()
        port = sc.query(StrategyPortfolio).filter(StrategyPortfolio.name == data['name']).first()
        if port:
            self.json_response({
                'code': 1117,
                'error': 'portfolio is already exists, please change the portfolio name'
            })
            return

        business = ''
        if self.current_user['id'] != 26:
            if self.is_stock_page():
                if not self.is_stock_group():
                    self.json_response({
                        'code': 2000,
                        'error': 'user have no stock permission'
                    })
                    return
                else:
                    business = 'stock'

            if self.is_future_page():
                if not self.is_future_group():
                    self.json_response({
                        'code': 2000,
                        'error': 'user have no future permission'
                    })
                    return
                else:
                    business = 'future'

        if not business:
            if self.current_user['id'] == consts.stock_user['id']:
                business = 'stock'
            elif self.current_user['id'] == consts.future_user['id']:
                business = 'future'

        research_portfolio_id = data.get('portfolio_id', None)
        research_portfolio = None
        if research_portfolio_id:
            research_portfolio = sc.query(ResearchStrategyPortfolio).filter(
                ResearchStrategyPortfolio.id == int(research_portfolio_id)
            ).first()
        if research_portfolio:
            research_portfolio.status = 'LT'
        else:
            self.json_response({
                'code': 1005,
                'error': '对象不存在'
            })
            return

        now = datetime.datetime.now()
        week_day = now.weekday()
        now_hour = now.strftime('%H%M')
        if week_day == 5:
            live_time = (now + datetime.timedelta(days=2)).strftime('%Y-%m-%d 00:00:00')
        elif week_day == 6:
            live_time = (now + datetime.timedelta(days=1)).strftime('%Y-%m-%d 00:00:00')
        else:
            if now_hour <= '0930':
                live_time = now.strftime('%Y-%m-%d 00:00:00')
            else:
                if week_day == 4:
                    live_time = (now + datetime.timedelta(days=3)).strftime('%Y-%m-%d 00:00:00')
                else:
                    live_time = (now + datetime.timedelta(days=1)).strftime('%Y-%m-%d 00:00:00')

        portfolio = StrategyPortfolio(
            name=data['name'],
            fund=float(data['gross']),
            description=data.get('desc', '') or '',
            r_create_user_id=self.current_user['id'],
            username=self.current_user['username'],
            live_time=live_time,
            status=consts.STRATEGY_TOBE_AUDITED,
            source='platform',
            research_portfolio_id=research_portfolio.id,
            business=business,
        )
        sc.add(portfolio)
        sc.commit()

        vs_strategies = []
        forex_rate = KdbQuery().get_forex_rate(datetime.datetime.now().strftime('%Y.%m.%d'))
        for strategy_id, weight in data['str_weights'].items():
            try:
                strategy_obj = sc.query(Strategy).filter(Strategy.id == strategy_id).first()
                if strategy_obj.group_id > 0 and strategy_obj.node in ['group']:
                    strategy_weight = strategy_obj.group_detail
                    group_id = strategy_id
                else:
                    strategy_weight = {strategy_id: 1}
                    group_id = 0

                strategy_total_fund = sum([float(f['fund']) for _, f in data['accounts'][strategy_id].items()])
                strategy_total_actual_fund = sum(
                    [float(f['actual_fund']) for _, f in data['accounts'][strategy_id].items()])

                for s_id, w in strategy_weight.items():
                    strategy = sc.query(Strategy).filter(Strategy.id == s_id).first()
                    symbols_accounts = []
                    exchange2products = {}
                    if strategy.node in ('back_test', 'order_list', 'trademaster_order_list', 'union_simu'):
                        for p in strategy.products[0]:
                            exchange2products[p['exch']] = exchange2products.get(p['exch'], []) + [p['symbol']]
                        for p in strategy.products[0]:
                            if p['exch'] in (consts.FUTURE_EXCHANGE + consts.FOREIGN_EXCHANGE):
                                if p['exch'] == 'LME':
                                    rank = ''
                                else:
                                    rank = '|'.join(sorted(map(str, p['rank'])))
                            elif p['type'] == 'index':
                                rank = 'index'
                            elif p['exch'] in ('SSE', 'SZSE'):
                                if p['type'] == 'stock_factor_FACTOR':
                                    rank = 'stock_factor'
                                else:
                                    rank = 'stock'
                            else:
                                rank = ''

                            if strategy_obj.group_id > 0:
                                amount = strategy_total_fund * float(w) / len(exchange2products) / len(
                                    exchange2products[p['exch']])
                                actual_amount = strategy_total_actual_fund * float(w) / len(exchange2products) / len(
                                    exchange2products[p['exch']])
                            else:
                                amount = float(data['accounts'][strategy_id][p['exch']]['fund']) / len(
                                    exchange2products[p['exch']])
                                actual_amount = float(data['accounts'][strategy_id][p['exch']]['actual_fund']) / len(
                                    exchange2products[p['exch']])

                            _symbol_account = {
                                'product': p['symbol'],
                                'account': data['accounts'][strategy_id][p['exch']]['account'],
                                'exchange': p['exch'],
                                'amount': amount,
                                'rank': rank,
                                'max_vol': '',
                                'currency': 'USD' if p['exch'].upper() in consts.FOREIGN_EXCHANGE else 'CNY',
                                'actual_amount': actual_amount,
                                'amount_rmb': amount,
                                'actual_amount_rmb': actual_amount,
                                'rate': 1,
                            }

                            if _symbol_account['currency'] != 'CNY':
                                _symbol_account['amount'] /= forex_rate[_symbol_account['currency'].lower()]
                                _symbol_account['actual_amount'] /= forex_rate[_symbol_account['currency'].lower()]
                                _symbol_account['rate'] = forex_rate[_symbol_account['currency'].lower()]

                            symbols_accounts.append(_symbol_account)

                    if strategy.day_night == 2:
                        symbols_accounts_detail = {
                            'day': symbols_accounts,
                            'night': symbols_accounts,
                        }
                    elif strategy.day_night == 1:
                        symbols_accounts_detail = {
                            'day': [],
                            'night': symbols_accounts,
                        }
                    elif strategy.day_night == 0:
                        symbols_accounts_detail = {
                            'day': symbols_accounts,
                            'night': []
                        }
                    else:
                        self.json_response({
                            'code': 1118,
                            'error': 'strategy day_night() is error' % strategy.day_night
                        })
                        return

                    vs_paras = {
                        'portfolio_id': portfolio.id,
                        'strategy_id': s_id,
                        'strategy_weight': float(weight) * float(w),
                        'symbols_accounts_detail': symbols_accounts_detail,
                        'status': consts.STRATEGY_TOBE_AUDITED,
                        'source': 'platform',
                        'group_id': group_id,
                    }
                    vs = VStrategies(**vs_paras)
                    vs_strategies.append(vs)

                if not strategy_obj.live_time:
                    strategy_obj.live_time = live_time

                strategy_obj.strategy_status = 'LT'
            except Exception as e:
                sentry.captureException()
                self.json_response({
                    'code': 1119,
                    'error': 'paras format error'
                })
                sc.query(StrategyPortfolio).filter(StrategyPortfolio.id == portfolio.id).delete()
                sc.commit()
                return

        for vs in vs_strategies:
            sc.add(vs)
        sc.commit()

        on_line_request = OnlineRequest(
            portfolio_id=portfolio.id,
            status=0,
            action=0,
            r_create_user=self.current_user['username']
        )
        sc.add(on_line_request)
        sc.commit()

        portfolio_id = portfolio.id
        try:
            for vs in sc.query(VStrategies).filter(VStrategies.portfolio_id == portfolio_id):
                symbols_accounts = vs.symbols_accounts_detail['day'] or vs.symbols_accounts_detail['night']
                account_detail = {}
                for _detail in symbols_accounts:
                    if _detail['exchange'] not in account_detail:
                        account_detail[_detail['exchange']] = {
                            'account': _detail['account'],
                            'fund': float(_detail['amount_rmb']),
                            'actual_fund': float(_detail['actual_amount_rmb']),
                        }
                    else:
                        account_detail[_detail['exchange']]['fund'] += float(_detail['amount_rmb'])
                        account_detail[_detail['exchange']]['actual_fund'] += float(_detail['actual_amount_rmb'])

                for exch, exchange_detail in account_detail.items():
                    vs_account_detail = VStrategyAccountDetail(
                        vstrategy_id=vs.id,
                        portfolio_id=portfolio_id,
                        account=exchange_detail['account'],
                        amount=exchange_detail['fund'],
                        actual_amount=exchange_detail['actual_fund'],
                        exchange=exch,
                    )
                    sc.add(vs_account_detail)

            sc.commit()
        except Exception as e:
            sc.rollback()
            sentry.captureException()

        sc.close()
        notify_operation_wechat('新组合(%s)提交实盘，请尽快审核并部署' % data['name'])
        self.json_response({
            'code': 0,
            'data': {},
        })


class DeployStrategyListV3Handler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        strategies = Strategy.get_live_strategy_analysis(self.current_user)
        headers_data = [
            {
                'prop': 'strategy_id',
                'title': '策略ID',
                'display': True,
                'sum': False
            },
            {
                'prop': 'name',
                'title': '名称',
                'display': True,
                'sum': False
            },
            {
                'prop': 'invest_user',
                'title': '投资者',
                'display': True,
                'sum': False
            },
            {
                'prop': 'uptime',
                'title': '上载时间',
                'display': True,
                'sum': False
            },
            {
                'prop': 'realtime',
                'title': '实盘时间',
                'display': True,
                'sum': False
            },
            {
                'prop': 'invest_funds',
                'title': '最新面值',
                'display': True,
                'sum': True
            },
            {
                'prop': 'total_pnl',
                'title': '总盈亏额',
                'display': True,
                'sum': True
            },
            {
                'prop': 'history_pnl',
                'title': '净值曲线',
                'display': True,
                'sum': False
            },
            {
                'prop': 'total_point',
                'title': '策略分账',
                'display': True,
                'sum': True
            },
            {
                'prop': 'vwap_slippage',
                'title': 'VWAP滑点(BP)<br>平均/标准差',
                'display': True,
                'sum': False
            },
            {
                'prop': 'status',
                'title': '策略状态',
                'display': True,
                'sum': False
            }
        ]
        data = {
            'summary': {
                'rows': strategies,
                'headers': headers_data
            }
        }
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StrategyDeployViewHandler(BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_id = int(kwargs['id'])
        date = self.get_argument('trading_date')
        day_night = int(self.get_argument('day_night'))

        day_night_mapping = {
            0: 'day',
            1: 'night'
        }
        day_night_str = day_night_mapping.get(day_night)
        if not day_night_str:
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'data': {
                    'msg': '{day_night} not valid'.format(day_night=day_night)
                }
            })
            return

        trading_calendar = TradeCalendar.init_from_kdb(**config.kdb_config)
        if not trading_calendar.is_trading_date(date=date):
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'data': {
                    'msg': '{date} is not trading date'.format(date=date)
                }
            })
            return

        sc = session()
        vs = sc.query(VStrategies).filter(VStrategies.id == vs_id).first()
        if not vs:
            sc.close()
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'data': {
                    'msg': 'vs {vs_id} not exists'.format(vs_id=vs_id)
                }
            })
            return

        if vs.status >= consts.STRATEGY_OFF_SHELF:
            sc.close()
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'data': {
                    'msg': 'vs {vs_id} is off_shelf'.format(vs_id=vs_id)
                }
            })
            return

        s_id = vs.strategy_id
        s = sc.query(Strategy).filter(Strategy.id == s_id).first()
        if not s:
            sc.close()
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'data': {
                    'msg': 'strategy {s_id} not exists'.format(s_id=s_id)
                }
            })
            return

        if s.day_night != 2 and s.day_night != day_night:
            sc.close()
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'data': {
                    'msg': 'strategy {s_id} do not support {day_night}'.format(s_id=s_id, day_night=day_night)
                }
            })
            return

        clear, close_status = None, False
        if vs.closing_out == consts.STRATEGY_CLOSING_OUT:
            clear = ClearPosition(vs_id)
            close_status = clear.check_position()
            if not close_status:
                sc.close()
                self.json_response({
                    'code': APIResponseCode.DefaultError.value,
                    'data': {
                        'msg': 'vs {vs_id} will be off_shelf'.format(vs_id=vs_id)
                    }
                })
                return

        # date = Strategy.get_trading_date(hour=19)
        # now_hour = datetime.datetime.now().hour
        # if 6 <= now_hour < 19:
        #     day_night_str = 'day'
        # else:
        #     day_night_str = 'night'
        #
        # if s.strategy_type in consts.stock_strategy_type:
        #     day_night_str = 'day'

        if s.node in {'back_test', 'union_simu'}:
            ev_files = []
            if clear and close_status:
                out_put_path = 'strategy_upload/output/%s/%s' % (s.username, s.name.strip().replace(' ', ''))
                full_out_path = os.path.join(config.media, out_put_path)
                if not os.path.exists(full_out_path):
                    os.makedirs(full_out_path)

                ev_file = os.path.join(full_out_path, 'clear_postion_%s_%s.csv' % (date, str(vs_id)))
                if not clear.generate_order_list_v2(ev_file):
                    sc.close()
                    self.json_response({
                        'code': APIResponseCode.DefaultError.value,
                        'data': {
                            'msg': 'can not generate clear position ev file, vs_id={}, ev={}'.format(
                                vs_id, ev_file
                            )
                        }
                    })
                    return
                else:
                    ev_files.append(ev_file)

                symbols_accounts_detail = self.gen_symbols_accounts_detail(sc, ev_file, s, vs)
                res = {
                    'id': s.id,
                    'name': s.id_no,
                    'so_file': '',
                    'ev_files': ev_files,
                    'strategy_type': 'clear_position',
                    'ev_changed': True,
                    'symbols_accounts': symbols_accounts_detail,
                    'st_idle': 0
                }
            else:
                for dep in s.dependency:
                    dep_s = sc.query(Strategy).filter(Strategy.id == dep['id']).first()
                    ev_file = 'strategy_upload/output/%s/%s/ev_output_%s_%s_%s.csv' % (
                        dep_s.username, dep_s.name.strip().replace(' ', ''), date, str(dep_s.id), day_night_str
                    )
                    if not os.path.exists(os.path.join(config.media, ev_file)):
                        sc.close()
                        self.json_response({
                            'code': APIResponseCode.DefaultError.value,
                            'data': {
                                'msg': 'can not find ev file date={}, s_id={}, ev_id={}'.format(
                                    date, s.id, dep_s.id
                                )
                            }
                        })
                        return
                    else:
                        ev_files.append(ev_file)

                res = {
                    'id': s.id,
                    'name': s.id_no,
                    'so_file': s.strategy_upload_file['relative_path'],
                    'ev_files': ev_files,
                    'strategy_type': s.node,
                    'ev_changed': True,
                    'st_idle': int(float(s.detail.get('time_interval', 0))),
                }
        elif s.node in {'order_list', 'trademaster_order_list'}:
            ev_files = []
            out_put_path = 'strategy_upload/output/%s/%s' % (s.username, s.name.strip().replace(' ', ''))
            full_out_path = os.path.join(config.media, out_put_path)
            ev_file = os.path.join(full_out_path, 'tradelist_ev_output_%s_%s.csv' % (date, str(s.id)))
            ev_deploy_file = os.path.join(out_put_path, 'tradelist_ev_output_%s_%s.csv' % (date, str(s.id)))
            if not os.path.exists(full_out_path):
                os.makedirs(full_out_path)

            # 处理清仓的逻辑
            if clear and close_status:
                ev_file = os.path.join(full_out_path, 'clear_postion_%s_%s.csv' % (date, str(vs_id)))
                clear.generate_order_list_v2(ev_file)
                ev_files.append(ev_file)
            else:
                try:
                    orderlist_count = sc.query(OrderList).filter(
                        OrderList.strategy_id == s.id,
                        OrderList.date == date,
                    ).count()
                    if orderlist_count <= 0:
                        sc.close()
                        self.json_response({
                            'code': APIResponseCode.DefaultError.value,
                            'data': {
                                'msg': 'order list is empty s_id={}, date={}'.format(
                                    s.id, date
                                )
                            }
                        })
                        return

                    url = 'http://%s/v1/moms/trade-list?date=%s&st_id=%s' % (config.analysis_service, date, s.id)
                    http_client = httpclient.AsyncHTTPClient()
                    response = yield gen.Task(http_client.fetch, url)
                    ev_content = json.loads(str(response.body, 'utf-8'))['data'][str(s.id)]
                    if not ev_content:
                        sc.close()
                        self.json_response({
                            'code': APIResponseCode.DefaultError.value,
                            'data': {
                                'msg': 'get trade list error strategy_id={}'.format(
                                    s.id
                                )
                            }
                        })
                        return

                    f = open(ev_file, 'wb')
                    f.write(bytes(ev_content, encoding='utf8'))
                    f.close()
                    ev_files.append(ev_deploy_file)
                except Exception as e:
                    sentry.captureException()
                    sc.close()
                    self.json_response({
                        'code': APIResponseCode.DefaultError.value,
                        'data': {
                            'msg': 'get trade list ev error'
                        }
                    })
                    return

            symbols_accounts_detail = self.gen_symbols_accounts_detail(sc, ev_file, s, vs)
            res = {
                'id': s.id,
                'name': s.id_no,
                'so_file': '',
                'ev_files': ev_files,
                'strategy_type': s.node,
                'ev_changed': True,
                'symbols_accounts': symbols_accounts_detail,
                'st_idle': 0
            }
        else:
            sc.close()
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'data': {
                    'msg': '{node} not support'.format(node=s.node)
                }
            })
            return

        res['is_t0_strategy'] = s.strategy_type in consts.t0_stock_strategy_type
        res['business'] = 'stock' if s.strategy_type in consts.stock_strategy_type else 'future'
        if s.strategy_type in consts.stock_strategy_type:
            res['reserve_type'] = 2
        else:
            res['reserve_type'] = 1
        res['portfolio_opt_version'] = StockPortfolioOptimizationVersion.get_paras(
            s.detail.get('portfolio_optimization_so_version', '')
        )

        res['is_factor_generate'] = bool(s.strategy_type == '26')
        res['factor_book'] = s.get_factor_book()

        if res['portfolio_opt_version'] and len(res['portfolio_opt_version']) >= 31:
            res['reserve_type'] = 2

        if res['factor_book']:
            res['reserve_type'] = 3

        if s.r_create_user_id == 609:
            res['reserve_type'] = 3

        res['smart_execution_so_version'] = s.detail.get('vwap_version', 'vwap_classic') or 'vwap_classic'

        if res['smart_execution_so_version'] == 'v1':
            res['smart_execution_so_version'] = 'vwap_classic'

        res['portfolio_opt_ev_path'] = './st_ev/'
        res['smart_execution_ev_path'] = ''
        res['smart_execution_so_path'] = ''
        res['smart_execution_so_symbols'] = []
        res['se_cash'] = 0
        res['income_attribution'] = []
        if s.strategy_type in consts.stock_strategy_type:
            res['se_cash'] = s.detail.get('se_cash_rate', 0) * VStrategies.get_total_investment(vs_id, date)

        if s.strategy_type in consts.alpha_stock_strategy_type:
            res['income_attribution'] = StrategyIncomeAttribution.get_income_attribution_adjusted(s.id, date)
            if res['income_attribution'] is None:
                sc.close()
                self.json_response({
                    'code': APIResponseCode.DefaultError.value,
                    'data': {
                        'msg': 'get alpha income_attribution error'
                    }
                })
                return

        if res['smart_execution_so_version'] != 'vwap_classic':
            exe_version = sc.query(
                StockSmartExecutionVersion
            ).filter(
                StockSmartExecutionVersion.value == res['smart_execution_so_version']
            ).first()

            if not exe_version:
                sc.close()
                self.json_response({
                    'code': APIResponseCode.DefaultError.value,
                    'data': {
                        'msg': 'smart execution version(%s) error'.format(res['smart_execution_so_version'])
                    }
                })
                return

            exe_s = sc.query(Strategy).filter(Strategy.id == exe_version.strategy_id).first()
            if not exe_s:
                sc.close()
                self.json_response({
                    'code': APIResponseCode.DefaultError.value,
                    'data': {
                        'msg': 'smart execution version(%s) error'.format(res['smart_execution_so_version'])
                    }
                })
                return

            smart_execution_ev = []
            for exe_dep in exe_s.dependency:
                exe_dep_s = sc.query(Strategy).filter(Strategy.id == exe_dep['id']).first()
                exe_ev_file = 'strategy_upload/output/%s/%s/ev_output_%s_%s_%s.csv' % (
                    exe_dep_s.username, exe_dep_s.name.strip().replace(' ', ''),
                    date, str(exe_dep_s.id), day_night_str
                )
                if not os.path.exists(os.path.join(config.media, exe_ev_file)):
                    sc.close()
                    self.json_response({
                        'code': APIResponseCode.DefaultError.value,
                        'data': {
                            'msg': 'can not find ev file date={}, s_id={}, ev_id={}'.format(
                                date, exe_s.id, exe_dep_s.id
                            )
                        }
                    })
                    return
                else:
                    smart_execution_ev.append(
                        os.path.join('./st_ev/', os.path.basename(exe_ev_file))
                    )

            res['smart_execution_ev_path'] = '|'.join(smart_execution_ev)
            res['smart_execution_so_path'] = './st_so/smart_execution_%s.so' % res['smart_execution_so_version']

            if exe_s.products:
                for p in exe_s.products[0]:
                    if p['exch'] in (consts.FUTURE_EXCHANGE + consts.FOREIGN_EXCHANGE):
                        if p['exch'] == 'LME':
                            rank = ''
                        else:
                            rank = '|'.join(sorted(map(str, p['rank'])))
                    elif p['type'] == 'index':
                        rank = 'index'
                    elif p['exch'] in ('SSE', 'SZSE'):
                        rank = 'stock'
                    else:
                        rank = ''

                    if p['type'] == 'stock_factor_FACTOR':
                        continue

                    smart_execution_so_symbol = {
                        'currency': 'CNY',
                        'product': p['symbol'],
                        'rank': rank,
                        'amount': 0,
                        'account': '',
                        'max_vol': '',
                        'exchange': p['exch'],
                        'rate': 1
                    }

                    res['smart_execution_so_symbols'].append(smart_execution_so_symbol)

        # 轧差交易策略，获取共享回报信息
        if s.strategy_type == StrategyConstant.StrategyType.MergeTrade.value:
            share_resp = get_merge_vs_share_resp_info(merge_vs_id=vs_id)
            if share_resp:
                res["extra_rsp"] = share_resp

        sc.close()
        self.json_response({
            'code': 0,
            'data': res
        })
        return

    def gen_symbols_accounts_detail(self, sc, ev_file, s, vs):
        trade_list_file = open(os.path.join(config.media, ev_file), 'r')
        symbols = [row['symbol'] for row in csv.DictReader(trade_list_file)]
        kdb = KdbQuery()
        product2exchange = {}
        for porfolio in s.products:
            for _p in porfolio:
                product2exchange[_p['symbol']] = _p.get('exch', '')
        product2exchange.update(get_stock_detail())
        product2exchange.update(consts.LONGPRODUCT2EXCHANGE)
        product2exchange.update(consts.SHORTPRODUCTS2EXCHANGE)
        product2exchange.update(kdb.get_symbol_exchange())
        symbol2exchange = {_symbol: product2exchange[_symbol] for _symbol in symbols}
        exchange_account = {}
        for _s_account in VStrategies.normalization_symbols_accounts(vs.symbols_accounts_detail):
            if _s_account['exchange'] not in exchange_account:
                exchange_account[_s_account['exchange']] = {
                    'account': _s_account['account'],
                    'amount': _s_account['amount']
                }
            else:
                if _s_account['account'] != exchange_account[_s_account['exchange']]['account']:
                    raise ValueError('account error')
                else:
                    exchange_account[_s_account['exchange']]['amount'] += _s_account['amount']

        if ('SSE' in symbol2exchange.values()) and ('SSE' not in exchange_account):
            exchange_account['SSE'] = {
                'account': exchange_account['SZSE']['account'],
                'amount': 0
            }

        if ('SZSE' in symbol2exchange.values()) and ('SZSE' not in exchange_account):
            exchange_account['SZSE'] = {
                'account': exchange_account['SSE']['account'],
                'amount': 0
            }

        exchange_symbols_count = dict(Counter(symbol2exchange.values()))
        symbols_accounts = []
        for _symbol in symbols:
            _symbol_exchange = symbol2exchange[_symbol]
            if _symbol_exchange in consts.FUTURE_EXCHANGE:
                rank = 'future'
            elif _symbol_exchange in consts.STOCK_EXCHANGE:
                rank = 'stock'
            elif _symbol_exchange in consts.FOREIGN_EXCHANGE:
                rank = 'foreign'
            else:
                rank = ''
            symbols_accounts.append({
                'product': _symbol,
                'account': exchange_account[_symbol_exchange]['account'],
                'exchange': _symbol_exchange,
                'amount': exchange_account[_symbol_exchange]['amount'] / exchange_symbols_count[_symbol_exchange],
                'rank': rank,
                'max_vol': '',
                'currency': 'CNY',
            })
        day_night = int(s.day_night)
        if day_night == 0:
            return {
                'day': symbols_accounts,
                'night': [],
            }
        elif day_night == 1:
            return {
                'day': [],
                'night': symbols_accounts,
            }
        elif day_night == 2:
            return {
                'day': symbols_accounts,
                'night': symbols_accounts,
            }
        else:
            sc.close()
            raise ValueError('day_night=%s error' % day_night)


class StrategyDeployEvViewHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_id = int(kwargs['id'])
        date = self.get_argument('trading_date')
        day_night = int(self.get_argument('day_night'))

        day_night_mapping = {
            0: 'day',
            1: 'night'
        }
        day_night_str = day_night_mapping.get(day_night)
        if not day_night_str:
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'data': {
                    'msg': '{day_night} not valid'.format(day_night=day_night)
                }
            })
            return

        # TODO: 交易日的判断可以去掉，提到调用者的地方判断，避免部署多个EV时，每次都需要校验。
        trading_calendar = TradeCalendar.init_from_kdb(**config.kdb_config)
        if not trading_calendar.is_trading_date(date=date):
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'data': {
                    'msg': '{date} is not trading date'.format(date=date)
                }
            })
            return

        sc = session()
        vs = sc.query(VStrategies).filter(VStrategies.id == vs_id).first()
        if not vs:
            sc.close()
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'data': {
                    'msg': 'vs {vs_id} not exists'.format(vs_id=vs_id)
                }
            })
            return

        if vs.status >= consts.STRATEGY_OFF_SHELF:
            sc.close()
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'data': {
                    'msg': 'vs {vs_id} is off_shelf'.format(vs_id=vs_id)
                }
            })
            return

        s_id = vs.strategy_id
        s = sc.query(Strategy).filter(Strategy.id == s_id).first()
        if not s:
            sc.close()
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'data': {
                    'msg': 'strategy {s_id} not exists'.format(s_id=s_id)
                }
            })
            return

        if s.day_night != 2 and s.day_night != day_night:
            sc.close()
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'data': {
                    'msg': 'strategy {s_id} do not support {day_night}'.format(s_id=s_id, day_night=day_night)
                }
            })
            return

        clear, close_status = None, False
        if vs.closing_out == consts.STRATEGY_CLOSING_OUT:
            clear = ClearPosition(vs_id)
            close_status = clear.check_position()
            if not close_status:
                sc.close()
                self.json_response({
                    'code': APIResponseCode.DefaultError.value,
                    'data': {
                        'msg': 'vs {vs_id} will be off_shelf'.format(vs_id=vs_id)
                    }
                })
                return

        # date = Strategy.get_trading_date(hour=19)
        # now_hour = datetime.datetime.now().hour
        # if 6 <= now_hour <= 18:
        #     day_night_str = 'day'
        # else:
        #     day_night_str = 'night'
        #
        # if s.strategy_type in consts.stock_strategy_type:
        #     day_night_str = 'day'

        if s.node in {'back_test', 'union_simu'}:
            ev_files = []
            if clear and close_status:
                out_put_path = 'strategy_upload/output/%s/%s' % (s.username, s.name.strip().replace(' ', ''))
                full_out_path = os.path.join(config.media, out_put_path)
                if not os.path.exists(full_out_path):
                    os.makedirs(full_out_path)

                ev_file = os.path.join(full_out_path, 'clear_postion_%s_%s.csv' % (date, str(vs_id)))
                if not clear.generate_order_list_v2(ev_file):
                    sc.close()
                    self.json_response({
                        'code': APIResponseCode.DefaultError.value,
                        'data': {
                            'msg': 'can not generate clear position ev file, vs_id={}, ev={}'.format(
                                vs_id, ev_file
                            )
                        }
                    })
                    return
                else:
                    ev_files.append(ev_file)

                res = {
                    'id': s.id,
                    'name': s.id_no,
                    'so_file': '',
                    'ev_files': ev_files,
                    'strategy_type': 'clear_position',
                }
            else:
                for dep in s.dependency:
                    dep_s = sc.query(Strategy).filter(Strategy.id == dep['id']).first()
                    ev_file = 'strategy_upload/output/%s/%s/ev_output_%s_%s_%s.csv' % (
                        dep_s.username, dep_s.name.strip().replace(' ', ''), date, str(dep_s.id), day_night_str
                    )
                    if not os.path.exists(os.path.join(config.media, ev_file)):
                        sc.close()
                        self.json_response({
                            'code': APIResponseCode.DefaultError.value,
                            'data': {
                                'msg': 'can not find ev file date={}, s_id={}, ev_id={}'.format(
                                    date, s.id, dep_s.id
                                )
                            }
                        })
                        return
                    else:
                        ev_files.append(ev_file)

                res = {
                    'id': s.id,
                    'name': s.id_no,
                    'so_file': s.strategy_upload_file['relative_path'],
                    'ev_files': ev_files,
                    'strategy_type': s.node,
                }
        elif s.node in {'order_list', 'trademaster_order_list'}:
            ev_files = []
            out_put_path = 'strategy_upload/output/%s/%s' % (s.username, s.name.strip().replace(' ', ''))
            full_out_path = os.path.join(config.media, out_put_path)
            ev_file = os.path.join(full_out_path, 'tradelist_ev_output_%s_%s.csv' % (date, str(s.id)))
            ev_deploy_file = os.path.join(out_put_path, 'tradelist_ev_output_%s_%s.csv' % (date, str(s.id)))
            if not os.path.exists(full_out_path):
                os.makedirs(full_out_path)

            # 处理清仓的逻辑
            if clear and close_status:
                ev_file = os.path.join(full_out_path, 'clear_postion_%s_%s.csv' % (date, str(vs_id)))
                clear.generate_order_list_v2(ev_file)
                ev_files.append(ev_file)
            else:
                try:
                    orderlist_count = sc.query(OrderList).filter(
                        OrderList.strategy_id == s.id,
                        OrderList.date == date,
                    ).count()
                    if orderlist_count <= 0:
                        sc.close()
                        self.json_response({
                            'code': APIResponseCode.DefaultError.value,
                            'data': {
                                'msg': 'order list is empty s_id={}, date={}'.format(
                                    s.id, date
                                )
                            }
                        })
                        return

                    url = 'http://%s/v1/moms/trade-list?date=%s&st_id=%s' % (config.analysis_service, date, s.id)
                    http_client = httpclient.AsyncHTTPClient()
                    response = yield gen.Task(http_client.fetch, url)
                    ev_content = json.loads(str(response.body, 'utf-8'))['data'][str(s.id)]
                    if not ev_content:
                        sc.close()
                        self.json_response({
                            'code': APIResponseCode.DefaultError.value,
                            'data': {
                                'msg': 'get trade list error s_id={}'.format(
                                    s.id
                                )
                            }
                        })
                        return

                    f = open(ev_file, 'wb')
                    f.write(bytes(ev_content, encoding='utf8'))
                    f.close()
                    ev_files.append(ev_deploy_file)
                except Exception as e:
                    sc.close()
                    sentry.captureException()
                    self.json_response({
                        'code': APIResponseCode.DefaultError.value,
                        'data': {
                            'msg': 'get trade list ev error'
                        }
                    })
                    return

            res = {
                'id': s.id,
                'name': s.id_no,
                'so_file': '',
                'ev_files': ev_files,
                'strategy_type': s.node,
            }
        else:
            sc.close()
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'data': {
                    'msg': 'invalid node: {}'.format(s.node)
                }
            })
            return

        sc.close()
        self.json_response({
            'code': 0,
            'data': res
        })


# class StrategyLogHandler(CurrentUserMixin, BaseHandler):
#
#     @gen.coroutine
#     def get(self, *args, **kwargs):
#         self.get_current_user()
#         if not self.current_user:
#             return False
#         sc = session()
#         strategyid = int(kwargs['id'])
#         if self.current_user['is_superuser']:
#             s = sc.query(Strategy).filter(
#                 Strategy.id == strategyid,
#             ).first()
#         else:
#             s = sc.query(Strategy).filter(
#                 Strategy.id == strategyid,
#                 Strategy.r_create_user_id == self.current_user['id']
#             ).first()
#         if not s:
#             self.write(json.dumps({
#                 'code': 1013,
#                 'error': 'can not find strategy id=%s' % strategyid
#             }))
#             sc.close()
#             return True
#         else:
#             self.write(json.dumps({
#                 'code': 0,
#                 'data': ''
#             }))
#             sc.close()
#             return True


# class DailyCheckHandler(BaseHandler):
#
#     @gen.coroutine
#     def get(self, *args, **kwargs):
#         from cron.strategy_upload_task import deploy_daily_check
#         deploy_daily_check.delay()
#         self.json_response({
#             'code': 0
#         })
#         return True


class ResearchPortfoliosHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        kwargs = {k: self.get_argument(k, '') for k in ('status', 'creator')}
        kwargs['create_type'] = self.get_argument('create_type', 0)
        kwargs['semi_lives'] = self.get_argument('semi_lives', 'false')
        details = ResearchStrategyPortfolio.portfolio_details(self.current_user, **kwargs)
        self.json_response({
            'code': 0,
            'data': details
        })
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        user_id = self.current_user['id']
        payload = self.get_payload()
        if not payload['strategies']:
            self.json_response({
                'code': 1007,
                'error': 'strategies can not empty'
            })
            return False
        create_type = payload.get('create_type', 0)  # 0:投资组合;1:策略组合
        semi_lives = payload.get('semi_lives', 0)  # 0:不保存待实盘; 1:保存待实盘
        sc = session()
        portfolio = sc.query(ResearchStrategyPortfolio).filter(
            ResearchStrategyPortfolio.name == payload['name']).first()
        if portfolio:
            self.json_response({
                'code': 1020,
                'error': '策略组合名称已存在'
            })
            return False
        portfolio = ResearchStrategyPortfolio(
            r_create_user_id=self.current_user['id'],
            r_update_user_id=self.current_user['id'],
            username=self.current_user['username'],
            name=payload['name'],
            fund=float(payload['gross']),
            description=payload.get('desc', ''),
            status='PT',
            weight_type=int(payload['weight']),
            is_public=True,
            create_type=create_type,
        )
        sc.add(portfolio)
        sc.commit()
        portfolio_id = portfolio.id
        group_strategy_id = 0

        if int(semi_lives) > 0:
            BackTestConfig.add_config(user_id, portfolio_id, consts.INVEST_GROUP)
        try:
            strategy_weight = {int(s['id']): float(s['weight']) for s in payload['strategies']}
            if create_type == 1:
                for s_id in strategy_weight.keys():
                    s_obj = sc.query(Strategy).filter(Strategy.id == s_id).first()
                    if s_obj.group_id > 0:
                        raise ValueError("sub-strategy cannot be a strategy group")
                    if s_obj.strategy_status not in ['BT', 'PT', 'LT']:
                        sc.query(ResearchStrategyPortfolio).filter(
                            ResearchStrategyPortfolio.id == portfolio_id).delete()
                        sc.commit()
                        sc.close()
                        self.json_response({
                            'code': 10009,
                            'error': u'未经回测的策略不可创建策略组合',
                        })
                        return False
                group_strategy_id = self.generate_strategy_group(sc, portfolio_id, portfolio.name, strategy_weight,
                                                                 float(portfolio.fund))
                update_strategy_performance.delay(group_strategy_id)
                update_strategy_sorting_result.apply_async(args=(group_strategy_id,), countdown=5)

            strategy_ids_len = sc.query(Strategy.id).filter(
                Strategy.is_delete == 0,
                Strategy.is_test == 0,
                Strategy.id.in_(strategy_weight.keys())
            ).count()
            if strategy_ids_len != len(payload['strategies']):
                raise ValueError("strategy_ids_len != len(payload['strategies'])")
            details = []
            for s_id, w in strategy_weight.items():
                sd = ResearchStrategyPortfolioDetail(
                    portfolio_id=portfolio.id,
                    strategy_id=s_id,
                    strategy_weight=w,
                    group_id=0,
                )
                details.append(sd)
            for sd in details:
                sc.add(sd)
            sc.commit()
            sc.close()
        except Exception as e:
            sentry.captureException()
            sc.rollback()
            sc.query(ResearchStrategyPortfolio).filter(ResearchStrategyPortfolio.id == portfolio_id).delete()
            if group_strategy_id > 0:
                sc.query(Strategy).filter(Strategy.id == group_strategy_id).delete()
            sc.commit()
            sc.close()
            self.application.logger.error(traceback.print_exc())
            self.json_response({
                'code': 1008,
                'error': '非法参数'
            })
            return False

        details = ResearchStrategyPortfolio.portfolio_details(self.current_user, portfolio_id=portfolio_id,
                                                              create_type=create_type)
        self.json_response({
            'code': 0,
            'data': details and details[0] or {}
        })
        return True

    def generate_strategy_group(self, sc, portfolio_id, portfolio_name, strategy_weight, portfolio_fund):
        node = 'group'
        name = portfolio_name
        strategy_upload_file_id = -1
        dependency = []
        detail = {}
        products = [[]]
        start = ''
        day_night_set = set()
        strategy_status = 'PT'
        paper_trading_date = ''
        strategies = sc.query(Strategy).filter(Strategy.id.in_(strategy_weight.keys()))
        for s in strategies:
            if s.strategy_status == 'BT':
                strategy_status = 'BT'
            if s.strategy_status in ['PT', 'LT']:
                paper_trading_date = max(paper_trading_date,
                                         (s.paper_trading_date or s.r_create_time).strftime('%Y-%m-%d'))
            start = max(start, s.start_date)
            day_night_set.add(s.day_night)
            if s.products:
                for product in s.products[0]:
                    if product not in products[0]:
                        products[0].append(product)
        end = '20500101'
        test = False
        status = consts.TASK_FINISHED
        post_data = {
            'node': node,
            'name': name,
            'dependency': dependency,
            'products': products,
            'start': start,
            'end': end,
            'test': test,
            'initial_cash': portfolio_fund,
        }
        for k, v in detail.items():
            post_data[k] = v
        post_data['desc'] = ''
        post_data['max_pos'] = 1000000
        if 2 in day_night_set:
            day_night = 2
        elif 0 in day_night_set and 1 in day_night_set:
            day_night = 2
        elif 0 in day_night_set and 1 not in day_night_set:
            day_night = 0
        elif 1 in day_night_set and 0 not in day_night_set:
            day_night = 1
        else:
            day_night = 0
        post_data['day_night'] = day_night

        id_no = Strategy.generate_id_no(
            self.current_user['id'], 'PO', time.strftime('%Y-%m-%d')
        )

        from service.back_test.proc_group import max_paper_trading_date
        max_date = max_paper_trading_date(portfolio_id, sc)
        sc = session()
        strategy = Strategy(
            r_create_user_id=self.current_user['id'],
            r_update_user_id=self.current_user['id'],
            username=self.current_user['username'],
            name=post_data['name'],
            status=status,
            description=post_data['desc'],
            node=node,
            start_date=post_data['start'],
            end_date=post_data['end'],
            day_night=post_data['day_night'],
            products=post_data['products'],
            max_pos=post_data['max_pos'],
            dependency=post_data['dependency'],
            detail=post_data,
            st_uuid=uuid.uuid1().hex,
            strategy_type='PO',
            strategy_feature='',
            strategy_underlying='',
            strategy_para_type='',
            strategy_status=strategy_status,
            id_no=id_no,
            code=id_no[-3:],
            is_test=1 if post_data['test'] else 0,
            strategy_upload_file_id=strategy_upload_file_id,
            paper_trading_date=max_date,
            hedge='',
            hedge_type='',
            group_id=portfolio_id,
            group_detail=strategy_weight,
            task_progress=1
        )
        sc.add(strategy)
        if strategy_status == 'PT' and paper_trading_date:
            strategy.paper_trading_date = paper_trading_date
        sc.commit()
        strategy_owner = StrategyOwners(
            strategy_id=strategy.id,
            owner_id=self.current_user['id'],
            r_create_user_id=self.current_user['id'],
        )
        sc.add(strategy_owner)
        sc.commit()
        return strategy.id


class ResearchPortfoliosDetailHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        portfolio_id = int(kwargs['id'])
        sc = session()
        portfolio = sc.query(ResearchStrategyPortfolio).filter(
            ResearchStrategyPortfolio.r_create_user_id == self.current_user['id'],
            ResearchStrategyPortfolio.id == portfolio_id
        ).first()
        if not portfolio:
            self.json_response({
                'code': 1005,
                'error': '对象不存在',
            })
            return False
        sc.close()
        details = ResearchStrategyPortfolio.portfolio_details(self.current_user, portfolio_id=portfolio_id)
        self.json_response({
            'code': 0,
            'data': details and details[0] or {}
        })
        return True

    @gen.coroutine
    def put(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        payload = self.get_payload()
        portfolio_id = int(kwargs['id'])
        create_type = int(payload.get('create_type', '0'))
        semi_lives = int(payload.get('semi_lives', 0))
        sc = session()
        if create_type == 1:
            __strategy = sc.query(Strategy).filter_by(group_id=portfolio_id).first()
            if not __strategy:
                self.json_response({
                    'code': 1013,
                    'error': 'strategy not found',
                })
                sc.close()
                return False
            if (datetime.datetime.now() - __strategy.r_create_time).total_seconds() >= 86400 or \
                    __strategy.is_deployed:
                self.json_response({
                    'code': 1011,
                    'error': u'已上传且未实盘的策略, 仅支持在一天内更新'
                })
                sc.close()
                return False

            # update strate group performance
            update_strategy_sorting_result.apply_async(args=(__strategy.id,), countdown=5)

        portfolio = sc.query(ResearchStrategyPortfolio).filter(
            ResearchStrategyPortfolio.name == payload['name'],
            ResearchStrategyPortfolio.id != portfolio_id,
        ).first()
        if portfolio:
            self.json_response({
                'code': 1020,
                'error': '策略组合名称已存在'
            })
            sc.close()
            return False
        portfolio = sc.query(ResearchStrategyPortfolio).filter(
            ResearchStrategyPortfolio.r_create_user_id == self.current_user['id'],
            ResearchStrategyPortfolio.id == portfolio_id
        ).first()
        if not portfolio:
            self.json_response({
                'code': 1005,
                'error': '对象不存在',
            })
            sc.close()
            return False
        if not portfolio.can_update():
            self.json_response({
                'code': 1004,
                'error': '无权限, 策略组合已被其他投资者使用',
            })
            sc.close()
            return False
        portfolio.name = payload['name']
        portfolio.fund = float(payload['gross'])
        portfolio.description = payload.get('desc', '')
        portfolio.weight_type = int(payload['weight'])
        if semi_lives:
            BackTestConfig.add_config(self.current_user['id'], portfolio.id, consts.INVEST_GROUP)

        old_detail_ids = [_d.id for _d in sc.query(ResearchStrategyPortfolioDetail).filter(
            ResearchStrategyPortfolioDetail.portfolio_id == portfolio.id)]
        try:
            strategy_weight = {int(s['id']): float(s['weight']) for s in payload['strategies']}
            if create_type == 1:
                group_strategy_id = self.update_strategy_group(sc, portfolio_id, portfolio.name, strategy_weight,
                                                               float(portfolio.fund))
            else:
                group_strategy_id = 0
            strategy_ids_len = sc.query(Strategy.id).filter(
                Strategy.is_delete == 0,
                Strategy.is_test == 0,
                Strategy.id.in_(strategy_weight.keys())
            ).count()
            if strategy_ids_len != len(payload['strategies']):
                raise ValueError("strategy_ids_len != len(payload['strategies'])")
            details = []
            for s_id, w in strategy_weight.items():
                sd = ResearchStrategyPortfolioDetail(
                    portfolio_id=portfolio.id,
                    strategy_id=s_id,
                    strategy_weight=w,
                    group_id=0,
                )
                details.append(sd)
            for sd in details:
                sc.add(sd)
            if old_detail_ids:
                sc.query(ResearchStrategyPortfolioDetail).filter(
                    ResearchStrategyPortfolioDetail.id.in_(old_detail_ids)
                ).delete(synchronize_session=False)
            sc.commit()
            sc.close()
        except Exception as e:
            sentry.captureException()
            sc.rollback()
            sc.close()
            self.json_response({
                'code': 1008,
                'error': '非法参数'
            })
            self.application.logger.error(traceback.print_exc())
            return False
        details = ResearchStrategyPortfolio.portfolio_details(self.current_user, portfolio_id=portfolio_id)
        self.json_response({
            'code': 0,
            'data': details and details[0] or {}
        })
        return True

    def update_strategy_group(self, sc, portfolio_id, portfolio_name, strategy_weight, portfolio_fund):
        strategy = sc.query(Strategy).filter_by(group_id=portfolio_id).first()
        if not strategy:
            raise ValueError("strategy group not found in strategy table.")
        products = [[]]
        start = ''
        day_night_set = set()
        strategy_status = 'PT'
        paper_trading_date = ''
        strategies = sc.query(Strategy).filter(Strategy.id.in_(strategy_weight.keys()))
        for s in strategies:
            if s.strategy_status == 'BT':
                strategy_status = 'BT'
            if s.strategy_status in ['PT', 'LT']:
                paper_trading_date = max(paper_trading_date,
                                         (s.paper_trading_date or s.r_create_time).strftime('%Y-%m-%d'))
            start = max(start, s.start_date)
            day_night_set.add(s.day_night)
            for product in s.products[0]:
                if product not in products[0]:
                    products[0].append(product)
        if 2 in day_night_set:
            day_night = 2
        elif 0 in day_night_set and 1 in day_night_set:
            day_night = 2
        elif 0 in day_night_set and 1 not in day_night_set:
            day_night = 0
        elif 1 in day_night_set and 0 not in day_night_set:
            day_night = 1
        else:
            day_night = 0
        post_data = copy.deepcopy(strategy.detail)
        strategy.name = portfolio_name
        post_data['name'] = portfolio_name
        post_data['initial_cash'] = portfolio_fund
        post_data['products'] = products
        strategy.detail = post_data
        strategy.start_date = start
        strategy.day_night = day_night
        strategy.products = products
        strategy.group_id = portfolio_id
        strategy.group_detail = strategy_weight
        strategy.strategy_status = strategy_status
        if strategy_status == 'PT' and paper_trading_date:
            strategy.paper_trading_date = paper_trading_date
        sc.commit()
        return strategy.id

    @gen.coroutine
    def delete(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        portfolio_id = int(kwargs['id'])
        sc = session()
        portfolio = sc.query(ResearchStrategyPortfolio).filter(
            ResearchStrategyPortfolio.r_create_user_id == self.current_user['id'],
            ResearchStrategyPortfolio.id == portfolio_id
        ).first()
        if not portfolio:
            self.json_response({
                'code': 1005,
                'error': '对象不存在',
            })
            return False
        if not portfolio.can_delete():
            self.json_response({
                'code': 1004,
                'error': '无权限, 策略组合已被其他投资者使用',
            })
            return False
        try:
            if portfolio.create_type == 1:
                s_obj = sc.query(Strategy).filter(Strategy.group_id == portfolio_id).first()
                if s_obj.is_deployed:
                    self.json_response({
                        'code': 1003,
                        'error': '策略组合已经被实盘部署',
                    })
                    return False
                s_obj.is_delete = 1
            sc.query(ResearchStrategyPortfolio).filter(ResearchStrategyPortfolio.id == portfolio_id).delete()
            sc.query(ResearchStrategyPortfolioDetail).filter(
                ResearchStrategyPortfolioDetail.portfolio_id == portfolio_id).delete()
            sc.commit()
            self.json_response({
                'code': 0
            })


        except Exception as e:
            sentry.captureException()
            sc.rollback()
            self.json_response({
                'code': 1004,
                'error': '无权限, 删除组合失败'
            })
        return True


class StrategyHedgeHandler(JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def put(self, *args, **kwargs):
        null_pnl_detail = {
            'pnl': {},
            'hedge_net': {},
            'origin_net': {},
            'sharpe': 0,
            'profitrate': 0,
            'annual_return': 0,
            'max_drawdown_pnl': 0,
            'max_drawdown_start': 0,
            'max_drawdown_end': 0,
            'paper_trading_sharpe': 0,
            'paper_trading_profitrate': 0,
            'paper_trading_annual_return': 0,
            'paper_trading_max_drawdown_pnl': 0,
            'paper_trading_max_drawdown_start': 0,
            'paper_trading_max_drawdown_end': 0,
        }
        sc = session()
        try:
            from analysis.performance_analysis import PerformanceAnalyzer
            data = self.get_payload()
            origin_pnl = data['origin_pnl']
            s_id = data.get('s_id', 0)
            data_type = data.get('type', '')

            vs_id = 0
            if data_type in ('LT', 'VS_BT'):
                vs_ids = data.get('vs_ids', [])
                if vs_ids:
                    vs_id = vs_ids[0]

            s = sc.query(Strategy).filter(
                Strategy.id == s_id
            ).first()

            # delete first day
            first_index = list(sorted(origin_pnl.keys()))[0]
            del origin_pnl[first_index]

            pnl_input = {
                'live_date': [],
                'live_pnl': [],
                'live_asset': [],
                'live_position_value': [],
                'live_cash_io': [],
                'live_end_position_value': 0,
                'back_test_date': [],
                'back_test_asset': [],
                'back_test_pnl': [],
                'back_test_position_value': [],
                'back_test_cash_io': [],
                'back_test_end_position_value': 0,
                'back_test_start_time': [],
                'back_test_end_time': [],
                'paper_trading_date': data.get('paper_trading_date', ''),
                'hedge': data['hedge'],
                'hedge_type': data.get('hedge_type', 'position') or 'position',
            }

            # Benchmark=融券对冲清单，需传入底仓策略id
            if pnl_input['hedge'] == HedgeBenchmark.MarginHedgeList.value:
                if s.has_margin_hedge():
                    pnl_input['margin_hedge_s_id'] = s.detail.get('alpha_s_id')
                else:
                    # 兼容处理
                    pnl_input['hedge'] = HedgeBenchmark.ZZ500.value

            cash_io_index = -1
            for key, item in sorted(origin_pnl.items(), key=lambda d: d[0]):
                if cash_io_index < 0:
                    if len(item) == 8:
                        cash_io_index = 7
                    elif len(item) == 10:
                        cash_io_index = 9
                pnl_input['back_test_date'].append(key)
                pnl_input['back_test_pnl'].append(item[1])
                pnl_input['back_test_asset'].append(item[2])
                pnl_input['back_test_position_value'].append(item[5])
                pnl_input['back_test_end_position_value'] = item[6]
                pnl_input['back_test_cash_io'].append(item[cash_io_index] if cash_io_index > 0 else 0)
                pnl_input['back_test_start_time'].append(0)
                pnl_input['back_test_end_time'].append(0)

            if len(pnl_input['back_test_position_value']) >= 2:
                pnl_input['back_test_position_value'][0] = pnl_input['back_test_position_value'][1]
            elif len(pnl_input['back_test_position_value']) == 1:
                pnl_input['back_test_position_value'][0] = pnl_input['back_test_end_position_value']

            if pnl_input['hedge_type'].startswith('live_'):
                vs_ids_str = [s for s in pnl_input['hedge_type'][5:].split('_')]
                hedge_pnl = InvestmentPerformanceService.get_hedge_vs_pnl(vs_ids_str)
                if hedge_pnl:
                    if hedge_pnl['hedge_pnl']:
                        for i, d in enumerate(pnl_input['back_test_date']):
                            pnl_input['back_test_pnl'][i] += hedge_pnl['hedge_pnl'].get(d, 0)

                pnl_input['hedge_type'] = ''
                pnl_input['hedge'] = ''

            fingerprint = ''
            if len(pnl_input['back_test_date']):
                finger = [pnl_input['hedge_type'], pnl_input['hedge'], pnl_input['paper_trading_date']]
                finger.extend(pnl_input['back_test_date'])
                finger.extend([str(int(i)) for i in pnl_input['back_test_pnl']])
                finger.extend([str(int(i)) for i in pnl_input['back_test_asset']])
                if len(finger) > 6:
                    finger = '|'.join(finger)
                    md = hashlib.md5()
                    md.update(str(finger).encode('utf8'))
                    fingerprint = md.hexdigest()

            if fingerprint:
                try:
                    file_path = get_str_cache('platform_fingerprint_%s_%s' % (s_id, fingerprint))
                    if file_path:
                        f = open(file_path, 'r')
                        data = simplejson.load(f)
                        f.close()
                        sc.close()
                        self.json_response({
                            'code': 0,
                            'data': data
                        })
                        return
                except Exception as e:
                    pass

            if data_type in ('LT', 'VS_BT', 'BT') and s_id:
                default_vwap_time = []
                cash_io_vwap_time = {}
                first_vwap_time = []
                try:
                    s_vwap_time = sc.query(StrategyVwapExecutimeTime).filter(
                        StrategyVwapExecutimeTime.strategy_id == s_id
                    ).order_by(
                        StrategyVwapExecutimeTime.trading_date.desc()
                    ).first()
                    if s_vwap_time:
                        default_vwap_time = [int(s_vwap_time.start_time) * 1000, int(s_vwap_time.end_time) * 1000]
                    vs_cash_io = sc.query(VStrategyAccountDetail).filter(
                        VStrategyAccountDetail.vstrategy_id == vs_id
                    )

                    for vs_cash in vs_cash_io:

                        if not vs_cash.trading_date:

                            if vs_cash.start_time:
                                first_vwap_time = [vs_cash.start_time * 1000, vs_cash.end_time * 1000]
                            else:
                                first_vwap_time = default_vwap_time[:]

                            continue

                        if vs_cash.start_time:
                            cash_io_vwap_time[vs_cash.trading_date.strftime('%Y%m%d')] = [
                                vs_cash.start_time * 1000,
                                vs_cash.end_time * 1000
                            ]

                        elif default_vwap_time:
                            cash_io_vwap_time[vs_cash.trading_date.strftime('%Y%m%d')] = default_vwap_time[:]

                except Exception as e:
                    sentry.captureException()

                if not default_vwap_time:
                    s_type = s.strategy_type
                    s_name = (s.name or '').lower()
                    if 'dt' in s_name:
                        default_vwap_time = [
                            93000000, 145500000
                        ]
                    elif 'im' in s_name:
                        default_vwap_time = [
                            93000000, 145500000
                        ]
                    elif 'da' in s_name:
                        default_vwap_time = [
                            93000000, 145500000
                        ]
                    elif s_type in ('33',):
                        default_vwap_time = [
                            93000000, 145500000
                        ]
                    elif 'hd' in s_name:
                        default_vwap_time = [
                            93000000, 113000000
                        ]

                if first_vwap_time:
                    pnl_input['back_test_start_time'][0] = first_vwap_time[0]
                    pnl_input['back_test_end_time'][0] = first_vwap_time[1]
                elif default_vwap_time:
                    pnl_input['back_test_start_time'][0] = default_vwap_time[0]
                    pnl_input['back_test_end_time'][0] = default_vwap_time[1]

                for d, d_vwap_time in cash_io_vwap_time.items():
                    if d in pnl_input['back_test_date']:
                        d_index = pnl_input['back_test_date'].index(d)
                        pnl_input['back_test_start_time'][d_index] = d_vwap_time[0]
                        pnl_input['back_test_end_time'][d_index] = d_vwap_time[1]

            if s.is_single_interest:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_stock_strategy_hedge_quest(pnl_input)
            else:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategy_hedge_quest(pnl_input)

            if net_pnl[0]:
                data = null_pnl_detail
            else:
                detail = net_pnl[1]
                pnl_detail = {
                    'pnl': {key.decode("utf-8"): value for key, value in detail['back_test_pnl'].items()},
                    'hedge_net': {key.decode("utf-8"): value for key, value in detail['back_test_hedge_net'].items()},
                    'origin_net': {key.decode("utf-8"): value for key, value in detail['back_test_origin_net'].items()},
                    'sharpe': detail['back_test_sharpe'],
                    'profitrate': detail['back_test_profitrate'],
                    'annual_return': detail['back_test_annual_return'],
                    'max_drawdown_pnl': detail['back_test_max_drawdown_pnl'],
                    'max_drawdown_start': detail['back_test_max_drawdown_start'],
                    'max_drawdown_end': detail['back_test_max_drawdown_end'],
                    'paper_trading_sharpe': detail['paper_trading_sharpe'],
                    'paper_trading_profitrate': detail['paper_trading_profitrate'],
                    'paper_trading_annual_return': detail['paper_trading_annual_return'],
                    'paper_trading_max_drawdown_pnl': detail['paper_trading_max_drawdown_pnl'],
                    'paper_trading_max_drawdown_start': detail['paper_trading_max_drawdown_start'],
                    'paper_trading_max_drawdown_end': detail['paper_trading_max_drawdown_end']
                }
                data = pnl_detail

            if fingerprint and data['pnl']:
                file_path = os.path.join(config.media, 'back_test_performace', '%s.json' % fingerprint)
                f = open(file_path, 'w')
                simplejson.dump(data, f, cls=MyEncoder, ignore_nan=True)
                f.close()
                set_str_cache('platform_fingerprint_%s_%s' % (s_id, fingerprint), file_path, 8 * 3600)

            sc.close()
            self.json_response({
                'code': 0,
                'data': data
            })
        except Exception as e:
            sentry.captureException()
            sc.close()
            self.json_response({
                'code': 0,
                'data': null_pnl_detail,
            })


class DeployErrorNotifyHandler(BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.json_response({
            'code': 0,
        })
        return


class VstrategiesCashHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        vs_id = self.get_argument('vstrategy_id', '')
        if vs_id:
            vs_ids = [int(vs_id)]
        else:
            vs_ids = None
        me = self.get_user_detail()
        group_ids = [int(g['id']) for g in me['groups']]
        # operation group_id = 3
        if 3 not in group_ids:
            self.json_response({
                'code': 1124,
                'error': 'only operation group has permission'
            })
            return
        self.current_user['is_superuser'] = True
        self.json_response({
            'code': 0,
            'data': VStrategyAccountDetail.get_vstrategies_cash_io(self.current_user, vs_ids)
        })
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        try:
            me = self.get_user_detail()
            group_ids = [int(g['id']) for g in me['groups']]
            # operation group_id = 3
            if 3 not in group_ids:
                self.json_response({
                    'code': 1124,
                    'error': 'only operation group has permission'
                })
                return
            self.current_user['is_superuser'] = True
            data = self.get_payload()
            vs_id = int(data['vstrategy_id'])
            account = data['account']
            exchange = data['exchange']
            fund = float(data['fund'])
            actual_fund = float(data['actual_fund'])
            origin_cashs = VStrategyAccountDetail.get_vstrategies_cash_io(self.current_user, [vs_id])
            portfolio_id = origin_cashs['values'][0][origin_cashs['columns'].index('strategy_portfolio_id')]
            trading_date = parse(data['trading_date'])
            accounts, exchanges = [], []
            account_index = origin_cashs['columns'].index('account')
            exchange_index = origin_cashs['columns'].index('exchange')
            last_trading_date = StrategyPerfInput.get_latest_settle_day()['trading_date']
            if trading_date.strftime('%Y%m%d') <= parse(last_trading_date).strftime('%Y%m%d'):
                self.json_response({
                    'code': 1123,
                    'error': 'trading_date must after %s' % last_trading_date
                })
                return
            for cash in origin_cashs['values']:
                accounts.append(cash[account_index])
                exchanges.append(cash[exchange_index])
            if account not in accounts:
                self.json_response({
                    'code': 1121,
                    'error': 'account error'
                })
                return
            if exchange not in exchanges:
                self.json_response({
                    'code': 1122,
                    'error': 'exchange error'
                })
                return
            vs_account_cash = VStrategyAccountDetail(
                vstrategy_id=vs_id,
                portfolio_id=portfolio_id,
                account=account,
                amount=fund,
                actual_amount=actual_fund,
                exchange=exchange,
                trading_date=trading_date,
                r_create_user_id=self.current_user['id'],
                r_update_user_id=self.current_user['id'],
            )
            sc = session()
            sc.add(vs_account_cash)
            sc.commit()
            sc.close()
            self.json_response({
                'code': 0
            })
        except Exception as e:
            sentry.captureException()
            self.json_response({
                'code': 1120,
                'error': 'create cash error'
            })
            return False
        return True


class VstrategiesCashDetailHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def delete(self, *args, **kwargs):
        cash_id = int(kwargs['id'])
        self.get_current_user()
        if not self.current_user:
            return False
        me = self.get_user_detail()
        group_ids = [int(g['id']) for g in me['groups']]
        if 3 not in group_ids:
            self.json_response({
                'code': 1124,
                'error': 'only operation group has permission'
            })
            return
        last_trading_date = StrategyPerfInput.get_latest_settle_day()['trading_date']
        last_trading_date = parse(last_trading_date).strftime('%Y%m%d')
        sc = session()
        cash = sc.query(VStrategyAccountDetail).filter(VStrategyAccountDetail.id == cash_id).first()
        if not (cash.trading_date and cash.trading_date.strftime('%Y%m%d') > last_trading_date):
            self.json_response({
                'code': 1124,
                'error': 'can not delete cash trading_date must after %s' % last_trading_date
            })
            return
        sc.query(VStrategyAccountDetail).filter(VStrategyAccountDetail.id == cash_id).delete()
        sc.commit()
        sc.close()
        self.json_response({
            'code': 0
        })
        return True


class TrackFilterHandler(CurrentUserMixin, BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        page = self.get_argument('page', 'provider_strategy').lower()
        from cron.strategy_upload_task import update_track_detail_cache_new
        update_track_detail_cache_new.delay()
        self.current_user['group_ids'] = self.get_user_group()
        history = self.get_argument('history', 'false').lower()
        history = True if history == 'true' else False

        is_stock_group = self.is_stock_group()
        is_stock_page = self.is_stock_page()

        is_future_page = self.is_future_page()
        is_future_group = self.is_future_group()

        self.json_response({
            'code': 0,
            'data': track_filter_data(
                self.current_user, page, history=history,
                stock_data=is_stock_page and is_stock_group,
                future_data=is_future_page and is_future_group,
                is_stock_group=is_stock_group,
                is_stock_page=is_stock_page,
                is_future_group=is_future_group,
                is_future_page=is_future_page,
            )
        })
        return True


class TrackDetailHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        strategy_id = self.get_argument('strategy_id', '')
        portfolio_name = self.get_argument('portfolio_name', '')
        try:
            from service.statistic.track import StrategyTrackService
            ss = StrategyTrackService(id_no=strategy_id, portfolio_name=portfolio_name)
            yield ss.async_get_live_quote()
            detail = ss.strategy_track()
            detail['position_data'] = ss.get_live_position()
            self.json_response({
                'code': 0,
                'data': detail
            })
            return True
        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 1126,
                'error': 'get track data error'
            })
            return False


class TrackHistoryDetailHandler(CurrentUserMixin_V2, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        strategy_id = self.get_argument('strategy_id', '')
        trading_date = self.get_argument('trading_date')
        try:
            from service.statistic.track import HistoryStrategyTrackService
            ss = HistoryStrategyTrackService(id_no=strategy_id, trading_date=trading_date)
            detail = ss.get_history_track_data()
            self.json_response({
                'code': 0,
                'data': detail
            })
            return True
        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 1126,
                'error': 'get track data error'
            })
            return False


class TrackPositionDetailHandler(CurrentUserMixin_V2, BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        # Todo To remove

        self.json_response({
            'code': 0,
            'data': {'position_data': {}}
        })
        return True


class TrackStrategyLiveTimeDetailHandler(CurrentUserMixin_V2, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        strategy_list_str = self.get_argument('strategy_list', '')
        if not strategy_list_str:
            self.json_response({
                'code': 0,
                'data': [],
            })
            return False
        strategy_list = strategy_list_str.split(',')
        today = datetime.datetime.now().strftime('%Y%m%d')
        live_time = today
        try:
            sc = session()
            strategies = sc.query(Strategy.live_time.label('live_time')).filter(
                Strategy.id_no.in_(strategy_list),
            )
            live_time = min([s.live_time.strftime('%Y%m%d') for s in strategies if s.live_time])
        except Exception as e:
            sentry.captureException()
            sc.close()
            self.json_response({
                'code': 1126,
                'error': 'get track data error'
            })
            return False
        sc.close()
        self.json_response({
            'code': 0,
            'data': live_time,
        })
        return True


class TrackHistoryPositionDetailHandler(CurrentUserMixin_V2, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        strategy_list_str = self.get_argument('strategy_list', '')
        if not strategy_list_str:
            self.json_response({
                'code': 0,
                'data': [],
            })
            return False
        strategy_list = strategy_list_str.split(',')
        today = datetime.datetime.now().strftime('%Y%m%d')
        try:
            kw = {
                'start': self.get_argument('start', today),
                'end': self.get_argument('end', today),
                'page': int(self.get_argument('page', 0)),
                'size': int(self.get_argument('size', 10))
            }
            ss = HistoryPositionTrackService(strategy_list, **kw)
            data = ss.get_history_position()
            total = data['total']
            position_data = data['data']
        except Exception as e:
            sentry.captureException()
            self.json_response({
                'code': 1126,
                'error': 'get track data error'
            })
            return False

        self.json_response({
            'code': 0,
            'data': position_data,
            'total': total,
        })
        return True


class PortfolioAnalysisViewHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @staticmethod
    def gen_cache_key(list_ids, cfg_id):
        strat_list = [str(id) for id in list_ids]
        return "portfolio_analysis_%s_%d" % ("_".join(strat_list), cfg_id)

    @staticmethod
    def calc_analysis_data(req_data, config_id=0):
        strat_ids = req_data['strategies']
        cache_key = PortfolioAnalysisViewHandler.gen_cache_key(strat_ids, config_id)
        result = get_cache(cache_key)
        if result:
            return result

        null_pnl_detail = {
            'strategy_status': 'PT',
            'pnl': {},
            'sharpe': 0,
            'profitrate': 0,
            'annual_return': 0,
            'max_drawdown_pnl': 0,
            'max_drawdown_start': 0,
            'max_drawdown_end': 0,
            'back_test_pnl': {},
            'back_test_sharpe': 0,
            'back_test_profitrate': 0,
            'back_test_annual_return': 0,
            'back_test_max_drawdown_pnl': 0,
            'back_test_max_drawdown_start': 0,
            'back_test_max_drawdown_end': 0,
            'papertrading_date': 0,
            'paper_trading_sharpe': 0,
            'paper_trading_profitrate': 0,
            'paper_trading_annual_return': 0,
            'paper_trading_max_drawdown_pnl': 0,
            'paper_trading_max_drawdown_start': 0,
            'paper_trading_max_drawdown_end': 0
        }
        try:
            from analysis.performance_analysis import PerformanceAnalyzer
            sc = session()
            weights, strats, vs_ids = {}, {}, {}

            # modify by lishaofeng on 2017.12.1
            for i, id in enumerate(strat_ids):
                s = sc.query(Strategy).filter(Strategy.id == id).first()
                if s.group_id > 0:
                    for s_id, w in s.group_detail.items():
                        strats[s_id] = sc.query(Strategy).filter(Strategy.id == s_id).first()
                        weights[s_id] = req_data['weights'][i] * w
                else:
                    strats[id] = s
                    weights[id] = req_data['weights'][i]
            for i, id in enumerate(strats):
                vstrategies = sc.query(VStrategies).filter(
                    VStrategies.strategy_id == id,
                )
                for vs in vstrategies:
                    if id not in vs_ids:
                        vs_ids[id] = vs.id
                    if vs.status == consts.STRATEGY_LIVE:
                        vs_ids[id] = vs.id
                        break

            back_test_pnl, live_pnl = {}, {}
            paper_trading_date = max(
                [(s.paper_trading_date or s.r_create_time).strftime('%Y-%m-%d') for s in strats.values()])
            sc.close()
            for id, s in strats.items():
                _backtest = Strategy.get_output_pnl(s.output(config_id))
                _live = s.live_pnl_v3()['pnl']
                back_test_pnl[id] = sorted(_backtest.items(), key=lambda r: r[0])
                live_pnl[id] = sorted(_live.items(), key=lambda r: r[0])
                # remove first day results due to invalid open cash
                if _backtest:
                    back_test_pnl[id].pop(0)
                if _live:
                    live_pnl[id].pop(0)
            aggregate_backtest_pnl, aggregate_live_pnl = {}, {}
            back_test_start_date = max([s.start_date for s in strats.values()] + ['20100101'])
            live_start_date = '20100101'
            # calculate adjusted weight
            _strategy_initial_cash = {id: strats[id].detail.get('initial_cash', 1000000) for id in weights.keys()}
            for id, pnl in back_test_pnl.items():
                _strategy_initial_cash.update({id: v[1][2] for v in pnl if v[0] == back_test_start_date})
            adj_backtest_weights = {id: weight * req_data['gross'] / _strategy_initial_cash[id] for id, weight in
                                    weights.items()}

            for id, pnl in back_test_pnl.items():
                if pnl:
                    del pnl[0]
                    _temp = {k: v[1] * adj_backtest_weights[id] + aggregate_backtest_pnl.get(k, 0) for k, v in pnl if
                             k >= back_test_start_date}
                    aggregate_backtest_pnl.update(_temp)
            day_cum_cash, initial_cash = {}, {}
            for id, vs_id in vs_ids.items():
                cash_io_record = VStrategies.vstratgies_account_invest_funds(
                    VStrategies.vstrategies_invest_funds_detail([vs_id]), [vs_id], 'all'
                )
                if not cash_io_record:
                    raise ValueError("no cash io record found")
                day_cash = {d: 0 for d, pnl in live_pnl[id]}
                initial_cash[id] = sorted(cash_io_record.items(), key=lambda d: d[0])[0][1]
                for d, _cash in cash_io_record.items():
                    day = parse(d).strftime('%Y%m%d')
                    day_cash[day] = _cash
                day_cum_cash[id] = pd.Series(day_cash).shift(1).cumsum().dropna().to_dict()
            adj_day_cum_cash = {}
            for id, cash in day_cum_cash.items():
                for d, v in cash.items():
                    adj_day_cum_cash[d] = v * weights[id] * req_data['gross'] / initial_cash[id] + adj_day_cum_cash.get(
                        d, 0)
            for id, pnl in live_pnl.items():
                if pnl:
                    del pnl[0]
                    live_start_date = max(pnl[0][0], live_start_date)
                    if not aggregate_live_pnl:
                        aggregate_live_pnl = {k: v[1] * weights[id] * req_data['gross'] / initial_cash[id] for k, v in
                                              pnl}
                    else:
                        aggregate_live_pnl = {k: v for k, v in aggregate_live_pnl.items() if k >= live_start_date}
                        for k, v in pnl:
                            if k >= live_start_date:
                                aggregate_live_pnl[k] = v[1] * weights[id] * req_data['gross'] / initial_cash[
                                    id] + aggregate_live_pnl.get(k, 0)
            pnl_input = {
                'live_date': [],
                'live_pnl': [],
                'live_asset': [],
                'live_position_value': [],
                'live_cash_io': [],
                'live_end_position_value': 0.0,
                'back_test_date': [],
                'back_test_asset': [],
                'back_test_pnl': [],
                'back_test_position_value': [],
                'back_test_cash_io': [],
                'back_test_end_position_value': 0.0,
                'paper_trading_date': paper_trading_date
            }
            backtest_open_asset, backtest_position = req_data['gross'], 0.0
            for day, pnl in sorted(aggregate_backtest_pnl.items(), key=lambda d: d[0]):
                pnl_input['back_test_date'].append(day)
                pnl_input['back_test_pnl'].append(pnl)
                pnl_input['back_test_asset'].append(backtest_open_asset)
                pnl_input['back_test_position_value'].append(backtest_position)
                pnl_input['back_test_cash_io'].append(0)
                backtest_open_asset += pnl
            pnl_input['back_test_end_position_value'] = backtest_position
            prev_accumulate_pnl, live_position = 0.0, 0.0
            for day, pnl in sorted(aggregate_live_pnl.items(), key=lambda d: d[0]):
                pnl_input['live_date'].append(day)
                pnl_input['live_pnl'].append(pnl)
                pnl_input['live_asset'].append(prev_accumulate_pnl + adj_day_cum_cash.get(day, 0))
                pnl_input['live_position_value'].append(live_position)
                pnl_input['live_cash_io'].append(0)
                prev_accumulate_pnl += pnl
            pnl_input['live_end_position_value'] = live_position
            net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategies_quest(pnl_input)
            if net_pnl[0]:
                null_pnl_detail['papertrading_date'] = paper_trading_date
                result = null_pnl_detail
            else:
                detail = net_pnl[1]
                pnl_detail = detail
                if pnl_detail['pnl']:
                    pnl_detail['strategy_status'] = 'LT'
                else:
                    pnl_detail['strategy_status'] = 'PT'
                pnl_detail['papertrading_date'] = paper_trading_date
                pnl_detail['pnl'] = {key.decode("utf-8"): value for key, value in pnl_detail['pnl'].items()}
                pnl_detail['back_test_pnl'] = {key.decode("utf-8"): value for key, value in
                                               pnl_detail['back_test_pnl'].items()}
                result = pnl_detail
        except Exception as e:
            sentry.captureException()
            result = null_pnl_detail
        set_cache(cache_key, result, 2 * 3600)
        return result

    @gen.coroutine
    def post(self, *args, **kwargs):
        req_data = self.get_payload()
        self.json_response({
            'code': 0,
            'data': PortfolioAnalysisViewHandler.calc_analysis_data(req_data)
        })

    @gen.coroutine
    def get(self, *args, **kwargs):
        result = {}
        user_id = self.check_login()
        all_info = BackTestConfig.get_strategies(user_id, consts.INVEST_GROUP)

        sc = session()
        for item in all_info:
            portfolio_id = item['strategy_id']
            request = {"strategies": [], "weights": [], "gross": 0,
                       "analysis_type": "performance", "analysis_request": "All"}
            pf_obj = sc.query(ResearchStrategyPortfolio).get(portfolio_id)
            pf_detail = sc.query(ResearchStrategyPortfolioDetail).filter(
                ResearchStrategyPortfolioDetail.portfolio_id == portfolio_id).all()
            if pf_obj is None:
                request['gross'] = 1000000
            else:
                request['gross'] = float(pf_obj.fund)
            for detail in pf_detail:
                request['strategies'].append(detail.strategy_id)
                request['weights'].append(float(detail.strategy_weight))
            result[portfolio_id] = PortfolioAnalysisViewHandler.calc_analysis_data(request)

        self.json_response({'code': 0, 'data': result})
        sc.close()
        return True


class CheckStatus:

    def __init__(self, pf_id=None, vs_id=None):
        self.is_single = True if vs_id else False
        self.start_list = ['07:30:00', '20:00:00']
        self.now_time = datetime.datetime.now()
        now_date = self.now_time.strftime('%Y-%m-%d')
        self.get_start_time = lambda st: datetime.datetime.strptime('%s %s' % (now_date, st), "%Y-%m-%d %H:%M:%S")
        self.close, self.cancel, self.update_time = self.get_close_status(pf_id, vs_id)

    def get_close_status(self, pf_id, vs_id):
        close, cancel, update_time = False, False, None
        sc = session()
        if vs_id:
            vs_objs = sc.query(VStrategies).filter(VStrategies.id == vs_id)
        else:
            vs_objs = sc.query(VStrategies).filter(VStrategies.portfolio_id == pf_id)
        for obj in vs_objs:
            if obj.closing_out == consts.STRATEGY_CLOSING_OUT:
                update_time = obj.set_close_time
                cancel = True
            if obj.closing_out == 0:
                close = True
        sc.close()
        return close, cancel, update_time

    def allow_close(self):
        if not self.close:
            return False
        for st in self.start_list:
            start = self.get_start_time(st)
            end = start + datetime.timedelta(hours=2)
            if start < self.now_time < end:
                return False
        return True

    def allow_cancel(self):
        if not self.cancel:
            return False
        if self.update_time is None:
            return False
        for st in self.start_list:
            start = self.get_start_time(st)
            if (self.update_time < start < self.now_time) or \
                    (self.now_time - self.update_time > datetime.timedelta(hours=12)):
                return False
        return True


class AllLivePortfolios(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @staticmethod
    def query_vs_ids(group_id):
        result = []
        sc = session()
        vs_objs = sc.query(VStrategies).filter(VStrategies.group_id == group_id,
                                               VStrategies.status == consts.STRATEGY_LIVE)
        for obj in vs_objs:
            result.append(obj.id)
        sc.close()
        return result

    @staticmethod
    def query_account_info(pf_id, vs_ids, exchange):
        result = []
        if not vs_ids:
            return result
        sc = session()
        str_ids = [str(id) for id in vs_ids]
        if exchange:
            stmt = "select account, exchange, sum(amount), sum(actual_amount) from vstrategy_account_detail " \
                   "where portfolio_id=%d and vstrategy_id in (%s) group by account, exchange" % (
                       pf_id, ",".join(str_ids))
        else:
            stmt = "select account, sum(amount), sum(actual_amount) from vstrategy_account_detail " \
                   "where portfolio_id=%d and vstrategy_id in (%s) group by account" % (pf_id, ",".join(str_ids))
        rows = sc.execute(stmt)
        for row in rows:
            if exchange:
                result.append({"account": row[0], "exchange": row[1],
                               "amount": row[2], "actual_amount": row[3]})
            else:
                result.append({"account": row[0], "exchange": '',
                               "amount": row[1], "actual_amount": row[2]})
        sc.close()
        return result

    @staticmethod
    def strategy_group_info(pf_id, group_id, exchange):
        result = {}
        sc = session()
        stmt1 = "select id, id_no, name, username, r_create_time from strategy where id = %d" % group_id
        row = sc.execute(stmt1).first()
        if row:
            result = {"s_id": row[0], 'strategy_id': row[1], 'name': row[2],
                      'creator': row[3], 'created_date': row[4].strftime('%Y-%m-%d')}

        vs_ids, status, close = [], -1, 0
        stmt2 = "select id, status, closing_out from vstrategies where group_id = %d and portfolio_id = %d and status = %d" % (
            group_id, pf_id, consts.STRATEGY_LIVE)
        rows = sc.execute(stmt2)
        for row in rows:
            vs_ids.append(row[0])
            status, close = row[1], row[2]
        if vs_ids:
            check = CheckStatus(vs_id=vs_ids[0])
            allow_close, allow_cancel = check.allow_close(), check.allow_cancel()
        else:
            allow_close, allow_cancel = False, False

        result.update({
            'status': VStrategies.get_status(status, close),
            'group_id': group_id, 'account': AllLivePortfolios.query_account_info(pf_id, vs_ids, exchange),
            'closable': allow_close, 'revokable': allow_cancel,
            'cash_manager': {'name': '', 'id_no': ''}
        })
        sc.close()
        return result

    @staticmethod
    def is_have_item(result, group_id):
        for item in result:
            if item.get('group_id', -1) == group_id:
                return item
        return {}

    def get_all_strat(self, pf_id, exchange, vs_cash_manager):
        result = []
        stmt = "select vs.id, st.id_no, vs.status, vs.closing_out, st.username, st.r_create_time, st.name, st.id as s_id, vs.group_id " \
               "from vstrategies as vs inner join strategy as st on vs.strategy_id = st.id where vs.portfolio_id=%d" % pf_id
        sc = session()
        rows = sc.execute(stmt)
        for row in rows:
            vs_id, st_id, group_id = row[0], row[7], row[8]
            check = CheckStatus(vs_id=vs_id)
            vstrategy_item = {
                'vs_id': vs_id,
                'name': row[6],
                'status': VStrategies.get_status(row[2], row[3]),
                'creator': row[4],
                'created_date': row[5].strftime('%Y-%m-%d'),
                'strategy_id': row[1],
                's_id': st_id,
                'account': AllLivePortfolios.query_account_info(pf_id, [vs_id], exchange),
                'closable': check.allow_close(),
                'revokable': check.allow_cancel(),
                'cash_manager': {
                    'name': vs_cash_manager.get(vs_id, {}).get('cm_name', ''),
                    'id_no': vs_cash_manager.get(vs_id, {}).get('id_no', ''),
                }
            }

            # deal with normal strategy
            if group_id <= 0:
                result.append(vstrategy_item)
                continue

            # deal with strategy group
            _exist_group = AllLivePortfolios.is_have_item(result, group_id)
            if not _exist_group:
                _new_group = AllLivePortfolios.strategy_group_info(pf_id, group_id, exchange)

                # add the first vstrategy to the new strategy group
                _new_group['sub_strategies'] = [vstrategy_item]

                # append this new strategy group
                result.append(_new_group)
                continue

            # append this vstrategy to strategy group
            _exist_group['sub_strategies'].append(vstrategy_item)

        sc.close()
        return result

    def get_live_strat(self, user_id, find_all, exchange, **kwargs):
        result = []
        sc = session()
        all_objs = sc.query(StrategyPortfolio).filter(StrategyPortfolio.status == consts.STRATEGY_LIVE)

        business = kwargs.get('business', '')
        if business:
            all_objs = all_objs.filter(StrategyPortfolio.business == business)
        else:
            if not find_all:
                all_objs = all_objs.filter(StrategyPortfolio.r_create_user_id == user_id)

        cash_managers = sc.query(
            CashManagerLiveConfig.vstrategy_id.label('vstrategy_id'),
            CashManagerLiveConfig.cm_group_name.label('cm_group_name'),
            Strategy.id_no.label('id_no'),
        ).join(Strategy, Strategy.id == CashManagerLiveConfig.cash_manager_id)

        vs_cash_manager = {}
        for cm in cash_managers:
            vs_cash_manager[cm.vstrategy_id] = {
                'cm_name': cm.cm_group_name,
                'id_no': cm.id_no
            }

        for obj in all_objs:
            check = CheckStatus(pf_id=obj.id)
            row = {"id": obj.id, "name": obj.name, "status": obj.get_portfolio_status(),
                   "creator": obj.username, "created_date": obj.r_create_time.strftime('%Y-%m-%d'),
                   "closable": check.allow_close(), "revokable": check.allow_cancel(),
                   'strategies': self.get_all_strat(obj.id, exchange, vs_cash_manager)}
            # for r_s in row['strategies']:
            #    r_s['cash_manager'] = {
            #        'name': vs_cash_manager.get(r_s.get("vs_id", ''), {}).get('cm_name', ''),
            #        'id_no': vs_cash_manager.get(r_s.get("vs_id", ''), {}).get('id_no', ''),
            #    }
            result.append(row)
        sc.close()
        return result

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        pf_id = int(self.get_argument('pf_id', 0))
        vs_id = int(self.get_argument('vs_id', 0))
        group_id = int(self.get_argument('group_id', 0))
        get_exch = self.get_argument('exchange', 'true')
        exchange = True if get_exch == 'true' else False

        if group_id > 0:
            vs_ids = AllLivePortfolios.query_vs_ids(group_id)
            ret_data = AllLivePortfolios.query_account_info(pf_id, vs_ids, exchange)
            self.json_response({'code': 0, 'data': ret_data})
            return True

        if vs_id > 0:
            ret_data = AllLivePortfolios.query_account_info(pf_id, [vs_id], exchange)
            self.json_response({'code': 0, 'data': ret_data})
            return True

        find_all = False
        user_id = self.current_user['id']
        group_ids = self.get_user_group()
        if consts.INVESTMENT_GROUP in group_ids or \
                consts.OPERATION_GROUP in group_ids:
            find_all = True

        business = ''
        if self.is_stock_page() and self.is_stock_group():
            # user_id = consts.stock_user['id']
            business = 'stock'

        if self.is_future_page() and self.is_future_group():
            # user_id = consts.future_user['id']
            business = 'future'

        ret_data = self.get_live_strat(user_id, find_all, exchange, business=business)

        self.json_response({'code': 0, 'data': ret_data})
        return True


class LivePortfolios(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    def set_close_status(self, pf_id, vs_id, group_id, status, close_way=None, close_duration=None):
        sc = session()
        if vs_id > 0:
            vs_objs = sc.query(VStrategies).filter(VStrategies.portfolio_id == pf_id, VStrategies.id == vs_id)
        elif group_id > 0:
            vs_objs = sc.query(VStrategies).filter(VStrategies.portfolio_id == pf_id, VStrategies.group_id == group_id)
        else:
            vs_objs = sc.query(VStrategies).filter(VStrategies.portfolio_id == pf_id)

        for obj in vs_objs:
            if status == 'revokeCloseout' and obj.closing_out == consts.STRATEGY_CLOSING_OUT:
                obj.closing_out = 0
            elif status == 'closeout' and obj.status == consts.STRATEGY_LIVE:
                obj.closing_out = consts.STRATEGY_CLOSING_OUT
                obj.set_close_time = datetime.datetime.now()

                # set close detail info
                if (close_way is None) or (close_duration is None):
                    continue

                obj_close_detail = ClosePositionDetail()
                obj_close_detail.vsid = obj.id
                obj_close_detail.pf_id = pf_id
                obj_close_detail.close_way = close_way
                obj_close_detail.close_execute_duration = close_duration
                obj_close_detail.close_status = ''
                _now = datetime.datetime.now()
                obj_close_detail.ctime = _now
                obj_close_detail.utime = _now
                sc.merge(obj_close_detail, load=True)

        sc.commit()
        sc.close()

    def get_portfolio_user(self, pf_id):
        sc = session()
        pf_obj = sc.query(StrategyPortfolio).filter(StrategyPortfolio.id == pf_id).first()
        user_id = pf_obj.r_create_user_id
        sc.close()
        return user_id

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        pf_id = int(kwargs['id'])
        payload = self.get_payload()
        status = payload.get('action', 'closeout')
        vs_id = payload.get('vs_id', 0)
        group_id = payload.get('group_id', 0)

        find_all = False
        group_ids = self.get_user_group()
        if consts.INVESTMENT_GROUP in group_ids or \
                consts.OPERATION_GROUP in group_ids:
            find_all = True

        if not find_all:
            user_id = self.get_user_id()['id']
            pf_user_id = self.get_portfolio_user(pf_id)
            if (user_id != pf_user_id) and (not ((self.is_future_page() and self.is_future_group()) or (
                    self.is_stock_page() and self.is_stock_group()))):
                self.json_response({
                    'code': 1004,
                    'error': 'Permission denied.'
                })
                return False

        check = CheckStatus(pf_id, vs_id)
        if (status == 'closeout' and not check.allow_close()) or \
                (status == 'revokeCloseout' and not check.allow_cancel()):
            self.json_response({
                'code': 1134,
                'error': '当前操作不允许.'
            })
            return False

        close_way = payload.get('close_way', None)
        close_duration = payload.get('close_execute_duration', None)

        self.set_close_status(pf_id, vs_id, group_id, status, close_way, close_duration)
        sql = 'SELECT deploy.`host`,st.id_no,deploy.id from vstrategies vs LEFT JOIN deploy_confs deploy on vs.id=deploy.vstrategy_id LEFT JOIN strategy st on st.id=vs.strategy_id WHERE vs.id = %s' % vs_id
        with session_context() as sc:
            for host, name, process_id in sc.execute(sql):
                action = "置为" if status == 'closeout' else "撤销"
                msg = '策略{name}(vs_id={vs_id}) host:{host}{action}下线，请知悉, process_id={process_id}'.format(vs_id=vs_id,
                                                                                                          process_id=process_id,
                                                                                                          action=action,
                                                                                                          host=host,
                                                                                                          name=name)
                notify_operation_wechat(msg)
        self.json_response({
            'code': 0,
            'data': 1
        })
        return True


class DownladGetList(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        sid = self.get_argument('strategy_id', None)
        if sid is None:
            self.json_response({'code': 1008, 'data': {}})
            return True

        uid = self.current_user['id']

        is_creator = StrategyUserRelation.is_creator(sid, uid)
        is_investor = StrategyUserRelation.is_investor(sid, uid)

        if (not self.is_stock_group()) and (not self.is_future_group()) and (uid != g_ROOT_ID) and (
                not is_creator and not is_investor):
            self.json_response({'code': 1004, 'data': {}})
            return True

        ret_d = get_download_list(int(sid), uid)

        self.json_response({'code': 0, 'data': ret_d})

        return True


class DownladGetFile(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        sid = self.get_argument('strategy_id', None)
        vid = self.get_argument('vid', None)
        type = self.get_argument('type', None)
        category = self.get_argument('category', None)

        if sid is None or type is None or category is None:
            self.json_response({'code': 1008, 'data': {}, 'error': 'common para error'})
            return True

        if category != 'bt' and vid is None:
            self.json_response({'code': 1008, 'data': {}, 'error': 'bt vid erro'})
            return True

        para_wrong = False
        csv_content = {}
        if category == 'lt':
            if type == 'summary':
                csv_content = gen_live_pnl_summary(int(sid), int(vid))
            elif type == 'detail':
                csv_content = gen_live_pnl_detail(int(sid), int(vid))
            else:
                para_wrong = True
        elif category == 'lt_analysis':
            if type == 'summary':
                csv_content = gen_vsbt_pnl_summary(int(sid), int(vid))
            elif type == 'detail':
                csv_content = gen_vsbt_pnl_detail(int(sid), int(vid))
            else:
                para_wrong = True
        elif category == 'bt':
            _func = gen_bt_pnl_summary
            _file_id = 'summary'
            if type == 'detail':
                _func = gen_bt_pnl_detail
                _file_id = 'detail'

            sc = session()
            st_obj = sc.query(Strategy).filter(Strategy.id == int(sid)).first()
            if not st_obj:
                self.json_response({'code': 1008, 'data': {}})
                return True
            if st_obj.node == 'group':
                # make a zip file
                zip_tmp_file = '%s_bt_%s.zip' % (int(sid), _file_id)
                zip_file_path = config.media + '/bt_result/' + zip_tmp_file
                import zipfile
                with zipfile.ZipFile(zip_file_path, 'w') as myzip:
                    for k, v in st_obj.group_detail.items():
                        csv_content = _func(int(k))
                        s_id_no = ''
                        s_name = ''
                        tmp_obj = sc.query(Strategy).filter(Strategy.id == int(k)).first()
                        if tmp_obj is not None:
                            s_id_no = tmp_obj.id_no
                            s_name = tmp_obj.name
                        myzip.writestr('%s_%s__%s_bt_%s.csv' % (k, s_id_no, s_name, _file_id), csv_content)
                self.json_response(
                    {'code': 0, 'data': {'content': '', 'static_url': '/media/bt_result/%s' % zip_tmp_file}})
                return True
            else:
                csv_content = _func(int(sid))
            sc.close()

        else:
            para_wrong = True

        _code = 1008 if para_wrong else 0

        self.json_response({'code': _code, 'data': {'content': csv_content}})
        return True


class PortfolioAnalysisHandler(CurrentUserMixin, BaseHandler):

    @staticmethod
    def gen_line(data):
        detail = json.loads(data[4])
        is_null = lambda s: s if s else ''
        up_type = {'back_test': 'so_file', 'order_list': 'order_list',
                   'trademaster_order_list': 'trademaster_order_list'}
        return {'id_no': data[0], 'name': data[1], 'upload_type': up_type.get(data[2], ''),
                'strategy_type': is_null(data[3]),
                'products': detail['products'], 'hedge': is_null(data[5]), 'hedge_type': is_null(data[6]),
                'day_night': data[7], 'quote_deepth': detail['quote_deepth'], 'desc': is_null(data[8])}

    @staticmethod
    def load_info(pf_id):
        result = []
        stmt = "select id_no, name, node, strategy_type, detail, hedge, hedge_type, day_night, description from strategy " \
               "where id in (select strategy_id from research_strategy_portfolio_detail where portfolio_id=%d)" % pf_id
        sc = session()
        rows = sc.execute(stmt)
        for row in rows:
            result.append(PortfolioAnalysisHandler.gen_line(row))
        sc.close()
        return result

    @staticmethod
    def get_portfolio_name(pf_id):
        sc = session()
        portfolio_name = None
        pf_obj = sc.query(ResearchStrategyPortfolio).filter(ResearchStrategyPortfolio.id == pf_id).first()
        if pf_obj:
            portfolio_name = pf_obj.name
        sc.close()
        return portfolio_name

    @gen.coroutine
    def get(self, *args, **kwargs):
        pf_id = int(kwargs['id'])

        pf_name = PortfolioAnalysisHandler.get_portfolio_name(pf_id)
        if pf_name is None:
            self.json_response({
                'code': 1005,
                'error': 'Parameter error.'})
            return False
        else:
            self.json_response({
                'code': 0,
                'data': {
                    'portfolio': pf_name,
                    'strategy': PortfolioAnalysisHandler.load_info(pf_id)}
            })
            return True


class EventHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        payload = self.get_payload()
        event = payload['event']
        if event == 'SettleDone':
            """
            1. clear settlement cache
            2. report
            """
            Strategy.clear_investmentperformance_cache()
            InvestmentPerformanceService.clear_basic_cache(None)
            from cron.strategy_upload_task import settlement_notify
            settlement_notify.delay(payload['content']['trading_date'], payload['content']['day_night'])
        elif event == 'SendFactorColumns':
            StockFactorStrategyColumns.set_factor_columns(
                payload['content']['fid'],
                payload['content']['columns']
            )

        self.json_response({
            'code': 0
        })
        return True


class AdvanceCheck(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    def get_dependency(self, data, trade_date, day_night):
        result = []
        dependency = json.loads(data[8])
        if trade_date is None:
            trade_date = Strategy.get_trading_date()
        if day_night is None:
            now_hour = datetime.datetime.now().hour
            if 6 <= now_hour < 18:
                day_night = 'day'
            else:
                day_night = 'night'

        for dep in dependency:
            sub_path = dep['name'].strip().replace(' ', '')[:-10]
            ev_file = 'strategy_upload/output/%s/%s/ev_output_%s_%d_%s.csv' % (data[7],
                                                                               sub_path, trade_date, dep['id'],
                                                                               day_night)
            full_ev_path = os.path.join(config.media, ev_file)
            result.append({'id': dep['id'], 'ev_file': full_ev_path})
        return result

    def get_live_strategies(self, date, day_night, proc_id):
        result = []
        stmt = "select vs.id, vs.portfolio_id, st.id, st.id_no, st.node, st.day_night, st.name, st.username, st.dependency " \
               "from vstrategies as vs inner join strategy as st on vs.strategy_id = st.id where "
        if proc_id is None:
            stmt += "vs.status=%d" % consts.STRATEGY_LIVE
        else:
            stmt += "vs.id in (select vstrategy_id from deploy_confs where id=%d)" % int(proc_id)
        sc = session()
        rows = sc.execute(stmt)
        for row in rows:
            line_data = {"vs_id": row[0], "pf_id": row[1], "st_id": row[2], "name": row[3],
                         "category": row[4], "username": row[7],
                         "dependency": self.get_dependency(row, date, day_night)}
            self.base_infos(line_data)
            self.check_ev_files(line_data)
            self.check_live_cash(line_data)
            result.append(line_data)
        sc.close()
        return result

    @staticmethod
    def get_file_info(path):
        file_path = path.encode('utf8')
        if os.path.exists(file_path):
            get_time = lambda tm: time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(tm))
            size = os.path.getsize(file_path)
            create_time = get_time(os.path.getctime(file_path))
            with open(file_path, 'r') as fp:
                lines = len(fp.readlines())
            return {'existence': True, 'size': size, 'create_time': create_time, 'lines': lines}
        else:
            return {'existence': False}

    def base_infos(self, data):
        all_ok = True
        for dep in data['dependency']:
            info = AdvanceCheck.get_file_info(dep['ev_file'])
            dep.update(info)
            if not info['existence']:
                all_ok = False
        data['ev_status'] = all_ok

    def check_zhanglong_strat(self, data, rules):
        if not data['ev_status']:
            return False

        dependency = data['dependency']
        for dep in dependency:
            if dep['id'] in rules:
                rule = rules[dep['id']]
            else:
                return False
            if dep['size'] < rule['size'][0]:
                return False
            if dep['lines'] < rule['lines'][0]:
                return False
        return True

    def check_ev_files(self, data):
        if data['st_id'] == 201282:
            rules = {201159: {'size': (80 * 1024,), 'lines': (2500,)},
                     201161: {'size': (50,), 'lines': (4,)},
                     201163: {'size': (25000,), 'lines': (250,)},
                     201165: {'size': (4 * 1024 * 1024,), 'lines': (2500,)}}
            data['ev_status'] = self.check_zhanglong_strat(data, rules)

        # Other strategies inspection rules
        # if data['st_id'] == 12345:
        # rules = {}
        # data['ev_status'] = self.check_xxxxx_strat(data, rules)

    def check_live_cash(self, data):
        stmt = "select cash, available_cash from vs_base where vstrategy_id=%d and (settle_date, daynight) = " \
               "(select settle_date, daynight from vs_base where vstrategy_id=%d order by settle_date desc, daynight asc LIMIT 0, 1)" % (
                   data['vs_id'], data['vs_id'])
        sc = session()
        rows = sc.execute(stmt)
        need_cash, available_cash = 0, 0
        for row in rows:
            need_cash = row[0]
            # available_cash = row[1]
        sc.close()
        data.update({'cash': need_cash})

    @gen.coroutine
    def get(self, *args, **kwargs):
        date = self.get_argument('date', None)
        day_night = self.get_argument('day_night', None)
        proc_id = self.get_argument('process_id', None)
        self.json_response({'code': 0,
                            'data': self.get_live_strategies(date, day_night, proc_id)})
        return True


class FactorData(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        sid = self.get_argument('strategy_id', None)
        if sid is None:
            self.json_response({'code': 1008, 'data': {}})
            return True

        ret_d = get_factor_data(int(sid))

        df = pd.DataFrame.from_dict(ret_d, orient='index')
        df.columns = ['strategy_id', 'date', 'symbol', 'long_pos', 'short_pos', 'price']
        df = df.sort_index()

        ret_str = df.to_json(orient='split')

        ret_d = json.loads(ret_str)

        del ret_d['index']

        self.json_response(ret_d)

        return True


class CashManagerHandler(JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        sc = session()
        strategies = sc.query(
            Strategy.username.label('username'),
            Strategy.r_create_user_id.label('user_id'),
            Strategy.id_no.label('id_no'),
            Strategy.id.label('id'),
        ).filter(
            Strategy.is_test == 0,
            Strategy.is_delete == 0,
            Strategy.node == 'cash_manager'
        )
        data = []
        for s in strategies:
            data.append({
                'username': s.username,
                'user_id': s.user_id,
                'id_no': s.id_no,
                'id': s.id,
            })
        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'strategies': data
            }
        })
        return True


class CashManagerStrategyHandler(JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):

        cm_strategy_id = kwargs['id'].upper()
        strategy_id, vs_id = None, None

        if cm_strategy_id.startswith('BT'):
            strategy_id = int(cm_strategy_id.replace('BT', ''))
        elif cm_strategy_id.startswith('LT'):
            vs_id = int(cm_strategy_id.replace('LT', ''))
        else:
            raise ValueError('strategy_id(%s) error' % cm_strategy_id)
        sc = session()

        if strategy_id:
            s = sc.query(Strategy).filter(Strategy.id == strategy_id).first()
        elif vs_id:
            s = sc.query(Strategy).join(
                VStrategies, VStrategies.strategy_id == Strategy.id
            ).filter(
                VStrategies.id == vs_id
            ).first()
        if not s:
            sc.close()
            raise ValueError('can not find strategy id=%s' % cm_strategy_id)
        data = {
            'id': s.id,
            'id_no': s.id_no,
            'products': s.products and s.products[0] or []
        }
        sc.close()
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class TobemanagedStrategiesHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        sc = session()

        self.get_current_user()
        if not self.current_user:
            return False

        strategies = sc.query(
            Strategy.id_no.label('id_no'),
            Strategy.id.label('id'),
            Strategy.name.label('name'),
        ).filter(
            Strategy.is_test == 0,
            Strategy.is_delete == 0,
            Strategy.node.in_(['order_list', 'trademaster_order_list', 'back_test']),
            Strategy.r_create_user_id == self.current_user['id'],
        )
        data = []
        for s in strategies:
            data.append({
                'id_no': s.id_no,
                'id': s.id,
                'name': s.name,
            })
        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'back_test_strategies': data,
            }
        })
        return True


class CashManagerLiveConfigHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        sc = session()

        self.get_current_user()
        if not self.current_user:
            return False

        payload = self.get_payload()

        if 'vs_ids' in payload:
            vs_ids = payload['vs_ids']
        elif 'ids' in payload:
            vs_ids = []
            for ids in payload['ids']:
                if 'vs_id' in ids:
                    vs_ids.append(ids['vs_id'])
                else:
                    for _vs in sc.query(VStrategies.id).filter(
                            VStrategies.group_id == ids['group_id'],
                            VStrategies.portfolio_id == ids['pf_id']):
                        vs_ids.append(_vs.id)
        else:
            sc.close()
            self.json_response({
                'code': 1082,
                'error': 'data error vs_ids or ids is required',
            })
            return
        vs_detail = {
            _vs[0]: {
                'group_id': _vs[1]
            }
            for _vs in sc.query(VStrategies.id, VStrategies.group_id).filter(VStrategies.id.in_(vs_ids))
        }

        accounts = sc.query(distinct(VStrategyAccountDetail.account)).filter(
            VStrategyAccountDetail.vstrategy_id.in_(vs_ids)
        )
        if accounts.count() != 1:
            self.json_response({
                'code': 1079,
                'error': 'vstrategies accounts not only'
            })
            return
        if sc.query(CashManagerLiveConfig).filter(CashManagerLiveConfig.cm_group_name == payload['name']).count() > 0:
            sc.close()
            self.json_response({
                'code': 1081,
                'error': 'cash manager name(%s) is already exists' % payload['name']
            })
            return
        cash_manager_vs = sc.query(CashManagerLiveConfig.vstrategy_id.label('vs_id')).filter(
            CashManagerLiveConfig.vstrategy_id.in_(vs_ids)
        )
        cash_manager_vs_ids = [c.vs_id for c in cash_manager_vs]
        if cash_manager_vs_ids:
            sc.close()
            self.json_response({
                'code': 1080,
                'error': 'vstrategies(%s) is already in other cash manager group' % cash_manager_vs_ids
            })
            return

        cm_uuid = uuid.uuid1().hex
        cms = []
        for vs_id in vs_ids:
            cm = CashManagerLiveConfig(
                cash_manager_id=payload['cash_manager_id'],
                vstrategy_id=vs_id,
                cm_group_id=cm_uuid,
                cm_group_name=payload['name'],
                r_create_user_id=self.current_user['id'],
                live_group_id=vs_detail[vs_id]['group_id'],
            )
            cms.append(cm)
        sc.add_all(cms)
        sc.commit()
        sc.close()
        self.json_response({
            'code': 0,
        })
        return True

    @gen.coroutine
    def get(self, *args, **kwargs):
        sc = session()
        self.get_current_user()
        if not self.current_user:
            return False

        find_all = False
        group_ids = self.get_user_group()
        if consts.INVESTMENT_GROUP in group_ids or \
                consts.OPERATION_GROUP in group_ids:
            find_all = True
        cms = sc.query(CashManagerLiveConfig).filter(CashManagerLiveConfig.vstrategy_id.isnot(None))
        if not find_all:
            cms = cms.filter(CashManagerLiveConfig.r_create_user_id == self.current_user['id'])

        data = {}
        for cm in cms:
            if cm.cm_group_id not in data:
                data[cm.cm_group_id] = {
                    'cash_manager_group_id': cm.cm_group_id,
                    'cash_manager_id': cm.cash_manager_id,
                    'cash_manager_group_name': cm.cm_group_name,
                    'user_id': cm.r_create_user_id,
                    'vs_detail': []
                }
            data[cm.cm_group_id]['vs_detail'].append({
                'id': cm.id,
                'vs_id': cm.vstrategy_id,
            })

        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'cash_manager_group': data,
            }
        })
        return True

    @gen.coroutine
    def delete(self, *args, **kwargs):
        sc = session()
        self.get_current_user()
        if not self.current_user:
            return False

        is_superuser = False
        group_ids = self.get_user_group()
        if consts.INVESTMENT_GROUP in group_ids or \
                consts.OPERATION_GROUP in group_ids:
            is_superuser = True

        cm_id = int(self.get_argument('id', -1))
        cm_group_id = int(self.get_argument('cash_manager_group_id', ''))

        if cm_id > 0:
            cms = sc.query(CashManagerLiveConfig).filter(CashManagerLiveConfig.id == cm_id)
        elif cm_group_id:
            cms = sc.query(CashManagerLiveConfig).filter(CashManagerLiveConfig.cm_group_id == cm_group_id)
        else:
            sc.close()
            self.json_response({
                'code': 1081,
                'error': 'args error'
            })
            return True

        if not is_superuser:
            cms = cms.filter(CashManagerLiveConfig.r_create_user_id == self.current_user['id'])
        cms.delete(synchronize_session=False)
        sc.close()
        self.json_response({
            'code': 0,
        })
        return True


class CashManagerPerformanceHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.json_response({
            'code': 0,
            'data': {},
        })
        return True


class CashManagerPerformanceTradelogsHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.json_response({
            'code': 0,
            'data': {},
        })
        return True


class SemiLivesHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        user_id = self.current_user['id']
        page = int(self.get_argument('page', 0))
        size = int(self.get_argument('size', 500))
        is_group = self.get_argument('is_portfolio', '')

        strat_one = BackTestConfig.get_strategies(user_id=user_id, group_id=consts.STRAT_SINGLE)
        strat_two = BackTestConfig.get_strategies(user_id=user_id, group_id=consts.STRAT_GROUP)
        if is_group == 'true':
            all_strate = strat_two
        elif is_group == 'false':
            all_strate = strat_one
        else:
            all_strate = strat_one + strat_two
        need_ids = [st['strategy_id'] for st in all_strate]
        sc = session()
        strategies = sc.query(Strategy).filter(Strategy.id.in_(need_ids))
        total = strategies.count()
        strategies = strategies.order_by(Strategy.id.desc()).offset(page * size).limit(size)

        result = []
        for item in strategies:
            cfg_id, back_id = BackTestConfig.query_config(all_strate, item.id)
            result.append(item.to_dict_detail(config_id=cfg_id, back_id=back_id))
        self.json_response({
            'code': 0,
            'data': result,
            'total': total,
        })
        sc.close()
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        user_id = self.current_user['id']
        payload = self.get_payload()
        action = payload["action"]
        st_id = int(payload["strategy_id"])

        if action == 'add' or action == 'revoke':
            if action == 'add':
                BackTestConfig.add_config(user_id, st_id)
            if action == 'revoke':
                is_group = payload.get('is_group', 0)
                BackTestConfig.revoke_config(user_id, st_id, int(is_group))
            self.json_response({
                'code': 0, 'data': 1
            })
            return True

        if action == 'start_task':
            start = payload['start_date']
            cash = float(payload['init_cash'])
            model = payload['trade_model']
            accounts = payload.get('accounts', {})
            if accounts:
                initial_cash = 0
                for _, a_d in accounts.items():
                    initial_cash += a_d['cash']
                if initial_cash:
                    cash = initial_cash
            st_config = {
                'accounts': accounts,
            }
            BackTestConfig.update_config(user_id, st_id, start, cash, model, True, **st_config)
            from cron.strategy_upload_task import refer_start_back_test
            refer_start_back_test.delay(user_id, st_id)
        if action == 'stop_task':
            BackTestConfig.stop_back_test(user_id, st_id)

        sc = session()
        st_obj = sc.query(Strategy).get(st_id)
        cfg_info = BackTestConfig.get_config_id(user_id, st_id)
        if cfg_info["group_id"] == consts.STRAT_SINGLE:
            cfg_id, back_id = cfg_info["cfg_id"], 0
        else:
            cfg_id, back_id = 0, cfg_info["cfg_id"]
        self.json_response({
            'code': 0, 'data': st_obj.to_dict_detail(config_id=cfg_id, back_id=back_id)
        })
        sc.close()
        return True


class StrategyAuthorListHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        # self.get_current_user()
        # if not self.current_user:
        #    return False
        is_stock_page = self.is_stock_page()
        if is_stock_page:
            cache_key = 'strategy_author_list_stock'
        else:
            cache_key = 'strategy_author_list'
        users = get_cache(cache_key)
        if not users:
            sc = session()
            if is_stock_page:
                users = [r[0] for r in sc.query(distinct(Strategy.username)).filter(
                    Strategy.is_delete == 0,
                    Strategy.is_test == 0,
                    Strategy.node == 'back_test',
                    Strategy.strategy_type.in_(consts.stock_strategy_type)
                ).order_by(Strategy.username)]
            else:
                users = [r[0] for r in sc.query(distinct(Strategy.username)).filter(
                    Strategy.is_delete == 0,
                    Strategy.is_test == 0,
                    Strategy.node == 'back_test'
                ).order_by(Strategy.username)]
            sc.close()
            set_cache(cache_key, users, 86400)
        self.json_response({
            'code': 0,
            'data': {
                'author_list': users,
            }
        })
        return


class StrategyListHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        self.json_response({
            'code': 0,
            'data': {
                'sum': 0,
                'list': []
            }
        })
        return


class PublishNotebookHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        nb_path = self.get_argument('nb_path', '')
        if not nb_path:
            self.json_response({'code': 1008, 'data': {}, 'error': 'path invalid'})
            return True

        nb_file_path = config.user_nb_dir_template % (
            self.current_user['id'], self.current_user['username']) + '/' + nb_path
        with open(nb_file_path) as f:
            content = f.read()

        import nbformat
        from nbconvert import HTMLExporter

        _notebook = nbformat.reads(content, as_version=4)
        html_exporter = HTMLExporter()
        html_exporter.template_file = 'full'

        (body, resources) = html_exporter.from_notebook_node(_notebook)

        output_tmp_file = os.path.basename(nb_path).replace('ipynb', 'html')
        relative_path = '/publish_notebooks/' + '%s_%s/' % (self.current_user['id'], self.current_user['username'])
        static_path = config.media + relative_path
        if not os.path.exists(static_path):
            os.makedirs(static_path)
        static_file = static_path + output_tmp_file

        with open(static_file, 'w') as f:
            f.write(body)

        self.json_response({'code': 0, 'data': {'static_url': '/media' + relative_path + output_tmp_file}})
        return


class TraverseNotebookHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        nb_path = self.get_argument('nb_path', '')
        if not nb_path:
            self.json_response({'code': 1008, 'data': {}, 'error': 'path invalid'})
            return True

        nb_file_path = config.user_nb_dir_template % (
            self.current_user['id'], self.current_user['username']) + '/' + nb_path

        ret_l = []

        for dirname, dirnames, filenames in os.walk(nb_file_path):

            for dir in dirnames:
                if dir == 'MY Data Documents (Read Only)' or dir == '茂源数据公共文档 (只读)' or dir == '应用数据':
                    continue
                if dir.startswith('.'):
                    continue
                ret_l.append({'name': dir, 'type': 'dir'})

            for file in filenames:
                if file.startswith('.'):
                    continue

                if not file.endswith('.ipynb'):
                    continue

                ret_l.append({'name': file, 'type': 'file'})

            break

        self.json_response({'code': 0, 'data': ret_l})
        return


class RemarksHandler(CurrentUserMixin, BaseHandler):
    reobj = re.compile(r'\[\[(?P<name>.*?)\]\((?P<link>.*?)\)\]')

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        sid = self.get_argument('sid', '')
        if not sid:
            self.json_response({'code': 1008, 'data': {}, 'error': 'para invalid'})
            return True

        from_lt_page = False
        vids = self.get_argument('vids', '')
        if vids:
            from_lt_page = True
            sorted_vids = sorted(vids.split(','))

        remarks_l = []
        sc = session()
        query = sc.query(StrategyRemark).filter(StrategyRemark.sid == int(sid))
        if from_lt_page:
            query = query.filter(StrategyRemark.vids == ','.join(sorted_vids))

        for row in query:

            if (not from_lt_page) and row.vids:
                continue

            d = {
                'remark_id': row.remark_id,
                'sid': row.sid,
                'uid': row.uid,
                'uname': row.uname,
                'remark': row.remark,
                'uptime': row.utime.strftime('%Y-%m-%d %H:%M:%S'),
            }
            remarks_l.append(d)

        self.json_response({
            'code': 0,
            'data': remarks_l,
        })
        sc.close()

        return

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        req_json = json.loads(self.request.body.decode('utf-8'))

        sid = req_json.get('sid', None)
        remark = req_json.get('remark', None)

        if (sid and remark) is None:
            self.json_response({'code': 1008, 'data': {}, 'error': 'para invalid'})
            return True

        from_lt_page = False
        vids = req_json.get('vids', [])
        if vids:
            from_lt_page = True
            sorted_vids = sorted(vids)

        uid = self.current_user['id']
        is_creator = StrategyUserRelation.is_creator(sid, uid)
        is_investor = StrategyUserRelation.is_investor(sid, uid)
        if (not self.is_stock_group()) and (not self.is_future_group()) and (uid != g_ROOT_ID) and (
                not is_creator and not is_investor):
            self.json_response({'code': 1004, 'data': {}})
            return True

        links_l = []
        for mo in self.reobj.finditer(remark):
            links_l.append({'name': mo.group('name'), 'link': mo.group('link')})

        obj = StrategyRemark()
        obj.sid = sid
        obj.uid = uid
        obj.uname = self.current_user['username']
        obj.remark = remark
        obj.links = links_l
        obj.vids = ','.join(str(x) for x in sorted_vids) if from_lt_page else ''

        sc = session()
        sc.add(obj)
        sc.commit()
        sc.close()

        cache_rds = redis.Redis(host=config.redis['host'], port=config.redis['port'], db=config.redis['db'])
        cache_key = 'platform_investment_basic_data_*'
        for key in cache_rds.keys(cache_key):
            cache_rds.delete(key)

        self.json_response({'code': 0, 'data': {}})
        return

    @gen.coroutine
    def put(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        req_json = json.loads(self.request.body.decode('utf-8'))

        remark_id = req_json.get('remark_id', None)
        remark = req_json.get('remark', None)

        if (remark_id and remark) is None:
            self.json_response({'code': 1008, 'data': {}, 'error': 'para invalid'})
            return True

        uid = self.current_user['id']

        try:
            sc = session()
            _query_result = sc.query(StrategyRemark).filter(StrategyRemark.remark_id == int(remark_id))
            row = _query_result.first()
            if not row:
                self.json_response({'code': 10091, 'data': {}, 'error': 'cannot found existing remark'})
                return True

            if str(uid) != str(row.uid):
                logger.info('modify remark not same user:%s,%s' % (uid, row.uid))
                self.json_response({'code': 10092, 'data': {}, 'error': 'not the same user who create the remark'})
                return True

            links_l = []
            for mo in self.reobj.finditer(remark):
                links_l.append({'name': mo.group('name'), 'link': mo.group('link')})

            _query_result.update(
                {
                    'remark': remark,
                    'links': links_l
                }, synchronize_session=False
            )

            sc.commit()

        except:
            sc.rollback()
            raise
        finally:
            sc.close()

        self.json_response({'code': 0, 'data': {}})
        return

    @gen.coroutine
    def delete(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        remark_id = self.get_argument('remark_id', '')
        if remark_id is None:
            self.json_response({'code': 1008, 'data': {}, 'error': 'para invalid'})
            return True

        uid = self.current_user['id']

        try:
            sc = session()

            _query_result = sc.query(StrategyRemark).filter(StrategyRemark.remark_id == int(remark_id))
            row = _query_result.first()
            if not row:
                self.json_response({'code': 10091, 'data': {}, 'error': 'cannot found existing remark'})
                return True

            if str(uid) != str(row.uid):
                self.json_response({'code': 10092, 'data': {}, 'error': 'not the same user who create the remark'})
                return True

            _query_result.delete()
            sc.commit()
        except:
            sc.rollback()
            raise
        finally:
            sc.close()

        self.json_response({'code': 0, 'data': {}})
        return


class QuantamentalsHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    def __check_task_need_restart(self, post_data):
        re_products = []
        current_date = datetime.datetime.now().strftime('%Y%m%d')
        if datetime.datetime.now().hour < 9:
            next_trading_date = current_date
        else:
            next_trading_date = KdbQuery().get_today_next_trading_date(current_date)[1]

        for p in post_data:
            if 'update' in p:
                if p['update'] < next_trading_date:
                    re_products.append(p['product'].lower())
        if re_products:
            return True, re_products
        return False, []

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        user_id = self.current_user['id']
        post_data = self.get_payload()
        """ e.g.
        post_data = [
            {
                'product': 'hc',
                'detail': [
                    {'date': '20180301', 'direction': 1, 'update': '20180413'},
                    {'date': '20180401', 'direction': -1, 'update': '20180413'},
                ]
                'papertrading_date': '20180302',
                'update': '20180301',
            },
            ...,
        ]
        """
        try:
            sc = session()
            need_re_back_test, products_to_restart = self.__check_task_need_restart(post_data)
            for p_data in post_data:
                papertrading_date = p_data.get('papertrading_date', '')
                product = p_data['product']
                predict_data_set = sorted(p_data['detail'], key=lambda k: k['date'])
                quantamental = sc.query(Quantamentals).filter(
                    Quantamentals.user_id == user_id,
                    Quantamentals.q_strat_id == user_id,
                    Quantamentals.product == product,
                ).first()
                if quantamental:
                    quantamental.papertrading_date = papertrading_date
                    sc.query(QuantamentalDetails).filter(
                        QuantamentalDetails.quantamental_id == quantamental.id
                    ).delete(synchronize_session=False)
                    for d in predict_data_set:
                        detail = {
                            'quantamental_id': quantamental.id,
                            'date': d['date'],
                            'direction': d['direction'],
                            'update': d['update'],
                            'description': d.get('description', ''),
                        }
                        if d['supply_predict']:
                            detail['supply_predict'] = d['supply_predict']
                        if d['demand_predict']:
                            detail['demand_predict'] = d['demand_predict']
                        if d['analyst_predict']:
                            detail['analyst_predict'] = d['analyst_predict']
                        sc.add(QuantamentalDetails(**detail))
                else:
                    data = {
                        'user_id': user_id,
                        'q_strat_id': user_id,
                        'product': product,
                        'papertrading_date': papertrading_date,
                    }
                    quantamental = Quantamentals(**data)
                    sc.add(quantamental)
                    sc.flush()
                    for d in predict_data_set:
                        detail = {
                            'quantamental_id': quantamental.id,
                            'date': d['date'],
                            'direction': d['direction'],
                            'update': d['update'],
                            'description': d.get('description', ''),
                        }
                        if d['supply_predict']:
                            detail['supply_predict'] = d['supply_predict']
                        if d['demand_predict']:
                            detail['demand_predict'] = d['demand_predict']
                        if d['analyst_predict']:
                            detail['analyst_predict'] = d['analyst_predict']
                        sc.add(QuantamentalDetails(**detail))
            sc.commit()
            if need_re_back_test:
                strategies = BackTestConfig.get_strategies(user_id=user_id, group_id=consts.STRAT_SINGLE)
                need_ids = [st['strategy_id'] for st in strategies]
                strategies = sc.query(Strategy).filter(
                    Strategy.id.in_(need_ids),
                    Strategy.node.in_(['order_list', 'trademaster_order_list']),
                )
                need_ids = []
                for st in strategies:
                    for p in st.products[0]:
                        if p['symbol'].lower() in products_to_restart:
                            need_ids.append(st.id)
                # need_ids = [st.id for st in strategies]
                for st_id in need_ids:
                    q_cfg_id = BackTestConfig.get_link_config_id(user_id, st_id)
                    BackTestConfig.stop_cfg_back_test(st_id, q_cfg_id)

                    task_id = BackTestConfig.copy_link_config(user_id, st_id)
                    q_cfg_id = BackTestConfig.get_link_config_id(user_id, st_id)

            self.json_response({
                'code': 0,
                'data': post_data,
            })
        except Exception as e:
            sc.rollback()
            sentry.captureException()
            self.json_response({
                'code': 500,
                'error': str(e),
            })
        finally:
            sc.close()

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        try:
            sc = session()
            quantamentals = sc.query(Quantamentals).filter(
                Quantamentals.user_id == self.current_user['id'],
                Quantamentals.q_strat_id == self.current_user['id'],
            )
            res = [d.to_dict() for d in quantamentals]
            self.json_response({
                'code': 0,
                'data': res,
            })
        except Exception as e:
            sc.rollback()
            sentry.captureException()
            self.json_response({
                'code': 500,
                'error': str(e),
            })
        finally:
            sc.close()


class QuantamentalPaperTradingHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        post_data = self.get_payload()
        """ e.g.
        post_data = {
            'product': 'hc',
            'detail': [
                {'date': '20180301', 'direction': 1, 'update': '20180413'},
                {'date': '20180401', 'direction': -1, 'update': '20180413'},
            ]
            'papertrading_date': '20180302',
        }
        """
        try:
            sc = session()
            papertrading_date = post_data.get('papertrading_date', '')
            product = post_data['product']
            new_data = post_data['detail']
            if not new_data:
                self.json_response({
                    'code': 0,
                    'data': {
                        'updated': False,
                        'papertrading_date': '',
                    }
                })
                return False
            quantamental = sc.query(Quantamentals).filter(
                Quantamentals.user_id == self.current_user['id'],
                Quantamentals.product == product,
            ).first()
            origin_data = None
            if quantamental:
                quantamental_detail = sc.query(QuantamentalDetails).filter(
                    QuantamentalDetails.quantamental_id == quantamental.id,
                )
                origin_data = [d.to_detail() for d in quantamental_detail]
            new_data = [{'date': d['date'], 'direction': d['direction'], 'supply_predict': d['supply_predict'],
                         'demand_predict': d['demand_predict'], 'analyst_predict': d['analyst_predict'],
                         'update': d['update']} for d in new_data]
            res = self.__check_papertrading_date(origin_data, new_data, papertrading_date)
            self.json_response({
                'code': 0,
                'data': {
                    'updated': res[0],
                    'papertrading_date': res[1],
                }
            })
        except Exception as e:
            sc.rollback()
            sentry.captureException()
            self.json_response({
                'code': 500,
                'error': str(e),
            })
        finally:
            sc.close()

    def __check_papertrading_date(self, origin_data, new_data, papertrading_date):
        current_date = datetime.datetime.now().strftime('%Y%m%d')
        if datetime.datetime.now().hour < 9:
            next_trading_date = current_date
        else:
            next_trading_date = KdbQuery().get_today_next_trading_date(current_date)[1]

        if not origin_data:
            return True, next_trading_date
        else:
            origin_data = sorted(origin_data, key=lambda k: k['date'])
            new_data = sorted(new_data, key=lambda k: k['date'])
            diff_data = self.__diff_predict_data(origin_data, new_data)
            for d in diff_data:
                if d['date'] >= papertrading_date and d['date'] < next_trading_date:
                    new_papertrading_date = self.__get_next_predict_date(d['date'], origin_data, next_trading_date)
                    return True, new_papertrading_date
            return False, papertrading_date

    def __diff_predict_data(self, origin_data, new_data):
        data = [d for d in new_data if d not in origin_data]
        return sorted(data, key=lambda k: k['date'], reverse=True)

    def __get_next_predict_date(self, predict_date, predict_set, trading_date):
        for d in predict_set:
            if d['date'] > predict_date:
                return min(d['date'], trading_date)
        return trading_date


class SemiQuantamentalHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        user_id = self.current_user['id']
        page = int(self.get_argument('page', 0))
        size = int(self.get_argument('size', 500))
        is_group = self.get_argument('is_portfolio', '')

        all_strate = BackTestConfig.get_strategies(user_id=user_id, group_id=consts.STRAT_SINGLE)
        need_ids = [st['strategy_id'] for st in all_strate]
        sc = session()
        strategies = sc.query(Strategy).filter(
            Strategy.id.in_(need_ids),
            Strategy.node.in_(['order_list', 'trademaster_order_list']),
        )
        total = strategies.count()
        strategies = strategies.order_by(Strategy.id.desc()).offset(page * size).limit(size)

        result = []
        for item in strategies:
            cfg_id, back_id = BackTestConfig.query_config(all_strate, item.id)
            data = item.to_dict_detail(cfg_id, back_id)
            if 'quantamental' in data:
                if data['quantamental'].get('status', 'NEW') != 'FINISHED':
                    data['status'] = data['quantamental'].get('status', 'NEW')

            result.append(data)
        self.json_response({
            'code': 0,
            'data': result,
            'total': total,
        })
        sc.close()
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        user_id = self.current_user['id']
        payload = self.get_payload()
        action = payload.get("action", None)
        st_id = int(payload["strategy_id"])
        only_quantamental = payload.get('only_quantamental', False)

        if only_quantamental:
            q_cfg_id = BackTestConfig.get_link_config_id(user_id, st_id)
            BackTestConfig.stop_cfg_back_test(st_id, q_cfg_id)
            task_id = BackTestConfig.copy_link_config(user_id, st_id)
            q_cfg_id = BackTestConfig.get_link_config_id(user_id, st_id)

        if action == 'start_task':
            if not only_quantamental:
                BackTestConfig.stop_back_test(user_id, st_id)
            q_cfg_id = BackTestConfig.get_link_config_id(user_id, st_id)
            BackTestConfig.stop_cfg_back_test(st_id, q_cfg_id)

            start = payload['start_date']
            cash = float(payload['init_cash'])
            model = payload['trade_model']
            accounts = payload.get('accounts', {})
            if accounts:
                initial_cash = 0
                for _, a_d in accounts.items():
                    initial_cash += a_d['cash']
                if initial_cash:
                    cash = initial_cash
            st_config = {
                'accounts': accounts,
            }
            if not only_quantamental:
                BackTestConfig.update_config(user_id, st_id, start, cash, model, True, **st_config)
            else:
                BackTestConfig.update_config_by_cfg_id(q_cfg_id, start, cash, model, True, **st_config)
            task_id = BackTestConfig.copy_link_config(user_id, st_id)
            q_cfg_id = BackTestConfig.get_link_config_id(user_id, st_id)
            from cron.strategy_upload_task import refer_start_back_test
            if not only_quantamental:
                refer_start_back_test.delay(user_id, st_id)
        if action == 'stop_task':
            if not only_quantamental:
                BackTestConfig.stop_back_test(user_id, st_id)
            q_cfg_id = BackTestConfig.get_link_config_id(user_id, st_id)
            BackTestConfig.stop_cfg_back_test(st_id, q_cfg_id)

        sc = session()
        st_obj = sc.query(Strategy).get(st_id)
        cfg_info = BackTestConfig.get_config_id(user_id, st_id)
        if cfg_info["group_id"] == consts.STRAT_SINGLE:
            cfg_id, back_id = cfg_info["cfg_id"], 0
        else:
            cfg_id, back_id = 0, cfg_info["cfg_id"]
        data = st_obj.to_dict_detail(cfg_id, back_id)

        self.json_response({
            'code': 0, 'data': data
        })
        sc.close()
        return True


class QuantamentalProductsHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        user_id = self.current_user['id']

        # TODO: query data from kdb
        self.json_response({
            'code': 0,
            'data': [
                {'product': 'hc', 'name': u'热轧卷板'},
                {'product': 'rb', 'name': u'螺纹钢'},
                {'product': 'jm', 'name': u'焦煤'},
                {'product': 'l', 'name': u'塑料'},
                {'product': 'pp', 'name': u'聚丙烯'},
                {'product': 'v', 'name': u'聚氯乙烯'},
                {'product': 'cu', 'name': u'铜'},
                {'product': 'al', 'name': u'铝'},
                {'product': 'zn', 'name': u'锌'},
                {'product': 'pb', 'name': u'铅'},
                {'product': 'ni', 'name': u'镍'},
                {'product': 'sn', 'name': u'锡'},
                {'product': 'ru', 'name': u'橡胶'},
                {'product': 'au', 'name': u'黄金'},
                {'product': 'ag', 'name': u'白银'},
                {'product': 'wr', 'name': u'线材'},
                {'product': 'fu', 'name': u'燃料油'},
                {'product': 'bu', 'name': u'石油沥青'},
                {'product': 'a', 'name': u'黄大豆'},
                {'product': 'b', 'name': u'黄豆2号'},
                {'product': 'm', 'name': u'豆粕'},
                {'product': 'y', 'name': u'豆油'},
                {'product': 'p', 'name': u'棕榈油'},
                {'product': 'c', 'name': u'玉米'},
                {'product': 'cs', 'name': u'玉米淀粉'},
                {'product': 'l', 'name': u'聚乙烯'},
                {'product': 'j', 'name': u'焦炭'},
                {'product': 'i', 'name': u'铁矿石'},
                {'product': 'jd', 'name': u'鸡蛋'},
                {'product': 'bb', 'name': u'胶合板'},
                {'product': 'fb', 'name': u'纤维板'},
                {'product': 'CF', 'name': u'棉一号'},
                {'product': 'SR', 'name': u'白砂糖'},
                {'product': 'WH', 'name': u'强麦'},
                {'product': 'PM', 'name': u'普麦'},
                {'product': 'RI', 'name': u'早籼稻'},
                {'product': 'LR', 'name': u'晚籼稻'},
                {'product': 'JR', 'name': u'粳稻'},
                {'product': 'TA', 'name': u'PTA'},
                {'product': 'OI', 'name': u'菜籽油'},
                {'product': 'RS', 'name': u'油菜籽'},
                {'product': 'RM', 'name': u'菜籽粕'},
                {'product': 'FG', 'name': u'玻璃'},
                {'product': 'ZC', 'name': u'动力煤'},
                {'product': 'SF', 'name': u'硅铁'},
                {'product': 'SM', 'name': u'锰硅'},
                {'product': 'MA', 'name': u'甲醇'},
                {'product': 'CY', 'name': u'棉纱'},
                {'product': 'AP', 'name': u'苹果'},
                {'product': 'sc', 'name': u'原油'},
            ],
        })
        return True


class MainCodeQuoteDailyHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()

        product = self.get_argument('product', None)
        if not product:
            self.json_response({
                'code': 400,
                'error': 'request argument error',
            })
            return
        product_main = '%s1' % product.lower()

        cache_key = 'platform_futures_daily_bar_%s' % product_main
        res = get_cache(cache_key)
        if res:
            self.json_response({
                'code': 0,
                'data': res,
            })
            return

        data = bar.daily_bar(ticker=product_main, start=20100101, end=20491231)
        details = []
        for index, row in data.iterrows():
            if pd.isnull(row['OPENPRICE']) and pd.isnull(row['CLOSEPRICE']) and \
                    pd.isnull(row['HIGHPRICE']) and pd.isnull(row['LOWPRICE']) and \
                    pd.isnull(row['VOLUME']) and pd.isnull(row['AMOUNT']):
                continue
            details.append([
                row['TRADE_DT'].strftime('%Y-%m-%d'),
                row['OPENPRICE'], row['CLOSEPRICE'],
                row['HIGHPRICE'], row['LOWPRICE'],
                row['VOLUME'], row['AMOUNT'],
            ])
        set_cache(cache_key, details, 3600)

        self.json_response({
            'code': 0,
            'data': details,
        })


class PredictCustomColumnNameHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if 'superuser' == self.current_user['type']:
            self.write(json.dumps({
                'code': 1398,
                'error': '暂不支持超级用户添加企业业务数据！',
            }))
            return
        company_id = self.current_user['company_id']
        if -1 == company_id:
            self.write(json.dumps({
                'code': 1444,
                'error': '未找到用户所属的公司信息！',
            }))
            return
        user_id = self.current_user['id']
        payload = self.get_payload()

        try:
            sc = session()
            name = payload.get('column_name', '')
            if not name:
                self.json_response({
                    'code': 400,
                    'error': 'column name is Null !',
                })
                return

            c = sc.query(
                PredictCustomColumnNames
            ).filter_by(
                column_name=name,
                create_user_id=user_id,
            ).first()
            if c:
                self.json_response({
                    'code': 400,
                    'error': 'column name has exist !',
                })
                return

            c = PredictCustomColumnNames(
                column_name=name,
                company_id=company_id,
                create_user_id=user_id
            )
            sc.add(c)
            sc.commit()

            self.json_response({
                'code': 0,
                'data': c.to_dict(),
            })
        except Exception as e:
            sc.rollback()
            sentry.captureException()
            self.json_response({
                'code': 500,
                'error': str(e),
            })
        finally:
            sc.close()


class PredictCustomColumnNameIDHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def delete(self, *args, **kwargs):
        self.get_current_user()
        if 'superuser' == self.current_user['type']:
            self.write(json.dumps({
                'code': 1398,
                'error': '暂不支持超级用户删除企业业务数据！',
            }))
            return
        company_id = self.current_user['company_id']
        if -1 == company_id:
            self.write(json.dumps({
                'code': 1444,
                'error': '未找到用户所属的公司信息！',
            }))
            return
        user_id = self.current_user['id']

        try:
            sc = session()
            sc.query(
                PredictCustomColumnNames
            ).filter_by(
                id=kwargs['id'],
                create_user_id=user_id
            ).delete()
            sc.commit()

            self.json_response({
                'code': 0,
            })
        except Exception as e:
            sc.rollback()
            sentry.captureException()
            self.json_response({
                'code': 500,
                'error': str(e),
            })
        finally:
            sc.close()


class PredictCustomColumnValuesHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        user_id = self.current_user['id']
        company_id = self.current_user['company_id']
        if -1 == company_id and 'superuser' != self.current_user['type']:
            self.write(json.dumps({
                'code': 1444,
                'error': '未找到用户所属的公司信息！',
            }))
            return

        try:
            out_data = {
                'column_names': [],
                'column_values': {}
            }
            sc = session()
            column_names = []
            if 'superuser' != self.current_user['type']:
                column_names = sc.query(PredictCustomColumnNames).filter_by(create_user_id=user_id).all()
            else:
                column_names = sc.query(PredictCustomColumnNames).all()

            for column_name in column_names:
                out_data['column_names'].append(column_name.to_dict())
                for column_value in column_name.column_values:
                    logger.info("==========%s,%d,%s" % (column_value.date, column_name.id, column_value.value))
                    if column_value.date not in out_data['column_values'].keys():
                        out_data['column_values'][column_value.date] = {}
                    out_data['column_values'][column_value.date][column_name.id] = column_value.value
                    logger.info(out_data)

            self.json_response({
                'code': 0,
                'data': out_data,
            })
        except Exception as e:
            sc.rollback()
            sentry.captureException()
            self.json_response({
                'code': 500,
                'error': str(e),
            })
        finally:
            sc.close()

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if 'superuser' == self.current_user['type']:
            self.write(json.dumps({
                'code': 1398,
                'error': '暂不支持超级用户添加企业业务数据！',
            }))
            return
        user_id = self.current_user['id']
        company_id = self.current_user['company_id']
        if -1 == company_id:
            self.write(json.dumps({
                'code': 1444,
                'error': '未找到用户所属的公司信息！',
            }))
            return
        payload = self.get_payload()
        try:
            sc = session()
            out_data = {}
            for _date, values in payload.items():
                out_data[_date] = {}
                for column_id, value in values.items():
                    column_id = int(column_id)
                    if value:
                        data = sc.query(
                            PredictCustomColumnValues
                        ).filter_by(
                            column_id=column_id,
                            date=_date,
                            company_id=company_id,
                            create_user_id=user_id
                        ).first()
                        if data:
                            data.value = value
                        else:
                            data = PredictCustomColumnValues(
                                date=_date,
                                column_id=column_id,
                                value=value,
                                company_id=company_id,
                                create_user_id=user_id,
                            )
                            sc.add(data)
                    else:
                        sc.query(
                            PredictCustomColumnValues
                        ).filter_by(
                            column_id=column_id,
                            date=_date,
                            company_id=company_id,
                        ).delete()
                    out_data[_date][column_id] = value
                sc.commit()

            self.json_response({
                'code': 0,
                'data': out_data,
            })
        except Exception as e:
            sc.rollback()
            sentry.captureException()
            self.json_response({
                'code': 500,
                'error': str(e),
            })
        finally:
            sc.close()


class PredictCustomColumnValuesRowHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def delete(self, *args, **kwargs):
        self.get_current_user()
        if 'superuser' == self.current_user['type']:
            self.write(json.dumps({
                'code': 1398,
                'error': '暂不支持超级用户删除企业业务数据！',
            }))
            return
        user_id = self.current_user['id']
        company_id = self.current_user['company_id']
        if -1 == company_id:
            self.write(json.dumps({
                'code': 1444,
                'error': '未找到用户所属的公司信息！',
            }))
            return

        try:
            sc = session()
            sc.query(
                PredictCustomColumnValues
            ).filter_by(
                date=kwargs['id'],
                create_user_id=user_id
            ).delete()
            sc.commit()

            self.json_response({
                'code': 0,
            })
        except Exception as e:
            sc.rollback()
            sentry.captureException()
            self.json_response({
                'code': 500,
                'error': str(e),
            })
        finally:
            sc.close()


class TuringTrackDetailHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        if not self.is_hft_group():
            self.json_response({
                'code': 2000,
                'error': "no permission",
            })
            return False

        category = int(self.get_argument('type', 1))
        if category not in [1, 2]:
            self.json_response({
                'code': 2200,
                'error': 'track type not supported',
            })
            return False

        trade_date = self.get_argument('trade_date', None)
        account = self.get_argument('account', None)
        if account:
            account_list = [account]
        else:
            account_list = None
        product = self.get_argument('product', None)

        desc = self.get_argument('desc', None)
        if not account and desc:
            try:
                sc = session()
                turing_live_accounts = sc.query(TuringLiveAccounts.name).filter(
                    TuringLiveAccounts.description.like("%" + str(desc) + "%"),
                )
                account_list = [r.name for r in turing_live_accounts if '_' not in r.name]
            except Exception as e:
                logger.error(e)
                sentry.captureException()
                self.json_response({
                    'code': 2201,
                    'error': 'live-account not found'
                })
                return False
            finally:
                sc.close()

        try:
            cache_key = 'turingtrack_pnl_%s_%s_%s_%s' % (
                category if category else '', trade_date if trade_date else '', account_list if account_list else '',
                product if product else '')
            data = get_cache(cache_key)
            if data:
                self.json_response({
                    'code': 0,
                    'data': data,
                })
                return

            from service.statistic.track import TuringTrackService
            ts = TuringTrackService()
            yield ts.async_get_live_quote()
            data = ts.calc_pnl_and_vol(category=category, trade_date=trade_date, account_list=account_list,
                                       product=product)
            if trade_date:
                data['is_loop'] = False
            else:
                data['is_loop'] = True
            self.json_response({
                'code': 0,
                'data': data
            })

            # set_cache(cache_key, data, 60)
            return True
        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 2201,
                'error': 'get track data error'
            })
            return False


class TuringTrackRejectOrderHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        if not self.is_hft_group():
            self.json_response({
                'code': 2000,
                'error': "no permission",
            })
            return False

        account = self.get_argument('account', None)
        try:
            from service.statistic.track import TuringTrackService
            ts = TuringTrackService()
            data = ts.get_reject_order(account=account)
            self.json_response({
                'code': 0,
                'data': data
            })
            return True
        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 2202,
                'error': 'get reject order error'
            })
            return False


class TuringLiveAccountsHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        data = {}
        self.get_current_user()
        if not self.current_user:
            return False

        if not self.is_hft_group():
            self.json_response({
                'code': 2000,
                'error': "no permission",
            })
            return False

        try:
            sc = session()
            accounts_info = sc.query(TuringLiveAccounts).all()
            for r in accounts_info:
                data[r.name] = r.description
            self.json_response({
                'code': 0,
                'data': data
            })
            return True
        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 2203,
                'error': 'get live-account data error'
            })
            return False
        finally:
            sc.close()

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        if not self.is_hft_group():
            self.json_response({
                'code': 2000,
                'error': "no permission",
            })
            return False

        user_id = self.current_user['id']

        payload = self.get_payload()
        account = payload.get('account', None)
        if not account:
            return False
        description = payload.get('description', '')

        try:
            sc = session()
            accounts_info = sc.query(TuringLiveAccounts).filter_by(
                name=account,
            ).first()
            if accounts_info:
                accounts_info.description = description
            else:
                accounts_info = TuringLiveAccounts(
                    name=account,
                    description=description,
                    create_user_id=user_id,
                )
                sc.add(accounts_info)
            sc.commit()
            self.json_response({
                'code': 0,
                'data': {
                    account: description,
                },
            })
            return True
        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 2204,
                'error': 'update live-account data error'
            })
            return False
        finally:
            sc.close()


class TuringCtpAccountsHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        data = {}
        self.get_current_user()
        if not self.current_user:
            return False

        if not self.is_hft_group():
            self.json_response({
                'code': 2000,
                'error': "no permission",
            })
            return False

        try:
            sc = session()
            accounts_info = sc.query(TuringCtpAccounts).all()
            for r in accounts_info:
                data[r.name] = r.description
            self.json_response({
                'code': 0,
                'data': data
            })
            return True
        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 2203,
                'error': 'get live-account data error'
            })
            return False
        finally:
            sc.close()

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        if not self.is_hft_group():
            self.json_response({
                'code': 2000,
                'error': "no permission",
            })
            return False

        user_id = self.current_user['id']

        payload = self.get_payload()
        account = payload.get('account', None)
        if not account:
            return False
        description = payload.get('description', '')

        try:
            sc = session()
            accounts_info = sc.query(TuringCtpAccounts).filter_by(
                name=account,
            ).first()
            if accounts_info:
                accounts_info.description = description
            else:
                accounts_info = TuringCtpAccounts(
                    name=account,
                    description=description,
                    create_user_id=user_id,
                )
                sc.add(accounts_info)
            sc.commit()
            self.json_response({
                'code': 0,
                'data': {
                    account: description,
                },
            })
            return True
        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 2204,
                'error': 'update live-account data error'
            })
            return False
        finally:
            sc.close()


class TuringTrackOrderDelayHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        data = {}
        self.get_current_user()
        if not self.current_user:
            return False

        if not self.is_hft_group():
            self.json_response({
                'code': 2000,
                'error': "no permission",
            })
            return False

        trade_date = self.get_argument('trade_date', None)
        host = self.get_argument('host', None)
        if not host:
            return False

        try:
            sc = session()
            turing_server = sc.query(TuringServers).filter(
                TuringServers.ip == host,
            ).first()
            if not turing_server:
                self.json_response({
                    'code': 2205,
                    'error': 'server config not found',
                })
                return False
            cpu_freq = turing_server.cpu_freq
            broker_delay_threshold = turing_server.broker_delay_threshold
            if not cpu_freq or not broker_delay_threshold:
                self.json_response({
                    'code': 2205,
                    'error': 'please set cpu_freq and max_delay first',
                })
                return False

            from service.statistic.track import TuringTrackService
            ts = TuringTrackService()
            data = ts.calc_order_delay(host, cpu_freq, broker_delay_threshold, trade_date=trade_date)

            self.json_response({
                'code': 0,
                'data': data
            })
            return True
        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 2205,
                'error': 'get track data error',
            })
            return False
        finally:
            sc.close()


class TuringServerDelayHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        data = []
        self.get_current_user()
        if not self.current_user:
            return False

        if not self.is_hft_group():
            self.json_response({
                'code': 2000,
                'error': "no permission",
            })
            return False

        try:
            sc = session()
            turing_servers = sc.query(TuringServers).filter(
                TuringServers.cpu_freq.isnot(None),
                TuringServers.broker_delay_threshold.isnot(None),
            )
            for r in turing_servers:
                data.append({
                    'id': r.id,
                    'host': r.ip,
                    'cpu_freq': r.cpu_freq,
                    'max_delay': r.broker_delay_threshold,
                })
            self.json_response({
                'code': 0,
                'data': data
            })
            return True
        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 2206,
                'error': 'get server config error'
            })
            return False
        finally:
            sc.close()

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        if not self.is_hft_group():
            self.json_response({
                'code': 2000,
                'error': "no permission",
            })
            return False

        payload = self.get_payload()
        host = payload.get('host', None)
        cpu_freq = payload.get('cpu_freq', None)
        broker_delay_threshold = payload.get('max_delay', None)
        if not host or not cpu_freq or not broker_delay_threshold:
            return False

        try:
            sc = session()
            turing_server = sc.query(TuringServers).filter(
                TuringServers.ip == host,
            ).first()
            if not turing_server:
                return False

            turing_server.cpu_freq = cpu_freq
            turing_server.broker_delay_threshold = broker_delay_threshold
            sc.commit()

            self.json_response({
                'code': 0,
                'data': {
                    'id': turing_server.id,
                    'host': turing_server.ip,
                    'cpu_freq': turing_server.cpu_freq,
                    'max_delay': turing_server.broker_delay_threshold,
                },
            })
            return True
        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 2207,
                'error': 'set server config error'
            })
            return False
        finally:
            sc.close()


class TuringAllLiveAccountsHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        data = []
        self.get_current_user()
        if not self.current_user:
            return False

        try:
            sc = session()
            all_accounts = sc.query(TuringLiveAccounts).filter()
            for r in all_accounts:
                data.append({
                    'name': r.name,
                    'exchange': r.exchange,
                })
            self.json_response({
                'code': 0,
                'data': data
            })
            return True
        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 2209,
                'error': 'get live accounts error'
            })
            return False
        finally:
            sc.close()

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        user_id = self.current_user['id']

        payload = self.get_payload()
        account = payload.get('name', None)
        exchange = payload.get('exchange', None)
        if account is None or exchange is None:
            return False

        try:
            sc = session()
            accounts_info = sc.query(TuringLiveAccounts).filter(
                TuringLiveAccounts.name == account,
            ).first()
            if accounts_info:
                accounts_info.exchange = exchange
            else:
                accounts_info = TuringLiveAccounts(
                    name=account,
                    exchange=exchange,
                    create_user_id=user_id,
                )
                sc.add(accounts_info)
            sc.commit()
            self.json_response({
                'code': 0,
                'data': {
                    'name': account,
                    'exchange': exchange,
                }
            })

        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 2209,
                'error': 'set live accounts error'
            })
            return False
        finally:
            sc.close()

    @gen.coroutine
    def delete(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        account = self.get_argument('account', None)
        if account is None:
            return False

        try:
            sc = session()
            sc.query(TuringLiveAccounts).filter(
                TuringLiveAccounts.name == account,
            ).delete()
            sc.commit()
            self.json_response({
                'code': 0,
                'data': 1,
            })

        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 2209,
                'error': 'delelte live accounts error'
            })
            return False
        finally:
            sc.close()


class TuringAnalysisOrdersDelayHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        trading_date = self.get_argument('trading_date', None)
        day_night = self.get_argument('day_night', None)
        if trading_date is None or day_night is None:
            return False

        server = self.get_argument('server', None)
        account = self.get_argument('account', None)
        product = self.get_argument('product', None)

        try:
            sc = session()
            trade_logs = sc.query(
                TuringTradeLogs.server.label('server'),
                TuringTradeLogs.account.label('account'),
                TuringTradeLogs.symbol.label('symbol'),
                TuringTradeLogs.serial_no.label('serial_no'),
                TuringTradeLogs.log_type.label('log_type'),
                TuringTradeLogs.quote_trigger.label('quote_trigger'),
                TuringTradeLogs.rdtsc.label('rdtsc'),
                TuringTradeLogs.entrust_no.label('entrust_no'),
            ).filter(
                # TuringTradeLogs.vstrategy_id == 1,
                TuringTradeLogs.log_type.in_(['0', '2', '3']),
                TuringTradeLogs.serial_no != '00000000000000000000',
                TuringTradeLogs.entrust_status != 'e',
                TuringTradeLogs.trading_date == trading_date,
                TuringTradeLogs.day_night == day_night,
            )

            if server:
                trade_logs = trade_logs.filter(TuringTradeLogs.server == server)
            if account:
                trade_logs = trade_logs.filter(TuringTradeLogs.account == account)
            if product:
                trade_logs = trade_logs.filter(TuringTradeLogs.symbol.like(str(product) + "%"))

            orders = {}
            for record in trade_logs:
                key = (record.server, record.account, record.serial_no, record.symbol)
                if key not in orders:
                    orders[key] = {
                        'server': record.server,
                        'account': record.account,
                        'symbol': record.symbol,
                        'serial_no': record.serial_no,
                        'trigger': 0, 'entrust_no': 0,
                        't0': 0, 't1': 0, 't2': 0,
                    }
                if record.log_type == '0':
                    orders[key]['trigger'] = record.quote_trigger
                    orders[key]['t0'] = int(record.rdtsc)
                elif record.log_type == '2':
                    if orders[key]['t1'] == 0:
                        orders[key]['entrust_no'] = record.entrust_no
                        orders[key]['t1'] = int(record.rdtsc)
                    elif orders[key]['t1'] != 0 and record.rdtsc < orders[key]['t1']:
                        orders[key]['t1'] = int(record.rdtsc)
                elif record.log_type == '3':
                    if orders[key]['t2'] == 0:
                        orders[key]['t2'] = int(record.rdtsc)
                    elif orders[key]['t2'] != 0 and record.rdtsc < orders[key]['t2']:
                        orders[key]['t2'] = int(record.rdtsc)

            data = []
            for k, v in orders.items():
                if v['t1'] == 0:
                    continue
                if v['t2'] == 0:
                    v['t2'] = v['t0']
                data.append({
                    'server': v['server'],
                    'account': v['account'],
                    'symbol': v['symbol'],
                    'serial_no': v['serial_no'],
                    'entrust_no': v['entrust_no'],
                    'trigger': v['trigger'],
                    'broker_delay': v['t1'] - v['t0'],
                    'exchange_delay': v['t2'] - v['t0'],
                })

            self.json_response({
                'code': 0,
                'data': data
            })
            return True
        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 2208,
                'error': 'get track orders error'
            })
            return False
        finally:
            sc.close()


class TuringAnalysisRejectOrdersHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        trading_date = self.get_argument('trading_date', None)
        day_night = self.get_argument('day_night', None)
        if trading_date is None or day_night is None:
            return False

        server = self.get_argument('server', None)
        account = self.get_argument('account', None)
        product = self.get_argument('product', None)

        try:
            sc = session()
            trade_logs = sc.query(
                TuringTradeLogs.server.label('server'),
                TuringTradeLogs.account.label('account'),
                TuringTradeLogs.symbol.label('symbol'),
                TuringTradeLogs.serial_no.label('serial_no'),
                TuringTradeLogs.log_type.label('log_type'),
                TuringTradeLogs.quote_trigger.label('quote_trigger'),
                TuringTradeLogs.rdtsc.label('rdtsc'),
                TuringTradeLogs.entrust_no.label('entrust_no'),
                TuringTradeLogs.calendar_time.label('calendar_time'),
                TuringTradeLogs.calendar_microsec.label('calendar_microsec'),
            ).filter(
                # TuringTradeLogs.vstrategy_id == 1,
                TuringTradeLogs.entrust_status == 'e',
                TuringTradeLogs.trading_date == trading_date,
                TuringTradeLogs.day_night == day_night,
            )

            if server:
                trade_logs = trade_logs.filter(TuringTradeLogs.server == server)
            if account:
                trade_logs = trade_logs.filter(TuringTradeLogs.account == account)
            if product:
                trade_logs = trade_logs.filter(TuringTradeLogs.symbol.like(str(product) + "%"))

            for record in trade_logs:
                data.append({
                    'server': record.server,
                    'account': record.account,
                    'symbol': record.symbol,
                    'serial_no': record.serial_no,
                    'log_type': record.log_type,
                    'trigger': record.quote_trigger,
                    'rdtsc': record.rdtsc,
                    'entrust_no': record.entrust_no,
                    'time': '%s %s' % (record.calendar_time, record.calendar_microsec),
                })

            self.json_response({
                'code': 0,
                'data': data,
                'total': len(data),
            })
            return True
        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 2208,
                'error': 'get track orders error'
            })
            return False
        finally:
            sc.close()


class TuringAnalysisCancelOrdersHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        trading_date = self.get_argument('trading_date', None)
        day_night = self.get_argument('day_night', None)
        if trading_date is None or day_night is None:
            return False

        server = self.get_argument('server', None)
        account = self.get_argument('account', None)
        product = self.get_argument('product', None)

        try:
            sc = session()
            trade_logs = sc.query(
                TuringTradeLogs.server.label('server'),
                TuringTradeLogs.account.label('account'),
                TuringTradeLogs.symbol.label('symbol'),
                TuringTradeLogs.serial_no.label('serial_no'),
                TuringTradeLogs.log_type.label('log_type'),
                TuringTradeLogs.quote_trigger.label('quote_trigger'),
                TuringTradeLogs.rdtsc.label('rdtsc'),
                TuringTradeLogs.entrust_no.label('entrust_no'),
                TuringTradeLogs.calendar_time.label('calendar_time'),
                TuringTradeLogs.calendar_microsec.label('calendar_microsec'),
            ).filter(
                # TuringTradeLogs.vstrategy_id == 1,
                TuringTradeLogs.entrust_status == 'd',
                TuringTradeLogs.trading_date == trading_date,
                TuringTradeLogs.day_night == day_night,
            )

            if server:
                trade_logs = trade_logs.filter(TuringTradeLogs.server == server)
            if account:
                trade_logs = trade_logs.filter(TuringTradeLogs.account == account)
            if product:
                trade_logs = trade_logs.filter(TuringTradeLogs.symbol.like(str(product) + "%"))

            for record in trade_logs:
                data.append({
                    'server': record.server,
                    'account': record.account,
                    'symbol': record.symbol,
                    'serial_no': record.serial_no,
                    'log_type': record.log_type,
                    'trigger': record.quote_trigger,
                    'rdtsc': record.rdtsc,
                    'entrust_no': record.entrust_no,
                    'time': '%s %s' % (record.calendar_time, record.calendar_microsec),
                })

            self.json_response({
                'code': 0,
                'data': data,
                'total': len(data),
            })
            return True
        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 2208,
                'error': 'get track orders error'
            })
            return False
        finally:
            sc.close()


class ParameterHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        strategy_id = self.get_argument('sid', None)

        ret_d = {'code': 0, 'data': {}, 'error': ''}

        sc = session()
        strategy_para = sc.query(StrategyParameter).filter(StrategyParameter.strategy_id == strategy_id).first()
        if strategy_para:
            ret_d['data'] = strategy_para.para_list

        self.json_response(ret_d)

        sc.commit()
        sc.close()

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        payload = json.loads(self.get_argument('paras', '{}'))

        strategy_id = payload.get('sid')

        sc = session()
        strategy = sc.query(Strategy).filter(
            Strategy.id == strategy_id,
            Strategy.r_create_user_id == self.current_user['id'],
        ).first()
        if not strategy:
            self.json_response({
                'code': 1013,
                'error': 'can not find strategy id=%s and created by %s' % (strategy_id, self.current_user['username'])
            })
            sc.close()
            return

        # process input parameters.
        paras_d = payload.get('today_paras')
        strategy_para = sc.query(StrategyParameter).filter(StrategyParameter.strategy_id == strategy_id).first()
        if strategy_para:

            input_keys_l = list(paras_d.keys())
            standard_keys_l = copy.deepcopy(strategy_para.para_structure)

            input_keys_l.sort()
            standard_keys_l.sort()

            if not (input_keys_l == standard_keys_l):
                self.json_response({
                    'code': 1013,
                    'error': 'parameter structure invalid'
                })
                sc.close()
                return

        para_structure_l = list(paras_d.keys())

        kdb = KdbQuery()
        begin_date = datetime.datetime.now()
        begin_date_str = begin_date.strftime('%Y%m%d')
        end_date = begin_date + datetime.timedelta(days=15)
        days = kdb.get_trading_days(begin_date_str, end_date.strftime('%Y%m%d'))
        now_hour = begin_date.hour
        if days[0] == begin_date_str and (now_hour >= 15):
            next_trading_day_int = int(days[1])
        else:
            next_trading_day_int = int(days[0])

        today_para = sc.query(StrategyParameter).filter(StrategyParameter.strategy_id == strategy_id,
                                                        StrategyParameter.date == next_trading_day_int).first()
        if today_para:
            today_para.para_structure = para_structure_l
            today_para.para_list = paras_d
        else:
            obj_para = StrategyParameter();
            obj_para.strategy_id = strategy_id
            obj_para.date = next_trading_day_int
            obj_para.para_structure = para_structure_l
            obj_para.para_list = paras_d
            sc.add(obj_para)

        sc.commit()

        try:
            upload_file = self.request.files['para_file'][0]
            file_content = upload_file['body'].decode('utf-8')

        except Exception as e:
            # no files uploaded is okay.
            self.json_response({'code': 0, 'data': {}})
            return False

        # Save file for debuging purpose.
        tmp_file = '%s-upload-parameter.csv' % (strategy_id)
        f = open(tmp_file, 'w')
        f.write(file_content)
        f.close()

        generate_path = os.path.join(config.media,
                                     'strategy_upload/output/%s/%s/' % (self.current_user['username'], strategy_id))

        # clear dir before generate files into it.
        if os.path.exists(generate_path):
            shutil.rmtree(generate_path)
        os.makedirs(generate_path)

        to_add_object_l = []
        with open(tmp_file) as fx:
            for line in fx:

                line = line.rstrip('\r\n ')

                if not line:
                    continue

                # Save parameters to files in a each day a file manner.
                para_l = line.split('|')
                if not para_l:
                    self.json_response({
                        'code': 1019,
                        'data': 'uploaded file invalid',
                    })
                    sc.close()
                    return False

                date = para_l[0]
                del para_l[0]

                today_content = ','.join(para_l)
                generate_file = os.path.join(generate_path, 'ev_output_%s_%s.csv' % (date, strategy_id))

                logger.info('generate_file:%s' % generate_file)

                f = open(generate_file, 'w')
                f.write(today_content)
                f.close()

                if len(para_l) != len(para_structure_l):
                    logger.error('file:%s para len %d != standard para len:%d ' %
                                 (generate_file, len(para_l), len(para_structure_l)))
                    continue

                paras_d = {}
                for idx, key in enumerate(para_structure_l):
                    paras_d[key] = para_l[idx]

                obj_para = StrategyParameter();
                obj_para.strategy_id = strategy_id
                obj_para.date = int(date)
                obj_para.para_structure = para_structure_l
                obj_para.para_list = paras_d
                to_add_object_l.append(obj_para)

        if to_add_object_l:
            # clear history data first
            today_para = sc.query(StrategyParameter).filter(StrategyParameter.strategy_id == strategy_id,
                                                            StrategyParameter.date != next_trading_day_int).delete()
            sc.commit()

        for obj in to_add_object_l:
            sc.add(obj)

        sc.commit()

        os.remove(tmp_file)

        self.json_response({
            'code': 0,
            'data': {},
        })
        sc.close()
        return


class TuringCtpAccountInfoHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        res = []

        sc = session()

        kdb = KdbQuery()
        trading_date = kdb.get_trading_date(hour=21)
        trading_date = parse(trading_date)
        trading_date_str = trading_date.strftime('%Y.%m.%d')

        pre_trading_date = kdb.get_nebor_trading_date(trading_date_str)['prev']
        pre_trading_date = parse(pre_trading_date)
        pre_trading_date_str = pre_trading_date.strftime('%Y.%m.%d')

        d = sc.query(DIMPreConfs).filter().order_by(DIMPreConfs.id.desc()).first()
        if not d:
            self.write(json.dumps({
                'code': 404,
                'error': 'DIM pre-config error',
            }))
            return
        uid = d.uid
        lines = sc.query(DIMPreConfs).filter(
            DIMPreConfs.uid == uid,
        )
        dim_cfg = {}
        product_set = {}
        lock_max_vol = {}
        for line in lines:
            account = line.account
            product = line.product
            rank = line.symbol
            max_pos = line.max_vol
            exchange = line.exchange
            day_night = line.day_night
            if exchange.lower() == 'czce':
                long_product = 'zz%s' % product.lower()
            elif exchange.lower() == 'dce':
                long_product = 'dl%s' % product.lower()
            elif exchange.lower() == 'shfe':
                long_product = 'sh%s' % product.lower()
            else:
                long_product = product.lower()
            if (long_product, rank) not in product_set:
                logger.info("CtpAccountInfo, product:%s, rank:%s" % (long_product, rank))
                if rank in ['R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R8', 'R9', 'R10',
                            'R11', 'R12', 'R13', 'R14', 'R15', 'R16', 'R17', 'R18', 'R19', 'R20']:
                    if long_product.upper() in ['CP50ETF', 'CP300ZJ', 'CP300SH', 'CP300SZ']:
                        symbol = kdb.get_opmain_code(trading_date_str, long_product, rank=int(rank.replace('R', '')))
                    elif long_product.upper() in ['CB', 'CBSZ', 'CBSH']:
                        symbol = kdb.get_cb_code(trading_date_str, long_product, rank=int(rank.replace('R', '')))
                    else:
                        symbol = kdb.get_main_code2(trading_date_str, long_product, rank=int(rank.replace('R', '')))
                else:
                    symbol = rank
                product_set[(long_product, rank)] = symbol
            else:
                symbol = product_set[(long_product, rank)]

            if line.single_max_vol > 0:
                if (account, symbol) not in lock_max_vol:
                    if day_night == 0:
                        lock_max_vol[(account, symbol)] = {
                            'day_max_pos': line.single_max_vol,
                            'night_max_pos': 0,
                        }
                    else:
                        lock_max_vol[(account, symbol)] = {
                            'day_max_pos': 0,
                            'night_max_pos': line.single_max_vol,
                        }
                else:
                    if day_night == 0:
                        lock_max_vol[(account, symbol)]['day_max_pos'] += line.single_max_vol
                    else:
                        lock_max_vol[(account, symbol)]['night_max_pos'] += line.single_max_vol

            if account not in dim_cfg:
                if day_night == 0:
                    dim_cfg[account] = [{
                        'symbol': symbol,
                        'exchange': exchange,
                        'day_max_pos': max_pos,
                        'night_max_pos': 0,
                        'max_pos': 0,
                    }]
                else:
                    dim_cfg[account] = [{
                        'symbol': symbol,
                        'exchange': exchange,
                        'day_max_pos': 0,
                        'night_max_pos': max_pos,
                        'max_pos': 0,
                    }]
            else:
                for _s in dim_cfg[account]:
                    if symbol == _s['symbol']:
                        if day_night == 0:
                            _s['day_max_pos'] += max_pos
                            break
                        else:
                            _s['night_max_pos'] += max_pos
                            break
                else:
                    if day_night == 0:
                        dim_cfg[account].append({
                            'symbol': symbol,
                            'exchange': exchange,
                            'day_max_pos': max_pos,
                            'night_max_pos': 0,
                            'max_pos': 0,
                        })
                    else:
                        dim_cfg[account].append({
                            'symbol': symbol,
                            'exchange': exchange,
                            'day_max_pos': 0,
                            'night_max_pos': max_pos,
                            'max_pos': 0,
                        })

        for account, s_item in dim_cfg.items():
            for _s in s_item:
                if (account, _s['symbol']) not in lock_max_vol:
                    _s['max_pos'] = max([_s['day_max_pos'], _s['night_max_pos']])
                else:
                    _s['max_pos'] = max([lock_max_vol[(account, _s['symbol'])]['day_max_pos'],
                                         lock_max_vol[(account, _s['symbol'])]['night_max_pos']])

        symbol_set = {}
        for sym in product_set.values():
            s_margin = sc.query(
                SymbolMargin.long_margin_ratio.label('long_margin_ratio'),
                SymbolMargin.short_margin_ratio.label('short_margin_ratio'),
            ).filter(
                SymbolMargin.symbol == sym
            ).order_by(SymbolMargin.timestamp.desc()).first()
            if not s_margin:
                continue
            if sym not in symbol_set:
                trade_unit = kdb.get_symbol_trade_unit(sym)
                pre_settle_price = kdb.get_symbol_sellteprice(pre_trading_date_str, sym)
                symbol_set[sym] = {
                    'long_margin_ratio': float(s_margin.long_margin_ratio),
                    'short_margin_ratio': float(s_margin.short_margin_ratio),
                    'trade_unit': trade_unit,
                    'pre_settle_price': pre_settle_price,
                }

        other_name = {}
        ctp_accounts = sc.query(TuringCtpAccounts).filter()
        for a in ctp_accounts:
            if a.other_name:
                other_name[a.name] = a.other_name

        live_users = [
            a.name for a in
            sc.query(TuringLiveAccounts.name).filter()
            if '_' not in a.name
        ]
        # live_users.append('85011366')
        # live_users.append('910086')
        # live_users.append('85011682')

        user_list = []
        users = sc.query(UserInfo.user_id).filter()
        for a in users:
            user_id = str(a.user_id)
            if user_id not in live_users and \
                    other_name.get(user_id, '') not in live_users and \
                    str.zfill(user_id, 12) not in live_users:
                continue
            user_list.append(user_id)

        for user_id in user_list:
            obj = sc.query(AccountInfo).filter(
                AccountInfo.user_id == user_id,
            ).order_by(
                AccountInfo.timestamp.desc()
            ).first()
            if not obj:
                data = {
                    'user_id': user_id,
                    'detail': []
                }

            else:
                data = obj.to_dict()
                if data.get('dynamic_interest') < 1000:
                    continue

                data['detail'] = []
                if user_id in dim_cfg or other_name.get(user_id, '') in dim_cfg:
                    if user_id in dim_cfg:
                        user_dim_cfg = dim_cfg[user_id]
                    elif other_name.get(user_id, '') in dim_cfg:
                        user_dim_cfg = dim_cfg[other_name.get(user_id, '')]
                    for v in user_dim_cfg:
                        symbol = v['symbol']
                        if symbol in symbol_set:
                            pre_settle_price = symbol_set[symbol].get('pre_settle_price')
                            trade_unit = symbol_set[symbol].get('trade_unit')
                            long_margin_ratio = symbol_set[symbol].get('long_margin_ratio')
                            short_margin_ratio = symbol_set[symbol].get('short_margin_ratio')
                        else:
                            pre_settle_price = 0
                            trade_unit = 0
                            long_margin_ratio = 0
                            short_margin_ratio = 0
                        max_pos = v['max_pos']
                        exchange = v['exchange']
                        if exchange == 'dce':
                            side = "双边"
                            margin = pre_settle_price * max_pos * long_margin_ratio * trade_unit + \
                                     pre_settle_price * max_pos * short_margin_ratio * trade_unit
                        else:
                            side = "单边"
                            margin = max([
                                pre_settle_price * max_pos * long_margin_ratio * trade_unit,
                                pre_settle_price * max_pos * short_margin_ratio * trade_unit,
                            ])
                        detail = {
                            'symbol': symbol,
                            'max_pos': max_pos,
                            'margin': round(float(margin), 2),
                            'side': side,
                            'long_pos': 0,
                            'short_pos': 0,
                        }
                        data['detail'].append(detail)

                    last_ctp_pos = sc.query(CtpAccountPos).filter(
                        CtpAccountPos.user_id == user_id,
                    ).order_by(
                        CtpAccountPos.timestamp.desc()
                    ).first()
                    if last_ctp_pos:
                        pos_records = sc.query(CtpAccountPos).filter(
                            CtpAccountPos.timestamp == last_ctp_pos.timestamp,
                            CtpAccountPos.user_id == user_id,
                        )
                        symb_pos_dict = {}
                        for p in pos_records:
                            symb_pos_dict.setdefault(p.symbol, {'long_pos': 0, 'short_pos': 0})
                            if p.type == 0:
                                symb_pos_dict[p.symbol]['short_pos'] = p.position
                            else:
                                symb_pos_dict[p.symbol]['long_pos'] = p.position

                        for k, v in symb_pos_dict.items():
                            for d in data['detail']:
                                if d['symbol'] == k:
                                    d['long_pos'] = v['long_pos']
                                    d['short_pos'] = v['short_pos']
                                    break
                            else:
                                data['detail'].append({
                                    'symbol': k,
                                    'max_pos': '',
                                    'margin': '',
                                    'side': '',
                                    'long_pos': v['long_pos'],
                                    'short_pos': v['short_pos'],
                                    'color': 'red',
                                })

                data['curr_margin'] = '%.2f' % data['curr_margin']
                data['available'] = '%.2f' % data['available']
                data['commission'] = '%.2f' % data['commission']
                data['close_profit'] = '%.2f' % data['close_profit']
                data['position_profit'] = '%.2f' % data['position_profit']
                data['pre_balance'] = '%.2f' % data['pre_balance']
                data['dynamic_interest'] = '%.2f' % data['dynamic_interest']
                data['risk'] = '%.4f' % data['risk']

            res.append(data)
        sc.close()

        self.write(json.dumps({
            'code': 0,
            'data': res,
        }))


class TuringTrackAutoCacheHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        try:
            cache_key_1 = 'turingtrack_pnl_1___'
            cache_key_2 = 'turingtrack_pnl_2___'

            from service.statistic.track import TuringTrackService
            ts = TuringTrackService()
            yield ts.async_get_live_quote()

            data = ts.calc_pnl_and_vol(category=1)
            data['is_loop'] = True
            set_cache(cache_key_1, data, 30)

            data = ts.calc_pnl_and_vol(category=2)
            data['is_loop'] = True
            set_cache(cache_key_2, data, 30)

            self.json_response({
                'code': 0,
            })
            return True
        except Exception as e:
            logger.error(e)
            sentry.captureException()
            self.json_response({
                'code': 2201,
                'error': 'get track data error'
            })
            return False


class StrategyBackTestPositionHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        s_id = int(kwargs['id'])
        now_time = datetime.datetime.now()
        start_date = parse(self.get_argument('start_date', now_time.strftime('%Y0101'))).strftime('%Y%m%d')
        end_date = parse(self.get_argument('end_date', now_time.strftime('%Y%m%d'))).strftime('%Y%m%d')

        sc = session()

        columns = [
            'trading_date', 'symbol', 'long_volume', 'long_price', 'short_volume', 'short_price'
        ]
        values = []

        daily_position = sc.query(
            StrategyResultDetail.trading_date.label('trading_date'),
            StrategyResultDetail.symbol.label('symbol'),
            StrategyResultDetail.long_volume.label('long_volume'),
            StrategyResultDetail.long_price.label('long_price'),
            StrategyResultDetail.short_volume.label('short_volume'),
            StrategyResultDetail.short_price.label('short_price'),
        ).filter(
            StrategyResultDetail.strategy_id == s_id,
            StrategyResultDetail.trading_date >= start_date,
            StrategyResultDetail.trading_date < end_date,
            StrategyResultDetail.day_night == 0,
            StrategyResultDetail.config_id == 0,
            or_(
                StrategyResultDetail.long_volume > 0,
                StrategyResultDetail.short_volume > 0,
            )
        )
        for pos in daily_position:
            values.append([
                pos.trading_date.strftime('%Y%m%d'),
                pos.symbol,
                pos.long_volume,
                pos.long_price,
                pos.short_volume,
                pos.short_price,
            ])
        sc.close()

        self.json_response({
            'code': 0,
            'data': {
                'columns': columns,
                'values': values,
            },
        })
        return True


class BackTestEvDataDepHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        keys = [
            'AShareEODDerivativeIndicator',
            'AShareDescription',
            'AShareST',
            'AShareCapitalization',
            'AIndexEODPrices',
            'AShareEODPrices',
            'AShareTTMHis',
            'AIndexFreeWeight',
            'AIndexFreeCloseWeight',
            'AShareBalanceSheet',
            'AShareIncome',
            'AShareConsensusData',
            'IndustrySWS01',
            'EquityDBEqutyDepth',
            'EquityDBEqutyIndex',
            'EquityDBEqutyDepthAll',
            'EquityDBOrder',
            'EquityDBOrderQueue',
            'EquityDBTransaction',
            'MinuteBarDBChinaAShare',
            'APICheck',
            'APICheck',
            'MarketDta_ALL',
            'MarketDta_Day_ALL',
            'MarketDta_Day_Foreign',
            'MarketDta_Day_Futures',
            'MarketDta_Day_Option',
            'MarketDta_Day_Stock',
            'MarketDta_Night_ALL',
            'MarketDta_Night_Foreign',
            'MarketDta_Night_Futures',
            'StockAnnInfo02',
            'StockAnnInfo22',
            'StockEOD'
        ]
        data = [
            {
                'name': k,
                'value': k,
            } for k in keys
        ]
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StockSmartExecutionHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return

        stock_smart_executions = list()
        with session_context() as sc:
            records = sc.query(StockSmartExecutionVersion).filter(
                StockSmartExecutionVersion.valid == True
            ).order_by(StockSmartExecutionVersion.id.desc()).all()
            stock_smart_executions.extend([r.dict() for r in records])

        data = {
            'stock_smart_executions': stock_smart_executions,
            'default_smart_execution': 'vwap_MFv29'
        }

        self.json_response({
            'code': APIResponseCode.OK.value,
            'data': data
        })

    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return

        payload = self.get_payload()
        action = payload.get('action', '')
        # strategy_id = payload.get('strategy_id', 0)
        # name = payload.get('name', '')
        # value = payload.get('value', '')
        # description = payload.get('description', '')
        rid = payload.get('id', 0)
        valid = payload.get('valid', True)

        try:
            with session_context() as sc:
                # if action == 'create':
                #     record = StockSmartExecutionVersion(
                #         strategy_id=strategy_id,
                #         name=name,
                #         value=value,
                #         description=description
                #     )
                #     sc.add(record)
                if action == 'modify_valid':
                    record = sc.query(StockSmartExecutionVersion).filter(
                        StockSmartExecutionVersion.id == rid
                    ).first()
                    if record:
                        record.valid = valid
                elif action == 'publish':
                    StockSmartExecutionVersion.publish(exe_version_id=rid)
                else:
                    self.json_response({
                        'code': APIResponseCode.DefaultError.value,
                        'error': 'action: {action} not support'.format(action=action)
                    })
                    return
        except Exception as e:
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'error': str(e)
            })
            return

        self.json_response({
            'code': APIResponseCode.OK.value,
            'data': 'action: {action} success'.format(action=action)
        })


class TradeModelHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return

        trade_models = list()
        with session_context() as sc:
            records = sc.query(TradeModel).filter(
                TradeModel.valid == True
            ).order_by(TradeModel.id.desc()).all()
            trade_models.extend([r.dict() for r in records])

        self.json_response({
            'code': APIResponseCode.OK.value,
            'data': trade_models
        })

    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return

        payload = self.get_payload()
        action = payload.get('action', '')
        name = payload.get('name', '')
        value = payload.get('value', '')
        description = payload.get('description', '')
        rid = payload.get('id', 0)
        valid = payload.get('valid', True)

        try:
            with session_context() as sc:
                if action == 'create':
                    record = TradeModel(
                        name=name,
                        value=value,
                        description=description
                    )
                    sc.add(record)
                elif action == 'modify_valid':
                    record = sc.query(TradeModel).filter(
                        TradeModel.id == rid
                    ).first()
                    if record:
                        record.valid = valid
                else:
                    self.json_response({
                        'code': APIResponseCode.DefaultError.value,
                        'error': 'action: {action} not support'.format(action=action)
                    })
                    return
        except Exception as e:
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'error': str(e)
            })
            return

        self.json_response({
            'code': APIResponseCode.OK.value,
            'data': 'action: {action} success'.format(action=action)
        })


class TradeModelStockSmartExecutionRelationHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return

        mode = self.get_argument('mode', '')
        if not mode:
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'error': 'mode: {mode} not support'.format(mode=mode)
            })
            return

        relation_info = dict()
        with session_context() as sc:
            trade_models = sc.query(TradeModel).filter(
                TradeModel.valid == True
            ).all()
            trade_model_dict = {r.id: r.dict() for r in trade_models}

            stock_smart_executions = sc.query(StockSmartExecutionVersion).filter(
                StockSmartExecutionVersion.valid == True
            ).all()
            stock_smart_execution_dict = {r.id: r.dict() for r in stock_smart_executions}

            relations = sc.query(TradeModelStockSmartExecutionRelation).filter(
                TradeModelStockSmartExecutionRelation.trade_model_id.in_(trade_model_dict.keys())
            ).all()

            if mode == 'name_only':
                for r in relations:
                    trade_model_name = trade_model_dict[r.trade_model_id]['name']
                    relation_info.setdefault(trade_model_name, list())
                    stock_smart_execution_name = stock_smart_execution_dict.get(
                        r.stock_smart_execution_id, {}).get('name', '')
                    if stock_smart_execution_name:
                        relation_info[trade_model_name].append(stock_smart_execution_name)
            elif mode == 'full':
                for r in relations:
                    trade_model_info = trade_model_dict[r.trade_model_id]
                    trade_model_name = trade_model_info['name']
                    relation_info.setdefault(trade_model_name, list())
                    stock_smart_execution_info = stock_smart_execution_dict.get(r.stock_smart_execution_id, {})
                    if stock_smart_execution_info:
                        relation_info[trade_model_name].append({
                            'trade_model_info': trade_model_info,
                            'stock_smart_execution_info': stock_smart_execution_info
                        })
            else:
                self.json_response({
                    'code': APIResponseCode.DefaultError.value,
                    'error': 'mode: {mode} not support'.format(mode=mode)
                })
                return

        self.json_response({
            'code': APIResponseCode.OK.value,
            'data': relation_info
        })

    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return

        payload = self.get_payload()
        trade_model_id = payload.get('trade_model_id', 0)
        stock_smart_execution_ids = payload.get('stock_smart_execution_ids', None)

        if trade_model_id <= 0 or stock_smart_execution_ids is None:
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'error': 'trade_model_id must > 0 and stock_smart_execution_ids must exist'
            })
            return

        with session_context() as sc:
            trade_model = sc.query(TradeModel).filter(
                TradeModel.id == trade_model_id,
                TradeModel.valid == True
            ).first()
            stock_smart_execution = sc.query(StockSmartExecutionVersion).filter(
                StockSmartExecutionVersion.id.in_(stock_smart_execution_ids),
                StockSmartExecutionVersion.valid == True
            ).all()
            if not trade_model or len(stock_smart_execution) != len(stock_smart_execution_ids):
                self.json_response({
                    'code': APIResponseCode.DefaultError.value,
                    'error': 'trade_model and stock_smart_execution must valid'
                })
                return

            records = sc.query(TradeModelStockSmartExecutionRelation).filter(
                TradeModelStockSmartExecutionRelation.trade_model_id == trade_model_id,
            ).all()

            exists_smart_execution_ids = [r.stock_smart_execution_id for r in records]

            add_ids = list(set(stock_smart_execution_ids) - set(exists_smart_execution_ids))
            remove_ids = list(set(exists_smart_execution_ids) - set(stock_smart_execution_ids))

            for id in add_ids:
                record = TradeModelStockSmartExecutionRelation(
                    trade_model_id=trade_model_id,
                    stock_smart_execution_id=id
                )
                sc.add(record)

            for id in remove_ids:
                sc.query(TradeModelStockSmartExecutionRelation).filter(
                    TradeModelStockSmartExecutionRelation.trade_model_id == trade_model_id,
                    TradeModelStockSmartExecutionRelation.stock_smart_execution_id == id,
                ).delete(synchronize_session=False)

        self.json_response({
            'code': APIResponseCode.OK.value,
            'data': 'success'
        })

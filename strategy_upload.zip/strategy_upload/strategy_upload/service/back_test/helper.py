from db import session_context
# from service.stock_factor.models import T0Subscriber
from models.strategy import VsT0Relation


def get_merge_vs_share_resp_info(merge_vs_id):
    """
    get share resp info from merge vs id
    :param merge_vs_id: int, vstrategy id
    :return:
    """
    with session_context() as sc:
        sql = """select distinct vstrategy_id from pre_strategy_confs where merge_vstrategy_id={merge_vs_id}""".format(
            merge_vs_id=merge_vs_id)
        vs_ids = [r[0] for r in sc.execute(sql)]
        # records = sc.query(T0Subscriber).filter(
        #     T0Subscriber.t0_vs_id.in_(vs_ids),
        #     T0Subscriber.share_resp == True
        # ).all()
        # info = {r.t0_vs_id: r.alpha_vs_id for r in records}

        records = sc.query(VsT0Relation).filter(
            VsT0Relation.vs_id.in_(vs_ids),
            VsT0Relation.share_resp == True,
            VsT0Relation.deleted == False
        ).all()
        info = {r.vs_id: r.link_vs_id for r in records}

        return info


def get_linked_merge_vs_deploy_ip(vs_id):
    """
    get deploy ip of merge vs linked with specific vs
    :param vs_id: int, vstrategy id
    :return:
    """
    deploy_ip = ""
    with session_context() as sc:
        sql = """select server_id, tcp_conf from pre_strategy_confs where vstrategy_id={vs_id}""".format(vs_id=vs_id)
        cursor = sc.execute(sql).fetchone()
        if cursor:
            tcp_conf = cursor['tcp_conf']
            if tcp_conf:
                tcp_conf = tcp_conf.split(",")
                if len(tcp_conf) >= 2 and tcp_conf[0] == 'client':
                    deploy_ip = tcp_conf[1]
                    vpn_mapping = {
                        '192.168.40.60': '192.168.30.60',
                        '192.168.40.61': '192.168.30.61',
                    }
                    if deploy_ip in vpn_mapping.keys():
                        deploy_ip = vpn_mapping[deploy_ip]
            else:
                sql_server = "select ip from servers where id={server_id}".format(server_id=cursor['server_id'])
                cursor_server = sc.execute(sql_server).fetchone()
                if cursor_server:
                    deploy_ip = cursor_server['ip']
    return deploy_ip


if __name__ == '__main__':
    # print(get_merge_vs_share_resp_info(merge_vs_id=2389))
    # print(get_linked_merge_vs_deploy_ip(vs_id=2699))
    # print(get_linked_merge_vs_deploy_ip(vs_id=2542))
    pass

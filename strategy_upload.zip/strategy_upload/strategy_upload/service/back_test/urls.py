# -*-coding:utf-8-*-

from service.back_test.handlers import *

urls = [
    (r"/api/v1/test", Test),
    # 查看策略配置信息及其 pnl 等指标信息，创建/编辑策略
    (r'/api/v1/strategy_upload/strategy$', StrategyHandler),
    # StrategyHandler的衍生api，仅用于修改策略名称和策略描述
    (r'/api/v1/strategy_upload/strategy/patch$', StrategyPatch),
    # 利用交易PNL信息来计算不同对冲模式后的收益
    (r'/api/v1/strategy_upload/strategy/hedge$', StrategyHedgeHandler),
    # 获取部署策略相关信息，比如策略文件，配置，依赖等
    (r'/api/v1/strategy_upload/strategy/deploy/(?P<id>\d+)$', StrategyDeployViewHandler),
    # 获取部署策略的 ev 信息
    (r'/api/v1/strategy_upload/strategy/deploy/ev/(?P<id>\d+)$', StrategyDeployEvViewHandler),
    # 策略信息查询，开始策略回测，"删除" 策略或组合
    (r'/api/v1/strategy_upload/strategy/(?P<id>\w+)$', StrategyViewHandler),
    # 用 get 方法 clone 策略
    (r'/api/v1/strategy_upload/strategy/clone/(?P<id>\w+)$', StrategyCloneHandler),
    # 查询用户策略依赖关系
    (r'/api/v1/strategy_upload/dependency$', DependencyHandler),
    # 获取策略绩效信息，如果没有数据那么会主动拉起计算
    (r'/api/v1/strategy_upload/performance/(?P<id>\d+)$', PerformanceHandler),
    # 策略列表的绩效信息
    (r'/api/v1/strategy_upload/allstrategy$', PerformanceStrategyListHandler),
    # 平台层面的策略组合，用来规划不同的产品
    (r'/api/v1/strategy_upload/group$', GroupHandler),
    # 策略参数上传接口，用 output_ev 文件方式存储
    (r'/api/v1/strategy_upload/parameter$', ParameterHandler),
    # 股票算法交易模块信息
    (r'/api/v1/strategy_upload/stock_smart_execution$', StockSmartExecutionHandler),
    # 成交模型信息
    (r'/api/v1/strategy_upload/trade_model$', TradeModelHandler),
    # 成交模型与股票算法交易模块关系
    (r'/api/v1/strategy_upload/trade_model_stock_smart_execution_relation$',
     TradeModelStockSmartExecutionRelationHandler),
    # 策略列表绩效信息
    (r'/api/v1/platform/strategies$', PerformanceStrategyListHandler),
    # 实盘策略的 overview 信息
    (r'/api/v1/platform/strategy/live_analysis$', DeployStrategyListV3Handler),
    # 策略投资组合创建与申请
    (r'/api/v1/platform/portfolio$', PortfolioHandler),
    # 获取投资组合的实盘和模拟总 PNL 信息
    (r'/api/v1/platform/portfolio-analysis', PortfolioAnalysisViewHandler),
    # 交易跟踪数据过滤，account, id_no, id
    (r'/api/v1/platform/track/filter$', TrackFilterHandler),
    # 实盘交易跟踪PNL与仓位信息
    (r'/api/v1/platform/track/detail$', TrackDetailHandler),
    # 无实现
    (r'/api/v1/platform/track/position$', TrackPositionDetailHandler),
    # 获取历史持仓数据
    (r'/api/v1/platform/track/history$', TrackHistoryPositionDetailHandler),
    # 历史某策略的所有交易记录信息
    (r'/api/v1/platform/track/detail/history$', TrackHistoryDetailHandler),
    # 获取策略列表中的 live_time
    (r'/api/v1/platform/track/strategy/live_time$', TrackStrategyLiveTimeDetailHandler),
    # (r'/api/v1/platform/strategy/logs/(?P<id>\d+)$', StrategyLogHandler),
    # (r'/api/v1/platform/strategy/deploy/dailycheck$', DailyCheckHandler),
    # 投资组合的创建与查询
    (r'/api/v1/platform/portfolios$', ResearchPortfoliosHandler),
    # 根据 id 查询，修改，删除投资组合信息，
    (r'/api/v1/platform/portfolios/(?P<id>\d+)$', ResearchPortfoliosDetailHandler),
    # 废弃 API
    (r'/api/v1/platform/deploy/error/notify/(?P<id>\d+)$', DeployErrorNotifyHandler),
    # 查询/创建虚拟策略账户信息
    (r'/api/v1/platform/vstrategy/cash$', VstrategiesCashHandler),
    # 删除虚拟策略账户信息
    (r'/api/v1/platform/vstrategy/cash/(?P<id>\d+)$$', VstrategiesCashDetailHandler),
    # 策略投资组合列表
    (r'/api/v1/platform/live-portfolios$', AllLivePortfolios),
    # 实盘投资组合操作
    (r'/api/v1/platform/live-portfolios/(?P<id>\d+)$', LivePortfolios),
    (r'/api/v1/platform/download/get_list$', DownladGetList),
    (r'/api/v1/platform/download/get_file$', DownladGetFile),
    # 获取因子或底仓数据
    (r'/api/v1/platform/factor_data$', FactorData),
    # 获取投资组合分析信息
    (r"/api/v1/platform/portfolios/portfolio_analysis/(?P<id>\d+)", PortfolioAnalysisHandler),
    # 通知结算完成/因子column添加/更新
    (r'/api/v1/platform/events$', EventHandler),
    # 检查实盘策略的 ev，资金等信息
    (r'/api/v1/platform/advance_check$', AdvanceCheck),
    # 查询 node 是 cash_manager 的策略信息
    (r'/api/v1/platform/cash_manager/strategy$', CashManagerHandler),
    # 在上面的基础上扩展了品种信息
    (r'/api/v1/platform/cash_manager/strategy/(?P<id>\w+)$', CashManagerStrategyHandler),
    # 除 cash_manager 外的策略集合
    (r'/api/v1/platform/cash_manager/managercontent$', TobemanagedStrategiesHandler),
    # 实盘策略资金管理
    (r'/api/v1/platform/cash_manager/liveconfig$', CashManagerLiveConfigHandler),
    # 无实现
    (r'/api/v1/platform/cash_manager/performance/(?P<id>\w+)$', CashManagerPerformanceHandler),
    # 无实现
    (r'/api/v1/platform/cash_manager/performance/tradelogs/(?P<id>\w+)$', CashManagerPerformanceTradelogsHandler),
    # 待上线策略查询
    (r'/api/v1/platform/semi_lives$', SemiLivesHandler),
    # 无实现
    (r'/api/v1/platform/get_strategy_list$', StrategyListHandler),
    # 查询策略提交用户
    (r'/api/v1/platform/get_strategy_author_list$', StrategyAuthorListHandler),
    # notebook 发布为网页
    (r'/api/v1/platform/publish_notebook$', PublishNotebookHandler),
    # 枚举 notebook 文件夹的 ipynb 文件
    (r'/api/v1/platform/traverse_notebook$', TraverseNotebookHandler),
    # 评论信息
    (r'/api/v1/platform/remarks$', RemarksHandler),
    # 添加主观预测
    (r'/api/v1/platform/quantamental/papertrading$', QuantamentalPaperTradingHandler),
    # 主观预测回测管理
    (r'/api/v1/platform/quantamental/backtest$', SemiQuantamentalHandler),
    # 添加主观预测
    (r'/api/v1/platform/quantamental/detail$', QuantamentalsHandler),
    # 主观预测交易的合约列表，固定的
    (r'/api/v1/platform/quantamental/products$', QuantamentalProductsHandler),
    # 主力合约的日度数据
    (r'/api/v1/platform/maincode/quote/daily$', MainCodeQuoteDailyHandler),
    # OTC 相关的公司扩展字段
    (r'/api/v1/platform/quantamental/custom_column_name', PredictCustomColumnNameHandler),
    # 删除公司扩展字段数据
    (r'/api/v1/platform/quantamental/custom_column_name/(?P<id>\d+)$', PredictCustomColumnNameIDHandler),
    # 公司扩展属性信息
    (r'/api/v1/platform/quantamental/custom_column_values', PredictCustomColumnValuesHandler),
    # 删除公司扩展属性
    (r'/api/v1/platform/quantamental/custom_column_values/(?P<id>\w+)$', PredictCustomColumnValuesRowHandler),
    # 高频turing系统的交易跟踪，仓位和 PNL 计算
    (r'/api/v1/platform/turing/track/detail$', TuringTrackDetailHandler),
    # (r'/api/v1/platform/turing/track/auto/cache$', TuringTrackAutoCacheHandler),
    # turing 拒单统计信息
    (r'/api/v1/platform/turing/track/reject_order$', TuringTrackRejectOrderHandler),
    # turing 实盘账户信息
    (r'/api/v1/platform/turing/track/accounts$', TuringLiveAccountsHandler),
    # turing 订单延迟统计
    (r'/api/v1/platform/turing/track/order_delay$', TuringTrackOrderDelayHandler),
    # turing broker 延迟统计
    (r'/api/v1/platform/turing/track/servers$', TuringServerDelayHandler),
    # turing 实盘账户的增删查
    (r'/api/v1/platform/turing/track/live_accounts$', TuringAllLiveAccountsHandler),
    # ctp 账户信息汇总展示
    (r"/api/v1/platform/turing/track/ctp/account/cash$", TuringCtpAccountInfoHandler),
    # turing ctp账户的查询和添加
    (r'/api/v1/platform/turing/track/ctp/accounts$', TuringCtpAccountsHandler),
    # 策略模拟回测仓位查询
    (r'/api/v1/platform/back_test/strategy/position/(?P<id>\d+)$', StrategyBackTestPositionHandler),
    # ev 数据生产需要依赖表名
    (r'/api/v1/platform/back_test/ev/data/dep$', BackTestEvDataDepHandler),
]

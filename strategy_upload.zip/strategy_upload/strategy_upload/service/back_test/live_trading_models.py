# -*-coding:utf-8-*-

import datetime
import itertools
from dateutil.parser import parse

from sqlalchemy import Column, func
from sqlalchemy.dialects.mysql import BIGINT, VARCHAR, DATETIME, INTEGER, DOUBLE, DATE, ENUM

from db import ModelBase, session

import consts
from kdb_query import KdbQuery


class CashLimit(ModelBase):
    __tablename__ = 'cash_limit'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vs_id = Column(INTEGER, nullable=False)
    strategy_id = Column(INTEGER, nullable=False)
    status = Column(INTEGER, nullable=False, default=1)
    remark = Column(VARCHAR(512), nullable=True, default='')
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=False)
    username = Column(VARCHAR(32), nullable=False)


class CashLimitDetail(ModelBase):
    __tablename__ = 'cash_limit_detail'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    cash_limit_id = Column(INTEGER, nullable=False)
    symbol = Column(VARCHAR(32), nullable=False)
    start_time = Column(DATETIME, nullable=False)
    end_time = Column(DATETIME, nullable=False)
    long_limit = Column(DOUBLE, nullable=False, default=1)
    short_limit = Column(DOUBLE, nullable=False, default=1)


class VsLiveParameter(ModelBase):
    __tablename__ = 'vs_live_parameter'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    username = Column(VARCHAR(32), nullable=True)
    vs_id = Column(INTEGER, nullable=False)
    strategy_id = Column(INTEGER, nullable=False)
    remark = Column(VARCHAR(512), nullable=True, default='')
    parameter0 = Column(DOUBLE, nullable=False, default=0)
    parameter1 = Column(DOUBLE, nullable=False, default=0)
    parameter2 = Column(DOUBLE, nullable=False, default=0)
    parameter3 = Column(DOUBLE, nullable=False, default=0)
    parameter4 = Column(DOUBLE, nullable=False, default=0)
    parameter5 = Column(DOUBLE, nullable=False, default=0)
    parameter6 = Column(DOUBLE, nullable=False, default=0)
    parameter7 = Column(DOUBLE, nullable=False, default=0)
    parameter8 = Column(DOUBLE, nullable=False, default=0)
    parameter9 = Column(DOUBLE, nullable=False, default=0)

    def to_dict(self):
        return {
            'create_time': self.r_create_time.strftime('%Y-%m-%d %X'),
            'creator': self.username,
            'vs_id': self.vs_id,
            'remark': self.remark or '',
            'parameter0': self.parameter0 and float(self.parameter0) or 0,
            'parameter1': self.parameter1 and float(self.parameter1) or 0,
            'parameter2': self.parameter2 and float(self.parameter2) or 0,
            'parameter3': self.parameter3 and float(self.parameter3) or 0,
            'parameter4': self.parameter4 and float(self.parameter4) or 0,
            'parameter5': self.parameter5 and float(self.parameter5) or 0,
            'parameter6': self.parameter6 and float(self.parameter6) or 0,
            'parameter7': self.parameter7 and float(self.parameter7) or 0,
            'parameter8': self.parameter8 and float(self.parameter8) or 0,
            'parameter9': self.parameter9 and float(self.parameter9) or 0,
        }


class VstrategyMarketMetric(ModelBase):
    __tablename__ = 'vs_market_metric'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    vs_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)
    strategy_id = Column(INTEGER, nullable=True)
    start_time = Column(DATETIME, nullable=False)
    end_time = Column(DATETIME, nullable=False)
    symbol = Column(VARCHAR(32), nullable=False)
    volume = Column(DOUBLE, nullable=False)
    market_volume = Column(DOUBLE, nullable=False)
    volume_percent = Column(DOUBLE, nullable=False, default=0)

    @staticmethod
    def get_vstrategy_volume_percent(vs_id):
        sc = session()
        rows = sc.query(
            VstrategyMarketMetric.trading_date.label('trading_date'),
            func.max(VstrategyMarketMetric.volume_percent).label('volume_percent'),
        ).filter(
            VstrategyMarketMetric.vs_id == vs_id
        ).group_by(VstrategyMarketMetric.trading_date)

        data = [
            {
                'trading_date': r.trading_date.strftime('%Y%m%d'),
                'volume_percent': float(r.volume_percent),
            } for r in rows
        ]
        sc.close()
        return data

    @staticmethod
    def get_vstrategy_symbols_volume_percent(vs_id, start_date, end_date, page=0, size=100, **kwargs):
        sc = session()
        rows = sc.query(
            VstrategyMarketMetric
        ).filter(
            VstrategyMarketMetric.vs_id == vs_id,
            VstrategyMarketMetric.trading_date >= start_date,
            VstrategyMarketMetric.trading_date <= end_date,
        ).order_by(VstrategyMarketMetric.volume_percent.desc())
        total = rows.count()
        if not kwargs.get('download'):
            rows = rows.offset(page * size).limit(size)
        data = [
            {
                'id': r.id,
                'vs_id': r.vs_id,
                'trading_date': r.trading_date.strftime('%Y%m%d'),
                'start_time': r.start_time.strftime('%Y%m%d %X'),
                'end_time': r.end_time.strftime('%Y%m%d %X'),
                'symbol': r.symbol,
                'volume': float(r.volume),
                'market_volume': float(r.market_volume),
                'volume_percent': float(r.volume_percent),
            }
            for r in rows
        ]
        sc.close()
        return data, total

    @staticmethod
    def get_vs_realtime_volume_percent(vs_id):
        pass

    @staticmethod
    def generate_vs_history_volume_percent(trading_date=None):
        from service.back_test.models import Strategy, VStrategies
        sc = session()
        vs_ids = [r[0] for r in sc.query(
            VStrategies.id
        ).join(
            Strategy, Strategy.id == VStrategies.strategy_id
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            Strategy.strategy_type.in_(consts.stock_strategy_type)
        )]
        if not trading_date:
            kdb = KdbQuery()
            trading_dates = kdb.get_trading_days('20180601', datetime.datetime.now().strftime('%Y%m%d'))
            sc.query(VstrategyMarketMetric).filter().delete()
            sc.commit()
        else:
            trading_dates = [parse(trading_date).strftime('%Y%m%d')]
            sc.query(VstrategyMarketMetric).filter(VstrategyMarketMetric.trading_date == trading_dates[0]).delete()
            sc.commit()
        for vs_id, trading_date in itertools.product(vs_ids, trading_dates):
            VstrategyMarketMetric.generate_vs_trading_date_volume_percent(
                vs_id, trading_date, clear=False
            )
        sc.close()
        return True

    @staticmethod
    def generate_vs_trading_date_volume_percent(vs_id, trading_date, clear=True):
        from service.back_test.models import TradeLogs
        sc = session()
        rows = sc.query(
            TradeLogs.symbol.label('symbol'),
            func.min(TradeLogs.calendar_time).label('begin_time'),
            func.max(TradeLogs.calendar_time).label('end_time'),
            func.sum(TradeLogs.trade_vol).label('trade_vol')

        ).filter(
            TradeLogs.vstrategy_id == vs_id,
            TradeLogs.trading_date == trading_date,
            TradeLogs.log_type.in_(['0', '3']),
        ).group_by(
            TradeLogs.symbol
        )
        data = []
        time_format = parse(trading_date).strftime('%Y-%m-%d ') + '%H:%M:%S'
        for r in rows:
            data.append({
                'symbol': r.symbol,
                'begin_time': r.begin_time.strftime(time_format),
                'end_time': r.end_time.strftime(time_format),
                'trade_vol': float(r.trade_vol),
                'market_volume': 0,
                'volume_percent': 0,
            })

        kdb = KdbQuery()
        kdb_trading_date = parse(trading_date).strftime('%Y.%m.%d')
        for d in data:
            begin_time = parse(d['begin_time'])
            end_time = parse(d['end_time'])
            if begin_time.strftime('%H%M%S') == end_time.strftime('%H%M%S'):
                begin_timestamp = begin_time - datetime.timedelta(seconds=15)
                end_timestamp = end_time + datetime.timedelta(seconds=15)
            else:
                begin_timestamp = begin_time - datetime.timedelta(seconds=5)
                end_timestamp = end_time + datetime.timedelta(seconds=5)
            d['market_volume'] = kdb.get_stock_market_volume(
                kdb_trading_date, d['symbol'],
                int(begin_timestamp.strftime('%H%M%S000')), int(end_timestamp.strftime('%H%M%S000'))
            )
            for i in range(10):
                if d['market_volume'] < d['trade_vol']:
                    begin_timestamp = begin_time - datetime.timedelta(seconds=(20 + i * 5))
                    end_timestamp = end_time + datetime.timedelta(seconds=(20 + i * 5))
                    d['market_volume'] = kdb.get_stock_market_volume(
                        kdb_trading_date, d['symbol'],
                        int(begin_timestamp.strftime('%H%M%S000')), int(end_timestamp.strftime('%H%M%S000'))
                    )
                else:
                    break

            if d['market_volume']:
                d['volume_percent'] = d['trade_vol'] / d['market_volume']

        if clear:
            sc.query(VstrategyMarketMetric).filter(
                VstrategyMarketMetric.vs_id == vs_id,
                VstrategyMarketMetric.trading_date == trading_date,
            ).delete()
            sc.commit()
        for d in data:
            o = VstrategyMarketMetric(
                vs_id=vs_id,
                trading_date=trading_date,
                start_time=d['begin_time'],
                end_time=d['end_time'],
                symbol=d['symbol'],
                volume=d['trade_vol'],
                market_volume=d['market_volume'],
                volume_percent=d['volume_percent'],
            )
            sc.add(o)
        sc.commit()
        sc.close()
        return True


class FundHedgeConfig(ModelBase):
    __tablename__ = 'fund_hedge_config'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    hedge_key = Column(VARCHAR(64), nullable=True)
    account = Column(VARCHAR(64), nullable=True)
    account_type = Column(ENUM('STOCK', 'FUTURE'), nullable=True)
    min_cash = Column(DOUBLE, nullable=False, default=0)
    max_cash = Column(DOUBLE, nullable=False, default=0)

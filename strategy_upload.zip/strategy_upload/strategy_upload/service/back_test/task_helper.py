import json

import consts

from db import session_context
from utils import get_mitype
from .models import Strategy, VStrategies, StockSmartExecutionVersion, StrategyLiveRunRecords, StrategyUploadFile, \
    StockPortfolioOptimizationVersion
from .helper import get_linked_merge_vs_deploy_ip
from models.strategy import VsT0Relation
from service.stock_factor.models import StockFactorStrategyColumns
from service.statistic.models import StrategyIncomeAttribution
from constant import StrategyConstant, TradingTimeRange, StrategyEventTrackConstant, VStrategiesConstant
from config import config, RedisCache0


class BackTestAnalysisTaskConstructorException(Exception):
    pass


class BackTestAnalysisCheckFailException(Exception):
    pass


def _get_depend_ev(sc, s):
    depend_ev = []
    for dep in (s.dependency or []):
        if dep['type'] == 'ev':
            dep_s = sc.query(Strategy).filter_by(id=dep['id']).first()
            if dep_s:
                depend_ev.append('strategy_upload/output/%s/%s/ev_output_%s_%s_[DAYNIGHT].csv' % (
                    dep_s.username, dep_s.name.strip().replace(' ', ''), '[DATE]', str(dep_s.id)
                ))
    return depend_ev


def _get_exchange_account(vs):
    exchange_account = {}
    for _acc in vs.symbols_accounts:
        exchange_account[_acc['exchange']] = _acc['account']

    return exchange_account


def _get_stock_fee_rate(vs):
    acc_set = {'1340154147', '109202003202'}
    stock_fee_rate = 0
    symbol_accounts = [a['account'] for a in vs.symbols_accounts]
    if len(set(symbol_accounts) & acc_set) != 0:
        stock_fee_rate = 0.00012

    return stock_fee_rate


def _get_symbol_account(exch, exchange_account):
    default_account = 'init_account'

    if len(set(exchange_account.values())) <= 1:
        return default_account
    else:
        if exch in consts.STOCK_EXCHANGE:
            for e in ([exch] + consts.STOCK_EXCHANGE):
                if e in exchange_account:
                    return exchange_account[exch]
        return exchange_account[exch]


def _get_quote_source(s):
    quote_source = '0'
    if s.strategy_type == '23':
        quote_source = 'whole'
    return quote_source


def _get_factor_book(s):
    factor_book = dict()
    for _p in s.products[0]:
        if _p['type'] == 'stock_factor_FACTOR':
            factor_info = _p['symbol'].split('_')
            factor_id = int(factor_info[2])
            factor_col = factor_info[3]
            f_book = factor_book.setdefault(factor_id, [])
            f_book.append(factor_col)
    return factor_book


def _is_hsa(s):
    for _p in s.products[0]:
        if _p['type'] == 'index' and _p['symbol'] == 'HSA':
            return True
    return False


def _is_use_default(exchange_account):
    if len(set(exchange_account.values())) <= 1:
        return True
    return False


def _get_config_type(s):
    config_type = 0
    if s.id > 208596:
        config_type = 1
    if s.strategy_type in consts.t0_stock_strategy_type:
        config_type = 2
    return config_type


def _get_contracts(s, exchange_account, quote_source):
    contracts = list()

    for _p in s.products[0]:
        if _p['type'] == 'futures' or (_p['exch'] == 'IDEALPRO'):
            if _p['exch'] in ('LME', 'IDEALPRO'):
                ranks = ''
            else:
                ranks = ','.join(['R%s' % i for i in sorted(_p['rank'])])

            if str(s.detail.get('quote_deepth', '1')) == '0' and _p['exch'] in consts.FUTURE_EXCHANGE:
                mitype = '12'
            else:
                mitype = get_mitype(_p['exch'])

            contracts.append('|'.join(
                [_p['symbol'], ranks, _p['exch'], mitype, str(s.max_pos), quote_source,
                 _get_symbol_account(_p['exch'], exchange_account)]
            ))
        elif _p['type'] == 'stock':
            mi_type = get_mitype(_p['exch'])
            if _p['symbol'][-3:].upper() in ['.SH', '.SZ']:
                mi_type = get_mitype('SSE_SZSE_INDEX')
            else:
                if s.strategy_type == '188':
                    mi_type += ',54'
            contracts.append('|'.join(
                [_p['symbol'], '', _p['exch'], mi_type, str(s.max_pos), '0',
                 _get_symbol_account(_p['exch'], exchange_account)]
            ))
        elif _p['type'] == 'stock_factor_FACTOR':
            pass
        elif _p['type'] == 'index':
            transaction_quote = [str(_x) for _x in s.detail.get('transaction_quote', [])]
            symbol_account = _get_symbol_account('SSE', exchange_account)
            if '1' in transaction_quote:
                contracts.append('%s|I|54|%s' % (_p['symbol'], symbol_account))
            if '2' in transaction_quote:
                contracts.append('%s|I|53|%s' % (_p['symbol'], symbol_account))
            if '3' in transaction_quote:
                contracts.append('%s|I|52|%s' % (_p['symbol'], symbol_account))

            if s.strategy_type == '188':
                contracts.append('%s|I+|%s' % (_p['symbol'], symbol_account))
            else:
                contracts.append('%s|I|%s' % (_p['symbol'], symbol_account))
        elif _p['type'] == 'spot':
            contracts.append('|'.join(
                [_p['symbol'], '', _p['exch'], get_mitype(_p['exch']),
                 str(s.max_pos), quote_source, _get_symbol_account(_p['exch'], exchange_account)]
            ))
        else:
            raise ValueError('product type (%s, %s) error' % (_p['symbol'], _p['type']))

    return contracts


def _get_smart_execution_contracts(se, s, exchange_account, quote_source):
    se_contracts = list()

    for _p in se.products[0]:
        if _p['type'] == 'futures':
            ranks = ','.join(['R%s' % i for i in sorted(_p['rank'])])
            if str(se.detail.get('quote_deepth', '1')) == '0' and _p['exch'] in consts.FUTURE_EXCHANGE:
                mitype = '12'
            else:
                mitype = get_mitype(_p['exch'])

            se_contracts.append('|'.join(
                [_p['symbol'], ranks, _p['exch'], mitype, '1000000', quote_source,
                 _get_symbol_account(_p['exch'], exchange_account)]
            ))
        elif _p['type'] == 'stock':
            mi_type = get_mitype(_p['exch'])
            if _p['symbol'][-3:].upper() in ['.SH', '.SZ']:
                mi_type = get_mitype('SSE_SZSE_INDEX')

            se_contracts.append('|'.join(
                [_p['symbol'], '', _p['exch'], mi_type, '1000000', '0',
                 _get_symbol_account(_p['exch'], exchange_account)]
            ))
        elif _p['type'] == 'index':
            transaction_quote = [str(_x) for _x in s.detail.get('transaction_quote', [])]
            symbol_account = _get_symbol_account('SSE', exchange_account)
            if '1' in transaction_quote:
                se_contracts.append('%s|I|54|%s' % (_p['symbol'], symbol_account))
            if '2' in transaction_quote:
                se_contracts.append('%s|I|53|%s' % (_p['symbol'], symbol_account))
            if '3' in transaction_quote:
                se_contracts.append('%s|I|52|%s' % (_p['symbol'], symbol_account))

            se_contracts.append('%s|I|%s' % (_p['symbol'], symbol_account))
        elif _p['type'] == 'stock_factor_POSITION':
            se_contracts.append('81|0|%s|' % (_p['symbol'].rsplit('_', 1)[-1]))
        else:
            pass

    return se_contracts


def _get_position_data(s, last_account_positions, exchange_account, is_hsa, quote_source):
    yesterday_pos = list()
    today_pos = list()
    pos_contracts = list()
    for _, pos in last_account_positions['positions'].items():
        if not (pos['today_long_pos'] > 0 or pos['today_short_pos'] > 0):
            continue
        yesterday_pos.append(
            '|'.join([str(pos[key]) for key in [
                'symbol', 'yest_long_pos', 'yest_long_avg_price',
                'yest_short_pos', 'yest_short_avg_price', 'account'
            ]])
        )
        today_pos.append(
            '|'.join([str(pos[key]) for key in [
                'symbol', 'today_long_pos', 'today_long_avg_price', 'today_short_pos',
                'today_short_avg_price', 'account'
            ]])
        )
        if len(pos['exchange']) <= 2:
            exchange = consts.EXCHANGE[pos['exchange']]

            if exchange == 'ICEU' and pos['symbol'][:1].upper() == 'B' and (exchange not in exchange_account) and (
                    'ICEE' in exchange_account):
                exchange = 'ICEE'
        else:
            exchange = pos['exchange']

        if exchange in (consts.FUTURE_EXCHANGE + consts.FOREIGN_EXCHANGE):
            if str(s.detail.get('quote_deepth', '1')) == '0' and exchange in consts.FUTURE_EXCHANGE:
                mi_type = '12'
            else:
                mi_type = get_mitype(exchange)

            pos_contracts.append(
                '|'.join(
                    [pos['symbol'], '', exchange, mi_type, str(s.max_pos), quote_source,
                     _get_symbol_account(exchange, exchange_account)]
                )
            )
        elif exchange in consts.STOCK_EXCHANGE and not is_hsa:
            if s.strategy_type == '188':
                mi_type = '9, 54'
            else:
                mi_type = '9'

            pos_contracts.append(
                '|'.join(
                    [pos['symbol'], '', exchange, mi_type, str(s.max_pos), '0',
                     _get_symbol_account(exchange, exchange_account)]
                )
            )
        else:
            pass

    return {
        "yesterday_pos": yesterday_pos,
        "today_pos": today_pos,
        "pos_contracts": pos_contracts,
    }


def _get_smart_execution_data(s, sc, exchange_account, quote_source):
    smart_execution_so_path = ''
    smart_execution_ev = ''
    se_contracts = []
    se_factor_book = {}

    if s.detail.get('vwap_version'):
        smart_execution_strategy = sc.query(Strategy).join(
            StockSmartExecutionVersion, StockSmartExecutionVersion.strategy_id == Strategy.id
        ).filter(
            StockSmartExecutionVersion.value == s.detail['vwap_version']
        ).first()
        if smart_execution_strategy:
            se_dep_ev = _get_depend_ev(sc, smart_execution_strategy)
            smart_execution_ev = '|'.join(se_dep_ev)
            smart_execution_so_path = smart_execution_strategy.strategy_upload_file['relative_path']
            se_contracts = _get_smart_execution_contracts(smart_execution_strategy, s, exchange_account, quote_source)
            se_factor_book = _get_factor_book(smart_execution_strategy)

    return {
        "smart_execution_so_path": smart_execution_so_path,
        "smart_execution_ev": smart_execution_ev,
        "se_contracts": se_contracts,
        "se_factor_book": se_factor_book
    }


def _get_factor_book_data(factor_book):
    contracts = list()
    factor_book_task = list()

    for f_id, cols in factor_book.items():
        contracts.append('80|0|%s|' % f_id)
        f_columns = StockFactorStrategyColumns.get_factor_columns(f_id)
        if 'ALL' in cols:
            factor_book_task.append(
                {'id': f_id, 'columns': f_columns, 'indexes': list(range(len(f_columns))),
                 'total_num': len(f_columns)}
            )
        else:
            book_col = []
            book_col_index = []
            for _i, _c in enumerate(f_columns):
                if _c in cols:
                    book_col.append(_c)
                    book_col_index.append(_i)
            factor_book_task.append(
                {'id': f_id, 'columns': book_col, 'indexes': book_col_index, 'total_num': len(f_columns)}
            )

    return {
        "contracts": contracts,
        "factor_book_task": factor_book_task,
    }


def _get_back_test_analysis_task_queue(s):
    if s.detail.get('back_test_split') or (s.strategy_type == StrategyConstant.StrategyType.StockFactor.value):
        task_queue = consts.NEW_AGENT_TASK_QUEUE + '_part1'
    elif s.strategy_type in consts.stock_strategy_type + consts.hedge_stock_strategy_type:
        task_queue = consts.NEW_AGENT_TASK_QUEUE + '_stock'
    else:
        task_queue = consts.NEW_AGENT_TASK_QUEUE + '_future'

    return task_queue


def back_test_analysis_task_constructor(vs_id, start_date, end_date=None, use_last_live_position=False,
                                        server='', trade_model='', so_id=0, **kwargs):
    """
    construct back test analysis task cmd which will send to back test system later
    :param vs_id: int, vstrategy id
    :param start_date: string, %Y%m%d
    :param end_date: string, %Y%m%d
    :param use_last_live_position: boolean
    :param server: string, ip addr
    :param trade_model: string
    :param so_id: int
    :return:
    """
    if end_date is None:
        end_date = start_date

    with session_context() as sc:
        vs = sc.query(VStrategies).filter(
            VStrategies.id == vs_id
        ).first()
        if not vs:
            raise BackTestAnalysisTaskConstructorException("vs {vs_id} not exists".format(vs_id=vs_id))

        s_id = vs.strategy_id
        s = sc.query(Strategy).filter(
            Strategy.id == s_id
        ).first()
        if not s:
            raise BackTestAnalysisTaskConstructorException("s {s_id} not exists".format(s_id=s_id))

        if not s.is_new_so:
            raise BackTestAnalysisTaskConstructorException("s {s_id} is not new so".format(s_id=s_id))

        if not s.products:
            raise BackTestAnalysisTaskConstructorException("s products invalid")

        if s.node not in {'back_test', 'union_simu'}:
            raise BackTestAnalysisTaskConstructorException("s node {s_node} not support".format(s_node=s.node))

        task_id = 'v_strategy_id:{}'.format(vs.id)
        day_night = s.day_night
        begin_end_time = consts.BEGIN_END_TIME[day_night]

        depend_ev = _get_depend_ev(sc, s)
        stock_fee_rate = _get_stock_fee_rate(vs)
        exchange_account = _get_exchange_account(vs)
        quote_source = _get_quote_source(s)
        is_hsa = _is_hsa(s)
        use_default = _is_use_default(exchange_account)

        contracts = _get_contracts(s, exchange_account, quote_source)
        if s.strategy_type in consts.t0_stock_strategy_type:
            t0_records = sc.query(VsT0Relation).filter(
                VsT0Relation.vs_id == vs.id,
                VsT0Relation.deleted == False
            ).all()
            for t0_record in t0_records:
                contracts.append('81|1|%s|' % t0_record.link_vs_id)

        last_account_positions = vs.get_last_back_test_account_position_v3(
            start_date,
            use_default=use_default,
            strategy_type=s.strategy_type,
            use_last_live_position=use_last_live_position,
            se_cash_rate=s.detail.get('se_cash_rate', 0)
        )
        if not last_account_positions['accounts']:
            raise BackTestAnalysisTaskConstructorException("last account positions: accounts empty")

        cash_io = last_account_positions.get('cash_io', {})
        total_investment = VStrategies.get_total_investment(vs_id, start_date)

        position_data = _get_position_data(s, last_account_positions, exchange_account, is_hsa, quote_source)

        if not server:
            server = vs.deploy_server
        if (not server) or (server == 'default'):
            server = sc.query(StrategyLiveRunRecords.host).filter(
                StrategyLiveRunRecords.vstrategy_id == vs_id
            ).order_by(StrategyLiveRunRecords.id.desc()).first()
            server = server and server[0] or ''

        if not trade_model:
            trade_model = vs.trade_model or s.detail['trade_model']

        so_path = s.strategy_upload_file['relative_path']
        if so_id:
            so_file = sc.query(StrategyUploadFile).filter(StrategyUploadFile.id == so_id).first()
            if so_file:
                so_path = so_file.relative_path

        config_type = _get_config_type(s)

        smart_execution_data = _get_smart_execution_data(s, sc, exchange_account, quote_source)

        factor_book = _get_factor_book(s)
        factor_book_data = _get_factor_book_data(factor_book)
        contracts.extend(factor_book_data['contracts'])

        se_factor_book = smart_execution_data['se_factor_book']
        se_factor_book_data = _get_factor_book_data(se_factor_book)
        smart_execution_data['se_contracts'].extend(se_factor_book_data['contracts'])

        t0_position = {}
        if s.strategy_type in consts.t0_stock_strategy_type:
            t0_position = vs.get_vs_t0_position()

        income_attribution = {}
        if s.strategy_type in consts.stock_strategy_type:
            income_attribution = StrategyIncomeAttribution.get_back_test_income_attribution_adjusted(
                s_id, start_date=start_date
            )

        task_cmd = {
            'reserve_type': 1,
            'db_conf': ','.join([config.KDB_HOST, str(config.KDB_PORT), config.KDB_USER, config.KDB_PASSWD]),
            'type': 110,
            'business': 2,
            'is_test': 0,
            'start_date': int(start_date),
            'end_date': int(end_date),
            'begin_time': begin_end_time['begin_time'],
            'end_time': begin_end_time['end_time'],
            'day_night_flag': day_night,
            'paper_trading_date': s.paper_trading_date.strftime('%Y%m%d'),
            'agent': '',
            'task_id': task_id,
            'user': s.username,
            'user_id': s.r_create_user_id,
            'flag_write_tunnel_log': False,
            'flag_write_strat_log': True,
            'flag_cross_day_position': True,
            'load_symbol_from_tradelist': s.detail.get('load_ev_config', False),
            'max_accum_open_vol': 1000000,
            'trader_type': 1,
            'match_type': 1,
            'plugins': [],
            'match_param': consts.COMMON_MATCH_PARAM,
            'sell_stock_short': s.detail.get('stock_loan', False),
            'so_path': [so_path],
            'config_type': config_type,
            'portfolio_optimization_model_version': StockPortfolioOptimizationVersion.get_paras(
                s.detail.get('portfolio_optimization_so_version', '')
            ),
            'vwap_version': s.detail.get('vwap_version', 'v1') or 'v1',
            'portfolio_optimization_ev_path': '/mnt/share_media/portfolio_optimization_ev/',
            'smart_execution_so_path': smart_execution_data["smart_execution_so_path"],
            'smart_execution_ev': smart_execution_data["smart_execution_ev"],
            'se_item': {
                'smart_execution_so_path': smart_execution_data["smart_execution_so_path"],
                'smart_execution_ev': smart_execution_data["smart_execution_ev"],
                'contracts': smart_execution_data["se_contracts"],
                'factor_book': se_factor_book_data["factor_book_task"],
                'se_cash': total_investment * s.detail.get('se_cash_rate', 0),
                'server': get_linked_merge_vs_deploy_ip(vs_id=vs_id),
            },
            't0_position': t0_position,
            'income_attribution': income_attribution,
            'factor_book': factor_book_data['factor_book_task'],
            'strat_item': {
                'strat_name': s.id_no or (s.name.strip().replace(' ', '')),
                'server': server,
                'strat_id': s_id,
                'contracts': contracts,
                'pos_contracts': position_data["pos_contracts"],
                'strat_param_file': '|'.join(depend_ev),
                'output_file_path': './output/vstrategy/{}'.format(vs_id),
                'accounts': [
                    '|'.join([
                        _acc, str(_acc_cash['cash']), str(_acc_cash['asset_cash']),
                        str(_acc_cash['currency'].upper()), str(_acc_cash['forex_rate'])])
                    for _acc, _acc_cash in last_account_positions['accounts'].items()
                ],
                'yesterday_pos': position_data["yesterday_pos"],
                'today_pos': position_data["today_pos"],
                'cash_limit': vs.get_vs_cash_limit(start_date, end_date),
                'factor_book': factor_book_data['factor_book_task'],
            },
            'settlement_kwargs': {
                'config_id': 0,
                'hedge': s.hedge or '',
                'hedge_type': s.hedge_type or '',
                'is_foregin_strategy': s.is_foregin_strategy,
                'strategy_type': Strategy.convert_strategy_type(s.strategy_type),
                'is_hk_stock': (vs_id in consts.hk_stock_vs_ids) or (s.strategy_type in ('27', '28')),
                'cash_io': cash_io,
                'stock_fee_rate': stock_fee_rate,
                'stock_account_fee_rate': vs.get_stock_account_fee_rate(list(exchange_account.values())),
                'se_cash_rate': s.detail.get('se_cash_rate', 0),
            },
            'unrealized_corp_data': last_account_positions.get('unrealized_corp_data',
                                                               {}) if last_account_positions.get(
                'is_first_day') else vs.get_unrealized_corp_items(start_date),
            'is_hk_strategy': s.strategy_type in ('27', '28'),
        }

        if len(task_cmd['portfolio_optimization_model_version']) > 31:
            task_cmd['reserve_type'] = 2

        if factor_book_data['factor_book_task']:
            task_cmd['reserve_type'] = 3

        optional_module = s.detail.get('modules', '[]')
        if 'VWAP' in optional_module:
            task_cmd['plugins'].append('vwap')

        if trade_model:
            task_cmd['strat_item']['trade_model'] = trade_model

        time_interval = int(float(s.detail.get('time_interval', 0)))
        if time_interval > 0:
            task_cmd['time_interval'] = time_interval

        extra_arguments = {
            'log_level': s.detail.get('log_level', StrategyConstant.DetailLogLevel.Production.value),
            'icopy': 0
        }
        task_cmd['extra_arguments'] = extra_arguments

        check_res = Strategy.vs_back_test_check_dependency(vs_id, start_date, 0, task=task_cmd)
        if not check_res:
            raise BackTestAnalysisCheckFailException("vs back test analysis check fail: {}".format(check_res))

        task_cmd = json.dumps(task_cmd)
        if s.strategy_type in consts.t0_stock_strategy_type:
            task_cmd = task_cmd.replace('init_account', 'account{}'.format(vs_id))

        return {
            "task_cmd": task_cmd,
            "task_queue": _get_back_test_analysis_task_queue(s)
        }


def vs_back_test_analysis(vs_id, start_date, **kwargs):
    task = back_test_analysis_task_constructor(vs_id, start_date, **kwargs)
    rds = RedisCache0()
    rds.lpush(task["task_queue"], task["task_cmd"])


def vs_union_simu_back_test_analysis(vs_ids, start_date, **kwargs):
    task_cmd_list = list()
    for vs_id in vs_ids:
        Strategy.add_vs_event(
            vs_id,
            start_date,
            TradingTimeRange.Day.value,
            StrategyEventTrackConstant.Event.PrepareVsTask.value,
        )
        task_cmd = json.loads(back_test_analysis_task_constructor(vs_id, start_date, **kwargs)["task_cmd"])
        task_cmd_list.append(task_cmd)
        Strategy.add_vs_event(
            vs_id,
            start_date,
            TradingTimeRange.Day.value,
            StrategyEventTrackConstant.Event.SendVsTask.value,
        )

    rds = RedisCache0()
    rds.lpush("new_master_add_task_stock_union", json.dumps(task_cmd_list))


def vs_union_simu_back_test_analysis_from_alpha_vs(union_simu_alpha_vs_id, start_date, **kwargs):
    with session_context() as sc:
        vs_t0_relation = sc.query(VsT0Relation).filter(
            VsT0Relation.link_vs_id == union_simu_alpha_vs_id,
        ).first()
        if vs_t0_relation:
            union_simu_vs_ids = [vs_t0_relation.link_vs_id, vs_t0_relation.vs_id]
            vs_union_simu_back_test_analysis(union_simu_vs_ids, start_date, **kwargs)

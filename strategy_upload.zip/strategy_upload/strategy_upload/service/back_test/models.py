# -*-coding:utf-8-*-


import os
import json
import time
import traceback
import itertools
import subprocess
import datetime
import redis
import base64
import copy
import uuid
import requests
import shutil
import numpy as np
import pandas as pd
from dateutil.parser import parse
from sqlalchemy import or_, and_
from sqlalchemy import distinct
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from sqlalchemy import ForeignKey, UniqueConstraint
from sqlalchemy.dialects.mysql import BIGINT, VARCHAR, FLOAT, BOOLEAN, DATETIME, INTEGER, JSON, DOUBLE, TEXT, DATE, TIME
from sqlalchemy import BigInteger, Column, Date, DateTime, Enum, Float, Index, Integer, String, Time, text, JSON

import consts
from db import ModelBase, engine, session, session_context
from extensions import sentry
from config import config
from log import logger
from kdb_query import KdbQuery
from utils import format_date, get_exchange_by_longname, get_mitype, set_cache, get_cache, \
    set_str_cache, get_str_cache, get_all_products_unit, del_cache, symlink_insurance, notify_operation_wechat
from service.back_test.live_position_models import VsBase, VsAccount, VsPosition, PositionCorpActionsTable, \
    StockVsAccountFee
from service.back_test.live_trading_models import CashLimit, CashLimitDetail
from service.back_test.t0_factors import get_t0_position, vs_get_t0_alpha_position
from datetime import timedelta
from analysis.performance_analysis import PerformanceAnalyzer
from constant import StrategyEventTrackConstant, CommonPath, StrategyConstant, TradingTimeRange, CompanyUser
from .helper import get_linked_merge_vs_deploy_ip


def get_end_date():
    hour = datetime.datetime.now().strftime('%H%M')
    if hour < '1930':
        end_date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime('%Y%m%d')
    else:
        end_date = datetime.datetime.now().strftime('%Y%m%d')
    return end_date


class Users(ModelBase):
    __tablename__ = 'users'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)
    email = Column(VARCHAR(128), nullable=True)
    nickname = Column(VARCHAR(32), nullable=True)
    # 总分成比率
    total_point_ratio = Column(DOUBLE, nullable=True)
    # 平台分成比率
    platform_cost_ratio = Column(DOUBLE, nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'nickname': self.nickname,
            'email': self.email,
            'total_point_ratio': self.total_point_ratio and float(self.total_point_ratio) or consts.TOTAL_POINT_RATIO,
            'platform_cost_ratio': self.platform_cost_ratio and float(
                self.platform_cost_ratio) or consts.PLATFORM_COST_RATIO,
        }


class StrategyUploadFile(ModelBase):
    __tablename__ = 'strategy_upload_file'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=False)
    filename = Column(VARCHAR(255), nullable=False)
    relative_path = Column(VARCHAR(255), nullable=False)
    file_type = Column(VARCHAR(8), nullable=False)

    UPLOAD_FILE_TYPE = ('ev', 'st', 'paras')

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.r_create_user_id,
            'filename': self.filename,
            'relative_path': self.relative_path,
            'file_type': self.file_type,
            'abs_path': os.path.join(config.media, self.relative_path)
        }

    @staticmethod
    def save_file(data):
        user_id = int(data['user_id'])
        content = data['content']
        filename = data['filename']
        if '/' in filename:
            filename = filename.split('/')[-1]
        if '\\' in filename:
            filename = filename.split('\\')[-1]
        filename = filename.replace(' ', '')
        file_type = data['file_type']
        filename = '_'.join([str(user_id), time.strftime('%Y%m%d%H%M%S'), filename])
        if not os.path.exists(os.path.join(config.media, 'strategy_upload/so_files')):
            os.makedirs(os.path.join(config.media, 'strategy_upload/so_files'))
        relative_path = os.path.join('strategy_upload/so_files', filename)
        data_fd = os.open(os.path.join(config.media, relative_path), os.O_CREAT | os.O_RDWR)
        os.write(data_fd, content)
        os.fsync(data_fd)
        os.close(data_fd)

        sc = session()
        try:
            f = StrategyUploadFile(
                r_create_user_id=user_id,
                r_update_user_id=user_id,
                filename=filename,
                file_type=file_type,
                relative_path=relative_path
            )
            sc.add(f)
            sc.commit()
            f_id = f.id
        except Exception as e:
            sentry.captureException()
            f_id = -1
        finally:
            sc.close()
        return f_id

    @staticmethod
    def copy_file(data):
        user_id = int(data['user_id'])
        username = data['user_name']
        file_type = data['file_type']
        file_md5 = data['file_md5']
        file_path = os.path.join(config.media, 'platform_file_upload', username, file_md5)
        meta_file = os.path.join(file_path, 'meta.json')
        meta_f = open(meta_file, 'r')
        meta_info = json.load(meta_f)
        meta_f.close()
        filename = meta_info.get('file_unpack_name', meta_info['file_name'])
        relative_path = os.path.join('platform_file_upload', username, file_md5, filename)
        with session_context() as sc:
            f = StrategyUploadFile(
                r_create_user_id=user_id,
                r_update_user_id=user_id,
                filename=filename,
                file_type=file_type,
                relative_path=relative_path
            )
            sc.add(f)
            sc.commit()
            return f.id
        return -1


class StrategyFileChangeRequest(ModelBase):
    __tablename__ = 'strategy_file_change_request'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=False)
    username = Column(VARCHAR(32), nullable=False)
    r_update_user_id = Column(INTEGER, nullable=True)
    strategy_upload_file_id = Column(INTEGER, nullable=False)
    strategy_upload_file_name = Column(VARCHAR(255), nullable=False)
    strategy_id = Column(INTEGER, nullable=False)
    strategy_id_no = Column(VARCHAR(32), nullable=False)
    status = Column(Enum('PENDING', 'APPROVED', 'REJECTED'), nullable=False, default='PENDING')
    request_msg = Column(VARCHAR(512), nullable=True, default="")
    audit_msg = Column(VARCHAR(512), nullable=True, default="")
    auditer = Column(VARCHAR(32), nullable=True)
    audit_user_id = Column(INTEGER, nullable=True)
    strategy_type = Column(VARCHAR(32), nullable=True, default="")

    def to_dict(self):
        return {
            'id': self.id,
            'creator': self.username,
            'create_time': self.r_create_time.strftime('%Y%m%d %X'),
            's_id': self.strategy_id,
            'strategy_id': self.strategy_id_no,
            'filename': self.strategy_upload_file_name,
            'request_msg': self.request_msg,
            'auditer': self.auditer,
            'audit_msg': self.audit_msg,
            'status': self.status,
        }


class LiveStrategyChangeRequest(ModelBase):
    __tablename__ = 'live_strategy_change_request'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=False)
    r_update_user_id = Column(INTEGER, nullable=True)
    username = Column(VARCHAR(32), nullable=False)

    strategy_id = Column(INTEGER, nullable=False)
    strategy_id_no = Column(VARCHAR(32), nullable=False)
    vs_id = Column(INTEGER, nullable=False)
    portfolio_name = Column(VARCHAR(128), nullable=False)

    new_strategy_id = Column(INTEGER, nullable=False)
    new_strategy_id_no = Column(VARCHAR(32), nullable=False)
    new_vs_id = Column(INTEGER, nullable=True)
    new_portfolio_name = Column(VARCHAR(128), nullable=True)

    parent_strategy_id = Column(INTEGER, nullable=False)

    trading_date = Column(Date, nullable=False)

    status = Column(Enum('PENDING', 'APPROVED', 'REJECTED'), nullable=False, default='PENDING')
    request_msg = Column(VARCHAR(512), nullable=True, default="")
    audit_msg = Column(VARCHAR(512), nullable=True, default="")
    auditer = Column(VARCHAR(32), nullable=True)
    audit_user_id = Column(INTEGER, nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'creator': self.username,
            'create_time': self.r_create_time.strftime('%Y%m%d %X'),
            'request_msg': self.request_msg,
            'auditer': self.auditer,
            'audit_msg': self.audit_msg,
            'status': self.status,
            's_id': self.strategy_id,
            'strategy_id': self.strategy_id_no,
            'vs_id': self.vs_id,
            'portfolio_name': self.portfolio_name,
            'new_s_id': self.new_strategy_id,
            'new_strategy_id': self.new_strategy_id_no,
            'new_vs_id': self.new_vs_id,
            'new_portfolio_name': self.new_portfolio_name,
            'trading_date': self.trading_date.strftime('%Y%m%d'),
        }

    @staticmethod
    def upgrade_vstrategy(vs_id, new_strategy_id, trading_date, **kwargs):
        pass


class Strategy(ModelBase):
    __tablename__ = 'strategy'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=False)
    r_update_user_id = Column(INTEGER, nullable=True)
    username = Column(VARCHAR(32), nullable=False)
    name = Column(VARCHAR(255), nullable=False)
    status = Column(INTEGER, nullable=False, default=1)  # 回测或者ev生产状态 0=完成 1=运行中 -1=失败 -2=停止 2=新建
    description = Column(VARCHAR(255), nullable=True, default="")
    node = Column(VARCHAR(32), nullable=False)  # ev=ev生产策略 back_test=使用sdp编写的so策略 order_list=交易清单策略 group=组合策略
    start_date = Column(VARCHAR(16), nullable=False)
    end_date = Column(VARCHAR(16), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    products = Column(JSON, nullable=False)
    max_pos = Column(INTEGER, nullable=True, default=0)
    dependency = Column(JSON)
    detail = Column(JSON, nullable=False)
    st_uuid = Column(VARCHAR(64), nullable=False)  # 一个回测或者ev生产任务的唯一标识id
    code = Column(VARCHAR(4), nullable=False)
    id_no = Column(VARCHAR(32), nullable=False)
    strategy_upload_file_id = Column(INTEGER, nullable=False)
    # consts.STRATEGY_TYPE 股票策略consts.stock_strategy_type
    # '26'=因子生产策略, if node=ev: 日间因子生产策略 node=back_test: 日内因子生产策略
    strategy_type = Column(VARCHAR(4), nullable=True)
    strategy_status = Column(VARCHAR(4), nullable=True)  # NEW=新建 BT=回测 PT=papertrading LT=实盘
    strategy_feature = Column(VARCHAR(4), nullable=True)
    strategy_underlying = Column(VARCHAR(4), nullable=True)
    strategy_para_type = Column(VARCHAR(4), nullable=True)
    is_delete = Column(INTEGER, nullable=False, default=0)  # 1=删除
    is_test = Column(INTEGER, nullable=False, default=0)  # 1=试运行
    error = Column(JSON, nullable=True)
    live_time = Column(DATETIME, nullable=True)
    task_progress = Column('progress', FLOAT, nullable=True)  # 回测进度
    paper_trading_date = Column(DATETIME, nullable=True)
    hedge = Column(VARCHAR(32), nullable=True)  # 对冲设置
    hedge_type = Column(VARCHAR(32), nullable=True)  # 对冲设置
    group_id = Column(BIGINT, nullable=False, default=0)  # 组合策略 ForeignKey:ResearchStrategyPortfolio.id
    group_detail = Column(JSON, nullable=True)  # 组合策略
    auto_paper_trading = Column(BOOLEAN, nullable=True, default=False)
    confidence = Column(DOUBLE, nullable=False, default=1)
    is_derive_strategy = Column(BOOLEAN, nullable=True, default=False)  # 是否是clone的策略 组合分析页面添加回测生成的

    def has_margin_hedge(self):
        """
        是否有融券底仓对冲
        :return: boolean
        """
        return self.strategy_type == StrategyConstant.StrategyType.StockAlpha.value \
               and self.detail.get('alpha_s_id', 0) != 0

    def direct_dep_factor_ids(self):
        return [int(p['symbol'].split('_')[2]) for p in self.products[0] if p.get('type', '') == 'stock_factor_FACTOR']

    def direct_dep_ids(self):
        if self.dependency is None:
            return []
        return [int(p['id']) for p in self.dependency]

    def get_query_time(self):
        if self.status == consts.TASK_RUNNING:
            query_time = min(20, max((datetime.datetime.now() - self.r_update_time).seconds, 5))
        else:
            query_time = 0
        return query_time

    @staticmethod
    def get_run_status(value):
        status_map = {
            consts.TASK_RUNNING: 'RUNNING',
            consts.TASK_FINISHED: 'FINISHED',
            consts.TASK_FAILED: 'FAILED',
            consts.TASK_STOPPED: 'STOPPED',
            consts.TASK_NEW: 'NEW'}
        return status_map.get(value, "UNKNOWN")

    @staticmethod
    def convert_strategy_type(s_type):
        if s_type == '27':
            return '15'
        elif s_type == '28':
            return '18'
        elif s_type == '33':
            return '15'
        else:
            return s_type

    @staticmethod
    def query_cache_data(key, config_id, back_id, update_time):
        last_update = update_time
        if config_id > 0:
            return None
        result = None
        if last_update <= (datetime.datetime.now() - timedelta(seconds=3600)):
            result = get_cache(key)
        return result if result else None

    @staticmethod
    def get_semi_info(cfg_id):
        item = BackTestConfig.get_item(cfg_id)
        value = item['other'].get('status', consts.TASK_FINISHED)
        return {
            'start': item['start_date'],
            'initial_cash': item['init_cash'],
            'trade_model': item['trade_model'],
            'progress': item['progress'],
            'status': Strategy.get_run_status(value),
            'task_id': item['task_id'],
            'accounts': item.get('accounts', {}),
        }

    def to_dict_brief(self, config_id=0, back_id=0):
        # from cron.strategy_upload_task import update_strategy_sorting_result

        d = self.detail or {}
        progress = 0
        if (self.task_progress or 0) >= 0:
            progress = self.task_progress
        if self.status == consts.TASK_FINISHED:
            progress = 1
        d['progress'] = progress
        if 'dependency' not in d:
            d['dependency'] = []
        d['status'] = Strategy.get_run_status(self.status)
        if self.status == consts.TASK_FAILED and d['progress'] > 0:
            d['status'] = 'PART_FINISHED'

        d['strategy_type'] = d.get('strategy_type') or self.strategy_type or '99'
        d['strategy_feature'] = d.get('strategy_feature') or self.strategy_feature or '999'
        d['strategy_underlying'] = d.get('strategy_underlying') or self.strategy_underlying or '07'
        d['strategy_para_type'] = d.get('strategy_para_type') or self.strategy_para_type or '1'
        d['strategy_status'] = self.strategy_status or 'BT'

        d['id'] = self.id
        d['end'] = time.strftime('%Y%m%d')
        d['strategy_id'] = self.id_no or (self.name.strip().replace(' ', ''))
        d['created_time'] = str(self.r_create_time)
        d['created_date'] = self.r_create_time.strftime('%Y-%m-%d')
        d['creator'] = self.username
        d['hedge'] = self.hedge or ''
        d['hedge_type'] = self.hedge_type or ''
        d['upload_type'] = self.node if self.node != 'back_test' else 'so_file'
        if self.is_delete == 1:
            d['status'] = 'DELETE'
        if self.strategy_status == 'NEW':
            d['status'] = 'NEW'
        d['papertrading_date'] = (self.paper_trading_date or self.r_create_time).strftime('%Y-%m-%d')
        if (self.node in ('back_test', 'cash_manager', 'trademaster_order_list')) or (self.strategy_type == '26'):
            d['so_file_name'] = os.path.basename(self.strategy_upload_file['relative_path']).split('_', 2)[-1]
        else:
            d['so_file_name'] = ''
        d['task_id'] = self.st_uuid
        d['log_path'] = 'log/simulation/%s/%s' % (self.id_no or self.name.strip().replace(' ', ''), d['task_id'])
        d['auto_paper_trading'] = self.auto_paper_trading
        d['confidence'] = float(self.confidence)
        d['query_time'] = 10
        d['is_root_strategy'] = self.detail.get('is_root_strategy', True)
        now_time = datetime.datetime.now()
        if d['progress'] >= 1:
            d['query_time'] = 0
        else:
            last_update_seconds = max((now_time - self.r_update_time).seconds, 10)
            if last_update_seconds >= 3600:
                d['query_time'] = 0
            else:
                d['query_time'] = min(20, last_update_seconds)

        d['pnl_url'] = '/media/strategy_pnl_graph/strategy_%s_0_%sthumbnail.png?_t=%s' % (
            self.id, 'hedge_' if self.hedge else '', now_time.strftime('%Y%m%d%H%M%S'))
        return d

    def to_dict(self, config_id=0, back_id=0):
        cache_key = 'platform_strategy_brief_%s_%d_%d' % (self.id, config_id, back_id)
        res = Strategy.query_cache_data(cache_key, config_id, back_id, self.r_update_time)
        if res:
            return res
        if self.node in ('order_list', 'trademaster_order_list'):
            return self.order_list_detail(config_id)
        d = self.detail or {}
        d.update(self.progress(config_id))
        if 'dependency' not in d:
            d['dependency'] = []
        d['status'] = Strategy.get_run_status(self.status)
        if self.node in ('back_test', 'cash_manager', 'union_simu'):
            d['strategy_type'] = d.get('strategy_type') or self.strategy_type or '99'
            d['strategy_feature'] = d.get('strategy_feature') or self.strategy_feature or '999'
            d['strategy_underlying'] = d.get('strategy_underlying') or self.strategy_underlying or '07'
            d['strategy_para_type'] = d.get('strategy_para_type') or self.strategy_para_type or '1'
            d['strategy_status'] = self.strategy_status or 'BT'
        else:
            d['strategy_type'] = ''
            d['strategy_feature'] = ''
            d['strategy_underlying'] = ''
            d['strategy_para_type'] = ''
            d['strategy_status'] = ''
        d['id'] = self.id
        d['end'] = time.strftime('%Y%m%d')
        d['strategy_id'] = self.id_no or (self.name.strip().replace(' ', ''))
        if self.status == consts.TASK_FAILED and d['progress'] > 0:
            d['status'] = 'PART_FINISHED'
        d['created_time'] = str(self.r_create_time)
        d['created_date'] = self.r_create_time.strftime('%Y-%m-%d')
        d['creator'] = self.username
        d['hedge'] = self.hedge or ''
        d['hedge_type'] = self.hedge_type or ''
        d['has_margin_hedge'] = self.has_margin_hedge()
        d['upload_type'] = self.node if self.node != 'back_test' else 'so_file'
        if self.is_delete == 1:
            d['status'] = 'DELETE'
        if self.strategy_status == 'NEW':
            d['status'] = 'NEW'
        d['papertrading_date'] = (self.paper_trading_date or self.r_create_time).strftime('%Y-%m-%d')
        if self.node in ('back_test', 'cash_manager', 'trademaster_order_list'):
            d['so_file_name'] = os.path.basename(self.strategy_upload_file['relative_path']).split('_', 2)[-1]
        else:
            d['so_file_name'] = ''
        if config_id > 0:
            d.update(Strategy.get_semi_info(config_id))
        else:
            d['task_id'] = self.st_uuid
        d['log_path'] = 'log/simulation/%s/%s' % (self.id_no or self.name.strip().replace(' ', ''), d['task_id'])
        d['auto_paper_trading'] = self.auto_paper_trading
        d['confidence'] = float(self.confidence)
        set_cache(cache_key, d, 3600)
        return d

    def normal_strategy_detail(self, config_id, back_id):
        d = self.to_dict(config_id, back_id)
        d['detail'] = {}
        d['detail']['ev_files'] = {}
        d['detail']['paras_files'] = {}
        d['detail']['back_test_pnl'] = {}
        d['detail']['error_info'] = self.error_info(config_id)
        cache = True
        if self.node == 'ev':
            cache = False
        output = self.output(config_id, cache)
        if self.node in ('ev', 'para'):
            ev_output_tmp = {}
            for p, date2files in output.items():
                p_ev_outputs = []
                for k in sorted(date2files.keys()):
                    for ev_f in date2files[k].split('|'):
                        if ev_f:
                            p_ev_outputs.append('media/%s' % ev_f)
                ev_output_tmp[p] = p_ev_outputs
            output = ev_output_tmp
        d['detail'][{
            'ev': 'ev_files',
            'para': 'paras_files',
            'back_test': 'back_test_pnl',
            'union_simu': 'back_test_pnl',
        }[self.node]] = output

        live_pnl_detail = self.live_pnl_v3()
        d['live_pnl'] = live_pnl_detail['pnl']
        d['vs_ids'] = live_pnl_detail.get('vs_ids', [])
        d['live_pnl_detail'] = live_pnl_detail
        d['vs_back_test_pnl'] = self.vs_back_test_pnl(config_id)
        if d['detail']['back_test_pnl'].get('pnl', {}):
            for _d in sorted(d['detail']['back_test_pnl']['pnl'].keys()):
                _d = format_date(_d, '-')
                if _d >= d['paper_trading_date']:
                    d['paper_trading_date'] = _d
                    break
        return d

    def to_dict_detail(self, config_id=0, back_id=0):
        cache_key = 'platform_strategy_detail_%s_%d_%d' % (self.id, config_id, back_id)
        result = Strategy.query_cache_data(cache_key, config_id, back_id, self.r_update_time)
        if result:
            return result

        if self.node in ('order_list', 'trademaster_order_list'):
            result = self.order_list_detail(config_id)
        elif self.node == 'group':
            result = self.strategy_group_detail(config_id, back_id)
        elif self.node == 'cash_manager':
            result = self.strategy_cash_manager_detail(config_id)
        else:
            result = self.normal_strategy_detail(config_id, back_id)

        set_cache(cache_key, result, 600)
        return result

    def get_quantamental_papertrading_date(self, q_strat_id):
        all_products = [p['symbol'].lower() for ps in self.products for p in ps]
        sc = session()
        cfg_objs = sc.query(Quantamentals).filter(
            Quantamentals.q_strat_id == q_strat_id,
            Quantamentals.product.in_(all_products),
        )
        papertrading_date_list = [c.papertrading_date for c in cfg_objs if c]
        sc.close()
        if not papertrading_date_list:
            return ''
        return datetime.datetime.strptime(max(papertrading_date_list), '%Y%m%d').strftime('%Y-%m-%d') if max(
            papertrading_date_list) else ''

    # def update_sorting_result(self):
    #     return True

    def strategy_cash_manager_detail(self, config_id=0, **kwargs):
        if self.node not in ('cash_manager',):
            raise ValueError('node error (%s)' % self.node)
        null_pnl_detail = {
            'pnl': {},
            'hedge_net': {},
            'origin_net': {},
            'sharpe': 0,
            'profitrate': 0,
            'annual_return': 0,
            'max_drawdown_pnl': 0,
            'max_drawdown_start': 0,
            'max_drawdown_end': 0,
            'return_over_drawdown': 0,
            'paper_trading_sharpe': 0,
            'paper_trading_profitrate': 0,
            'paper_trading_annual_return': 0,
            'paper_trading_max_drawdown_pnl': 0,
            'paper_trading_max_drawdown_start': 0,
            'paper_trading_max_drawdown_end': 0,
        }

        d = self.to_dict()
        d['detail'] = {}
        d['detail']['ev_files'] = {}
        d['detail']['paras_files'] = {}
        d['detail']['back_test_pnl'] = {'default': null_pnl_detail}
        d['detail']['error_info'] = {}
        d['live_pnl'] = {}
        d['live_pnl_detail'] = null_pnl_detail
        d['vs_back_test_pnl'] = null_pnl_detail
        d['weight'] = {}
        return d

    @property
    def is_deployed(self):
        if self.node == 'ev':
            return False
        is_deploy = False
        sc = session()
        if sc.query(VStrategies.id).filter(or_(and_(VStrategies.strategy_id == self.id, VStrategies.group_id == 0),
                                               VStrategies.group_id == self.id),
                                           VStrategies.status == consts.STRATEGY_LIVE).first():
            is_deploy = True
        sc.close()
        return is_deploy

    @property
    def is_btc_strategy(self):
        if not self.products:
            return False
        exchanges = [p['exch'] for p in self.products[0] if 'exch' in p]
        if set(exchanges) & set(consts.BTC_EXCHANGE):
            return True
        return False

    @property
    def can_edit(self):
        if self.node == 'ev':
            return False
        if self.strategy_status in ('LT',):
            return False
        if self.is_deployed:
            return False
        return True

    # def log_info(self, config_id=0):
    #     # Todo remove
    #     return {
    #         'terminal': '',
    #         'files': [],
    #         'log_path': ''
    #     }

    def live_pnl_v3(self):
        pnl_detail = {
            'pnl': {},
            'events': {},
            'hedge_net': {},
            'origin_net': {},
            'profitrate': 0,
            'sharpe': 0,
            'max_drawdown_pnl': 0,
            'max_drawdown_start': 0,
            'max_drawdown_end': 0,
            'annual_return': 0
        }
        if self.node not in ('back_test', 'order_list', 'group', 'trademaster_order_list'):
            return pnl_detail
        cache_key = 'platform_strategy_live_pnl_v3_%s' % self.id
        pnl = get_cache(cache_key)
        if pnl:
            return pnl

        try:

            sc = session()
            vstrategies = sc.query(VStrategies).filter(VStrategies.strategy_id == self.id)
            vs_id = None
            for vs in vstrategies:
                if not vs_id:
                    vs_id = vs.id
                if vs.status == consts.STRATEGY_LIVE:
                    vs_id = vs.id
                    break

            if not vs_id:
                sc.close()
                return pnl_detail
            vs_ids = [vs_id]

            hedge, hedge_type = self.hedge, self.hedge_type or 'position'

            live_pnl_detail = Strategy.vs_live_pnl_detail(
                self.id, _vs_ids=vs_ids, hedge=hedge, hedge_type=hedge_type, strategy_type=self.strategy_type
            )
            pnl_detail = Strategy.live_net_line(
                live_pnl_detail['live_pnl'][vs_id], '', hedge=hedge, hedge_type=hedge_type
            )

            if live_pnl_detail.get('t0_daily_pnl_extra'):
                t0_daily_pnl_extra = {
                    k: live_pnl_detail['t0_daily_pnl_extra'].get(k, live_pnl_detail['t0_daily_pnl_extra']['default'])
                    for k in pnl_detail['pnl'].keys()
                }
                pnl_detail['t0_daily_pnl_extra'] = t0_daily_pnl_extra

            pnl_detail['events'] = Strategy.get_accident_events(vs_ids)
            pnl_detail['vs_ids'] = vs_ids
        except Exception as e:
            sentry.captureException()
        if pnl_detail['pnl']:
            set_cache(cache_key, pnl_detail, 3600 * 2)
        return pnl_detail

    def vs_back_test_pnl(self, config_id=0):
        pnl_detail = {
            'pnl': {},
            'hedge_net': {},
            'origin_net': {},
            'profitrate': 0,
            'sharpe': 0,
            'max_drawdown_pnl': 0,
            'max_drawdown_start': 0,
            'max_drawdown_end': 0,
            'annual_return': 0
        }
        if self.node not in ('back_test', 'order_list', 'group', 'trademaster_order_list'):
            return pnl_detail
        cache_key = 'platform_strategy_vs_back_test_pnl_%s_%d' % (self.id, config_id)
        pnl = get_cache(cache_key)
        if pnl:
            return pnl
        try:

            sc = session()
            vstrategies = sc.query(VStrategies).filter(
                VStrategies.strategy_id == self.id
            )
            vs_id, initial_cash = None, 0
            for vs in vstrategies:
                if not vs_id:
                    vs_id = vs.id
                if vs.status == consts.STRATEGY_LIVE:
                    vs_id = vs.id
                    break
            sc.close()

            if not vs_id:
                return pnl_detail
            vs_ids = [vs_id]
            hedge, hedge_type = self.hedge, self.hedge_type or 'position'
            vs_back_test_pnl_detail = Strategy.vs_back_test_pnl_detail(
                self.id, _vs_ids=vs_ids, hedge=hedge, hedge_type=hedge_type, strategy_type=self.strategy_type
            )
            pnl_detail = Strategy.vs_back_test_net_line(
                vs_back_test_pnl_detail['vs_back_test_pnl'][vs_id], '', hedge=hedge, hedge_type=hedge_type
            )
            if vs_back_test_pnl_detail.get('t0_daily_pnl_extra'):
                t0_daily_pnl_extra = {
                    k: vs_back_test_pnl_detail['t0_daily_pnl_extra'].get(k,
                                                                         vs_back_test_pnl_detail['t0_daily_pnl_extra'][
                                                                             'default'])
                    for k in pnl_detail['pnl'].keys()
                }
                pnl_detail['t0_daily_pnl_extra'] = t0_daily_pnl_extra
        except Exception as e:
            sentry.captureException()
        if pnl_detail['pnl']:
            set_cache(cache_key, pnl_detail, 3600 * 2)
        return pnl_detail

    def order_list_detail(self, config_id=0):
        if self.node not in ('order_list', 'trademaster_order_list'):
            raise ValueError('node error (%s)' % self.node)
        d = self.detail or {}
        d.update(self.progress(config_id))
        if 'dependency' not in d:
            d['dependency'] = []
        d['status'] = Strategy.get_run_status(self.status)
        d['strategy_type'] = d.get('strategy_type') or self.strategy_type or '99'
        d['strategy_feature'] = d.get('strategy_feature') or self.strategy_feature or '999'
        d['strategy_underlying'] = d.get('strategy_underlying') or self.strategy_underlying or '07'
        d['strategy_para_type'] = ''
        d['strategy_status'] = self.strategy_status or 'NEW'
        if self.is_delete == 1:
            d['status'] = 'DELETE'
        if self.strategy_status == 'NEW':
            d['status'] = 'NEW'
        d['id'] = self.id
        d['node'] = 'back_test'
        d['upload_type'] = self.node
        d['start'] = self.start_date or self.r_create_time.strftime('%Y%m%d')
        d['end'] = time.strftime('%Y%m%d')
        d['strategy_id'] = self.id_no or (self.name.strip().replace(' ', ''))
        d['created_time'] = str(self.r_create_time)
        d['created_date'] = self.r_create_time.strftime('%Y-%m-%d')
        d['creator'] = self.username
        d['hedge'] = self.hedge or ''
        d['hedge_type'] = self.hedge_type or ''
        if config_id > 0:
            d.update(Strategy.get_semi_info(config_id))
        else:
            d['task_id'] = ''
        d['log_path'] = ''
        d['detail'] = {}
        d['detail']['ev_files'] = {}
        d['detail']['paras_files'] = {}
        d['detail']['back_test_pnl'] = self.back_test_output(config_id)
        d['detail']['error_info'] = []

        live_pnl_detail = self.live_pnl_v3()

        d['live_pnl'] = live_pnl_detail['pnl']
        d['live_pnl_detail'] = live_pnl_detail
        d['vs_back_test_pnl'] = self.vs_back_test_pnl(config_id)
        d['papertrading_date'] = (self.paper_trading_date or self.r_create_time).strftime('%Y-%m-%d')
        d['auto_paper_trading'] = self.auto_paper_trading
        d['confidence'] = float(self.confidence)
        if self.node in ('trademaster_order_list',):
            d['so_file_name'] = os.path.basename(self.strategy_upload_file['relative_path']).split('_', 2)[-1]
        else:
            d['so_file_name'] = ''

        if config_id > 0:
            # 18 年 vwap & dma trade_list 相关配置
            quantamental_config_id = BackTestConfig.get_quantamental_cfg_id(config_id)
            if quantamental_config_id > 0:
                quantamental_detail = {
                    'detail': {
                        'back_test_pnl': self.back_test_output(quantamental_config_id),
                    },
                }
                quantamental_detail.update(Strategy.get_semi_info(quantamental_config_id))
                d['quantamental'] = quantamental_detail
                d['progress'] = min([d['progress'], quantamental_detail['progress']])
        return d

    def strategy_group_detail(self, config_id=0, back_id=0):
        if self.node != 'group':
            raise ValueError('node error (%s)' % self.node)
        d = self.detail or {}
        d.update({
            'total': 0,
            'done': 0,
            'finished': 0,
            'failed': 0,
            'stop': 0,
            'running': 0,
            'progress': 0,
        })
        if 'dependency' not in d:
            d['dependency'] = []
        sc = session()
        sc.close()
        d['initial_cash'] = float(self.detail.get('initial_cash', 1000000) or 1000000)
        d['progress'] = 1
        d['is_portfolio'] = True
        d['portfolio_id'] = self.group_id
        d['status'] = Strategy.get_run_status(self.status)
        d['strategy_type'] = d.get('strategy_type') or self.strategy_type or '99'
        d['strategy_feature'] = d.get('strategy_feature') or self.strategy_feature or '999'
        d['strategy_underlying'] = d.get('strategy_underlying') or self.strategy_underlying or '07'
        d['strategy_para_type'] = ''
        d['strategy_status'] = self.strategy_status or 'NEW'
        if self.is_delete == 1:
            d['status'] = 'DELETE'
        if self.strategy_status == 'NEW':
            d['status'] = 'NEW'
        d['id'] = self.id
        d['node'] = 'back_test'
        d['upload_type'] = ''
        d['start'] = self.start_date or self.r_create_time.strftime('%Y%m%d')
        d['end'] = time.strftime('%Y%m%d')
        d['strategy_id'] = self.id_no or (self.name.strip().replace(' ', ''))
        d['created_time'] = str(self.r_create_time)
        d['created_date'] = self.r_create_time.strftime('%Y-%m-%d')
        d['creator'] = self.username
        d['hedge'] = self.hedge or ''
        d['hedge_type'] = self.hedge_type or ''
        d['so_file_name'] = ''
        d['task_id'] = ''
        d['log_path'] = ''
        d['detail'] = {}
        d['detail']['ev_files'] = {}
        d['detail']['paras_files'] = {}
        d['detail']['back_test_pnl'] = self.back_test_output(config_id)
        d['detail']['error_info'] = []
        vstrategies = sc.query(
            VStrategies.id.label('vs_id'),
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            VStrategies.status == consts.STRATEGY_LIVE,
            or_(and_(VStrategies.strategy_id == self.id, VStrategies.group_id == 0), VStrategies.group_id == self.id),
            StrategyPortfolio.status == consts.STRATEGY_LIVE,
            StrategyPortfolio.source == 'platform',
            VStrategies.source == 'platform',
        ).order_by(VStrategies.id.desc())
        _vs_ids = [vs.vs_id for vs in vstrategies]
        live_pnl_detail = self.live_analysis_pnl_grpha(_vs_ids=_vs_ids)
        d['live_pnl'] = live_pnl_detail['live_net_comebine_line']['pnl']
        d['live_pnl_detail'] = live_pnl_detail['live_net_comebine_line']
        d['vs_back_test_pnl'] = {k.replace('vs_back_test_', ''): v for k, v in
                                 live_pnl_detail['vs_back_test_net_comebine_line'].items()}
        d['papertrading_date'] = (self.paper_trading_date or self.r_create_time).strftime('%Y-%m-%d')
        d['auto_paper_trading'] = self.auto_paper_trading
        if back_id > 0:
            d.update(Strategy.get_semi_info(back_id))
        return d

    @staticmethod
    def generate_id_no(user_id, strategy_type, date):
        """
        Generate normalized STRATEGY ID:

        Example:
            MYC01_20_20180706_002            

        """
        date = format_date(date, '-')
        user_id = int(user_id)
        sc = session()
        max_code = sc.query(func.max(Strategy.code).label('max_code')).filter(
            Strategy.r_create_user_id == user_id,
            or_(
                func.date(Strategy.r_create_time) == date,
                func.date(Strategy.paper_trading_date) == date,
            ),
            Strategy.code.isnot(None),
        ).first().max_code
        if not max_code:
            max_code = '001'
        else:
            max_code = str(int(max_code) + 1).zfill(3)
        username = sc.query(Users.name).filter(Users.id == user_id).first().name[:3]
        # TODO: Over complicated method  to get username index, 
        # check if index can be constant '001'. 
        users = sc.query(Users.id).filter(Users.name.ilike('%s%%' % username)).order_by(Users.id)
        users_ids = [u[0] for u in users]
        user_name = (username + str(users_ids.index(user_id) + 1).zfill(2)).upper()
        sc.close()
        return '_'.join([user_name, strategy_type, format_date(date, ''), max_code])

    def progress(self, config_id=0):
        sc = session()
        finished, failed, stop, running = 0, 0, 0, 0
        total, done = 0, 0
        if config_id > 0:
            item = BackTestConfig.get_item(config_id)
            progress = item["progress"]
        else:
            if (self.task_progress or 0) >= 0:
                progress = self.task_progress
            if self.status == consts.TASK_FINISHED:
                progress = 1
        sc.close()
        return {
            'total': total,
            'done': done,
            'finished': finished,
            'failed': failed,
            'stop': stop,
            'running': running,
            'progress': progress or 0,
        }

    def error_info(self, config_id=0):
        errors = []
        sc = session()
        res = sc.query(StrategyResult).filter(
            StrategyResult.strategy_id == self.id,
            StrategyResult.config_id == config_id,
            StrategyResult.status == consts.TASK_FAILED
        ).all()
        for r in res:
            errors.append({
                'task_id': self.id,
                'product': r.product,
                'date': r.date,
                'info': r.detail and r.detail.get('msg', '详情查看服务器日志') or '详情查看服务器日志'
            })
        for e in (self.error or []):
            errors.append(e)
        sc.commit()
        sc.close()
        return errors

    @property
    def user(self):
        with session_context() as sc:
            u = sc.query(Users).filter_by(id=self.r_create_user_id).first()
            return u.to_dict()

    @property
    def strategy_upload_file(self):
        if self.node == 'order_list':
            raise ValueError('node error (%s)' % self.node)
        with session_context() as sc:
            f = sc.query(StrategyUploadFile).filter_by(id=self.strategy_upload_file_id).first()
            return f.to_dict()

    def gen_stock_factor_from_csv(self, *args, **kwargs):
        from cron.strategy_upload_task import ev_task_done, factor_upload_csv_done
        from service.stock_factor.models import StockFactorStrategy
        if kwargs.get('auto', False):
            return True
        sc = session()
        strategy = sc.query(Strategy).filter(Strategy.id == self.id).first()
        error_msg = ''
        try:
            StockFactorStrategy.gen_factor_from_csv(self.id)
            strategy.status = consts.TASK_FINISHED
            r_status = consts.TASK_FINISHED
        except Exception as e:
            sentry.captureException()
            strategy.status = consts.TASK_FAILED
            r_status = consts.TASK_FAILED
            error_msg += traceback.format_exc()
        strategy.task_progress = 1
        d = kwargs['start_date']
        out_put_path = 'strategy_upload/output/%s/%s' % (self.username, self.name.strip().replace(' ', ''))
        d_r = sc.query(StrategyResult).filter_by(strategy_id=self.id, date=d).first()
        if not d_r:
            d_r = StrategyResult(
                strategy_id=self.id,
                config_id=0,
                date=d,
                taskdate=d,
                product='',
                status=r_status
            )
        d_r.done_time = datetime.datetime.now()
        d_r.status = r_status
        if r_status == consts.TASK_FAILED:
            r_detail = {
                'taskid': self.id,
                'return': -1,
                'data': {},
                'date': d,
                'msg': 'script exce error:%s' % error_msg,
                'time': datetime.datetime.now().strftime('%Y%m%d %X'),
            }
            d_r.detail = r_detail
        else:
            d_r.result_file_name = os.path.join(
                out_put_path, 'ev_output_%s_%s_%s.csv' % (d, str(self.id), 'day')
            )
        sc.add(d_r)
        sc.commit()
        sc.close()
        # day_count = (datetime.datetime.now() - parse(kwargs['start_date'])).days
        # factor_evalue = True if day_count >= 60 else False
        # ev_task_done.delay(self.id, factor_evalue=factor_evalue)
        factor_upload_csv_done.delay(self.id)
        return True

    def start_stock_factor_task(self, *args, test_mode=False, **kwargs):
        from cron.strategy_upload_task import ev_task_done, \
            factor_trading_date_done, factor_in_sample_done, factor_out_sample_done, factor_task_done
        # handle csv strategy
        file_ext = self.strategy_upload_file['filename'].rsplit('.', 1)[-1].lower()
        if file_ext == 'csv':
            return self.gen_stock_factor_from_csv(*args, **kwargs)

        config_id = kwargs.get('config_id', 0)
        # task_id = kwargs.get('task_id', self.st_uuid) or ''

        # decide task date range
        start_date = kwargs['start_date']
        now = datetime.datetime.now()
        if now.hour >= 17:
            end_date = Strategy.get_trading_date(hour=17)
            if kwargs.get('auto', False):
                start_date = end_date
        else:
            end_date = max(now.strftime('%Y%m%d'), parse(start_date).strftime('%Y%m%d'))

        if 'end_date' in kwargs:
            end_date = kwargs['end_date']

        sc = session()
        kdb = KdbQuery()

        days = kdb.get_trading_days(start_date, end_date)
        # day_range_size = self.detail.get('day_range_size', 60)
        # day_range = [days[i: i + day_range_size] for i in range(0, len(days), day_range_size)]

        # make sure path exists
        out_put_path = os.path.join(CommonPath.strategy_output, self.username, self.name.strip().replace(' ', ''))
        if test_mode:
            out_put_path = out_put_path.replace("/output", "/output_test")
        if not os.path.exists(out_put_path):
            os.makedirs(out_put_path)

        data_home_path = os.path.join(config.ev_work_path, '%s_%s' % (self.r_create_user_id, self.username))
        if not os.path.exists(data_home_path):
            raise ValueError('can not find path: %s' % data_home_path)

        cwd = os.path.join(data_home_path, 'app_working_dir')
        if not os.path.exists(cwd):
            os.makedirs(cwd)
            os.makedirs(os.path.join(cwd, 'output'))

        log_dir = os.path.join(
            os.path.join(config.ev_work_path, '%s_%s' % (self.r_create_user_id, self.username)),
            'strategy/log/ev',
            self.name.replace(' ', '').replace('/', ''),
        )
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)

        # decide sample date range
        factor_category = int(self.detail.get('factor_category', 0))
        if factor_category == 1:
            sample_start_date = '20070101'
        else:
            if self.detail.get('algorithm', '') == StrategyConstant.DetailAlgorithm.Fundamental.value:
                sample_start_date = '20100101'
            else:
                sample_start_date = '20111201'
        sample_end_date = '20171228'

        # decide days in different period
        day_range = []
        days_in_sample = []
        days_out_sample = []
        other_days = []

        for d in days:
            separate_date = (now - datetime.timedelta(days=10)).strftime('%Y%m%d')
            if sample_start_date <= d <= sample_end_date:
                days_in_sample.append(d)
            elif sample_end_date < d <= separate_date:
                days_out_sample.append(d)
            elif d > separate_date:
                other_days.append([d])
            else:
                pass

        day_range.append(days_in_sample)
        day_range.append(days_out_sample)
        day_range.extend(other_days)

        # find factor dependence
        factors = []
        rely_basic_factor = []
        rely_my_factor = []
        f_ids = [int(p['symbol'].split('_')[2]) for p in self.products[0] if p['type'] == 'stock_factor_FACTOR']
        for f in sc.query(Strategy).filter(Strategy.id.in_(f_ids)):
            if f.detail.get('factor_category', 0) == 1:
                rely_basic_factor.append(f.id)
            else:
                rely_my_factor.append(f.id)

        sc.close()

        for i, d_range in enumerate(day_range):
            if not d_range:
                continue
            d = d_range[0]
            _day_night = 0
            ev_output = os.path.join(
                out_put_path, 'ev_output_%s_%s_%s.csv' % (d, str(self.id), {0: 'day', 1: 'night'}[_day_night])
            )
            log_file = os.path.join(
                log_dir,
                'ev_output_%s_%s_%s.log' % (d, str(self.id), {0: 'day', 1: 'night'}[_day_night])
            )
            try:
                os.system('touch "%s"' % log_file)
            except Exception as e:
                sentry.captureException()

            error_msg = ''
            # init factor producer processing params
            factor_paras = {
                'start_date': d_range[0],
                'end_date': d_range[-1],
                'date': d_range[0],
                'output': os.path.join(config.media, ev_output),
                'day_night': 0,
                'portfolio_optimization_ev_path': '/home/rss/jupyter_userworkspace/media/portfolio_optimization_ev/',
                'log_file': log_file,
                'strategy_id': self.id,
                'factor_id': self.id,
                'factors': factors,
                'notify_api': config.notify_api,
                'rely_basicfactor': rely_basic_factor,
                'rely_myfactor': rely_my_factor,
            }
            # start produce
            try:
                if file_ext == 'py':
                    com_list = ['/usr/bin/python3', self.strategy_upload_file['abs_path'], json.dumps(factor_paras)]
                    output_string = subprocess.check_output(
                        com_list, universal_newlines=True, cwd=cwd, stderr=subprocess.STDOUT
                    )
                elif file_ext == 'so':
                    self.generate_so_factor(factor_paras)

                self.status = consts.TASK_FINISHED
                r_status = consts.TASK_FINISHED
            except subprocess.CalledProcessError as e:
                sentry.captureException()
                error_msg += e.output[-1000:]
                self.status = consts.TASK_FAILED
                r_status = consts.TASK_FAILED
            except Exception as e:
                sentry.captureException()
                error_msg += traceback.format_exc()
                self.status = consts.TASK_FAILED
                r_status = consts.TASK_FAILED
            if test_mode:
                continue

            # TODO: NEED TO IMPROVE: this variable only use when failed.
            r_detail = {
                'taskid': self.id,
                'return': -1,
                'data': {},
                'date': d,
                'msg': 'script execute error:%s' % error_msg,
                'time': datetime.datetime.now().strftime('%Y%m%d %X'),
            }

            sc = session()
            # write result
            for d in d_range:
                d_r = sc.query(StrategyResult).filter_by(strategy_id=self.id, date=d).first()
                if not d_r:
                    d_r = StrategyResult(
                        strategy_id=self.id,
                        config_id=config_id,
                        date=d,
                        taskdate=d,
                        product='',
                        status=r_status
                    )
                    sc.add(d_r)
                d_r.done_time = datetime.datetime.now()
                d_r.status = r_status
                if r_status == consts.TASK_FAILED:
                    d_r.detail = r_detail
                else:
                    d_r.result_file_name = os.path.join(
                        out_put_path, 'ev_output_%s_%s_%s.csv' % (d, str(self.id), 'day')
                    )
                sc.commit()
            sc.close()

            if i == 0 and (len(d_range) >= 100):
                task_progress = float(len(day_range[0])) / len(days)
                factor_out_sample_done.delay(self.id, d_range[-1], factor_category=factor_category,
                                             task_progress=task_progress)

            if i == 1 and (len(d_range) >= 200):
                task_progress = float(len(day_range[0]) + len(day_range[1])) / len(days)
                factor_in_sample_done.delay(self.id, d_range[-1], factor_category=factor_category,
                                            task_progress=task_progress)

            if i >= 2:
                task_progress = float((days.index(d_range[0]) + 1)) / len(days)
                factor_trading_date_done.delay(self.id, d, factor_category=factor_category, task_progress=task_progress)

        del_cache('platform_strategy_brief_%s_0_0' % self.id)
        del_cache('platform_strategy_detail_%s_0_0' % self.id)
        del_cache('platform_strategy_output_%s_0' % self.id)

        # ev_task_done.delay(self.id, s_status=self.status)

        do_simulator = False
        if len(days) > 20:
            do_simulator = True
        factor_task_done.delay(self.id, s_status=self.status, do_simulator=do_simulator)

        return True

    def get_ev_task_paras(self, *args, test_mode=False, **kwargs):
        config_id = 0
        start_date = kwargs['start_date']

        now = datetime.datetime.now()
        if now.hour >= 17:
            end_date = Strategy.get_trading_date(hour=17)
            if kwargs.get('auto', False):
                start_date = end_date
        else:
            end_date = max(now.strftime('%Y%m%d'), parse(start_date).strftime('%Y%m%d'))

        if 'end_date' in kwargs:
            end_date = kwargs['end_date']

        if kwargs.get('auto', False):
            day_night = kwargs.get('day_night', -1)
            if self.day_night in (0, 1):
                day_night = self.day_night

            if day_night == -1:
                if 0 <= now.hour <= 16:
                    day_night = 0
                elif 17 <= now.hour <= 21:
                    day_night = 1
                else:
                    raise ValueError('day night error')
        else:
            day_night = self.day_night
        day_nights = [1, 0] if day_night == 2 else [day_night]

        kdb = KdbQuery()
        days = kdb.get_trading_days(start_date, end_date)
        if self.is_test:
            days = days[:10]

        out_put_path = 'strategy_upload/output/%s/%s' % (self.username, self.name.strip().replace(' ', ''))
        if test_mode:
            out_put_path = out_put_path.replace("/output", "/output_test")
        if not os.path.exists(os.path.join(config.media, out_put_path)):
            os.makedirs(os.path.join(config.media, out_put_path))

        log_dir = os.path.join(
            os.path.join(config.ev_work_path, '%s_%s' % (self.r_create_user_id, self.username)),
            'strategy/log/ev',
            self.name.replace(' ', '').replace('/', ''),
        )
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)

        data_home_path = os.path.join(config.ev_work_path, '%s_%s' % (self.r_create_user_id, self.username))

        if not os.path.exists(data_home_path):
            raise ValueError('can not find path: %s' % data_home_path)

        cwd = os.path.join(data_home_path, 'app_working_dir')

        if not os.path.exists(cwd):
            os.makedirs(cwd)
            os.makedirs(os.path.join(cwd, 'output'))
            os.symlink(os.path.join(config.renv, 'qserver.so'), os.path.join(cwd, 'qserver.so'))
            os.symlink(os.path.join(config.renv, 'qserver.R'), os.path.join(cwd, 'qserver.R'))

        paras = {
            'config_id': config_id,
            'start_date': start_date,
            'end_date': end_date,
            'day_night': day_night,
            'day_nights': day_nights,
            'days': days,
            'out_put_path': out_put_path,
            'log_dir': log_dir,
            'cwd': cwd,
        }

        return paras

    def start_ev_task_v3(self, *args, test_mode=False, **kwargs):
        """
        ev 生产程序
        :param args:
        :param test_mode: 测试模式 会把output改成output_test
        :param kwargs:
        :return:
        """
        from cron.strategy_upload_task import ev_trading_date_done, ev_task_done
        # produce stock factor
        if self.strategy_type == '26' and self.detail.get('new_factor_strategy'):
            return self.start_stock_factor_task(*args, test_mode=test_mode, **kwargs)

        ev_task_paras = self.get_ev_task_paras(*args, test_mode=test_mode, **kwargs)
        config_id = ev_task_paras['config_id']
        # start_date = ev_task_paras['start_date']
        # end_date = ev_task_paras['end_date']
        # day_night = ev_task_paras['day_night']
        day_nights = ev_task_paras['day_nights']
        days = ev_task_paras['days']
        out_put_path = ev_task_paras['out_put_path']
        log_dir = ev_task_paras['log_dir']
        cwd = ev_task_paras['cwd']
        sc = session()

        self.set_ev_running()
        for index, d in enumerate(days):
            if self.is_ev_stop():
                logger.info('%s %s ev_task stop!!' % (self.id, self.st_uuid))
                break

            r = sc.query(StrategyResult).filter_by(strategy_id=self.id, config_id=config_id, date=d).first()
            file_ext = self.strategy_upload_file['filename'].rsplit('.', 1)[-1].lower()
            # TODO: NEED TO ABSTRACT: extract file ext
            # TODO: NEED TO IMPROVE: do not extract file ext every loop
            if file_ext in ('py', 'r', 'so'):
                ev_outputs = []
                error_msg = ''
                for _day_night in day_nights:
                    ev_output = os.path.join(
                        out_put_path, 'ev_output_%s_%s_%s.csv' % (d, str(self.id), {0: 'day', 1: 'night'}[_day_night])
                    )

                    log_file = os.path.join(
                        log_dir, 'ev_output_%s_%s_%s.log' % (d, str(self.id), {0: 'day', 1: 'night'}[_day_night])
                    )

                    try:
                        os.system('touch "%s"' % log_file)
                    except Exception as e:
                        sentry.captureException()

                    select_paras = {
                        'date': format_date(d, origin_split=''),
                        'output': os.path.join(config.media, ev_output),
                        'day_night': _day_night,
                        'portfolio_optimization_ev_path': '/home/rss/jupyter_userworkspace/media/portfolio_optimization_ev/',
                        'log_file': log_file,
                        'strategy_id': self.id,
                        'notify_api': config.notify_api,
                    }
                    # start produce
                    try:
                        if file_ext == 'py':
                            if self.r_create_time.strftime('%Y%m%d') >= '20180314':
                                com_list = ['/usr/bin/python3', self.strategy_upload_file['abs_path'],
                                            json.dumps(select_paras)]
                            else:
                                com_list = ['python2', self.strategy_upload_file['abs_path'], json.dumps(select_paras)]
                            output_string = subprocess.check_output(com_list, universal_newlines=True, cwd=cwd,
                                                                    stderr=subprocess.STDOUT)
                        elif file_ext == 'r':
                            com_list = ['Rscript', self.strategy_upload_file['abs_path'], json.dumps(select_paras)]
                            output_string = subprocess.check_output(com_list, universal_newlines=True, cwd=cwd,
                                                                    stderr=subprocess.STDOUT)
                        elif file_ext == 'so':
                            self.generate_so_ev(select_paras, **ev_task_paras)

                        self.status = consts.TASK_FINISHED
                        ev_outputs.append(ev_output)

                        if self.id in consts.portfolio_optimization_ev_name and _day_night == 0:
                            ev_name_tmp = consts.portfolio_optimization_ev_name[self.id]
                            dst = os.path.join(
                                config.media, 'portfolio_optimization_ev', ev_name_tmp % d
                            )
                            shutil.copy(select_paras['output'], dst)
                            shutil.copy(select_paras['output'], os.path.join(
                                config.ev_work_path, 'stock_group_share/portfolio_optimization_ev', ev_name_tmp % d
                            ))
                    except subprocess.CalledProcessError as e:
                        sentry.captureException()
                        error_msg += e.output[-1000:]
                    except Exception as e:
                        sentry.captureException()
                        error_msg += traceback.format_exc()
                    if test_mode:
                        continue

                    ev_trading_date_done.delay(self.id, d, _day_night, task_progress=float((index + 1)) / len(days))
                if test_mode:
                    return

                if not r:
                    r = StrategyResult(
                        strategy_id=self.id,
                        config_id=config_id,
                        date=d,
                        taskdate=d,
                        product='',
                        status=self.status
                    )
                r.done_time = datetime.datetime.now()
                if not ev_outputs:
                    self.status = consts.TASK_FAILED
                    r.detail = {
                        'taskid': self.id,
                        'return': -1,
                        'data': {},
                        'date': d,
                        'msg': 'script exce error:%s' % error_msg,
                        'time': datetime.datetime.now().strftime('%Y%m%d %X'),
                    }
                    r.status = self.status
                else:
                    self.status = consts.TASK_FINISHED
                    if r.result_file_name:
                        ev_outputs.extend(r.result_file_name.split('|'))
                    r.status = consts.TASK_FINISHED
                    r.result_file_name = '|'.join(sorted(set(ev_outputs)))
                sc.add(r)
                sc.commit()

        del_cache('platform_strategy_brief_%s_0_0' % self.id)
        del_cache('platform_strategy_detail_%s_0_0' % self.id)
        del_cache('platform_strategy_output_%s_0' % self.id)
        ev_task_done.delay(self.id, s_status=self.status)
        sc.close()
        return True

    def generate_so_ev(self, cfg, **kwargs):

        so_path = os.path.join(config.media, self.strategy_upload_file['relative_path'])
        cwd = kwargs['cwd']
        so_cwd = os.path.join(cwd, 'ev_so_%s' % self.id)
        if not os.path.exists(so_cwd):
            os.makedirs(so_cwd)

        so_symbol_link = os.path.join(so_cwd, 'ev_generation.so')
        # if os.path.exists(so_symbol_link):
        #     os.remove(so_symbol_link)
        # os.symlink(so_path, so_symbol_link)

        # if os.path.islink(so_symbol_link):
        #    if os.readlink(so_symbol_link) != so_path:
        #        os.remove(so_symbol_link)
        #        os.symlink(so_path, so_symbol_link)
        # else:
        #    os.symlink(so_path, so_symbol_link)
        symlink_insurance(so_path, so_symbol_link)

        init_py = os.path.join(so_cwd, '__init__.py')
        if not os.path.exists(init_py):
            with open(init_py, 'w') as f:
                pass

        codestr = """
import sys
import json
from {ev} import ev_generation

if __name__ == '__main__':
    cfg = json.loads(sys.argv[1])
    out_put = ev_generation.generate_strategy_config(cfg)
    """.format(**{'ev': 'ev_so_%s' % self.id})

        strategy_py = os.path.join(cwd, 'ev_generation_%s.py' % self.id)

        with open(strategy_py, 'w') as f:
            f.write(codestr)

        com_list = ['/usr/bin/python3', strategy_py, json.dumps(cfg)]
        output_string = subprocess.check_output(com_list, universal_newlines=True, cwd=cwd, stderr=subprocess.STDOUT)

    def generate_so_factor(self, cfg, **kwargs):

        so_path = os.path.join(config.media, self.strategy_upload_file['relative_path'])
        data_home_path = os.path.join(config.ev_work_path, '%s_%s' % (self.r_create_user_id, self.username))
        if not os.path.exists(data_home_path):
            raise ValueError('can not find path: %s' % data_home_path)

        cwd = os.path.join(data_home_path, 'app_working_dir')
        if not os.path.exists(cwd):
            os.makedirs(cwd)
            os.makedirs(os.path.join(cwd, 'output'))

        so_cwd = os.path.join(cwd, 'ev_so_%s' % self.id)
        if not os.path.exists(so_cwd):
            os.makedirs(so_cwd)

        so_symbol_link = os.path.join(so_cwd, 'ev_generation.so')

        # if os.path.exists(so_symbol_link):
        #     os.remove(so_symbol_link)
        # os.symlink(so_path, so_symbol_link)

        # if os.path.islink(so_symbol_link):
        #     if os.readlink(so_symbol_link) != so_path:
        #         os.remove(so_symbol_link)
        #         os.symlink(so_path, so_symbol_link)
        # else:
        #     os.symlink(so_path, so_symbol_link)
        symlink_insurance(so_path, so_symbol_link)

        init_py = os.path.join(so_cwd, '__init__.py')
        if not os.path.exists(init_py):
            with open(init_py, 'w') as f:
                pass

        codestr = """
import sys
import json
from {ev} import ev_generation

if __name__ == '__main__':
    cfg = json.loads(sys.argv[1])
    out_put = ev_generation.generate_strategy_config(cfg)
    """.format(**{'ev': 'ev_so_%s' % self.id})

        strategy_py = os.path.join(cwd, 'ev_generation_%s.py' % self.id)

        with open(strategy_py, 'w') as f:
            f.write(codestr)

        com_list = ['/usr/bin/python3', strategy_py, json.dumps(cfg)]
        output_string = subprocess.check_output(com_list, universal_newlines=True, cwd=cwd,
                                                stderr=subprocess.STDOUT)

    @property
    def is_new_so(self):
        """
        Check if so file is a new version strategy.

        check so's exported symbols to see if it got my_on_book.
        """
        cmd = 'nm -gC "%s"| grep my_on_book' % (os.path.join(config.media, self.strategy_upload_file['relative_path']))
        output = subprocess.getoutput(cmd)
        return output.strip() != ''

    @property
    def is_foregin_strategy(self):
        if not self.products:
            return False
        if set(p.get('exch') for p in self.products[0]) & set(consts.FOREIGN_EXCHANGE):
            return True
        return False

    @property
    def is_single_interest(self):
        return self.detail.get('single_interest', False)

    # @staticmethod
    # def is_single_interest_strategy(s_id):
    #     s_ids = Strategy.get_single_interest_strategy_ids() or []
    #     return s_id in s_ids

    @staticmethod
    def set_single_interest(s_id=None, id_no=''):
        sc = session()
        try:
            # sc = session()
            s = None
            if s_id:
                s = sc.query(Strategy).filter(Strategy.id == s_id).first()
            if (not s) and id_no:
                s = sc.query(Strategy).filter(Strategy.id_no == id_no).first()

            # _single_interest = False
            if s and (s.strategy_type in consts.stock_strategy_type):
                s_d = copy.deepcopy(s.detail)
                if not s_d.get('single_interest', False):
                    s_d['single_interest'] = True
                    s.detail = s_d
                    sc.commit()
                    # _single_interest = True

            # sc.close()

            # if _single_interest:
            #     Strategy.get_single_interest_strategy_ids(cache=False)
        except Exception as e:
            sentry.captureException()
            sc.close()
            return False

        sc.close()
        return True

    # @staticmethod
    # def get_single_interest_strategy_ids(cache=True):
    #     cache_key = 'single_interest_strategy_ids'
    #     if cache:
    #         data = get_cache(cache_key)
    #         if data:
    #             return data
    #     sc = session()
    #     rows = sc.query(
    #         Strategy
    #     ).filter(
    #         Strategy.node == 'back_test',
    #         Strategy.is_delete == 0,
    #         Strategy.is_test == 0,
    #         Strategy.strategy_type.in_(consts.stock_strategy_type)
    #     )
    #     data = []
    #     for s in rows:
    #         if s.detail.get('single_interest'):
    #             data.append(s.id)
    #     set_cache(cache_key, data, 86400)
    #     return data

    def get_factor_book(self):
        from service.stock_factor.models import StockFactorStrategyColumns
        if not self.products:
            return ''
        factor_book = {}
        for _p in self.products[0]:
            if _p['type'] == 'stock_factor_FACTOR':
                factor_info = _p['symbol'].split('_')
                factor_id = int(factor_info[2])
                factor_col = factor_info[3]
                f_book = factor_book.setdefault(factor_id, [])
                f_book.append(factor_col)

        factor_book_task = []
        for f_id, cols in factor_book.items():
            f_columns = StockFactorStrategyColumns.get_factor_columns(f_id)
            if 'ALL' in cols:
                factor_book_task.append(
                    {'id': f_id, 'columns': f_columns, 'indexes': list(range(len(f_columns))),
                     'total_num': len(f_columns)}
                )
            else:
                book_col = []
                book_col_index = []
                for _i, _c in enumerate(f_columns):
                    if _c in cols:
                        book_col.append(_c)
                        book_col_index.append(_i)
                factor_book_task.append(
                    {'id': f_id, 'columns': book_col, 'indexes': book_col_index, 'total_num': len(f_columns)}
                )
        if not factor_book_task:
            return ''
        return json.dumps(factor_book_task)

    def new_strategy_back_test(self, **kwargs):
        from cron.strategy_upload_task import redo_strategy_papertrading
        from service.stock_factor.models import StockFactorStrategyColumns
        from service.statistic.models import StrategyIncomeAttribution

        product_portfolios = self.products or []
        task_id = kwargs['task_id']
        config_id = kwargs['config_id']
        initial_cash = kwargs['init_cash']
        start_date = kwargs['start_date']
        end_date = kwargs['end_date']
        trade_model = kwargs['trade_model']
        accounts = kwargs.get('accounts', {})

        Strategy.add_strategy_event(
            self.id,
            start_date,
            TradingTimeRange.Day.value,
            StrategyEventTrackConstant.Event.PrepareStrategyTask.value,
            task_id=task_id
        )

        if accounts and ('accounts' not in accounts):
            accounts = {
                'accounts': {},
                'exchanges': {},
            }
            # A bi-directional dict is duplicated and tricky.
            for a, a_d in kwargs['accounts'].items():
                accounts['accounts'][a] = a_d
                for e in a_d['exchange']:
                    accounts['exchanges'][e] = a

        if self.is_test > 0:
            product_portfolios = product_portfolios[:1]
            today = datetime.datetime.now()
            start_date = (today - datetime.timedelta(10)).strftime("%Y%m%d")
            end_date = today.strftime("%Y%m%d")

        sc = session()
        depend = []
        depend_ev = []
        for dep in (self.dependency or []):
            # dep_s = sc.query(Strategy).filter_by(id=dep['id']).first()
            # dep_out_put = dep_s.output(config_id)
            if dep['type'] == 'ev':
                dep_s = sc.query(Strategy).filter_by(id=dep['id']).first()
                dep_out_put = dep_s.output(config_id)
                depend.append(dep_out_put)
                depend_ev.append('strategy_upload/output/%s/%s/ev_output_%s_%s_[DAYNIGHT].csv' % (
                    dep_s.username, dep_s.name.strip().replace(' ', ''), '[DATE]', str(dep_s.id)
                ))

        # TODO: not used anymore ?
        if self.strategy_type == '98':
            depend_ev.append('strategy_upload/output/%s/%s/ev_output_%s_%s.csv' % (
                self.username, str(self.id), '[DATE]', str(self.id)))

        begin_end_time = consts.BEGIN_END_TIME[self.day_night]
        is_hsa = False
        default_account = 'testaccount1'
        if accounts:
            default_account = list(accounts['accounts'].keys())[0]

        def get_symbol_account(exch):
            if accounts:
                if exch in consts.STOCK_EXCHANGE:
                    for e in ([exch] + consts.STOCK_EXCHANGE):
                        if e in accounts['exchanges']:
                            return accounts['exchanges'][e]
                    return default_account
                else:
                    return accounts['exchanges'].get(exch, default_account)
            else:
                return default_account

        quote_source = '0'
        if self.strategy_type == '23':
            quote_source = 'whole'

        factor_book = {}
        se_factor_book = {}
        for product_portfolio in product_portfolios[:1]:
            products, contracts, yesterday_pos, today_pos = [], [], [], []
            for _p in product_portfolio:
                products.append(_p['symbol'])
                # if _p['exch'] in consts.BTC_EXCHANGE:
                #     ranks = ''
                #     mitype = '58'
                #     contracts.append('|'.join(
                #         [_p['symbol'], ranks, _p['exch'], mitype, str(self.max_pos), quote_source,
                #          get_symbol_account(_p['exch'])]
                #     ))
                if (_p['type'] == 'futures') or (_p['exch'] == 'IDEALPRO'):
                    if _p['exch'] in ('LME', 'IDEALPRO'):
                        ranks = ''
                    else:
                        ranks = ','.join(['R%s' % i for i in sorted(_p['rank'])])
                    if str(self.detail.get('quote_deepth', '1')) == '0' and _p['exch'] in consts.FUTURE_EXCHANGE:
                        mitype = '12'
                    else:
                        mitype = get_mitype(_p['exch'])
                    contracts.append('|'.join(
                        [_p['symbol'], ranks, _p['exch'], mitype, str(self.max_pos), quote_source,
                         get_symbol_account(_p['exch'])]
                    ))
                elif _p['type'] == 'stock':
                    mi_type = get_mitype(_p['exch'])
                    if _p['symbol'][-3:].upper() in ['.SH', '.SZ']:
                        mi_type = get_mitype('SSE_SZSE_INDEX')
                    else:
                        if self.strategy_type == '188':
                            mi_type = mi_type + ',54'
                    contracts.append('|'.join(
                        [_p['symbol'], '', _p['exch'], mi_type, str(self.max_pos), '0', get_symbol_account(_p['exch'])]
                    ))

                    transaction_quote = [str(_x) for _x in self.detail.get('transaction_quote', [])]
                    if '1' in transaction_quote:
                        contracts.append('|'.join(
                            [_p['symbol'], '', _p['exch'], 54, str(self.max_pos), '0', get_symbol_account(_p['exch'])]))
                    if '2' in transaction_quote:
                        contracts.append('|'.join(
                            [_p['symbol'], '', _p['exch'], 53, str(self.max_pos), '0', get_symbol_account(_p['exch'])]))
                    if '3' in transaction_quote:
                        contracts.append('|'.join(
                            [_p['symbol'], '', _p['exch'], 52, str(self.max_pos), '0', get_symbol_account(_p['exch'])]))
                elif _p['type'] == 'stock_factor_FACTOR':
                    factor_info = _p['symbol'].split('_')
                    factor_id = int(factor_info[2])
                    factor_col = factor_info[3]
                    f_book = factor_book.setdefault(factor_id, [])
                    f_book.append(factor_col)
                elif _p['type'] == 'stock_factor_POSITION':
                    contracts.append('81|0|%s|' % (_p['symbol'].rsplit('_', 1)[-1]))
                elif _p['type'] == 'index':
                    if _p['symbol'] == 'HSA':
                        is_hsa = True
                    transaction_quote = [str(_x) for _x in self.detail.get('transaction_quote', [])]
                    if '1' in transaction_quote:
                        contracts.append('%s|I|54|%s' % (_p['symbol'], get_symbol_account('SSE')))
                    if '2' in transaction_quote:
                        contracts.append('%s|I|53|%s' % (_p['symbol'], get_symbol_account('SSE')))
                    if '3' in transaction_quote:
                        contracts.append('%s|I|52|%s' % (_p['symbol'], get_symbol_account('SSE')))

                    if self.strategy_type == '188':
                        contracts.append('%s|I+|%s' % (_p['symbol'], get_symbol_account('SSE')))
                    else:
                        contracts.append('%s|I|%s' % (_p['symbol'], get_symbol_account('SSE')))
                elif _p['type'] == 'spot':
                    contracts.append('|'.join(
                        [
                            _p['symbol'], '', _p['exch'], get_mitype(_p['exch']),
                            str(self.max_pos), quote_source, get_symbol_account(_p['exch'])
                        ]
                    ))
                else:
                    raise ValueError('product type (%s, %s) error' % (_p['symbol'], _p['type']))

            config_type = 0
            if self.id > 208596:
                config_type = 1
            if self.strategy_type in consts.t0_stock_strategy_type:
                config_type = 2

            smart_execution_so_path = ''
            smart_execution_ev = ''
            se_contracts = []

            if self.detail.get('vwap_version'):
                smart_execution_strategy = sc.query(Strategy).join(
                    StockSmartExecutionVersion, StockSmartExecutionVersion.strategy_id == Strategy.id
                ).filter(
                    StockSmartExecutionVersion.value == self.detail['vwap_version']
                ).first()
                if smart_execution_strategy:
                    smart_execution_ev = []
                    for _dep in (smart_execution_strategy.dependency or []):
                        # _dep_s = sc.query(Strategy).filter_by(id=_dep['id']).first()
                        if _dep['type'] == 'ev':
                            _dep_s = sc.query(Strategy).filter_by(id=_dep['id']).first()
                            smart_execution_ev.append('strategy_upload/output/%s/%s/ev_output_%s_%s_[DAYNIGHT].csv' % (
                                _dep_s.username, _dep_s.name.strip().replace(' ', ''), '[DATE]', str(_dep_s.id)
                            ))
                    smart_execution_ev = '|'.join(smart_execution_ev)
                    smart_execution_so_path = smart_execution_strategy.strategy_upload_file['relative_path']
                    for p_portfolio in smart_execution_strategy.products[:1]:
                        for _p in p_portfolio:
                            if _p['type'] == 'futures':
                                ranks = ','.join(['R%s' % i for i in sorted(_p['rank'])])
                                if str(smart_execution_strategy.detail.get('quote_deepth', '1')) == '0' and _p[
                                    'exch'] in consts.FUTURE_EXCHANGE:
                                    mitype = '12'
                                else:
                                    mitype = get_mitype(_p['exch'])

                                se_contracts.append('|'.join(
                                    [_p['symbol'], ranks, _p['exch'], mitype, '1000000', quote_source,
                                     get_symbol_account(_p['exch'])]
                                ))
                            elif _p['type'] == 'stock':
                                mi_type = get_mitype(_p['exch'])
                                if _p['symbol'][-3:].upper() in ['.SH', '.SZ']:
                                    mi_type = get_mitype('SSE_SZSE_INDEX')
                                se_contracts.append('|'.join(
                                    [_p['symbol'], '', _p['exch'], mi_type, '1000000', '0',
                                     get_symbol_account(_p['exch'])]
                                ))
                            elif _p['type'] == 'index':
                                if _p['symbol'] == 'HSA':
                                    is_hsa = True
                                transaction_quote = [str(_x) for _x in self.detail.get('transaction_quote', [])]
                                if '1' in transaction_quote:
                                    se_contracts.append('%s|I|54|%s' % (_p['symbol'], get_symbol_account('SSE')))
                                if '2' in transaction_quote:
                                    se_contracts.append('%s|I|53|%s' % (_p['symbol'], get_symbol_account('SSE')))
                                if '3' in transaction_quote:
                                    se_contracts.append('%s|I|52|%s' % (_p['symbol'], get_symbol_account('SSE')))

                                se_contracts.append('%s|I|%s' % (_p['symbol'], get_symbol_account('SSE')))
                            elif _p['type'] == 'stock_factor_FACTOR':
                                factor_info = _p['symbol'].split('_')
                                factor_id = int(factor_info[2])
                                factor_col = factor_info[3]
                                f_book = se_factor_book.setdefault(factor_id, [])
                                f_book.append(factor_col)
                            elif _p['type'] == 'stock_factor_POSITION':
                                se_contracts.append('81|0|%s|' % (_p['symbol'].rsplit('_', 1)[-1]))
                            else:
                                pass

            factor_book_task = []
            se_factor_book_task = []
            for f_id, cols in factor_book.items():
                contracts.append('80|0|%s|' % f_id)
                f_columns = StockFactorStrategyColumns.get_factor_columns(f_id)
                if 'ALL' in cols:
                    factor_book_task.append(
                        {
                            'id': f_id,
                            'columns': f_columns,
                            'indexes': list(range(len(f_columns))),
                            'total_num': len(f_columns)
                        }
                    )
                else:
                    book_col = []
                    book_col_index = []
                    for _i, _c in enumerate(f_columns):
                        if _c in cols:
                            book_col.append(_c)
                            book_col_index.append(_i)
                    factor_book_task.append(
                        {
                            'id': f_id,
                            'columns': book_col,
                            'indexes': book_col_index,
                            'total_num': len(f_columns)
                        }
                    )

            for f_id, cols in se_factor_book.items():
                se_contracts.append('80|0|%s|' % f_id)
                f_columns = StockFactorStrategyColumns.get_factor_columns(f_id)
                if 'ALL' in cols:
                    se_factor_book_task.append(
                        {
                            'id': f_id,
                            'columns': f_columns,
                            'indexes': list(range(len(f_columns))),
                            'total_num': len(f_columns)
                        }
                    )
                else:
                    book_col = []
                    book_col_index = []
                    for _i, _c in enumerate(f_columns):
                        if _c in cols:
                            book_col.append(_c)
                            book_col_index.append(_i)
                    se_factor_book_task.append(
                        {
                            'id': f_id,
                            'columns': book_col,
                            'indexes': book_col_index,
                            'total_num': len(f_columns)
                        }
                    )

            if (self.strategy_type in consts.stock_strategy_type) and (int(self.detail.get('alpha_s_id', 0) or 0) > 0):
                contracts.append('81|0|%s|' % self.detail['alpha_s_id'])

            income_attribution = {}
            if self.strategy_type in consts.stock_strategy_type:
                income_attribution = StrategyIncomeAttribution.get_back_test_income_attribution_adjusted(
                    self.id, start_date=start_date
                )

            master_weight = {}
            if self.detail.get('predict_s_ids', []):
                w = 1.0 / len(self.detail['predict_s_ids'])
                for w_s_i in self.detail['predict_s_ids']:
                    master_weight[w_s_i] = w

            task_cmd = {
                'reserve_type': 1,
                'db_conf': ','.join([config.KDB_HOST, str(config.KDB_PORT), config.KDB_USER, config.KDB_PASSWD]),
                'type': 110,
                'business': 0 if not kwargs.get('auto') else 1,
                'is_test': 1 if self.is_test else 0,
                'start_date': int(start_date),
                'end_date': int(end_date),
                'begin_time': begin_end_time['begin_time'],
                'end_time': begin_end_time['end_time'],
                'day_night_flag': self.day_night,
                'paper_trading_date': self.paper_trading_date.strftime('%Y%m%d'),
                'agent': '',
                'task_id': task_id,
                'user': self.username,
                'user_id': self.r_create_user_id,
                'flag_write_tunnel_log': False,
                'flag_write_strat_log': True,
                'flag_cross_day_position': True,
                'load_symbol_from_tradelist': self.detail.get('load_ev_config', False),
                'max_accum_open_vol': 1000000,
                'trader_type': 1,
                'match_type': 1,
                'plugins': [],
                'write_publish': True,
                'match_param': consts.COMMON_MATCH_PARAM,
                'sell_stock_short': self.detail.get('stock_loan', False),
                'so_path': [self.strategy_upload_file['relative_path']],
                # 'btc_simulation': self.is_btc_strategy,
                'config_type': config_type,
                'portfolio_optimization_model_version': StockPortfolioOptimizationVersion.get_paras(
                    self.detail.get('portfolio_optimization_so_version', '')
                ),
                'vwap_version': self.detail.get('vwap_version', 'v1') or 'v1',
                'portfolio_optimization_ev_path': '/mnt/share_media/portfolio_optimization_ev/',
                'smart_execution_so_path': smart_execution_so_path,
                'smart_execution_ev': smart_execution_ev,
                'se_item': {
                    'smart_execution_so_path': smart_execution_so_path,
                    'smart_execution_ev': smart_execution_ev,
                    'contracts': se_contracts,
                    'factor_book': se_factor_book_task,
                    'se_cash': initial_cash * self.detail.get('se_cash_rate', 0),
                },
                'income_attribution': income_attribution,
                'master_weight': master_weight,
                'factor_book': factor_book_task,
                'strat_item': [{
                    'strat_name': self.id_no or (self.name.strip().replace(' ', '')),
                    'strat_id': self.id,
                    'contracts': contracts,
                    'strat_param_file': '|'.join(depend_ev),
                    'output_file_path': './output/%s/%s' % (self.id_no, task_id),
                    'pos_contracts': [],
                    'cash_limit': [],
                    'factor_book': factor_book_task,
                }],
                'settlement_kwargs': {
                    'config_id': config_id,
                    'hedge': self.hedge or '',
                    'hedge_type': self.hedge_type or '',
                    # 'is_btc_strategy': self.is_btc_strategy,
                    'is_foregin_strategy': self.is_foregin_strategy,
                    'strategy_type': Strategy.convert_strategy_type(self.strategy_type),
                    'single_interest': self.detail.get('single_interest', False),
                    'is_hk_stock': self.strategy_type in ('27', '28'),
                    'stock_fee_rate': self.detail.get('stock_fee_rate', 0),
                },
                'unrealized_corp_data': self.get_unrealized_corp_items(start_date, config_id),
                'is_hk_strategy': self.strategy_type in ('27', '28'),
                "is_union_simu": False,
            }

            if len(task_cmd['portfolio_optimization_model_version']) > 31:
                task_cmd['reserve_type'] = 2

            if factor_book_task:
                task_cmd['reserve_type'] = 3

            optional_module = self.detail.get('modules', '[]')
            if 'VWAP' in optional_module:
                task_cmd['plugins'].append('vwap')

            task_cmd['strat_item'][0]['trade_model'] = trade_model
            time_interval = int(float(self.detail.get('time_interval', 0)))
            if accounts:
                kdb = KdbQuery()
                forex_rate = kdb.get_forex_rate(start_date)
                # if not self.is_btc_strategy:
                #     forex_rate = kdb.get_forex_rate(start_date)
                # else:
                #     forex_rate = {
                #         acc_cash_detail['currency'].lower(): 1
                #         for _, acc_cash_detail in accounts['accounts'].items()
                #     }
                task_cmd['strat_item'][0]['accounts'] = [
                    '|'.join(
                        [
                            _acc,
                            str(acc_cash_detail['cash'] / forex_rate[acc_cash_detail['currency'].lower()]),
                            str(acc_cash_detail['cash'] / forex_rate[acc_cash_detail['currency'].lower()]),
                            acc_cash_detail['currency'].upper(),
                            str(forex_rate[acc_cash_detail['currency'].lower()])
                        ])
                    for _acc, acc_cash_detail in accounts['accounts'].items()
                ]
            else:
                task_cmd['strat_item'][0]['accounts'] = [
                    '|'.join([default_account, str(initial_cash), str(initial_cash), 'CNY', '1.0'])
                ]

            if time_interval > 0:
                task_cmd['time_interval'] = time_interval

            # get yesterday_pos from previous result under PT
            if kwargs.get('auto') and (kwargs['auto'] is True):
                res = sc.query(StrategyResult).filter(StrategyResult.strategy_id == self.id,
                                                      StrategyResult.config_id == config_id,
                                                      StrategyResult.status == consts.TASK_FINISHED,
                                                      StrategyResult.date < start_date
                                                      ).order_by(StrategyResult.date.desc()).first()
                position = {}
                if res is not None:
                    for r in res.detail:
                        # overwrite by latest result
                        if int(r['day_night']) != 0:
                            continue
                        if r['long_volume'] + r['short_volume'] > 0:
                            position[r['symbol']] = '|'.join(map(str, [
                                r['symbol'], int(r['long_volume']), r['long_price'], int(r['short_volume']),
                                r['short_price'], r.get('account', default_account) or default_account,
                            ]))
                        else:
                            continue
                        exchange = consts.EXCHANGE[chr(r['exchange'])]

                        if exchange == 'ICEU' and r['symbol'][:1].upper() == 'B' and (
                                exchange not in accounts['exchanges']) and ('ICEE' in accounts['exchanges']):
                            exchange = 'ICEE'

                        if exchange in (consts.FUTURE_EXCHANGE + consts.FOREIGN_EXCHANGE) and r['long_volume'] + r[
                            'short_volume'] > 0:
                            if str(self.detail.get('quote_deepth', '1')) == '0' and exchange in consts.FUTURE_EXCHANGE:
                                mi_type = '12'
                            else:
                                mi_type = get_mitype(exchange)
                            contract = '|'.join([r['symbol'], '', exchange, mi_type, str(self.max_pos), quote_source,
                                                 get_symbol_account(exchange)])
                            task_cmd['strat_item'][0]['pos_contracts'].append(contract)
                        elif exchange in consts.STOCK_EXCHANGE and not is_hsa:
                            mi_type = '9'
                            # Here don't need to add other contracts if HSA. modify cxwen
                            if self.strategy_type == '188':
                                mi_type = '9,54'
                            contract = '|'.join([r['symbol'], '', exchange, mi_type, str(self.max_pos), '0',
                                                 get_symbol_account(exchange)])
                            task_cmd['strat_item'][0]['pos_contracts'].append(contract)

                        # if exchange in consts.BTC_EXCHANGE:
                        #     mi_type = '58'
                        #     contract = '|'.join([r['symbol'], '', exchange, mi_type, str(self.max_pos), '0',
                        #                          get_symbol_account(exchange)])
                        #     task_cmd['strat_item'][0]['pos_contracts'].append(contract)

                    for key in position:
                        yesterday_pos.append(position[key])
                        today_pos.append(position[key])

                    task_cmd['strat_item'][0]['yesterday_pos'] = yesterday_pos
                    task_cmd['strat_item'][0]['today_pos'] = today_pos

                    if accounts:
                        acc_details_start_date = sc.query(
                            StrategyResultAccount.trading_date
                        ).filter(
                            StrategyResultAccount.strategy_id == self.id,
                            StrategyResultAccount.config_id == config_id,
                            StrategyResultAccount.trading_date < start_date,
                            StrategyResultAccount.day_night == 0,
                        ).order_by(
                            StrategyResultAccount.trading_date.desc()
                        ).first()

                        if acc_details_start_date:
                            acc_details = sc.query(StrategyResultAccount).filter(
                                StrategyResultAccount.strategy_id == self.id,
                                StrategyResultAccount.config_id == config_id,
                                StrategyResultAccount.trading_date == acc_details_start_date[0].strftime('%Y%m%d'),
                                StrategyResultAccount.day_night == 0,
                            )

                            task_cmd['strat_item'][0]['accounts'] = [
                                '|'.join([
                                    acc_d.account,
                                    str(float(acc_d.available_cash) / float(acc_d.forex_rate or 1.0)),
                                    str(float(acc_d.asset_cash) / float(acc_d.forex_rate or 1.0)),
                                    (acc_d.currency or 'CNY').upper(),
                                    str(float(acc_d.forex_rate or 1.0))
                                ])
                                for acc_d in acc_details
                            ]
                        else:
                            task_cmd['strat_item'][0]['accounts'] = [
                                '|'.join(
                                    [
                                        default_account, str(res.available_cash or initial_cash),
                                        str(res.asset_cash or initial_cash),
                                        'CNY',
                                        '1.0'
                                    ]
                                )
                            ]
                    else:
                        task_cmd['strat_item'][0]['accounts'] = [
                            '|'.join(
                                [
                                    default_account, str(res.available_cash or initial_cash),
                                    str(res.asset_cash or initial_cash),
                                    'CNY',
                                    '1.0'
                                ]
                            )
                        ]

            task_cmd['strat_item'] = task_cmd['strat_item'][0]

            if config_id > 0:
                task_cmd['strat_item']['cash_limit'] = self.get_strategy_cash_limit(start_date, end_date)

            if self.is_derive_strategy:
                icopy = MutilFactorStrategy.get_main_s_id(sub_s_id=self.id)
            else:
                icopy = 0

            extra_arguments = {
                'log_level': self.detail.get('log_level', StrategyConstant.DetailLogLevel.Production.value),
                'icopy': icopy
            }
            task_cmd['extra_arguments'] = extra_arguments

            rds = redis.Redis(host=config.redis['host'], port=config.redis['port'], db=config.redis['db'])

            if config_id > 0:
                task_queue = consts.NEW_AGENT_TASK_QUEUE + '_vwap_test'
            elif self.detail.get(
                    'back_test_split') or self.strategy_type == StrategyConstant.StrategyType.StockFactor.value:
                task_queue = consts.NEW_AGENT_TASK_QUEUE + '_part1'
            elif self.strategy_type in consts.stock_strategy_type + consts.hedge_stock_strategy_type:
                task_queue = consts.NEW_AGENT_TASK_QUEUE + '_stock'
            else:
                task_queue = consts.NEW_AGENT_TASK_QUEUE + '_future'

            check_res = self.check_dependency(start_date, TradingTimeRange.Day.value, task=task_cmd)

            if kwargs.get('auto') and (not check_res) and not (15 < datetime.datetime.now().hour < 19):
                redo_strategy_papertrading.apply_async(args=(self.id, start_date), countdown=600)
                sc.close()
                return False

            Strategy.add_strategy_event(
                self.id,
                start_date,
                TradingTimeRange.Day.value,
                StrategyEventTrackConstant.Event.SendStrategyTask.value,
                task_id=task_id
            )

            if (self.r_create_user_id == CompanyUser.HuangChunChun['id'] and self.detail.get('back_test_split')) or (
                    self.strategy_type == '26'):
                kdb = KdbQuery()
                days = kdb.get_trading_days(str(start_date), str(end_date))
                for d in days:
                    t_cmd = copy.deepcopy(task_cmd)
                    t_cmd['start_date'] = int(d)
                    t_cmd['end_date'] = int(d)
                    t_cmd = json.dumps(t_cmd)
                    rds.rpush(task_queue, t_cmd)
                    logger.info('send task[%s] to agent %s' % (t_cmd, task_queue))
            else:
                task_cmd = json.dumps(task_cmd)
                if self.strategy_type in consts.t0_stock_strategy_type:
                    task_cmd = task_cmd.replace('testaccount1', 'account%s' % self.id)

                rds.rpush(task_queue, task_cmd)
                logger.info('send task[%s] to agent %s' % (task_cmd, task_queue))

        sc.close()
        return True

    def get_strategy_cash_limit(self, start_date, end_date):
        sc = session()
        cash_limits = sc.query(
            CashLimitDetail
        ).join(
            CashLimit, CashLimit.id == CashLimitDetail.cash_limit_id
        ).filter(
            CashLimit.strategy_id == self.id,
            CashLimitDetail.start_time <= parse(end_date).strftime('%Y-%m-%d 20:00:00'),
            CashLimitDetail.end_time >= parse(start_date).strftime('%Y-%m-%d 00:00:00'),
        )
        data = []
        for l in cash_limits:
            data.append({
                'start_time': l.start_time.strftime('%Y%m%d 000000'),
                'end_time': l.end_time.strftime('%Y%m%d 153000'),
                'symbol': l.symbol,
                'max_long_ratio': float(l.long_limit),
                'max_short_ratio': float(l.short_limit),
            })
        sc.close()
        return data

    def start_back_test_task_v4(self, **kwargs):
        if self.is_new_so:
            return self.new_strategy_back_test(**kwargs)

        Strategy.add_strategy_event(
            self.id,
            datetime.datetime.now().strftime('%Y%m%d'),
            TradingTimeRange.Day.value,
            StrategyEventTrackConstant.Event.BackTestDepCheck.value,
            task_id=self.st_uuid,
            status=StrategyEventTrackConstant.Status.Fail.value,
            detail={
                'error': 'so file error'
            }
        )
        return False

    def start_union_simulation(self, *args, **kwargs):
        from cron.strategy_upload_task import redo_strategy_papertrading
        from service.stock_factor.models import StockFactorStrategyColumns
        from service.statistic.models import StrategyIncomeAttribution

        task_id = kwargs['task_id']
        config_id = kwargs['config_id']
        total_initial_cash = kwargs['init_cash']
        start_date = kwargs['start_date']
        end_date = kwargs['end_date']
        trade_model = kwargs['trade_model']
        accounts = kwargs.get('accounts', {})
        stra_initial_cash = {int(k): total_initial_cash * float(v) for k, v in
                             self.detail.get('union_stra_weight', {}).items()}
        Strategy.add_strategy_event(
            self.id,
            start_date, 0,
            'PrepareStrategyTask',
            task_id=task_id
        )

        union_s_ids = [int(k) for k in self.detail.get('union_stra_weight', {}).keys()]
        union_task = []
        sc = session()
        for s_id in union_s_ids:
            s = sc.query(Strategy).filter_by(id=s_id).first()
            product_portfolios = s.products or []

            if accounts and ('accounts' not in accounts):
                accounts = {
                    'accounts': {},
                    'exchanges': {},
                }
                # A bi-directional dict is duplicated and tricky.
                for a, a_d in kwargs['accounts'].items():
                    accounts['accounts'][a] = a_d
                    for e in a_d['exchange']:
                        accounts['exchanges'][e] = a

            if s.is_test > 0:
                product_portfolios = product_portfolios[:1]
                today = datetime.datetime.now()
                start_date = (today - datetime.timedelta(10)).strftime("%Y%m%d")
                end_date = today.strftime("%Y%m%d")

            depend = []
            depend_ev = []
            for dep in (s.dependency or []):
                # dep_s = sc.query(Strategy).filter_by(id=dep['id']).first()
                # dep_out_put = dep_s.output(config_id)
                if dep['type'] == 'ev':
                    dep_s = sc.query(Strategy).filter_by(id=dep['id']).first()
                    dep_out_put = dep_s.output(config_id)
                    depend.append(dep_out_put)
                    depend_ev.append('strategy_upload/output/%s/%s/ev_output_%s_%s_[DAYNIGHT].csv' % (
                        dep_s.username, dep_s.name.strip().replace(' ', ''), '[DATE]', str(dep_s.id)
                    ))

                    # if dep_s.start_date > start_date:
                    #    dep_s.start_ev_task_v3(start_date=start_date, end_date=dep_s.start_date)

            if s.strategy_type == '98':
                depend_ev.append('strategy_upload/output/%s/%s/ev_output_%s_%s.csv' % (
                    s.username, str(s.id), '[DATE]', str(s.id)))

            begin_end_time = consts.BEGIN_END_TIME[s.day_night]
            is_hsa = False
            # if s.strategy_type in consts.t0_stock_strategy_type:
            #     default_account = 'account%s' % s.id
            # else:
            #     default_account = 'testaccount1'
            default_account = 'testaccount1'
            if accounts:
                default_account = list(accounts['accounts'].keys())[0]

            def get_symbol_account(exch):
                if accounts:
                    if exch in consts.STOCK_EXCHANGE:
                        for e in ([exch] + consts.STOCK_EXCHANGE):
                            if e in accounts['exchanges']:
                                return accounts['exchanges'][e]
                        return default_account
                    else:
                        return accounts['exchanges'].get(exch, default_account)
                else:
                    return default_account

            quote_source = '0'
            if s.strategy_type == '23':
                quote_source = 'whole'

            factor_book = {}
            se_factor_book = {}
            for product_portfolio in product_portfolios[:1]:
                products, contracts, yesterday_pos, today_pos = [], [], [], []
                for _p in product_portfolio:
                    products.append(_p['symbol'])
                    if _p['exch'] in consts.BTC_EXCHANGE:
                        ranks = ''
                        mitype = '58'
                        contracts.append('|'.join(
                            [_p['symbol'], ranks, _p['exch'], mitype, str(s.max_pos), quote_source,
                             get_symbol_account(_p['exch'])]
                        ))
                    elif (_p['type'] == 'futures') or (_p['exch'] == 'IDEALPRO'):
                        if _p['exch'] in ('LME', 'IDEALPRO'):
                            ranks = ''
                        else:
                            ranks = ','.join(['R%s' % i for i in sorted(_p['rank'])])
                        if str(s.detail.get('quote_deepth', '1')) == '0' and _p['exch'] in consts.FUTURE_EXCHANGE:
                            mitype = '12'
                        else:
                            mitype = get_mitype(_p['exch'])

                        contracts.append('|'.join(
                            [_p['symbol'], ranks, _p['exch'], mitype, str(s.max_pos), quote_source,
                             get_symbol_account(_p['exch'])]
                        ))
                    elif _p['type'] == 'stock':
                        mi_type = get_mitype(_p['exch'])
                        if _p['symbol'][-3:].upper() in ['.SH', '.SZ']:
                            mi_type = get_mitype('SSE_SZSE_INDEX')
                        else:
                            if s.strategy_type == '188':
                                mi_type = mi_type + ',54'

                        contracts.append('|'.join(
                            [_p['symbol'], '', _p['exch'], mi_type, str(s.max_pos), '0', get_symbol_account(_p['exch'])]
                        ))
                        transaction_quote = [str(_x) for _x in s.detail.get('transaction_quote', [])]
                        if '1' in transaction_quote:
                            contracts.append('|'.join(
                                [_p['symbol'], '', _p['exch'], 54, str(s.max_pos), '0',
                                 get_symbol_account(_p['exch'])]))
                        if '2' in transaction_quote:
                            contracts.append('|'.join(
                                [_p['symbol'], '', _p['exch'], 53, str(s.max_pos), '0',
                                 get_symbol_account(_p['exch'])]))
                        if '3' in transaction_quote:
                            contracts.append('|'.join(
                                [_p['symbol'], '', _p['exch'], 52, str(s.max_pos), '0',
                                 get_symbol_account(_p['exch'])]))
                    elif _p['type'] == 'stock_factor_FACTOR':
                        factor_info = _p['symbol'].split('_')
                        factor_id = int(factor_info[2])
                        factor_col = factor_info[3]
                        f_book = factor_book.setdefault(factor_id, [])
                        f_book.append(factor_col)
                    elif _p['type'] == 'stock_factor_POSITION':
                        contracts.append('81|0|%s|' % (_p['symbol'].rsplit('_', 1)[-1]))
                    elif _p['type'] == 'index':
                        if _p['symbol'] == 'HSA':
                            is_hsa = True

                        transaction_quote = [str(_x) for _x in s.detail.get('transaction_quote', [])]
                        if '1' in transaction_quote:
                            contracts.append('%s|I|54|%s' % (_p['symbol'], get_symbol_account('SSE')))
                        if '2' in transaction_quote:
                            contracts.append('%s|I|53|%s' % (_p['symbol'], get_symbol_account('SSE')))
                        if '3' in transaction_quote:
                            contracts.append('%s|I|52|%s' % (_p['symbol'], get_symbol_account('SSE')))

                        if s.strategy_type == '188':
                            contracts.append('%s|I+|%s' % (_p['symbol'], get_symbol_account('SSE')))
                        else:
                            contracts.append('%s|I|%s' % (_p['symbol'], get_symbol_account('SSE')))
                    elif _p['type'] == 'spot':
                        contracts.append('|'.join(
                            [
                                _p['symbol'], '', _p['exch'], get_mitype(_p['exch']),
                                str(s.max_pos), quote_source, get_symbol_account(_p['exch'])
                            ]
                        ))
                    else:
                        raise ValueError('product type (%s, %s) error' % (_p['symbol'], _p['type']))

                config_type = 0
                if s.id > 208596:
                    config_type = 1

                if s.strategy_type in consts.t0_stock_strategy_type:
                    config_type = 2

                smart_execution_so_path = ''
                smart_execution_ev = ''
                se_contracts = []

                if s.detail.get('vwap_version'):
                    smart_execution_strategy = sc.query(Strategy).join(
                        StockSmartExecutionVersion, StockSmartExecutionVersion.strategy_id == Strategy.id
                    ).filter(
                        StockSmartExecutionVersion.value == s.detail['vwap_version']
                    ).first()
                    if smart_execution_strategy:
                        smart_execution_ev = []
                        for _dep in (smart_execution_strategy.dependency or []):
                            # _dep_s = sc.query(Strategy).filter_by(id=_dep['id']).first()
                            if _dep['type'] == 'ev':
                                _dep_s = sc.query(Strategy).filter_by(id=_dep['id']).first()
                                smart_execution_ev.append(
                                    'strategy_upload/output/%s/%s/ev_output_%s_%s_[DAYNIGHT].csv' % (
                                        _dep_s.username, _dep_s.name.strip().replace(' ', ''), '[DATE]', str(_dep_s.id)
                                    ))
                        smart_execution_ev = '|'.join(smart_execution_ev)
                        smart_execution_so_path = smart_execution_strategy.strategy_upload_file['relative_path']
                        for p_portfolio in smart_execution_strategy.products[:1]:
                            for _p in p_portfolio:
                                if _p['type'] == 'futures':
                                    ranks = ','.join(['R%s' % i for i in sorted(_p['rank'])])
                                    if str(smart_execution_strategy.detail.get('quote_deepth', '1')) == '0' and _p[
                                        'exch'] in consts.FUTURE_EXCHANGE:
                                        mitype = '12'
                                    else:
                                        mitype = get_mitype(_p['exch'])

                                    se_contracts.append('|'.join(
                                        [_p['symbol'], ranks, _p['exch'], mitype, '1000000', quote_source,
                                         get_symbol_account(_p['exch'])]
                                    ))
                                elif _p['type'] == 'stock':
                                    mi_type = get_mitype(_p['exch'])
                                    if _p['symbol'][-3:].upper() in ['.SH', '.SZ']:
                                        mi_type = get_mitype('SSE_SZSE_INDEX')

                                    se_contracts.append('|'.join(
                                        [_p['symbol'], '', _p['exch'], mi_type, '1000000', '0',
                                         get_symbol_account(_p['exch'])]
                                    ))
                                elif _p['type'] == 'index':
                                    if _p['symbol'] == 'HSA':
                                        is_hsa = True
                                    transaction_quote = [str(_x) for _x in s.detail.get('transaction_quote', [])]
                                    if '1' in transaction_quote:
                                        se_contracts.append('%s|I|54|%s' % (_p['symbol'], get_symbol_account('SSE')))
                                    if '2' in transaction_quote:
                                        se_contracts.append('%s|I|53|%s' % (_p['symbol'], get_symbol_account('SSE')))
                                    if '3' in transaction_quote:
                                        se_contracts.append('%s|I|52|%s' % (_p['symbol'], get_symbol_account('SSE')))

                                    se_contracts.append('%s|I|%s' % (_p['symbol'], get_symbol_account('SSE')))
                                elif _p['type'] == 'stock_factor_FACTOR':
                                    factor_info = _p['symbol'].split('_')
                                    factor_id = int(factor_info[2])
                                    factor_col = factor_info[3]
                                    f_book = se_factor_book.setdefault(factor_id, [])
                                    f_book.append(factor_col)
                                elif _p['type'] == 'stock_factor_POSITION':
                                    se_contracts.append('81|0|%s|' % (_p['symbol'].rsplit('_', 1)[-1]))

                factor_book_task = []
                se_factor_book_task = []
                for f_id, cols in factor_book.items():
                    contracts.append('80|0|%s|' % f_id)
                    f_columns = StockFactorStrategyColumns.get_factor_columns(f_id)
                    if 'ALL' in cols:
                        factor_book_task.append(
                            {'id': f_id, 'columns': f_columns, 'indexes': list(range(len(f_columns))),
                             'total_num': len(f_columns)}
                        )
                    else:
                        book_col = []
                        book_col_index = []
                        for _i, _c in enumerate(f_columns):
                            if _c in cols:
                                book_col.append(_c)
                                book_col_index.append(_i)
                        factor_book_task.append(
                            {'id': f_id, 'columns': book_col, 'indexes': book_col_index, 'total_num': len(f_columns)}
                        )

                for f_id, cols in se_factor_book.items():
                    se_contracts.append('80|0|%s|' % f_id)
                    f_columns = StockFactorStrategyColumns.get_factor_columns(f_id)
                    if 'ALL' in cols:
                        se_factor_book_task.append(
                            {'id': f_id, 'columns': f_columns, 'indexes': list(range(len(f_columns))),
                             'total_num': len(f_columns)}
                        )
                    else:
                        book_col = []
                        book_col_index = []
                        for _i, _c in enumerate(f_columns):
                            if _c in cols:
                                book_col.append(_c)
                                book_col_index.append(_i)
                        se_factor_book_task.append(
                            {'id': f_id, 'columns': book_col, 'indexes': book_col_index, 'total_num': len(f_columns)}
                        )

                if (s.strategy_type in consts.stock_strategy_type) and (int(s.detail.get('alpha_s_id', 0) or 0) > 0):
                    contracts.append('81|0|%s|' % s.detail['alpha_s_id'])

                income_attribution = {}
                if s.strategy_type in consts.stock_strategy_type:
                    income_attribution = StrategyIncomeAttribution.get_back_test_income_attribution_adjusted(
                        s.id, start_date=start_date
                    )

                master_weight = {}
                if s.detail.get('predict_s_ids', []):
                    w = 1.0 / len(s.detail['predict_s_ids'])
                    for w_s_i in s.detail['predict_s_ids']:
                        master_weight[w_s_i] = w

                initial_cash = stra_initial_cash[s_id]
                task_cmd = {
                    'reserve_type': 1,
                    'db_conf': ','.join([config.KDB_HOST, str(config.KDB_PORT), config.KDB_USER, config.KDB_PASSWD]),
                    'type': 110,
                    'business': 0 if not kwargs.get('auto') else 1,
                    'is_test': 1 if s.is_test else 0,
                    'start_date': int(start_date),
                    'end_date': int(end_date),
                    'begin_time': begin_end_time['begin_time'],
                    'end_time': begin_end_time['end_time'],
                    'day_night_flag': s.day_night,
                    'paper_trading_date': s.paper_trading_date.strftime('%Y%m%d'),
                    'agent': '',
                    'task_id': task_id,
                    'user': s.username,
                    'user_id': s.r_create_user_id,
                    'flag_write_tunnel_log': False,
                    'flag_write_strat_log': True,
                    'flag_cross_day_position': True,
                    'load_symbol_from_tradelist': s.detail.get('load_ev_config', False),
                    'max_accum_open_vol': 1000000,
                    'trader_type': 1,
                    'match_type': 1,
                    'plugins': [],
                    'write_publish': True,
                    'match_param': consts.COMMON_MATCH_PARAM,
                    'sell_stock_short': s.detail.get('stock_loan', False),
                    'so_path': [s.strategy_upload_file['relative_path']],
                    'btc_simulation': s.is_btc_strategy,
                    'config_type': config_type,
                    'portfolio_optimization_model_version': StockPortfolioOptimizationVersion.get_paras(
                        s.detail.get('portfolio_optimization_so_version', '')
                    ),
                    'vwap_version': s.detail.get('vwap_version', 'v1') or 'v1',
                    'portfolio_optimization_ev_path': '/mnt/share_media/portfolio_optimization_ev/',
                    'smart_execution_so_path': smart_execution_so_path,
                    'smart_execution_ev': smart_execution_ev,
                    'se_item': {
                        'smart_execution_so_path': smart_execution_so_path,
                        'smart_execution_ev': smart_execution_ev,
                        'contracts': se_contracts,
                        'factor_book': se_factor_book_task,
                        'se_cash': initial_cash * s.detail.get('se_cash_rate', 0),
                    },
                    'income_attribution': income_attribution,
                    'master_weight': master_weight,
                    'factor_book': factor_book_task,
                    'strat_item': [{
                        'strat_name': s.id_no or (s.name.strip().replace(' ', '')),
                        'strat_id': s.id,
                        'contracts': contracts,
                        'strat_param_file': '|'.join(depend_ev),
                        'output_file_path': './output/%s/%s' % (s.id_no, task_id),
                        'pos_contracts': [],
                        'cash_limit': [],
                        'factor_book': factor_book_task,
                    }],
                    'settlement_kwargs': {
                        'config_id': config_id,
                        'hedge': s.hedge or '',
                        'hedge_type': s.hedge_type or '',
                        'is_btc_strategy': s.is_btc_strategy,
                        'is_foregin_strategy': s.is_foregin_strategy,
                        'strategy_type': Strategy.convert_strategy_type(s.strategy_type),
                        'single_interest': s.detail.get('single_interest', False),
                        'is_hk_stock': s.strategy_type in ('27', '28'),
                        'stock_fee_rate': s.detail.get('stock_fee_rate', 0),
                    },
                    'unrealized_corp_data': s.get_unrealized_corp_items(start_date, config_id),
                    'is_hk_strategy': s.strategy_type in ('27', '28'),
                    "is_union_simu": True,
                }

                if len(task_cmd['portfolio_optimization_model_version']) > 31:
                    task_cmd['reserve_type'] = 2

                if factor_book_task:
                    task_cmd['reserve_type'] = 3

                optional_module = s.detail.get('modules', '[]')
                if 'VWAP' in optional_module:
                    task_cmd['plugins'].append('vwap')

                task_cmd['strat_item'][0]['trade_model'] = trade_model
                time_interval = int(float(s.detail.get('time_interval', 0)))
                if accounts:
                    kdb = KdbQuery()
                    if not s.is_btc_strategy:
                        forex_rate = kdb.get_forex_rate(start_date)
                    else:
                        forex_rate = {
                            acc_cash_detail['currency'].lower(): 1
                            for _, acc_cash_detail in accounts['accounts'].items()
                        }
                    task_cmd['strat_item'][0]['accounts'] = [
                        '|'.join(
                            [
                                _acc,
                                str(acc_cash_detail['cash'] / forex_rate[acc_cash_detail['currency'].lower()]),
                                str(acc_cash_detail['cash'] / forex_rate[acc_cash_detail['currency'].lower()]),
                                acc_cash_detail['currency'].upper(),
                                str(forex_rate[acc_cash_detail['currency'].lower()])
                            ])
                        for _acc, acc_cash_detail in accounts['accounts'].items()
                    ]
                else:
                    task_cmd['strat_item'][0]['accounts'] = [
                        '|'.join([default_account, str(initial_cash), str(initial_cash), 'CNY', '1.0'])
                    ]
                if time_interval > 0:
                    task_cmd['time_interval'] = time_interval

                # get yesterday_pos from previous result under PT
                if kwargs.get('auto') and (kwargs['auto'] is True):
                    res = sc.query(StrategyResult).filter(StrategyResult.strategy_id == s.id,
                                                          StrategyResult.config_id == config_id,
                                                          StrategyResult.status == consts.TASK_FINISHED,
                                                          StrategyResult.date < start_date
                                                          ).order_by(StrategyResult.date.desc()).first()
                    position = {}
                    if res is not None:
                        for r in res.detail:
                            # will be overwrited by latest result
                            if int(r['day_night']) != 0:
                                continue
                            if r['long_volume'] + r['short_volume'] > 0:
                                position[r['symbol']] = '|'.join(map(str, [
                                    r['symbol'], int(r['long_volume']), r['long_price'], int(r['short_volume']),
                                    r['short_price'], r.get('account', default_account) or default_account,
                                ]))
                            else:
                                continue
                            exchange = consts.EXCHANGE[chr(r['exchange'])]

                            if exchange == 'ICEU' and r['symbol'][:1].upper() == 'B' and (
                                    exchange not in accounts['exchanges']) and ('ICEE' in accounts['exchanges']):
                                exchange = 'ICEE'

                            if exchange in (consts.FUTURE_EXCHANGE + consts.FOREIGN_EXCHANGE) and r['long_volume'] + r[
                                'short_volume'] > 0:
                                if str(s.detail.get('quote_deepth', '1')) == '0' and exchange in consts.FUTURE_EXCHANGE:
                                    mi_type = '12'
                                else:
                                    mi_type = get_mitype(exchange)
                                contract = '|'.join([r['symbol'], '', exchange, mi_type, str(s.max_pos), quote_source,
                                                     get_symbol_account(exchange)])
                                task_cmd['strat_item'][0]['pos_contracts'].append(contract)
                            elif exchange in consts.STOCK_EXCHANGE and not is_hsa:
                                mi_type = '9'
                                # Here don't need to add other contracts if HSA. modify cxwen
                                if s.strategy_type == '188':
                                    mi_type = '9,54'
                                contract = '|'.join([r['symbol'], '', exchange, mi_type, str(s.max_pos), '0',
                                                     get_symbol_account(exchange)])
                                task_cmd['strat_item'][0]['pos_contracts'].append(contract)
                            if exchange in consts.BTC_EXCHANGE:
                                mi_type = '58'
                                contract = '|'.join([r['symbol'], '', exchange, mi_type, str(s.max_pos), '0',
                                                     get_symbol_account(exchange)])
                                task_cmd['strat_item'][0]['pos_contracts'].append(contract)

                        for key in position:
                            yesterday_pos.append(position[key])
                            today_pos.append(position[key])

                        task_cmd['strat_item'][0]['yesterday_pos'] = yesterday_pos
                        task_cmd['strat_item'][0]['today_pos'] = today_pos

                        if accounts:
                            acc_details_start_date = sc.query(
                                StrategyResultAccount.trading_date
                            ).filter(
                                StrategyResultAccount.strategy_id == s.id,
                                StrategyResultAccount.config_id == config_id,
                                StrategyResultAccount.trading_date < start_date,
                                StrategyResultAccount.day_night == 0,
                            ).order_by(
                                StrategyResultAccount.trading_date.desc()
                            ).first()

                            if acc_details_start_date:
                                acc_details = sc.query(StrategyResultAccount).filter(
                                    StrategyResultAccount.strategy_id == s.id,
                                    StrategyResultAccount.config_id == config_id,
                                    StrategyResultAccount.trading_date == acc_details_start_date[0].strftime('%Y%m%d'),
                                    StrategyResultAccount.day_night == 0,
                                )

                                task_cmd['strat_item'][0]['accounts'] = [
                                    '|'.join([
                                        acc_d.account,
                                        str(float(acc_d.available_cash) / float(acc_d.forex_rate or 1.0)),
                                        str(float(acc_d.asset_cash) / float(acc_d.forex_rate or 1.0)),
                                        (acc_d.currency or 'CNY').upper(),
                                        str(float(acc_d.forex_rate or 1.0))
                                    ])
                                    for acc_d in acc_details
                                ]
                            else:
                                task_cmd['strat_item'][0]['accounts'] = [
                                    '|'.join(
                                        [
                                            default_account, str(res.available_cash or initial_cash),
                                            str(res.asset_cash or initial_cash), 'CNY', '1.0']
                                    )
                                ]
                        else:
                            task_cmd['strat_item'][0]['accounts'] = [
                                '|'.join(
                                    [
                                        default_account, str(res.available_cash or initial_cash),
                                        str(res.asset_cash or initial_cash), 'CNY', '1.0'
                                    ]
                                )
                            ]
                task_cmd['strat_item'] = task_cmd['strat_item'][0]
                if config_id > 0:
                    task_cmd['strat_item']['cash_limit'] = s.get_strategy_cash_limit(start_date, end_date)

                if s.is_derive_strategy:
                    icopy = MutilFactorStrategy.get_main_s_id(sub_s_id=s.id)
                else:
                    icopy = 0
                extra_arguments = {
                    'log_level': s.detail.get('log_level', StrategyConstant.DetailLogLevel.Production.value),
                    'icopy': icopy
                }
                task_cmd['extra_arguments'] = extra_arguments

                check_res = s.check_dependency(start_date, 0, task=task_cmd)
                if kwargs.get('auto') and (not check_res) and (datetime.datetime.now().hour < 15):
                    redo_strategy_papertrading.apply_async(args=(self.id, start_date), countdown=600)
                    sc.close()
                    return False

                union_task.append(task_cmd)

        union_task = json.dumps(union_task)
        task_queue = 'new_master_add_task_stock_union'
        rds = redis.Redis(host=config.redis['host'], port=config.redis['port'], db=config.redis['db'])
        rds.rpush(task_queue, union_task)
        logger.info('send task[%s] to agent %s' % (union_task, task_queue))

        Strategy.add_strategy_event(
            self.id,
            start_date, 0,
            'SendStrategyTask',
            task_id=task_id
        )
        sc.close()
        return True

    def start_trademaster_task(self, trading_date, day_night, **kwargs):

        from service.order_list.models import OrderList

        trading_date = parse(trading_date).strftime('%Y%m%d')
        day_night = int(day_night)

        if self.node != 'trademaster_order_list':
            raise ValueError('strategy type error: must trademaster_order_list')

        so_path = os.path.join(config.media, self.strategy_upload_file['relative_path'])
        cwd = os.path.join(config.ev_work_path, '   %s_%s/app_working_dir' % (self.r_create_user_id, self.username))
        if not os.path.exists(cwd):
            os.makedirs(cwd)
            os.makedirs(os.path.join(cwd, 'output'))
            os.symlink(os.path.join(config.renv, 'qserver.so'), os.path.join(cwd, 'qserver.so'))
            os.symlink(os.path.join(config.renv, 'qserver.R'), os.path.join(cwd, 'qserver.R'))

        so_cwd = os.path.join(cwd, self.id_no)
        if not os.path.exists(so_cwd):
            os.makedirs(so_cwd)

        so_symbol_link = os.path.join(so_cwd, 'tradelist_gen.so')
        # if os.path.exists(so_symbol_link):
        #     os.remove(so_symbol_link)
        # os.symlink(so_path, so_symbol_link)
        symlink_insurance(so_path, so_symbol_link)

        init_py = os.path.join(so_cwd, '__init__.py')
        if not os.path.exists(init_py):
            with open(init_py, 'w') as f:
                pass

        codestr = """
import sys
import json
from {strategy} import tradelist_gen

if __name__ == '__main__':
    cfg = json.loads(sys.argv[1])
    trading_date = cfg['trading_date']
    day_night = cfg['day_night']
    config = cfg['config']
    out_put_file = config['out_put_file']
    out_put = tradelist_gen.trade_list_generation(trading_date, day_night, config)
    with open(out_put_file, 'w') as f:
        f.write(out_put)
    """.format(**{'strategy': self.id_no})

        strategy_py = os.path.join(cwd, '%s.py' % self.id_no)

        with open(strategy_py, 'w') as f:
            f.write(codestr)

        sc = session()
        try:
            out_put_file = os.path.join(so_cwd, 'tradelist_%s_%s_%s.csv' % (self.id_no, trading_date, day_night))
            args = {
                'trading_date': trading_date,
                'day_night': day_night,
                'config': {
                    'out_put_file': out_put_file,
                },
            }
            com_list = ['/usr/bin/python3', strategy_py, json.dumps(args)]
            output_string = subprocess.check_output(com_list, universal_newlines=True, cwd=cwd)
            trade_list = pd.read_csv(out_put_file, sep=',', dtype={
                'date': str, 'symbol': str, 'weight': np.float64, 'size': np.float64,
                'limit_price': np.float64, 'algo': str, 'start': str, 'end': str
            })

            cols = trade_list.columns.tolist()

            trade_list_to_delete = sc.query(OrderList).filter(
                OrderList.date == trading_date,
                OrderList.strategy_id == self.id,
            )

            trade_list_to_delete.delete()

            date_index = cols.index('date')
            symbol_index = cols.index('symbol')
            algo_index = cols.index('algo')
            start_index = cols.index('start')
            end_index = cols.index('end')

            weight_index, size_index, limit_price_index = -1, -1, -1
            if 'weight' in cols:
                weight_index = cols.index('weight')
            if 'size' in cols:
                size_index = cols.index('size')
            if 'limit_price' in cols:
                limit_price_index = cols.index('limit_price')

            orderlists = []
            for row in trade_list.values:
                order_kwargs = {
                    'r_create_user_id': 1,
                    'r_update_user_id': 1,
                    'date': row[date_index],
                    'strategy_id': self.id,
                    'hedge_id': -1,  # No hedge as of 2017.09.05
                    'symbol': row[symbol_index],
                    'algo': row[algo_index],
                    'start': row[start_index],
                    'end': row[end_index],
                }
                if weight_index >= 0 and not np.isnan(row[weight_index]):
                    order_kwargs['weight'] = row[weight_index]
                if size_index >= 0 and not np.isnan(row[size_index]):
                    order_kwargs['size'] = row[size_index]
                if limit_price_index >= 0 and not np.isnan(row[limit_price_index]):
                    order_kwargs['limit_price'] = row[limit_price_index]
                orderlists.append(order_kwargs)
            if orderlists:
                sc.execute(OrderList.__table__.insert(), orderlists)
            sc.commit()
            sc.close()
            return True
        except Exception as e:
            sentry.captureException()
            sc.close()
            return False

    def generat_trademaster_orderlist(self, *args, **kwargs):
        from service.order_list.models import OrderList
        start_date = parse(kwargs['start_date']).strftime('%Y%m%d')
        end_date = parse(kwargs['end_date']).strftime('%Y%m%d')
        kdb = KdbQuery()
        trading_dates = kdb.get_trading_days(start_date, end_date)
        sc = session()
        order_list_day_counts = {
            d_count[0]: d_count[1]
            for d_count in sc.query(OrderList.date, func.count('1')).filter(
                OrderList.strategy_id == self.id,
                OrderList.date >= start_date,
                OrderList.date <= end_date,
            ).group_by(OrderList.date)
        }

        rds = redis.Redis(host=config.redis['host'], port=config.redis['port'], db=config.redis['db'])
        for d in trading_dates:
            status = str(rds.hget(consts.AGENT_TASK_STOP_MAP, self.st_uuid) or b'', 'utf-8')
            if status == str(consts.AGENT_TASK_STOP):
                logger.info('generat_trademaster_orderlist stop!!')
                break

            if order_list_day_counts.get(d, 0) > 0:
                continue
            try:
                self.start_trademaster_task(d, self.day_night)
            except Exception as e:
                sentry.captureException()
        sc.close()
        return True

    def get_last_position(self, init_cash, start_date, config_id):
        account = {
            'init_account': {
                'cash': init_cash,
                'available_cash': init_cash,
                'asset_cash': init_cash,
                'account_accumulated_pnl': 0,
                'daynight': 'DAY'
            }
        }

        result = {
            'cash': init_cash,
            'available_cash': init_cash,
            'asset_cash': init_cash,
            'accumulated_pnl': 0,
            'daynight': 'DAY',
            'accounts': account,
            'unrealized_corp_data': self.get_unrealized_corp_items(start_date, config_id),
            'data': {}
        }
        sc = session()
        last_item = sc.query(StrategyResult).filter(StrategyResult.strategy_id == self.id,
                                                    StrategyResult.config_id == config_id,
                                                    StrategyResult.status == consts.TASK_FINISHED,
                                                    StrategyResult.date < start_date).order_by(
            StrategyResult.date.desc()).first()
        if last_item is not None:
            if last_item.available_cash:
                result['cash'] = account['init_account']['cash'] = float(last_item.available_cash)
                result['available_cash'] = account['init_account']['available_cash'] = float(last_item.available_cash)
                result['asset_cash'] = account['init_account']['asset_cash'] = float(last_item.asset_cash)
            remain_pos = {'account': 'init_account', 'daynight': 'DAY', 'symbol_net_pnl': 0}
            for item in last_item.detail:
                if not (item['long_volume'] > 0 or item['short_volume'] > 0):
                    continue
                new_pos = copy.deepcopy(remain_pos)
                new_pos['yest_long_pos'] = new_pos['today_long_pos'] = item['long_volume']
                new_pos['yest_long_avg_price'] = new_pos['today_long_avg_price'] = item['long_price']
                new_pos['yest_short_pos'] = new_pos['today_short_pos'] = item['short_volume']
                new_pos['yest_short_avg_price'] = new_pos['today_short_avg_price'] = item['short_price']
                result['data'][item['symbol']] = new_pos
        sc.close()
        return result

    def start_quantamental_trade_list(self, *args, **kwargs):
        init_cash = kwargs['init_cash']
        start_date = kwargs['start_date']
        end_date = kwargs['end_date']
        task_id = kwargs['task_id']
        config_id = kwargs['config_id']
        strategy_id = self.id
        data = {}
        date_product_map = {}

        sc = session()

        conf_obj = sc.query(BackTestConfig).filter(BackTestConfig.id == config_id).first()
        l_cfg_id = conf_obj.link_cfg_id

        origin_conf_obj = sc.query(BackTestConfig).filter(BackTestConfig.id == l_cfg_id).first()
        if origin_conf_obj.progress < 1:
            sc.close()
            return False

        sc.query(StrategyResultDetail).filter(
            StrategyResultDetail.strategy_id == strategy_id,
            StrategyResultDetail.config_id == config_id,
            StrategyResultDetail.trading_date >= start_date,
            StrategyResultDetail.trading_date <= end_date,
        ).delete(synchronize_session=False)

        sc.query(StrategyResultAccount).filter(
            StrategyResultAccount.strategy_id == strategy_id,
            StrategyResultAccount.config_id == config_id,
            StrategyResultAccount.trading_date >= start_date,
            StrategyResultAccount.trading_date <= end_date,
        ).delete(synchronize_session=False)

        sc.commit()

        detail_data = {}
        strategy_results = sc.query(StrategyResult).filter(
            StrategyResult.strategy_id == strategy_id,
            StrategyResult.config_id == l_cfg_id,
            StrategyResult.date >= start_date,
            StrategyResult.date <= end_date,
        )
        for r in strategy_results:
            date = r.date
            product = r.product
            detail_data.setdefault(date, {'symbols': []})
            date_product_map.setdefault(date, set())
            date_product_map[date].add(product)

        result_details = sc.query(StrategyResultDetail).filter(
            StrategyResultDetail.strategy_id == strategy_id,
            StrategyResultDetail.config_id == l_cfg_id,
            StrategyResultDetail.trading_date >= start_date,
            StrategyResultDetail.trading_date <= end_date,
        )
        for d in result_details:
            day_night = d.day_night
            trading_date = d.trading_date.strftime("%Y%m%d")
            symbol = d.symbol
            long_volume = d.long_volume
            short_volume = d.short_volume
            pnl = float(d.pnl)
            data.setdefault(trading_date, {'symbols': {}})
            data[trading_date]['symbols'].setdefault(symbol, {'long_volume': 0, 'short_volume': 0, 'pnl': 0})
            if day_night == 0:
                data[trading_date]['symbols'][symbol]['long_volume'] = long_volume
                data[trading_date]['symbols'][symbol]['short_volume'] = short_volume
            data[trading_date]['symbols'][symbol]['pnl'] += pnl
        sc.close()

        for _trading_date, _symbols in data.items():
            symbol_line_data = []
            for _symbol, _symbol_detail in _symbols['symbols'].items():
                symbol_line_data.append({
                    'symbol': _symbol,
                    'long_volume': _symbol_detail['long_volume'],
                    'short_volume': _symbol_detail['short_volume'],
                    'pnl': _symbol_detail['pnl'],
                })
            detail_data[_trading_date]['symbols'] = symbol_line_data

        """
        param = {
            'init_cash': 100000,
            'detail': {
                '20180101': {
                    'symbols': [
                         {'symbol': 'hc1801', 'long_volume': 1, 'short_volume': 0, 'pnl': 10},
                         {'symbol': 'hc1803': 'long_volume': 0, 'short_volume': 1, 'pnl': 20},
                    ],
                },
            },
        }
        """
        param = {
            'init_cash': init_cash,
            'detail': detail_data,
            'q_id': kwargs['q_id'],
        }

        from service.back_test.tradelist_backtesting import back_test_quantamental_strat
        """
        output = {
            '20180101': {'close_value': 100000, 'pnl': 0},
            '20180102': {'close_value': -100000, 'pnl': 100},
        }
        """
        _tt = time.time()
        output = back_test_quantamental_strat(param)
        # print('back test quantamental task cost: %s' % (time.time() - _tt))

        sc = session()
        for date in sorted(output.keys()):
            product_key = '|'.join(date_product_map[date])
            close_value = output[date]['close_value']
            pnl = output[date]['pnl']

            r = sc.query(StrategyResult).filter(
                StrategyResult.strategy_id == strategy_id,
                StrategyResult.config_id == config_id,
                StrategyResult.product == product_key,
                StrategyResult.date == date,
            ).first()
            if not r:
                r = StrategyResult(
                    strategy_id=strategy_id,
                    config_id=config_id,
                    date=date,
                    taskdate=date,
                    product=product_key,
                )
                sc.add(r)
                sc.commit()
            if sorted(detail_data.keys()) != sorted(output.keys()):
                r.status = consts.TASK_FAILED
            else:
                r.status = consts.TASK_FINISHED
            r.detail = []
            r.done_time = datetime.datetime.now()
            r.redo_times = 0
            r.log_files = []
            r.dividend = 0
            r.pnl = pnl
            r.available_cash = close_value
            r.asset_cash = close_value
            r.position_cash = 0
            r.total_asset = close_value
            sc.commit()
        sc.close()

        BackTestConfig.update_progress(task_id, 1)
        self.update_status()
        self.update_cache()
        return True

    def get_unrealized_corp_items(self, start_date, config_id=0):
        sc = session()
        corp_actions = sc.query(BackTestPositionCorpActions).filter(
            BackTestPositionCorpActions.strategy_id == self.id,
            BackTestPositionCorpActions.config_id == config_id,
            BackTestPositionCorpActions.eqy_record_date < start_date,
            or_(
                BackTestPositionCorpActions.dividend_cash_payout_date >= start_date,
                BackTestPositionCorpActions.ex_date >= start_date,
                BackTestPositionCorpActions.dividend_share_listing_date >= start_date,
            )
        )
        data = {}
        for corp in corp_actions:
            sym_corps = data.setdefault(corp.symbol, [])
            sym_corps.append(corp.to_brief())
        sc.close()
        return data

    # def start_trade_list(self, *args, **kwargs):
    #
    #     if kwargs.get('only_quantamental', False):
    #         res = self.start_quantamental_trade_list(*args, **kwargs)
    #         return res
    #
    #     if self.node == 'trademaster_order_list':
    #         self.generat_trademaster_orderlist(*args, **kwargs)
    #
    #     task_id = kwargs['task_id']
    #     config_id = kwargs['config_id']
    #     init_cash = kwargs['init_cash']
    #     start_date = kwargs['start_date']
    #     end_date = kwargs['end_date']
    #     trade_model = kwargs['trade_model']
    #
    #     trade_list_param = {
    #         'strat_id': self.id, 'task_id': task_id,
    #         'start_date': start_date, 'end_date': end_date,
    #         'cash': init_cash, 'max_vol': self.max_pos, 'trade_model': trade_model,
    #         'hedge': self.hedge or '', 'hedge_type': self.hedge_type or '',
    #         'settlement_kwargs': {
    #             'config_id': config_id,
    #             'hedge': self.hedge or '',
    #             'hedge_type': self.hedge_type or '',
    #             'strategy_type': Strategy.convert_strategy_type(self.strategy_type),
    #         },
    #         'q_id': kwargs.get('q_id', 0),
    #     }
    #
    #     if kwargs.get('auto'):
    #         trade_list_param['position'] = self.get_last_position(init_cash, start_date, config_id)
    #         trade_list_param['cash'] = trade_list_param['position']['cash']
    #
    #     logger.info('start_trade_list task_id=%s, start_date=%s, strat_id=%s' % (task_id, start_date, self.id))
    #     rds = redis.Redis(host=config.redis['host'], port=config.redis['port'], db=config.redis['db'])
    #     from service.back_test.tradelist_backtesting import back_test_tradelist_strat
    #     gen_obj = back_test_tradelist_strat(trade_list_param)
    #     for daily_item in gen_obj:
    #         rds.rpush(consts.AGENT_RESULT_QUEUE, json.dumps(daily_item))
    #         logger.info('strat_id=%s date=%d day_night=%d progress=%d' % (
    #             self.id, daily_item['date'], daily_item['day_night'], daily_item['progress']))
    #         status = str(rds.hget(consts.AGENT_TASK_STOP_MAP, task_id) or b'', 'utf-8')
    #         if status == str(consts.AGENT_TASK_STOP):
    #             logger.info('back_test_tradelist_strat stop!!')
    #             return True
    #
    #     finish_notify = {
    #         "task_id": task_id,
    #         "status": consts.AGENT_TASK_FINISHED,
    #         "msg": "Task finished!"
    #     }
    #
    #     rds.rpush(consts.AGENT_RESULT_QUEUE, json.dumps(finish_notify))
    #     logger.info('back_test_tradelist_strat sid:%s done!!' % self.id)
    #     return True

    def start_task(self, *args, **kwargs):
        """
        start ev,back_test,order_list,trademaster_order_list task

        :param user_id:
            load user backtest config
        :param auto: bool
            decide if using config start_date or start_date in kwargs
        :param start_date:
            backtest start date

        :referred_task: `strategy_upload.cron.strategy_upload_task.ev_start_strategy_task`
        :referred_task: `strategy_upload.cron.strategy_upload_task.refer_start_back_test`
        :referred_task: `strategy_upload.cron.strategy_upload_task.strategy_ev_task`
        :referred_task: `strategy_upload.cron.strategy_upload_task.redo_strategy_papertrading`
        :referred_task: `strategy_upload.cron.strategy_upload_task.auto_daily_task`
        """
        if self.node == 'group':
            return False

        user_id = kwargs.get("user_id")
        cfg_id = kwargs.get("cfg_id")
        if cfg_id:
            task_id = kwargs.get('task_id', 0)
            BackTestConfig.update_task_by_cfg_id(cfg_id, {"status": consts.TASK_RUNNING})
            cfg_info = BackTestConfig.get_config_by_cfg_id(cfg_id, q_id=user_id)
            if task_id == 0 or cfg_info['task_id'] == 0 or task_id != cfg_info['task_id']:
                return False
            config_id = cfg_info["cfg_id"]
            start_date = cfg_info["start_date"]
            init_cash = cfg_info["init_cash"]
            trade_model = cfg_info["model"]
            accounts = cfg_info.get('accounts', {})
            q_id = cfg_info.get('q_id', 0)
        elif user_id:
            task_id = uuid.uuid1().hex
            BackTestConfig.update_task_id(user_id, self.id, task_id, {"status": consts.TASK_RUNNING})
            cfg_info = BackTestConfig.get_config_id(user_id, self.id)
            config_id = cfg_info["cfg_id"]
            start_date = cfg_info["start_date"]
            init_cash = cfg_info["init_cash"]
            trade_model = cfg_info["model"]
            accounts = cfg_info.get('accounts', {})
            q_id = 0
        else:
            task_id = self.st_uuid
            config_id = 0
            start_date = self.start_date
            init_cash = float(self.detail.get('initial_cash', 1000000) or 1000000)
            trade_model = self.detail.get('trade_model', '')
            accounts = self.detail.get('accounts', {})
            q_id = 0

        if not kwargs.get('auto'):
            kwargs['start_date'] = start_date

        kwargs['task_id'] = task_id
        kwargs['config_id'] = config_id
        kwargs['end_date'] = get_end_date()
        kwargs['init_cash'] = float(init_cash)
        kwargs['trade_model'] = trade_model
        kwargs['accounts'] = accounts
        kwargs['q_id'] = q_id
        set_cache("task_id:" + task_id, {"config_id": config_id, "strategy_id": self.id}, 24 * 3600 * 15)

        if config_id > 0 and kwargs.get('auto') is False:
            sc = session()
            sc.query(StrategyResult).filter(StrategyResult.strategy_id == self.id,
                                            StrategyResult.config_id == config_id).delete(synchronize_session=False)
            sc.query(StrategyResultDetail).filter(StrategyResultDetail.strategy_id == self.id,
                                                  StrategyResultDetail.config_id == config_id).delete(
                synchronize_session=False)
            sc.commit()
            sc.close()

        if config_id == 0 and ('start_date' in kwargs):
            sc = session()
            sc.query(BackTestTradeLogs).filter(
                BackTestTradeLogs.strategy_id == self.id,
                BackTestTradeLogs.trading_date >= kwargs['start_date'],
                BackTestTradeLogs.trading_date <= kwargs['end_date'],
            ).delete(
                synchronize_session=False
            )
            sc.commit()
            sc.close()

        if self.node == 'ev':
            del kwargs['end_date']
            return self.start_ev_task_v3(*args, **kwargs)
        elif self.node == 'back_test':
            return self.start_back_test_task_v4(**kwargs)
        # elif self.node in ('order_list', 'trademaster_order_list'):  # TODO: maybe not used ?
        # YES, order_list and tradermaster have not been used since a long time ago.
        # self.start_trade_list(*args, **kwargs)
        # elif self.node == 'para':
        #     return self.start_para_task(*args, **kwargs)
        # elif self.node == 'cash_manager':
        #     return self.start_cash_manager_task(*args, **kwargs)
        elif self.node == 'union_simu':
            return self.start_union_simulation(*args, **kwargs)
        else:
            return False

    def stop_task(self, *args, **kwargs):
        task_id = kwargs.get("task_id")
        if task_id is None:
            task_id = self.st_uuid
        if self.node in ('back_test', 'order_list', 'trademaster_order_list'):
            del_cache("task_id:" + task_id)
        rds = redis.Redis(host=config.redis['host'], port=config.redis['port'], db=config.redis['db'])
        rds.hset(consts.AGENT_TASK_STOP_MAP, task_id, consts.AGENT_TASK_STOP)
        if self.node == 'ev':
            set_str_cache('ev_task:%s_%s' % (self.id, self.st_uuid), 'STOP', None)
        Strategy.add_strategy_event(
            self.id,
            datetime.datetime.now().strftime('%Y%m%d'),
            0,
            'StopStrategyBackTest',
            task_id=task_id,
        )
        return True

    def set_ev_running(self):
        if self.node == 'ev':
            set_str_cache('ev_task:%s_%s' % (self.id, self.st_uuid), 'RUNNING', None)
            return True
        return False

    def is_ev_stop(self):
        if self.node == 'ev':
            cache_key = 'ev_task:%s_%s' % (self.id, self.st_uuid)
            status = get_str_cache(cache_key)
            if status == 'STOP':
                return True
        return False

    @staticmethod
    def add_strategy_event(s_id, trading_date, day_night, event, task_id='', status=0, detail=None):
        StrategyEventTrack.add_strategy_event(
            s_id, trading_date, day_night, event, task_id=task_id, status=status, detail=detail
        )
        return True

    @staticmethod
    def add_vs_event(vs_id, trading_date, day_night, event, status=0, detail=None):
        VsEventTrack.add_vs_event(
            vs_id, trading_date, day_night, event, status=status, detail=detail
        )
        return True

    def check_dependency(self, trading_date, day_night, **kwargs):
        try:
            if self.node == 'ev':
                return self.check_ev_dependency(trading_date, day_night) and \
                       self.check_factor_dependency(trading_date, day_night)
            elif self.node in ('back_test', 'union_simu'):
                return self.back_test_check_dependency(trading_date, day_night, **kwargs)
        except Exception as e:
            sentry.captureException()
            return False
        return True

    def check_ev_dependency(self, trading_date, day_night):
        event = StrategyEventTrackConstant.Event.EvDepCheck.value
        sc = session()
        dep_ids = set([dep['id'] for dep in self.dependency])
        if dep_ids:
            dep_result = sc.query(StrategyResult.strategy_id).filter(
                StrategyResult.strategy_id.in_(dep_ids),
                StrategyResult.date == trading_date,
                StrategyResult.status == consts.TASK_FINISHED,
                StrategyResult.result_file_name.isnot(None),
            )
            dep_result_ids = set([dep_r[0] for dep_r in dep_result])
            if len(dep_ids) != len(dep_result_ids):
                sc.close()
                diff_ids = list(dep_ids.difference(dep_result_ids))
                detail = {
                    'error': StrategyEventTrackConstant.DetailError.EVDependenceNotReady.value,
                    'ids': diff_ids
                }
                Strategy.add_strategy_event(
                    self.id, trading_date, day_night, event,
                    status=StrategyEventTrackConstant.Status.Fail.value, detail=detail
                )

                return False

        sc.close()

        Strategy.add_strategy_event(
            self.id, trading_date, day_night, event, status=StrategyEventTrackConstant.Status.Success.value,
        )

        return True

    def check_factor_dependency(self, trading_date, day_night):
        event = StrategyEventTrackConstant.Event.FactorDepCheck.value
        sc = session()
        products = self.products and self.products[0] or []
        if products:
            f_ids = set([
                int(p['symbol'].split('_')[2]) for p in products if p.get('type', '') == 'stock_factor_FACTOR'
            ])
            if f_ids:
                dep_result = sc.query(StrategyResult.strategy_id).filter(
                    StrategyResult.strategy_id.in_(f_ids),
                    StrategyResult.date == trading_date,
                    StrategyResult.status == consts.TASK_FINISHED,
                    StrategyResult.result_file_name.isnot(None),
                )
                dep_result_ids = set([dep_r[0] for dep_r in dep_result])
                if len(f_ids) != len(dep_result_ids):
                    sc.close()
                    diff_ids = list(f_ids.difference(dep_result_ids))
                    detail = {
                        'error': StrategyEventTrackConstant.DetailError.FactorDependenceNotReady.value,
                        'ids': diff_ids
                    }
                    Strategy.add_strategy_event(
                        self.id, trading_date, day_night, event,
                        status=StrategyEventTrackConstant.Status.Fail.value,
                        detail=detail
                    )
                    return False

        sc.close()

        Strategy.add_strategy_event(
            self.id, trading_date, day_night, event, status=StrategyEventTrackConstant.Status.Success.value,
        )

        return True

    def back_test_check_dependency(self, trading_date, day_night, **kwargs):
        task = kwargs['task']
        check_res = Strategy.check_back_test_task(task)
        res = check_res['status']

        Strategy.add_strategy_event(
            self.id,
            trading_date,
            day_night,
            StrategyEventTrackConstant.Event.BackTestDepCheck.value,
            task_id=task['task_id'],
            status=StrategyEventTrackConstant.Status.Success.value if res else StrategyEventTrackConstant.Status.Fail.value,
            detail=check_res['detail']
        )

        return res

    @staticmethod
    def vs_back_test_check_dependency(vs_id, trading_date, day_night, **kwargs):

        task = kwargs['task']
        check_res = Strategy.check_back_test_task(task)
        res = check_res['status']

        Strategy.add_vs_event(
            vs_id,
            trading_date,
            day_night,
            'VsBackTestDepCheck',
            status=(0 if res else -1),
            detail=check_res['detail']
        )
        return res

    @staticmethod
    def check_back_test_task(task):
        host = 'http://192.168.10.101:3333'
        check_url = host + '/api/v1/task_check'
        res = {
            'status': False,
            'detail': {
                'error': []
            }
        }
        try:
            ret = requests.post(check_url, json=task, timeout=60)
            if ret.status_code == 200:
                ret = ret.json()
                if ret['code'] != 0:
                    for item in ret['error']:
                        res['detail']['error'].append(item)
                else:
                    res['status'] = True
            else:
                res['detail']['error'].append('check back test task error')
        except Exception as e:
            sentry.captureException()
            res['detail']['error'].append('check back test task error')
        return res

    def output(self, config_id=0, cache=True):
        cache_key = 'platform_strategy_output_%s_%d' % (self.id, config_id)
        if cache and config_id == 0:
            res = get_cache(cache_key)
            if res:
                if self.node in ('back_test', 'order_list', 'group', 'trademaster_order_list', 'union_simu'):
                    for k, v in res.items():
                        if not v['pnl']:
                            res = {}
                            break
                if res:
                    return res

        if self.node == 'ev':
            res = self.ev_output(config_id)
        elif self.node == 'para':  # TODO: Not used anymore ?
            res = self.para_output()
        elif self.node in ('back_test', 'order_list', 'group', 'trademaster_order_list', 'union_simu'):
            res = self.back_test_output(config_id)
        else:
            res = {}

        if res:
            set_cache(cache_key, res, 8 * 3600)

        return res

    @staticmethod
    def get_output_pnl(data):
        ret_pnl = {}
        if data:
            need = list(data.items())[0][1]
            if 'pnl' in need:
                ret_pnl = need['pnl']
        return ret_pnl

    def ev_output(self, config_id=0):
        sc = session()
        res = sc.query(
            StrategyResult.product.label('product'),
            StrategyResult.date.label('date'),
            StrategyResult.result_file_name.label('result_file_name'),
        ).filter(
            StrategyResult.strategy_id == self.id,
            StrategyResult.config_id == config_id,
            StrategyResult.status == consts.TASK_FINISHED,
            StrategyResult.result_file_name.isnot(None),
        ).all()
        output = {}
        for r in res:
            if r.product in output:
                output[r.product][r.date] = r.result_file_name
            else:
                output[r.product] = {r.date: r.result_file_name}
        sc.close()
        return output

    def para_output(self):
        return {}

    def group_back_test_result(self, config_id=0, cache=True, start_date='', end_date=''):
        sc = session()
        weights = self.group_detail
        strats, vs_ids = {}, {}
        gross = float(self.detail.get('initial_cash', 1000000) or 1000000)
        for s_id, w in weights.items():
            strats[s_id] = sc.query(Strategy).filter(Strategy.id == s_id).first()
            vstrategies = sc.query(VStrategies).filter(VStrategies.strategy_id == s_id)
            for vs in vstrategies:
                if s_id not in vs_ids:
                    vs_ids[s_id] = vs.id
                if vs.status == consts.STRATEGY_LIVE:
                    vs_ids[s_id] = vs.id
                    break
        back_test_pnl = {}
        paper_trading_date = max(
            [(s.paper_trading_date or s.r_create_time).strftime('%Y-%m-%d') for s in strats.values() if s])
        sc.close()

        for id, s in strats.items():
            _backtest = Strategy.get_output_pnl(s.output(config_id))
            back_test_pnl[id] = sorted(_backtest.items(), key=lambda r: r[0])
        aggregate_backtest_pnl = {}
        back_test_start_date = max([s.start_date for s in strats.values()] + ['20100101'])
        adj_backtest_weights = {id: weight * gross / strats[id].detail.get('initial_cash', 1000000) for id, weight in
                                weights.items()}
        for id, pnl in back_test_pnl.items():
            if pnl:
                del pnl[0]
                _temp = {k: v[1] * adj_backtest_weights[id] + aggregate_backtest_pnl.get(k, 0) for k, v in pnl if
                         k >= back_test_start_date}
                aggregate_backtest_pnl.update(_temp)
        pnl_input = {
            'live_date': [],
            'live_pnl': [],
            'live_asset': [],
            'live_position_value': [],
            'live_cash_io': [],
            'back_test_date': [],
            'back_test_asset': [],
            'back_test_pnl': [],
            'back_test_position_value': [],
            'back_test_cash_io': [],
            'paper_trading_date': paper_trading_date,
        }
        if start_date:
            start_date = parse(start_date).strftime('%Y%m%d')
        else:
            start_date = '19900101'
        if end_date:
            end_date = parse(end_date).strftime('%Y%m%d')
        else:
            end_date = time.strftime('%Y%m%d')
        backtest_open_asset = gross
        backtest_position = 0.0
        for day, pnl in sorted(aggregate_backtest_pnl.items(), key=lambda d: d[0]):
            if start_date <= day <= end_date:
                pnl_input['back_test_date'].append(day)
                pnl_input['back_test_pnl'].append(pnl)
                pnl_input['back_test_asset'].append(backtest_open_asset)
                pnl_input['back_test_position_value'].append(backtest_position)
                pnl_input['back_test_cash_io'].append(0)
            backtest_open_asset += pnl
        return pnl_input

    def back_test_output(self, config_id=0):

        t0_daily_pnl_extra = {}

        initial_cash = self.detail.get('initial_cash', 1000000) or 1000000

        default_stock_fee = 0.00016 if self.strategy_type != '28' else 0.00025

        stock_fee = self.detail.get('stock_fee_rate', default_stock_fee) or default_stock_fee

        if self.group_id > 0:
            # Portfolio back testing.
            back_test_result = self.group_back_test_result()
        else:
            sc = session()
            res = sc.query(
                StrategyResult.date.label('date'),
                StrategyResult.pnl.label('pnl'),
                StrategyResult.position_cash.label('position_cash'),
                StrategyResult.total_asset.label('total_asset'),
            ).filter(
                StrategyResult.strategy_id == self.id,
                StrategyResult.config_id == config_id,
                StrategyResult.status == consts.TASK_FINISHED
            ).order_by(StrategyResult.date)

            back_test_result = {
                'live_date': [],
                'live_pnl': [],
                'live_asset': [],
                'live_position_value': [],
                'live_end_position_value': 0.0,
                'live_cash_io': [],
                'back_test_date': [],
                'back_test_asset': [],
                'back_test_pnl': [],
                'back_test_position_value': [],
                'back_test_end_position_value': 0.0,
                'back_test_cash_io': [],
                'paper_trading_date': (self.paper_trading_date or self.r_create_time).strftime('%Y-%m-%d'),
            }

            paper_trading_date = (self.paper_trading_date or self.r_create_time).strftime('%Y%m%d')
            confidence = float(self.confidence)

            if config_id > 0:
                initial_cash = Strategy.get_semi_info(config_id).get('initial_cash', 1000000) or 1000000

            daily_open_asset = float(initial_cash)
            daily_position_cash = 0.0
            alpha_position_cash = {}
            if (self.strategy_type in consts.t0_stock_strategy_type) and self.detail.get('alpha_s_id'):
                try:
                    alpha_position_cash = get_t0_position(int(self.detail.get('alpha_s_id')), mode="new")
                except Exception as e:
                    sentry.captureException()
            for r in res:
                back_test_result['back_test_date'].append(r.date)
                back_test_result['back_test_asset'].append(daily_open_asset + alpha_position_cash.get(r.date, 0))
                r_pnl = float(r.pnl)
                if r.date < paper_trading_date and r_pnl > 0:
                    back_test_result['back_test_pnl'].append(r_pnl * confidence)
                else:
                    back_test_result['back_test_pnl'].append(r_pnl)
                back_test_result['back_test_position_value'].append(daily_position_cash)
                back_test_result['back_test_cash_io'].append(0)
                if r.total_asset:
                    daily_open_asset = float(r.total_asset)
                else:
                    daily_open_asset += float(r.pnl)
                daily_position_cash = float(r.position_cash or 0.0)
                t0_daily_pnl_extra[r.date] = [daily_open_asset, alpha_position_cash.get(r.date, 0), stock_fee]
            back_test_result['back_test_end_position_value'] = daily_position_cash
            sc.close()

        if self.products:
            product_key = '|'.join([p['symbol'] for p in self.products[0]])[:250]
        else:
            product_key = ''
        if not self.hedge:
            if self.is_single_interest:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_stock_strategies_quest(back_test_result)
            else:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategies_quest(back_test_result)
        else:
            back_test_result['hedge'] = ''
            back_test_result['hedge_type'] = ''

            if len(back_test_result['back_test_position_value']) >= 2:
                back_test_result['back_test_position_value'][0] = back_test_result['back_test_position_value'][1]
            elif len(back_test_result['back_test_position_value']) == 1:
                back_test_result['back_test_position_value'][0] = back_test_result['back_test_end_position_value']
            if self.is_single_interest:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_stock_strategy_hedge_quest(
                    back_test_result)
            else:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategy_hedge_quest(back_test_result)

        if net_pnl[0]:
            null_pnl_detail = {
                'pnl': {},
                'hedge_net': {},
                'origin_net': {},
                'sharpe': 0,
                'profitrate': 0,
                'annual_return': 0,
                'max_drawdown_pnl': 0,
                'max_drawdown_start': 0,
                'max_drawdown_end': 0,
                'paper_trading_sharpe': 0,
                'paper_trading_profitrate': 0,
                'paper_trading_annual_return': 0,
                'paper_trading_max_drawdown_pnl': 0,
                'paper_trading_max_drawdown_start': 0,
                'paper_trading_max_drawdown_end': 0
            }
            return {product_key: null_pnl_detail}
        else:
            detail = net_pnl[1]
            _pnl = {}
            _t0_daily_pnl_extra = {}
            _default_t0_daily_pnl_extra = [initial_cash, 0, stock_fee]

            for k, v in detail['back_test_pnl'].items():
                k = k.decode('utf-8')
                _pnl[k] = v
                _t0_daily_pnl_extra[k] = t0_daily_pnl_extra.get(k, _default_t0_daily_pnl_extra)

            pnl_detail = {
                'pnl': _pnl,
                'hedge_net': {},
                'origin_net': {},
                'sharpe': detail['back_test_sharpe'],
                'profitrate': detail['back_test_profitrate'],
                'annual_return': detail['back_test_annual_return'],
                'max_drawdown_pnl': detail['back_test_max_drawdown_pnl'],
                'max_drawdown_start': detail['back_test_max_drawdown_start'],
                'max_drawdown_end': detail['back_test_max_drawdown_end'],
                'paper_trading_sharpe': detail['paper_trading_sharpe'],
                'paper_trading_profitrate': detail['paper_trading_profitrate'],
                'paper_trading_annual_return': detail['paper_trading_annual_return'],
                'paper_trading_max_drawdown_pnl': detail['paper_trading_max_drawdown_pnl'],
                'paper_trading_max_drawdown_start': detail['paper_trading_max_drawdown_start'],
                'paper_trading_max_drawdown_end': detail['paper_trading_max_drawdown_end'],
            }
            if self.strategy_type in consts.t0_stock_strategy_type:
                pnl_detail['t0_daily_pnl_extra'] = _t0_daily_pnl_extra
            if self.hedge:
                pnl_detail['hedge_net'] = {
                    key.decode("utf-8"): value for key, value in detail['back_test_hedge_net'].items()
                }
                pnl_detail['origin_net'] = {
                    key.decode("utf-8"): value for key, value in detail['back_test_origin_net'].items()
                }
            return {product_key: pnl_detail}

    def output_dependency(self, cache=True):
        if self.is_test or self.is_delete:
            return []
        dependency = []
        output_files = self.output(cache=cache)
        if output_files:
            days = list(set(itertools.chain.from_iterable([v.keys() for v in output_files.values()])))
            if days:
                dependency.append(
                    {
                        'id': self.id,
                        'name': '%s_%s_output' % (self.name, self.node),
                        'start': min(days),
                        'end': max(days),
                        'products': list(output_files.keys()),
                        'type': self.node,
                    }
                )
        return dependency

    def report(self, user_id=None):
        if (self.node not in ('back_test', 'order_list', 'group', 'trademaster_order_list', 'union_simu')) or (
                self.is_delete > 0) or (self.is_test > 0):
            return {}
        data = {
            'id': self.id,
            'name': self.name,
            'group_id': self.group_id,
            'strategy_id': self.id_no or self.name,
            'status': self.strategy_status or 'BT',
            'type': consts.STRATEGY_TYPE.get(self.strategy_type, consts.STRATEGY_TYPE['01']),
            'feature': consts.STRATEGY_FEATURE.get(self.strategy_feature, consts.STRATEGY_FEATURE['999']),
            'underlying': consts.STRATEGY_UNDERLYING_TYPE.get(self.strategy_underlying,
                                                              consts.STRATEGY_UNDERLYING_TYPE['07']),
            'para_type': consts.STRATEGY_PARA_TYPE.get(self.strategy_para_type, consts.STRATEGY_PARA_TYPE['1']),
            'created_time': str(self.r_create_time),
            'created_date': self.r_create_time.strftime('%Y-%m-%d'),
            'creator': self.username,
            'products': self.products,
            'strategy_type': self.node,
            'desc': self.description,
            'dependency': self.dependency or [],
            'day_night': self.day_night,
            'start_date': self.start_date if self.strategy_status != 'NEW' else None,
            'hedge': self.hedge or '',
            'hedge_type': self.hedge_type or '',
        }
        if user_id:
            data['semi_live'] = BackTestConfig.is_wait_live(user_id, self.id)
        if self.node in ('order_list', 'trademaster_order_list'):
            data['para_type'] = ''
            data['status'] = self.strategy_status or 'NEW'
            data['products'] = self.products
        return data

    def rank_detail(self, user_id=None):
        if (self.node not in ('back_test', 'order_list', 'group', 'trademaster_order_list', 'union_simu')) or (
                self.is_delete > 0) or (self.is_test > 0):
            return {}
        data = {
            'id': self.id,
            'name': self.name,
            'group_id': self.group_id,
            'strategy_id': self.id_no or self.name,
            'status': self.strategy_status or 'BT',
            'feature': consts.STRATEGY_FEATURE.get(self.strategy_feature, consts.STRATEGY_FEATURE['999']),
            'underlying': consts.STRATEGY_UNDERLYING_TYPE.get(self.strategy_underlying,
                                                              consts.STRATEGY_UNDERLYING_TYPE['07']),
            'created_time': str(self.r_create_time),
            'created_date': self.r_create_time.strftime('%Y-%m-%d'),
            'creator': self.username,
            'products': self.products,
            'desc': self.description,
            'dependency': self.dependency or [],
            'day_night': self.day_night,
            'start_date': self.start_date if self.strategy_status != 'NEW' else None,
            'hedge': self.hedge or '',
            'hedge_type': self.hedge_type or '',
        }
        if user_id:
            data['semi_live'] = BackTestConfig.is_wait_live(user_id, self.id)
        if self.node in ('order_list', 'trademaster_order_list'):
            data['para_type'] = ''
            data['status'] = self.strategy_status or 'NEW'
            data['products'] = self.products
        return data

    def save_detail(self):
        """update detail
        field task_progress is taken care of independently
        if there is other fields
        """
        new_detail = dict(self.detail)
        for c in self.__table__.columns:
            key = c.name
            key = "task_progress" if key == "progress" else key
            try:
                new_detail[key] = getattr(self, key)
            except AttributeError:
                return False
        self.detail = new_detail
        return True

    def update_name_and_des(self, new_name, description):
        """update name and description"""

        # update fields and json string in detail
        # it should be noted that:
        #                       mapping to
        # description in fields ==========> desc in json string
        new_detail = dict(self.detail)
        if new_name:
            self.name = new_name
            new_detail['name'] = new_name
        if description:
            self.description = description
            new_detail['desc'] = description
        self.detail = new_detail
        return True

    def update_status(self):
        if self.status == consts.TASK_STOPPED:
            return 0
        progress = self.progress()
        total, failed, finished, running = progress['total'], progress['failed'], progress['finished'], progress[
            'running']
        if running > 0:
            self.status = consts.TASK_RUNNING
        if failed > 0:
            self.status = consts.TASK_FAILED
        task_progress = self.task_progress or 0
        if task_progress >= 1:
            self.status = consts.TASK_FINISHED
        if finished >= total and self.node in (
                'back_test', 'order_list', 'trademaster_order_list') and task_progress > 0.96:
            if self.strategy_status == 'NEW':
                self.strategy_status = 'BT'
        self.update_cache()
        return True

    def update_cache(self):
        self.output(cache=False)
        return True

    @property
    def input_dependency_ids(self):
        return [d['id'] for d in (self.dependency or [])]

    @property
    def exchanges(self):
        res = []
        for p in self.products[0]:
            if p.get('exch'):
                res.append(p['exch'])
            else:
                res.append(get_exchange_by_longname(p['symbol']))
        return res

    @staticmethod
    def investment_performance_net_pnl(strategy_id, vs_ids=None, **kwargs):
        cache_key = 'investment_performance_net_pnl_%s'
        if vs_ids:
            cache_key = cache_key % ('_'.join(map(str, [strategy_id] + sorted(vs_ids))))
        else:
            cache_key = cache_key % strategy_id

        trading_date = kwargs.get('trading_date', '')
        day_night = kwargs.get('day_night', -1)
        if not trading_date or day_night == -1:
            trading_date, day_night = StrategyPerfInput.get_trading_date_day_night()

        res = get_cache(cache_key)
        if res and res.get('trading_date', '') == trading_date and res.get('day_night', '') == day_night:
            return res

        pnl_details = Strategy.pnl_detail(strategy_id, _vs_ids=vs_ids)

        is_single_interest = False
        with session_context() as sc:
            s = sc.query(Strategy).filter(
                Strategy.id == strategy_id
            ).first()
            if s and s.is_single_interest:
                is_single_interest = True

        back_test_paper_trading_net_line = Strategy.back_test_paper_trading_net_line(
            pnl_details['back_test_pnl'], pnl_details['paper_trading_date'],
            pnl_details['hedge'], pnl_details['hedge_type'], 'back_test_',
            is_single_interest=is_single_interest
        )

        live_combine_detail = {}
        for vs_id, live_detail in pnl_details['live_pnl'].items():
            for d, _pnl in live_detail.items():
                if d not in live_combine_detail:
                    live_combine_detail[d] = _pnl
                else:
                    live_combine_detail[d] = [live_combine_detail[d][i] + v for i, v in enumerate(_pnl)]

        live_net_combine_line = Strategy.live_net_line(
            live_combine_detail, pnl_details['paper_trading_date'], pnl_details['hedge'], pnl_details['hedge_type'],
            is_single_interest=is_single_interest
        )

        vs_back_test_combine_detail = {}
        for vs_id, vs_back_test_detail in pnl_details['vs_back_test_pnl'].items():
            for d, _pnl in vs_back_test_detail.items():
                if d not in vs_back_test_combine_detail:
                    vs_back_test_combine_detail[d] = _pnl
                else:
                    vs_back_test_combine_detail[d] = [vs_back_test_combine_detail[d][i] + v for i, v in enumerate(_pnl)]

        vs_back_test_combine_net = Strategy.vs_back_test_net_line(
            vs_back_test_combine_detail, pnl_details['paper_trading_date'],
            pnl_details['hedge'], pnl_details['hedge_type'], 'vs_back_test_',
            is_single_interest=is_single_interest
        )

        res = {
            'back_test_paper_trading_net_line': back_test_paper_trading_net_line,
            'live_net_combine_line': live_net_combine_line,
            'vs_back_test_combine_net': vs_back_test_combine_net,
            'trading_date': trading_date,
            'day_night': day_night,
            'strategy_type': pnl_details.get('strategy_type', ''),
        }
        if pnl_details.get('back_test_t0_daily_pnl_extra'):
            back_test_t0_daily_pnl_extra = {
                k: pnl_details['back_test_t0_daily_pnl_extra'].get(k, pnl_details['back_test_t0_daily_pnl_extra'][
                    'default'])
                for k in res['back_test_paper_trading_net_line']['back_test_pnl'].keys()
            }
            res['back_test_paper_trading_net_line']['back_test_t0_daily_pnl_extra'] = back_test_t0_daily_pnl_extra
        if pnl_details.get('vs_back_test_t0_daily_pnl_extra'):
            vs_back_test_t0_daily_pnl_extra = {
                k: pnl_details['vs_back_test_t0_daily_pnl_extra'].get(k, pnl_details['vs_back_test_t0_daily_pnl_extra'][
                    'default'])
                for k in res['vs_back_test_combine_net']['vs_back_test_pnl'].keys()
            }
            res['vs_back_test_combine_net']['vs_back_test_t0_daily_pnl_extra'] = vs_back_test_t0_daily_pnl_extra
        if pnl_details.get('live_t0_daily_pnl_extra'):
            live_t0_daily_pnl_extra = {
                k: pnl_details['live_t0_daily_pnl_extra'].get(k, pnl_details['live_t0_daily_pnl_extra']['default'])
                for k in res['live_net_combine_line']['pnl'].keys()
            }
            res['live_net_combine_line']['t0_daily_pnl_extra'] = live_t0_daily_pnl_extra

        set_cache(cache_key, res, 3600)
        return res

    @staticmethod
    def clear_investmentperformance_cache():
        cache_rds = redis.Redis(host=config.redis['host'], port=config.redis['port'], db=config.redis['db'])
        for key in cache_rds.keys('platform_vstrategies_invest_funds_total_pnl_*'):
            cache_rds.delete(key)
        for key in cache_rds.keys('investment_performance_net_pnl_*'):
            cache_rds.delete(key)
        for key in cache_rds.keys('platform_investment_performance_v2_*'):
            cache_rds.delete(key)
        return True

    @staticmethod
    def get_strategy_slippage(ids, id_type):
        from service.vwap.models import StrategySlippage
        return StrategySlippage.get_strategy_slippage(ids, id_type)

    @staticmethod
    def get_accident_events(vs_ids):
        result = {}
        id_list = [str(id) for id in vs_ids]
        stmt = "select trading_date_start, vstrategy_id, description, trading_date_end, " \
               "calendar_time_start, calendar_time_end from strategy_accident" \
               " where vstrategy_id in (%s)" % (','.join(id_list))
        sc = session()
        rows = sc.execute(stmt)
        descs = {}
        for row in rows:
            fmt_date = row[0].strftime('%Y-%m-%d')
            end_date = row[3].strftime('%Y-%m-%d') if row[3] else 'none'
            event = {
                'vs_id': row[1],
                'description': row[2] or '',
                'repair_date': end_date,
                'start_time': row[4] and row[4].strftime('%Y-%m-%d %X') or '',
                'end_time': row[5] and row[5].strftime('%Y-%m-%d %X') or '',
            }
            key = '%s_%s_%s' % (event['start_time'], event['end_time'], event['description'][:100])
            if key in descs:
                continue
            else:
                descs[key] = 1
            if fmt_date in result:
                result[fmt_date].append(event)
            else:
                result[fmt_date] = [event]
        sc.close()
        return result

    @staticmethod
    def get_vs_cash_io(vs_ids):
        sc = session()
        cash_io = sc.query(
            VStrategyAccountDetail.vstrategy_id.label('vstrategy_id'),
            VStrategyAccountDetail.trading_date.label('trading_date'),
            func.sum(VStrategyAccountDetail.amount).label('amount'),
        ).filter(
            VStrategyAccountDetail.vstrategy_id.in_(vs_ids)
        ).group_by(VStrategyAccountDetail.vstrategy_id, VStrategyAccountDetail.trading_date)

        vs_cash_io = {}
        for cash in cash_io:
            if cash.vstrategy_id not in vs_cash_io:
                vs_cash_io[cash.vstrategy_id] = {}
            if not cash.trading_date:
                vs_cash_io[cash.vstrategy_id]['init_cash'] = float(cash.amount)
            else:
                vs_cash_io[cash.vstrategy_id][cash.trading_date.strftime('%Y%m%d')] = float(cash.amount)
        sc.close()
        return vs_cash_io

    @staticmethod
    def vs_live_pnl_detail(strategy_id, _vs_ids=None, hedge='', hedge_type='', **kwargs):
        if not (strategy_id or _vs_ids):
            raise ValueError('strategy_id, vs_ids can not both be none')
        live_pnl = {}
        sc = session()
        vstrategies = sc.query(
            VStrategies.id.label('vs_id')
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            VStrategies.source == 'platform',
        )

        if _vs_ids:
            vstrategies = vstrategies.filter(VStrategies.id.in_(list(_vs_ids)))
        elif strategy_id:
            vstrategies = vstrategies.filter(
                or_(
                    VStrategies.strategy_id == strategy_id,
                    VStrategies.group_id == strategy_id
                ))

        vs_ids = [vs.vs_id for vs in vstrategies]
        vs_alpha_position = {}
        strategy_type = kwargs.get('strategy_type', '')
        is_t0_strategy = strategy_type in consts.t0_stock_strategy_type
        if is_t0_strategy:
            for vs_id in vs_ids:
                try:
                    vs_alpha_position[vs_id] = vs_get_t0_alpha_position(vs_id)
                except Exception as e:
                    sentry.captureException()
                    vs_alpha_position[vs_id] = {}

        stock_fee = 0.00025 if strategy_type == '28' else 0.00012

        t0_daily_pnl_extra = {
            'default': [0, 0, stock_fee]
        }

        vs_base = sc.query(
            VsBase.vstrategy_id.label('vstrategy_id'),
            VsBase.pnl.label('pnl'),
            VsBase.accumulated_pnl.label('accumulated_pnl'),
            VsBase.cash.label('available_cash'),
            VsBase.position_cash.label('position_cash'),
            VsBase.settle_date.label('settle_date'),
            VsBase.daynight.label('day_night'),
        ).filter(
            VsBase.vstrategy_id.in_(vs_ids),
            # VsBase.daynight == 'DAY',
        )

        vs_live_time = sc.query(StrategyPortfolio.live_time, VStrategies.id).join(
            VStrategies, VStrategies.portfolio_id == StrategyPortfolio.id
        ).filter(
            VStrategies.id.in_(vs_ids)
        )
        vs_live_time = {
            r[1]: r[0] and r[0].strftime('%Y%m%d') or '20000101' for r in vs_live_time
        }
        vs_open_position = {}
        for r in vs_base:
            if r.vstrategy_id not in live_pnl:
                live_pnl[r.vstrategy_id] = {}
            trading_date = r.settle_date.strftime('%Y%m%d')
            if trading_date < vs_live_time.get(r.vstrategy_id, '20000101'):
                continue
            elif (trading_date == vs_live_time.get(r.vstrategy_id, '20000101')) and (r.day_night == 'NIGHT'):
                vs_open_position[r.vstrategy_id] = float(r.position_cash)

            if r.day_night == 'NIGHT':
                continue

            if trading_date not in live_pnl[r.vstrategy_id]:
                live_pnl[r.vstrategy_id][trading_date] = [
                    float(r.pnl), float(r.position_cash), float(r.available_cash),
                    float(r.position_cash) + float(r.available_cash), float(r.accumulated_pnl), float(r.position_cash),
                    0
                ]
            else:
                if r.day_night == 'DAY':
                    live_pnl[r.vstrategy_id][trading_date] = [
                        float(r.pnl), float(r.position_cash), float(r.available_cash),
                        float(r.position_cash) + float(r.available_cash), float(r.accumulated_pnl),
                        float(r.position_cash), 0
                    ]
        vs_cash_io = Strategy.get_vs_cash_io(vs_ids)
        open_asset_index = 3
        position_cash_index = 1
        pnl_index = 0
        accumulated_pnl_index = 4
        cash_io_index = 6

        for vs_id, _live_pnl in live_pnl.items():
            _vs_cash_io = vs_cash_io.get(vs_id, {})
            _vs_alpha_position = vs_alpha_position.get(vs_id, {})
            _days = sorted(_live_pnl.keys())
            _d_close_asset = _vs_cash_io.get('init_cash', 0)
            if _days:
                _d_close_asset += _vs_cash_io.get(_days[0], 0)
            _d_close_position_cash = vs_open_position.get(vs_id, 0)
            _d_prev_accumulated_pnl = 0
            for index, d in enumerate(_days):
                _live_pnl[d][pnl_index] = _live_pnl[d][accumulated_pnl_index] - _d_prev_accumulated_pnl
                if hedge and d > '20171110':
                    _d_open_asset = _d_close_asset
                    _d_close_asset = _live_pnl[d][open_asset_index]
                else:
                    _d_open_asset = _d_close_asset + _vs_cash_io.get(d, 0)
                    _d_close_asset = _d_open_asset + _live_pnl[d][pnl_index]
                _live_pnl[d][
                    open_asset_index] = _d_open_asset if _d_open_asset >= _d_close_position_cash else _d_close_position_cash

                if is_t0_strategy:
                    t0_daily_pnl_extra[d] = [_d_open_asset, _vs_alpha_position.get(d, 0), stock_fee]
                    if _vs_alpha_position.get(d):
                        if vs_id in consts.t0_vs_ids_version_01:
                            _live_pnl[d][open_asset_index] = _vs_alpha_position[d]
                            t0_daily_pnl_extra[d][0] = 0
                        else:
                            _live_pnl[d][open_asset_index] += _vs_alpha_position[d]
                _live_pnl[d][position_cash_index], _d_close_position_cash = _d_close_position_cash, _live_pnl[d][
                    position_cash_index]
                _d_prev_accumulated_pnl = _live_pnl[d][accumulated_pnl_index]
                # if index > 0:
                _live_pnl[d][cash_io_index] = _vs_cash_io.get(d, 0)
        sc.close()
        return {
            'live_pnl': live_pnl,
            'vs_cash_io': vs_cash_io,
            't0_daily_pnl_extra': t0_daily_pnl_extra if is_t0_strategy else {},
        }

    @staticmethod
    def vs_back_test_pnl_detail(strategy_id, _vs_ids=None, hedge='', hedge_type='', **kwargs):
        if not (strategy_id or _vs_ids):
            raise ValueError('strategy_id, vs_ids can not both be none')
        vs_back_test_pnl = {}
        sc = session()
        vstrategies = sc.query(
            VStrategies.id.label('vs_id')
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            VStrategies.source == 'platform',
        )
        if _vs_ids:
            vstrategies = vstrategies.filter(VStrategies.id.in_(list(_vs_ids)))
        elif strategy_id:
            vstrategies = vstrategies.filter(
                or_(
                    VStrategies.strategy_id == strategy_id,
                    VStrategies.group_id == strategy_id
                )
            )

        vs_ids = [vs.vs_id for vs in vstrategies]

        vs_alpha_position = {}
        strategy_type = kwargs.get('strategy_type', '')
        is_t0_strategy = strategy_type in consts.t0_stock_strategy_type
        if is_t0_strategy:
            for vs_id in vs_ids:
                try:
                    vs_alpha_position[vs_id] = vs_get_t0_alpha_position(vs_id)
                except Exception as e:
                    sentry.captureException()
                    vs_alpha_position[vs_id] = {}

        stock_fee = 0.00025 if strategy_type == '28' else 0.00012

        t0_daily_pnl_extra = {
            'default': [0, 0, stock_fee]
        }

        vs_res = sc.query(
            VstrategyBackTestResult.vstrategy_id.label('vstrategy_id'),
            VstrategyBackTestResult.trading_date.label('trading_date'),
            VstrategyBackTestResult.day_night.label('day_night'),
            VstrategyBackTestResult.pnl.label('pnl'),
            VstrategyBackTestResult.position_cash.label('position_cash'),
            VstrategyBackTestResult.asset_cash.label('asset_cash'),
            VstrategyBackTestResult.available_cash.label('available_cash'),
            VstrategyBackTestResult.done_time.label('done_time'),
        ).filter(
            VstrategyBackTestResult.vstrategy_id.in_(vs_ids)
        )

        vs_back_test_done_time = {}

        for r in vs_res:
            if r.vstrategy_id not in vs_back_test_pnl:
                vs_back_test_pnl[r.vstrategy_id] = {}
            if r.vstrategy_id not in vs_back_test_done_time:
                vs_back_test_done_time[r.vstrategy_id] = {}
            trading_date = r.trading_date.strftime('%Y%m%d')
            vs_back_test_done_time[r.vstrategy_id][trading_date] = r.done_time.strftime('%Y%m%d%H%M%S')
            if trading_date not in vs_back_test_pnl[r.vstrategy_id]:
                vs_back_test_pnl[r.vstrategy_id][trading_date] = [
                    float(r.pnl), float(r.position_cash), float(r.available_cash),
                    float(r.position_cash) + float(r.available_cash), float(r.position_cash), 0
                ]
            else:
                vs_back_test_pnl[r.vstrategy_id][trading_date][0] += float(r.pnl)
                if r.day_night == 0:
                    vs_back_test_pnl[r.vstrategy_id][trading_date][1] = float(r.position_cash)
                    vs_back_test_pnl[r.vstrategy_id][trading_date][2] = float(r.available_cash)
                    vs_back_test_pnl[r.vstrategy_id][trading_date][3] = float(r.position_cash) + float(r.available_cash)
                    vs_back_test_pnl[r.vstrategy_id][trading_date][4] = float(r.position_cash)

        vs_cash_io = Strategy.get_vs_cash_io(vs_ids)
        open_asset_index = 3
        position_cash_index = 1
        pnl_index = 0
        cash_io_index = 5

        for vs_id, vs_bt_pnl in vs_back_test_pnl.items():
            _vs_cash_io = vs_cash_io.get(vs_id, {})
            _vs_alpha_position = vs_alpha_position.get(vs_id, {})
            _days = sorted(vs_bt_pnl.keys())
            _d_close_asset = _vs_cash_io.get('init_cash', 0)
            if _days:
                _d_close_asset += _vs_cash_io.get(_days[0], 0)
            _d_close_position_cash = 0
            for index, d in enumerate(_days):
                if hedge:
                    if vs_back_test_done_time[vs_id][d] <= '20190417143000':
                        _d_open_asset = _d_close_asset + _vs_cash_io.get(d, 0)
                    else:
                        _d_open_asset = _d_close_asset
                    _d_close_asset = vs_bt_pnl[d][open_asset_index]
                else:
                    _d_open_asset = _d_close_asset + _vs_cash_io.get(d, 0)
                    _d_close_asset = _d_open_asset + vs_bt_pnl[d][pnl_index]
                vs_bt_pnl[d][
                    open_asset_index] = _d_open_asset if _d_open_asset >= _d_close_position_cash else _d_close_position_cash
                t0_daily_pnl_extra[d] = [_d_open_asset, _vs_alpha_position.get(d, 0), stock_fee]
                if is_t0_strategy:
                    if _vs_alpha_position.get(d):
                        if vs_id in consts.t0_vs_ids_version_01:
                            vs_bt_pnl[d][open_asset_index] = _vs_alpha_position[d]
                            t0_daily_pnl_extra[d][0] = 0
                        else:
                            vs_bt_pnl[d][open_asset_index] += _vs_alpha_position[d]

                vs_bt_pnl[d][position_cash_index], _d_close_position_cash = _d_close_position_cash, vs_bt_pnl[d][
                    position_cash_index]
                # if index > 0:
                vs_bt_pnl[d][cash_io_index] = _vs_cash_io.get(d, 0)

        sc.close()
        return {
            'vs_back_test_pnl': vs_back_test_pnl,
            'vs_cash_io': vs_cash_io,
            't0_daily_pnl_extra': t0_daily_pnl_extra if is_t0_strategy else {},
        }

    @staticmethod
    def pnl_detail(strategy_id, config_id=0, _vs_ids=None):
        back_test_pnl = {}
        sc = session()
        strategy = sc.query(Strategy).filter(Strategy.id == strategy_id).first()

        # default_stock_fee = 0.00016 if strategy.strategy_type != '28' else 0.00025
        default_stock_fee = 0.00016 if strategy.strategy_type != StrategyConstant.StrategyType.HKStockT0.value \
            else 0.00025
        stock_fee = strategy.detail.get('stock_fee_rate', default_stock_fee) or default_stock_fee

        back_test_t0_daily_pnl_extra = {
            'default': [
                float(strategy.detail.get('initial_cash', 1000000) or 1000000), 0, stock_fee
            ]
        }

        alpha_position_cash = {}
        if (strategy.strategy_type in consts.t0_stock_strategy_type) and strategy.detail.get('alpha_s_id'):
            try:
                alpha_position_cash = get_t0_position(int(strategy.detail.get('alpha_s_id')))
            except Exception as e:
                pass

        if strategy.group_id > 0:
            results = strategy.group_back_test_result()
            for i, date in enumerate(results['back_test_date']):
                back_test_pnl[date] = [results['back_test_pnl'][i], results['back_test_position_value'][i], 0,
                                       results['back_test_asset'][i]]
        else:
            _paper_trading_date = (strategy.paper_trading_date or strategy.r_create_time).strftime('%Y%m%d')
            _confidence = float(strategy.confidence)
            res = sc.query(
                StrategyResult.date.label('date'),
                StrategyResult.pnl.label('pnl'),
                StrategyResult.position_cash.label('position_cash'),
                StrategyResult.available_cash.label('available_cash'),
                StrategyResult.total_asset.label('total_asset'),
            ).filter(
                StrategyResult.strategy_id == strategy.id,
                StrategyResult.config_id == config_id,
                StrategyResult.status == consts.TASK_FINISHED
            ).order_by(StrategyResult.date)
            daily_open_asset = float(strategy.detail.get('initial_cash', 1000000) or 1000000)
            daily_position_cash, daily_available_cash = 0.0, daily_open_asset
            for r in res:
                r_pnl = float(r.pnl)
                if r.date < _paper_trading_date and r_pnl > 0:
                    r_pnl *= _confidence
                back_test_pnl[r.date] = [
                    r_pnl, daily_position_cash, daily_available_cash,
                    daily_open_asset + alpha_position_cash.get(r.date, 0), float(r.position_cash or 0.0)
                ]
                back_test_t0_daily_pnl_extra[r.date] = [
                    daily_open_asset, alpha_position_cash.get(r.date, 0), stock_fee
                ]
                if r.total_asset:
                    daily_open_asset = float(r.total_asset)
                else:
                    daily_open_asset += float(r.pnl)
                daily_position_cash = float(r.position_cash or 0.0)
                daily_available_cash = float(r.available_cash or 0)

        vstrategies = sc.query(
            VStrategies.id.label('vs_id')
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            # VStrategies.strategy_id == strategy.id,
            VStrategies.source == 'platform',
        )
        if _vs_ids:
            vstrategies = vstrategies.filter(VStrategies.id.in_(_vs_ids))
        else:
            vstrategies = vstrategies.filter(VStrategies.strategy_id == strategy.id)
        vs_ids = [vs.vs_id for vs in vstrategies]
        live_pnl = Strategy.vs_live_pnl_detail(strategy.id, vs_ids, strategy.hedge, strategy.hedge_type,
                                               strategy_type=strategy.strategy_type)
        vs_back_test_pnl = Strategy.vs_back_test_pnl_detail(strategy.id, vs_ids, strategy.hedge, strategy.hedge_type,
                                                            strategy_type=strategy.strategy_type)
        res = {
            'strategy_type': strategy.strategy_type or '',
            'hedge': strategy.hedge or '',
            'hedge_type': strategy.hedge_type or '',
            'paper_trading_date': (strategy.paper_trading_date or strategy.r_create_time).strftime('%Y-%m-%d'),
            'back_test_pnl': back_test_pnl,
            'live_pnl': live_pnl['live_pnl'],
            'vs_back_test_pnl': vs_back_test_pnl['vs_back_test_pnl'],
            'vs_cash_io': live_pnl['vs_cash_io'],
            'live_t0_daily_pnl_extra': {},
            'vs_back_test_t0_daily_pnl_extra': {},
            'back_test_t0_daily_pnl_extra': {},
        }
        if (strategy.strategy_type in consts.t0_stock_strategy_type) and strategy.detail.get('alpha_s_id'):
            res['live_t0_daily_pnl_extra'] = live_pnl['t0_daily_pnl_extra']
            res['vs_back_test_t0_daily_pnl_extra'] = vs_back_test_pnl['t0_daily_pnl_extra']
            res['back_test_t0_daily_pnl_extra'] = back_test_t0_daily_pnl_extra
        sc.close()
        return res

    @staticmethod
    def back_test_net_line(data, paper_trading_date, hedge='', hedge_type='', prefix='', position_close_index=4,
                           is_single_interest=False, **kwargs):
        return Strategy.back_test_paper_trading_net_line(data, '', hedge, hedge_type, prefix, position_close_index,
                                                         is_single_interest=is_single_interest, **kwargs)

    @staticmethod
    def back_test_paper_trading_net_line(data, paper_trading_date, hedge='', hedge_type='', prefix='',
                                         position_close_index=4, is_single_interest=False, **kwargs):
        if hedge and not hedge_type:
            hedge_type = 'position'
        null_pnl_detail = {
            prefix + 'pnl': {},
            prefix + 'hedge_net': {},
            prefix + 'origin_net': {},
            prefix + 'sharpe': 0,
            prefix + 'profitrate': 0,
            prefix + 'annual_return': 0,
            prefix + 'max_drawdown_pnl': 0,
            prefix + 'max_drawdown_start': 0,
            prefix + 'max_drawdown_end': 0,
            'paper_trading_sharpe': 0,
            'paper_trading_profitrate': 0,
            'paper_trading_annual_return': 0,
            'paper_trading_max_drawdown_pnl': 0,
            'paper_trading_max_drawdown_start': 0,
            'paper_trading_max_drawdown_end': 0
        }

        if not data:
            return null_pnl_detail
        request_data = {
            'live_date': [],
            'live_pnl': [],
            'live_asset': [],
            'live_position_value': [],
            'live_cash_io': [],
            'live_end_position_value': 0,
            'back_test_date': [],
            'back_test_asset': [],
            'back_test_pnl': [],
            'back_test_position_value': [],
            'back_test_cash_io': [],
            'paper_trading_date': paper_trading_date,
            'back_test_end_position_value': 0,
        }
        pnl_index, position_index, asset_index = 0, 1, 3
        for d, pnl in sorted(data.items(), key=lambda _l: _l[0]):
            request_data['back_test_date'].append(d)
            request_data['back_test_asset'].append(pnl[asset_index])
            request_data['back_test_pnl'].append(pnl[pnl_index])
            request_data['back_test_position_value'].append(pnl[position_index])
            request_data['back_test_cash_io'].append(0)
        if position_close_index > 0 and (len(pnl) >= position_close_index + 1):
            request_data['back_test_end_position_value'] = pnl[position_close_index]

        if not hedge:
            if is_single_interest:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_stock_strategies_quest(request_data)
            else:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategies_quest(request_data)
        else:
            request_data['hedge'] = ''
            request_data['hedge_type'] = ''

            if len(request_data['back_test_position_value']) >= 2:
                request_data['back_test_position_value'][0] = request_data['back_test_position_value'][1]
            elif len(request_data['back_test_position_value']) == 1:
                request_data['back_test_position_value'][0] = request_data['back_test_end_position_value']
            if is_single_interest:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_stock_strategy_hedge_quest(request_data)
            else:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategy_hedge_quest(request_data)

        if net_pnl[0]:
            return null_pnl_detail
        else:
            detail = net_pnl[1]
            pnl_detail = {
                prefix + 'pnl': {key.decode("utf-8"): value for key, value in detail['back_test_pnl'].items()},
                prefix + 'hedge_net': {},
                prefix + 'origin_net': {},
                prefix + 'sharpe': detail['back_test_sharpe'],
                prefix + 'profitrate': detail['back_test_profitrate'],
                prefix + 'annual_return': detail['back_test_annual_return'],
                prefix + 'max_drawdown_pnl': detail['back_test_max_drawdown_pnl'],
                prefix + 'max_drawdown_start': detail['back_test_max_drawdown_start'],
                prefix + 'max_drawdown_end': detail['back_test_max_drawdown_end'],
                'paper_trading_sharpe': detail['paper_trading_sharpe'],
                'paper_trading_profitrate': detail['paper_trading_profitrate'],
                'paper_trading_annual_return': detail['paper_trading_annual_return'],
                'paper_trading_max_drawdown_pnl': detail['paper_trading_max_drawdown_pnl'],
                'paper_trading_max_drawdown_start': detail['paper_trading_max_drawdown_start'],
                'paper_trading_max_drawdown_end': detail['paper_trading_max_drawdown_end']
            }
            if hedge:
                pnl_detail[prefix + 'hedge_net'] = {
                    key.decode("utf-8"): value for key, value in detail['back_test_hedge_net'].items()
                }
                pnl_detail[prefix + 'origin_net'] = {
                    key.decode("utf-8"): value for key, value in detail['back_test_origin_net'].items()
                }
            return pnl_detail

    @staticmethod
    def vs_back_test_net_line(data, paper_trading_date, hedge='', hedge_type='', prefix='', position_close_index=4,
                              cash_io_index=5, is_single_interest=False):
        return Strategy.live_net_line(data, paper_trading_date, hedge, hedge_type, prefix, position_close_index,
                                      cash_io_index, is_single_interest)

    @staticmethod
    def live_net_line(data, paper_trading_date, hedge='', hedge_type='', prefix='', position_close_index=5,
                      cash_io_index=6, is_single_interest=False):
        if hedge and not hedge_type:
            hedge_type = 'position'

        pnl_detail = {
            prefix + 'pnl': {},
            prefix + 'hedge_net': {},
            prefix + 'origin_net': {},
            prefix + 'profitrate': 0,
            prefix + 'sharpe': 0,
            prefix + 'max_drawdown_pnl': 0,
            prefix + 'max_drawdown_start': 0,
            prefix + 'max_drawdown_end': 0,
            prefix + 'annual_return': 0,
            prefix + 'performance_total_pnl': 0,
        }
        if not data:
            return pnl_detail
        request_data = {
            'live_date': [],
            'live_pnl': [],
            'live_asset': [],
            'live_position_value': [],
            'live_cash_io': [],
            'live_end_position_value': 0,
            'back_test_date': [],
            'back_test_asset': [],
            'back_test_pnl': [],
            'back_test_position_value': [],
            'back_test_cash_io': [],
            'paper_trading_date': '',
            'back_test_end_position_value': 0,
        }
        pnl_index, position_index, asset_index = 0, 1, 3
        for d, pnl in sorted(data.items(), key=lambda _l: _l[0]):
            request_data['live_date'].append(d)
            request_data['live_asset'].append(pnl[asset_index])
            request_data['live_pnl'].append(pnl[pnl_index])
            request_data['live_position_value'].append(pnl[position_index])
            request_data['live_cash_io'].append(pnl[cash_io_index])

        if position_close_index > 0 and (len(pnl) >= position_close_index + 1):
            request_data['live_end_position_value'] = pnl[position_close_index]

        open_position = request_data['live_position_value'] and request_data['live_position_value'][0] or 0

        if not hedge:
            if is_single_interest:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_stock_strategies_quest(request_data)
            else:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategies_quest(request_data)
        else:
            request_data['hedge'] = ''
            request_data['hedge_type'] = ''

            if len(request_data['live_position_value']) >= 2:
                request_data['live_position_value'][0] = request_data['live_position_value'][1]
            elif len(request_data['live_position_value']) == 1:
                request_data['live_position_value'][0] = request_data['live_end_position_value']

            if is_single_interest:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_stock_strategy_hedge_quest(request_data)
            else:
                net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategy_hedge_quest(request_data)

        if not net_pnl[0]:
            detail = net_pnl[1]
            _pnl, performance_total_pnl = {}, 0
            for key, value in detail['pnl'].items():
                _pnl[key.decode("utf-8")] = value
                performance_total_pnl += value[1]
            if request_data['live_date']:
                if request_data['live_date'][0] in _pnl:
                    _pnl[request_data['live_date'][0]][5] = open_position
            pnl_detail = {
                prefix + 'pnl': _pnl,
                prefix + 'hedge_net': {},
                prefix + 'origin_net': {},
                prefix + 'profitrate': detail['profitrate'],
                prefix + 'sharpe': detail['sharpe'],
                prefix + 'max_drawdown_pnl': detail['max_drawdown_pnl'],
                prefix + 'max_drawdown_start': detail['max_drawdown_start'],
                prefix + 'max_drawdown_end': detail['max_drawdown_end'],
                prefix + 'annual_return': detail['annual_return'],
                prefix + 'performance_total_pnl': performance_total_pnl,
            }
            if hedge:
                pnl_detail[prefix + 'hedge_net'] = {
                    key.decode("utf-8"): value for key, value in detail['hedge_net'].items()
                }
                pnl_detail[prefix + 'origin_net'] = {
                    key.decode("utf-8"): value for key, value in detail['origin_net'].items()
                }
        return pnl_detail

    @staticmethod
    def combine_pnls(pnls, mode='back_test', prefix='', **kwargs):
        pnl_detail = {
            prefix + 'pnl': {},
            prefix + 'hedge_net': {},
            prefix + 'origin_net': {},
            prefix + 'profitrate': 0,
            prefix + 'sharpe': 0,
            prefix + 'max_drawdown_pnl': 0,
            prefix + 'max_drawdown_start': 0,
            prefix + 'max_drawdown_end': 0,
            prefix + 'annual_return': 0,
            prefix + 'performance_total_pnl': 0,
        }
        if not pnls:
            return pnl_detail
        request_data = {
            'live_date': [],
            'live_pnl': [],
            'live_asset': [],
            'live_position_value': [],
            'live_cash_io': [],
            'live_end_position_value': 0,
            'back_test_date': [],
            'back_test_asset': [],
            'back_test_pnl': [],
            'back_test_position_value': [],
            'back_test_cash_io': [],
            'paper_trading_date': '',
            'back_test_end_position_value': 0,
        }
        cash_io = kwargs.get('cash_io', {})
        if cash_io:
            init_cash = cash_io[min(cash_io.keys())]
        else:
            init_cash = 0
        pnl_index, asset_index, position_index, position_close_index = 1, 2, 5, 6
        data = {}
        for pnl in pnls:
            s_type = pnl.pop('strategy_type', '')
            for _i, (d, d_pnl) in enumerate(sorted(pnl.items(), key=lambda _x: _x[0])):
                if _i == 0:
                    continue

                if s_type not in ('18', '28', '20'):
                    _d_pnl_begin_position = d_pnl[position_index]
                    _d_pnl_end_position = d_pnl[position_close_index]
                else:
                    _d_pnl_begin_position = 0
                    _d_pnl_end_position = 0
                # if _i == 1:
                #    _d_pnl_begin_position = 0
                if d not in data:
                    data[d] = [d_pnl[pnl_index], d_pnl[asset_index], _d_pnl_begin_position, _d_pnl_end_position]
                else:
                    data[d][0] += d_pnl[pnl_index]
                    data[d][1] += d_pnl[asset_index]
                    data[d][2] += _d_pnl_begin_position
                    data[d][3] += _d_pnl_end_position

        prev_close_asset = 0 if not cash_io else init_cash

        if cash_io and data:
            prev_close_asset = sum(v for k, v in cash_io.items() if k <= min(data.keys()))
        else:
            prev_close_asset = 0

        for index, d in enumerate(sorted(data.keys())):
            if cash_io:
                if index == 0:
                    d_asset = prev_close_asset
                else:
                    d_asset = prev_close_asset + cash_io.get(d, 0)
                prev_close_asset = d_asset + data[d][0]
            else:
                d_asset = data[d][1]

            if mode == 'back_test':
                request_data['back_test_date'].append(d)
                request_data['back_test_pnl'].append(data[d][0])
                request_data['back_test_asset'].append(d_asset)
                request_data['back_test_position_value'].append(data[d][2])
                request_data['back_test_end_position_value'] = data[d][3]
                request_data['back_test_cash_io'].append(0)
            else:
                request_data['live_date'].append(d)
                request_data['live_pnl'].append(data[d][0])
                request_data['live_asset'].append(d_asset)
                request_data['live_position_value'].append(data[d][2])
                request_data['live_end_position_value'] = data[d][3]
                request_data['live_cash_io'].append(0)

        if not request_data:
            return pnl_detail

        net_pnl = PerformanceAnalyzer(kdb_ip=config.KDB_HOST).process_strategies_quest(request_data)
        ret_prefix = ''
        if mode == 'back_test':
            ret_prefix = 'back_test_'
        if not net_pnl[0]:
            detail = net_pnl[1]
            _pnl, performance_total_pnl = {}, 0
            for key, value in detail[ret_prefix + 'pnl'].items():
                _pnl[key.decode("utf-8")] = value
                performance_total_pnl += value[1]
            pnl_detail = {
                prefix + 'pnl': _pnl,
                prefix + 'hedge_net': {},
                prefix + 'origin_net': {},
                prefix + 'profitrate': detail[ret_prefix + 'profitrate'],
                prefix + 'sharpe': detail[ret_prefix + 'sharpe'],
                prefix + 'max_drawdown_pnl': detail[ret_prefix + 'max_drawdown_pnl'],
                prefix + 'max_drawdown_start': detail[ret_prefix + 'max_drawdown_start'],
                prefix + 'max_drawdown_end': detail[ret_prefix + 'max_drawdown_end'],
                prefix + 'annual_return': detail[ret_prefix + 'annual_return'],
                prefix + 'performance_total_pnl': performance_total_pnl,
            }
        return pnl_detail

    def live_analysis_pnl_grpha(self, _vs_ids=None):
        pnl_details = Strategy.pnl_detail(self.id, _vs_ids=_vs_ids)

        back_test_net_line = Strategy.back_test_net_line(
            pnl_details['back_test_pnl'], pnl_details['paper_trading_date'],
            pnl_details['hedge'], pnl_details['hedge_type'], 'back_test_'
        )

        back_test_paper_trading_net_line = Strategy.back_test_paper_trading_net_line(
            pnl_details['back_test_pnl'], pnl_details['paper_trading_date'],
            pnl_details['hedge'], pnl_details['hedge_type'], 'back_test_'
        )

        live_net_line = {
            vs_id: Strategy.live_net_line(
                live_detail, pnl_details['paper_trading_date'], pnl_details['hedge'], pnl_details['hedge_type']
            )
            for vs_id, live_detail in pnl_details['live_pnl'].items()
        }

        live_combine_detail = {}
        for vs_id, live_detail in pnl_details['live_pnl'].items():
            for d, _pnl in live_detail.items():
                if d not in live_combine_detail:
                    live_combine_detail[d] = _pnl
                else:
                    live_combine_detail[d] = [live_combine_detail[d][i] + v for i, v in enumerate(_pnl)]

        live_net_combine_line = Strategy.live_net_line(
            live_combine_detail, pnl_details['paper_trading_date'], pnl_details['hedge'], pnl_details['hedge_type']
        )

        vs_back_test_net_line = {
            vs_id: Strategy.vs_back_test_net_line(
                vs_back_test_detail, pnl_details['paper_trading_date'],
                pnl_details['hedge'], pnl_details['hedge_type'], 'vs_back_test_'
            )
            for vs_id, vs_back_test_detail in pnl_details['vs_back_test_pnl'].items()
        }

        vs_back_test_combine_detail = {}
        for vs_id, vs_back_test_detail in pnl_details['vs_back_test_pnl'].items():
            for d, _pnl in vs_back_test_detail.items():
                if d not in vs_back_test_combine_detail:
                    vs_back_test_combine_detail[d] = _pnl
                else:
                    vs_back_test_combine_detail[d] = [vs_back_test_combine_detail[d][i] + v for i, v in enumerate(_pnl)]

        vs_back_test_net_combine_line = Strategy.vs_back_test_net_line(
            vs_back_test_combine_detail, pnl_details['paper_trading_date'], pnl_details['hedge'],
            pnl_details['hedge_type'], 'vs_back_test_'
        )

        if _vs_ids:
            for vs_id in _vs_ids:
                if vs_id not in live_net_line:
                    live_net_line[vs_id] = Strategy.live_net_line({}, '')
                if vs_id not in vs_back_test_net_line:
                    vs_back_test_net_line[vs_id] = Strategy.vs_back_test_net_line({}, '', prefix='vs_back_test_')

        return {
            'back_test_net_line': back_test_net_line,
            'back_test_paper_trading_net_line': back_test_paper_trading_net_line,
            'live_net_line': live_net_line,
            'vs_back_test_net_line': vs_back_test_net_line,
            'live_net_comebine_line': live_net_combine_line,
            'vs_back_test_net_comebine_line': vs_back_test_net_combine_line,
            'vs_cash_io': pnl_details['vs_cash_io'],
        }

    def live_strategy_analysis_v2(self, *args, **kwargs):

        cache_key = 'platform_live_strategy_analysis_v2_%s' % self.id

        trading_date = kwargs.get('trading_date', '')
        day_night = kwargs.get('day_night', -1)
        if not trading_date:
            trading_date, day_night = StrategyPerfInput.get_trading_date_day_night()
        if day_night == -1:
            trading_date, day_night = StrategyPerfInput.get_trading_date_day_night()

        res = get_cache(cache_key)
        if res and res.get('trading_date', '') == trading_date and res.get('day_night', '') == day_night:
            return res
        sc = session()
        user_detail = sc.query(Users).filter(Users.id == self.r_create_user_id).first().to_dict()
        strategy = {
            'strategy_id': self.id_no,
            's_id': self.id,
            'name': self.name,
            'uptime': self.r_create_time.strftime('%Y%m%d'),
            'strategy_type': self.strategy_type,
            'strategy_feature': self.strategy_feature,
            'hedge': self.hedge or '',
            'hedge_type': self.hedge_type or '',
            'trade_model': self.detail.get('trade_model', ''),
            'realtime': '',
            'invest_funds': 0,
            'total_pnl': 0,
            'total_point': 0,
            'total_net_income': 0,
            'history_pnl': {},
            'vwap_slippage': {
                'std': None,
                'avg': None,
            },
            'user_info': [],
            'trading_date': trading_date,
            'day_night': day_night,
        }

        back_test_pnl = {}
        back_test_paper_trading_pnl = {}
        live_pnl = {}
        strategy.update(back_test_pnl)
        strategy.update(live_pnl)
        vstrategies = sc.query(
            VStrategies.id.label('vs_id'),
            VStrategies.status.label('strategy_status'),
            VStrategies.closing_out.label('close_status'),
            VStrategies.strategy_id.label('strategy_id'),
            StrategyPortfolio.name.label('portfolio_name'), StrategyPortfolio.r_create_user_id.label('p_user_id'),
            StrategyPortfolio.live_time.label('p_live_time'), StrategyPortfolio.r_create_time.label('p_create_time'),
            Strategy.id_no.label('id_no'),
            Strategy.name.label('name'),
            Strategy.detail.label('s_detail'),
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).join(
            Strategy, Strategy.id == VStrategies.strategy_id,
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            or_(and_(VStrategies.strategy_id == self.id, VStrategies.group_id == 0), VStrategies.group_id == self.id),
            StrategyPortfolio.status >= consts.STRATEGY_LIVE,
            StrategyPortfolio.source == 'platform',
            VStrategies.source == 'platform',
        ).order_by(VStrategies.id.desc())
        vs_ids = []
        invest_user_ids = []
        for vs in vstrategies:
            vs_ids.append(vs.vs_id)
            invest_user_ids.append(vs.p_user_id)

            accident_info = {}

            is_creator = StrategyUserRelation.is_creator(vs.strategy_id, kwargs['uid'])
            is_investor = StrategyUserRelation.is_investor(vs.strategy_id, kwargs['uid'])
            if kwargs['uid'] == 1 or is_creator or is_investor:
                accident_info = Strategy.get_accident_events([vs.vs_id])

            vs_detail = {
                'vs_ids': [vs.vs_id],
                'id': vs.vs_id,
                's_id': vs.strategy_id,
                'strategy_id': vs.id_no,
                'status': VStrategies.get_status(vs.strategy_status, vs.close_status),
                'strategy_type': self.strategy_type,
                'strategy_feature': self.strategy_feature,
                'invest_user': '',
                'invest_user_id': vs.p_user_id,
                'name': vs.name,
                'creator': self.username,
                'desc': self.description or '',
                'uptime': strategy['uptime'],
                'realtime': (vs.p_live_time or vs.p_create_time).strftime('%Y%m%d'),
                'platform_cost': 0,
                'total_net_income': 0,
                'invest_funds': 0,
                'total_point': 0,
                'total_pnl': 0,
                'papertrading_date': (self.paper_trading_date or self.r_create_time).strftime('%Y-%m-%d'),
                'hedge': strategy['hedge'],
                'hedge_type': strategy['hedge_type'],
                'trade_model': vs.s_detail.get('trade_model', ''),
                'vwap_slippage': Strategy.get_strategy_slippage(ids=[vs.vs_id], id_type='vs'),
                'events': accident_info
            }
            live_pnl = {}
            vs_back_test_pnl = {}
            vs_detail.update(back_test_paper_trading_pnl)
            vs_detail.update(live_pnl)
            vs_detail.update(vs_back_test_pnl)
            if not strategy['realtime']:
                strategy['realtime'] = vs_detail['realtime']
            else:
                strategy['realtime'] = min(strategy['realtime'], vs_detail['realtime'])
            strategy['user_info'].append(vs_detail)
        pnl_net_details = self.live_analysis_pnl_grpha(vs_ids)
        strategy['vwap_slippage'] = Strategy.get_strategy_slippage(ids=vs_ids, id_type='vs')
        strategy.update(pnl_net_details['live_net_comebine_line'])
        strategy.update(pnl_net_details['back_test_net_line'])
        invest_users = {}
        if invest_user_ids:
            invest_users = {u.id: u.name for u in sc.query(Users).filter(Users.id.in_(invest_user_ids))}
        for vs_d in strategy['user_info']:
            vs_d['invest_user'] = invest_users.get(vs_d['invest_user_id'], '')
            if vs_d['status'] == consts.VSTRATEGY_STATUE.get(consts.STRATEGY_OFF_SHELF):
                vs_d['invest_funds'] = 0
            else:
                vs_d['invest_funds'] = sum(pnl_net_details['vs_cash_io'].get(vs_d['id'], {}).values())
            if self.group_id > 0:
                _back_test_data = Strategy.pnl_detail(vs_d['s_id'], _vs_ids=[-1])
                vs_d.update(
                    Strategy.back_test_paper_trading_net_line(
                        _back_test_data['back_test_pnl'], _back_test_data['paper_trading_date'],
                        _back_test_data['hedge'], _back_test_data['hedge_type'], 'back_test_'
                    )
                )
            else:
                vs_d.update(pnl_net_details['back_test_paper_trading_net_line'])

            vs_d.update(pnl_net_details['vs_back_test_net_line'][vs_d['id']])
            vs_d.update(pnl_net_details['live_net_line'][vs_d['id']])
            vs_d['total_pnl'] = pnl_net_details['live_net_line'][vs_d['id']]['performance_total_pnl']

            if vs_d['total_pnl'] != 0:
                vs_d['total_point'] = round(vs_d['total_pnl'] * user_detail['platform_cost_ratio'], 3)
                vs_d['total_net_income'] = round(vs_d['total_pnl'] - vs_d['total_point'], 3)

            strategy['total_pnl'] += vs_d['total_pnl']
            strategy['total_net_income'] += vs_d['total_net_income']
            strategy['total_point'] += vs_d['total_point']
            strategy['invest_funds'] += vs_d['invest_funds']
        sc.close()
        set_cache(cache_key, strategy, 3600 * 5)
        return strategy

    @staticmethod
    def get_live_strategy_analysis(current_user):
        sc = session()
        strategies = sc.query(
            Strategy
        ).join(
            VStrategies, or_(and_(VStrategies.strategy_id == Strategy.id, VStrategies.group_id == 0),
                             VStrategies.group_id == Strategy.id)
        ).join(
            StrategyOwners,
            StrategyOwners.strategy_id == Strategy.id
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            VStrategies.source == 'platform',
            StrategyOwners.owner_id == current_user['id']
        ).order_by(Strategy.id.desc())
        data = [s.live_strategy_analysis_v2(uid=current_user['id']) for s in strategies]
        sc.close()
        return data

    @staticmethod
    def get_trading_date(hour=18, calendar_date=None, calendar_hour=None):
        kdb = KdbQuery()
        try:
            date = kdb.get_trading_date(hour, calendar_date, calendar_hour)
        except Exception as e:
            if calendar_date or calendar_hour:
                raise ValueError('get trading date error')
            now = datetime.datetime.now()
            if now.hour >= hour:
                next_day = 1 if now.weekday() != 4 else 3
                date = (now + datetime.timedelta(days=next_day)).strftime('%Y%m%d')
            else:
                date = now.strftime('%Y%m%d')
        return date

    # @staticmethod
    # def cash_manager_performance(cm_strategy_id, category):
    #     """
    #     :param cm_strategy_id: 'BT200156'|'LT956'
    #     :param category: 'BT'|'LT'
    #     :return:
    #     """
    #     return {
    #         'back_test': {
    #             'brief': {
    #                 'columns': ['trading_date', 'ret', 'pnl', 'open_asset', 'open_position'],
    #                 'values': []
    #             },
    #             'detail': {
    #                 'columns': ['trading_date', 'symbol', 'close_short', 'close_long', 'settle_price'],
    #                 'values': []
    #
    #             },
    #         },
    #         'live': {
    #             'brief': {
    #                 'columns': ['trading_date', 'ret', 'pnl', 'open_asset', 'open_position'],
    #                 'values': []
    #             },
    #             'detail': {
    #                 'columns': ['trading_date', 'symbol', 'close_short', 'close_long', 'settle_price'],
    #                 'values': []
    #
    #             },
    #         },
    #     }

    # @staticmethod
    # def cash_manager_performance_trade_logs(cm_strategy_id, category):
    #     """
    #     :param cm_strategy_id: 'BT200156'|'LT956'
    #     :param category: 'BT'|'LT'
    #     :return:
    #     """
    #     back_test_columns = [
    #         'trading_date', 'calendar_time', 'day_night', 'account', 'strategy_id', 'serial_no',
    #         'symbol', 'direction', 'open_close', 'trade_price', 'trade_vol', 'fee', 'entrust_status', 'msg_type'
    #     ]
    #
    #     live_columns = back_test_columns
    #
    #     back_test_log = {
    #         'columns': back_test_columns,
    #         'values': []
    #     }
    #
    #     live_log = {
    #         'columns': live_columns,
    #         'values': []
    #     }
    #     return {
    #         'back_test': {
    #             'trade_log': back_test_log,
    #         },
    #         'live': {
    #             'trade_log': live_log
    #         }
    #     }


class MutilFactorStrategy(ModelBase):
    __tablename__ = 'mutil_factor_strategy'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    strategy_id = Column(BIGINT(unsigned=True), index=True)
    factor_strategy_id = Column(BIGINT(unsigned=True), index=True)

    @staticmethod
    def get_main_s_id(sub_s_id):
        with session_context() as sc:
            record = sc.query(MutilFactorStrategy.strategy_id).filter(
                MutilFactorStrategy.factor_strategy_id == sub_s_id
            ).first()
            if record:
                return record.strategy_id
        return 0


class ToBeDeletedStrategy(ModelBase):
    __tablename__ = 'strategy_tobedeleted'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    strategy_id = Column(BIGINT(unsigned=True), index=True, unique=True)


class StrategyOwners(ModelBase):
    __tablename__ = 'strategy_owners'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(BIGINT(unsigned=True))
    owner_id = Column(BIGINT(unsigned=True))
    r_create_user_id = Column(BIGINT(unsigned=True), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())

    __table_args__ = (UniqueConstraint('strategy_id', 'owner_id'),)


class InvestMentShare(ModelBase):
    __tablename__ = 'investment_share'
    id = Column(BIGINT(unsigned=True), primary_key=True)
    vstrategy_id = Column(BIGINT(unsigned=True))
    owner_id = Column(BIGINT(unsigned=True))
    r_create_user_id = Column(BIGINT(unsigned=True), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())


class VstrategyBackTestResult(ModelBase):
    """
    盘后分析的结果表
    """
    __tablename__ = 'vstrategy_backtest_result'
    id = Column(BIGINT(unsigned=True), primary_key=True)
    vstrategy_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    pnl = Column(DOUBLE, default=0)
    status = Column(INTEGER, nullable=False, default=1)
    done_time = Column(DATETIME, nullable=True)
    log_files = Column(JSON, nullable=True)
    available_cash = Column(DOUBLE, default=0)
    asset_cash = Column(DOUBLE, default=0)
    position_cash = Column(DOUBLE, default=0)
    group_id = Column(INTEGER, nullable=False, default=0)
    total_asset = Column(DOUBLE, nullable=False, default=0)
    dividend = Column(DOUBLE, nullable=False, default=0)


class VstrategyBackTestResultDetail(ModelBase):
    """
    盘后分析的结果表
    """
    __tablename__ = 'vstrategy_backtest_result_detail'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vstrategy_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)
    day_night = Column(INTEGER, nullable=False)
    done_time = Column(DATETIME, nullable=True)
    symbol = Column(VARCHAR(32), nullable=False)
    product = Column(VARCHAR(32), nullable=False)
    exchange = Column(VARCHAR(12), nullable=False)
    fee = Column(DOUBLE, default=0)
    gross_pnl = Column(DOUBLE, default=0)
    pnl = Column(DOUBLE, default=0)
    long_volume = Column(INTEGER, default=0)
    long_price = Column(DOUBLE, default=0)
    short_volume = Column(INTEGER, default=0)
    short_price = Column(DOUBLE, default=0)
    dividend = Column(DOUBLE, nullable=False, default=0)
    account = Column(VARCHAR(64), nullable=True)
    currency = Column(String(20), nullable=False, default='CNY')
    forex_rate = Column(DOUBLE, nullable=False, default=1)


class VstrategyBackTestResultAccount(ModelBase):
    """
    盘后分析的结果表
    """
    __tablename__ = 'vstrategy_backtest_result_account'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vstrategy_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)
    day_night = Column(INTEGER, nullable=False)
    done_time = Column(DATETIME, nullable=True)
    account = Column(VARCHAR(64), nullable=False)
    asset_cash = Column(DOUBLE, default=0)
    available_cash = Column(DOUBLE, default=0)
    currency = Column(String(20), nullable=False, default='CNY')
    forex_rate = Column(DOUBLE, nullable=False, default=1)


class StrategyResultDetail(ModelBase):
    """
    回测的每个合约每天结束持仓
    """
    __tablename__ = 'backtest_result_detail'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)
    day_night = Column(INTEGER, nullable=False)
    done_time = Column(DATETIME, nullable=True)
    symbol = Column(VARCHAR(32), nullable=False)
    product = Column(VARCHAR(32), nullable=False)
    exchange = Column(VARCHAR(12), nullable=False)
    fee = Column(DOUBLE, default=0)
    gross_pnl = Column(DOUBLE, default=0)
    pnl = Column(DOUBLE, default=0)
    long_volume = Column(INTEGER, default=0)
    long_price = Column(DOUBLE, default=0)
    short_volume = Column(INTEGER, default=0)
    short_price = Column(DOUBLE, default=0)
    dividend = Column(DOUBLE, nullable=False, default=0)
    config_id = Column(INTEGER, nullable=False, default=0)
    account = Column(VARCHAR(64), nullable=True)
    currency = Column(String(20), nullable=False, default='CNY')
    forex_rate = Column(DOUBLE, nullable=False, default=1)


class StrategyResultAccount(ModelBase):
    """
    回测的每天每个账户的结束资金
    """
    __tablename__ = 'backtest_result_account'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False, index=True)
    day_night = Column(INTEGER, nullable=False)
    done_time = Column(DATETIME, nullable=True)
    config_id = Column(INTEGER, nullable=False, default=0)
    account = Column(VARCHAR(64), nullable=False)
    asset_cash = Column('cash_asset', DOUBLE, default=0)
    available_cash = Column('cash_available', DOUBLE, default=0)
    currency = Column(String(20), nullable=False, default='CNY')
    forex_rate = Column(DOUBLE, nullable=False, default=1)


class BackTestPositionCorpActions(ModelBase):
    __tablename__ = 'backtest_position_corp_actions'

    id = Column(INTEGER, primary_key=True)
    strategy_id = Column(INTEGER, nullable=False, index=True)
    config_id = Column(INTEGER, nullable=False, default=0)
    account = Column(String(20), nullable=False, server_default=text("''"))
    symbol = Column(String(20), nullable=False)
    today_long_pos = Column(INTEGER, nullable=False)
    today_short_pos = Column(INTEGER, nullable=False)
    # 股权登记日
    eqy_record_date = Column(Date, nullable=False, index=True)
    # 除权除息日
    ex_date = Column(Date, nullable=False, server_default=text("'1900-01-01'"))
    # 每股派息
    cash_dividend_per_share = Column(String(20), nullable=False)
    # 派息日
    dividend_cash_payout_date = Column(Date, nullable=False, index=True, server_default=text("'1900-01-01'"))
    payout_cash = Column(DOUBLE, nullable=False)
    # 每股送股比率
    share_bonus_rate = Column(DOUBLE, nullable=False)
    # 每股转增比率
    share_conversederate_rate = Column(DOUBLE, nullable=False)
    # 红股上市日期
    dividend_share_listing_date = Column(Date, nullable=False, index=True, server_default=text("'1900-01-01'"))
    # 转换后的多仓
    payout_pos = Column(DOUBLE, nullable=False)
    # 转换后的空仓
    payout_short_pos = Column(DOUBLE, nullable=False)
    create_time = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    update_time = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))

    def to_brief(self):
        return {
            'symbol': self.symbol,
            'account': self.account,
            'today_long_pos': int(self.today_long_pos),
            'today_short_pos': int(self.today_long_pos),
            'eqy_record_date': self.eqy_record_date.strftime('%Y-%m-%d'),
            'ex_date': self.ex_date.strftime('%Y-%m-%d'),
            'cash_dividend_per_share': float(self.cash_dividend_per_share),
            'dividend_share_listing_date': self.dividend_share_listing_date.strftime('%Y-%m-%d'),
            'share_bonus_rate': float(self.share_bonus_rate),
            'share_conversederate_rate': float(self.share_conversederate_rate),
            'payout_pos': float(self.payout_pos),
            'payout_short_pos': float(self.payout_short_pos),
            'payout_cash': float(self.payout_cash),
            'dividend_cash_payout_date': self.dividend_cash_payout_date.strftime('%Y-%m-%d'),
        }


class VsBackTestPositionCorpActions(ModelBase):
    __tablename__ = 'vstartegy_backtest_position_corp_actions'

    id = Column(INTEGER, primary_key=True)
    vstrategy_id = Column(INTEGER, nullable=False, index=True)
    account = Column(String(20), nullable=False, server_default=text("''"))
    symbol = Column(String(20), nullable=False)
    today_long_pos = Column(Integer, nullable=False)
    today_short_pos = Column(Integer, nullable=False)
    eqy_record_date = Column(Date, nullable=False, index=True)
    ex_date = Column(Date, nullable=False, server_default=text("'1900-01-01'"))
    cash_dividend_per_share = Column(String(20), nullable=False)
    dividend_cash_payout_date = Column(Date, nullable=False, index=True, server_default=text("'1900-01-01'"))
    payout_cash = Column(DOUBLE, nullable=False)
    share_bonus_rate = Column(DOUBLE, nullable=False)
    share_conversederate_rate = Column(DOUBLE, nullable=False)
    dividend_share_listing_date = Column(Date, nullable=False, index=True, server_default=text("'1900-01-01'"))
    payout_pos = Column(DOUBLE, nullable=False)
    payout_short_pos = Column(DOUBLE, nullable=False)
    create_time = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    update_time = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))

    def to_brief(self):
        return {
            'symbol': self.symbol,
            'account': self.account,
            'today_long_pos': int(self.today_long_pos),
            'today_short_pos': int(self.today_long_pos),
            'eqy_record_date': self.eqy_record_date.strftime('%Y-%m-%d'),
            'ex_date': self.ex_date.strftime('%Y-%m-%d'),
            'cash_dividend_per_share': float(self.cash_dividend_per_share),
            'dividend_share_listing_date': self.dividend_share_listing_date.strftime('%Y-%m-%d'),
            'share_bonus_rate': float(self.share_bonus_rate),
            'share_conversederate_rate': float(self.share_conversederate_rate),
            'payout_pos': float(self.payout_pos),
            'payout_short_pos': float(self.payout_short_pos),
            'payout_cash': float(self.payout_cash),
            'dividend_cash_payout_date': self.dividend_cash_payout_date.strftime('%Y-%m-%d'),
        }


class BackTestConfig(ModelBase):
    __tablename__ = 'back_test_config'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    user_id = Column(INTEGER, nullable=False)
    strategy_id = Column(INTEGER, nullable=False)
    task_id = Column(VARCHAR(64), nullable=False)
    start_date = Column(VARCHAR(16), nullable=False)
    trade_model = Column(VARCHAR(32), nullable=False)
    init_cash = Column(DOUBLE, nullable=False, default=0)
    status = Column(INTEGER, nullable=False, default=0)
    progress = Column(FLOAT, nullable=False, default=0)
    update_time = Column(DATETIME, nullable=False)
    group_id = Column(INTEGER, nullable=False, default=0)
    child_list = Column(VARCHAR(256), nullable=True)
    accounts = Column(JSON, nullable=True)
    link_cfg_id = Column(INTEGER, nullable=False, default=0)

    @staticmethod
    def get_quantamental_cfg_id(config_id):
        res = 0
        sc = session()
        cfg_obj = sc.query(BackTestConfig).filter(BackTestConfig.link_cfg_id == config_id).first()
        if cfg_obj:
            res = cfg_obj.id
        sc.close()
        return res

    @staticmethod
    def get_quantamental_strategy_id(config_id):
        quantamental_strategy_id = 0
        sc = session()
        cfg_obj = sc.query(BackTestConfig).filter(BackTestConfig.id == config_id).first()
        if cfg_obj and cfg_obj.link_cfg_id > 0:
            l_cfg_obj = sc.query(BackTestConfig).filter(BackTestConfig.id == cfg_obj.link_cfg_id).first()
            quantamental_strategy_id = l_cfg_obj.user_id
        sc.close()
        return quantamental_strategy_id

    @staticmethod
    def is_quantamental_cfg(config_id):
        res = False
        sc = session()
        cfg_obj = sc.query(BackTestConfig).filter(BackTestConfig.id == config_id).first()
        if cfg_obj:
            if cfg_obj.link_cfg_id > 0:
                res = True
        sc.close()
        return res

    @staticmethod
    def get_default_cfg(st_id):
        sc = session()
        start_date, cash, group_id, model, progress, accounts = '20150101', 1000000, 0, '', 0, {}
        st_obj = sc.query(Strategy).get(st_id)
        if st_obj:
            start_date = st_obj.start_date
            detail = st_obj.detail
            if 'initial_cash' in detail:
                cash = detail['initial_cash']
            if 'trade_model' in detail:
                model = detail['trade_model']
            accounts = detail.get('accounts', {})
            group_id = st_obj.group_id
            if group_id > 0:
                progress = st_obj.task_progress
                group_id = consts.STRAT_GROUP
        sc.close()
        return start_date, cash, group_id, model, progress, accounts

    @staticmethod
    def add_config(us_id, st_id, group=None):
        sc = session()
        start, cash, group_id, model, progress, accounts = BackTestConfig.get_default_cfg(st_id)
        if group:
            group_id = group
        cfg_obj = sc.query(BackTestConfig).filter(BackTestConfig.user_id == us_id,
                                                  BackTestConfig.strategy_id == st_id,
                                                  BackTestConfig.group_id == group_id).first()
        if cfg_obj:
            cfg_obj.status = consts.STRATEGY_SEMI_LIVE
        else:
            cfg_obj = BackTestConfig(
                user_id=us_id,
                strategy_id=st_id,
                task_id='0',
                start_date=start,
                trade_model=model,
                progress=progress,
                init_cash=cash,
                status=consts.STRATEGY_SEMI_LIVE,
                update_time=datetime.datetime.now(),
                group_id=group_id,
                child_list=json.dumps({"status": consts.TASK_NEW}),
                accounts=accounts,
            )
            sc.add(cfg_obj)
        sc.commit()
        sc.close()

    @staticmethod
    def copy_link_config(us_id, st_id):
        task_id = uuid.uuid1().hex
        sc = session()
        cfg_obj = sc.query(BackTestConfig).filter(
            BackTestConfig.user_id == us_id,
            BackTestConfig.strategy_id == st_id
        ).first()
        q_cfg_obj = sc.query(BackTestConfig).filter(BackTestConfig.link_cfg_id == cfg_obj.id).first()
        if q_cfg_obj:
            q_cfg_obj.status = consts.STRATEGY_SEMI_QUANTAMEMTAL
            q_cfg_obj.task_id = task_id
        else:
            q_cfg_obj = BackTestConfig(
                user_id=-1,
                strategy_id=cfg_obj.strategy_id,
                task_id=task_id,
                start_date=cfg_obj.start_date,
                trade_model=cfg_obj.trade_model,
                progress=cfg_obj.progress,
                init_cash=cfg_obj.init_cash,
                status=consts.STRATEGY_SEMI_QUANTAMEMTAL,
                update_time=datetime.datetime.now(),
                group_id=cfg_obj.group_id,
                child_list=json.dumps({"status": consts.TASK_NEW}),
                accounts=cfg_obj.accounts,
                link_cfg_id=cfg_obj.id,
            )
            sc.add(q_cfg_obj)
        sc.commit()
        sc.close()
        return task_id

    @staticmethod
    def update_config(us_id, st_id, start, cash, model, reset=False, **kwargs):
        sc = session()
        cfg_obj = sc.query(BackTestConfig).filter(BackTestConfig.user_id == us_id,
                                                  BackTestConfig.strategy_id == st_id,
                                                  BackTestConfig.group_id < consts.INVEST_GROUP).first()
        if cfg_obj:
            start_date = datetime.datetime.strptime(start, "%Y-%m-%d")
            cfg_obj.start_date = start_date.strftime('%Y%m%d')
            cfg_obj.init_cash = cash
            cfg_obj.trade_model = model
            cfg_obj.status = consts.STRATEGY_SEMI_LIVE
            cfg_obj.update_time = datetime.datetime.now()
            cfg_obj.accounts = kwargs.get('accounts', {})
            if reset:
                cfg_obj.progress = 0
            sc.commit()

        q_cfg_obj = sc.query(BackTestConfig).filter(BackTestConfig.link_cfg_id == cfg_obj.id).first()
        if q_cfg_obj:
            start_date = datetime.datetime.strptime(start, "%Y-%m-%d")
            q_cfg_obj.start_date = start_date.strftime('%Y%m%d')
            q_cfg_obj.init_cash = cash
            q_cfg_obj.trade_model = model
            q_cfg_obj.status = consts.STRATEGY_SEMI_QUANTAMEMTAL
            q_cfg_obj.update_time = datetime.datetime.now()
            q_cfg_obj.accounts = kwargs.get('accounts', {})
            if reset:
                q_cfg_obj.progress = 0
            sc.commit()
        sc.close()

    @staticmethod
    def update_config_by_cfg_id(cfg_id, start, cash, model, reset=False, **kwargs):
        sc = session()
        cfg_obj = sc.query(BackTestConfig).filter(BackTestConfig.id == cfg_id).first()
        if cfg_obj:
            start_date = datetime.datetime.strptime(start, "%Y-%m-%d")
            cfg_obj.start_date = start_date.strftime('%Y%m%d')
            cfg_obj.init_cash = cash
            cfg_obj.trade_model = model
            cfg_obj.status = consts.STRATEGY_SEMI_QUANTAMEMTAL
            cfg_obj.update_time = datetime.datetime.now()
            cfg_obj.accounts = kwargs.get('accounts', {})
            if reset:
                cfg_obj.progress = 0
            sc.commit()
        sc.close()

    @staticmethod
    def update_task_id(us_id, st_id, task_id, other_dict):
        sc = session()
        sc.query(BackTestConfig).filter(BackTestConfig.user_id == us_id,
                                        BackTestConfig.strategy_id == st_id, BackTestConfig.group_id ==
                                        consts.STRAT_SINGLE).update({
            BackTestConfig.task_id: task_id,
            BackTestConfig.child_list: json.dumps(other_dict)})
        sc.commit()
        sc.close()

    @staticmethod
    def update_task_by_cfg_id(cfg_id, other_dict):
        sc = session()
        sc.query(BackTestConfig).filter(BackTestConfig.id == cfg_id).update({
            BackTestConfig.child_list: json.dumps(other_dict)})
        sc.commit()
        sc.close()

    @staticmethod
    def update_progress(task_id, progress):
        sc = session()
        cfg_obj = sc.query(BackTestConfig).filter(BackTestConfig.task_id == task_id).first()
        if cfg_obj:
            cfg_obj.progress = progress
            if progress >= 1:
                cfg_obj.child_list = json.dumps({"status": consts.TASK_FINISHED})
            sc.commit()
        sc.close()

    @staticmethod
    def get_item(cfg_id):
        sc = session()
        obj = sc.query(BackTestConfig).get(cfg_id)
        other = json.loads(obj.child_list) if obj.child_list else {}
        result = {
            'user_id': obj.user_id,
            'strategy_id': obj.strategy_id,
            'start_date': obj.start_date,
            'init_cash': obj.init_cash,
            'trade_model': obj.trade_model,
            'status': obj.status,
            'group_id': obj.group_id,
            'progress': obj.progress,
            'update_time': obj.update_time,
            'other': other,
            'task_id': obj.task_id,
            'accounts': obj.accounts or {},
        }
        sc.close()
        return result

    @staticmethod
    def revoke_config(us_id, st_id, group_id=0):
        sc = session()
        cfg_obj = sc.query(BackTestConfig).filter(BackTestConfig.user_id == us_id,
                                                  BackTestConfig.strategy_id == st_id)
        if group_id > 0:
            cfg_obj = cfg_obj.filter(BackTestConfig.group_id == consts.INVEST_GROUP).first()
        else:
            cfg_obj = cfg_obj.filter(BackTestConfig.group_id < consts.INVEST_GROUP).first()
        if cfg_obj:
            cfg_obj.status = 0
            sc.query(BackTestConfig).filter(BackTestConfig.link_cfg_id == cfg_obj.id).update({BackTestConfig.status: 0})
            sc.commit()
        sc.close()

    @staticmethod
    def get_link_config_id(us_id, st_id):
        sc = session()
        cfg_id, start_date, init_cash, model, group_id, accounts = 0, '', 0, '', 0, {}
        cfg_obj = sc.query(BackTestConfig).filter(
            BackTestConfig.user_id == us_id,
            BackTestConfig.strategy_id == st_id,
            BackTestConfig.group_id < consts.INVEST_GROUP
        ).first()
        if cfg_obj:
            q_cfg_obj = sc.query(BackTestConfig).filter(BackTestConfig.link_cfg_id == cfg_obj.id).first()
            if q_cfg_obj:
                cfg_id = q_cfg_obj.id
        sc.close()
        return cfg_id

    @staticmethod
    def get_config_id(us_id, st_id):
        sc = session()
        cfg_id, start_date, init_cash, model, group_id, accounts = 0, '', 0, '', 0, {}
        cfg_obj = sc.query(BackTestConfig).filter(
            BackTestConfig.user_id == us_id,
            BackTestConfig.strategy_id == st_id,
            BackTestConfig.group_id < consts.INVEST_GROUP
        ).first()
        if cfg_obj:
            cfg_id = cfg_obj.id
            start_date = cfg_obj.start_date
            init_cash = cfg_obj.init_cash
            model = cfg_obj.trade_model
            group_id = cfg_obj.group_id
            accounts = cfg_obj.accounts or {}
        sc.close()
        return {
            'cfg_id': cfg_id,
            'start_date': start_date,
            'init_cash': float(init_cash),
            'model': model,
            'group_id': group_id,
            'accounts': accounts,
        }

    @staticmethod
    def get_config_by_cfg_id(cfg_id, q_id):
        sc = session()
        cfg_obj = sc.query(BackTestConfig).filter(
            BackTestConfig.id == cfg_id,
        ).first()
        if cfg_obj:
            res = {
                'cfg_id': cfg_obj.id,
                'start_date': cfg_obj.start_date,
                'init_cash': float(cfg_obj.init_cash),
                'model': cfg_obj.trade_model,
                'group_id': cfg_obj.group_id,
                'accounts': cfg_obj.accounts or {},
                'q_id': q_id,
                'task_id': cfg_obj.task_id,
            }
        else:
            res = {}
        sc.close()
        return res

    @staticmethod
    def is_wait_live(us_id, st_id, group_id=0):
        result = False
        stmt = "select status from back_test_config where user_id=%d and strategy_id=%d " % (us_id, st_id)
        if group_id == consts.INVEST_GROUP:
            stmt += (" and group_id=%d" % consts.INVEST_GROUP)
        else:
            stmt += (" and group_id<%d" % consts.INVEST_GROUP)
        sc = session()
        row = sc.execute(stmt).first()
        if row and int(row[0]) == consts.STRATEGY_SEMI_LIVE:
            result = True
        sc.close()
        return result

    @staticmethod
    def stop_back_test(us_id, st_id):
        sc = session()
        cfg_obj = sc.query(BackTestConfig).filter(BackTestConfig.user_id == us_id,
                                                  BackTestConfig.strategy_id == st_id,
                                                  BackTestConfig.group_id == consts.STRAT_SINGLE).first()
        if cfg_obj:
            task_id = cfg_obj.task_id
            BackTestConfig.update_task_id(us_id, st_id, task_id, {"status": consts.TASK_STOPPED})
            st_obj = sc.query(Strategy).filter(Strategy.id == st_id).first()
            st_obj.stop_task(task_id=task_id)
        sc.close()

    @staticmethod
    def stop_cfg_back_test(st_id, cfg_id):
        sc = session()
        cfg_obj = sc.query(BackTestConfig).filter(BackTestConfig.id == cfg_id).first()
        if cfg_obj:
            task_id = cfg_obj.task_id
            BackTestConfig.update_task_by_cfg_id(cfg_id, {"status": consts.TASK_STOPPED})
            st_obj = sc.query(Strategy).filter(Strategy.id == st_id).first()
            st_obj.stop_task(task_id=task_id)
        sc.close()

    @staticmethod
    def get_strategies(user_id=None, group_id=0):
        result = []
        stmt = "select id, user_id, strategy_id, group_id, task_id from back_test_config where status=%d and group_id=%d " \
               % (consts.STRATEGY_SEMI_LIVE, group_id)
        if user_id:
            stmt += (" and user_id=%d" % user_id)
        sc = session()
        rows = sc.execute(stmt)
        for row in rows:
            result.append({"config_id": int(row[0]), "user_id": int(row[1]),
                           "strategy_id": int(row[2]), "group_id": int(row[3]), "task_id": row[4]})
        sc.close()
        return result

    @staticmethod
    def query_config(strategies, st_id):
        for item in strategies:
            if item['strategy_id'] == st_id:
                if item['group_id'] == consts.STRAT_SINGLE:
                    return item['config_id'], 0
                elif item['group_id'] == consts.STRAT_GROUP:
                    return 0, item['config_id']
        return 0, -1


class StrategyResult(ModelBase):
    """
    回测结果表或者ev生产结果表
    """
    __tablename__ = 'strategy_result'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(INTEGER, index=True)  # 策略id
    date = Column(VARCHAR(16), nullable=False)  # 交易日期
    taskdate = Column(VARCHAR(16), nullable=False)  # 多参数任务时会用到
    product = Column(VARCHAR(255), nullable=False)
    paras = Column(JSON, nullable=True)
    pnl = Column(DOUBLE, default=0)  # 策略回测某一天的pnl
    detail = Column(JSON, nullable=True)
    status = Column(INTEGER, nullable=False, default=1)  # 0=完成 1=运行中 -1=失败
    result_file_name = Column(VARCHAR(512), nullable=True)  # ev生产的结果文件 日夜盘使用|拼接
    done_time = Column(DATETIME, nullable=True)
    redo_times = Column(INTEGER, default=0)
    log_files = Column(JSON, nullable=True)
    available_cash = Column('cash_available', DOUBLE, default=0)
    asset_cash = Column('cash_asset', DOUBLE, default=0)
    position_cash = Column(DOUBLE, default=0)
    total_asset = Column(DOUBLE, nullable=False, default=0)
    dividend = Column(DOUBLE, nullable=False, default=0)
    config_id = Column(INTEGER, nullable=False, default=0)

    @staticmethod
    def handle_vstrategy_back_test_result(data):
        from cron.strategy_upload_task import vs_back_test_done, vs_back_test_trading_date_done
        vs_id = int(data['task_id'])
        sc = session()
        vs = sc.query(VStrategies).filter(VStrategies.id == vs_id).first()
        if not vs:
            sc.close()
            return False

        if data['status'] == consts.AGENT_TASK_FAILED and ('date' not in data):
            vs_back_test_done.delay(vs.id, status=consts.AGENT_TASK_FAILED)
            sc.close()
            return False

        if data['status'] == consts.AGENT_TASK_FINISHED and ('date' not in data):
            vs_back_test_done.delay(vs.id, status=consts.AGENT_TASK_FINISHED)
            sc.close()
            return True

        if 'date' not in data:
            sc.close()
            return False

        date = str(data['date'])
        day_night = int(data['day_night'])
        r = sc.query(
            VstrategyBackTestResult
        ).filter(
            VstrategyBackTestResult.vstrategy_id == vs_id,
            VstrategyBackTestResult.trading_date == date,
            VstrategyBackTestResult.day_night == day_night,
        ).first()
        if not r:
            r = VstrategyBackTestResult(
                vstrategy_id=vs_id,
                trading_date=date,
                day_night=day_night,
                status=consts.TASK_RUNNING,
            )
            sc.add(r)
            sc.commit()

        if data['status'] != 0:
            r.status = consts.TASK_FAILED
        else:
            r.status = consts.TASK_FINISHED
        r.log_files = data.get('log_name', [])
        r.done_time = datetime.datetime.now()
        r.pnl = sum([(l['net_pnl'] or 0) for l in data['pnl_nodes']])
        r.available_cash = data.get('cash', 0)
        r.asset_cash = data.get('asset_cash', 0)
        r.total_asset = data.get('total_asset', 0)
        r.dividend = data.get('dividend', 0)

        products_unit = get_all_products_unit()
        position_cash = 0
        if data.get('accounts', {}):
            position_cash = sum(acc_d.get('position_cash', 0) for _, acc_d in data['accounts'].items())
        else:
            for l in data['pnl_nodes']:
                position_cash += ((l['long_volume'] or 0) * (l['long_price'] or 0) + (l['short_volume'] or 0) * (
                        l['short_price'] or 0)) * products_unit.get(l['product'], 1)
        r.position_cash = position_cash
        sc.commit()
        old_details = sc.query(VstrategyBackTestResultDetail).filter(
            VstrategyBackTestResultDetail.vstrategy_id == vs_id,
            VstrategyBackTestResultDetail.trading_date == date,
            VstrategyBackTestResultDetail.day_night == day_night,
        )
        old_details.delete(synchronize_session=False)

        old_vstrategy_accounts = sc.query(
            VstrategyBackTestResultAccount
        ).filter(
            VstrategyBackTestResultAccount.vstrategy_id == vs_id,
            VstrategyBackTestResultAccount.trading_date == date,
            VstrategyBackTestResultAccount.day_night == day_night,
        )
        old_vstrategy_accounts.delete(synchronize_session=False)
        sc.commit()

        for l in data['pnl_nodes']:
            exch = ''
            if 0 <= l['exchange'] <= 255:
                exch = chr(l['exchange'])
            if ((l['long_volume'] or 0) == 0) and ((l['short_volume'] or 0) == 0) and ((l['net_pnl'] or 0) == 0):
                continue
            currency, forex_rate = 'CNY', 1.0
            if data.get('accounts', {}):
                l_acc = data['accounts'].get(l.get('account', ''), {})
                currency = l_acc.get('currency', 'CNY')
                forex_rate = l_acc.get('forex_rate', 1.0)
                l['currency'] = currency
                l['forex_rate'] = forex_rate
            d = VstrategyBackTestResultDetail(
                vstrategy_id=vs_id,
                trading_date=date,
                day_night=day_night,
                done_time=datetime.datetime.now(),
                symbol=l['symbol'],
                product=l['product'],
                exchange=exch,
                fee=(l['fee'] or 0),
                gross_pnl=(l['gross_pnl'] or 0),
                pnl=(l['net_pnl'] or 0),
                long_volume=(l['long_volume'] or 0),
                long_price=(l['long_price'] or 0),
                short_volume=(l['short_volume'] or 0),
                short_price=(l['short_price'] or 0),
                dividend=(l.get('dividend', 0) or 0),
                account=l.get('account', ''),
                currency=currency,
                forex_rate=forex_rate,
            )
            sc.add(d)

        for a, a_detail in data.get('accounts', {}).items():
            acc = VstrategyBackTestResultAccount(
                vstrategy_id=vs_id,
                trading_date=date,
                day_night=day_night,
                done_time=datetime.datetime.now(),
                account=a,
                asset_cash=a_detail.get('asset_cash', 0),
                available_cash=a_detail.get('cash', 0),
                currency=a_detail.get('currency', 'CNY'),
                forex_rate=a_detail.get('forex_rate', 1.0),
            )
            sc.add(acc)
        if day_night == 0:
            sc.query(VsBackTestPositionCorpActions).filter(
                VsBackTestPositionCorpActions.vstrategy_id == vs_id,
                VsBackTestPositionCorpActions.eqy_record_date == date
            ).delete(synchronize_session=False)
            sc.commit()
            for sym, sym_corp_d in data.get('unrealized_corp_data', {}).items():
                for sym_corp in sym_corp_d:
                    if sym_corp['eqy_record_date'].replace('-', '') != date:
                        continue
                    corp_item = VsBackTestPositionCorpActions()
                    corp_item.vstrategy_id = vs_id
                    corp_item.account = sym_corp['account']
                    corp_item.today_long_pos = sym_corp['today_long_pos']
                    corp_item.today_short_pos = sym_corp['today_short_pos']
                    corp_item.symbol = sym
                    corp_item.eqy_record_date = sym_corp['eqy_record_date']
                    corp_item.ex_date = sym_corp['ex_date']
                    corp_item.dividend_cash_payout_date = sym_corp['dividend_cash_payout_date']
                    corp_item.dividend_share_listing_date = sym_corp['dividend_share_listing_date']
                    corp_item.cash_dividend_per_share = sym_corp['cash_dividend_per_share']
                    corp_item.share_bonus_rate = sym_corp['share_bonus_rate']
                    corp_item.share_conversederate_rate = sym_corp['share_conversederate_rate']
                    corp_item.payout_cash = sym_corp['payout_cash']
                    corp_item.payout_pos = sym_corp['payout_pos']
                    corp_item.payout_short_pos = sym_corp['payout_short_pos']
                    sc.add(corp_item)
        sc.commit()
        vs_back_test_trading_date_done.delay(vs_id, date, day_night)
        sc.close()
        return True

    @staticmethod
    def handle_result_v4(data):
        from cron.strategy_upload_task import update_strategy_status, back_test_done, \
            strategy_back_test_trading_date_done
        from service.stock_factor.models import StockFactorStrategyColumns
        if data['task_id'].startswith('v_strategy_id'):
            data['task_id'] = int(data['task_id'].split(':')[1])
            return StrategyResult.handle_vstrategy_back_test_result(data)

        task_info = get_cache("task_id:" + data['task_id'])
        config_id = task_info["config_id"]
        sc = session()

        s = sc.query(Strategy).filter(Strategy.id == task_info["strategy_id"]).first()
        if not s:
            sc.close()
            return False

        # 联合模拟,回测系统会分别返回联合模拟策略及其子策略的回报
        # 联合模拟策略回报中，strat_id=0；子策略回报中strat_id是子策略自己的策略id
        if s.strategy_type == '34' and data['strat_id'] != 0:
            s = sc.query(Strategy).filter(Strategy.id == data['strat_id']).first()
            if not s:
                sc.close()
                return False

        if data['status'] == consts.AGENT_TASK_FAILED and ('date' not in data):
            s.status = consts.TASK_FAILED
            sc.commit()
            back_test_done.delay(s.id, config_id=config_id)
            sc.close()
            return False

        if data['status'] == consts.AGENT_TASK_FINISHED and ('date' not in data):
            s.status = consts.TASK_FINISHED
            sc.commit()
            back_test_done.delay(s.id, config_id=config_id)
            sc.close()
            return True

        if data.get('factor_columns', []):
            StockFactorStrategyColumns.set_factor_columns(s.id, data['factor_columns'])

        if 'date' not in data:
            sc.close()
            return False

        date = str(data['date'])
        strategy_products = [p['symbol'] for p in s.products[0]]
        product_key = '|'.join(sorted(strategy_products))[:250]
        day_night = int(data['day_night'])
        if s.day_night == 2 and day_night == 0:
            time.sleep(3)

        r = sc.query(StrategyResult).filter(
            StrategyResult.strategy_id == s.id,
            StrategyResult.config_id == config_id,
            StrategyResult.product == product_key,
            StrategyResult.date == date,
        ).first()

        if not r:
            r = StrategyResult(
                strategy_id=s.id,
                config_id=config_id,
                date=date,
                taskdate=date,
                product=product_key,
                status=consts.TASK_RUNNING
            )
            sc.add(r)
            sc.commit()

        if data['status'] != 0:
            r.status = consts.TASK_FAILED
            detail = []
            pnl_nodes = []
        else:
            r.status = consts.TASK_FINISHED
            detail = r.detail and copy.deepcopy(r.detail) or []
            detail = [l for l in detail if l['day_night'] != day_night]
            pnl_nodes = data['pnl_nodes']
            if not isinstance(pnl_nodes, list):
                return False
            for node in pnl_nodes:
                node['day_night'] = day_night
                node['date'] = date
            detail.extend(pnl_nodes)
            if data.get('progress', 0) >= 100:
                s.status = consts.TASK_FINISHED
        r.detail = detail
        if not detail:
            r.position_cash = 0
        elif data.get('accounts', {}):
            r.position_cash = sum(acc_d.get('position_cash', 0) for _, acc_d in data['accounts'].items())
        else:
            products_unit = get_all_products_unit()
            day_position_cash, night_position_cash = None, 0
            for l in detail:
                l_position_cash = (
                                          (l['long_volume'] or 0) * (l['long_price'] or 0) +
                                          (l['short_volume'] or 0) * (l['short_price'] or 0)
                                  ) * products_unit.get(l['product'], 1)
                if l['day_night'] == 0:
                    day_position_cash = (day_position_cash or 0) + l_position_cash
                else:
                    night_position_cash += l_position_cash
            if day_position_cash is not None:
                position_cash = day_position_cash
            else:
                position_cash = night_position_cash
            r.position_cash = position_cash
        r.log_files = (r.log_files or []) + data.get('log_name', [])
        r.pnl = sum([(l['net_pnl'] or 0) for l in detail])
        r.done_time = datetime.datetime.now()
        r.available_cash = data.get('cash', 0)
        r.asset_cash = data.get('asset_cash', 0)
        if int(config_id) > 0:
            BackTestConfig.update_progress(data['task_id'], data.get('progress', 0) / 100)
        else:
            s.task_progress = max(s.task_progress or 0, data.get('progress', 0) / 100)
        r.total_asset = data.get('total_asset', 0)
        r.dividend = data.get('dividend', 0)
        strategy_id = s.id
        sc.commit()

        old_details = sc.query(StrategyResultDetail).filter(
            StrategyResultDetail.strategy_id == s.id,
            StrategyResultDetail.config_id == config_id,
            StrategyResultDetail.trading_date == date,
            StrategyResultDetail.day_night == day_night,
        )
        old_details.delete(synchronize_session=False)
        old_strategy_accounts = sc.query(
            StrategyResultAccount
        ).filter(
            StrategyResultAccount.strategy_id == s.id,
            StrategyResultAccount.config_id == config_id,
            StrategyResultAccount.trading_date == date,
            StrategyResultAccount.day_night == day_night,
        )
        old_strategy_accounts.delete(synchronize_session=False)
        sc.commit()
        for l in pnl_nodes:
            exch = ''
            if 0 <= l['exchange'] <= 255:
                exch = chr(l['exchange'])
            currency, forex_rate = 'CNY', 1.0
            if data.get('accounts', {}):
                l_acc = data['accounts'].get(l.get('account', ''), {})
                currency = l_acc.get('currency', 'CNY')
                forex_rate = l_acc.get('forex_rate', 1.0)
                l['currency'] = currency
                l['forex_rate'] = forex_rate
            d = StrategyResultDetail(
                strategy_id=s.id,
                config_id=config_id,
                trading_date=date,
                day_night=day_night,
                done_time=datetime.datetime.now(),
                symbol=l['symbol'],
                product=l['product'],
                exchange=exch,
                fee=(l['fee'] or 0),
                gross_pnl=(l['gross_pnl'] or 0),
                pnl=(l['net_pnl'] or 0),
                long_volume=(l['long_volume'] or 0),
                long_price=(l['long_price'] or 0),
                short_volume=(l['short_volume'] or 0),
                short_price=(l['short_price'] or 0),
                dividend=(l.get('dividend', 0) or 0),
                account=l.get('account', ''),
                currency=currency,
                forex_rate=forex_rate,
            )
            sc.add(d)

        for a, a_detail in data.get('accounts', {}).items():
            acc = StrategyResultAccount(
                strategy_id=s.id,
                config_id=config_id,
                trading_date=date,
                day_night=day_night,
                done_time=datetime.datetime.now(),
                account=a,
                asset_cash=a_detail.get('asset_cash', 0),
                available_cash=a_detail.get('cash', 0),
                currency=a_detail.get('currency', 'CNY'),
                forex_rate=a_detail.get('forex_rate', 1.0),
            )
            sc.add(acc)
        if day_night == 0:
            sc.query(BackTestPositionCorpActions).filter(
                BackTestPositionCorpActions.strategy_id == s.id,
                BackTestPositionCorpActions.config_id == config_id,
                BackTestPositionCorpActions.eqy_record_date == date
            ).delete(synchronize_session=False)
            sc.commit()
            for sym, sym_corp_d in data.get('unrealized_corp_data', {}).items():
                for sym_corp in sym_corp_d:
                    if sym_corp['eqy_record_date'].replace('-', '') != date:
                        continue
                    corp_item = BackTestPositionCorpActions()
                    corp_item.strategy_id = s.id
                    corp_item.config_id = config_id
                    corp_item.account = sym_corp['account']
                    corp_item.today_long_pos = sym_corp['today_long_pos']
                    corp_item.today_short_pos = sym_corp['today_short_pos']
                    corp_item.symbol = sym
                    corp_item.eqy_record_date = sym_corp['eqy_record_date']
                    corp_item.ex_date = sym_corp['ex_date']
                    corp_item.dividend_cash_payout_date = sym_corp['dividend_cash_payout_date']
                    corp_item.dividend_share_listing_date = sym_corp['dividend_share_listing_date']
                    corp_item.cash_dividend_per_share = sym_corp['cash_dividend_per_share']
                    corp_item.share_bonus_rate = sym_corp['share_bonus_rate']
                    corp_item.share_conversederate_rate = sym_corp['share_conversederate_rate']
                    corp_item.payout_cash = sym_corp['payout_cash']
                    corp_item.payout_pos = sym_corp['payout_pos']
                    corp_item.payout_short_pos = sym_corp['payout_short_pos']
                    sc.add(corp_item)
        sc.commit()
        sc.close()
        update_strategy_status.delay(strategy_id)
        strategy_back_test_trading_date_done.delay(strategy_id, date, day_night, config_id)
        return True


class StrategyBackTestResultPerformance(ModelBase):
    __tablename__ = 'strategy_backtest_performance'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(INTEGER, nullable=False, index=True)
    config_id = Column(INTEGER, nullable=False, index=True)
    key = Column(VARCHAR(255), nullable=False, index=True)
    start_date = Column(DATE, nullable=True)
    end_date = Column(DATE, nullable=True)

    sharpe = Column(DOUBLE, nullable=False)
    annual_return = Column(DOUBLE, nullable=False)
    profitrate = Column(DOUBLE, nullable=False)
    max_drawdown_pnl = Column(DOUBLE, nullable=False)
    # 回撤收益比
    drawdown_earn_ratio = Column(DOUBLE, nullable=False)

    pt_days = Column(INTEGER, nullable=False, default=0)
    valid = Column(BOOLEAN, nullable=False, default=True)
    # 平均每日交易回合
    avg_daily_rounds = Column(DOUBLE, nullable=False, default=0)

    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())

    def to_dict(self):
        return {
            'key': self.key,
            'start_date': self.start_date and self.start_date.strftime('%Y%m%d') or '',
            'end_date': self.end_date and self.end_date.strftime('%Y%m%d') or '',
            'sharpe': 'N/A' if abs(float(self.sharpe)) >= 99999 else float(self.sharpe),
            'annual_return': 'N/A' if abs(float(self.annual_return)) >= 99999 else float(self.annual_return),
            'profitrate': 'N/A' if abs(float(self.profitrate)) >= 99999 else float(self.profitrate),
            'max_drawdown_pnl': 'N/A' if abs(float(self.max_drawdown_pnl)) >= 99999 else float(self.max_drawdown_pnl),
            'drawdown_earn_ratio': 'N/A' if abs(float(self.drawdown_earn_ratio)) >= 99999 else float(
                self.drawdown_earn_ratio),
            'avg_daily_rounds': 'N/A' if abs(float(self.avg_daily_rounds)) >= 99999 else float(self.avg_daily_rounds),
            'pt_days': self.pt_days,
        }


class StrategyPortfolio(ModelBase):
    """
    策略组合表，策略提交实盘时，是以策略组合为单位提交的
    """
    __tablename__ = 'strategy_portfolio'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(128), nullable=False)
    fund = Column(DOUBLE, nullable=False)
    description = Column(VARCHAR(255), nullable=True)
    status = Column(INTEGER, nullable=False, default=11)  # consts.STRATEGY_LIVE
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=False)
    r_update_user_id = Column(INTEGER, nullable=True)
    live_time = Column(DATETIME, nullable=True)  # 实盘时间
    username = Column(VARCHAR(32), nullable=False)  # 提交实盘的用户
    source = Column(VARCHAR(32), nullable=True)  # 字段有默认值，早期有非平台的策略也使用平台进行实盘交易
    business = Column(VARCHAR(32), nullable=True)  # stock | future | NULL（比如外部合作）
    research_portfolio_id = Column(INTEGER, nullable=True)
    vstrategy_obj = relationship('VStrategies', backref='strategy_portfolio', passive_deletes=True)

    def analysis_detail(self):
        return {
            'description': self.description,
            'name': self.name,
            'fund': float(self.fund),
            'id': self.id,
            'status': self.get_portfolio_status(),
            'creator': self.username,
            'created_time': str(self.r_create_time),
            'created_date': self.r_create_time.strftime('%Y-%m-%d'),
            'detail': [vst.analysis_detail() for vst in self.vstrategy_obj],
        }

    def get_portfolio_status(self):
        curr_status = self.status
        if curr_status == consts.STRATEGY_LIVE:
            sc = session()
            vs_objs = sc.query(VStrategies).filter(VStrategies.portfolio_id == self.id).all()
            for obj in vs_objs:
                if obj.closing_out == consts.STRATEGY_CLOSING_OUT:
                    curr_status = consts.STRATEGY_CLOSING_OUT
                    break
            sc.close()
        return consts.VSTRATEGY_STATUE.get(curr_status, self.status)


class DefaulStrategySet(ModelBase):
    __tablename__ = 'default_strategy_set'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_user_id = Column(INTEGER, nullable=False)
    strategy_set_id = Column(INTEGER, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())


class NewStrategySet(ModelBase):
    __tablename__ = 'new_strategy_set'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(255), nullable=False)
    r_create_user_id = Column(INTEGER, nullable=False)
    username = Column(VARCHAR(32), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    is_default = Column(INTEGER, nullable=False, default=0)
    page = Column(VARCHAR(32), nullable=False)


class NewStrategySetdetail(ModelBase):
    __tablename__ = 'new_strategy_set_detail'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_set_id = Column(INTEGER, nullable=False)
    vs_id = Column(INTEGER, nullable=False)


class NewStrategySetShare(ModelBase):
    __tablename__ = 'new_strategy_set_share'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(255), nullable=True)
    strategy_set_id = Column(INTEGER, nullable=False)
    owner_id = Column(INTEGER, nullable=False)
    r_create_user_id = Column(INTEGER, nullable=False)
    username = Column(VARCHAR(32), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    is_default = Column(INTEGER, nullable=False, default=0)


class VStrategies(ModelBase):
    """
    虚拟策略表，提交实盘时会生成对应的记录
    """
    __tablename__ = 'vstrategies'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    status = Column(INTEGER, default=11)  # portfolio.status
    portfolio_id = Column(ForeignKey('strategy_portfolio.id', ondelete='CASCADE'))  # strategy_portfolio.id
    strategy_id = Column(INTEGER, nullable=False)  # strategy.id
    strategy_weight = Column(DOUBLE, nullable=True, default=0)  # 组合内的策略权重
    symbols_accounts_detail = Column('symbols_accounts', JSON, nullable=True)  # 合约，账户资金等配置
    source = Column(VARCHAR(32), nullable=True)
    name = Column(VARCHAR(128), nullable=True)
    group_id = Column(INTEGER, nullable=False, default=0)  # 如果是组合策略，对应其策略id
    closing_out = Column(INTEGER, nullable=False, default=0)  # 策略下线时设置状态
    set_close_time = Column(DATETIME, nullable=True)  # 设置下线的时间
    deploy_server = Column(VARCHAR(18), nullable=False)  # 盘后分析的配置, 行情源 对应表live_quote_server
    trade_model = Column(VARCHAR(32), nullable=False)  # 盘后分析的配置，成交模型

    @staticmethod
    def get_exchange_to_account_info(vs_id):
        info = dict()
        with session_context() as sc:
            vs = sc.query(VStrategies).filter(
                VStrategies.id == vs_id
            ).first()
            if vs:
                info.update({r['exchange']: r['account'] for r in vs.symbols_accounts})
                if 'SSE' not in info and 'SZSE' in info:
                    info['SSE'] = info['SZSE']
                if 'SZSE' not in info and 'SSE' in info:
                    info['SZSE'] = info['SSE']
        return info

    @property
    def symbols_accounts(self):
        if not self.symbols_accounts_detail:
            return []
        if isinstance(self.symbols_accounts_detail, list):
            return self.symbols_accounts_detail
        elif isinstance(self.symbols_accounts_detail, dict):
            day = self.symbols_accounts_detail.get('day', [])
            night = self.symbols_accounts_detail.get('night', [])
            return day or night
        else:
            raise ValueError('symbols_accounts error: %s' % self.symbols_accounts_detail)

    @staticmethod
    def normalization_symbols_accounts(symbols_accounts_detail):
        if not symbols_accounts_detail:
            return []
        if isinstance(symbols_accounts_detail, list):
            return symbols_accounts_detail
        elif isinstance(symbols_accounts_detail, dict):
            day = symbols_accounts_detail.get('day', [])
            night = symbols_accounts_detail.get('night', [])
            return day or night
        else:
            raise ValueError('symbols_accounts error: %s' % symbols_accounts_detail)

    def analysis_detail(self):
        sc = session()
        strategy_obj = sc.query(Strategy).filter(Strategy.id == self.strategy_id).first()
        detail = strategy_obj.report()
        detail['weight'] = float(self.strategy_weight)
        detail['symbols_accounts'] = self.symbols_accounts if self.symbols_accounts else []
        detail['vstrategy_id'] = self.id
        sc.close()
        return detail

    @staticmethod
    def get_status(self_status, close_status, vs_id=None):
        curr_status = self_status
        if self_status == consts.STRATEGY_LIVE and close_status == consts.STRATEGY_CLOSING_OUT:
            curr_status = consts.STRATEGY_CLOSING_OUT

        _ret_str = consts.VSTRATEGY_STATUE.get(curr_status)
        if (vs_id is not None) and (
                curr_status == consts.STRATEGY_OFF_SHELF or curr_status == consts.STRATEGY_CLOSING_OUT):
            sc = session()
            closing_detail = sc.query(ClosePositionDetail).filter(ClosePositionDetail.vsid == vs_id).order_by(
                ClosePositionDetail.utime).first()
            if closing_detail is not None:
                _ret_str += ('(' + closing_detail.close_way + ')')
            sc.close()

        return _ret_str

    @staticmethod
    def vstrategies_invest_funds_detail(vs_ids):
        if not vs_ids:
            return {}
        if not isinstance(vs_ids, list):
            return {}
        sc = session()
        detail = {}
        try:
            v_account_details = sc.query(
                VStrategyAccountDetail.vstrategy_id.label('vstrategy_id'),
                VStrategyAccountDetail.account.label('account'),
                VStrategyAccountDetail.amount.label('amount'),
                VStrategyAccountDetail.trading_date.label('trading_date'),
                StrategyPortfolio.live_time.label('live_time'),
            ).join(
                StrategyPortfolio, StrategyPortfolio.id == VStrategyAccountDetail.portfolio_id
            ).filter(VStrategyAccountDetail.vstrategy_id.in_(vs_ids))

            for v_a_detail in v_account_details:
                date = v_a_detail.trading_date or v_a_detail.live_time
                date = (date - timedelta(days=1)).strftime('%Y-%m-%d')
                if v_a_detail.vstrategy_id not in detail:
                    detail[v_a_detail.vstrategy_id] = {}
                if v_a_detail.account not in detail[v_a_detail.vstrategy_id]:
                    detail[v_a_detail.vstrategy_id][v_a_detail.account] = {}
                detail[v_a_detail.vstrategy_id][v_a_detail.account][date] = detail[v_a_detail.vstrategy_id][
                                                                                v_a_detail.account].get(date,
                                                                                                        0) + float(
                    v_a_detail.amount)
        except Exception as e:
            sentry.captureException()
        sc.close()
        return detail

    @staticmethod
    def vstratgies_account_invest_funds(detail, vs_ids, accounts):
        try:
            res = {}
            for v_id in vs_ids:
                account_details = detail.get(v_id, {})
                for account, invest_funds in account_details.items():
                    if (account in accounts) or (accounts == 'all'):
                        for d, amount in invest_funds.items():
                            res[d] = res.get(d, 0) + amount
            return res
        except Exception as e:
            sentry.captureException()
            return {}

    def get_last_back_test_account_position_v3(self, trading_date, use_default=False, **kwargs):
        res = {
            'accounts': {},
            'positions': {},
            'cash_io': {},
            'is_first_day': False,
            'unrealized_corp_data': {},
            'use_last_live_position': kwargs.get('use_last_live_position', False),
        }
        se_cash_rate = kwargs.get('se_cash_rate', 0)
        sc = session()
        trading_date = parse(trading_date).strftime('%Y%m%d')
        portfolio = sc.query(StrategyPortfolio).filter(StrategyPortfolio.id == self.portfolio_id).first()
        live_time = (portfolio.live_time or portfolio.r_create_time).strftime('%Y%m%d')

        kdb = KdbQuery()
        neighbour_trading_dates = kdb.get_nebor_trading_date(trading_date)
        prev_trading_date = neighbour_trading_dates['prev']
        # next_trading_date = neighbour_trading_dates['next']
        last_trading_date = parse(prev_trading_date).strftime('%Y%m%d')

        if live_time <= '20180306':
            use_default = True

        def convert_account(acc):
            if use_default:
                return 'init_account'
            else:
                return acc

        if (trading_date <= live_time) or kwargs.get('use_last_live_position'):
            res['is_first_day'] = True
            res['use_last_live_position'] = True
            vs_last_position = None
            if kwargs.get('strategy_type') in consts.stock_strategy_type:
                vs_last_position = sc.query(VsPosition).filter(
                    VsPosition.vstrategy_id == self.id,
                    VsPosition.settle_date == last_trading_date,
                    VsPosition.daynight == 'DAY',
                    or_(
                        VsPosition.today_long_pos != 0,
                        VsPosition.today_short_pos != 0,
                    )
                ).first()

            if vs_last_position:
                vs_accounts = sc.query(VsAccount).filter(
                    VsAccount.vstrategy_id == self.id,
                    VsAccount.settle_date == last_trading_date,
                    VsAccount.daynight == 'DAY',
                )
                for acc in vs_accounts:
                    _acc = convert_account(acc.account)
                    if _acc not in res['accounts']:
                        res['accounts'][_acc] = {
                            'cash': 0,
                            'asset_cash': 0,
                            'currency': 'CNY',
                        }
                    res['accounts'][_acc]['forex_rate'] = 1
                    res['accounts'][_acc]['cash'] += float(acc.available_cash)
                    res['accounts'][_acc]['asset_cash'] += float(acc.asset_cash)

                positions = sc.query(VsPosition).filter(
                    VsPosition.vstrategy_id == self.id,
                    VsPosition.settle_date == last_trading_date,
                    VsPosition.daynight == 'DAY',
                    or_(
                        VsPosition.today_long_pos != 0,
                        VsPosition.today_short_pos != 0,
                    )
                )

                if kwargs.get('strategy_type') not in consts.t0_stock_strategy_type:
                    for pos in positions:
                        res['positions'][pos.symbol] = {
                            'symbol': pos.symbol,
                            'exchange': pos.exchange,
                            'account': convert_account(pos.account or 'init_account'),
                            'yest_long_pos': int(pos.today_long_pos),
                            'yest_long_avg_price': float(pos.today_long_avg_price),
                            'yest_short_pos': int(pos.today_short_pos),
                            'yest_short_avg_price': float(pos.today_short_avg_price),
                            'today_long_pos': int(pos.today_long_pos),
                            'today_long_avg_price': float(pos.today_long_avg_price),
                            'today_short_pos': int(pos.today_short_pos),
                            'today_short_avg_price': float(pos.today_short_avg_price),
                        }
            else:
                accounts_detail = sc.query(VStrategyAccountDetail).filter(
                    VStrategyAccountDetail.vstrategy_id == self.id,
                    VStrategyAccountDetail.trading_date.is_(None),
                )
                acc_currency = {}
                for _acc_d in self.symbols_accounts:
                    acc_currency[_acc_d['account']] = _acc_d.get('currency', 'CNY')
                # if kwargs.get('is_btc_strategy'):
                #     forex_rate = {}
                # else:
                forex_rate = kdb.get_forex_rate(trading_date)
                for acc in accounts_detail:
                    _acc = convert_account(acc.account)
                    if _acc not in res['accounts']:
                        res['accounts'][_acc] = {
                            'cash': 0,
                            'asset_cash': 0,
                            'currency': acc_currency.get(_acc, 'CNY'),
                        }
                        if _acc == 'init_account' and acc_currency:
                            res['accounts'][_acc]['currency'] = list(acc_currency.values())[0]
                    # if kwargs.get('is_btc_strategy'):
                    #     acc_forex_rate = 1
                    # else:
                    acc_forex_rate = forex_rate[res['accounts'][_acc]['currency'].lower()]
                    res['accounts'][_acc]['forex_rate'] = acc_forex_rate
                    res['accounts'][_acc]['cash'] += ((1 - se_cash_rate) * float(acc.amount) / acc_forex_rate)
                    res['accounts'][_acc]['asset_cash'] += ((1 - se_cash_rate) * float(acc.amount) / acc_forex_rate)

            unrealized_corp_data = self.get_unrealized_corp_items(trading_date, is_first_day=True)

            for s, s_d in unrealized_corp_data.items():
                for l in s_d:
                    l['account'] = convert_account(l['account'])
            res['unrealized_corp_data'] = unrealized_corp_data
        else:
            last_res = sc.query(VstrategyBackTestResult).filter(
                VstrategyBackTestResult.vstrategy_id == self.id,
                VstrategyBackTestResult.trading_date == last_trading_date,
                VstrategyBackTestResult.day_night == 0
            ).first()
            positions = sc.query(VstrategyBackTestResultDetail).filter(
                VstrategyBackTestResultDetail.vstrategy_id == self.id,
                VstrategyBackTestResultDetail.trading_date == last_trading_date,
                VstrategyBackTestResultDetail.day_night == 0
            )
            if not last_res:
                last_res = sc.query(VstrategyBackTestResult).filter(
                    VstrategyBackTestResult.vstrategy_id == self.id,
                    VstrategyBackTestResult.trading_date == last_trading_date,
                    VstrategyBackTestResult.day_night == 1
                ).first()
                positions = sc.query(VstrategyBackTestResultDetail).filter(
                    VstrategyBackTestResultDetail.vstrategy_id == self.id,
                    VstrategyBackTestResultDetail.trading_date == last_trading_date,
                    VstrategyBackTestResultDetail.day_night == 1
                )

            last_account_res = sc.query(
                VstrategyBackTestResultAccount
            ).filter(
                VstrategyBackTestResultAccount.vstrategy_id == self.id,
                VstrategyBackTestResultAccount.trading_date == last_trading_date,
                VstrategyBackTestResultAccount.day_night == 0,
            )

            if not last_res:
                raise ValueError('get last result error')

            correct_val = lambda d: float(d) if d else 100000
            for l_a in last_account_res:
                _l_a_account = convert_account(l_a.account)
                if _l_a_account not in res['accounts']:
                    res['accounts'][_l_a_account] = {
                        'cash': 0,
                        'asset_cash': 0,
                        'currency': l_a.currency or 'CNY',
                        'forex_rate': float(l_a.forex_rate) or 1.0
                    }
                res['accounts'][_l_a_account]['cash'] += (
                        float(l_a.available_cash) / res['accounts'][_l_a_account]['forex_rate'])
                res['accounts'][_l_a_account]['asset_cash'] += (
                        float(l_a.asset_cash) / res['accounts'][_l_a_account]['forex_rate'])

            if not res['accounts']:
                res['accounts']['init_account'] = {
                    'cash': correct_val(last_res.available_cash),
                    'asset_cash': correct_val(last_res.asset_cash),
                    'currency': 'CNY',
                    'forex_rate': 1.0,
                }

            if last_res.done_time.strftime('%Y%m%d%H%M%S') <= '20190417143000':
                accounts_detail = sc.query(VStrategyAccountDetail).filter(
                    VStrategyAccountDetail.vstrategy_id == self.id,
                    VStrategyAccountDetail.trading_date == trading_date
                )
                for acc in accounts_detail:
                    _acc = convert_account(acc.account)
                    if _acc not in res['accounts']:
                        res['accounts'][_acc] = {
                            'cash': 0,
                            'asset_cash': 0,
                            'currency': 'CNY',
                            'forex_rate': 1.0,
                        }
                    res['accounts'][_acc]['cash'] += (float(acc.amount) / res['accounts'][_acc]['forex_rate'])
                    res['accounts'][_acc]['asset_cash'] += (float(acc.amount) / res['accounts'][_acc]['forex_rate'])

            for pos in positions:
                res['positions'][pos.symbol] = {
                    'symbol': pos.symbol,
                    'exchange': pos.exchange,
                    'account': convert_account(pos.account or 'init_account'),
                    'yest_long_pos': int(pos.long_volume),
                    'yest_long_avg_price': float(pos.long_price),
                    'yest_short_pos': int(pos.short_volume),
                    'yest_short_avg_price': float(pos.short_price),
                    'today_long_pos': int(pos.long_volume),
                    'today_long_avg_price': float(pos.long_price),
                    'today_short_pos': int(pos.short_volume),
                    'today_short_avg_price': float(pos.short_price),
                }

        cash_io = sc.query(VStrategyAccountDetail).filter(
            VStrategyAccountDetail.vstrategy_id == self.id,
        )
        for cash in cash_io:
            if not cash.trading_date:
                continue
            d = cash.trading_date.strftime('%Y-%m-%d')
            _acc = convert_account(cash.account)
            if _acc not in res['cash_io']:
                res['cash_io'][_acc] = {}
            res['cash_io'][_acc][d] = res['cash_io'][_acc].get(d, 0) + float(cash.amount) * (1 - se_cash_rate)
        return res

    @staticmethod
    def get_total_investment(vs_id, trading_date):
        sc = session()
        cash_io = sc.query(VStrategyAccountDetail).filter(
            VStrategyAccountDetail.vstrategy_id == vs_id,
        )
        total = 0
        for cash in cash_io:
            d = cash.trading_date.strftime('%Y%m%d') if cash.trading_date else '20000101'
            if d <= trading_date:
                total += float(cash.amount)
        sc.close()
        return total

    def get_unrealized_corp_items(self, start_date, is_first_day=False, **kwargs):
        sc = session()
        if is_first_day or kwargs.get('use_last_live_position'):
            corp_actions = sc.query(PositionCorpActionsTable).filter(
                PositionCorpActionsTable.vstrategy_id == self.id,
                PositionCorpActionsTable.eqy_record_date < start_date,
                or_(
                    PositionCorpActionsTable.dividend_cash_payout_date >= start_date,
                    PositionCorpActionsTable.ex_date >= start_date,
                    PositionCorpActionsTable.dividend_share_listing_date >= start_date,
                )
            )
        else:
            corp_actions = sc.query(VsBackTestPositionCorpActions).filter(
                VsBackTestPositionCorpActions.vstrategy_id == self.id,
                VsBackTestPositionCorpActions.eqy_record_date < start_date,
                or_(
                    VsBackTestPositionCorpActions.dividend_cash_payout_date >= start_date,
                    VsBackTestPositionCorpActions.ex_date >= start_date,
                    VsBackTestPositionCorpActions.dividend_share_listing_date >= start_date,
                )
            )
        data = {}
        for corp in corp_actions:
            sym_corps = data.setdefault(corp.symbol, [])
            sym_corps.append(corp.to_brief())
        sc.close()
        return data

    # def get_vs_t0_position(self):
    #     from service.stock_factor.models import T0SubscriberHistory
    #     res = {}
    #     sc = session()
    #     vs_sub_history = sc.query(T0SubscriberHistory).filter(
    #         T0SubscriberHistory.t0_vs_id == self.id
    #     )
    #
    #     for r in vs_sub_history:
    #         d = r.trading_date.strftime('%Y%m%d_0')
    #         if d in res:
    #             res[d].append(r.alpha_vs_id)
    #         else:
    #             res[d] = [r.alpha_vs_id]
    #     sc.close()
    #     return res

    def get_vs_t0_position(self):
        from models.strategy import VsT0Relation
        res = dict()
        with session_context() as sc:
            t0_records = sc.query(VsT0Relation).filter(
                VsT0Relation.vs_id == self.id
            ).all()

            for record in t0_records:
                d = record.link_date.strftime('%Y%m%d_0')
                dd = res.setdefault(d, [])
                dd.append(record.link_vs_id)
        return res

    @staticmethod
    def get_stock_account_fee_rate(accounts):
        sc = session()
        res = {}
        for r in sc.query(StockVsAccountFee).filter(StockVsAccountFee.account.in_(accounts)):
            res[r.trading_date.strftime('%Y%m%d')] = float(r.fee_rate)
        sc.close()
        return res

    # def new_back_test_analysis(self, trading_date, **kwargs):
    #     from service.stock_factor.models import StockFactorStrategyColumns
    #     # from service.stock_factor.models import T0Subscriber
    #     from models.strategy import VsT0Relation
    #     from cron.strategy_upload_task import vs_back_test
    #     from service.statistic.models import StrategyIncomeAttribution
    #
    #     trading_date = parse(trading_date)
    #     start_date = trading_date.strftime('%Y%m%d')
    #     end_date = start_date
    #     if kwargs.get('end_date'):
    #         end_date = parse(kwargs['end_date']).strftime('%Y%m%d')
    #
    #     Strategy.add_vs_event(
    #         self.id,
    #         trading_date,
    #         TradingTimeRange.Day.value,
    #         StrategyEventTrackConstant.Event.PrepareVsTask.value,
    #     )
    #
    #     sc = session()
    #     strategy = sc.query(Strategy).filter(Strategy.id == self.strategy_id).first()
    #     day_night = strategy.day_night
    #     begin_end_time = consts.BEGIN_END_TIME[day_night]
    #     if strategy.node != 'back_test':
    #         return False
    #
    #     depend_ev = []
    #     for dep in (strategy.dependency or []):
    #         # dep_s = sc.query(Strategy).filter_by(id=dep['id']).first()
    #         if dep['type'] == 'ev':
    #             dep_s = sc.query(Strategy).filter_by(id=dep['id']).first()
    #             depend_ev.append('strategy_upload/output/%s/%s/ev_output_%s_%s_[DAYNIGHT].csv' % (
    #                 dep_s.username, dep_s.name.strip().replace(' ', ''), '[DATE]', str(dep_s.id)
    #             ))
    #
    #     # v_strategy_id = self.id + 200000
    #     task_id = 'v_strategy_id:%s' % self.id
    #     stock_fee_rate = 0
    #     account_exchange = {}
    #     for _acc in self.symbols_accounts:
    #         account_exchange[_acc['exchange']] = _acc['account']
    #         if _acc['account'] in ('1340154147', '109202003202'):
    #             stock_fee_rate = 0.00012
    #
    #     contracts, pos_contracts = [], []
    #     if not strategy.products:
    #         return False
    #
    #     default_account = 'init_account'
    #
    #     def get_symbol_account(exch):
    #         if len(set(account_exchange.values())) <= 1:
    #             return default_account
    #         else:
    #             if exch in consts.STOCK_EXCHANGE:
    #                 for e in ([exch] + consts.STOCK_EXCHANGE):
    #                     if e in account_exchange:
    #                         return account_exchange[exch]
    #             return account_exchange[exch]
    #
    #     quote_source = '0'
    #     if strategy.strategy_type == '23':
    #         quote_source = 'whole'
    #
    #     is_hsa = False
    #     factor_book = {}
    #     se_factor_book = {}
    #     for _p in strategy.products[0]:
    #         if _p['type'] == 'futures' or (_p['exch'] == 'IDEALPRO'):
    #             if _p['exch'] in ('LME', 'IDEALPRO'):
    #                 ranks = ''
    #             else:
    #                 ranks = ','.join(['R%s' % i for i in sorted(_p['rank'])])
    #
    #             if str(strategy.detail.get('quote_deepth', '1')) == '0' and _p['exch'] in consts.FUTURE_EXCHANGE:
    #                 mitype = '12'
    #             else:
    #                 mitype = get_mitype(_p['exch'])
    #
    #             contracts.append('|'.join(
    #                 [_p['symbol'], ranks, _p['exch'], mitype, str(strategy.max_pos), quote_source,
    #                  get_symbol_account(_p['exch'])]
    #             ))
    #         elif _p['type'] == 'stock':
    #             mi_type = get_mitype(_p['exch'])
    #             if _p['symbol'][-3:].upper() in ['.SH', '.SZ']:
    #                 mi_type = get_mitype('SSE_SZSE_INDEX')
    #             else:
    #                 if strategy.strategy_type == '188':
    #                     mi_type += ',54'
    #             contracts.append('|'.join(
    #                 [_p['symbol'], '', _p['exch'], mi_type, str(strategy.max_pos), '0', get_symbol_account(_p['exch'])]
    #             ))
    #         elif _p['type'] == 'stock_factor_FACTOR':
    #             factor_info = _p['symbol'].split('_')
    #             factor_id = int(factor_info[2])
    #             factor_col = factor_info[3]
    #             f_book = factor_book.setdefault(factor_id, [])
    #             f_book.append(factor_col)
    #         elif _p['type'] == 'index':
    #             if _p['symbol'] == 'HSA':
    #                 is_hsa = True
    #             transaction_quote = [str(_x) for _x in strategy.detail.get('transaction_quote', [])]
    #             if '1' in transaction_quote:
    #                 contracts.append('%s|I|54|%s' % (_p['symbol'], get_symbol_account('SSE')))
    #             if '2' in transaction_quote:
    #                 contracts.append('%s|I|53|%s' % (_p['symbol'], get_symbol_account('SSE')))
    #             if '3' in transaction_quote:
    #                 contracts.append('%s|I|52|%s' % (_p['symbol'], get_symbol_account('SSE')))
    #
    #             if strategy.strategy_type == '188':
    #                 contracts.append('%s|I+|%s' % (_p['symbol'], get_symbol_account('SSE')))
    #             else:
    #                 contracts.append('%s|I|%s' % (_p['symbol'], get_symbol_account('SSE')))
    #         elif _p['type'] == 'spot':
    #             contracts.append('|'.join(
    #                 [_p['symbol'], '', _p['exch'], get_mitype(_p['exch']),
    #                  str(strategy.max_pos), quote_source, get_symbol_account(_p['exch'])]
    #             ))
    #         else:
    #             raise ValueError('product type (%s, %s) error' % (_p['symbol'], _p['type']))
    #
    #     if strategy.strategy_type in consts.t0_stock_strategy_type:
    #         # for t0_sub in sc.query(T0Subscriber).filter(T0Subscriber.t0_vs_id == self.id):
    #         #     contracts.append('81|1|%s|' % t0_sub.alpha_vs_id)
    #
    #         t0_records = sc.query(VsT0Relation).filter(
    #             VsT0Relation.vs_id == self.id,
    #             VsT0Relation.deleted == False
    #         ).all()
    #         for t0_record in t0_records:
    #             contracts.append('81|1|%s|' % t0_record.link_vs_id)
    #
    #     use_default = False
    #     if len(set(account_exchange.values())) <= 1:
    #         use_default = True
    #
    #     last_account_positions = self.get_last_back_test_account_position_v3(
    #         trading_date.strftime('%Y%m%d'),
    #         use_default=use_default,
    #         strategy_type=strategy.strategy_type,
    #         use_last_live_position=kwargs.get('use_last_live_position', False),
    #         se_cash_rate=strategy.detail.get('se_cash_rate', 0)
    #     )
    #     cash_io = last_account_positions.get('cash_io', {})
    #     total_investment = VStrategies.get_total_investment(self.id, start_date)
    #     if not last_account_positions['accounts']:
    #         return False
    #     yesterday_pos, today_pos = [], []
    #     for _, pos in last_account_positions['positions'].items():
    #         if not (pos['today_long_pos'] > 0 or pos['today_short_pos'] > 0):
    #             continue
    #         yesterday_pos.append(
    #             '|'.join([str(pos[key]) for key in [
    #                 'symbol', 'yest_long_pos', 'yest_long_avg_price',
    #                 'yest_short_pos', 'yest_short_avg_price', 'account'
    #             ]])
    #         )
    #         today_pos.append(
    #             '|'.join([str(pos[key]) for key in [
    #                 'symbol', 'today_long_pos', 'today_long_avg_price', 'today_short_pos',
    #                 'today_short_avg_price', 'account'
    #             ]])
    #         )
    #         if len(pos['exchange']) <= 2:
    #             exchange = consts.EXCHANGE[pos['exchange']]
    #
    #             if exchange == 'ICEU' and pos['symbol'][:1].upper() == 'B' and (exchange not in account_exchange) and (
    #                     'ICEE' in account_exchange):
    #                 exchange = 'ICEE'
    #         else:
    #             exchange = pos['exchange']
    #
    #         if exchange in (consts.FUTURE_EXCHANGE + consts.FOREIGN_EXCHANGE):
    #             if str(strategy.detail.get('quote_deepth', '1')) == '0' and exchange in consts.FUTURE_EXCHANGE:
    #                 mi_type = '12'
    #             else:
    #                 mi_type = get_mitype(exchange)
    #             pos_contracts.append(
    #                 '|'.join(
    #                     [pos['symbol'], '', exchange, mi_type, str(strategy.max_pos), quote_source,
    #                      get_symbol_account(exchange)]
    #                 )
    #             )
    #         elif exchange in consts.STOCK_EXCHANGE and not is_hsa:
    #             if strategy.strategy_type == '188':
    #                 mi_type = '9, 54'
    #             else:
    #                 mi_type = '9'
    #             pos_contracts.append(
    #                 '|'.join(
    #                     [pos['symbol'], '', exchange, mi_type, str(strategy.max_pos), '0', get_symbol_account(exchange)]
    #                 )
    #             )
    #         else:
    #             pass
    #
    #     server = kwargs.get('server', '')
    #     trade_model = kwargs.get('trade_model', '')
    #     if not server:
    #         server = self.deploy_server
    #
    #     if (not server) or (server == 'default'):
    #         server = sc.query(StrategyLiveRunRecords.host).filter(
    #             StrategyLiveRunRecords.vstrategy_id == self.id
    #         ).order_by(StrategyLiveRunRecords.id.desc()).first()
    #         server = server and server[0] or ''
    #
    #     if not trade_model:
    #         trade_model = self.trade_model or strategy.detail['trade_model']
    #
    #     so_path = strategy.strategy_upload_file['relative_path']
    #     if kwargs.get('so_id'):
    #         so_file = sc.query(StrategyUploadFile).filter(StrategyUploadFile.id == int(kwargs['so_id'])).first()
    #         if so_file:
    #             so_path = so_file.relative_path
    #
    #     config_type = 0
    #     if strategy.id > 208596:
    #         config_type = 1
    #     if strategy.strategy_type in consts.t0_stock_strategy_type:
    #         config_type = 2
    #
    #     smart_execution_so_path = ''
    #     smart_execution_ev = ''
    #     se_contracts = []
    #
    #     if strategy.detail.get('vwap_version'):
    #         smart_execution_strategy = sc.query(Strategy).join(
    #             StockSmartExecutionVersion, StockSmartExecutionVersion.strategy_id == Strategy.id
    #         ).filter(
    #             StockSmartExecutionVersion.value == strategy.detail['vwap_version']
    #         ).first()
    #         if smart_execution_strategy:
    #             smart_execution_ev = []
    #             for _dep in (smart_execution_strategy.dependency or []):
    #                 # _dep_s = sc.query(Strategy).filter_by(id=_dep['id']).first()
    #                 if _dep['type'] == 'ev':
    #                     _dep_s = sc.query(Strategy).filter_by(id=_dep['id']).first()
    #                     smart_execution_ev.append('strategy_upload/output/%s/%s/ev_output_%s_%s_[DAYNIGHT].csv' % (
    #                         _dep_s.username, _dep_s.name.strip().replace(' ', ''), '[DATE]', str(_dep_s.id)
    #                     ))
    #             smart_execution_ev = '|'.join(smart_execution_ev)
    #             smart_execution_so_path = smart_execution_strategy.strategy_upload_file['relative_path']
    #
    #             for p_portfolio in smart_execution_strategy.products[:1]:
    #                 for _p in p_portfolio:
    #                     if _p['type'] == 'futures':
    #                         ranks = ','.join(['R%s' % i for i in sorted(_p['rank'])])
    #                         if str(smart_execution_strategy.detail.get('quote_deepth', '1')) == '0' and _p[
    #                             'exch'] in consts.FUTURE_EXCHANGE:
    #                             mitype = '12'
    #                         else:
    #                             mitype = get_mitype(_p['exch'])
    #
    #                         se_contracts.append('|'.join(
    #                             [_p['symbol'], ranks, _p['exch'], mitype, '1000000', quote_source,
    #                              get_symbol_account(_p['exch'])]
    #                         ))
    #                     elif _p['type'] == 'stock':
    #                         mi_type = get_mitype(_p['exch'])
    #                         if _p['symbol'][-3:].upper() in ['.SH', '.SZ']:
    #                             mi_type = get_mitype('SSE_SZSE_INDEX')
    #                         se_contracts.append('|'.join(
    #                             [_p['symbol'], '', _p['exch'], mi_type, '1000000', '0', get_symbol_account(_p['exch'])]
    #                         ))
    #                     elif _p['type'] == 'index':
    #                         if _p['symbol'] == 'HSA':
    #                             is_hsa = True
    #                         transaction_quote = [str(_x) for _x in strategy.detail.get('transaction_quote', [])]
    #                         if '1' in transaction_quote:
    #                             se_contracts.append('%s|I|54|%s' % (_p['symbol'], get_symbol_account('SSE')))
    #                         if '2' in transaction_quote:
    #                             se_contracts.append('%s|I|53|%s' % (_p['symbol'], get_symbol_account('SSE')))
    #                         if '3' in transaction_quote:
    #                             se_contracts.append('%s|I|52|%s' % (_p['symbol'], get_symbol_account('SSE')))
    #                         se_contracts.append('%s|I|%s' % (_p['symbol'], get_symbol_account('SSE')))
    #                     elif _p['type'] == 'stock_factor_FACTOR':
    #                         factor_info = _p['symbol'].split('_')
    #                         factor_id = int(factor_info[2])
    #                         factor_col = factor_info[3]
    #                         f_book = se_factor_book.setdefault(factor_id, [])
    #                         f_book.append(factor_col)
    #                     elif _p['type'] == 'stock_factor_POSITION':
    #                         se_contracts.append('81|0|%s|' % (_p['symbol'].rsplit('_', 1)[-1]))
    #                     else:
    #                         pass
    #
    #     factor_book_task = []
    #     se_factor_book_task = []
    #     for f_id, cols in factor_book.items():
    #         contracts.append('80|0|%s|' % f_id)
    #         f_columns = StockFactorStrategyColumns.get_factor_columns(f_id)
    #         if 'ALL' in cols:
    #             factor_book_task.append(
    #                 {'id': f_id, 'columns': f_columns, 'indexes': list(range(len(f_columns))),
    #                  'total_num': len(f_columns)}
    #             )
    #         else:
    #             book_col = []
    #             book_col_index = []
    #             for _i, _c in enumerate(f_columns):
    #                 if _c in cols:
    #                     book_col.append(_c)
    #                     book_col_index.append(_i)
    #             factor_book_task.append(
    #                 {'id': f_id, 'columns': book_col, 'indexes': book_col_index, 'total_num': len(f_columns)}
    #             )
    #
    #     for f_id, cols in se_factor_book.items():
    #         se_contracts.append('80|0|%s|' % f_id)
    #         f_columns = StockFactorStrategyColumns.get_factor_columns(f_id)
    #         if 'ALL' in cols:
    #             se_factor_book_task.append(
    #                 {'id': f_id, 'columns': f_columns, 'indexes': list(range(len(f_columns))),
    #                  'total_num': len(f_columns)}
    #             )
    #         else:
    #             book_col = []
    #             book_col_index = []
    #             for _i, _c in enumerate(f_columns):
    #                 if _c in cols:
    #                     book_col.append(_c)
    #                     book_col_index.append(_i)
    #             se_factor_book_task.append(
    #                 {'id': f_id, 'columns': book_col, 'indexes': book_col_index, 'total_num': len(f_columns)}
    #             )
    #
    #     t0_position = {}
    #     if strategy.strategy_type in consts.t0_stock_strategy_type:
    #         t0_position = self.get_vs_t0_position()
    #
    #     income_attribution = {}
    #     if strategy.strategy_type in consts.stock_strategy_type:
    #         income_attribution = StrategyIncomeAttribution.get_back_test_income_attribution_adjusted(
    #             strategy.id, start_date=start_date
    #         )
    #
    #     task_cmd = {
    #         'reserve_type': 1,
    #         'db_conf': ','.join([config.KDB_HOST, str(config.KDB_PORT), config.KDB_USER, config.KDB_PASSWD]),
    #         'type': 110,
    #         'business': 2,
    #         'is_test': 0,
    #         'start_date': int(start_date),
    #         'end_date': int(end_date),
    #         'begin_time': begin_end_time['begin_time'],
    #         'end_time': begin_end_time['end_time'],
    #         'day_night_flag': day_night,
    #         'paper_trading_date': strategy.paper_trading_date.strftime('%Y%m%d'),
    #         'agent': '',
    #         'task_id': task_id,
    #         'user': strategy.username,
    #         'user_id': strategy.r_create_user_id,
    #         'flag_write_tunnel_log': False,
    #         'flag_write_strat_log': True,
    #         'flag_cross_day_position': True,
    #         'load_symbol_from_tradelist': strategy.detail.get('load_ev_config', False),
    #         'max_accum_open_vol': 1000000,
    #         'trader_type': 1,
    #         'match_type': 1,
    #         'plugins': [],
    #         'match_param': consts.COMMON_MATCH_PARAM,
    #         'sell_stock_short': strategy.detail.get('stock_loan', False),
    #         'so_path': [so_path],
    #         'config_type': config_type,
    #         'portfolio_optimization_model_version': StockPortfolioOptimizationVersion.get_paras(
    #             strategy.detail.get('portfolio_optimization_so_version', '')
    #         ),
    #         'vwap_version': strategy.detail.get('vwap_version', 'v1') or 'v1',
    #         'portfolio_optimization_ev_path': '/mnt/share_media/portfolio_optimization_ev/',
    #         'smart_execution_so_path': smart_execution_so_path,
    #         'smart_execution_ev': smart_execution_ev,
    #         'se_item': {
    #             'smart_execution_so_path': smart_execution_so_path,
    #             'smart_execution_ev': smart_execution_ev,
    #             'contracts': se_contracts,
    #             'factor_book': se_factor_book_task,
    #             'se_cash': total_investment * strategy.detail.get('se_cash_rate', 0),
    #             'server': get_linked_merge_vs_deploy_ip(vs_id=self.id),
    #         },
    #         't0_position': t0_position,
    #         'income_attribution': income_attribution,
    #         'factor_book': factor_book_task,
    #         'strat_item': [{
    #             'strat_name': strategy.id_no or (strategy.name.strip().replace(' ', '')),
    #             'server': server,
    #             'strat_id': strategy.id,
    #             'contracts': contracts,
    #             'pos_contracts': pos_contracts,
    #             'strat_param_file': '|'.join(depend_ev),
    #             'output_file_path': './output/vstrategy/%s' % self.id,
    #             'accounts': [
    #                 '|'.join([
    #                     _acc, str(_acc_cash['cash']), str(_acc_cash['asset_cash']),
    #                     str(_acc_cash['currency'].upper()), str(_acc_cash['forex_rate'])])
    #                 for _acc, _acc_cash in last_account_positions['accounts'].items()
    #             ],
    #             'yesterday_pos': yesterday_pos,
    #             'today_pos': today_pos,
    #             'cash_limit': self.get_vs_cash_limit(start_date, end_date),
    #             'factor_book': factor_book_task,
    #         }],
    #         'settlement_kwargs': {
    #             'config_id': 0,
    #             'hedge': strategy.hedge or '',
    #             'hedge_type': strategy.hedge_type or '',
    #             'is_foregin_strategy': strategy.is_foregin_strategy,
    #             'strategy_type': Strategy.convert_strategy_type(strategy.strategy_type),
    #             'is_hk_stock': (self.id in consts.hk_stock_vs_ids) or (strategy.strategy_type in ('27', '28')),
    #             'cash_io': cash_io,
    #             'stock_fee_rate': stock_fee_rate,
    #             'stock_account_fee_rate': self.get_stock_account_fee_rate(list(account_exchange.values())),
    #             'se_cash_rate': strategy.detail.get('se_cash_rate', 0),
    #         },
    #         'unrealized_corp_data': last_account_positions.get('unrealized_corp_data',
    #                                                            {}) if last_account_positions.get(
    #             'is_first_day') else self.get_unrealized_corp_items(start_date),
    #         'is_hk_strategy': strategy.strategy_type in ('27', '28'),
    #     }
    #
    #     if len(task_cmd['portfolio_optimization_model_version']) > 31:
    #         task_cmd['reserve_type'] = 2
    #
    #     if factor_book_task:
    #         task_cmd['reserve_type'] = 3
    #
    #     optional_module = strategy.detail.get('modules', '[]')
    #     if 'VWAP' in optional_module:
    #         task_cmd['plugins'].append('vwap')
    #     if trade_model:
    #         task_cmd['strat_item'][0]['trade_model'] = trade_model
    #     time_interval = int(float(strategy.detail.get('time_interval', 0)))
    #     if time_interval > 0:
    #         task_cmd['time_interval'] = time_interval
    #     task_cmd['strat_item'] = task_cmd['strat_item'][0]
    #
    #     extra_arguments = {
    #         'log_level': strategy.detail.get('log_level', StrategyConstant.DetailLogLevel.Production.value),
    #         'icopy': 0
    #     }
    #     task_cmd['extra_arguments'] = extra_arguments
    #
    #     rds = redis.Redis(host=config.redis['host'], port=config.redis['port'], db=config.redis['db'])
    #
    #     if strategy.detail.get('back_test_split') or (
    #             strategy.strategy_type == StrategyConstant.StrategyType.StockFactor.value):
    #         task_queue = consts.NEW_AGENT_TASK_QUEUE + '_part1'
    #     elif strategy.strategy_type in consts.stock_strategy_type + consts.hedge_stock_strategy_type:
    #         task_queue = consts.NEW_AGENT_TASK_QUEUE + '_stock'
    #     else:
    #         task_queue = consts.NEW_AGENT_TASK_QUEUE + '_future'
    #
    #     check_res = Strategy.vs_back_test_check_dependency(self.id, trading_date, 0, task=task_cmd)
    #     if (not check_res) and kwargs.get('auto'):
    #         vs_back_test.apply_async(args=(self.id, start_date), kwargs={'auto': True}, countdown=600)
    #         sc.close()
    #         return False
    #
    #     task_cmd = json.dumps(task_cmd)
    #     if strategy.strategy_type in consts.t0_stock_strategy_type:
    #         task_cmd = task_cmd.replace('init_account', 'account%s' % self.id)
    #
    #     rds.lpush(task_queue, task_cmd)
    #
    #     Strategy.add_vs_event(
    #         self.id,
    #         trading_date,
    #         TradingTimeRange.Day.value,
    #         StrategyEventTrackConstant.Event.SendVsTask.value,
    #     )
    #
    #     sc.close()
    #     return True

    def get_vs_cash_limit(self, start_date, end_date):
        sc = session()
        cash_limits = sc.query(
            CashLimitDetail
        ).join(
            CashLimit, CashLimit.id == CashLimitDetail.cash_limit_id
        ).filter(
            CashLimit.vs_id == self.id,
            CashLimitDetail.start_time <= parse(end_date).strftime('%Y-%m-%d 20:00:00'),
            CashLimitDetail.end_time >= parse(start_date).strftime('%Y-%m-%d 00:00:00'),
        )
        data = []
        for l in cash_limits:
            data.append({
                'start_time': l.start_time.strftime('%Y%m%d 000000'),
                'end_time': l.end_time.strftime('%Y%m%d 153000'),
                'symbol': l.symbol,
                'max_long_ratio': float(l.long_limit),
                'max_short_ratio': float(l.short_limit),
            })
        sc.close()
        return data

    # def back_test_analysis(self, trading_date, **kwargs):
    #     trading_date = parse(trading_date)
    #     sc = session()
    #     strategy = sc.query(Strategy).filter(Strategy.id == self.strategy_id).first()
    #     if strategy.is_new_so:
    #         sc.close()
    #         return self.new_back_test_analysis(trading_date.strftime('%Y%m%d'), **kwargs)
    #
    #     sc.close()
    #     return True


class VsBackTestOperationlogs(ModelBase):
    __tablename__ = 'vs_back_test_operation_logs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vs_id = Column(INTEGER, nullable=False, index=True)
    user_id = Column(INTEGER, nullable=False)
    user_name = Column(VARCHAR(32), nullable=False)
    start_date = Column(DATE, nullable=False)
    end_date = Column(DATE, nullable=False)
    deploy_server = Column(VARCHAR(18), nullable=True)
    trade_model = Column(VARCHAR(32), nullable=True)

    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())

    def to_dict(self):
        return {
            'id': self.id,
            'vs_id': self.vs_id,
            'user_name': self.user_name or '',
            'start_date': self.start_date.strftime('%Y%m%d'),
            'end_date': self.end_date.strftime('%Y%m%d'),
            'server': self.deploy_server or '',
            'trade_model': self.trade_model or '',
            'create_time': self.r_create_time.strftime('%Y%m%d %X'),
        }


class VStrategyAccountDetail(ModelBase):
    __tablename__ = 'vstrategy_account_detail'
    id = Column(BIGINT(unsigned=True), primary_key=True)
    vstrategy_id = Column(INTEGER, nullable=False)
    portfolio_id = Column(INTEGER, nullable=False)
    account = Column(VARCHAR(128), nullable=False)
    amount = Column(DOUBLE, nullable=False, default=0)
    actual_amount = Column(DOUBLE, nullable=False, default=0)
    annual_rate = Column(DOUBLE, nullable=False, default=0)
    exchange = Column(VARCHAR(32), nullable=False)
    trading_date = Column(DATE, nullable=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True)
    r_update_user_id = Column(INTEGER, nullable=True)
    start_time = Column(INTEGER, nullable=False, default=0)
    end_time = Column(INTEGER, nullable=False, default=0)
    is_live = Column(BOOLEAN, nullable=False, default=False)

    @staticmethod
    def get_vstrategy_cash(vs_ids, shift=True, dateformat='%Y-%m-%d'):
        if not vs_ids:
            return {}
        if not isinstance(vs_ids, list):
            return {}
        sc = session()
        detail = {}
        try:
            v_account_details = sc.query(
                VStrategyAccountDetail.account.label('account'),
                VStrategyAccountDetail.actual_amount.label('actual_amount'),
                VStrategyAccountDetail.trading_date.label('trading_date'),
                StrategyPortfolio.live_time.label('live_time'),
            ).join(
                StrategyPortfolio, StrategyPortfolio.id == VStrategyAccountDetail.portfolio_id
            ).filter(VStrategyAccountDetail.vstrategy_id.in_(vs_ids))

            for v_a_detail in v_account_details:
                date = v_a_detail.trading_date or v_a_detail.live_time
                if shift:
                    date = (date - timedelta(days=1)).strftime(dateformat)
                else:
                    date = date.strftime(dateformat)
                detail[date] = detail.get(date, 0) + float(v_a_detail.actual_amount)
        except Exception as e:
            detail = {}
            sentry.captureException()
        sc.close()
        return detail

    @staticmethod
    def get_vstrategy_cash2(vs_ids, shift=True, dateformat='%Y-%m-%d', **kwargs):
        """
        Sum up account cash flow (income and withdraw) by vstrategy ids.

        If 11111111 is in vs_ids, only sum up vs_ids,
        else sum up vstrategy ids from vs_ids  and strategies created by Fund/Department users                      
        """
        if not vs_ids:
            return {}
        if not isinstance(vs_ids, list):
            return {}
        sc = session()
        detail = {}
        try:
            # Vsid in portfolios which created by Fund/Department users.
            # The first fund relased is coded as "YIN HUO"            
            yinhuo_vs_ids = sc.query(
                VStrategies.id,
            ).join(
                StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
            ).filter(
                or_(
                    StrategyPortfolio.r_create_user_id.in_(consts.investment_user_ids),
                    StrategyPortfolio.business.in_(['stock', 'future']),
                ),
                VStrategies.id.in_(vs_ids),
            )

            # Foreign arbitrage strategies, created by ZHANGQI, Currently this user has been deprecated,
            # also most strategies in this list are forever offline.
            # TODO: Need simplification here.                     
            zhangqi_vs_ids = [1313, 1300, 1343, 1392, 1391, 1408, 1430, 1712, 1747, 1789]

            if len(vs_ids) <= 10:
                yinhuo_vs_ids = yinhuo_vs_ids.filter(
                    VStrategies.id.notin_(zhangqi_vs_ids)
                )

            yinhuo_vs_ids = [r[0] for r in yinhuo_vs_ids]

            if 11111111 in vs_ids:
                yinhuo_vs_ids = []

            if yinhuo_vs_ids:
                detail = VStrategyAccountDetail.get_vstrategy_cash_summary(
                    vs_ids, shift=shift, dateformat=dateformat, **kwargs
                )

            other_vs_ids = [v_id for v_id in vs_ids if v_id not in yinhuo_vs_ids]

            v_account_details = sc.query(
                VStrategyAccountDetail.account.label('account'),
                VStrategyAccountDetail.actual_amount.label('actual_amount'),
                VStrategyAccountDetail.trading_date.label('trading_date'),
                StrategyPortfolio.live_time.label('live_time'),
            ).join(
                StrategyPortfolio, StrategyPortfolio.id == VStrategyAccountDetail.portfolio_id
            ).filter(VStrategyAccountDetail.vstrategy_id.in_(other_vs_ids))

            for v_a_detail in v_account_details:
                date = v_a_detail.trading_date or v_a_detail.live_time
                if shift:
                    date = (date - timedelta(days=1)).strftime(dateformat)
                else:
                    date = date.strftime(dateformat)
                detail[date] = detail.get(date, 0) + float(v_a_detail.actual_amount)
        except Exception as e:
            detail = {}
            sentry.captureException()
        sc.close()
        return detail

    @staticmethod
    def get_vstrategy_cash_summary(vs_ids, shift=True, dateformat='%Y-%m-%d', **kwargs):
        """ Sum up account cash income and withdraw by vsid.

        :NOTE: This functions do not comply with trading date shifting.         

        :param  vs_ids: list, Virtual strategy id.
        :param shift: This field is useless.
        :return: dict, key: date
                       value: accumulated cash income and withdraw.
        """
        if not vs_ids:
            return {}
        if not isinstance(vs_ids, list):
            return {}
        sc = session()
        detail = {}
        try:
            if kwargs.get('is_future'):
                accounts = [
                    a[0]
                    for a in sc.query(
                        distinct(VsAccount.account)
                    ).filter(
                        VsAccount.vstrategy_id.in_(vs_ids)
                    )]
            else:
                accounts = [
                    a[0]
                    for a in sc.query(
                        distinct(VStrategyAccountDetail.account)
                    ).filter(
                        VStrategyAccountDetail.vstrategy_id.in_(vs_ids)
                    )]

            v_account_details = sc.query(
                AccountCash.actual_amount.label('actual_amount'),
                AccountCash.trading_date.label('trading_date'),
            ).filter(
                AccountCash.account.in_(accounts)
            )

            for v_a_detail in v_account_details:
                date = v_a_detail.trading_date.strftime(dateformat)
                detail[date] = detail.get(date, 0) + float(v_a_detail.actual_amount)
        except Exception as e:
            detail = {}
            sentry.captureException()
        sc.close()
        return detail

    @staticmethod
    def get_vstrategies_cash_io(current_user, vs_ids=None):
        if vs_ids and not isinstance(vs_ids, list):
            return []
        sc = session()
        detail = sc.query(
            VStrategyAccountDetail.id.label('id'),
            VStrategyAccountDetail.account.label('account'),
            VStrategyAccountDetail.amount.label('fund'),
            VStrategyAccountDetail.actual_amount.label('actual_fund'),
            VStrategyAccountDetail.exchange.label('exchange'),
            VStrategyAccountDetail.trading_date.label('trading_date'),
            StrategyPortfolio.name.label('sp_name'),
            StrategyPortfolio.id.label('sp_id'),
            StrategyPortfolio.r_create_time.label('sp_create_date'),
            Strategy.id_no.label('s_name'),
            Strategy.id.label('strategy_id'),
            VStrategies.id.label('vstrategy_id'),
        ).join(
            VStrategies, VStrategies.id == VStrategyAccountDetail.vstrategy_id
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategyAccountDetail.portfolio_id
        ).join(
            Strategy, VStrategies.strategy_id == Strategy.id
        ).filter(
            VStrategies.status == consts.STRATEGY_LIVE,
            StrategyPortfolio.status == consts.STRATEGY_LIVE,
            StrategyPortfolio.source == 'platform',
            VStrategies.source == 'platform',
        )
        if not current_user['is_superuser']:
            detail = detail.filter(StrategyPortfolio.r_create_user_id == current_user['id'])
        if vs_ids:
            detail = detail.filter(VStrategies.id.in_(vs_ids))
        detail = detail.order_by(VStrategyAccountDetail.portfolio_id, VStrategyAccountDetail.vstrategy_id)
        columns = [
            'id', 'strategy_portfolio_name', 'strategy_portfolio_id', 'vstrategy_id', 'strategy_id', 'exchange',
            'account', 'fund',
            'actual_fund', 'trading_date'
        ]
        values = [
            [
                d.id, d.sp_name, d.sp_id, d.vstrategy_id, d.s_name, d.exchange, d.account,
                float(d.fund), float(d.actual_fund), (d.trading_date or d.sp_create_date).strftime('%Y%m%d')]
            for d in detail
        ]
        sc.close()
        return {
            'columns': columns,
            'values': values
        }

    @staticmethod
    def get_vs_accounts(vs_ids):
        sc = session()
        accounts = [
            a[0]
            for a in sc.query(
                distinct(VStrategyAccountDetail.account)
            ).filter(
                VStrategyAccountDetail.vstrategy_id.in_(vs_ids)
            )]
        sc.close()
        return accounts


class AccountCash(ModelBase):
    __tablename__ = 'account_cash_io'
    id = Column(BIGINT(unsigned=True), primary_key=True)
    account = Column(VARCHAR(128), nullable=False)
    amount = Column(DOUBLE, nullable=False, default=0)  # useless field.
    actual_amount = Column(DOUBLE, nullable=False, default=0)
    trading_date = Column(DATE, nullable=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=True, default=1)
    r_update_user_id = Column(INTEGER, nullable=True, default=1)

    @staticmethod
    def add_record(account, actual_amount, trading_date):
        """
        account cash io for real, not for cash transfer between account in the same product
        :param account: string
        :param actual_amount: int, +/-
        :param trading_date: datetime.date
        :return:
        """
        with session_context() as sc:
            record = AccountCash(
                account=account,
                actual_amount=actual_amount,
                trading_date=trading_date
            )
            sc.add(record)


class TradeLogs(ModelBase):
    __tablename__ = 'trade_logs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    trading_date = Column(DATE, nullable=False)
    calendar_time = Column(TIME, nullable=False)
    calendar_microsec = Column(INTEGER, nullable=True)
    exchange_time = Column(TIME, nullable=True)
    exchange_microsec = Column(INTEGER, nullable=True)
    internal_date = Column(DATE, nullable=False)
    calendar_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    server = Column(VARCHAR(45), nullable=False)
    account = Column(VARCHAR(32), nullable=False)
    log_type = Column(VARCHAR(1), nullable=False)
    vstrategy_id = Column(BIGINT(unsigned=True), nullable=False)
    serial_no = Column(VARCHAR(32), nullable=False)
    cancel_serial_no = Column(VARCHAR(32), nullable=False)
    symbol = Column(VARCHAR(32), nullable=False)
    direction = Column(INTEGER, nullable=False)
    open_close = Column(INTEGER, nullable=False)
    order_price = Column(DOUBLE, nullable=False)
    order_vol = Column(INTEGER, nullable=False)
    entrust_no = Column(BIGINT(unsigned=True), nullable=False)
    entrust_status = Column(VARCHAR(1), nullable=False)
    trade_price = Column(DOUBLE, nullable=False)
    trade_vol = Column(INTEGER, nullable=False)
    remain_vol = Column(INTEGER, nullable=False)
    trade_no = Column(BIGINT, nullable=False)
    speculator = Column(INTEGER, nullable=False)
    order_price_type = Column(INTEGER, nullable=False)
    order_type = Column(INTEGER, nullable=False)
    error_no = Column(INTEGER, nullable=False)
    quote_trigger = Column(VARCHAR(16), nullable=True)
    cp_open_vol_remain = Column(INTEGER, nullable=False)
    cp_cancel_vol_remain = Column(INTEGER, nullable=False)
    rdtsc = Column(BIGINT(unsigned=True), nullable=True)

    def to_dict(self):
        return {
            'vstrategy_id': self.vstrategy_id,
            'strategy_id': self.vstrategy_id,
            'time_stamp': None,
            'microsec': self.calendar_microsec,
            'trading_date': self.trading_date.strftime('%Y%m%d'),
            'calendar_time': str(self.calendar_time),
            'calendar_microsec': self.calendar_microsec,
            'exchange_time': str(self.exchange_time),
            'exchange_microsec': self.exchange_microsec,
            'internal_date': self.internal_date.strftime('%Y%m%d'),
            'calendar_date': self.calendar_date.strftime('%Y%m%d'),
            'day_night': self.day_night,
            'server': self.server,
            'account': self.account,
            'msg_type': self.log_type,
            'serial_no': self.serial_no,
            'cancel_serial_no': self.cancel_serial_no,
            'symbol': self.symbol,
            'direction': self.direction,
            'open_close': self.open_close,
            'price': float(self.order_price),
            'volume': self.order_vol,
            'entrust_no': self.entrust_no,
            'entrust_status': self.entrust_status,
            'trade_price': float(self.trade_price),
            'trade_vol': self.trade_vol,
            'vol_remain': self.remain_vol,
            'trade_no': self.trade_no,
            'speculator': self.speculator,
            'order_price_type': self.order_price_type,
            'order_type': self.order_type,
            'error_no': self.error_no,
            'trigger': self.quote_trigger,
            'open_vol_remain': self.cp_open_vol_remain,
            'n_cancel_remain': self.cp_cancel_vol_remain,
        }

    def brief(self):
        calendar_time = '%s %s.%s' % (
            self.calendar_date.strftime('%Y%m%d'), str(self.calendar_time), str(self.calendar_microsec or 0).zfill(6))
        data = {
            'send_time': calendar_time,
            'transaction_time': '',
            'msg_type': self.log_type,
            'log_type': self.log_type,
            'serial_no': self.serial_no,
            'open_close': self.open_close,
            'price': float(self.order_price),
            'volume': float(self.order_vol or 0),
            'trade_price': float(self.trade_price),
            'trade_vol': self.trade_vol,
            'vol_remain': self.remain_vol,
            'account': self.account,
            'direction': self.direction,
            'symbol': self.symbol,
            'vstrategy_id': self.vstrategy_id,
            'day_night': self.day_night,
            'business_volume': float(self.trade_vol),
            'business_price': float(self.trade_price),
            'parent_serial_no': '',
            'cancel_time': '',
        }
        if str(self.log_type) == consts.trade_rtn:
            data['transaction_time'] = calendar_time
        if str(self.entrust_status) == 'd':
            data['cancel_time'] = calendar_time
        return data


class TuringTradeLogs(ModelBase):
    __tablename__ = 'turing_trade_logs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    trading_date = Column(DATE, nullable=False)
    calendar_time = Column(TIME, nullable=False)
    calendar_microsec = Column(INTEGER, nullable=True)
    exchange_time = Column(TIME, nullable=True)
    exchange_microsec = Column(INTEGER, nullable=True)
    internal_date = Column(DATE, nullable=False)
    calendar_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    server = Column(VARCHAR(45), nullable=False)
    account = Column(VARCHAR(32), nullable=False)
    log_type = Column(VARCHAR(1), nullable=False)
    vstrategy_id = Column(BIGINT(unsigned=True), nullable=False)
    serial_no = Column(VARCHAR(32), nullable=False)
    cancel_serial_no = Column(VARCHAR(32), nullable=False)
    symbol = Column(VARCHAR(32), nullable=False)
    direction = Column(INTEGER, nullable=False)
    open_close = Column(INTEGER, nullable=False)
    order_price = Column(DOUBLE, nullable=False)
    order_vol = Column(INTEGER, nullable=False)
    entrust_no = Column(BIGINT(unsigned=True), nullable=False)
    entrust_status = Column(VARCHAR(1), nullable=False)
    trade_price = Column(DOUBLE, nullable=False)
    trade_vol = Column(INTEGER, nullable=False)
    remain_vol = Column(INTEGER, nullable=False)
    trade_no = Column(BIGINT, nullable=False)
    speculator = Column(INTEGER, nullable=False)
    order_price_type = Column(INTEGER, nullable=False)
    order_type = Column(INTEGER, nullable=False)
    error_no = Column(INTEGER, nullable=False)
    quote_trigger = Column(VARCHAR(16), nullable=True)
    cp_open_vol_remain = Column(INTEGER, nullable=False)
    cp_cancel_vol_remain = Column(INTEGER, nullable=False)
    rdtsc = Column(BIGINT(unsigned=True), nullable=True)


class SettlementManualTradelog(ModelBase):
    __tablename__ = 'settlement_manual_tradelogs'

    account = Column(String(20), primary_key=True, nullable=False, server_default=text("''"))
    serial_no = Column(String(20), primary_key=True, nullable=False, server_default=text("''"))
    vstrategy_id = Column(BigInteger, nullable=False)
    trading_date = Column(Date, primary_key=True, nullable=False)
    daynight = Column(Enum('Unknown', 'DAY', 'NIGHT'), nullable=False)
    symbol = Column(String(20), nullable=False)
    direction = Column(Enum('Unknown', 'BUY', 'SELL'), nullable=False, server_default=text("'Unknown'"))
    open_close = Column(Enum('Unknown', 'OPEN', 'CLOSE'), nullable=False, server_default=text("'Unknown'"))
    trade_price = Column(String(20), nullable=False, server_default=text("'0'"))
    trade_vol = Column(String(20), nullable=False, server_default=text("'0'"))
    trade_time = Column(DateTime, nullable=False, default='1900-01-01 00:00:00.000000')
    entrust_no = Column(BigInteger, nullable=False, default=0)
    ctime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    utime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))

    def brief(self):
        valid = True
        if self.daynight == 'NIGHT':
            day_night = 1
        elif self.daynight == 'DAY':
            day_night = 0
        else:
            day_night = None
            valid = False

        if self.direction == 'SELL':
            direction = 1
        elif self.direction == 'BUY':
            direction = 0
        else:
            direction = None
            valid = False

        if self.open_close == 'OPEN':
            open_close = 0
        elif self.open_close == 'CLOSE':
            open_close = 1
        else:
            open_close = None
            valid = False

        serial_no = ''.join([{0: '2', 1: '1'}.get(day_night, 'X'), self.serial_no])

        return {
            'valid': valid,
            'send_time': self.trade_time.strftime('%Y%m%d %X.%f'),
            'transaction_time': self.trade_time.strftime('%Y%m%d %X.%f'),
            'msg_type': '3',
            'serial_no': serial_no,
            'open_close': open_close,
            'price': float(self.trade_price),
            'volume': int(self.trade_vol),
            'trade_price': float(self.trade_price),
            'trade_vol': int(self.trade_vol),
            'vol_remain': 0,
            'account': self.account,
            'direction': direction,
            'symbol': self.symbol,
            'vstrategy_id': self.vstrategy_id,
            'day_night': day_night,
            'cancel_time': '',
        }


class BackTestTradeLogs(ModelBase):
    __tablename__ = 'backtest_trade_logs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    trading_date = Column(DATE, nullable=False)
    calendar_time = Column(DATETIME(fsp=6), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    account = Column(VARCHAR(32), nullable=False)
    strategy_id = Column(BIGINT(unsigned=True))
    vstrategy_id = Column(BIGINT(unsigned=True))
    serial_no = Column(VARCHAR(32), default='')
    symbol = Column(VARCHAR(32), nullable=False)
    direction = Column(INTEGER, nullable=False)
    open_close = Column(INTEGER, nullable=False)
    trade_price = Column(DOUBLE, nullable=False)
    trade_vol = Column(INTEGER, nullable=False)
    fee = Column(DOUBLE, default=0)
    entrust_status = Column(VARCHAR(1), nullable=True)
    msg_type = Column(VARCHAR(1), nullable=True)


class StrategyPerfInput(object):
    @staticmethod
    def get_position_data(vs_ids, day_night='', trading_date=''):
        try:
            if day_night not in (0, 1):
                day_night = 0 if 9 <= datetime.datetime.now().hour <= 18 else 1
            last_day_night = {0: 'NIGHT', 1: 'DAY'}[day_night]
            if not vs_ids:
                return []
            if not trading_date:
                trading_date = engine.execute("""select max(settle_date) from vs_positions where daynight=%s""",
                                              last_day_night).fetchone()[0]
                if not trading_date:
                    return []
                trading_date = trading_date.strftime('%Y-%m-%d')
            sql_args = [trading_date, last_day_night] + vs_ids
            columns = [
                'vstrategy_id', 'symbol', 'settle_date', 'account', 'exchange', 'today_max_pos',
                'yest_long_pos', 'yest_long_avg_price', 'yest_short_pos', 'yest_short_avg_price',
                'today_long_pos', 'today_long_avg_price', 'today_short_pos', 'today_short_avg_price',
                'today_settle_price',
                'daynight', 'today_long_freeze_pos', 'today_short_freeze_pos', 'today_settle_price'
            ]
            columns_index = {col: c_index for c_index, col in enumerate(columns)}

            vs_position_detail_sql = """
                select %s from vs_positions
                where (today_long_pos > 0 or today_short_pos > 0)
                and settle_date=%%s and daynight=%%s and vstrategy_id in (%s)
            """ % (','.join(columns), ','.join(['%s'] * len(vs_ids)))

            row = engine.execute(vs_position_detail_sql, sql_args)

            data = []
            for r in row:
                d = {
                    'vstrategy_id': r[columns_index['vstrategy_id']],
                    'trade_date': str(r[columns_index['settle_date']]).replace('-', ''),
                    'day_night': {'DAY': 0, 'NIGHT': 1}.get(r[columns_index['daynight']], r[columns_index['daynight']]),
                    'symbol': r[columns_index['symbol']],
                    'exchange': r[columns_index['exchange']],
                    'cash': 0,
                    'account': r[columns_index['account']],
                    'today_max_pos': r[columns_index['today_max_pos']],
                    'yest_long_pos': r[columns_index['yest_long_pos']],
                    'yest_long_avg_price': float(r[columns_index['yest_long_avg_price']] or 0),
                    'yest_short_pos': r[columns_index['yest_short_pos']],
                    'yest_short_avg_price': float(r[columns_index['yest_short_avg_price']] or 0),
                    'today_long_pos': r[columns_index['today_long_pos']],
                    'today_long_avg_price': float(r[columns_index['today_long_avg_price']] or 0),
                    'today_short_pos': r[columns_index['today_short_pos']],
                    'today_short_avg_price': float(r[columns_index['today_short_avg_price']] or 0),
                    'currency': 'CNY',
                    'today_long_freeze_pos': float(r[columns_index['today_long_freeze_pos']] or 0),
                    'today_short_freeze_pos': float(r[columns_index['today_short_freeze_pos']] or 0),
                    'today_settle_price': float(r[columns_index['today_settle_price']] or 0),
                }
                data.append(d)
            return data
        except Exception as e:
            sentry.captureException()
            return []

    @staticmethod
    def get_latest_settle_day():
        """
        latest (settle_date, settle_day_night) from vs_base table
        :return:
        """
        sc = session()
        latest_settle_day = sc.query(
            VsBase.settle_date.label('trading_date'), VsBase.daynight.label('day_night')
        ).distinct().order_by(
            VsBase.settle_date.desc(),
            VsBase.daynight.asc()
        ).first()
        if not latest_settle_day:
            sc.close()
            return {
                'trading_date': '',
                'day_night': 0
            }
        res = {
            'trading_date': latest_settle_day.trading_date.strftime('%Y-%m-%d'),
            'day_night': 0 if latest_settle_day.day_night == 'DAY' else 1
        }
        sc.close()
        return res

    @staticmethod
    def get_trading_date_day_night():
        latest_settle_day = StrategyPerfInput.get_latest_settle_day()
        # day_night = 1 if latest_settle_day['day_night'] == 0 else 0
        day_night = int(latest_settle_day['day_night'] == 0)
        if day_night == 0:
            return parse(latest_settle_day['trading_date']).strftime('%Y%m%d'), day_night

        trading_date = Strategy.get_trading_date(
            hour=0, calendar_date=parse(latest_settle_day['trading_date']).strftime('%Y%m%d')
        )
        return parse(trading_date).strftime('%Y%m%d'), day_night


class ParentOrder(ModelBase):
    __tablename__ = 'parent_orders'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    parent_order_id = Column(VARCHAR(64), nullable=False)
    vstrategy_id = Column(BIGINT, nullable=False)
    symbol = Column(VARCHAR(128), nullable=False)
    parent_order_size = Column(INTEGER, nullable=False)
    limit_price = Column(DOUBLE, nullable=False)
    algorithm = Column(INTEGER, nullable=False)  # algorithm: 1-DMA; 2-VWAP; 3-TWAP;
    side = Column(INTEGER, nullable=False)  # 方向 1-buy, 2-sell
    start_time = Column(TIME, nullable=False)
    start_time_ms = Column(INTEGER, nullable=False)
    end_time = Column(TIME, nullable=False)
    end_time_ms = Column(INTEGER, nullable=False)
    timestamp = Column(TIME, nullable=False)
    timestamp_ms = Column(INTEGER, nullable=False)
    internal_date = Column(DATE, nullable=False)
    calendar_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    trading_date = Column(DATE, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())

    def brief(self):
        return {
            'parent_order_id': self.parent_order_id,
            'vstrategy_id': self.vstrategy_id,
            'symbol': self.symbol,
            'parent_order_size': self.parent_order_size,
            'limit_price': float(self.limit_price),
            'algorithm': self.algorithm,
            'start_time': int('%s%s' % (self.start_time.strftime('%H%M%S'), str(self.start_time_ms).zfill(3))),
            'end_time': int('%s%s' % (self.end_time.strftime('%H%M%S'), str(self.end_time_ms).zfill(3))),
            'side': self.side,
            'clock': int(time.mktime(time.strptime('%s %s' % (
                self.calendar_date.strftime('%Y-%m-%d'), self.timestamp.strftime('%H:%M:%S')), '%Y-%m-%d %H:%M:%S'))),
            'ms': self.timestamp_ms,
            'children_log': [],
            'day_night': self.day_night,
            'volume': self.parent_order_size,
            'direction': self.side,
            'business_volume': 0,
            'business_price': 0,
            'send_time': '',
            'remain_volume': 0,
            'transaction_time': '',
            'account': 0,
            'total_notional': 0,
            'cancel_time': '',
        }


class ChildrenOrder(ModelBase):
    __tablename__ = 'child_orders'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    child_order_id = Column(VARCHAR(64), nullable=False)
    vstrategy_id = Column(BIGINT, nullable=False)
    parent_order_id = Column(VARCHAR(64), nullable=False)
    child_order_size = Column(INTEGER, nullable=False)
    execution_price = Column(DOUBLE, nullable=False)
    order_type = Column(INTEGER, nullable=False)  # order_type: 1：PASSIVE; 2:AGGRESSIVE;
    indicator = Column(FLOAT, nullable=False)
    timestamp = Column(TIME, nullable=False)
    timestamp_ms = Column(INTEGER, nullable=False)
    internal_date = Column(DATE, nullable=False)
    calendar_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    trading_date = Column(DATE, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())

    def brief(self):
        return {
            'child_order_id': self.child_order_id,
            'vstrategy_id': self.vstrategy_id,
            'parent_order_id': self.parent_order_id,
            'child_order_size': self.child_order_size,
            'execution_price': float(self.execution_price),
            'order_type': self.order_type,
            'trade_type': self.order_type,
            'indicator': self.indicator,
            'clock': int(time.mktime(time.strptime('%s %s' % (
                self.calendar_date.strftime('%Y-%m-%d'), self.timestamp.strftime('%H:%M:%S')), '%Y-%m-%d %H:%M:%S'))),
            'ms': self.timestamp_ms,
            'trade_log': [],
            'day_night': self.day_night,
            'volume': 0,
            'business_volume': 0,
            'remain_volume': 0,
            'business_price': 0,
            'send_time': '',
            'transaction_time': '',
            'account': '',
            'symbol': '',
            'direction': '',
            'parent_serial_no': self.parent_order_id,
            'price': 0,
            'total_notional': 0,
            'cancel_time': '',
        }


class OnlineRequest(ModelBase):
    __tablename__ = 'online_request'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    portfolio_id = Column(ForeignKey('strategy_portfolio.id'))
    status = Column(INTEGER, default=0)
    action = Column(INTEGER, nullable=False)
    audit_time = Column(DATETIME(fsp=6), nullable=True, server_default=func.now(6), onupdate=func.now(6))
    audit_user = Column(VARCHAR(64), nullable=True)
    audit_comment = Column(VARCHAR(256), nullable=True)
    r_create_user = Column(VARCHAR(64), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())


class ResearchStrategyPortfolio(ModelBase):
    """
    个人的多个策略组合成一个策略供投资者使用
    """
    __tablename__ = 'research_strategy_portfolio'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=False)
    r_update_user_id = Column(INTEGER, nullable=True)
    name = Column(VARCHAR(128), nullable=False, unique=True)
    fund = Column(DOUBLE, nullable=False)
    description = Column(VARCHAR(255), nullable=True)
    status = Column(VARCHAR(4), nullable=True)
    weight_type = Column(INTEGER, nullable=False, default=1)
    is_public = Column(BOOLEAN, nullable=False, default=False)
    username = Column(VARCHAR(32), nullable=False)
    create_type = Column(INTEGER, nullable=False, default=0)  ##区分投资组合还是策略组合

    @staticmethod
    def portfolio_details(current_user, *args, **kwargs):
        create_type = kwargs.get('create_type', 0)
        semi_lives = kwargs.get('semi_lives', 'false')
        user_id = current_user['id']
        sc = session()
        details = sc.query(
            ResearchStrategyPortfolio, ResearchStrategyPortfolioDetail, Strategy, StrategyPortfolio
        ).join(
            ResearchStrategyPortfolioDetail,
            ResearchStrategyPortfolioDetail.portfolio_id == ResearchStrategyPortfolio.id
        ).join(
            Strategy, Strategy.id == ResearchStrategyPortfolioDetail.strategy_id
        ).join(
            StrategyPortfolio, StrategyPortfolio.research_portfolio_id == ResearchStrategyPortfolio.id, isouter=True
        ).filter(
            ResearchStrategyPortfolio.create_type == create_type,
        )
        if not current_user['is_superuser']:
            details = details.filter(
                or_(
                    ResearchStrategyPortfolio.r_create_user_id == user_id,
                    ResearchStrategyPortfolio.is_public == True,
                )
            )
        if kwargs.get('creator'):
            details = details.filter(ResearchStrategyPortfolio.username == kwargs.get('creator'))
        if kwargs.get('status'):
            details = details.filter(ResearchStrategyPortfolio.status == kwargs.get('status'))
        if kwargs.get('portfolio_id'):
            details = details.filter(ResearchStrategyPortfolio.id == int(kwargs.get('portfolio_id')))
        if semi_lives == 'true':
            all_info = BackTestConfig.get_strategies(user_id, consts.INVEST_GROUP)
            pf_ids = [item['strategy_id'] for item in all_info]
            details = details.filter(ResearchStrategyPortfolio.id.in_(pf_ids))

        data = {}
        for sp, sp_d, s, p in details:
            if sp.id not in data:
                if sp.status == 'LT' and p:
                    if p.status == 15:
                        sp_status = 'LT'  # 实盘
                    elif p.status == 16:
                        sp_status = 'Closed'  # 下架
                    else:
                        sp_status = 'UR'  # 审核中或审核未通过
                else:
                    sp_status = sp.status
                data[sp.id] = {
                    'id': sp.id,
                    'weight': sp.weight_type,
                    'name': sp.name,
                    'gross': float(sp.fund),
                    'status': sp_status,
                    'creator': sp.username,
                    'created_date': sp.r_create_time.strftime('%Y-%m-%d'),
                    'created_time': sp.r_create_time.strftime('%Y-%m-%d %H:%M:%S'),
                    'description': '',
                    'semi_live': BackTestConfig.is_wait_live(user_id, sp.id, consts.INVEST_GROUP),
                    'strategies': []
                }
            s_detail = s.report(user_id)
            if not s_detail:
                continue
            s_detail['weight'] = float(sp_d.strategy_weight)
            data[sp.id]['strategies'].append(s_detail)
        sc.close()
        return [d for d in sorted(data.values(), key=lambda d: d['id']) if d['strategies']]

    def can_delete(self, *args, **kwargs):
        if self.status == 'LT':
            return False
        return True

    def can_update(self, *args, **kwargs):
        if self.status == 'LT':
            return False
        return True


class ResearchStrategyPortfolioDetail(ModelBase):
    __tablename__ = 'research_strategy_portfolio_detail'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    portfolio_id = Column(INTEGER, nullable=False)
    strategy_id = Column(INTEGER, nullable=False)
    strategy_weight = Column(DOUBLE, nullable=True, default=0)
    group_id = Column(BIGINT, nullable=False, default=0)


class StrategyCheckWhiteList(ModelBase):
    __tablename__ = 'strategy_check_white_list'
    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(INTEGER, nullable=False)


class CashManagerBackTestConfig(ModelBase):
    __tablename__ = 'cash_manager_back_test_config'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    cash_manager_id = Column(INTEGER, nullable=False)
    strategy_id = Column(INTEGER, nullable=True)
    cm_group_id = Column(VARCHAR(64), nullable=True)
    cm_group_name = Column(VARCHAR(64), nullable=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=False)
    r_update_user_id = Column(INTEGER, nullable=True)


class CashManagerLiveConfig(ModelBase):
    __tablename__ = 'cash_manager_live_config'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    cash_manager_id = Column(INTEGER, nullable=False)
    vstrategy_id = Column(INTEGER, nullable=False)
    live_group_id = Column(INTEGER, nullable=False, default=0)
    cm_group_id = Column(VARCHAR(64), nullable=False)
    cm_group_name = Column(VARCHAR(64), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    r_create_user_id = Column(INTEGER, nullable=False)
    r_update_user_id = Column(INTEGER, nullable=True)


class CashManagerBackTestResult(ModelBase):
    __tablename__ = 'cash_manager_back_test_result'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    cash_manager_id = Column(INTEGER, nullable=False)
    cm_group_id = Column(VARCHAR(64), nullable=True)
    strategy_id = Column(INTEGER, nullable=False)
    trading_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    weight = Column(DOUBLE, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())


class CashManagerLiveResult(ModelBase):
    __tablename__ = 'cash_manager_live_result'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    cash_manager_id = Column(INTEGER, nullable=False)
    cm_group_id = Column(VARCHAR(64), nullable=True)
    strategy_id = Column(INTEGER, nullable=False)
    trading_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    weight = Column(DOUBLE, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())


class ClearPosition:

    def __init__(self, vs_id):
        self.vs_id = vs_id
        self.data_set = self.query_remain_pos()

    def query_remain_pos(self):
        vs_pos_sql = "select symbol_type, symbol, today_long_pos, today_short_pos from vs_positions where vstrategy_id=%d and (settle_date, daynight) =" \
                     "(select settle_date, daynight from vs_base where vstrategy_id=%d order by settle_date desc, daynight asc LIMIT 0, 1)" % (
                         self.vs_id, self.vs_id)
        data_set = pd.read_sql_query(vs_pos_sql, engine, index_col='symbol')
        data_set = data_set[data_set.today_long_pos + data_set.today_short_pos > 0]
        return data_set

    def set_portfolio(self, sc, pf_id):
        vs_objs = sc.query(VStrategies).filter(VStrategies.portfolio_id == pf_id).all()
        for obj in vs_objs:
            if obj.status == consts.STRATEGY_LIVE:
                return
        pf_obj = sc.query(StrategyPortfolio).filter(StrategyPortfolio.id == pf_id).first()
        pf_obj.status = consts.STRATEGY_OFF_SHELF
        sc.commit()

    def gen_csv_file(self, data_set, fp_path, is_stock, way=None, duration='ALL'):
        if not data_set.empty:
            if is_stock:
                algo, start, end = 'vwap', '9:30', '14:55'
                if way is not None:
                    algo = way
                if duration != 'ALL':
                    start, end = duration.split('|')
                add_cols = [('weight', 0), ('size', 0), ('limit_price', ''), ('algo', algo), ('start', start),
                            ('end', end)]
            else:
                algo, start, end = 'dma', '9:00', '23:59'
                if way is not None:
                    algo = way
                if duration != 'ALL':
                    start, end = duration.split('|')
                add_cols = [('weight', 0), ('size', 0), ('limit_price', ''), ('algo', algo), ('start', start),
                            ('end', end)]
            data_set = data_set.drop(['symbol_type', 'today_long_pos', 'today_short_pos'], axis=1)
            for item in add_cols:
                data_set[item[0]] = item[1]
            data_set.to_csv(fp_path)

    def gen_csv_file_v2(self, data_set, fp_path, way=None, duration='ALL'):
        columns = ['symbol', 'weight', 'size', 'limit_price', 'algo', 'start', 'end']
        data_dict = data_set.T.to_dict()
        ls = []
        for symbol, d in data_dict.items():
            if d['symbol_type'] == 'Stock':
                algo, start, end = 'vwap', '9:30', '14:55'
                if way is not None:
                    algo = way
                if duration != 'ALL':
                    start, end = duration.split('|')
            else:
                algo, start, end = 'dma', '9:00', '23:59'
                if way is not None:
                    algo, start, end = way, '9:00', '14:55'
                if duration != 'ALL':
                    start, end = duration.split('|')
            ls.append({'symbol': symbol, 'weight': 0.0, 'size': 0, 'limit_price': None, 'algo': algo, 'start': start,
                       'end': end})
        out_set = pd.DataFrame(ls, columns=columns)
        out_set.to_csv(fp_path, index=False)

    # def generate_order_list(self, fp_path):
    #     need_data = self.data_set[self.data_set.symbol_type == 'Stock']
    #     self.gen_csv_file(need_data, fp_path, True)
    #     need_data = self.data_set[self.data_set.symbol_type != 'Stock']
    #     self.gen_csv_file(need_data, fp_path, False)

    def generate_order_list_v2(self, fp_path):
        sc = session()
        try:
            close_detail = sc.query(ClosePositionDetail).filter(ClosePositionDetail.vsid == self.vs_id).first()
            if close_detail:
                close_way = close_detail.close_way.lower().replace('my_', '')
                duration = close_detail.close_execute_duration
            else:
                close_way = None
                duration = 'ALL'
            self.gen_csv_file_v2(self.data_set, fp_path, way=close_way, duration=duration)
        except Exception as e:
            sentry.captureException()
            sc.close()
            return False

        sc.close()
        return True

    def check_position(self):
        total_pos = self.data_set.today_long_pos.sum() + self.data_set.today_short_pos.sum()
        return total_pos > 0

    def check_position_and_off_line(self):
        sc = session()
        total_pos = self.data_set.today_long_pos.sum() + self.data_set.today_short_pos.sum()
        if total_pos == 0:
            vs_obj = sc.query(VStrategies).filter(VStrategies.id == self.vs_id).first()
            vs_obj.closing_out = consts.STRATEGY_CLOSED_DONE
            vs_obj.status = consts.STRATEGY_OFF_SHELF
            sc.commit()
            self.set_portfolio(sc, vs_obj.portfolio_id)
            try:
                from cron.strategy_upload_task import notify_vs_off_line
                notify_vs_off_line(self.vs_id)
                url = 'http://192.168.10.100/api/v1/shannon/operation/deploy_offline/%s' % self.vs_id
                r = requests.put(url)
            except Exception as e:
                sentry.captureException()
        sc.close()
        return total_pos > 0


class StrategyUserRelation(object):

    @staticmethod
    def is_creator(strategy_id, uid):
        sc = session()
        _count = sc.query(Strategy).filter(Strategy.id == strategy_id, Strategy.r_create_user_id == uid).count()
        sc.close()

        return _count > 0

    @staticmethod
    def is_investor(strategy_id, uid):
        sc = session()

        sid = [strategy_id]
        query = sc.query(Strategy).filter(Strategy.id == strategy_id)
        for row in query:
            if row.node == 'group':
                _detail = row.group_detail
                for s_id, weight in _detail.items():
                    sid.append(s_id)

        query = sc.query(VStrategies).join(StrategyPortfolio, VStrategies.portfolio_id == StrategyPortfolio.id).filter(
            VStrategies.strategy_id.in_(sid), StrategyPortfolio.r_create_user_id == uid)
        _count = query.count()
        sc.close()

        return _count > 0


class ClosePositionDetail(ModelBase):
    __tablename__ = 'close_position_detail'

    vsid = Column(BigInteger, primary_key=True, server_default=text("'0'"))
    pf_id = Column(BigInteger, nullable=False, server_default=text("'0'"))
    close_way = Column(String(128), nullable=False, server_default=text("''"))
    close_execute_duration = Column(String(128), nullable=False, server_default=text("''"))
    close_status = Column(String(128), nullable=False, server_default=text("''"))
    ctime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    utime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))


class StrategyRemark(ModelBase):
    __tablename__ = 'strategy_remark'

    remark_id = Column(BigInteger, primary_key=True)
    sid = Column(BigInteger, nullable=False, index=True, server_default=text("'0'"))
    uid = Column(String(128), nullable=False, server_default=text("''"))
    uname = Column(String(128), nullable=False, server_default=text("''"))
    remark = Column(String(5120), nullable=False, server_default=text("''"))
    links = Column(JSON)
    vids = Column(String(1024), nullable=False, server_default=text("''"))
    ctime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    utime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))


class StrategyLiveRunRecords(ModelBase):
    __tablename__ = 'strategy_live_run_records'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(BIGINT(unsigned=True), nullable=False)
    vstrategy_id = Column(BIGINT(unsigned=True), nullable=False)
    host = Column(VARCHAR(64), nullable=False)
    deploy_path = Column(VARCHAR(256), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())


class StrategyOrdersRejected(ModelBase):
    __tablename__ = 'strategy_orders_rejected'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    calendar_date = Column(DATE, nullable=False)
    calendar_time = Column(TIME, nullable=False)
    calendar_microsec = Column(INTEGER, nullable=True)
    trading_date = Column(DATE, nullable=False)
    internal_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False)
    vstrategy_id = Column(BIGINT(unsigned=True), nullable=False)
    serial_no = Column(VARCHAR(32), nullable=False)
    cancel_serial_no = Column(VARCHAR(32), nullable=False)
    exchange = Column(VARCHAR(10), nullable=False)
    symbol = Column(VARCHAR(32), nullable=False)
    # 0:buy 1:sell
    direction = Column(INTEGER, nullable=False)
    # 0:open 1:close 2:close_today 3:close_yesterday
    open_close = Column(INTEGER, nullable=False)
    price = Column(DOUBLE, nullable=False)
    volume = Column(INTEGER, nullable=False)
    # 0:Limit Order  1:Market Order
    order_type = Column(INTEGER, nullable=False)
    # 0:SPECULATOR  1:EDGER  2:ARBITRAGEURS
    investor_type = Column(INTEGER, nullable=False)
    # 0:norma 1:FAK 2:IOC 3:FOK 4:GTD 5:GTC
    time_in_force = Column(INTEGER, nullable=False)
    error_no = Column(INTEGER, nullable=False)
    error_msg = Column(VARCHAR(512), nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'calendar_date': self.calendar_date,
            'calendar_time': self.calendar_time,
            'calendar_microsec': self.calendar_microsec,
            'trading_date': self.trading_date,
            'day_night': self.day_night,
            'vstrategy_id': self.vstrategy_id,
            'serial_no': self.serial_no,
            'cancel_serial_no': self.cancel_serial_no,
            'exchange': self.exchange,
            'symbol': self.symbol,
            'direction': self.direction,
            'open_close': self.open_close,
            'price': self.price,
            'volume': self.volume,
            'order_type': self.order_type,
            'investor_type': self.investor_type,
            'time_in_force': self.time_in_force,
            'error_no': self.error_no,
            'error_msg': self.error_msg,
        }


class Quantamentals(ModelBase):
    __tablename__ = 'quantamentals'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    user_id = Column(INTEGER, nullable=False)
    product = Column(VARCHAR(32), nullable=False)
    papertrading_date = Column(VARCHAR(16), nullable=False)
    q_strat_id = Column(INTEGER, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())

    @property
    def detail(self):
        sc = session()
        q_details = sc.query(QuantamentalDetails).filter(QuantamentalDetails.quantamental_id == self.id)
        res = [d.to_dict() for d in q_details]
        sc.close()
        return res

    def to_dict(self):
        return {
            'product': self.product,
            'papertrading_date': self.papertrading_date,
            'detail': self.detail or [],
        }


class QuantamentalDetails(ModelBase):
    __tablename__ = 'quantamental_details'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    quantamental_id = Column(BIGINT(unsigned=True), nullable=False)
    date = Column(VARCHAR(16), nullable=False)
    direction = Column(INTEGER, nullable=False, default=0)
    supply_predict = Column(INTEGER)
    demand_predict = Column(INTEGER)
    analyst_predict = Column(INTEGER)
    update = Column(VARCHAR(16), nullable=False)
    description = Column(VARCHAR(512), nullable=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())

    def to_dict(self):
        return {
            'date': self.date,
            'direction': self.direction,
            'supply_predict': self.supply_predict,
            'demand_predict': self.demand_predict,
            'analyst_predict': self.analyst_predict,
            'update': self.update,
            'description': self.description or '',
        }

    def to_detail(self):
        return {
            'date': self.date,
            'direction': self.direction,
            'update': self.update,
        }


class OTCSpotCompanyGroups(ModelBase):
    __tablename__ = 'otc_spot_company_groups'

    id = Column(INTEGER(unsigned=True), primary_key=True)
    company_id = Column(INTEGER(unsigned=True), nullable=False)
    group_id = Column(INTEGER(unsigned=True), nullable=False, unique=True)


class PredictCustomColumnNames(ModelBase):
    __tablename__ = 'predict_custom_column_names'

    id = Column(INTEGER(unsigned=True), primary_key=True)
    column_name = Column(VARCHAR(32), nullable=False)
    company_id = Column(INTEGER(unsigned=True), nullable=False)
    create_user_id = Column(BIGINT(unsigned=True))
    update_user_id = Column(BIGINT(unsigned=True))
    create_time = Column(DATETIME, nullable=False, server_default=func.now())
    update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())

    column_values = relationship("PredictCustomColumnValues", backref='column_name')

    def to_dict(self):
        return {
            'column_id': self.id,
            'column_name': self.column_name,
        }


class PredictCustomColumnValues(ModelBase):
    __tablename__ = 'predict_custom_column_values'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    date = Column(VARCHAR(16), nullable=False)
    column_id = Column(INTEGER(unsigned=True),
                       ForeignKey('predict_custom_column_names.id', onupdate="CASCADE", ondelete="CASCADE"))
    value = Column(VARCHAR(32), nullable=False)
    company_id = Column(INTEGER(unsigned=True), nullable=False)
    create_user_id = Column(BIGINT(unsigned=True))
    update_user_id = Column(BIGINT(unsigned=True))
    create_time = Column(DATETIME, nullable=False, server_default=func.now())
    update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())


class TuringLiveAccounts(ModelBase):
    __tablename__ = 'turing_live_accounts'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)
    exchange = Column(VARCHAR(255), nullable=True)
    description = Column(VARCHAR(255), nullable=True)
    create_user_id = Column(BIGINT(unsigned=True))
    update_user_id = Column(BIGINT(unsigned=True))
    create_time = Column(DATETIME, nullable=False, server_default=func.now())
    update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())


class TuringCtpAccounts(ModelBase):
    __tablename__ = 'turing_ctp_accounts'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(32), nullable=False, unique=True)
    exchange = Column(VARCHAR(255), nullable=True)
    description = Column(VARCHAR(255), nullable=True)
    other_name = Column(VARCHAR(32), nullable=True)
    create_user_id = Column(BIGINT(unsigned=True))
    update_user_id = Column(BIGINT(unsigned=True))
    create_time = Column(DATETIME, nullable=False, server_default=func.now())
    update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())


class TuringServers(ModelBase):
    __tablename__ = 'turing_servers'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    ip = Column(VARCHAR(45), nullable=False, unique=True)
    cpu_freq = Column(INTEGER, nullable=True)
    broker_delay_threshold = Column(INTEGER, nullable=True)


class StockHedgeVs(ModelBase):
    """
    实盘alpha策略和对冲策略对应关系
    """
    __tablename__ = 'stock_hedge_vs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    stock_vs_id = Column(BIGINT(unsigned=True))  # 多头vs_id
    future_vs_id = Column(BIGINT(unsigned=True))  # 空头vs_id
    valid = Column(BOOLEAN, default=True, nullable=True)


class StrategyParameter(ModelBase):
    __tablename__ = 'strategy_parameter'

    strategy_id = Column(BIGINT, primary_key=True, nullable=False)
    date = Column(BIGINT, primary_key=True, nullable=False)
    para_structure = Column(JSON, nullable=False)
    para_list = Column(JSON, nullable=False)
    ctime = Column(DATETIME, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    utime = Column(DATETIME, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))


class StockPortfolioOptimizationVersion(ModelBase):
    """
    组合优化配置记录
    """
    __tablename__ = 'stock_portfolio_optimization_version'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(INTEGER, nullable=False)
    name = Column(VARCHAR(255), nullable=False, unique=True)
    value = Column(VARCHAR(255), nullable=False)
    description = Column(VARCHAR(255), nullable=False)  # TODO: Check if description is identical to value.
    paras = Column(JSON, nullable=True)  # 配置参数
    r_create_user_id = Column(BIGINT(unsigned=True), nullable=True)
    r_update_user_id = Column(BIGINT(unsigned=True), nullable=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())

    @staticmethod
    def publish(version_path):
        """
        发布到实盘
        """
        sc = session()
        hour = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        version = 'v%s' % hour
        name = 'stock_risk_%s' % version
        version = name
        tar_filename = os.path.join(config.media, 'portfolio_optimization_so/%s.tar.bz2' % name)
        so_file_path = os.path.join(config.media, version_path)
        so_files = ' '.join(os.listdir(so_file_path))
        tar_cmd = """tar cjf {tar_filename} -C {so_file_path} {so_files}""".format(
            tar_filename=tar_filename,
            so_file_path=so_file_path,
            so_files=so_files,
        )
        os.system(tar_cmd)
        sql = """INSERT INTO `programs` (`name`, `type_id`, `filepath`, `version`) VALUES ('{name}', {type_id}, '{filepath}', '{version}');"""

        sql = sql.format(name=name, type_id=11, filepath=tar_filename, version=version)
        sc.execute(sql)
        sc.commit()
        sc.close()
        notify_operation_wechat('股票风险模块已发布新版本(%s)，请尽快更新到实盘' % name)
        return True

    @staticmethod
    def get_paras(v):
        sc = session()
        o = sc.query(StockPortfolioOptimizationVersion).filter(
            StockPortfolioOptimizationVersion.value == v
        ).first()
        if not (o and o.paras):
            sc.close()
            return v
        paras = str(base64.b64encode(json.dumps(o.paras).encode()), 'utf8')
        sc.close()
        return paras


class StockSmartExecutionVersion(ModelBase):
    """
    记录交易执行算法版本记录
    """
    __tablename__ = 'stock_smart_execution_version'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    strategy_id = Column(INTEGER, nullable=False)
    name = Column(VARCHAR(255), nullable=False, unique=True)
    value = Column(VARCHAR(255), nullable=False)
    description = Column(VARCHAR(255), nullable=False)
    r_create_user_id = Column(BIGINT(unsigned=True), nullable=True)
    r_update_user_id = Column(BIGINT(unsigned=True), nullable=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    valid = Column(BOOLEAN, default=True, nullable=True)

    def dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "value": self.value,
            "description": self.description,
            "valid": self.valid
        }

    @staticmethod
    def publish(exe_version_id):
        """
        发布到实盘
        """
        sc = session()

        exe_version = sc.query(StockSmartExecutionVersion).filter(
            StockSmartExecutionVersion.id == exe_version_id
        ).first()

        s_id = exe_version.strategy_id

        s = sc.query(Strategy).filter(
            Strategy.id == s_id
        ).first()

        if not (s and s.strategy_type == '24'):
            sc.close()
            raise ValueError('strategy(id=%s) is not stock smart execution' % s_id)

        file_path = s.strategy_upload_file['abs_path']

        stock_smart_execution_so = 'smart_execution_%s.so' % exe_version.value

        shutil.copy(file_path, os.path.join(config.media, 'stock_smart_execution/%s' % stock_smart_execution_so))

        hour = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        version = 'v%s' % hour
        name = '%s_%s' % (exe_version.value, version)
        version = name
        tar_filename = os.path.join(config.media, 'stock_smart_execution/%s.tar.bz2' % name)

        tar_cmd = """tar cjf {tar_filename} -C {so_file_path} {stock_smart_execution_so}""".format(
            tar_filename=tar_filename,
            so_file_path=os.path.join(config.media, 'stock_smart_execution'),
            stock_smart_execution_so=stock_smart_execution_so
        )
        os.system(tar_cmd)
        sql = """INSERT INTO `programs` (`name`, `type_id`, `filepath`, `version`) 
        VALUES ('{name}', {type_id}, '{filepath}', '{version}');""".format(
            name=name, type_id=11, filepath=tar_filename, version=version)
        sc.execute(sql)
        sc.commit()
        sc.close()
        notify_operation_wechat('股票算法交易模块已发布新版本(%s)，请尽快更新到实盘' % name)
        return True


class TradeModel(ModelBase):
    """
    成交模型
    """
    __tablename__ = 'trade_model'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(255), nullable=False, unique=True)
    value = Column(VARCHAR(255), nullable=False)
    description = Column(VARCHAR(255), nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    valid = Column(BOOLEAN, default=True, nullable=False)

    def dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "value": self.value,
            "description": self.description,
            "valid": self.valid
        }


class TradeModelStockSmartExecutionRelation(ModelBase):
    """
    成交模型与股票算法交易模块关系
    """
    __tablename__ = 'trade_model_stock_smart_execution_relation'

    id = Column(INTEGER, primary_key=True)
    trade_model_id = Column(BIGINT(unsigned=True), index=True, nullable=False)
    stock_smart_execution_id = Column(BIGINT(unsigned=True), index=True, nullable=False)


class TuringPositionLogs(ModelBase):
    __tablename__ = 'turing_position_logs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    account = Column(VARCHAR(64), nullable=False)
    vstrategy_id = Column(INTEGER, nullable=False, default=0)
    symbol = Column(VARCHAR(16), nullable=False)
    td_long_pos = Column(INTEGER, nullable=False)
    td_long_avg_price = Column(FLOAT, nullable=False)
    td_short_pos = Column(INTEGER, nullable=False)
    td_short_avg_price = Column(FLOAT, nullable=False)
    yd_long_pos = Column(INTEGER, nullable=False)
    yd_long_avg_price = Column(FLOAT, nullable=False)
    yd_short_pos = Column(INTEGER, nullable=False)
    yd_short_avg_price = Column(FLOAT, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())


class UserInfo(ModelBase):
    __tablename__ = 'user_info'

    user_id = Column(BIGINT, primary_key=True)
    user_passwd = Column(VARCHAR(64), nullable=False)
    server_ip = Column(VARCHAR(32), nullable=False)
    server_port = Column(INTEGER, nullable=False)
    broker_id = Column(INTEGER, nullable=False)
    request_cycle = Column(INTEGER, nullable=False)


class SymbolList(ModelBase):
    __tablename__ = 'symbol_list'

    symbol_id = Column(BIGINT, primary_key=True)
    symbol = Column(VARCHAR(64), nullable=False)


class SymbolMargin(ModelBase):
    __tablename__ = 'symbol_margin'

    timestamp = Column(BIGINT, primary_key=True)
    symbol = Column(VARCHAR(64), primary_key=True)
    hedge_flag = Column(INTEGER, nullable=False)
    long_margin_ratio = Column(DOUBLE, nullable=False)
    short_margin_ratio = Column(DOUBLE, nullable=False)


class AccountInfo(ModelBase):
    __tablename__ = 'account_info'

    user_id = Column(BIGINT, nullable=False, primary_key=True)
    timestamp = Column(BIGINT, nullable=False, primary_key=True)
    PreDeposit = Column(DOUBLE, nullable=False)  # 上次存款额
    PreBalance = Column(DOUBLE, nullable=False)  # 上次结算准备金
    Deposit = Column(DOUBLE, nullable=False)  # 入金金额
    Withdraw = Column(DOUBLE, nullable=False)  # 出金金额
    FrozenMargin = Column(DOUBLE, nullable=False)  # 冻结的保证金
    FrozenCash = Column(DOUBLE, nullable=False)  # 冻结的资金
    FrozenCommission = Column(DOUBLE, nullable=False)  # 冻结的手续费
    CurrMargin = Column(DOUBLE, nullable=False)  # 当前保证金总额
    Balance = Column(DOUBLE, nullable=False)  # 期货结算准备金
    Available = Column(DOUBLE, nullable=False)  # 可用资金
    WithdrawQuota = Column(DOUBLE, nullable=False)  # 可取资金
    ExchangeMargin = Column(DOUBLE, nullable=False)  # 交易所保证金
    Commission = Column(DOUBLE, nullable=False)  # 手续费
    CloseProfit = Column(DOUBLE, nullable=False)  # 平仓盈亏
    PositionProfit = Column(DOUBLE, nullable=False)  # 持仓盈亏

    @staticmethod
    def stampToTime(stamp):
        datatime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(float(str(stamp)[0:10])))
        # datatime = datatime+'.'+str(stamp)[10:]
        return datatime

    def to_dict(self):
        dynamic_interest = self.Available + self.CurrMargin
        if dynamic_interest == 0:
            risk = 0
        else:
            risk = self.CurrMargin / dynamic_interest
        return {
            'user_id': self.user_id,
            'datetime': self.stampToTime(self.timestamp),
            'curr_margin': round(float(self.CurrMargin), 2),
            'available': round(float(self.Available), 2),
            'commission': round(float(self.Commission), 2),
            'close_profit': round(float(self.CloseProfit), 2),
            'position_profit': round(float(self.PositionProfit), 2),
            'pre_balance': round(float(self.PreBalance), 2),
            'risk': round(float(risk), 4),
            'dynamic_interest': round(float(dynamic_interest), 2),
        }


class DIMPreConfs(ModelBase):
    __tablename__ = 'dim_pre_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
    type = Column(INTEGER, nullable=False, default=1)  # 1:product 2:test
    internal_date = Column(VARCHAR(16), nullable=False)
    day_night = Column(INTEGER, nullable=False)
    exchange = Column(VARCHAR(16), nullable=False)
    product = Column(VARCHAR(16), nullable=False)
    symbol = Column(VARCHAR(16), nullable=False)
    alphamixer = Column(VARCHAR(256), nullable=False)
    strategy = Column(VARCHAR(256), nullable=False)
    max_vol = Column(INTEGER, nullable=False)
    limit_vol = Column(INTEGER, nullable=False)
    single_max_vol = Column(INTEGER, nullable=False, default=0)
    ev_dim = Column(VARCHAR(256), nullable=False)
    ev_data = Column(VARCHAR(256), nullable=False)
    account = Column(VARCHAR(256), nullable=True)
    fixed = Column(BOOLEAN, nullable=False)
    uid = Column(VARCHAR(256), nullable=False)
    fake_account = Column(VARCHAR(256), nullable=True)
    account_id = Column(INTEGER, nullable=True)
    quote_lv = Column(INTEGER, nullable=True)
    v_account_id = Column(INTEGER, nullable=True)
    status = Column(INTEGER, nullable=False, default=0)  # 0: standby; 1: in-live


class CtpAccountPos(ModelBase):
    __tablename__ = 'ctp_account_pos'

    user_id = Column(BIGINT, nullable=False, primary_key=True)
    timestamp = Column(BIGINT, nullable=False, primary_key=True)
    symbol = Column(VARCHAR(64), nullable=False, primary_key=True)
    type = Column(BOOLEAN, nullable=False, primary_key=True)
    position = Column(INTEGER, nullable=False)


class LiveQuoteServer(ModelBase):
    __tablename__ = 'live_quote_server'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    business = Column(VARCHAR(32), nullable=False)
    server = Column(VARCHAR(32), nullable=False)


class VsbBackTestPara(ModelBase):
    __tablename__ = 'vs_back_test_para'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vstrategy_id = Column(BIGINT, nullable=False)
    trading_date = Column(VARCHAR(16), nullable=False)
    use_last_live_position = Column(BOOLEAN, nullable=True, default=False)

    __table_args__ = (
        UniqueConstraint('vstrategy_id', 'trading_date', name='ix_vs_id_trading_date'),
    )


# class BackTestT0Subscriber(ModelBase):
#     __tablename__ = 'back_test_t0_subscriber'
#
#     id = Column(BIGINT(unsigned=True), primary_key=True)
#     t0_s_id = Column(INTEGER, nullable=False, index=True)
#     alpha_s_id = Column(INTEGER, nullable=False)
#     r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
#     r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())
#     r_create_user_id = Column(INTEGER, nullable=True)
#     r_update_user_id = Column(INTEGER, nullable=True)


class StrategyEventTrack(ModelBase):
    __tablename__ = 'strategy_event_track'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    s_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False, default=0)
    event = Column(VARCHAR(48), nullable=False)  # `strategy_upload.strategy_upload.constant.StrategyEventTrackConstant`
    task_id = Column(VARCHAR(64), nullable=True)
    status = Column(INTEGER, nullable=False, default=0)
    done_time = Column(DATETIME, nullable=False, server_default=func.now())
    detail = Column(JSON, nullable=True)

    @staticmethod
    def add_strategy_event(s_id, trading_date, day_night, event, task_id='', status=0, detail=None):
        """
        record strategy event
        """
        sc = session()
        try:
            record = StrategyEventTrack(
                s_id=s_id,
                trading_date=trading_date,
                day_night=day_night,
                event=event,
                task_id=task_id,
                status=status,
                detail=detail
            )
            sc.add(record)
            sc.commit()
        except Exception as e:
            sentry.captureException()
            sc.close()
            return False
        sc.close()
        return True


class VsEventTrack(ModelBase):
    __tablename__ = 'vs_event_track'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vs_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False)
    day_night = Column(INTEGER, nullable=False, default=0)
    event = Column(VARCHAR(48), nullable=False)
    status = Column(INTEGER, nullable=False, default=0)
    done_time = Column(DATETIME, nullable=False, server_default=func.now())
    detail = Column(JSON, nullable=True)

    @staticmethod
    def add_vs_event(vs_id, trading_date, day_night, event, status=0, detail=None):
        try:
            with session_context() as sc:
                record = VsEventTrack(
                    vs_id=vs_id,
                    trading_date=trading_date,
                    day_night=day_night,
                    event=event,
                    status=status,
                    detail=detail
                )
                sc.add(record)
        except Exception as e:
            sentry.captureException()
            return False

        return True

#-*-coding:utf-8-*-


from config import config
from qpython import qconnection
from sqlalchemy.sql import func
from db import session, engine
import numpy as np, pandas as pd
from service.back_test.models import ResearchStrategyPortfolioDetail, Strategy


def get_group_list(group_id, sc):
    strat_info = {}
    relation = lambda group: sc.query(ResearchStrategyPortfolioDetail).filter(ResearchStrategyPortfolioDetail.portfolio_id == group).all()
    pf_detail = relation(group_id)
    for item in pf_detail:
        if item.group_id > 0:
            sub_detail = relation(item.group_id)
            for sub in sub_detail:
                strat_info[sub.strategy_id] = float(item.strategy_weight * sub.strategy_weight)
        else:
            strat_info[item.strategy_id] = float(item.strategy_weight)
    return strat_info


def max_paper_trading_date(group_id, sc):
    strat_info = get_group_list(group_id, sc)
    find_strat = sc.query(func.max(Strategy.paper_trading_date)).filter(Strategy.id.in_(strat_info.keys())).first()
    trade_date = find_strat[0]
    return trade_date

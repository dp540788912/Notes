# -*-coding:utf-8-*-

import os
import datetime
import simplejson

from dateutil.parser import parse
from sqlalchemy import func, distinct
from sqlalchemy import Column
from sqlalchemy.dialects.mysql import BIGINT, INTEGER, DOUBLE, DATE

from my.data import meta_api, quote
from my.data.config import NpqData
from my.data.tradelist_api import get_tables

from db import ModelBase, session, session_context
from config import config
from utils import MyEncoder, get_cache, set_cache
from extensions import sentry
from models.strategy import VsT0Relation


class VsAlphaPositionValue(ModelBase):
    __tablename__ = 'vs_alpha_position_factor'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    vs_id = Column(INTEGER, nullable=False, index=True)
    trading_date = Column(DATE, nullable=False)
    position = Column(DOUBLE, nullable=False, default=0)


def get_daily_stock_price(trading_date):
    data = get_tables(trading_date, NpqData.ASHARE_EOD)
    res = {}
    for d in data:
        sym = str(d['SYMBOL'], 'utf-8').split('.')[0].lower()
        res[sym] = d['S_DQ_OPEN']
    return res


def get_t0_daily_position(s_id, date, mode="new"):
    """
    get t0 strategy daily position
    :param s_id: int, strategy id
    :param date: trading date, '%Y%m%d'
    :param mode:    "add" means sum all
                    "new" means sum all the latest volumes
                    "max" means sum all the largest volumes
                    "min" means sum all the smallest volumes
    :return: sum of all the market value
    """
    try:
        pos_np = quote.position(date, 281, s_id, 0, 0)['quote']
        prices = get_daily_stock_price(date)
        if mode not in ("add", "new", "max", "min"):
            mode = "new"

        if mode == "new":
            total = 0
            symbols = set()
            for r in pos_np[::-1]:
                sym = str(r['ticker'], 'utf-8')
                if sym in symbols:
                    continue
                total += (r['volume'] * prices.get(sym, 0))
                symbols.add(sym)
            return total
        elif mode == "add":
            total = 0
            for r in pos_np:
                sym = str(r['ticker'], 'utf-8')
                total += (r['volume'] * prices.get(sym, 0))
            return total
        elif mode == "max":
            total = 0
            symbols = {}
            for r in pos_np:
                sym = str(r['ticker'], 'utf-8')
                if sym in symbols:
                    if symbols[sym] < r['volume']:
                        symbols[sym] = r['volume']
                else:
                    symbols[sym] = r['volume']
            for sym in symbols:
                total += (symbols[sym] * prices.get(sym, 0))
            return total
        elif mode == "min":
            total = 0
            symbols = {}
            for r in pos_np:
                sym = str(r['ticker'], 'utf-8')
                if sym in symbols:
                    if symbols[sym] > r['volume']:
                        symbols[sym] = r['volume']
                else:
                    symbols[sym] = r['volume']
            for sym in symbols:
                total += (symbols[sym] * prices.get(sym, 0))
            return total
        else:
            return 0
    except Exception as _:
        return 0


def get_t0_position(s_id, cache=True, **kwargs):
    """
    get t0 strategy daily position
    :param s_id: int, strategy id
    :param cache:
    :param kwargs:
    :return: {'20200522': 0}
    """
    file_path = os.path.join(config.media, 't0_position', '%s.json' % s_id)
    if cache:
        try:
            f = open(file_path, 'r')
            res = simplejson.load(f)
            f.close()
            return res
        except Exception as e:
            pass

    start_date = kwargs.get('start_date', '')
    if not start_date:
        start_date = '20160101'

    end_date = datetime.datetime.now().strftime('%Y%m%d')
    # 这里获取从start_date到end_date的交易日序列
    days = [d.replace('-', '') for d in meta_api.get_trading_date_range(int(start_date), int(end_date), 'SSE')]

    mode = kwargs.get('mode', '')
    res = {}
    for i, d in enumerate(days):
        res[d] = get_t0_daily_position(s_id, d, mode=mode)

    if res:
        f = open(file_path, 'w')
        simplejson.dump(res, f, cls=MyEncoder, ignore_nan=True)
        f.close()

    return res


# def vs_get_t0_alpha_position(t0_vs_id, cache=True):
#     from service.stock_factor.models import T0SubscriberHistory
#
#     sc = session()
#     alpha_s = sc.query(T0SubscriberHistory.alpha_vs_id).filter(
#         T0SubscriberHistory.t0_vs_id == t0_vs_id
#     )
#     alpha_s = [r[0] for r in alpha_s]
#     sc.close()
#
#     if t0_vs_id == 1570:
#         alpha_s = [1571, 1698, 1707]
#     elif t0_vs_id == 1661:
#         alpha_s = [1659, 1710]
#     elif t0_vs_id == 1682:
#         alpha_s = [1681, 1708]
#     else:
#         pass
#
#     res = {}
#     for alpha_s_id in alpha_s:
#         alpha_s_position = vs_get_t0_position(alpha_s_id, cache=cache)
#         for k, v in alpha_s_position.items():
#             if k == 'time':
#                 continue
#             res[k] = res.get(k, 0) + v
#
#     return res


def vs_get_t0_alpha_position(t0_vs_id, cache=True):
    res = dict()
    with session_context() as sc:
        t0_records = sc.query(VsT0Relation).filter(
            VsT0Relation.vs_id == t0_vs_id
        ).all()
        alpha_vs_ids = [r.link_vs_id for r in t0_records]

    for alpha_vs_id in alpha_vs_ids:
        alpha_position = vs_get_t0_position(alpha_vs_id=alpha_vs_id, cache=cache)
        for k, v in alpha_position.items():
            res[k] = res.get(k, 0) + v

    return res


def vs_get_t0_position(alpha_vs_id, cache=True):
    cache_key = 'vs_alpha_position_%s' % alpha_vs_id

    if cache:
        data = get_cache(cache_key)
        if data:
            return data

    data = {}
    sc = session()
    for r in sc.query(VsAlphaPositionValue).filter(VsAlphaPositionValue.vs_id == alpha_vs_id):
        data[r.trading_date.strftime('%Y%m%d')] = float(r.position)
    sc.close()

    if data:
        set_cache(cache_key, data, 14400)

    return data


# def update_vs_t0_alpha_position():
#     from service.stock_factor.models import T0SubscriberHistory
#     sc = session()
#     for alpha_vs_id in sc.query(T0SubscriberHistory.alpha_vs_id).distinct():
#         try:
#             update_vs_alpha_position(alpha_vs_id[0])
#         except Exception as e:
#             sentry.captureException()
#     sc.close()
#     return True


def update_vs_t0_alpha_position():
    with session_context() as sc:
        t0_records = sc.query(VsT0Relation).all()
        alpha_vs_ids = list(set([r.link_vs_id for r in t0_records]))
        for alpha_vs_id in alpha_vs_ids:
            try:
                update_vs_alpha_position(alpha_vs_id=alpha_vs_id)
            except Exception as e:
                sentry.captureException()


def update_vs_alpha_position(alpha_vs_id):
    sc = session()
    last_date = sc.query(
        func.max(VsAlphaPositionValue.trading_date)
    ).filter(
        VsAlphaPositionValue.vs_id == alpha_vs_id
    ).first()

    now_date = datetime.datetime.now()
    last_date = last_date and last_date[0] or parse('20190501')
    last_date = (last_date - datetime.timedelta(days=3)).strftime('%Y%m%d')

    days = [
        d.replace('-', '') for d in
        meta_api.get_trading_date_range(int(last_date), int(now_date.strftime('%Y%m%d')), 'SSE')
    ]
    position = {}
    for d in days:
        try:
            position[d] = vs_get_t0_daily_position(alpha_vs_id, d)
        except Exception as e:
            sentry.captureException()

    for d, v in position.items():
        r = sc.query(
            VsAlphaPositionValue
        ).filter(
            VsAlphaPositionValue.vs_id == alpha_vs_id,
            VsAlphaPositionValue.trading_date == d
        ).first()
        if r:
            r.position = v
        else:
            r = VsAlphaPositionValue(
                vs_id=alpha_vs_id,
                trading_date=d,
                position=v
            )
            sc.add(r)
        sc.commit()
    sc.close()
    vs_get_t0_position(alpha_vs_id, cache=False)
    return True


def vs_get_t0_daily_position(vs_id, date):
    from service.back_test.models import LiveQuoteServer

    try:
        # sources = [
        #     0,
        #     '192.168.30.60',
        #     '192.168.30.61',
        #     '192.168.40.55',
        #     '192.168.40.59'
        # ]
        with session_context() as sc:
            sources = [
                r[0] for r in
                sc.query(distinct(LiveQuoteServer.server)).filter(
                    LiveQuoteServer.business == 'stock'
                )
            ]
            sources.insert(0, 0)

        pos_np = []
        for source in sources:
            try:
                pos_np = quote.position(date, 281, vs_id, 0, source)['quote']
                break
            except Exception as e:
                pass

        prices = get_daily_stock_price(date)
        total = 0
        symbols = set()
        for r in pos_np[::-1]:
            sym = str(r['ticker'], 'utf-8')
            if sym in symbols:
                continue
            total += (r['volume'] * prices.get(sym, 0))
            symbols.add(sym)
        return total
    except Exception as e:
        return 0

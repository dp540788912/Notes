# -*-coding:utf-8-*-

import sys
import os

if 'GEN_DATA_TEST' in os.environ:
    sys.path.insert(0, '/home/rss/bss_server/strategy_upload/strategy_upload')

import json
import csv
import copy
import io
from sqlalchemy.orm import mapper
from sqlalchemy import or_
from sqlalchemy import Table, MetaData

if 'GEN_DATA_TEST' in os.environ:
    from models import *
else:
    from service.back_test.models import *

from db import ModelBase, engine, session, session_context as mysql_sc
from log import logger
from service.back_test.live_position_models import VsBase, VsAccount, VsPosition
import consts
from kdb_query import KdbQuery
import traceback
import datetime
import functools

from service.back_test import numpy_db_api

g_inited = False

g_ROOT_ID = 1

g_row_val = {'date': '',
             'symbol': '',
             'open_pos': 0,
             'pre_close': 0,
             'close_pos': 0,
             'close': 0,
             'buy_volume': 0,
             'buy_turnover': 0,
             'buy_price': 0,
             'sell_volume': 0,
             'sell_turnover': 0,
             'sell_price': 0,
             'fee': 0,
             'dividend': 0,
             'pnl': 0
             }


class CorpActionCls(object):
    pass


class Tradelog(object):
    pass


class ManualTradelog(object):
    pass


def init_map_cls():
    metadata_corp_actions = MetaData()
    corp_actions_table = Table('position_corp_actions_table', metadata_corp_actions, autoload=True,
                               autoload_with=engine)
    mapper(CorpActionCls, corp_actions_table)

    metadata_tradelog = MetaData()
    tradelog_table = Table('trade_logs', metadata_tradelog, autoload=True, autoload_with=engine)
    mapper(Tradelog, tradelog_table)

    metadata_manual_tradelog = MetaData()
    manual_tradelog_table = Table('settlement_manual_tradelogs', metadata_manual_tradelog, autoload=True,
                                  autoload_with=engine)
    mapper(ManualTradelog, manual_tradelog_table)


# _date format : YYYYMMDD
def get_numpy_price(_symbol, _date):
    _date = _date[0:4] + '-' + _date[4:6] + '-' + _date[6:]

    _lower = _symbol.lower()
    symbol_type = 'stock'

    if not _lower.isdigit():
        symbol_type = 'future'

    if _lower == 'au(t+d)' or _lower == 'ag(t+d)':
        symbol_type = 'spot'

    numpy_settle_price = 0
    try:
        numpy_settle_price = numpy_db_api.get_end_price(_lower, symbol_type, _date, 0)
    except Exception as e:
        print('get numpy settle price got exp:%s,bt:%s' % (str(e), traceback.format_exc()))
        return 0

    return numpy_settle_price


def get_pre_trading_day(all_trading_days, _date):
    # _date format : %Y%m%d
    for index, d in enumerate(all_trading_days):
        if d >= _date:
            return all_trading_days[index - 1]

    # if cannot find the first item which is larger than _date,
    # then the last item is properly the one we wanted
    return all_trading_days[-1]


def gen_live_pnl_detail(strategy_id, vsid):
    def get_start_end(_strategy_id, _vsid):

        pnl_details = Strategy.pnl_detail(strategy_id)
        vs_live_detail = Strategy.live_net_line(pnl_details['live_pnl'][vsid], pnl_details['paper_trading_date'],
                                                pnl_details['hedge'], pnl_details['hedge_type'])
        pnl_d = vs_live_detail['pnl']
        start_date = ''
        end_date = ''
        first_idx = True
        for _date in sorted(pnl_d):
            if first_idx:
                start_date = _date
            end_date = _date
            first_idx = False

        return start_date, end_date

    def get_positions(*args, **kwargs):

        sc = kwargs['sc']
        data_d = kwargs['data_d']
        vsid = kwargs['vsid']
        start_date = kwargs['start_date']
        end_date = kwargs['end_date']

        _kdb = KdbQuery()
        _all_trading_days = _kdb.get_trading_days_since('2003.01.01')

        global g_row_val

        lst_day_pos = {}  # date-symbol --> [last_pos,last_price]
        q = sc.query(VsPosition).filter(VsPosition.vstrategy_id == vsid, VsPosition.settle_date >= start_date,
                                        VsPosition.settle_date <= end_date)
        q = q.order_by(VsPosition.settle_date, VsPosition.daynight.desc(), VsPosition.symbol)
        for row in q:

            is_stock = row.symbol.isdigit()
            if row.daynight == 'NIGHT' and not is_stock:
                continue

            _date = row.settle_date.strftime('%Y%m%d')
            k = '%s-%s' % (_date, row.symbol)
            if k not in data_d:
                data_d[k] = copy.deepcopy(g_row_val)

            if row.daynight == 'NIGHT' and is_stock:
                data_d[k]['date'] = _date
                data_d[k]['symbol'] = row.symbol
                data_d[k]['open_pos'] = row.today_long_pos - row.today_short_pos
                data_d[k]['pre_close'] = row.today_settle_price

            if row.daynight == 'DAY':
                data_d[k]['date'] = _date
                data_d[k]['symbol'] = row.symbol
                data_d[k]['close_pos'] = row.today_long_pos - row.today_short_pos
                data_d[k]['close'] = row.today_settle_price
                data_d[k]['pnl'] = float(row.symbol_pnl)

                # lt : stock use NIGHT session's result
                if is_stock:
                    continue

                # only futures need to do this:
                _pre_ = get_pre_trading_day(_all_trading_days, _date)
                pre_k = '%s-%s' % (_pre_, row.symbol)
                if pre_k in lst_day_pos:
                    data_d[k]['open_pos'] = lst_day_pos[pre_k][0]
                    data_d[k]['pre_close'] = lst_day_pos[pre_k][1]

                lst_day_pos[k] = []
                lst_day_pos[k].append(data_d[k]['close_pos'])
                lst_day_pos[k].append(data_d[k]['close'])

    return gen_pnl_detail(strategy_id, vsid, get_start_end, get_positions, 'lt')


def gen_vsbt_pnl_detail(strategy_id, vsid):
    def get_start_end(_strategy_id, _vsid):

        pnl_details = Strategy.pnl_detail(_strategy_id)
        vsbt_live_detail = Strategy.vs_back_test_net_line(pnl_details['vs_back_test_pnl'].get(_vsid, {}),
                                                          pnl_details['paper_trading_date'],
                                                          pnl_details['hedge'],
                                                          pnl_details['hedge_type'])
        pnl_d = vsbt_live_detail['pnl']
        start_date = ''
        end_date = ''
        first_idx = True
        for _date in sorted(pnl_d):
            if first_idx:
                start_date = _date
            end_date = _date
            first_idx = False

        return start_date, end_date

    def get_positions(*args, **kwargs):

        sc = kwargs['sc']
        data_d = kwargs['data_d']
        vsid = kwargs['vsid']
        start_date = kwargs['start_date']
        end_date = kwargs['end_date']

        global g_row_val

        lst_day_pos = {}  # symbol --> [last_pos,last_price]
        q = sc.query(VstrategyBackTestResultDetail).filter(
            VstrategyBackTestResultDetail.vstrategy_id == vsid,
            VstrategyBackTestResultDetail.trading_date >= start_date,
            VstrategyBackTestResultDetail.trading_date <= end_date)
        q = q.order_by(VstrategyBackTestResultDetail.trading_date, VstrategyBackTestResultDetail.symbol,
                       VstrategyBackTestResultDetail.day_night.desc())
        for row in q:

            is_stock = row.symbol.isdigit()
            # if row.day_night==1 and not is_stock:
            # continue

            _date = row.trading_date.strftime('%Y%m%d')
            k = '%s-%s' % (_date, row.symbol)
            if k not in data_d:
                data_d[k] = copy.deepcopy(g_row_val)

            if row.day_night == 1:
                data_d[k]['date'] = _date
                data_d[k]['symbol'] = row.symbol
                data_d[k]['pnl'] = row.pnl

                if is_stock:
                    data_d[k]['open_pos'] = row.long_volume - row.short_volume
                    data_d[k]['pre_close'] = row.long_price if row.long_price > 0 else row.short_price

                continue

            data_d[k]['date'] = _date
            data_d[k]['symbol'] = row.symbol
            data_d[k]['close_pos'] = row.long_volume - row.short_volume
            data_d[k]['close'] = row.long_price if row.long_price > 0 else row.short_price
            data_d[k]['pnl'] = float(data_d[k].get('pnl', 0)) + float(row.pnl)
            data_d[k]['dividend'] = row.dividend

            # if is_stock:
            # continue

            if row.symbol in lst_day_pos:
                do_that = True
                if is_stock and (data_d[k].get('open_pos', 0) > 0):
                    do_that = False

                if do_that:
                    data_d[k]['open_pos'] = lst_day_pos[row.symbol][0]
                    data_d[k]['pre_close'] = lst_day_pos[row.symbol][1]

            lst_day_pos[row.symbol] = []
            lst_day_pos[row.symbol].append(data_d[k]['close_pos'])
            lst_day_pos[row.symbol].append(data_d[k]['close'])

    return gen_pnl_detail(strategy_id, vsid, get_start_end, get_positions, 'lt_analysis')


def gen_bt_pnl_detail(strategy_id):
    def get_start_end(*args, **kwargs):
        _strategy_id = args[0]
        pnl_details = Strategy.pnl_detail(_strategy_id)
        vsbt_live_detail = Strategy.back_test_net_line(pnl_details['back_test_pnl'],
                                                       pnl_details['paper_trading_date'],
                                                       pnl_details['hedge'],
                                                       pnl_details['hedge_type'])
        pnl_d = vsbt_live_detail['pnl']
        start_date = ''
        end_date = ''
        first_idx = True
        for _date in sorted(pnl_d):
            if first_idx:
                start_date = _date
            end_date = _date
            first_idx = False

        return start_date, end_date

    def get_positions(*args, **kwargs):

        sc = kwargs['sc']
        data_d = kwargs['data_d']
        strategy_id = kwargs['strategy_id']
        start_date = kwargs['start_date']
        end_date = kwargs['end_date']

        global g_row_val

        corp_info = {}

        if start_date != '' and end_date != '':
            kdb_start = start_date[:4] + '.' + start_date[4:6] + '.' + start_date[6:]
            kdb_end = end_date[:4] + '.' + end_date[4:6] + '.' + end_date[6:]
            kdb = KdbQuery()
            corp_info = kdb.get_corp_actions(kdb_start, kdb_end)

        to_realize_actions = {
            'ex': {},  # 除权除息
            'listing': {},  # 红股上市
        }

        lst_day_pos = {}  # symbol --> [last_pos,last_price]
        q = sc.query(StrategyResult).filter(StrategyResult.strategy_id == strategy_id,
                                            StrategyResult.date >= start_date,
                                            StrategyResult.date <= end_date,
                                            StrategyResult.config_id == 0)
        q = q.order_by(StrategyResult.date)
        for row in q:
            _date = row.date
            _detail = row.detail

            # sort list
            def my_cmp(item_d1, item_d2):

                if float(item_d1['date']) < float(item_d2['date']):
                    return -1;

                if float(item_d1['date']) > float(item_d2['date']):
                    return 1;

                return 1 if item_d1['day_night'] < item_d2['day_night'] else -1

            # sorting
            _detail.sort(key=functools.cmp_to_key(my_cmp))

            for item in _detail:
                # bt : seldom has night session's result , just skip
                # if item['day_night']==1 :
                # continue

                k = '%s-%s' % (_date, item['symbol'])
                if k not in data_d:
                    data_d[k] = copy.deepcopy(g_row_val)

                is_stock = item['symbol'].isdigit()

                if item['day_night'] == 1:
                    data_d[k]['date'] = _date
                    data_d[k]['symbol'] = item['symbol']
                    data_d[k]['pnl'] = item['net_pnl']

                    # data_d[k]['close_pos'] =  item['long_volume'] - item['short_volume']
                    # data_d[k]['close']     =  item['long_price'] if item['long_price'] > 0  else item['short_price']
                    # if item['symbol'] in lst_day_pos:
                    #    data_d[k]['open_pos']   = lst_day_pos[item['symbol']][0]
                    #    data_d[k]['pre_close']  = lst_day_pos[item['symbol']][1]

                    if is_stock:
                        data_d[k]['open_pos'] = item['long_volume'] - item['short_volume']
                        data_d[k]['pre_close'] = item['long_price'] if item['long_price'] > 0 else item[
                                                                                                       'short_price'] > 0

                    continue

                data_d[k]['date'] = _date
                data_d[k]['symbol'] = item['symbol']
                data_d[k]['close_pos'] = item['long_volume'] - item['short_volume']
                data_d[k]['close'] = item['long_price'] if item['long_price'] > 0 else item['short_price']
                data_d[k]['pnl'] = float(data_d[k].get('pnl', 0)) + float(item['net_pnl'])
                data_d[k]['dividend'] = item.get('dividend', 0)

                if item['symbol'] in lst_day_pos:
                    data_d[k]['open_pos'] = lst_day_pos[item['symbol']][0]
                    data_d[k]['pre_close'] = lst_day_pos[item['symbol']][1]

                lst_day_pos[item['symbol']] = []
                lst_day_pos[item['symbol']].append(data_d[k]['close_pos'])
                lst_day_pos[item['symbol']].append(data_d[k]['close'])

                if not is_stock:
                    continue

                if k in corp_info:
                    # register today actions
                    ex_k = '%s-%s' % (corp_info[k]['ex_dt'], item['symbol'])
                    to_realize_actions['ex'][ex_k] = corp_info[k]['ratio']

                    dvd_shares = corp_info[k]['ratio'] * data_d[k]['close_pos']
                    listing_k = '%s-%s' % (corp_info[k]['listing_dt'], item['symbol'])
                    to_realize_actions['listing'][listing_k] = dvd_shares

                    # realize today benifits
                if k in to_realize_actions['ex']:
                    data_d[k]['pre_close'] = data_d[k]['pre_close'] / (1 + to_realize_actions['ex'][k])

                if k in to_realize_actions['listing']:
                    data_d[k]['open_pos'] = data_d[k]['open_pos'] + to_realize_actions['listing'][k]

    return gen_pnl_detail(strategy_id, None, get_start_end, get_positions, 'bt')


def gen_pnl_detail(strategy_id, vsid, _func_start_end, _func_position, _type):
    global g_inited
    if not g_inited:
        init_map_cls()
        g_inited = True

    start_date, end_date = _func_start_end(strategy_id, vsid)

    global g_row_val
    data_d = {}

    sc = session()

    # query position info
    _func_position(data_d=data_d, start_date=start_date, end_date=end_date, strategy_id=strategy_id, vsid=vsid, sc=sc)

    # query tradelog
    if _type == 'lt':
        q = sc.query(Tradelog).filter(or_(Tradelog.entrust_status == 'p', Tradelog.entrust_status == 'c'),
                                      Tradelog.log_type == 3,
                                      Tradelog.vstrategy_id == vsid,
                                      Tradelog.trading_date >= start_date,
                                      Tradelog.trading_date <= end_date)
    elif _type == 'lt_analysis':
        q = sc.query(BackTestTradeLogs).filter(
            or_(BackTestTradeLogs.entrust_status == 'p', BackTestTradeLogs.entrust_status == 'c'),
            BackTestTradeLogs.vstrategy_id == vsid,
            BackTestTradeLogs.trading_date >= start_date,
            BackTestTradeLogs.trading_date <= end_date)
    elif _type == 'bt':
        q = sc.query(BackTestTradeLogs).filter(
            or_(BackTestTradeLogs.entrust_status == 'p', BackTestTradeLogs.entrust_status == 'c'),
            BackTestTradeLogs.strategy_id == strategy_id,
            BackTestTradeLogs.trading_date >= start_date,
            BackTestTradeLogs.trading_date <= end_date)

    def process_row(row, is_manual=False):
        _date = row.trading_date.strftime('%Y%m%d')
        k = '%s-%s' % (_date, row.symbol)

        position_existed = True
        if k not in data_d:
            data_d[k] = copy.deepcopy(g_row_val)
            data_d[k]['date'] = _date
            data_d[k]['symbol'] = row.symbol
            position_existed = False

        _trade_vol = int(float(row.trade_vol))

        is_buy = (row.direction == 'BUY') if is_manual else (row.direction == 0)

        if is_buy:
            data_d[k]['buy_volume'] += _trade_vol
            data_d[k]['buy_turnover'] += float(_trade_vol * float(row.trade_price))
        else:
            data_d[k]['sell_volume'] += _trade_vol
            data_d[k]['sell_turnover'] += float(_trade_vol * float(row.trade_price))
        data_d[k]['fee'] += float(row.fee)

        if not position_existed:
            data_d[k]['need_fix'] = True
            kdb = KdbQuery()
            neighbour_d = kdb.get_nebor_trading_date(_date)
            data_d[k]['pre_close'] = get_numpy_price(row.symbol, neighbour_d['prev'])

    for row in q:
        process_row(row)

    if _type == 'lt':
        q = sc.query(ManualTradelog).filter(ManualTradelog.vstrategy_id == vsid,
                                            ManualTradelog.trading_date >= start_date,
                                            ManualTradelog.trading_date <= end_date)
        for row in q:
            row.fee = 0
            process_row(row, True)

    for k, v in data_d.items():
        v['buy_price'] = 0 if not v['buy_volume'] else v['buy_turnover'] / v['buy_volume']
        v['sell_price'] = 0 if not v['sell_volume'] else v['sell_turnover'] / v['sell_volume']

        if 'need_fix' in v:
            if v['need_fix']:
                data_d[k]['open_pos'] = data_d[k]['sell_volume'] - data_d[k]['buy_volume']
            del v['need_fix']

    # query dividend info
    if _type == 'lt':
        q = sc.query(CorpActionCls).filter(CorpActionCls.vstrategy_id == vsid,
                                           CorpActionCls.dividend_cash_payout_date >= start_date,
                                           CorpActionCls.dividend_cash_payout_date <= end_date,
                                           CorpActionCls.payout_cash > 0)
        for row in q:
            k = '%s-%s' % (row.dividend_cash_payout_date.strftime('%Y%m%d'), row.symbol)
            if k not in data_d:
                data_d[k] = copy.deepcopy(g_row_val)
                data_d[k]['date'] = row.dividend_cash_payout_date.strftime('%Y%m%d')
                data_d[k]['symbol'] = row.symbol
                data_d[k]['pnl'] = row.payout_cash
                data_d[k]['dividend'] = row.payout_cash
            else:
                data_d[k]['dividend'] = row.payout_cash

    sc.close()

    _strio = io.StringIO()
    writer = csv.DictWriter(_strio,
                            fieldnames=['date', 'symbol', 'open_pos', 'pre_close', 'close_pos', 'close', 'buy_volume',
                                        'buy_price', 'sell_volume', 'sell_price', 'fee', 'dividend', 'pnl'],
                            delimiter=',')
    writer.writeheader()
    for k in sorted(data_d):
        del data_d[k]['buy_turnover']
        del data_d[k]['sell_turnover']

        writer.writerow(data_d[k])

    content = _strio.getvalue()
    _strio.close()

    return content


def gen_pnl_summary(strategy_id, vsid, _func, _type):
    pnl_details = Strategy.pnl_detail(strategy_id)

    net_line = _func(pnl_details, vsid)

    if vsid is None:  # retrieving  bt data
        sc = session()
        row = sc.query(Strategy).filter(Strategy.id == strategy_id).first()
        vs_cash_io = {'init_cash': row.detail.get('initial_cash', 0)}
        sc.close()
    else:
        vs_cash_io = pnl_details['vs_cash_io'][vsid]

    # get daily available cash
    daily_available_cash = {}
    sc = session()
    if _type == 'lt':
        rows = sc.query(VsBase).filter(VsBase.vstrategy_id == vsid, VsBase.daynight == 'DAY')
        for row in rows:
            daily_available_cash[row.settle_date.strftime('%Y%m%d')] = row.available_cash
    elif _type == 'vsbt':
        rows = sc.query(VstrategyBackTestResult).filter(VstrategyBackTestResult.vstrategy_id == vsid)
        for row in rows:
            daily_available_cash[row.trading_date.strftime('%Y%m%d')] = str(row.available_cash)
    elif _type == 'bt':
        rows = sc.query(StrategyResult).filter(StrategyResult.strategy_id == strategy_id)
        for row in rows:
            daily_available_cash[row.date] = str(row.available_cash)
    sc.close()

    pnl_d = net_line['pnl']

    first_idx = True
    _vs_data_l = []
    for _date in sorted(pnl_d):
        _vs_data = {}
        _vs_data['date'] = _date
        _vs_data['acc_return(before hedged)'] = net_line['origin_net'].get(_date, [0])[0]
        _vs_data['position_value'] = pnl_d[_date][6]
        _vs_data['index return'] = net_line['hedge_net'].get(_date, [0])[0]
        _vs_data['invest_cash'] = vs_cash_io['init_cash'] if first_idx else vs_cash_io.get(_date, 0)
        _vs_data['acc_return(after hedged)'] = pnl_d[_date][0]
        _vs_data['available_cash'] = daily_available_cash.get(_date, 0)
        first_idx = False
        _vs_data_l.append(_vs_data)

    _strio = io.StringIO()

    writer = csv.DictWriter(_strio,
                            fieldnames=['date', 'acc_return(before hedged)', 'position_value', 'index return',
                                        'invest_cash', 'acc_return(after hedged)', 'available_cash'],
                            delimiter=',')
    writer.writeheader()
    for item in _vs_data_l:
        writer.writerow(item)

    content = _strio.getvalue()
    _strio.close()

    return content


def gen_live_pnl_summary(strategy_id, vsid):
    def _func(pnl_details, _vsid):
        return Strategy.live_net_line(pnl_details['live_pnl'][_vsid],
                                      pnl_details['paper_trading_date'], pnl_details['hedge'],
                                      pnl_details['hedge_type'])

    return gen_pnl_summary(strategy_id, vsid, _func, 'lt')


def gen_vsbt_pnl_summary(strategy_id, vsid):
    def _func(pnl_details, _vsid):
        return Strategy.vs_back_test_net_line(pnl_details['vs_back_test_pnl'].get(_vsid, {}),
                                              pnl_details['paper_trading_date'],
                                              pnl_details['hedge'],
                                              pnl_details['hedge_type'])

    return gen_pnl_summary(strategy_id, vsid, _func, 'vsbt')


def gen_bt_pnl_summary(strategy_id):
    def _func(*args, **kwargs):
        pnl_details = args[0]
        return Strategy.back_test_net_line(pnl_details['back_test_pnl'],
                                           pnl_details['paper_trading_date'],
                                           pnl_details['hedge'],
                                           pnl_details['hedge_type'])

    return gen_pnl_summary(strategy_id, None, _func, 'bt')


def get_download_list(strategy_id, uid):
    ret_d = {'lt': [],
             'lt_analysis': [],
             'bt': {
                 "Back Testing": {"start_date": ""},
                 "Paper Trading": {"start_date": ""}
             }
             }

    sc = session()

    vids = {}
    q = sc.query(VStrategies).filter(VStrategies.strategy_id == strategy_id, VStrategies.source == 'platform',
                                     VStrategies.status == consts.STRATEGY_LIVE)
    for row in q:
        vids[row.id] = row.portfolio_id

    for vid, portfolio_id in vids.items():
        row = sc.query(StrategyPortfolio).filter(StrategyPortfolio.id == portfolio_id).first()
        _d = {'vid': vid,
              'lt_date': row.live_time.strftime('%Y%m%d')}

        ret_d['lt'].append(copy.deepcopy(_d))
        ret_d['lt_analysis'].append(copy.deepcopy(_d))

    row = sc.query(Strategy).filter(Strategy.id == strategy_id).first()

    bt_start_date = ''
    pt_start_date = ''

    if row is not None:
        if row.start_date is not None:
            bt_start_date = row.start_date
        if row.paper_trading_date is not None:
            pt_start_date = row.paper_trading_date.strftime('%Y%m%d')

    ret_d['bt']['Back Testing']['start_date'] = bt_start_date
    ret_d['bt']['Paper Trading']['start_date'] = pt_start_date

    sc.close()

    return ret_d


def main():
    # kdb = KdbQuery()
    # print( kdb.get_nebor_trading_date('2018-01-05') )

    # print(get_numpy_price('000503','20170508'))

    # print(StrategyUserRelation.is_investor(200503,101))
    # print(StrategyUserRelation.is_creator(200503,107))

    # print(get_download_list(201282,107))
    # print(gen_live_pnl_summary(200886,933))
    # print(gen_live_pnl_detail(203317, 1021))

    # print(gen_vsbt_pnl_summary(200886,933))
    # print(gen_vsbt_pnl_detail(203969,1051))

    # print(gen_bt_pnl_summary(200886))
    # print(gen_bt_pnl_detail(200852))
    pass


if __name__ == '__main__':
    main()

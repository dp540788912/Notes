# -*-coding:utf-8-*-

import copy
import json
import platform
import sys
import time
import numpy as np
from datetime import datetime

import pandas as pd
from qpython import qconnection
from tornado import httpclient

if platform.system() != 'Windows':
    # invoker must establish a link to the settlement_system dir
    sys.path.append('settlement_link_dir')

dependency_path = [
    '/home/rss/bss_server/new_settlement',
    # '/home/rss/bss_server/strategy_upload/strategy_upload/'
]

for path in dependency_path:
    if path not in sys.path:
        sys.path.append(path)

from config import config
import cal_fee
import settlement
import traceback
from new_settlement import back_test_settle_one_day

# STOCK_TICKER_LENGTH = 6
# In milliseconds
DAY_SESSION_OPEN_TIME = 90000000
DAY_SESSION_CLOSE_TIME = 150000000
NIGHT_SESSION_OPEN_TIME = 210000000
INVALID_PRICE = -99999.99

# Get Market Data
oneday_result = {
    'task_id': '',
    'progress': 0,
    'status': 0,
    'date': 0,
    'day_night': 0,
    'asset_cash': 0,
    'log_name': [''],
    'pnl_nodes': [],
    'total_asset': 0,
    'dividend': 0,
}

pnl_node = {
    "cancel_cnt": 0,
    "exchange": 0,
    "fee": 0,
    "gross_pnl": 0,
    "long_price": 0,
    "long_volume": 0,
    "max_live_pnl": 0,
    "max_tick_dd": 0,
    "max_vol": 0,
    "net_pnl": 0,
    "param1": 0,
    "param2": 0,
    "param3": 0,
    "place_cnt": 0,
    "product": "",
    "rounds": 0,
    "short_price": 0,
    "short_volume": 0,
    "strat_id": 0,
    "strat_name": "",
    "symbol": "",
    "tot_buy_amt": 0,
    "tot_buy_vol": 0,
    "tot_sell_amt": 0,
    "tot_sell_vol": 0,
    "tot_trade_amt": 0,
    "tot_trade_vol": 0,
    "dividend": 0,
}

# kdb_candles tick data
bar_qsql_strings = [
    # %s: Date %s Ticker, %d begin_time, %d end_time, %category, %bar_interval
    "",  # MI_CFEX_DEEP, 0, cfex_deep_quote
    "",  # MI_DCE_BEST_DEEP, 1, dce_my_best_deep_quote
    "",  # MI_DCE_MARCH_PRICE, 2, dce_my_march_pri_quote
    "",  # MI_DCE_ORDER_STATISTIC, 3  dce_my_ord_stat_quote
    "",  # MI_DCE_REALTIME_PRICE, 4  dce_my_rt_pri_quote
    "",  # MI_DCE_TEN_ENTRUST, 5  dce_my_ten_entr_quote
    "",  # MI_SHFE_MY, 6  shfe_my_quote, primary data source(zhongrong + zhongxin)
    "",  # MI_CZCE_DEEP_MY, 7  czce_my_deep_quote
    "",  # MI_CZCE_SNAPSHOT_MY, 8  czce_my_snapshot_quote
    # MI_MY_STOCK_LV2, 9  my_stock_lv2_quote
    '.gw.asyncexec["select from MinuteBar where date=%s,Symbol in (`%s),Types=`Securities ";`EquityDB]',
    "",  # MI_MY_STOCK_INDEX, 10 my_stock_index_quote
    "",  # MI_MY_MARKET_DATA, 11 my_marketdata
    '.gw.asyncexec["select from MinuteBar where date=%s,Symbol in (`%s),Category=%d ";`CTP]',
    # MI_MY_LEVEL1, 12 my_level1_quote
    # MI_SGD_OPTION, 13 my_stock_option_quote
    ".gw.asyncexec[(`GetCandlesTick;`optionquote;%s;%s;(%d;%d));`OptionAshare]",
    "",  # 14 MI_SGD_ORDER_QUEUE
    "",  # 15 MI_SGD_PER_ENTRUST
    "",  # 16 MI_SGD_PER_BARGAIN
    "",  # 17 MI_MY_EACH_DATASRC
    "",  # 18 MI_TAP_MY
    "",  # 19 MI_IB_BOOK
    "",  # 20 MI_IB_QUOTE
    "",  # 21 MI_RAW_INTERNAL_DATA
    "",  # MI_SGE_DEEP,22
    "",  # 23 MI_MY_STATIC_FACTOR
    "",  # 24 MI_MY_DYNAMIC_FACTOR
    "",  # MI_MY_ESUNNY_FOREIGN, 25 my_esunny_frn_quote
    "",  # MI_SHFE_MY_LV3, 26 shfe_my_quote, only support zhongxin now.
    "",  # MI_DCE_DEEP_ORDS, 27 dce deep quote & order status
    "",  # MI_DCE_LEVEL1 , 28
]


def get_trade_list(start_date, end_date, st_id, q_id):
    """
    date, open_cash, close_cash
    """
    # get initial cash from bss api
    # self._bss_url
    _url = "http://127.0.0.1/api/v1/platform/tradelist?start_date=%s&end_date=%s&st_id=%s&q_id=%s" % \
           (start_date, end_date, st_id, q_id)
    buf = '{}'
    client = httpclient.HTTPClient()
    try:
        buf = client.fetch(_url, request_timeout=100).body.decode("utf-8")
    except httpclient.HTTPError as e:
        print(str(e))
    finally:
        client.close()
    return json.loads(buf)


def timetoint(time):
    tm = datetime.strptime(str(time).split(' ')[-1], '%H:%M:%S')
    tm_ret = (tm.hour * 10000 + tm.minute * 100 + tm.second) * 1000
    if tm_ret < 60000000:
        tm_ret = tm_ret + 240000000
    return tm_ret


# Util function to help query kdb+
def get_kdb(sql, pandas=True):
    with qconnection.QConnection(host=config.KDB_HOST,  # '192.168.1.41'
                                 port=config.KDB_PORT,  # 9000
                                 username=config.KDB_USER,  # 'user1'
                                 password=config.KDB_PASSWD  # 'password'
                                 ) as q:
        q.async(sql)
        return q.receive(pandas=pandas)


def get_bar_data(symbols, date, mi_type, category, bar_interval):
    start_time = time.time()
    if mi_type == 9:
        sql = bar_qsql_strings[mi_type] % (date, '`'.join(symbols))
    else:
        sql = bar_qsql_strings[mi_type] % (date, '`'.join(symbols), category)
    data = get_kdb(sql.encode('ascii', 'ignore'))
    data.Time = data['Time'].apply(timetoint)
    data = data.rename(columns={"OpenPrice": "OpenPrcM", "HighestPrice": "HighestPrcM", "LowestPrice": "LowestPrcM",
                                "ClosePrice": "ClosePrcM", "Volume": "VolumeM", "Turnover": "TurnoverM"})
    print("get_bar_data consume time=%.3fs" % (time.time() - start_time))
    return data


def get_quantamental_signal(q_id):
    _url = "http://127.0.0.1/api/v1/platform/tradelist/quantamental?q_id=%s" % q_id
    buf = '{}'
    client = httpclient.HTTPClient()
    try:
        buf = client.fetch(_url, request_timeout=100).body.decode("utf-8")
    except httpclient.HTTPError as e:
        print(str(e))
    finally:
        client.close()
    return json.loads(buf)


def get_quantamental_signal_per_date(quantamental_dict, trading_day):
    res_dict = {}
    if not quantamental_dict:
        return res_dict
    for _product, _quant_info in quantamental_dict.items():
        _lower_dates_list = []
        for _date, _signal in _quant_info.items():
            if _date <= trading_day:
                _lower_dates_list.append(_date)
        if len(_lower_dates_list) == 0:
            continue
        else:
            res_dict[_product] = _quant_info[max(_lower_dates_list)]
    return res_dict


Ashare_dtype = np.dtype([
    ('SYMBOL', 'S9'),
    ('TRADE_DT', '<i4'),
    ('OBJECT_ID', 'S38'),
    ('CRNCY_CODE', 'S3'),
    ('S_DQ_PRECLOSE', '<f8'),
    ('S_DQ_OPEN', '<f8'),
    ('S_DQ_HIGH', '<f8'),
    ('S_DQ_LOW', '<f8'),
    ('S_DQ_CLOSE', '<f8'),
    ('S_DQ_CHANGE', '<f8'),
    ('S_DQ_PCTCHANGE', '<f8'),
    ('S_DQ_VOLUME', '<f8'),
    ('S_DQ_AMOUNT', '<f8'),
    ('S_DQ_ADJFACTOR', '<f8'),
    ('S_DQ_AVGPRICE', '<f8'),
    ('OPDATE', '<f8'),
    ('OPMODE', 'S1'),
    ('S_DQ_TRADESTATUS', 'S9'),
    ('UPDATETIME', '<f8'),
    ('date', '<i4')], align=False)


def get_tables(date, tbl, dtype):
    """
    util function. not open as api
    get data from disk path(date+table) and use dtype to parse
    Returns: np.array data
    """
    edepth_path = "%s/%s/0/%s.npq"
    npq_file = edepth_path % ('/data', date, tbl)
    try:
        data = np.fromfile(npq_file, dtype=dtype)
        return data
    except Exception as s:
        print(s)
        return []


def read_stock_eof(date):
    data = get_tables(date, "AShareEODPrices", Ashare_dtype)
    ret_json = {
        'suspend_list': []
    }
    if len(data) > 0:
        for d in data:
            symbol = d[0].decode('utf-8').split('.')[0]
            trade_status = d[17].decode('utf-8')
            tmp_dict = ret_json[symbol] = {}
            tmp_dict['S_DQ_TRADESTATUS'] = trade_status
            if trade_status == 'SUSPENDED':
                ret_json['suspend_list'].append(symbol)
            tmp_dict['S_DQ_OPEN'] = d[5]
    return ret_json


def tradelogs_cash_check(st_id, trade_logs, positions, mi_type):
    if st_id not in positions:
        return trade_logs
    if st_id not in trade_logs:
        return trade_logs
    if mi_type != 9:  # long stocks only
        return trade_logs

    cash = positions[st_id]['cash']
    long_cash = 0
    short_cash = 0
    multiplier = 1  # long stocks only

    for symbol in trade_logs[st_id]:
        for trade_log_item in trade_logs[st_id][symbol]:
            if trade_log_item['open_close'] == 0 and trade_log_item['direction'] == 0:
                long_cash = long_cash + trade_log_item['trade_vol'] * trade_log_item['trade_price'] * multiplier
            if trade_log_item['open_close'] == 1 and trade_log_item['direction'] == 1:
                short_cash = short_cash + trade_log_item['trade_vol'] * trade_log_item['trade_price'] * multiplier
    print(cash, short_cash, long_cash)
    available_cash = cash + short_cash - long_cash
    if available_cash >= 0:
        return trade_logs
    else:
        # print("trade_logs are changedddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd")
        for symbol in trade_logs[st_id]:
            for trade_log_item in trade_logs[st_id][symbol]:
                if trade_log_item['open_close'] == 0 and trade_log_item['direction'] == 0:
                    trade_log_item['trade_vol'] = int(trade_log_item['trade_vol'] *
                                                      (cash + short_cash) / long_cash / 100) * 100
        return trade_logs


# Match trades based on market data, and generate trade_logs for clearing. positions here is the initial position from
# the end of last session.
# day_night_flag: 0 - Day, 1 - Night.
def do_match(st_id, day_night_flag, trade_list, _quant_list_info, bar_data, mi_type, positions,
             trading_date, df_EOD, trade_model):
    _st_tradelogs = {st_id: {}}
    if day_night_flag == 1:
        bar_data['Time'] = [(i + 240000000) if i < 50000000 else i for i in bar_data['Time'].tolist()]
    # Check to make sure we have strategy record and cash.
    if st_id not in positions:
        print("Position doesn't have strategy related info, st_id: %d" % st_id)
        return _st_tradelogs
    elif 'cash' not in positions[st_id]:
        print("Position doesn't have cash, st_id: %d" % st_id)
        return _st_tradelogs
    elif 'data' not in positions[st_id]:
        print("Position doesn't have data, st_id: %d" % st_id)
        return _st_tradelogs

    # Get the total asset value, Add up all assets and the available cash.
    asset_cash = positions[st_id]['asset_cash']
    position_value = 0.0

    # First, Calc Position Value, close out the previous position that are not in the trade_list.
    # Symbol is the key, symbol_pos_d is the detail dictionary
    for symbol, symbol_pos_d in positions[st_id].get('data', {}).items():
        multiplier = 1
        try:
            multiplier = cal_fee.get_symbol_trade_unit(symbol)
        except Exception as e:
            print('got exception get_future_trade_unit:%s' % (str(e)))

        # Calc the position value.
        long_open_pos = symbol_pos_d.get('today_long_pos', 0)
        short_open_pos = symbol_pos_d.get('today_short_pos', 0)
        long_avg_px = symbol_pos_d.get('today_long_avg_price', 0.0)
        short_avg_px = symbol_pos_d.get('today_short_avg_price', 0.0)
        # if symbol not in df_EOD.loc[df_EOD['S_DQ_TRADESTATUS'] == 'SUSPENDED'].Symbol.tolist():
        # if symbol not in df_EOD['suspend_list']:
        if True:
            position_value += (long_open_pos * long_avg_px - short_open_pos * short_avg_px) * multiplier

        # Check whether the symbol is in positions.
        # tradelist_symbol = ''
        for symbol_trade_info in trade_list:
            tradelist_symbol = symbol_trade_info.get('symbol', "")  # Algo symbol
            if symbol == tradelist_symbol:  # If it's in tradelist, break out the for loop
                break
        # If there's no tradelist, still need to check quantamental signal.
        if len(trade_list) == 0:
            if mi_type == 9:
                _product = symbol
            if mi_type == 12:
                _product = ''.join([i for i in symbol if not i.isdigit()])
            if _product not in _quant_list_info:
                continue
            _signal = _quant_list_info[_product]

            start_time = 90000000
            end_time = 91500000
            algo = 'twap'
            filtered_bar_data = bar_data.loc[
                (bar_data.Symbol == symbol.encode('utf-8')) & (bar_data.Time > start_time) &
                (bar_data.Time <= end_time)
                ]
            price = get_price(bar_data, algo, mi_type, symbol, trading_date, df_EOD,
                              start_time, end_time, trade_model)
            if price == INVALID_PRICE:
                continue

            # Default a trade_log_item, with Close Position Flag and Price.
            trade_log_item = {
                'vsid': st_id,
                'symbol': symbol,
                'direction': 0,  # 0: Buy, 1: Sell
                'open_close': 1,  # Close Position. 0:Open 1:Close 2:Close Today 3:Close Yest.
                'trade_price': price,  # Execution Price
                'trade_vol': 0,  # Trade Volume
                'account': settlement.InitValueMgr.INIT_ACCOUNT,  # Account Info
                'serial_no': '',  # Unique ExecutionID
                'msg_type': '3',
                'entrust_status': 'c',
            }

            if symbol not in _st_tradelogs[st_id]:
                _st_tradelogs[st_id][symbol] = []
            # Both long_open_pos and short_open_pos greater than zero doesn't exist in tradelist backtest.
            pre_net_pos = long_open_pos - short_open_pos
            if pre_net_pos > 0 > _signal:
                trade_log_item1 = copy.deepcopy(trade_log_item)
                buy_or_sell = 1
                trade_log_item1['direction'] = buy_or_sell  # Sell
                trade_log_item1['trade_vol'] = long_open_pos
                if end_time == 290100000 and day_night_flag == 1:
                    if long_open_pos > 1:
                        trade_log_item1['trade_vol'] = int(long_open_pos / 2)
                    else:
                        continue
                trade_log_item1['calendar_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')

                if reach_limit_check(filtered_bar_data, buy_or_sell, True, mi_type) is True:
                    continue
                _st_tradelogs[st_id][symbol].append(trade_log_item1)

            if pre_net_pos < 0 < _signal:
                trade_log_item2 = copy.deepcopy(trade_log_item)
                buy_or_sell = 0
                trade_log_item2['direction'] = buy_or_sell  # Buy
                trade_log_item2['trade_vol'] = short_open_pos
                if end_time == 290100000 and day_night_flag == 1:
                    if short_open_pos > 1:
                        trade_log_item2['trade_vol'] = int(short_open_pos / 2)
                    else:
                        continue
                trade_log_item2['calendar_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')

                if reach_limit_check(filtered_bar_data, buy_or_sell, True, mi_type) is True:
                    continue
                _st_tradelogs[st_id][symbol].append(trade_log_item2)

    # Add up to Asset Value
    asset_value = asset_cash + position_value
    # print("asset_value: %f"%asset_value)

    # Then, read TradeList, and read symbol, and dates. Loop through each trade record.
    for symbol_trade_info in trade_list:
        buy_or_sell = 0  # 0: Buy,  1: Sell
        open_or_close = 0  # 0: Open, 1: close, 2: Close Today  3. Close Yesterday
        total_notional_one_contract = 0.0

        symbol = symbol_trade_info.get('symbol', "")  # Algo symbol

        # 1. Get the volume, form the tradelogs.
        trade_log_item = {
            'vsid': st_id,
            'symbol': symbol,
            'direction': 0,  # 0: Buy, 1: Sell
            'open_close': 0,  # 0:Open 1:Close  2:Close Today 3:Close Yest.
            'trade_price': 0.0,  # Execution Price
            'trade_vol': 0,  # Trade Volume
            'account': settlement.InitValueMgr.INIT_ACCOUNT,  # Account Info
            'serial_no': '',  # Unique ExecutionID
            'msg_type': '3',
            'entrust_status': 'c',
        }

        # For position API, check http://drtp.my/showdoc-master/index.php?s=/9&page_id=515
        # Preprocessing, based on trade_list and positions.
        # Keep what's in trade_list, use volume - volume in positions.

        def symbol_in_pos():
            if st_id in positions:
                if 'data' in positions[st_id]:
                    if symbol in positions[st_id]['data']:
                        return True
            return False

        # 2. Get the Price first. For each symbol, filter the Time, use bar_data to calculate the VWAP/TWAP/DMA price
        start_time = symbol_trade_info.get('start_time', 000000000)  # Algo start time
        end_time = symbol_trade_info.get('end_time', 000000000)  # Algo end time
        algo = symbol_trade_info.get('algo', "").lower()
        filtered_bar_data = bar_data.loc[
            (bar_data.Symbol == symbol.encode('utf-8')) & (bar_data.Time > start_time) & (bar_data.Time <= end_time)
            ]
        price = get_price(bar_data, algo, mi_type, symbol, trading_date, df_EOD, start_time, end_time, trade_model)
        if price == INVALID_PRICE:
            continue
        open_price = get_price(bar_data, algo, mi_type, symbol, trading_date, df_EOD,
                               start_time, end_time, 'open_price')
        if open_price == INVALID_PRICE:
            continue

        # Calc the target volume based on weight or volume.
        volume = target_pos = 0
        if symbol_trade_info.get('weight', 0.0) is not None:
            weight = symbol_trade_info.get('weight', 0.0)
            total_notional_one_contract = asset_value * weight
        elif symbol_trade_info.get('volume', 0) is not None:
            volume = target_pos = int(symbol_trade_info.get('volume', 0))  # OrderQty.

        if total_notional_one_contract != 0.0:
            if open_price > 0.0:
                multiplier = 1
                try:
                    multiplier = cal_fee.get_symbol_trade_unit(symbol)
                except Exception as e:
                    print('got exception get_future_trade_unit:%s' % (str(e)))

                volume = target_pos = int(total_notional_one_contract / (open_price * multiplier))
                if symbol.isdigit() is True:  # If ticker has a numeric characters, we consider it a stock
                    volume = target_pos = int(volume / 100) * 100
                # print("Stock,Volume convet to:%d"%volume)
            # print( "TotalNotionalOneContract: %f FinalVol: %d"% (total_notional_one_contract, volume))
        # consider quantamental signal.
        if mi_type == 9:
            _product = symbol
        if mi_type == 12:
            _product = ''.join([i for i in symbol if not i.isdigit()])
        if _product not in _quant_list_info:
            _signal = 0
        else:
            _signal = _quant_list_info[_product]
        if (target_pos > 0 > _signal) or (target_pos < 0 < _signal):
            target_pos = 0

        if symbol not in _st_tradelogs[st_id]:
            _st_tradelogs[st_id][symbol] = []

        if symbol_in_pos():
            pre_today_long_pos = 0
            pre_today_short_pos = 0

            if st_id in positions:
                if 'data' in positions[st_id]:
                    if symbol in positions[st_id]['data']:
                        pre_today_long_pos = positions[st_id]['data'][symbol].get('today_long_pos', 0)
                        pre_today_short_pos = positions[st_id]['data'][symbol].get('today_short_pos', 0)

            pre_net_pos = pre_today_long_pos - pre_today_short_pos

            if end_time == 290100000 and day_night_flag == 1:
                target_pos = pre_net_pos + int((target_pos - pre_net_pos) / 2)
            if pre_net_pos == target_pos:
                continue
            # There're 4 scenarios based on target_pos and pre_net_pos
            if pre_net_pos >= 0:  # Prepos is Long
                if target_pos > 0:  # want to get a long pos, two scenarios.
                    if target_pos > pre_net_pos:  # Buy Open the position difference
                        buy_or_sell = 0
                        open_or_close = 0
                        volume = target_pos - pre_net_pos
                        # print "====Buy Open %d"%volume
                    elif target_pos < pre_net_pos:  # Sell Close the position difference.
                        buy_or_sell = 1
                        open_or_close = 1
                        volume = pre_net_pos - target_pos
                        # print "====Sell Close %d"%volume
                elif target_pos < 0:  # want to get a short pos, two actions.
                    # Sell close current long pos
                    buy_or_sell = 1
                    open_or_close = 1
                    volume = pre_net_pos
                    # print "====Sell Close First %d"%volume
                    # Check Price validity, if we reach limits during the start ~ end time, continue, don't trade.
                    if reach_limit_check(filtered_bar_data, buy_or_sell, (algo == 'dma'), mi_type) is True:
                        continue
                    trade_log_item['direction'] = buy_or_sell
                    trade_log_item['open_close'] = open_or_close
                    trade_log_item['trade_vol'] = volume
                    trade_log_item['trade_price'] = price
                    trade_log_item['calendar_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')

                    _st_tradelogs[st_id][symbol].append(copy.deepcopy(trade_log_item))

                    # Sell Open to target pos.
                    buy_or_sell = 1
                    open_or_close = 0
                    volume = abs(target_pos)
                    # print "====Sell Open Next %d"%volume
                else:  # target_pos = 0: #Sell Close current long pos
                    buy_or_sell = 1
                    open_or_close = 1
                    volume = pre_net_pos
                    # print "====Sell Close %d"%volume
            elif pre_net_pos < 0:  # Prepos is Short
                if target_pos < 0:  # want to get a short pos, two scenarios.
                    if abs(target_pos) > abs(pre_net_pos):  # Sell Open the position difference
                        buy_or_sell = 1
                        open_or_close = 0
                        volume = abs(target_pos) - abs(pre_net_pos)
                        # print "====Sell Open %d"%volume
                    elif abs(target_pos) < abs(pre_net_pos):  # Buy Close the position difference.
                        buy_or_sell = 0
                        open_or_close = 1
                        volume = abs(pre_net_pos) - abs(target_pos)
                        # print "====Buy Close %d"%volume
                elif target_pos > 0:  # want to get a long pos, two actions.
                    # Buy close current short pos
                    buy_or_sell = 0
                    open_or_close = 1
                    volume = abs(pre_net_pos)
                    # print("====Buy Close First %s %d@%f"% (symbol, volume, price))
                    # Check Price validity, if we reach limits during the start ~ end time, continue, don't trade.
                    if reach_limit_check(filtered_bar_data, buy_or_sell, (algo == 'dma'), mi_type) is True:
                        continue
                    # Buy Open to target pos.
                    trade_log_item['direction'] = buy_or_sell
                    trade_log_item['open_close'] = open_or_close
                    trade_log_item['trade_vol'] = volume
                    trade_log_item['trade_price'] = price
                    trade_log_item['calendar_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')

                    _st_tradelogs[st_id][symbol].append(copy.deepcopy(trade_log_item))

                    buy_or_sell = 0
                    open_or_close = 0
                    volume = abs(target_pos)
                    # print "====Buy Open Next %d"%volume
                else:  # target_pos = 0: #Buy Close current long pos
                    buy_or_sell = 0
                    open_or_close = 1
                    volume = abs(pre_net_pos)
                    # print "====Buy Close %d"%volume
        elif target_pos != 0:  # It's a new contract, just buy/sell open it.
            buy_or_sell = 0 if (target_pos > 0) else 1
            open_or_close = 0
            volume = abs(target_pos)
            if end_time == 290100000 and day_night_flag == 1:
                if volume > 1:
                    volume = int(abs(target_pos) / 2)
                else:
                    continue
            # print "====%s Open %d"%( "Buy" if(buy_or_sell == 0) else "Sell", volume)
        else:  # Target_pos is 0, and there's no previous position, do nothing.
            # print ('do_match do symbol and target_pos==0')
            continue

        # Check Price validity, if we reach limits during the start ~ end time, continue, don't trade.
        if reach_limit_check(filtered_bar_data, buy_or_sell, (algo == 'dma'), mi_type) is True:
            continue

        # Form trade logs.
        trade_log_item['direction'] = buy_or_sell
        trade_log_item['open_close'] = open_or_close
        trade_log_item['trade_vol'] = volume
        trade_log_item['trade_price'] = price
        trade_log_item['calendar_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
        _st_tradelogs[st_id][symbol].append(trade_log_item)
        # print("TradeLog: %s"%trade_log_item)

    # print("TradeLog: %s"%_st_tradelogs)
    return _st_tradelogs


# Based on Buy or Sell, check if we reach upper/lower limit. # buy_or_sell:  0 - Buy,  1 - Sell
# If it's DMA, use the first data; or else check every bar to see we reach the limit.
def reach_limit_check(bar_data, buy_or_sell, is_dma, mi_type):
    if len(bar_data) <= 0:
        return False
    if buy_or_sell == 0:  # Buy, check the high price in bar equals to UpperLimitPrice. If so, we reach upper limit.
        if mi_type == 9:
            if is_dma is True:
                if bar_data.iloc[0]["Flag"] == 1:
                    return True
                else:
                    return False
            else:
                filtered_bar_data = bar_data.loc[bar_data.Flag == 1]
                if len(filtered_bar_data) > (len(bar_data) - 5):
                    return True
                else:
                    return False
        else:
            if is_dma is True:
                if bar_data.iloc[0]["HighestPrcM"] == bar_data.iloc[0]["UpperLimitPrice"]:
                    return True
                else:
                    return False
            else:
                filtered_bar_data = bar_data.loc[bar_data.HighestPrcM == bar_data.UpperLimitPrice]
                if len(filtered_bar_data) > 0:
                    return True
                else:
                    return False
    elif buy_or_sell == 1:  # Sell, check the low price in bar equals to LowerLimitPrice. If so, we reach lower limit.
        if mi_type == 9:
            if is_dma is True:
                if bar_data.iloc[0]["Flag"] == -1:
                    return True
                else:
                    return False
            else:
                filtered_bar_data = bar_data.loc[bar_data.Flag == -1]
                if len(filtered_bar_data) > (len(bar_data) - 5):
                    return True
                else:
                    return False
        else:
            if is_dma is True:
                if bar_data.iloc[0]["LowestPrcM"] == bar_data.iloc[0]["LowerLimitPrice"]:
                    return True
                else:
                    return False
            else:
                filtered_bar_data = bar_data.loc[bar_data.LowestPrcM == bar_data.LowerLimitPrice]
                if len(filtered_bar_data) > 0:
                    return True
                else:
                    return False
    return False


# get_price:  bar_data is the market data, algo is string, start_time, end_time is int YYYYMMDD
def get_price(bar_data, algo, mi_type, symbol, trading_date, df_EOD, start_time, end_time, trade_model):
    filtered_bar_data = bar_data.loc[
        (bar_data.Symbol == symbol.encode('utf-8')) & (bar_data.Time > start_time) & (bar_data.Time <= end_time)
        ]
    price = INVALID_PRICE
    if len(filtered_bar_data) <= 0:
        try:
            # df_tmp = df_EOD.loc[df_EOD['Symbol'] == symbol]
            # price = df_tmp.loc[df_tmp['S_DQ_TRADESTATUS'] == 'TRADE'].iloc[0]['S_DQ_OPEN']
            price = df_EOD[symbol]['S_DQ_OPEN']
        except KeyError:
            print('Suspended symbol: ', symbol)
        return price
    multiplier = 1
    try:
        multiplier = cal_fee.get_symbol_trade_unit(symbol)
    except Exception as e:
        print('got exception get_symbol_trade_unit:%s' % (str(e)))

    if trade_model == "open_price":
        price = bar_data.loc[(bar_data.Symbol == symbol.encode('utf-8'))].iloc[0]["ClosePrcM"]
        if mi_type == 9:  # If it's stock data, we need to divide by 10000
            price /= 10000
    elif trade_model == "close_price":
        price = bar_data.loc[(bar_data.Symbol == symbol.encode('utf-8'))].iloc[-1]["ClosePrcM"]
        if mi_type == 9:  # If it's stock data, we need to divide by 10000
            price /= 10000
    elif trade_model == "vwap_price":
        sum_vol = filtered_bar_data.sum()["VolumeM"]
        if sum_vol != 0:
            price = filtered_bar_data.sum()["TurnoverM"] / multiplier / sum_vol
    elif trade_model == "twap_price":
        sum_price = filtered_bar_data.sum()["ClosePrcM"]
        # Get the average price for each price in one minute, i.e, Time Weighted Price between start_time, end_time.
        if len(filtered_bar_data) > 0:
            price = sum_price / len(filtered_bar_data)
        if mi_type == 9:  # If it's stock data, we need to divide by 10000
            price /= 10000
    elif trade_model == "dma_price":
        # Get the start_time's next bar, use it's ClosePrcM as DMA_price.
        if len(filtered_bar_data) >= 1:
            price = filtered_bar_data.iloc[0]["ClosePrcM"]
        if mi_type == 9:  # If it's stock data, we need to divide by 10000
            price /= 10000
    else:
        if algo == "twap":
            sum_price = filtered_bar_data.sum()["ClosePrcM"]
            # Get the average price for each price in one minute, i.e, Time Weighted Price between start_time, end_time.
            if len(filtered_bar_data) > 0:
                price = sum_price / len(filtered_bar_data)
            if mi_type == 9:  # If it's stock data, we need to divide by 10000
                price /= 10000

        elif algo == "dma":
            # Get the start_time's next bar, use it's ClosePrcM as DMA_price.
            if len(filtered_bar_data) >= 1:
                price = filtered_bar_data.iloc[0]["ClosePrcM"]
            if mi_type == 9:  # If it's stock data, we need to divide by 10000
                price /= 10000

        elif algo == "vwap":
            sum_vol = filtered_bar_data.sum()["VolumeM"]
            if sum_vol != 0:
                price = filtered_bar_data.sum()["TurnoverM"] / multiplier / sum_vol

        else:
            print("Doesn't support this algo %s" % algo)

    return price


# quantamental backtest
def back_test_quantamental_strat(param):
    q_id = param.get('q_id', 0)
    start_time = time.time()
    quantamental_dict = get_quantamental_signal(q_id)['data']
    print("get_quantamental_signal consume time=%.3fs" % (time.time() - start_time))

    initial_cash = param['init_cash']
    origin_cum_value = initial_cash
    qmental_cum_value = initial_cash
    output = {}
    if 'detail' in param:
        for date in sorted(param['detail'].keys()):
            quant_list_info = get_quantamental_signal_per_date(quantamental_dict, date)
            origin_daily_pnl = 0
            qmental_daily_pnl = 0
            if 'symbols' in param['detail'][date]:
                for pos_pnl in param['detail'][date]['symbols']:
                    origin_daily_pnl += pos_pnl['pnl']

                    if pos_pnl['symbol'].isdigit():
                        product = pos_pnl['symbol']
                    else:
                        product = ''.join([i for i in pos_pnl['symbol'] if not i.isdigit()])
                    if product in quant_list_info:
                        net_pos = pos_pnl['long_volume'] - pos_pnl['short_volume']
                        if net_pos * quant_list_info[product] < 0:
                            # Different prediction. Assume close at open.
                            qmental_daily_pnl += 0
                        else:
                            qmental_daily_pnl += pos_pnl['pnl'] * qmental_cum_value / origin_cum_value
                    else:
                        qmental_daily_pnl += pos_pnl['pnl'] * qmental_cum_value / origin_cum_value

                origin_cum_value += origin_daily_pnl
                qmental_cum_value += qmental_daily_pnl

            output[date] = {'close_value': qmental_cum_value, 'pnl': qmental_daily_pnl}

    return output


# Pass in a starting date and st_id
def back_test_tradelist_strat(param):
    global oneday_result
    oneday_result["task_id"] = param['task_id']
    st_id = param['strat_id']
    int_start_date = param['start_date']
    int_end_date = param['end_date']
    hedge = param.get('hedge', '')
    hedge_type = param.get('hedge_type', '')
    task_id = param['task_id']
    trade_model = param.get('trade_model', '')
    settlement_kwargs = param.get('settlement_kwargs', {})
    q_id = param.get('q_id', 0)

    # Get and process trade_list. We only have one strategy here.
    start_time = time.time()
    trade_list = get_trade_list(param['start_date'], param['end_date'], st_id, q_id)["data"]
    print("get_trade_list consume time=%.3fs" % (time.time() - start_time))

    # trade_list = {"st_id":24,"detail":[
    # {
    #  "date":20170622,
    #  "trade_list":[
    #      [69,24,2,"600276",null,100,null,"VWAP","13:30","15:00"],
    #      [70,24,2,"600741",null,200,null,"VWAP","13:30","15:00"]
    #  ]
    # },
    # {
    #  "date":20170623,
    #  "trade_list":[
    #       [69,24,2,"600276",null,500,null,"VWAP","9:30","9:45"]]
    # }
    # ]}
    # TODO: Add trade_list check, handle wrong input, like NULL. Also add weights, LimitPrice processing.
    # Process trade_list, Get Symbol, Dates, Algo, TradeTime.
    # print(trade_list)
    start_time = time.time()
    quantamental_dict = get_quantamental_signal(q_id)['data']
    print("get_quantamental_signal consume time=%.3fs" % (time.time() - start_time))

    if 'position' in param:
        pos_d = param['position']
    else:
        pos_d = settlement.InitValueMgr.get_init_vs_pos(param['cash'])

    current_positions = {st_id: pos_d}

    # For each strat_id.
    tradelist_per_strat_id = {}

    for item in trade_list:
        # check st_id, only process the same st_id trade list.
        if item.get('st_id', -1) != st_id:
            continue
        tradelist_per_strat_id = item
        break

    cur_progress = 0
    # Get all trading days from begin and end time.

    tmp_datetime1 = datetime.strptime(str(int_start_date), '%Y%m%d')
    str_begin_date = tmp_datetime1.strftime("%Y.%m.%d")

    tmp_datetime2 = datetime.strptime(str(int_end_date), '%Y%m%d')
    str_end_date = tmp_datetime2.strftime("%Y.%m.%d")

    trading_day_list = cal_fee.get_around_trading_days(str_begin_date, str_end_date)  # Trading_day is in %Y%M%D format.
    total_progress = len(trading_day_list)
    last_tradelist_records = []
    ready_to_close_dict = {}

    # Go through trading days.
    for trading_day in trading_day_list:
        # Get tradelist for that trading_day.
        print("============== Processing: Date %s ================" % trading_day)

        tradelist_records = []
        tradelist_date = ''
        # 1. Find the tradelist for that tradeing day. If no tradelist for that day, do a quick clearing.
        # Loop through tradelist to find that day. TODO: Optimize this part, use tradingdate as key.
        for tradelist_dict_per_day in tradelist_per_strat_id.get('detail', []):
            tradelist_date = tradelist_dict_per_day.get('date', '')
            if tradelist_date != trading_day:
                continue
            tradelist_records = tradelist_dict_per_day.get('trade_list', [])
            break

        cur_progress += 1
        current_bt_percent = int((cur_progress * 100) / total_progress)

        start = time.time()
        ashare_eod_dict = read_stock_eof(str(trading_day))
        print("read ashare_eod_dict time consumption %s" % (time.time() - start))

        day_symbols = []
        night_symbols = []
        # list of {"symbol":"600276","volume":100,"algo":"VWAP","start_time":"90010000","end_time":150010000}
        day_list_info = []
        night_list_info = []
        tmp_datetime = datetime.strptime(trading_day, '%Y%m%d')

        quant_list_info = get_quantamental_signal_per_date(quantamental_dict, trading_day)

        # Didn't find the trade list for that day, just do a quick clearing with an empty tradelogs.
        if tradelist_date != trading_day:
            category = 0
            tmp_str_date = tmp_datetime.strftime("%Y.%m.%d")

            if st_id in current_positions:
                if 'data' in current_positions[st_id]:
                    for symbol, symbol_pos in current_positions[st_id]['data'].items():
                        day_symbols.append(symbol)

            current_positions, one_session_result = do_clearing(st_id, tmp_str_date, category, day_symbols,
                                                                day_list_info, quant_list_info,
                                                                current_positions, current_bt_percent,
                                                                settlement.SettleEnvMgr.START_POINT_DAY,
                                                                ashare_eod_dict, trade_model,
                                                                hedge=hedge, hedge_type=hedge_type,
                                                                task_id=task_id, settlement_kwargs=settlement_kwargs
                                                                )
            yield one_session_result
            continue

        str_date = tmp_datetime.strftime("%Y.%m.%d")  # Date can be different from the start_date parameter.
        # 2. Found the tradelist for that day. Get all tradelist detail: Symbols, List_info
        for tradelist_record_per_day in tradelist_records:
            if len(tradelist_record_per_day) < 10:  # TradeList is not valid.
                continue
            # Get symbols and trade list detail per day #######.  #Convert time from 13:30 to 133000000
            start_datetime = datetime.strptime(str(tradelist_record_per_day[8]), '%H:%M')
            end_datetime = datetime.strptime(str(tradelist_record_per_day[9]), '%H:%M')
            int_start_time = int(start_datetime.strftime("%H%M%S000"))
            int_end_time = int(end_datetime.strftime("%H%M%S000"))

            # print("TradeList: %s, Weight:%s, Volume:%s Time: %d~%d"%(tradelist_record_per_day[3],
            # tradelist_record_per_day[4],tradelist_record_per_day[5],int_start_time,int_end_time))
            # Night Session
            if int_start_time >= NIGHT_SESSION_OPEN_TIME:
                if DAY_SESSION_CLOSE_TIME >= int_end_time > DAY_SESSION_OPEN_TIME:
                    # If there's duplicated symbol in one trade_list, we only process the first one.
                    if tradelist_record_per_day[3] not in night_symbols:
                        night_symbols.append(tradelist_record_per_day[3])
                        tmp_dic = {
                            "symbol": tradelist_record_per_day[3],
                            "weight": tradelist_record_per_day[4],
                            "volume": tradelist_record_per_day[5],
                            "algo": tradelist_record_per_day[7],
                            "start_time": int_start_time,
                            "end_time": 290100000
                        }
                        night_list_info.append(tmp_dic)
                    if tradelist_record_per_day[3] not in day_symbols:
                        day_symbols.append(tradelist_record_per_day[3])
                        tmp_dic = {
                            "symbol": tradelist_record_per_day[3],
                            "weight": tradelist_record_per_day[4],
                            "volume": tradelist_record_per_day[5],
                            "algo": tradelist_record_per_day[7],
                            "start_time": 90000000,
                            "end_time": int_end_time
                        }
                        day_list_info.append(tmp_dic)
                else:
                    if tradelist_record_per_day[3] not in night_symbols:
                        night_symbols.append(tradelist_record_per_day[3])
                        tmp_dic = {
                            "symbol": tradelist_record_per_day[3],
                            "weight": tradelist_record_per_day[4],
                            "volume": tradelist_record_per_day[5],
                            "algo": tradelist_record_per_day[7],
                            "start_time": int_start_time,
                            "end_time": int_end_time
                        }
                        night_list_info.append(tmp_dic)

            elif int_start_time > int_end_time or \
                    (int_start_time > DAY_SESSION_CLOSE_TIME > int_start_time) or \
                    (int_end_time > DAY_SESSION_CLOSE_TIME > int_end_time):
                print("trade_list time is wrong: st_id: %d symbol:%s startEndTime: %s %s" %
                      (st_id, tradelist_record_per_day[3], tradelist_record_per_day[8], tradelist_record_per_day[9]))
            # If there's duplicated symbol in one trade_list, we only process the first one.
            elif tradelist_record_per_day[3] not in day_symbols:
                day_symbols.append(tradelist_record_per_day[3])
                tmp_dic = {
                    "symbol": tradelist_record_per_day[3],
                    "weight": tradelist_record_per_day[4],
                    "volume": tradelist_record_per_day[5],
                    "algo": tradelist_record_per_day[7],
                    "start_time": int_start_time,
                    "end_time": int_end_time
                }
                day_list_info.append(tmp_dic)

        # 3. do_clearing for Night/Day sessions
        night_list_info, night_symbols, day_list_info, day_symbols, ready_to_close_dict = \
            add_tradelist_from_position(night_list_info, night_symbols, day_list_info, day_symbols,
                                        ready_to_close_dict, current_positions[st_id], last_tradelist_records)
        category = 1
        # print('night_symbols: ',night_symbols)
        # night_symbols = add_symbol_from_position( night_symbols, current_positions[st_id] )
        current_positions, night_session_result = do_clearing(st_id, str_date, category, night_symbols,
                                                              night_list_info, quant_list_info, current_positions,
                                                              current_bt_percent,
                                                              settlement.SettleEnvMgr.START_POINT_DAY,
                                                              ashare_eod_dict, trade_model, hedge=hedge,
                                                              hedge_type=hedge_type, task_id=task_id,
                                                              settlement_kwargs=settlement_kwargs)
        category = 0
        # day_symbols = add_symbol_from_position( day_symbols, current_positions[st_id] )
        # print('day_symbols: ', day_symbols)
        current_positions, day_session_result = do_clearing(st_id, str_date, category, day_symbols,
                                                            day_list_info, quant_list_info, current_positions,
                                                            current_bt_percent,
                                                            settlement.SettleEnvMgr.START_POINT_NIGHT,
                                                            ashare_eod_dict, trade_model, hedge=hedge,
                                                            hedge_type=hedge_type, task_id=task_id,
                                                            settlement_kwargs=settlement_kwargs)
        last_tradelist_records = tradelist_records
        # compute cumulative pnl of night session and day session
        if 'pnl_nodes' not in night_session_result:
            print('pnl_nodes not in night_session_result')
            night_session_result['pnl_nodes'] = []
        to_add = []
        for night_pnl_node in night_session_result['pnl_nodes']:
            if 'pnl_nodes' not in day_session_result:
                print('pnl_nodes not in day_session_result')
                day_session_result['pnl_nodes'] = []

            is_add = False
            for day_pnl_node in day_session_result['pnl_nodes']:
                if night_pnl_node.get('symbol', 'day-def-sym') == day_pnl_node.get('symbol', 'night-def-sym'):
                    # print('debug symbol %s before add %s' % (day_pnl_node['symbol'],str(day_pnl_node['net_pnl'])))
                    day_pnl_node['net_pnl'] = day_pnl_node.get('net_pnl', 0) + night_pnl_node.get('net_pnl', 0)
                    # print('debug symbol %s after add %s' % (day_pnl_node['symbol'],str(day_pnl_node['net_pnl'])))
                    is_add = True
            if not is_add:
                night_pnl_node['day_night'] = 0
                to_add.append(night_pnl_node)

        day_session_result['pnl_nodes'] += to_add

        yield day_session_result


# Clearing Function:  str_dot_date: 2017.09.30
def do_clearing(st_id, str_dot_date, cur_category, symbols, list_info, _quant_list_info, _positions,
                _current_bt_percent, _start_point, df_EOD, trade_model, **kwargs):
    global oneday_result
    bar_interval = 60  # in seconds.
    trade_logs = {}
    # Set mi_type
    mi_type = 9
    if len(symbols) > 0:
        if symbols[0].isdigit() is False:  # If not all digit, it's a futures TODO: Find a better way
            mi_type = 12  # Mi_TYPE is CTP Level 1 Futures.

    # Get Market Data
    # json.loads(cfg)
    # cfg = '{ "symbol":"`cu1712", "date": "2017.09.01", "mi_type":12, "category":0,
    # "bar_interval":60, "begin_time":90010000,"end_time":150010000}'
    bar_data = get_bar_data(symbols, str_dot_date, mi_type, cur_category, bar_interval)

    _date_str = str_dot_date[:4] + str_dot_date[5:7] + str_dot_date[8:10]
    cp_oneday = copy.deepcopy(oneday_result)
    cp_oneday['date'] = int(_date_str)
    cp_oneday['day_night'] = cur_category
    cp_oneday['progress'] = _current_bt_percent

    # Do matching logic get trade logs
    if not isinstance(bar_data, pd.DataFrame):
        print("KDB Error: %s" % bar_data)

    trade_logs = {}
    # Based on tradelist, bar data, pre_session_position, do match logic, and return a tradelog list
    if len(bar_data) > 0 and isinstance(bar_data, pd.DataFrame):
        trade_logs = do_match(st_id, cur_category, list_info, _quant_list_info, bar_data, mi_type, _positions,
                              int(_date_str), df_EOD, trade_model)
        trade_logs = tradelogs_cash_check(st_id, trade_logs, _positions, mi_type)
        if st_id in trade_logs:
            if not trade_logs[st_id]:
                trade_logs = {}
        # print(trade_logs)
        # if trade_logs:
        #    for key,value in trade_logs[st_id].items():
        #        if len(value) > 0:
        #            print(key,value[0]['trade_vol'],value[0]['trade_price'],value[0]['direction'],value[0]['open_close'])
        #    print('--------------------------------------------------------')
        # else:
        #    print(str_dot_date)

    """
    elif len(symbols) > 0:
        #print ("Can't find Market Data for %s on %s %s session"%(','.join(symbols), str_dot_date,'NIGHT' 
        if cur_category else 'DAY'))
        return _positions, cp_oneday
    """
    # Calling settlement.
    # print('clearing date:%s daynight:%d  debug before: positions: [[%s]], tradelogs:[[%s]] ' %
    # (str_dot_date,cur_category,json.dumps(_positions),json.dumps(trade_logs)))
    try:
        # _positions = settlement_wrapper.settle_oneday(st_id, str_dot_date.replace('.','-'),
        # 'NIGHT' if cur_category else 'DAY', _positions, trade_logs,_start_point)
        kdb_config = {
            'host': config.KDB_HOST,
            'port': config.KDB_PORT,
            'username': config.KDB_USER,
            'password': config.KDB_PASSWD,
        }
        last_day_night = {
            'START_POINT_DAY': 0,
            'START_POINT_NIGHT': 1
        }[_start_point]
        settle_begin = time.time()
        _positions = back_test_settle_one_day(
            kdb_config, st_id, str_dot_date, cur_category, _positions, trade_logs, last_day_night,
            mysql_config=config.mysql, **kwargs
        )
        print('settle one session time: %s' % (time.time() - settle_begin))
    except Exception as e:
        print('settle_oneday date:' + str_dot_date + ',category:' + str(cur_category) +
              ' got exception :%s' + str(e) + ',bt:' + traceback.format_exc())
        return _positions, cp_oneday

    # print('clearing date:%s daynight:%d  debug after: positions: [[%s]] ' %
    # (str_dot_date,cur_category,json.dumps(_positions)))
    # print('clearing date running:%s daynight:%d done' % (str_dot_date,cur_category))
    # cp_oneday = copy.deepcopy(oneday_result)

    cp_oneday['asset_cash'] = _positions[st_id]['asset_cash']
    cp_oneday['cash'] = _positions[st_id]['cash']
    cp_oneday['total_asset'] = _positions[st_id].get('total_asset', 0)
    cp_oneday['dividend'] = _positions[st_id].get('dividend', 0)
    if cur_category == 0:
        cp_oneday['unrealized_corp_data'] = _positions[st_id].get('unrealized_corp_data', {})

    # _session_total_pnl = 0.0
    for vsid, vs_pos_d in _positions.items():
        if 'data' not in vs_pos_d:
            print('data not found in vs_pos_d,continue..')
            continue

        for symbol, symbol_pos_d in vs_pos_d['data'].items():
            _node = copy.deepcopy(pnl_node)
            _node['date'] = _date_str
            _node['symbol'] = symbol
            _node['net_pnl'] = symbol_pos_d['symbol_net_pnl']
            _node['day_night'] = cur_category
            _node['long_price'] = symbol_pos_d['today_long_avg_price']
            _node['long_volume'] = symbol_pos_d['today_long_pos']
            _node['short_price'] = symbol_pos_d['today_short_avg_price']
            _node['short_volume'] = symbol_pos_d['today_short_pos']
            _node['dividend'] = symbol_pos_d.get('dividend', 0)
            product = symbol
            if cal_fee.get_symbol_type(symbol) == cal_fee.SymbolType.Future:
                product = cal_fee.get_symbol_product(symbol)
            _node['product'] = product

            cp_oneday['pnl_nodes'].append(_node)

            # _session_total_pnl += _node['net_pnl']

    # print("Session PNL:%f"%_session_total_pnl)
    return _positions, cp_oneday


# Read symbols from _positions, add them into _symbols if there're not in _symbols
def add_symbol_from_position(_symbols, _positions):
    for symbol, symbol_pos_d in _positions.get('data', {}).items():
        if symbol not in _symbols:  # If there's duplicated symbol in one trade_list, we only process the first one.
            _symbols.append(symbol)

    return _symbols


def add_tradelist_from_position(_night_list, _night_symbols, _day_list, _day_symbols,
                                _ready_to_close_dict, _positions, _last_tradelist):
    for _symbol, _symbol_pos_d in _positions.get('data', {}).items():
        if _symbol_pos_d['today_long_pos'] <= 0 and _symbol_pos_d['today_short_pos'] <= 0:
            continue
        if _symbol not in _night_symbols and _symbol not in _day_symbols:
            # Get close-out symbol in last_tradelisti
            in_last_tradelist = False
            for _tradelist in _last_tradelist:
                if _symbol != _tradelist[3]:
                    continue
                start_datetime = datetime.strptime(str(_tradelist[8]), '%H:%M')
                end_datetime = datetime.strptime(str(_tradelist[9]), '%H:%M')
                int_start_time = int(start_datetime.strftime("%H%M%S000"))
                int_end_time = int(end_datetime.strftime("%H%M%S000"))
                _ready_to_close_dict[_symbol] = {
                    'int_start_time': int_start_time,
                    'int_end_time': int_end_time,
                    'algo': _tradelist[7]
                }

                if int_start_time >= NIGHT_SESSION_OPEN_TIME:
                    if int_end_time > DAY_SESSION_OPEN_TIME >= int_end_time:
                        _night_symbols.append(_tradelist[3])
                        tmp_dic = {
                            "symbol": _tradelist[3],
                            "weight": 0,
                            "volume": 0,
                            "algo": _tradelist[7],
                            "start_time": int_start_time,
                            "end_time": 290100000
                        }
                        _night_list.append(tmp_dic)
                        _day_symbols.append(_tradelist[3])
                        tmp_dic = {
                            "symbol": _tradelist[3],
                            "weight": 0,
                            "volume": 0,
                            "algo": _tradelist[7],
                            "start_time": 90000000,
                            "end_time": int_end_time
                        }
                        _day_list.append(tmp_dic)
                    else:
                        _night_symbols.append(_tradelist[3])
                        tmp_dic = {
                            "symbol": _tradelist[3],
                            "weight": 0,
                            "volume": 0,
                            "algo": _tradelist[7],
                            "start_time": int_start_time,
                            "end_time": int_end_time
                        }
                        _night_list.append(tmp_dic)

                elif int_start_time > int_end_time or \
                        (int_start_time > DAY_SESSION_CLOSE_TIME > int_start_time) or \
                        (int_end_time > DAY_SESSION_CLOSE_TIME > int_end_time):
                    print("trade_list time is wrong: symbol:%s startEndTime: %s %s" %
                          (_tradelist[3], _tradelist[8], _tradelist[9]))
                else:
                    _day_symbols.append(_tradelist[3])
                    tmp_dic = {
                        "symbol": _tradelist[3],
                        "weight": 0,
                        "volume": 0,
                        "algo": _tradelist[7],
                        "start_time": int_start_time,
                        "end_time": int_end_time
                    }
                    _day_list.append(tmp_dic)
                in_last_tradelist = True
            if not in_last_tradelist:
                _day_symbols.append(_symbol)
                if _symbol in _ready_to_close_dict:
                    _day_list.append({
                        "symbol": _symbol,
                        "weight": 0,
                        "volume": 0,
                        "algo": _ready_to_close_dict[_symbol]['algo'],
                        "start_time": _ready_to_close_dict[_symbol]['int_start_time'],
                        "end_time": _ready_to_close_dict[_symbol]['int_end_time']
                    })
                else:
                    print('Warning: no tradelist found in last day when closing out remaining positions %s' % _symbol)
                    _day_list.append({
                        "symbol": _symbol,
                        "weight": 0,
                        "volume": 0,
                        "algo": 'dma',
                        "start_time": 90000000,
                        "end_time": 100000000
                    })

    return _night_list, _night_symbols, _day_list, _day_symbols, _ready_to_close_dict


# For testing only
if __name__ == '__main__':
    # if len(sys.argv) == 1:
    #    cfg = '{ "symbol":"`cu1712", "date": "2017.09.01",
    #             "mi_type":12, "category":0, "bar_interval":60,
    #             "begin_time":90010000,"end_time":150010000}'
    # else:
    #    cfg = sys.argv[1]

    # Use st_id = 24, start_date = 20170623 to do a unit testing.
    trade_list_param = {
        'strat_id': 203317,
        'task_id': 'test_demo',
        'start_date': 20170105,
        'end_date': 20170123,
        'cash': 2000000,
        'max_vol': 100
    }

    rst = back_test_tradelist_strat(trade_list_param)
    # print ('rst-----------:',rst)
    for day_data in rst:
        cur_date = day_data['date']
        sum_pnl = 0

        for symbol_data in day_data['pnl_nodes']:
            sum_pnl += symbol_data['net_pnl']
            # print('%s,%d,%f,%f'%(symbol_data['symbol'],symbol_data['long_volume'],
            # symbol_data['long_price'],symbol_data['net_pnl']))
        print('settle_oneday_debug date:%s,daynight:%d,sum_pnl:%f,progress:%d' %
              (cur_date, day_data['day_night'], sum_pnl, day_data['progress']))

# -*-coding:utf-8-*-

import json
import datetime

import requests
from tornado import gen
from sqlalchemy import or_

from db import session
from config import config, ProductConfigIDC
from service.basehandler import BaseHandler, CurrentUserMixin, JsonPayloadMixin
from service.cash_io.models import CashIoRequest, AccountChangeRequest
from service.back_test.models import VStrategyAccountDetail
from log import logger
from kdb_query import KdbQuery
from utils import notify_operation_wechat
from extensions import sentry
from service.cash_io.helper import send_cash_change_to_live_server
from cron.operator_handler_task import cashio_approved_task


class GetPendingRequests(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):

        # check user group
        sessionid = self.get_cookie('sessionid')
        user_ret_d = requests.get('http://127.0.0.1/api/v1/user', cookies={'sessionid': sessionid}).json()

        if user_ret_d['code'] != 0:
            logger.error('cahsio audit API handler : access authenticate svc fail,ret code:' + str(user_ret_d['code']))
            self.json_response({'code': 401, 'error': 'user not logined'})
            return False

        # user_id = user_ret_d['data']['id']
        user_name = user_ret_d['data']['username']

        is_operation_group = False

        for group_d in user_ret_d['data']['groups']:
            if group_d['name'] == 'operation' or group_d['name'] == 'all':
                is_operation_group = True
                break

        if not is_operation_group:
            logger.error(
                'user %s is not in operation group,user interface return:[%s]' % (user_name, json.dumps(user_ret_d)))
            self.json_response({'code': 1004, 'error': 'user dont have privilege to audit'})
            return False

        ret_l = []

        sc = session()
        reqs = sc.query(CashIoRequest).filter(CashIoRequest.status == 'PENDING').order_by(
            CashIoRequest.request_time.desc())
        for req in reqs:

            op_type = 'unknown'
            if req.operation_type == 'CASH_IN':
                op_type = '入金'
            elif req.operation_type == 'CASH_OUT':
                op_type = '出金'

            for item in req.strategy_detail:
                item['operation_type'] = op_type

            if isinstance(req.strategy_detail, list) and len(req.strategy_detail) > 0:
                id_no = req.strategy_detail[0].get("strategy_id", "")
            else:
                id_no = ""

            item_d = {
                'id': req.id,
                'user_id': req.user_id,
                'user_name': req.user_name,
                'portfolio_name': req.protfolio_name,
                'strategy_name': req.st_or_group_name,
                'operation_type': op_type,
                'io_notional_amount': req.io_notional_amount,
                'actual_io_notional_amount': req.actual_io_notional_amount,
                'currency': req.currency,
                'request_time': req.request_time.strftime('%Y-%m-%d %H:%M:%S'),
                'strategies': req.strategy_detail,
                'id_no': id_no
            }

            ret_l.append(item_d)

        sc.close()

        data = {
            'code': 0, 'data': {
                'headers': [
                    {
                        'title': '策略ID',
                        'prop': 'id_no'
                    },
                    {
                        'title': '投资组合名称',
                        'prop': 'portfolio_name'
                    },
                    {
                        'title': '策略名称',
                        'prop': 'strategy_name'
                    },
                    {
                        'title': '资金量',
                        'prop': 'actual_io_notional_amount'
                    },
                    {
                        'title': '面值',
                        'prop': 'io_notional_amount'
                    },
                    {
                        'title': '类型',
                        'prop': 'operation_type'
                    },
                    {
                        'title': '币种',
                        'prop': 'currency'
                    },
                    {
                        'title': '申请人',
                        'prop': 'user_name'
                    },
                    {
                        'title': '申请时间',
                        'prop': 'request_time'
                    },
                ],
                'rows': ret_l
            }
        }

        self.write(json.dumps(data, ensure_ascii=False))


class GetFinishedRequests(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):

        # check user group
        sessionid = self.get_cookie('sessionid')
        user_ret_d = requests.get('http://127.0.0.1/api/v1/user', cookies={'sessionid': sessionid}).json()

        if user_ret_d['code'] != 0:
            logger.error('cahsio audit API handler : access authenticate svc fail,ret code:' + str(user_ret_d['code']))
            self.json_response({'code': 401, 'error': 'user not logined'})
            return False

        # user_id = user_ret_d['data']['id']
        user_name = user_ret_d['data']['username']

        is_operation_group = False

        for group_d in user_ret_d['data']['groups']:
            if group_d['name'] == 'operation' or group_d['name'] == 'all':
                is_operation_group = True
                break

        if not is_operation_group:
            logger.error('user %s is not in operation group' % (user_name))
            self.json_response({'code': 1004, 'error': 'user dont have privilege to audit'})
            return False

        ret_l = []

        sc = session()
        reqs = sc.query(CashIoRequest).filter(
            or_(CashIoRequest.status == 'APPROVED', CashIoRequest.status == 'REJECTED')).order_by(
            CashIoRequest.audit_time.desc())
        for req in reqs:

            op_type = 'unknown'
            if req.operation_type == 'CASH_IN':
                op_type = '入金'
            elif req.operation_type == 'CASH_OUT':
                op_type = '出金'

            for item in req.strategy_detail:
                item['operation_type'] = op_type

            if isinstance(req.strategy_detail, list) and len(req.strategy_detail) > 0:
                id_no = req.strategy_detail[0].get("strategy_id", "")
            else:
                id_no = ""

            item_d = {
                'id': req.id,
                'user_id': req.user_id,
                'user_name': req.user_name,
                'portfolio_name': req.protfolio_name,
                'strategy_name': req.st_or_group_name,
                'operation_type': op_type,
                'actual_io_notional_amount': req.actual_io_notional_amount,
                'io_notional_amount': req.io_notional_amount,
                'currency': req.currency,
                'request_time': req.request_time.strftime('%Y-%m-%d %H:%M:%S'),
                'status': req.status,
                'audit_time': req.audit_time.strftime('%Y-%m-%d %H:%M:%S'),
                'auditor': req.auditor,
                'opinion': req.opinion,
                'strategies': req.strategy_detail,
                'id_no': id_no
            }

            ret_l.append(item_d)

        sc.close()

        data = {
            'code': 0, 'data': {
                'headers': [
                    {
                        'title': '策略ID',
                        'prop': 'id_no'
                    },
                    {
                        'title': '投资组合名称',
                        'prop': 'portfolio_name'
                    },
                    {
                        'title': '策略名称',
                        'prop': 'strategy_name'
                    },
                    {
                        'title': '资金量',
                        'prop': 'actual_io_notional_amount'
                    },
                    {
                        'title': '面值',
                        'prop': 'io_notional_amount'
                    },
                    {
                        'title': '类型',
                        'prop': 'operation_type'
                    },
                    {
                        'title': '币种',
                        'prop': 'currency'
                    },
                    {
                        'title': '申请人',
                        'prop': 'user_name'
                    },
                    {
                        'title': '申请时间',
                        'prop': 'request_time'
                    },
                    {
                        'title': '审核结果',
                        'prop': 'status'
                    },
                    {
                        'title': '审核时间',
                        'prop': 'audit_time'
                    },
                    {
                        'title': '审核人',
                        'prop': 'auditor'
                    },
                    {
                        'title': '审核意见',
                        'prop': 'opinion'
                    },
                ],
                'rows': ret_l
            }
        }
        self.write(json.dumps(data, ensure_ascii=False))


class Audit(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):

        # check user group
        session_id = self.get_cookie('sessionid')
        user_ret_d = requests.get('http://127.0.0.1/api/v1/user', cookies={'sessionid': session_id}).json()

        if user_ret_d['code'] != 0:
            self.json_response({'code': 401, 'error': 'user not logined'})
            return False

        user_name = user_ret_d['data']['username']

        is_operation_group = False

        for group_d in user_ret_d['data']['groups']:
            if group_d['name'] == 'operation' or group_d['name'] == 'all':
                is_operation_group = True
                break

        if not is_operation_group:
            self.json_response({'code': 1004, 'error': 'user dont have privilege to audit'})
            return False

        req_json = json.loads(self.request.body.decode('utf-8'))
        if ('id' not in req_json) or ('result' not in req_json) or ('opinion' not in req_json):
            self.json_response({'code': 1008, 'error': 'parameter wrong'})
            return False

        _ids = req_json['id']
        _result = req_json['result']
        _opinion = req_json['opinion']
        is_live_request = req_json.get('is_live_request', False)

        if _result == 'approve':
            audit_status = 'APPROVED'
        elif _result == 'reject':
            audit_status = 'REJECTED'
        else:
            self.json_response({'code': 1008, 'error': 'parameter wrong'})
            return False

        _ids_l = [int(x) for x in _ids.split(',')]

        _dt = datetime.datetime.now()

        sc = session()
        try:
            cash_change_list = list()
            if audit_status == 'APPROVED':
                # default effect date is next trading day ,if operator do not assign effect date manually
                if "effect_date" not in req_json:
                    kdb = KdbQuery()
                    _dt = datetime.datetime.now()
                    cur_date = _dt.strftime('%Y%m%d')
                    today_is_trading_day, next_trading_day, next_next_trading_day = kdb.get_today_next_trading_date(
                        cur_date)
                    effect_date = next_trading_day
                else:
                    effect_date = req_json["effect_date"]

                rows = sc.query(CashIoRequest).filter(CashIoRequest.id.in_(_ids_l), CashIoRequest.status == 'PENDING')
                for row in rows:
                    for item in row.strategy_detail:
                        io_item = VStrategyAccountDetail()
                        io_item.vstrategy_id = item['vstrategy_id']
                        io_item.portfolio_id = row.protfolio_id
                        io_item.account = item['account']
                        io_item.amount = item['io_notional_amount']
                        io_item.actual_amount = item['actual_io_notional_amount']
                        io_item.exchange = item['exchange']
                        io_item.trading_date = effect_date
                        io_item.is_live = is_live_request

                        sc.add(io_item)
                        cash_change_list.append({
                            'type': 12,
                            'data': {
                                'vs_id': item['vstrategy_id'],
                                'adj_available_cash': item['io_notional_amount']
                            }
                        })

            sc.query(CashIoRequest).filter(CashIoRequest.id.in_(_ids_l), CashIoRequest.status == 'PENDING').update(
                {
                    'status': audit_status,
                    'audit_time': _dt,
                    'auditor': user_name,
                    'opinion': _opinion,
                }, synchronize_session=False
            )
            sc.commit()
            for change in cash_change_list:
                cashio_approved_task.delay(effect_date, change["data"]['vs_id'], user_name)

            # send to live server
            if is_live_request and cash_change_list and isinstance(config, ProductConfigIDC):
                send_cash_change_to_live_server(cash_change_list=cash_change_list)

        except Exception as e:
            sentry.captureException()
            sc.rollback()
        finally:
            sc.close()

        data = {
            'code': 0,
            'error': ''
        }
        self.write(json.dumps(data))


class AppendCash(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        pf_id = int(self.get_argument('pf_id', 0))
        vs_id = int(self.get_argument('vs_id', 0))
        group_id = int(self.get_argument('group_id', 0))

        business = ''
        if self.is_stock_page() and self.is_stock_group():
            business = 'stock'

        if self.is_future_page() and self.is_future_group():
            business = 'future'

        self.json_response({
            'code': 0,
            'data': CashIoRequest.query_record(self.current_user['id'], pf_id, vs_id, group_id, business=business)
        })
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        payload = self.get_payload()
        pf_id = payload.get('pf_id', 0)
        vs_id = payload.get('vs_id', 0)
        group_id = payload.get('group_id', 0)
        account = payload.get('account', [])
        if not CashIoRequest.append_cash2(self.current_user, pf_id, vs_id, group_id, account):
            self.json_response({'code': 1266, 'error': 'Repeated requests'})
            return False
        notify_operation_wechat('有新的出入金提交，请尽快审核')
        self.json_response({'code': 0, 'data': 1})
        return True


class AccountChange(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        user_id = self.current_user['id']
        pf_id = int(self.get_argument('pf_id', 0))
        vs_id = int(self.get_argument('vs_id', 0))
        group_id = int(self.get_argument('group_id', 0))
        self.json_response({
            'code': 0,
            'data': AccountChangeRequest.query_change_list(user_id, pf_id, vs_id, group_id)
        })
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        payload = self.get_payload()
        pf_id = payload.get('pf_id', 0)
        vs_id = payload.get('vs_id', 0)
        group_id = payload.get('group_id', 0)
        account = payload.get('account', [])
        info = AccountChangeRequest.query_account_info(vs_id, group_id)
        if info['symbol_type'] != 'Future':
            self.json_response({'code': 1260, 'error': "Modify account only support future"})
            return False

        if not AccountChangeRequest.submit_change(self.current_user, pf_id, vs_id, group_id, account):
            self.json_response({'code': 1266, 'error': 'Repeated requests'})
            return False
        notify_operation_wechat('有新的账户更换申请，请尽快审核')
        self.json_response({'code': 0, 'data': 1})
        return True


class AccountChangeOperation(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):

        # check user group
        sessionid = self.get_cookie('sessionid')
        user_ret_d = requests.get('http://127.0.0.1/api/v1/user', cookies={'sessionid': sessionid}).json()

        if user_ret_d['code'] != 0:
            logger.error('cahsio audit API handler : access authenticate svc fail,ret code:' + str(user_ret_d['code']))
            self.json_response({'code': 401, 'error': 'user not logined'})
            return False

        user_id = user_ret_d['data']['id']
        user_name = user_ret_d['data']['username']

        is_operation_group = False

        for group_d in user_ret_d['data']['groups']:
            if group_d['name'] == 'operation' or group_d['name'] == 'all':
                is_operation_group = True
                break

        if not is_operation_group:
            logger.error('user %s is not in operation group' % (user_name))
            self.json_response({'code': 1004, 'error': 'user dont have privilege to audit'})
            return False

        _type = self.get_argument('type')
        if not (_type == 'pending' or _type == 'finished'):
            logger.error('type parameter unknown:%s' % (_type))
            self.json_response({'code': 1008, 'error': 'type parameter unknown'})
            return False

        ret_l = []

        sc = session()
        if _type == 'pending':
            reqs = sc.query(AccountChangeRequest).filter(AccountChangeRequest.status == 'PENDING').order_by(
                AccountChangeRequest.request_time.desc())
        elif _type == 'finished':
            reqs = sc.query(AccountChangeRequest).filter(AccountChangeRequest.status != 'PENDING',
                                                         AccountChangeRequest.status != 'UNKNOWN').order_by(
                AccountChangeRequest.audit_time.desc())

        for req in reqs:

            item_d = {
                'id': req.id,
                'user_id': req.user_id,
                'user_name': req.user_name,
                'pf_name': req.pf_name,
                'strategy_name': req.st_or_group_name,
                'request_time': req.request_time.strftime('%Y-%m-%d %H:%M:%S'),
                'strategies': req.detail
            }

            if _type == 'finished':
                item_d.update({
                    'status': req.status,
                    'audit_time': req.audit_time.strftime('%Y-%m-%d %H:%M:%S'),
                    'auditor': req.auditor,
                    'opinion': req.opinion,
                })

            ret_l.append(item_d)

        sc.close()

        headers_l = [
            {
                'title': '投资组合名',
                'prop': 'pf_name'
            },
            {
                'title': '策略名称',
                'prop': 'strategy_name'
            },
            {
                'title': '申请人',
                'prop': 'user_name'
            },
            {
                'title': '申请时间',
                'prop': 'request_time'
            },
        ]

        if _type == 'finished':
            headers_l.extend([
                {
                    'title': '审核结果',
                    'prop': 'status'
                },
                {
                    'title': '审核时间',
                    'prop': 'audit_time'
                },
                {
                    'title': '审核人',
                    'prop': 'auditor'
                },
                {
                    'title': '审核意见',
                    'prop': 'opinion'
                },
            ])

        data = {
            'code': 0, 'data': {
                'headers': headers_l,
                'rows': ret_l
            }
        }

        self.write(json.dumps(data, ensure_ascii=False))

    @gen.coroutine
    def post(self, *args, **kwargs):

        # check user group
        sessionid = self.get_cookie('sessionid')
        user_ret_d = requests.get('http://127.0.0.1/api/v1/user', cookies={'sessionid': sessionid}).json()

        if user_ret_d['code'] != 0:
            logger.error('cahsio audit API handler : access authenticate svc fail,ret code:' + str(user_ret_d['code']))
            self.json_response({'code': 401, 'error': 'user not logined'})
            return False

        user_id = user_ret_d['data']['id']
        user_name = user_ret_d['data']['username']

        is_operation_group = False

        for group_d in user_ret_d['data']['groups']:
            if group_d['name'] == 'operation' or group_d['name'] == 'all':
                is_operation_group = True
                break

        if not is_operation_group:
            logger.error('user %s is not in operation group' % (user_name))
            self.json_response({'code': 1004, 'error': 'user dont have privilege to audit'})
            return False

        req_json = json.loads(self.request.body.decode('utf-8'))

        if ('id' not in req_json) or ('result' not in req_json) or ('opinion' not in req_json):
            self.json_response({'code': 1008, 'error': 'parameter wrong'})
            return False

        _ids = req_json['id']
        _result = req_json['result']
        _opinion = req_json['opinion']

        audit_status = ''
        if _result == 'approve':
            audit_status = 'APPROVED'
        elif _result == 'reject':
            audit_status = 'REJECTED'
        else:
            return False

        _ids_l = [int(x) for x in _ids.split(',')]

        _dt = datetime.datetime.now()

        sc = session()

        try:
            effect_date = '1970-01-01'
            if audit_status == 'APPROVED':
                # default effect date is next trading day ,if operator do not assign effect date manually
                if "effect_date" not in req_json:
                    kdb = KdbQuery()
                    _dt = datetime.datetime.now()
                    cur_date = _dt.strftime('%Y%m%d')
                    today_is_trading_day, next_trading_day, next_next_trading_day = kdb.get_today_next_trading_date(
                        cur_date)
                    effect_date = next_trading_day
                else:
                    effect_date = req_json["effect_date"]

            sc.query(AccountChangeRequest).filter(AccountChangeRequest.id.in_(_ids_l),
                                                  AccountChangeRequest.status == 'PENDING').update(
                {
                    'status': audit_status,
                    'audit_time': _dt,
                    'effective_date': effect_date,
                    'auditor': user_name,
                    'opinion': _opinion,
                }, synchronize_session=False
            )
            sc.commit()
        except:
            sc.rollback()
            raise
        finally:
            sc.close()

        data = {
            'code': 0,
            'error': ''
        }
        self.write(json.dumps(data))

# -*-coding:utf-8-*-


import datetime
from db import session
from sqlalchemy.sql import func
from sqlalchemy import BigInteger, Column, Date, DateTime, Enum, Float, Index, Integer, String, Time, text, JSON
from db import ModelBase
from log import logger


def query_strategy_info(pf_id, vs_id, group_id):
    sc = session()
    st_id, id_no, name, pf_name = 0, '0', '', ''
    stmt = "select name from strategy_portfolio where id=%d" % pf_id
    row = sc.execute(stmt).first()
    if row:
        pf_name = row[0]
    if group_id > 0:
        stmt = "select id, id_no, name from strategy where id=%d" % group_id
        row = sc.execute(stmt).first()
        if row:
            st_id, id_no, name = row[0], row[1], row[2]
    else:
        stmt = "select st.id as st_id, st.id_no, st.name from vstrategies as vs " \
               "inner join strategy as st on vs.strategy_id = st.id where vs.id=%d" % vs_id
        row = sc.execute(stmt).first()
        if row:
            st_id, id_no, name = row[0], row[1], row[2]
    result = {"pf_id": pf_id, "pf_name": pf_name,
              "st_id": st_id, "id_no": id_no, "name": name}
    sc.close()
    return result


def check_vstrategy(detail, vs_id):
    for item in detail:
        if item["vstrategy_id"] == vs_id:
            return True
    return False


def get_vs_account(pf_id, vs_id):
    result = []
    sc = session()
    stmt = "select account, exchange from vstrategy_account_detail " \
           "where portfolio_id=%d and vstrategy_id=%d" % (pf_id, vs_id)
    rows = sc.execute(stmt)
    for row in rows:
        result.append({"account": row[0], "exchange": row[1]})
    sc.close()
    return result


class CashIoRequest(ModelBase):
    __tablename__ = 'cash_io_request'

    id = Column(Integer, primary_key=True)
    user_id = Column(String(56), nullable=False, index=True, server_default=text("''"))
    user_name = Column(String(56), nullable=False, server_default=text("''"))
    protfolio_id = Column(Integer, nullable=False, server_default=text("'0'"))
    protfolio_name = Column(String(128), nullable=False, server_default=text("''"))
    st_or_group_id = Column(Integer, nullable=False, server_default=text("'0'"))
    st_or_group_name = Column(String(128), nullable=False, server_default=text("''"))
    strategy_detail = Column(JSON)
    account_info = Column(JSON)
    actual_io_notional_amount = Column(String(20), nullable=False, server_default=text("''"))
    io_notional_amount = Column(String(20), nullable=False, server_default=text("''"))
    operation_type = Column(Enum('UNKNOWN', 'CASH_IN', 'CASH_OUT'), nullable=False, server_default=text("'UNKNOWN'"))
    currency = Column(Enum('UNKNOWN', 'CNY', 'USD'), nullable=False, server_default=text("'UNKNOWN'"))
    request_time = Column(DateTime, nullable=False, server_default=text("'1970-01-01 00:00:01'"))
    status = Column(Enum('UNKNOWN', 'PENDING', 'APPROVED', 'REJECTED'), nullable=False,
                    server_default=text("'UNKNOWN'"))
    audit_time = Column(DateTime, nullable=False, server_default=text("'1970-01-01 00:00:01'"))
    auditor = Column(String(56), nullable=False, server_default=text("''"))
    opinion = Column(String(1024), nullable=False, server_default=text("''"))
    ctime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    utime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))

    @staticmethod
    def append_cash2(user_info, pf_id, vs_id, group_id, request):
        from service.back_test.models import Strategy, StrategyPortfolio, VStrategies
        sc = session()
        user_id = str(user_info['id'])
        pending_request = sc.query(
            CashIoRequest
        ).filter(
            CashIoRequest.user_id == user_id,
            CashIoRequest.protfolio_id == int(pf_id),
            CashIoRequest.status == 'PENDING'
        )
        if group_id > 0:
            pending_request = pending_request.filter(
                CashIoRequest.st_or_group_id == group_id
            ).first()
            if pending_request:
                return False
        else:
            for req in pending_request:
                if any([l['vstrategy_id'] == vs_id for l in req.strategy_detail]):
                    return False

        portfolio_name = sc.query(StrategyPortfolio.name).filter(StrategyPortfolio.id == int(pf_id)).first()[0]
        if group_id > 0:
            st = sc.query(
                Strategy.id.label('id'),
                Strategy.id_no.label('id_no'),
                Strategy.name.label('name'),
            ).filter(Strategy.id == group_id).first()
        else:
            st = sc.query(
                Strategy.id.label('id'),
                Strategy.id_no.label('id_no'),
                Strategy.name.label('name'),
            ).join(
                VStrategies, VStrategies.strategy_id == Strategy.id
            ).filter(
                VStrategies.id == vs_id
            ).first()

        strategy = {
            'pf_id': pf_id,
            'pf_name': portfolio_name,
            'st_id': st.id,
            'id_no': st.id_no,
            'name': st.name
        }
        total_cash = 0
        total_actual = 0
        account_info = {}
        request_account_info = []
        details = []

        for item in request:
            sub_cash = float(item['cash_value'])
            sub_actual = float(item['actual_cash_value'])
            total_cash += sub_cash
            total_actual += sub_actual
            acc_info = account_info.setdefault(item['account'], {
                'io_notional_amount': 0,
                'actual_io_notional_amount': 0,
                'exchanges': [],
            })
            acc_info['io_notional_amount'] += sub_cash
            acc_info['actual_io_notional_amount'] += sub_actual
            acc_info['exchanges'].append(item['exchange'])
            if sub_cash >= 0:
                sub_direct = 'CASH_IN'
            else:
                sub_direct = 'CASH_OUT'
            request_account_info.append({
                'account': item['account'],
                'exchange': item['exchange'],
                'io_notional_amount': sub_cash,
                'actual_io_notional_amount': sub_actual,
                'operation_type': sub_direct

            })

        if group_id > 0:
            _vstrategies = sc.query(VStrategies).filter(
                VStrategies.portfolio_id == pf_id,
                VStrategies.group_id == group_id
            )
            total_weight = sc.query(func.sum(VStrategies.strategy_weight)).filter(
                VStrategies.portfolio_id == pf_id,
                VStrategies.group_id == group_id
            ).first()
            if total_weight and total_weight[0]:
                total_weight = float(total_weight[0])
            else:
                total_weight = 1
            for vs in _vstrategies:
                vs_accounts = {}
                for acc_d in VStrategies.normalization_symbols_accounts(vs.symbols_accounts_detail):
                    if acc_d['account'] not in vs_accounts:
                        vs_accounts[acc_d['account']] = {
                            'exchanges': [acc_d['exchange']],
                        }
                    else:
                        vs_accounts[acc_d['account']]['exchanges'].append(acc_d['exchange'])

                for acc, acc_d in vs_accounts.items():
                    if acc not in account_info:
                        continue
                    acc_info = account_info[acc]
                    if acc_info['io_notional_amount'] >= 0:
                        operation_type = 'CASH_IN'
                    else:
                        operation_type = 'CASH_OUT'
                    details.append({
                        'sid': strategy['st_id'],
                        'strategy_id': strategy['id_no'],
                        'vstrategy_id': vs.id,
                        'operation_type': operation_type,
                        'account': acc,
                        'exchange': acc_d['exchanges'][0],
                        'io_notional_amount': acc_info['io_notional_amount'] * float(vs.strategy_weight) / total_weight,
                        'actual_io_notional_amount': acc_info['actual_io_notional_amount'] * float(
                            vs.strategy_weight) / total_weight,
                    })
        else:
            for acc, acc_d in account_info.items():
                if acc_d['io_notional_amount'] >= 0:
                    operation_type = 'CASH_IN'
                else:
                    operation_type = 'CASH_OUT'
                details.append({
                    'sid': strategy['st_id'],
                    'strategy_id': strategy['id_no'],
                    'vstrategy_id': vs_id,
                    'operation_type': operation_type,
                    'account': acc,
                    'exchange': acc_d['exchanges'][0],
                    'io_notional_amount': acc_d['io_notional_amount'],
                    'actual_io_notional_amount': acc_d['actual_io_notional_amount'],
                })

        if total_cash >= 0:
            tot_direct = 'CASH_IN'
        else:
            tot_direct = 'CASH_OUT'

        if strategy and details:
            now_time = datetime.datetime.now()
            add_obj = CashIoRequest(
                user_id=user_id,
                user_name=user_info['username'],
                protfolio_id=pf_id,
                protfolio_name=strategy['pf_name'],
                st_or_group_id=group_id,
                st_or_group_name=strategy['name'],
                account_info=request_account_info,
                strategy_detail=details,
                io_notional_amount=str(total_cash),
                actual_io_notional_amount=str(total_actual),
                operation_type=tot_direct,
                currency=request[0]['currency'],
                request_time=now_time,
                status='PENDING',
                ctime=now_time,
                utime=now_time)
            sc.add(add_obj)
            sc.commit()
        sc.close()
        return True

    @staticmethod
    def query_record(user_id, pf_id, vs_id, group_id, **kwargs):
        result = []
        sc = session()
        business = kwargs.get('business', '')
        need_obj = sc.query(
            CashIoRequest
        ).filter(
            CashIoRequest.protfolio_id == pf_id
        )
        if not business:
            need_obj = need_obj.filter(CashIoRequest.user_id == str(user_id))
        for obj in need_obj:
            query_group = (group_id > 0 and obj.st_or_group_id == group_id)
            query_st = (group_id == 0 and check_vstrategy(obj.strategy_detail, vs_id))

            if not (query_group or query_st):
                continue

            for item in obj.strategy_detail:
                if query_st and (int(item['vstrategy_id']) != int(vs_id)):
                    continue
                result.append({
                    'st_name': obj.st_or_group_name,
                    'account': item['account'],
                    'exchange': item['exchange'],
                    'cash_value': item['io_notional_amount'],
                    'actual_cash_value': item['actual_io_notional_amount'],
                    'currency': obj.currency,
                    'create_time': obj.request_time.strftime('%Y-%m-%d %X'),
                    'status': obj.status,
                    'opinion': obj.opinion,
                })
        sc.close()
        return result


class AccountChangeRequest(ModelBase):
    __tablename__ = 'account_change_request'

    id = Column(Integer, primary_key=True)
    user_id = Column(String(56), nullable=False)
    user_name = Column(String(64), nullable=False)
    pf_id = Column(Integer, nullable=False, server_default=text("'0'"))
    pf_name = Column(String(56), nullable=False, server_default=text("''"))
    st_or_group_id = Column(Integer, nullable=False, server_default=text("'0'"))
    st_or_group_name = Column(String(128), nullable=False, server_default=text("''"))
    detail = Column(JSON)
    request_time = Column(DateTime, nullable=False, server_default=text("'1970-01-01 00:00:01'"))
    status = Column(Enum('UNKNOWN', 'PENDING', 'APPROVED', 'REJECTED', 'SUCC', 'FAIL'), nullable=False,
                    server_default=text("'UNKNOWN'"))
    auditor = Column(String(56), nullable=False, server_default=text("''"))
    audit_time = Column(DateTime, nullable=False, server_default=text("'1970-01-01 00:00:01'"))
    effective_date = Column(Date, nullable=False, server_default=text("'1970-01-01'"))
    opinion = Column(String(1024), nullable=False, server_default=text("''"))
    fail_reason = Column(String(256), nullable=False, server_default=text("''"))
    ctime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP"))
    utime = Column(DateTime, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))

    @staticmethod
    def check_account(result, account):
        for item in result:
            if item["account"] == account:
                return True
        return False

    @staticmethod
    def get_protfolio_detail(pf_id, vs_id, group_id, account):
        result = []
        sc = session()
        stmt = "select st.id as st_id, st.id_no, vs.id as vs_id from vstrategies as vs " \
               "inner join strategy as st on vs.strategy_id = st.id where "
        if group_id > 0:
            stmt += "vs.portfolio_id=%d and vs.group_id=%d" % (pf_id, group_id)
        else:
            stmt += "vs.portfolio_id=%d and vs.id=%d" % (pf_id, vs_id)
        rows = sc.execute(stmt)
        for row in rows:
            account_info = get_vs_account(pf_id, row[2])
            for item in account:
                if AccountChangeRequest.check_account(account_info, item["original_account"]):
                    result.append({"sid": row[0], "strategy_id": row[1], "vstrategy_id": row[2],
                                   "original_account": item["original_account"],
                                   "target_account": item["target_account"]})
        sc.close()
        return result

    @staticmethod
    def submit_change(user_info, pf_id, vs_id, group_id, request):
        sc = session()
        user_id = user_info['id']
        find_obj = sc.query(AccountChangeRequest).filter(
            AccountChangeRequest.user_id == user_id, AccountChangeRequest.pf_id == pf_id,
            AccountChangeRequest.status == 'PENDING')
        if group_id > 0:
            find_obj = find_obj.filter(AccountChangeRequest.st_or_group_id == group_id).first()
            if find_obj:
                return False
        else:
            for obj in find_obj:
                if check_vstrategy(obj.detail, vs_id):
                    return False

        strategy = query_strategy_info(pf_id, vs_id, group_id)
        if strategy:
            now_time = datetime.datetime.now()
            add_obj = AccountChangeRequest(
                user_id=user_id, user_name=user_info['username'],
                pf_id=pf_id, pf_name=strategy['pf_name'],
                st_or_group_id=group_id, st_or_group_name=strategy['name'],
                detail=AccountChangeRequest.get_protfolio_detail(pf_id, vs_id, group_id, request),
                request_time=now_time, status='PENDING',
                ctime=now_time, utime=now_time)
            sc.add(add_obj)
            sc.commit()
        sc.close()
        return True

    @staticmethod
    def query_change_list(user_id, pf_id, vs_id, group_id):
        result = []
        sc = session()
        fmt_timestamp = lambda dt: dt.strftime('%Y-%m-%d %X')
        all_obj = sc.query(AccountChangeRequest).filter(AccountChangeRequest.user_id == user_id,
                                                        AccountChangeRequest.pf_id == pf_id)
        for obj in all_obj:

            query_group = (group_id > 0 and obj.st_or_group_id == group_id)
            query_st = (group_id == 0 and check_vstrategy(obj.detail, vs_id))

            if not (query_group or query_st):
                continue

            for item in obj.detail:
                if query_st and (int(item['vstrategy_id']) != int(vs_id)):
                    continue

                fail_reason = obj.fail_reason
                if obj.status == 'APPROVED':
                    fail_reason = '下一个交易日生效'

                result.append({"st_name": obj.st_or_group_name, "create_time": fmt_timestamp(obj.request_time),
                               "original_account": item["original_account"],
                               "target_account": item["target_account"],
                               "status": obj.status, "opinion": obj.opinion, "fail_reason": fail_reason})

        sc.close()
        return result

    @staticmethod
    def query_account_info(vs_id, group_id):
        sc = session()
        result = {"total_pos": 0, "symbol_type": 'Stock'}
        stmt1 = "select sum(today_long_pos), sum(today_short_pos) from vs_positions where vstrategy_id=%d " \
                "and (settle_date, daynight)=(select settle_date, daynight from vs_base where vstrategy_id=%d " \
                "order by settle_date desc, daynight asc limit 0, 1)" % (vs_id, vs_id)
        # row = sc.execute(stmt1).first()
        # if row[0]:
        #    result['total_pos'] = int(row[0]) + int(row[1])
        if group_id > 0:
            stmt1 = "select id from vstrategies where status=15 and group_id = %d limit 0, 1" % group_id
            row = sc.execute(stmt1).first()
            if row:
                vs_id = row[0]

        stmt2 = "select symbol_type from vs_positions where vstrategy_id=%d limit 0, 1" % vs_id
        row = sc.execute(stmt2).first()
        if row:
            result['symbol_type'] = str(row[0])
        else:
            # query trade logs if no positions found
            stmt3 = "select * from trade_logs where (entrust_status='p' or entrust_status='c') and log_type=3  and vstrategy_id=%d limit 0,1" % vs_id
            row = sc.execute(stmt3).first()
            if row:
                if not row.symbol.isdigit():
                    result['symbol_type'] = 'Future'

        sc.close()
        return result

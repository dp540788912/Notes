import uuid
import json
from db import session
from config import RedisCache0
from constant import RedisKeyConstant


def send_cash_change_to_live_server(cash_change_list):
    rds = RedisCache0()
    queue_key = RedisKeyConstant.OssACmd.value
    # queue_key = RedisKeyConstant.TestOssACmd.value
    sc = session()
    deploy_confs_query = "select id,host from deploy_confs where vstrategy_id={vs_id} and day_night=0 and valid=1"
    for item in cash_change_list:
        vs_id = item['data']['vs_id']
        sql_query = deploy_confs_query.format(vs_id=vs_id)
        cursor = sc.execute(sql_query).fetchone()
        if cursor:
            key = queue_key.format(server_ip=cursor['host'])
            item['data']['process_id'] = cursor['id']
            item['seq'] = uuid.uuid4().int & ((1 << 16) - 1)
            rds.rpush(key, json.dumps(item))

            # also send to merge strategy
            # sql_query = "select merge_vstrategy_id from pre_strategy_confs where vstrategy_id={vs_id}".format(
            #     vs_id=vs_id)
            # cursor = sc.execute(sql_query).fetchone()
            # if cursor:
            #     merge_vs_id = cursor['merge_vstrategy_id']
            #     if merge_vs_id:
            #         sql_query = deploy_confs_query.format(vs_id=merge_vs_id)
            #         cursor = sc.execute(sql_query).fetchone()
            #         if cursor:
            #             key = queue_key.format(server_ip=cursor['host'])
            #             item['data']['process_id'] = cursor['id']
            #             item['data']['vs_id'] = merge_vs_id
            #             item['seq'] = uuid.uuid4().int & ((1 << 16) - 1)
            #             rds.rpush(key, json.dumps(item))
    sc.close()


def send_cash_change_to_live_server_test():
    items = [
        {
            'type': 12,
            'data': {
                'vs_id': 2284,
                'adj_available_cash': -200000
            }
        }
    ]
    send_cash_change_to_live_server(cash_change_list=items)


if __name__ == '__main__':
    # send_cash_change_to_live_server_test()
    pass

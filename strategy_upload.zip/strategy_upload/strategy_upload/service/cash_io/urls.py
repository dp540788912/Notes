# -*-coding:utf-8-*-

from service.cash_io.handlers import *

urls = [
    (r'/api/v1/platform/cashio/get_pending_requests$', GetPendingRequests),
    (r'/api/v1/platform/cashio/get_finished_requests$', GetFinishedRequests),
    (r'/api/v1/platform/cashio/audit$', Audit),
    (r'/api/v1/platform/cashio$', AppendCash),

    (r'/api/v1/platform/account_change$', AccountChange),
    (r'/api/v1/platform/cashio/account_change_operation', AccountChangeOperation),
]

import datetime

from service.basehandler import BaseHandler, CurrentUserMixin, JsonPayloadMixin
from extensions import sentry
from constant import APIResponseCode
from models.strategy import VsT0Relation
from data_brick.strategy import VsBasicData
from db import session_context
from utility.db_util import TradeCalendar
from utility.func_util import login_required
from config import config

from .helper import send_vs_trading_status_to_live_server,get_vs_backtest_info


class VsTradingStatusHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return
        payload = self.get_payload()
        try:
            process_id = payload['process_id']
            trading_status = payload['trading_status']
        except Exception as e:
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'error': str(e)
            })
            return

        try:
            success = send_vs_trading_status_to_live_server(process_id=process_id, trading_status=trading_status)
        except Exception as e:
            sentry.captureException()
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'error': str(e)
            })
            return

        self.json_response({
            'code': APIResponseCode.OK.value,
            'data': {
                'success': success
            }
        })


class VsT0RelationHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return

        s_ids_set = set()
        t0_alpha_relation = dict()
        with session_context() as sc:
            relations = sc.query(VsT0Relation).order_by(
                VsT0Relation.id.desc()
            ).all()
            for r in relations:
                s_ids_set.add(r.vs_id)
                s_ids_set.add(r.link_vs_id)
                t0_alpha_relation.setdefault(r.vs_id, {
                    'deleted': [],
                    'available': []
                })
                item = {
                    't0_vs_id': r.vs_id,
                    'alpha_vs_id': r.link_vs_id,
                    'record_id': r.id,
                    'share_resp': r.share_resp,
                    'link_date': r.link_date.strftime("%Y%m%d"),
                    'unlink_date': r.unlink_date.strftime("%Y%m%d") if r.unlink_date else "",
                }
                if r.deleted:
                    t0_alpha_relation[r.vs_id]['deleted'].append(item)
                else:
                    t0_alpha_relation[r.vs_id]['available'].append(item)

        vs_basic_data = VsBasicData.get_many(identifiers=list(s_ids_set))

        data = {
            'vs_basic_data': vs_basic_data,
            't0_alpha_relation': t0_alpha_relation
        }

        self.json_response({
            'code': APIResponseCode.OK.value,
            'data': data
        })

    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return

        user_id = self.current_user['id']
        payload = self.get_payload()
        t0_vs_id = int(payload['t0_vs_id'])
        alpha_vs_id = int(payload['alpha_vs_id'])
        share_resp = payload.get('share_resp', False)

        trading_calendar = TradeCalendar.init_from_kdb(**config.kdb_config)
        next_trading_date = trading_calendar.get_next_trading_date().astype(datetime.date)

        with session_context() as sc:
            new_record = VsT0Relation(
                r_create_user_id=user_id,
                r_update_user_id=user_id,
                vs_id=t0_vs_id,
                link_vs_id=alpha_vs_id,
                link_date=next_trading_date,
                share_resp=share_resp
            )
            sc.add(new_record)

        self.json_response({
            'code': APIResponseCode.OK.value,
            'data': {
                'status': 'success'
            }
        })

    def put(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return

        user_id = self.current_user['id']
        payload = self.get_payload()
        record_id = int(payload['record_id'])
        share_resp = payload.get('share_resp', False)

        with session_context() as sc:
            record = sc.query(VsT0Relation).filter(
                VsT0Relation.id == record_id,
                VsT0Relation.deleted == False
            ).first()
            if not record:
                self.json_response({
                    'code': APIResponseCode.DefaultError.value,
                    'data': {
                        'msg': 'record not exists'
                    }
                })
                return

            record.share_resp = share_resp
            record.r_update_user_id = user_id

        self.json_response({
            'code': APIResponseCode.OK.value,
            'data': {
                'status': 'success'
            }
        })

    def delete(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return

        user_id = self.current_user['id']
        record_id = int(self.get_argument('record_id'))

        trading_calendar = TradeCalendar.init_from_kdb(**config.kdb_config)
        next_trading_date = trading_calendar.get_next_trading_date().astype(datetime.date)

        with session_context() as sc:
            record = sc.query(VsT0Relation).filter(
                VsT0Relation.id == record_id,
                VsT0Relation.deleted == False
            ).first()
            if not record:
                self.json_response({
                    'code': APIResponseCode.DefaultError.value,
                    'data': {
                        'msg': 'record not exists'
                    }
                })
                return

            record.r_update_user_id = user_id
            record.deleted = True
            record.unlink_date = next_trading_date

        self.json_response({
            'code': APIResponseCode.OK.value,
            'data': {
                'status': 'success'
            }
        })


class VstrategiesBacktest(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @login_required
    def get(self, *args, **kwargs):
        """

        API for finding all failed  back test at today

        query params:
            sort_by: String
            reverse: String
            page_size: Int
            page_num: Int
            strategy_type: String

        """
        try:
            sort_by = self.get_argument('sort_by', None)

            sort_reverse = self.get_argument('reverse', 'true')
            sort_reverse = True if sort_reverse == 'true' else False

            page_size = int(self.get_argument('page_size', 10))
            page_num = int(self.get_argument('page_num', 0))
            strategy_type = self.get_argument('strategy_type', '')

            vs_backtest_info = get_vs_backtest_info(sort_by=sort_by, page_num=page_num, page_size=page_size,
                                                    sort_reverse=sort_reverse, strategy_type=strategy_type)

        except Exception as e:
            sentry.captureException()
            self.json_response({
                'code': APIResponseCode.DefaultError.value,
                'error': str(e)
            })
            return

        self.json_response({
            'code': APIResponseCode.OK.value,
            'data': vs_backtest_info
        })

from .handler import VsTradingStatusHandler, VsT0RelationHandler, VstrategiesBacktest

urls = [
    (r'/api/v1/platform/operation/vs_trading_status', VsTradingStatusHandler),
    (r'/api/v1/platform/operation/vs_t0_relation', VsT0RelationHandler),
    (r'/api/v1/platform/operation/vstrategy/backtest', VstrategiesBacktest),
]

import json
import uuid
from decimal import Decimal
from datetime import datetime
from sqlalchemy import func, or_, desc, text, case
from config import RedisCache0
from db import session, session_context
from consts import STRATEGY_TYPE
from constant import RedisKeyConstant, StrategyConstant
from service.back_test.live_position_models import VsBase
from service.back_test.models import Strategy, VStrategies, StrategyPortfolio, StrategyLiveRunRecords, \
    VstrategyBackTestResult, VStrategyAccountDetail


def send_vs_trading_status_to_live_server(process_id, trading_status):
    rds = RedisCache0()
    queue_key = RedisKeyConstant.OssACmd.value
    # queue_key = RedisKeyConstant.TestOssACmd.value
    sc = session()
    sql_query = "select vstrategy_id,host from deploy_confs where id={process_id}".format(process_id=process_id)
    cursor = sc.execute(sql_query).fetchone()
    if cursor:
        key = queue_key.format(server_ip=cursor["host"])
        value = {
            "type": 13,
            "data": {
                "vs_id": cursor["vstrategy_id"],
                "process_id": process_id,
                "trading_status": trading_status
            },
            "seq": uuid.uuid4().int & ((1 << 16) - 1)
        }
        rds.rpush(key, json.dumps(value))
        sc.close()
        return True
    sc.close()
    return False


def get_vs_backtest_info(sort_by, page_num, page_size, sort_reverse, strategy_type):
    """
    query database and get failed back test info at today
    @param:
            sort_by: String
            sort_reverse: String
            page_size: Int
            page_num: Int
            strategy_type: String
    @return:
            List[Dict[String:Union[String,Float]]]
    """
    info = dict()
    with session_context() as sc:
        last_settle_date = sc.query(
            func.max(VsBase.settle_date)
        ).filter(
            VsBase.daynight == 'DAY'
        ).first()[0].strftime('%Y%m%d')

        info['trading_date'] = last_settle_date

        # find virtual strategy changed at last day
        settle_virtual_strategies = sc.query(
            VsBase.vstrategy_id
        ).filter(
            VsBase.settle_date == last_settle_date
        ).distinct()

        virtual_strategy_ids = sc.query(VStrategies.id.label("id")).filter(
            or_(
                # 15 means live strategy, 16 means offline
                VStrategies.status == 15,
                VStrategies.id.in_(settle_virtual_strategies)
            )
        )

        servers_sub_query = sc.query(
            StrategyLiveRunRecords.vstrategy_id.label('vs_id'),
            StrategyLiveRunRecords.host.label('host'),
        ).filter(
            StrategyLiveRunRecords.id.in_(
                sc.query(
                    func.max(StrategyLiveRunRecords.id)
                ).filter(
                    StrategyLiveRunRecords.vstrategy_id.in_(virtual_strategy_ids)
                ).group_by(
                    StrategyLiveRunRecords.vstrategy_id
                )
            )
        ).subquery()

        back_test_day_result = sc.query(
            VstrategyBackTestResult.vstrategy_id.label('vs_id'),
            VstrategyBackTestResult.pnl.label('pnl'),
            VstrategyBackTestResult.done_time.label('done_time')
        ).filter(
            VstrategyBackTestResult.trading_date == last_settle_date,
            VstrategyBackTestResult.vstrategy_id.in_(virtual_strategy_ids),
            VstrategyBackTestResult.day_night == 0
        ).subquery()

        back_test_night_result = sc.query(
            VstrategyBackTestResult.vstrategy_id.label('vs_id'),
            VstrategyBackTestResult.pnl.label('pnl'),
            VstrategyBackTestResult.done_time.label('done_time')
        ).filter(
            VstrategyBackTestResult.trading_date == last_settle_date,
            VstrategyBackTestResult.vstrategy_id.in_(virtual_strategy_ids),
            VstrategyBackTestResult.day_night == 1
        ).subquery()

        settle_detail = sc.query(
            VsBase.vstrategy_id.label('vs_id'),
            VsBase.pnl.label('settle_pnl')
        ).filter(
            VsBase.settle_date == last_settle_date,
            VsBase.daynight == 'DAY',
            VsBase.vstrategy_id.in_(virtual_strategy_ids)
        ).subquery()

        virtual_strategy_accounts = sc.query(
            VStrategyAccountDetail.vstrategy_id.label('vs_id'),
            func.group_concat(VStrategyAccountDetail.account.distinct()).label('accounts')
        ).filter(
            VStrategyAccountDetail.vstrategy_id.in_(virtual_strategy_ids)
        ).group_by(
            VStrategyAccountDetail.vstrategy_id
        ).subquery()

        # main query start
        virtual_strategies = sc.query(
            VStrategies.id.label('vs_id'),
            Strategy.id.label('s_id'),
            Strategy.id_no.label('s_id_no'),
            Strategy.detail['trade_model'],
            Strategy.node,
            StrategyPortfolio.username.label('username'),
            StrategyPortfolio.name.label('portfolio_name'),
            StrategyPortfolio.live_time.label('live_time'),
            servers_sub_query.c.host.label('server'),
            back_test_night_result.c.pnl.label("night_pnl"),
            back_test_night_result.c.done_time.label("night_done_time"),
            back_test_day_result.c.pnl.label("day_pnl"),
            back_test_day_result.c.done_time.label("day_done_time"),
            settle_detail.c.settle_pnl.label("settle_pnl"),
            (back_test_night_result.c.pnl + back_test_day_result.c.pnl).label('backtest_pnl'),
            (back_test_night_result.c.pnl + back_test_day_result.c.pnl - settle_detail.c.settle_pnl).label('delta'),
            case([
                (
                    back_test_night_result.c.done_time > back_test_day_result.c.done_time,
                    back_test_night_result.c.done_time),
            ],
                else_=back_test_day_result.c.done_time
            ).label('done_time'),
            case(
                [
                    (settle_detail.c.settle_pnl == 0, 0),
                    (back_test_day_result.c.pnl.is_(None), 0),
                    (
                        settle_detail.c.settle_pnl != 0, (
                                (
                                        back_test_night_result.c.pnl + back_test_day_result.c.pnl - settle_detail.c.settle_pnl) /
                                settle_detail.c.settle_pnl)
                    )
                ]
            ).label('percent'),
            case(
                [
                    (back_test_night_result.c.pnl.is_(None), 'Error'),
                    (back_test_day_result.c.pnl.is_(None), 'Error'),
                    (settle_detail.c.settle_pnl == 0, 'Error'),
                    (
                        (
                                (
                                        back_test_night_result.c.pnl + back_test_day_result.c.pnl - settle_detail.c.settle_pnl) /
                                settle_detail.c.settle_pnl) >= 1, 'Error'
                    )
                ],
                else_='Undetermined'
            ).label('status'),
            func.concat(
                virtual_strategy_accounts.c.accounts
            ).label('accounts')
        ).join(
            Strategy, Strategy.id == VStrategies.strategy_id
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).join(
            servers_sub_query, servers_sub_query.c.vs_id == VStrategies.id, isouter=True
        ).filter(
            VStrategies.id.in_(virtual_strategy_ids),
            # no hedge strategy currently
            Strategy.strategy_type != StrategyConstant.StrategyType.StockAlphaHedgeStrategy.value
        ).join(
            back_test_night_result, back_test_night_result.c.vs_id == VStrategies.id, isouter=True
        ).join(
            back_test_day_result, back_test_day_result.c.vs_id == VStrategies.id, isouter=True
        ).join(
            settle_detail, settle_detail.c.vs_id == VStrategies.id, isouter=True
        ).join(
            virtual_strategy_accounts, virtual_strategy_accounts.c.vs_id == VStrategies.id
        )

        # filter by strategy type
        if strategy_type == "stock":
            virtual_strategies = virtual_strategies.filter(
                Strategy.strategy_type.in_(tuple(StrategyConstant.StrategyType.stock_group())))
        elif strategy_type == "future":
            virtual_strategies = virtual_strategies.filter(
                Strategy.strategy_type.in_(
                    tuple(set(STRATEGY_TYPE.keys()) - set(StrategyConstant.StrategyType.stock_group()))))
        elif strategy_type == "stock_factor":
            virtual_strategies = virtual_strategies.filter(
                Strategy.strategy_type == StrategyConstant.StrategyType.StockFactor.value)
        elif strategy_type == "stock_not_factor":
            virtual_strategies = virtual_strategies.filter(
                Strategy.strategy_type.in_(tuple(StrategyConstant.StrategyType.stock_not_factor_group())))
        elif strategy_type.isdigit():
            virtual_strategies = virtual_strategies.filter(Strategy.strategy_type == strategy_type)

        field_names = ['id', 's_id', 's_id_no', 'trade_model', 'node', 'username', 'portfolio_name',
                       'live_time', 'server', 'night_pnl', 'night_done_time', 'day_pnl',
                       'day_done_time',
                       'settle_pnl', 'backtest_pnl', 'delta', 'done_time', 'percent', 'status', 'accounts']

        # handle special case when sort_by name is not same as field name in db
        sort_map = {
            "server": servers_sub_query.c.host,
            "id": VStrategies.id,
        }

        # order by
        if sort_by and sort_by in field_names:
            if sort_by in sort_map.keys():
                sort_by = sort_map[sort_by]
            else:
                sort_by = text(sort_by)
            if sort_reverse:
                virtual_strategies = virtual_strategies.order_by(desc(sort_by))
            else:
                virtual_strategies = virtual_strategies.order_by(sort_by)

        # pagination
        count = virtual_strategies.count()
        info['sum'] = count
        virtual_strategies = virtual_strategies.offset(page_num * page_size).limit(page_size)

        virtual_strategies = back_test_info_serialize(virtual_strategies, field_names)

        info['list'] = virtual_strategies
        return info


def back_test_info_serialize(results, names):
    """
    convert back test info to list of dict
    """
    if not results:
        return []

    data = []
    for result in results:
        info = {}
        for index, value in enumerate(result):
            if value is None and names[index] in ['backtest_pnl', 'delta', 'settle_pnl', 'day_pnl', 'night_pnl']:
                value = 0
            elif value is None:
                value = "N/A"
            elif isinstance(value, Decimal):
                value = float(value)
            elif isinstance(value, datetime):
                value = value.strftime('%Y%m%d %X')
            elif isinstance(value, bytes):
                value = value.decode('utf-8')
            info[names[index]] = value

        # font end need list
        info['accounts'] = str(info['accounts']).split(",")
        data.append(info)
    return data


if __name__ == '__main__':
    # send_vs_trading_status_to_live_server(process_id=2442, trading_status=1)
    pass

# -*-coding:utf-8-*-

import datetime
import json
from tornado import gen
from tornado.web import MissingArgumentError
from dateutil.parser import parse
from sqlalchemy import or_, func, distinct

import consts
from db import session, session_context
from service.basehandler import BaseHandler, CurrentUserMixin, JsonPayloadMixin
from service.back_test.models import Users, Strategy, VStrategies, StrategyPortfolio, \
    StrategyUploadFile, StrategyFileChangeRequest, StrategyResult, StrategyResultAccount, StrategyResultDetail, \
    LiveStrategyChangeRequest, VstrategyBackTestResult, StrategyLiveRunRecords, VsBackTestOperationlogs, \
    ToBeDeletedStrategy, LiveQuoteServer, OnlineRequest, VStrategyAccountDetail, StockHedgeVs
from service.back_test.live_position_models import VsBase
from cron.strategy_upload_task import vs_back_test, redo_strategy_papertrading, redo_ev_task, \
    update_strategy_confidence
from cron.live_trading_task import upgrade_vs_position
from kdb_query import KdbQuery
from utils import send_email, notify_operation_wechat
from config import config
from service.strategymanager.manager import live_ev_check, live_ev_check2, get_strategy_dep_id, get_filename_and_status
from service.operation_deploy.models import VstrategyUpgrade
from constant import CompanyEmailGroup, APIResponseCode, VStrategiesConstant, StrategyConstant
from utility.db_util import TradeCalendar


class StrategySoChangeStrategyHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        sc = session()
        strategies = sc.query(
            Strategy.id.label('id'),
            Strategy.id_no.label('id_no')
        ).join(
            VStrategies, VStrategies.strategy_id == Strategy.id,
        ).filter(
            VStrategies.status >= consts.STRATEGY_LIVE,
            Strategy.r_create_user_id == self.current_user['id'],
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.node == 'back_test',
        ).distinct()
        pending_strategy_ids = [r[0] for r in sc.query(
            StrategyFileChangeRequest.strategy_id
        ).filter(
            StrategyFileChangeRequest.status == 'PENDING'
        )]

        row = [
            {
                'id': r[0],
                'id_no': r[1],
            } for r in strategies if r[0] not in pending_strategy_ids
        ]
        sc.close()
        self.json_response({
            'code': 0,
            'data': row,

        })
        return True


class StrategySoChangeHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        page = int(self.get_argument('page', 0))
        size = int(self.get_argument('size', 10))
        filter_args = json.loads(self.get_argument('filter', "{}"))
        request_status = filter_args.get('status', [])
        if request_status == 'all' or ('all' in request_status):
            request_status = []
        sc = session()
        so_requests = sc.query(StrategyFileChangeRequest).filter(
            StrategyFileChangeRequest.r_create_user_id == self.current_user['id']
        )
        if request_status:
            so_requests = so_requests.filter(StrategyFileChangeRequest.status.in_(request_status))
        total = so_requests.count()
        so_requests = so_requests.order_by(StrategyFileChangeRequest.id.desc()).offset(page * size).limit(size)
        row = [r.to_dict() for r in so_requests]
        sc.close()
        self.json_response({
            'code': 0,
            'data': row,
            'total': total,

        })
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        strategy_id = self.get_argument('strategy_id')
        sc = session()
        try:
            s = sc.query(Strategy).filter(
                Strategy.id == int(strategy_id),
            ).first()
        except Exception as e:
            s = sc.query(Strategy).filter(
                Strategy.id_no == strategy_id,
            ).first()

        if not s:
            self.json_response({
                'code': 3001,
                'error': 'can not find strategy',
            })
            sc.close()
            return False

        if s.node not in ('back_test',):
            self.json_response({
                'code': 3001,
                'error': '此策略不需要so',
            })
            sc.close()
            return False

        if sc.query(StrategyFileChangeRequest.id).filter(
                StrategyFileChangeRequest.strategy_id == s.id,
                StrategyFileChangeRequest.status == 'PENDING').first():
            self.json_response({
                'code': 3010,
                'error': '此策略有未审核的更换申请',
            })
            sc.close()
            return False

        live_s = sc.query(VStrategies).filter(
            VStrategies.strategy_id == s.id, VStrategies.status >= consts.STRATEGY_LIVE
        )
        if not live_s.count():
            self.json_response({
                'code': 3002,
                'error': '策略还未实盘，请通过策略上载页面直接替换',
            })
            sc.close()
            return False

        try:
            upload_file = self.request.files['file'][0]
            filename = upload_file['filename']

            if '/' in filename:
                filename = filename.split('/')[-1]
            if '\\' in filename:
                filename = filename.split('\\')[-1]

            file_data = {
                'user_id': self.current_user['id'],
                'content': upload_file['body'],
                'filename': filename,
                'file_type': 'st',
            }
            strategy_upload_file_id = StrategyUploadFile.save_file(file_data)
            if strategy_upload_file_id < 0:
                raise ValueError('upload file failed')
        except Exception as e:
            self.application.sentry.captureException()
            self.json_response({
                'code': 3003,
                'error': 'upload file failed',
            })
            sc.close()
            return False

        so_request = StrategyFileChangeRequest(
            r_create_user_id=self.current_user['id'],
            username=self.current_user['username'],
            r_update_user_id=self.current_user['id'],
            strategy_upload_file_id=strategy_upload_file_id,
            strategy_upload_file_name=filename,
            strategy_id=s.id,
            strategy_id_no=s.id_no,
            status='PENDING',
            request_msg=self.get_argument('msg', ''),
            strategy_type='stock' if s.strategy_type in consts.stock_strategy_type else 'future',
        )
        sc.add(so_request)
        sc.commit()
        data = so_request.to_dict()
        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StrategySoChangeAuditHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        group_ids = self.get_user_group()

        is_operation = (self.current_user['is_superuser']) or (2 in group_ids) or (22 in group_ids) or (32 in group_ids)

        if (self.is_stock_page()) and (is_operation or self.is_stock_group()):
            strategy_type = 'stock'
        elif (self.is_future_page()) and (is_operation or self.is_future_group()):
            strategy_type = 'future'
        elif is_operation:
            strategy_type = ''
        else:
            strategy_type = 'xxxxx'
        page = int(self.get_argument('page', 0))
        size = int(self.get_argument('size', 10))
        filter_args = json.loads(self.get_argument('filter', "{}"))
        request_status = filter_args.get('status', [])
        if request_status == 'all' or ('all' in request_status):
            request_status = []
        sc = session()
        so_requests = sc.query(StrategyFileChangeRequest)
        if request_status:
            so_requests = so_requests.filter(StrategyFileChangeRequest.status.in_(request_status))
        if strategy_type:
            so_requests = so_requests.filter(StrategyFileChangeRequest.strategy_type == strategy_type)
        total = so_requests.count()
        so_requests = so_requests.order_by(StrategyFileChangeRequest.id.desc()).offset(page * size).limit(size)
        row = [r.to_dict() for r in so_requests]
        sc.close()
        self.json_response({
            'code': 0,
            'data': row,
            'total': total,

        })
        return True


class StrategySoChangeAuditDetailHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        r_id = int(kwargs['id'])
        payload = self.get_payload()
        sc = session()
        r = sc.query(StrategyFileChangeRequest).filter(StrategyFileChangeRequest.id == r_id).first()
        if not r:
            self.json_response({
                'code': 3004,
                'error': 'can not find strategy file change request',
            })
            sc.close()
            return False

        s = sc.query(Strategy).filter(Strategy.id == r.strategy_id).first()
        if not s:
            self.json_response({
                'code': 3005,
                'error': 'can not find strategy',
            })
            sc.close()
            return False

        status = payload.get('status', '')
        if status not in ('APPROVED', 'REJECTED'):
            self.json_response({
                'code': 3006,
                'error': 'status must be APPROVED or REJECTED',
            })
            sc.close()
            return False
        if r.status in ('APPROVED', 'REJECTED'):
            self.json_response({
                'code': 3007,
                'error': 'request is already audited',
            })
            sc.close()
            return False

        r.status = status
        r.audit_user_id = self.current_user['id']
        r.auditer = self.current_user['username']
        r.audit_msg = payload.get('msg', '')
        if status == 'APPROVED':
            s.strategy_upload_file_id = r.strategy_upload_file_id
        sc.commit()
        if status == 'APPROVED':
            user_emails = [
                u[0] for u in sc.query(Users.email).filter(Users.id.in_([r.r_create_user_id, self.current_user['id']]))
            ]
            title = '%s 更换so审核通知' % s.id_no
            user_emails.extend(
                [
                    CompanyEmailGroup.quant_dev,
                    CompanyEmailGroup.quant_ops,
                    CompanyEmailGroup.LiShaoFeng,
                    CompanyEmailGroup.LuoYang,
                    CompanyEmailGroup.ZengDan
                ]
            )
            msg = '请重新部署此策略的实盘so'
        else:
            user_emails = [
                u[0] for u in sc.query(Users.email).filter(Users.id.in_([r.r_create_user_id, self.current_user['id']]))
            ]
            title = '%s 更换so审核通知' % s.id_no
            msg = '更换so审核不通过，原因:%s' % r.audit_msg
        if config.Debug:
            user_emails = [CompanyEmailGroup.quant_dev_test]
        sc.close()
        send_email(title, msg, list(set(user_emails)))
        notify_operation_wechat(title + ':' + msg)
        self.json_response({
            'code': 0,
            'data': '',
        })
        return True


class StrategyManagerBasicHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        strategy_id = kwargs['id']
        sc = session()
        try:
            strategyies = sc.query(Strategy).filter(
                Strategy.id == int(strategy_id),
            )
        except Exception as e:
            strategyies = sc.query(Strategy).filter(
                Strategy.id_no == strategy_id,
            )
        group_ids = self.get_user_group()
        if not ((self.current_user['is_superuser']) or (2 in group_ids) or (22 in group_ids) or (
                32 in group_ids) or self.is_stock_group() or self.is_future_group()):
            strategyies = strategyies.filter(Strategy.r_create_user_id == self.current_user['id'])
        s = strategyies.first()
        if not s:
            self.json_response({
                'code': 3007,
                'error': 'can not find strategy'
            })
            sc.close()
            return True

        data = {
            'id': s.id,
            'strategy_id': s.id_no,
            'name': s.name,
            'type': 'ev' if s.node == 'ev' else 'strategy',
            'dependency': [
            ],
            'vstrategies': [
            ]
        }
        dependency_ids = [dep['id'] for dep in s.dependency]
        dep_strategies = sc.query(Strategy).filter(Strategy.id.in_(dependency_ids))
        for dep in dep_strategies:
            data['dependency'].append({
                'id': dep.id,
                'type': 'ev',
                'name': dep.name,
            })

        vstrategies_detail = sc.query(
            VStrategies.id.label('vs_id'),
            StrategyPortfolio.name.label('portfolio_name'),
            StrategyPortfolio.username.label('investmentor')
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            VStrategies.status == consts.STRATEGY_LIVE,
            StrategyPortfolio.status == consts.STRATEGY_LIVE,
            VStrategies.strategy_id == s.id
        )
        for vs in vstrategies_detail:
            data['vstrategies'].append({
                'id': vs.vs_id,
                'portfolio_name': vs.portfolio_name,
                'investmentor': vs.investmentor,
            })

        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class EvRedoHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        s_id = int(kwargs['id'])
        payload = self.get_payload()
        sc = session()
        s = sc.query(Strategy).filter(
            Strategy.id == s_id, Strategy.node == 'ev', Strategy.is_delete == 0, Strategy.is_test == 0
        ).first()
        if not s:
            sc.close()
            self.json_response({
                'code': 3010,
                'error': 'can not find ev strategy',
            })
            return True
        start_date = parse(str(payload['start'])).strftime('%Y%m%d')
        end_date = parse(str(payload.get('end', start_date))).strftime('%Y%m%d')
        clear_history = payload.get('clear_history', False)
        if clear_history:
            pass
        s.start_date = min(start_date, s.start_date)
        sc.commit()
        redo_ev_task.delay(s.id, start_date, end_date=end_date)
        sc.close()
        self.json_response({
            'code': 0,
            'data': '',
        })
        return True


class StrategyPaperTradingRedoHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        s_id = int(kwargs['id'])
        payload = self.get_payload()

        sc = session()

        s = sc.query(Strategy).filter(
            Strategy.id == s_id,
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.node.in_(['back_test', 'order_list', 'trademaster_order_list', 'ev'])
        ).first()

        if not s:
            sc.close()
            self.json_response({
                'code': 3010,
                'error': 'can not find strategy',
            })
            return True

        start_date = parse(str(payload['start'])).strftime('%Y%m%d')
        end_date = parse(str(payload.get('end', start_date))).strftime('%Y%m%d')
        if s.node == 'ev':
            s.start_date = min(start_date, s.start_date)
            sc.commit()
            redo_ev_task.delay(s.id, start_date, end_date=end_date)
            sc.close()
            self.json_response({
                'code': 0,
                'data': '',
            })
            return True

        clear_history = payload.get('clear_history', True)
        if clear_history:
            sc.query(StrategyResult).filter(
                StrategyResult.strategy_id == s.id,
                StrategyResult.date >= start_date,
                StrategyResult.date <= end_date,
                StrategyResult.config_id == 0,
            ).delete(synchronize_session=False)

            sc.query(StrategyResultDetail).filter(
                StrategyResultDetail.strategy_id == s.id,
                StrategyResultDetail.trading_date >= start_date,
                StrategyResultDetail.trading_date <= end_date,
                StrategyResultDetail.config_id == 0
            ).delete(synchronize_session=False)

            sc.query(StrategyResultAccount).filter(
                StrategyResultAccount.strategy_id == s.id,
                StrategyResultAccount.trading_date >= start_date,
                StrategyResultAccount.trading_date <= end_date,
                StrategyResultAccount.config_id == 0
            ).delete(synchronize_session=False)

            sc.commit()

        redo_strategy_papertrading.delay(s.id, start_date)

        Strategy.add_strategy_event(
            s.id,
            start_date,
            0,
            'RedoStrategyBackTest',
            task_id=s.st_uuid or '',
            detail=payload
        )

        s.r_update_time = datetime.datetime.now()

        sc.commit()
        sc.close()

        self.json_response({
            'code': 0,
            'data': '',
        })
        return True


class VstrategiesbacktestRedoHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        vs_id = int(kwargs['id'])
        payload = self.get_payload()
        sc = session()
        vs = sc.query(VStrategies).filter(
            VStrategies.id == vs_id
        ).first()
        if not vs:
            sc.close()
            self.json_response({
                'code': 3010,
                'error': 'can not find vstrategy',
            })
            return False

        start_date = parse(str(payload['start'])).strftime('%Y%m%d')
        end_date = parse(str(payload.get('end', start_date))).strftime('%Y%m%d')

        server = payload.get('server', '')
        trade_model = payload.get('trade_model', '')
        use_last_live_position = payload.get('use_last_live_position', False)

        if server:
            vs.deploy_server = server

        if trade_model:
            vs.trade_model = trade_model

        l = VsBackTestOperationlogs(
            vs_id=vs_id,
            user_id=self.current_user['id'],
            user_name=self.current_user['username'],
            start_date=start_date,
            end_date=end_date,
            deploy_server=server,
            trade_model=trade_model,
        )
        sc.add(l)
        sc.commit()

        para = {
            'server': server,
            'trade_model': trade_model,
            'use_last_live_position': use_last_live_position,
            'end_date': end_date
        }

        vs_back_test.delay(vs_id, start_date, **para)

        Strategy.add_vs_event(
            vs_id,
            start_date,
            0,
            'RedoVsBackTest',
            detail=para
        )
        sc.close()
        self.json_response({
            'code': 0,
            'data': '',
        })
        return True


class VstrategiesbacktestDetailHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        sc = session()
        data = {}
        last_settle_date = sc.query(
            func.max(VsBase.settle_date)
        ).filter(
            VsBase.daynight == 'DAY'
        ).first()[0].strftime('%Y%m%d')

        settle_vstrateies = sc.query(
            VsBase.vstrategy_id
        ).filter(
            VsBase.settle_date == last_settle_date
        ).distinct()

        data['trading_date'] = last_settle_date
        data['vstrategies'] = []

        vstrategy_ids = sc.query(VStrategies.id).filter(
            or_(
                VStrategies.status == 15,
                VStrategies.id.in_(settle_vstrateies)
            )
        )

        vstrategies = sc.query(
            VStrategies.id.label('vs_id'),
            Strategy.id.label('s_id'),
            Strategy.id_no.label('s_id_no'),
            Strategy.detail.label('s_detail'),
            Strategy.node.label('node'),
            StrategyPortfolio.name.label('portfolio_name'),
            StrategyPortfolio.live_time.label('live_time'),
        ).join(
            Strategy, Strategy.id == VStrategies.strategy_id
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            VStrategies.id.in_(vstrategy_ids),
            Strategy.strategy_type.notin_(['20'])
        )
        vs_detail = {}
        for vs in vstrategies:
            vs_detail[vs.vs_id] = {
                'id': vs.vs_id,
                'vs_id': vs.vs_id,
                's_id': vs.s_id,
                's_id_no': vs.s_id_no,
                'upload_type': vs.node if vs.node != 'back_test' else 'so_file',
                'portfolio_name': vs.portfolio_name,
                'live_time': vs.live_time.strftime('%Y%m%d'),
                'back_test_pnl': 'N/A',
                'night_pnl': 0,
                'day_pnl': 'N/A',
                'settle_pnl': 0,
                'delta': 0,
                'percent': 1000,
                'done_time': 'N/A',
                'trade_model': vs.s_detail.get('trade_model', ''),
                'server': '',
                'status': 'Undetermined',
            }

        servers = sc.query(
            StrategyLiveRunRecords.vstrategy_id.label('vs_id'),
            StrategyLiveRunRecords.host.label('host'),
        ).filter(
            StrategyLiveRunRecords.id.in_(
                sc.query(
                    func.max(StrategyLiveRunRecords.id)
                ).filter(
                    StrategyLiveRunRecords.vstrategy_id.in_(vstrategy_ids)
                ).group_by(
                    StrategyLiveRunRecords.vstrategy_id
                )
            )
        )

        for ser in servers:
            if ser.vs_id in vs_detail:
                vs_detail[ser.vs_id]['server'] = ser.host

        vs_back_test_detail = sc.query(VstrategyBackTestResult).filter(
            VstrategyBackTestResult.trading_date == last_settle_date,
            VstrategyBackTestResult.vstrategy_id.in_(vstrategy_ids)
        )

        for r in vs_back_test_detail:
            if r.vstrategy_id in vs_detail:
                if r.day_night == 1:
                    vs_detail[r.vstrategy_id]['night_pnl'] = float(r.pnl)
                elif r.day_night == 0:
                    vs_detail[r.vstrategy_id]['day_pnl'] = float(r.pnl)
                vs_detail[r.vstrategy_id]['done_time'] = max(
                    r.done_time.strftime('%Y%m%d %X'),
                    vs_detail[r.vstrategy_id]['done_time'] if vs_detail[r.vstrategy_id][
                                                                  'done_time'] != 'N/A' else '20000101 00:00:00'
                )

        settle_detail = sc.query(
            VsBase
        ).filter(
            VsBase.settle_date == last_settle_date,
            VsBase.daynight == 'DAY',
            VsBase.vstrategy_id.in_(vstrategy_ids)
        )
        for r in settle_detail:
            if r.vstrategy_id in vs_detail:
                vs_detail[r.vstrategy_id]['settle_pnl'] = float(r.pnl)

        for k, v in vs_detail.items():
            if v['day_pnl'] != 'N/A':
                v['back_test_pnl'] = v['night_pnl'] + v['day_pnl']
                v['delta'] = v['back_test_pnl'] - v['settle_pnl']
                if v['settle_pnl'] != 0:
                    v['percent'] = abs(v['delta'] / v['settle_pnl'])
            else:
                v['status'] = 'Error'

            if v['percent'] >= 1:
                v['status'] = 'Error'
        data['vstrategies'] = sorted(vs_detail.values(), key=lambda d: (d['status'], -d['id']))
        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class StrategyPapertradingDetailHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):

        page = int(self.get_argument('page', 0))
        size = int(self.get_argument('size', 100))

        sort_by = self.get_argument('sort_by', '')
        sort_reverse = self.get_argument('reverse', 'true').lower()

        s_id = self.get_argument('strategy_id', '')
        s_id_no = ''
        try:
            s_id = int(s_id)
        except Exception as e:
            s_id_no = s_id
            s_id = ''

        filters = json.loads(self.get_argument('filters', '{}'))
        tobedeleted = list(set(filters.get('tobedeleted', [])))
        is_live = list(set(filters.get('is_live', [])))
        strategy_status = [consts.STRATEGY_STATUS_MAP2.get(i, 0) for i in filters.get('strategy_status', [])]

        data = {}

        sc = session()
        last_settle_date = sc.query(
            func.max(VsBase.settle_date)
        ).filter(
            VsBase.daynight == 'DAY'
        ).first()[0].strftime('%Y%m%d')

        delete_strategy_ids = [s[0] for s in sc.query(ToBeDeletedStrategy.strategy_id)]

        live_strategy = [s[0] for s in sc.query(
            VStrategies.strategy_id
        ).filter(VStrategies.status == 15)]

        strategy_detail = sc.query(
            Strategy.id.label('id'),
            Strategy.id_no.label('id_no'),
            Strategy.name.label('name'),
            Strategy.username.label('user_name'),
            Strategy.task_progress.label('task_progress'),
            Strategy.r_create_time.label('r_create_time'),
            Strategy.status.label('strategy_status'),
        ).filter(
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.node.in_(['back_test', 'order_list', 'trademaster_order_list']),
            Strategy.strategy_type != '22',
        )

        if strategy_status:
            strategy_detail = strategy_detail.filter(Strategy.status.in_(strategy_status))

        if len(is_live) == 1:
            if is_live[0]:
                strategy_detail = strategy_detail.filter(
                    Strategy.id.in_(live_strategy)
                )
            else:
                strategy_detail = strategy_detail.filter(
                    Strategy.id.notin_(live_strategy)
                )

        if len(tobedeleted) == 1:
            if tobedeleted[0]:
                strategy_detail = strategy_detail.filter(
                    Strategy.id.in_(delete_strategy_ids)
                )
            else:
                strategy_detail = strategy_detail.filter(
                    Strategy.id.notin_(delete_strategy_ids)
                )

        if s_id:
            strategy_detail = strategy_detail.filter(Strategy.id == s_id)
            sort_by = ''
        elif s_id_no:
            strategy_detail = strategy_detail.filter(Strategy.id_no == s_id_no)
            sort_by = ''

        if sort_by == 'days':
            total = strategy_detail.count()

            s_ids = [s.id for s in strategy_detail]

            sql = """
               select strategy_id from strategy_result where id in (
               select max(id) from strategy_result
               where strategy_id in ({s_ids_str})
               GROUP BY strategy_id
               ) order by date {reverse}, strategy_id desc LIMIT {pagestart}, {size};
            """.format(
                reverse='asc' if sort_reverse == 'true' else 'desc',
                pagestart=page * size,
                size=size,
                s_ids_str=','.join(map(str, s_ids))
            )

            sorted_s_ids = [r[0] for r in sc.execute(sql)]

            if total < size:
                total = len(sorted_s_ids)

            strategy_detail = strategy_detail.filter(
                Strategy.id.in_(sorted_s_ids)
            )

        else:
            strategy_detail = strategy_detail.order_by(
                Strategy.id.desc()
            )

            total = strategy_detail.count()

            strategy_detail = strategy_detail.offset(page * size).limit(size)
            sorted_s_ids = []

        strategies = {}
        for s in strategy_detail:
            strategies[s.id] = {
                'id': s.id,
                'id_no': s.id_no,
                'name': s.name,
                'user_name': s.user_name,
                'task_progress': float(s.task_progress or 0),
                'r_create_time': s.r_create_time.strftime('%Y%m%d %X'),
                'pnl': 'N/A',
                'done_time': 'N/A',
                'last_back_test_date': 'N/A',
                'days': 'N/A',
                'status': 'Undetermined',
                'strategy_status': Strategy.get_run_status(s.strategy_status),
                'tobedeleted': True if s.id in delete_strategy_ids else False,
                'is_live': True if s.id in live_strategy else False,
            }
        s_ids = strategies.keys()

        today_s_r = sc.query(
            StrategyResult.strategy_id.label('s_id'),
            StrategyResult.pnl.label('pnl'),
            StrategyResult.done_time.label('done_time'),
        ).filter(
            StrategyResult.strategy_id.in_(s_ids),
            StrategyResult.date == last_settle_date,
            StrategyResult.config_id == 0,
        )
        for r in today_s_r:
            strategies[r.s_id]['pnl'] = float(r.pnl)
            strategies[r.s_id]['done_time'] = r.done_time and r.done_time.strftime('%Y%m%d %X') or ''

        last_back_test_dates = sc.query(
            StrategyResult.strategy_id.label('s_id'),
            func.max(StrategyResult.date).label('date'),
        ).filter(
            StrategyResult.strategy_id.in_(s_ids),
            StrategyResult.config_id == 0,
        ).group_by(
            StrategyResult.strategy_id
        )
        for r in last_back_test_dates:
            strategies[r.s_id]['last_back_test_date'] = r.date
            strategies[r.s_id]['days'] = int((parse(last_settle_date) - parse(r.date)).days)

        for s_id, s in strategies.items():
            if s['strategy_status'] in ('NEW', 'RUNNING'):
                continue
            if s['days'] != 0:
                s['status'] = 'Error'

        data['trading_date'] = last_settle_date
        if sort_by == 'days':
            data['strategies'] = [strategies[s_id] for s_id in sorted_s_ids if s_id in strategies]
        else:
            data['strategies'] = sorted(strategies.values(), key=lambda d: (d['status'], -d['id']))
        data['total'] = total
        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
            'total': total
        })
        return True


class StrategyEvDetailHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        data = live_ev_check()

        self.json_response({
            'code': 0,
            'data': sorted(data.values(), key=lambda d: d['id'])
        })
        return True


class TradingDatesHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        kdb = KdbQuery()
        begin_date = datetime.datetime.now()
        now_hour = begin_date.hour
        end_date = begin_date + datetime.timedelta(days=10)
        begin_date_str = begin_date.strftime('%Y%m%d')
        trading_dates = kdb.get_trading_days(begin_date_str, end_date.strftime('%Y%m%d'))
        if now_hour >= 9 and (begin_date_str in trading_dates):
            trading_dates.remove(begin_date_str)
        self.json_response({
            'code': 0,
            'data': trading_dates,
        })
        return True


class VsUpgradeStrategyHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):
    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        sc = session()
        strategies = sc.query(
            Strategy.id_no.label('id_no'),
            StrategyPortfolio.name.label('sp_name'),
            VStrategies.id.label('vs_id'),
        ).join(
            VStrategies, VStrategies.strategy_id == Strategy.id,
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id,
        ).filter(
            VStrategies.status == consts.STRATEGY_LIVE,
            Strategy.r_create_user_id == self.current_user['id'],
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.node == 'back_test',
        ).distinct()

        pending_strategy_ids = [r[0] for r in sc.query(
            LiveStrategyChangeRequest.vs_id
        ).filter(
            LiveStrategyChangeRequest.status == 'PENDING'
        )]

        live_strategy = [
            {
                'vs_id': r.vs_id,
                'id_no': '%s_%s' % (r.sp_name, r.id_no),
            } for r in strategies if r.vs_id not in pending_strategy_ids
        ]

        upgrede_strategy = [
            {
                's_id': r[0],
                'strategy_id': r[1],
            } for r in sc.query(Strategy.id, Strategy.id_no).filter(
                Strategy.r_create_user_id == self.current_user['id'],
                Strategy.node == 'back_test',
                Strategy.is_delete == 0,
                Strategy.is_test == 0, )
        ]

        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'live_strategy': live_strategy,
                'upgrade_strategy': upgrede_strategy,
            },

        })
        return True


class VsUpgradeRequestHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        page = int(self.get_argument('page', 0))
        size = int(self.get_argument('size', 10))
        filter_args = json.loads(self.get_argument('filter', "{}"))
        request_status = filter_args.get('status', [])
        if request_status == 'all' or ('all' in request_status):
            request_status = []
        sc = session()
        so_requests = sc.query(LiveStrategyChangeRequest).filter(
            LiveStrategyChangeRequest.r_create_user_id == self.current_user['id']
        )
        if request_status:
            so_requests = so_requests.filter(LiveStrategyChangeRequest.status.in_(request_status))
        total = so_requests.count()
        so_requests = so_requests.order_by(LiveStrategyChangeRequest.id.desc()).offset(page * size).limit(size)
        row = [r.to_dict() for r in so_requests]
        sc.close()
        self.json_response({
            'code': 0,
            'data': row,
            'total': total,

        })

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        pay_load = self.get_payload()
        vs_id = int(pay_load['vs_id'])
        new_strategy_id = int(pay_load['new_strategy_id'])
        trading_date = parse(str(pay_load['trading_date'])).strftime('%Y%m%d')
        request_msg = pay_load.get('msg', '')

        sc = session()
        new_s = sc.query(Strategy).filter(
            Strategy.id == new_strategy_id
        ).first()

        if not new_s:
            self.json_response({
                'code': 3001,
                'error': 'can not find strategy',
            })
            sc.close()
            return False

        if new_s.node not in ('back_test',):
            self.json_response({
                'code': 3001,
                'error': '此策略不需要so',
            })
            sc.close()
            return False

        if sc.query(LiveStrategyChangeRequest.id).filter(
                LiveStrategyChangeRequest.vs_id == vs_id,
                LiveStrategyChangeRequest.status == 'PENDING').first():
            self.json_response({
                'code': 3010,
                'error': '此策略有未审核的更换申请',
            })
            sc.close()
            return False

        live_s = sc.query(VStrategies).filter(
            VStrategies.id == vs_id,
            VStrategies.status >= consts.STRATEGY_LIVE
        )
        if not live_s.count():
            self.json_response({
                'code': 3002,
                'error': '策略还未实盘，请通过策略上载页面直接替换',
            })
            sc.close()
            return False

        old_strategy = sc.query(
            VStrategies.id.label('vs_id'),
            Strategy.id.label('s_id'),
            Strategy.id_no.label('id_no'),
            StrategyPortfolio.name.label('sp_name'),
        ).join(
            Strategy, Strategy.id == VStrategies.strategy_id
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            VStrategies.id == vs_id
        ).first()

        parent_strategy_id = old_strategy.s_id
        old_req = sc.query(LiveStrategyChangeRequest.parent_strategy_id).filter(
            LiveStrategyChangeRequest.strategy_id == old_strategy.s_id,
            LiveStrategyChangeRequest.parent_strategy_id.isnot(None),
        ).first()
        if old_req and old_req[0]:
            parent_strategy_id = old_req[0]

        req = LiveStrategyChangeRequest(
            r_create_user_id=self.current_user['id'],
            r_update_user_id=self.current_user['id'],
            username=self.current_user['username'],
            strategy_id=old_strategy.s_id,
            strategy_id_no=old_strategy.id_no,
            vs_id=old_strategy.vs_id,
            portfolio_name=old_strategy.sp_name,
            new_strategy_id=new_s.id,
            new_strategy_id_no=new_s.id_no,
            parent_strategy_id=parent_strategy_id,
            trading_date=trading_date,
            request_msg=request_msg
        )
        sc.add(req)
        sc.commit()
        data = req.to_dict()
        sc.close()
        self.json_response({
            'code': 0,
            'data': data,
        })
        return True


class VsUpgradeAuditHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        group_ids = self.get_user_group()
        if not ((self.current_user['is_superuser']) or (2 in group_ids) or (22 in group_ids) or (32 in group_ids)):
            self.json_response({
                'code': 1124,
                'error': 'only investment group has permission'
            })
            return False

        page = int(self.get_argument('page', 0))
        size = int(self.get_argument('size', 10))
        filter_args = json.loads(self.get_argument('filter', "{}"))
        request_status = filter_args.get('status', [])
        if request_status == 'all' or ('all' in request_status):
            request_status = []
        sc = session()
        so_requests = sc.query(LiveStrategyChangeRequest)
        if request_status:
            so_requests = so_requests.filter(LiveStrategyChangeRequest.status.in_(request_status))
        total = so_requests.count()
        so_requests = so_requests.order_by(LiveStrategyChangeRequest.id.desc()).offset(page * size).limit(size)
        row = [r.to_dict() for r in so_requests]
        sc.close()
        self.json_response({
            'code': 0,
            'data': row,
            'total': total,

        })
        return True


class VsUpgradeAuditDetailHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def put(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        r_id = int(kwargs['id'])
        payload = self.get_payload()
        sc = session()
        r = sc.query(LiveStrategyChangeRequest).filter(LiveStrategyChangeRequest.id == r_id).first()
        if not r:
            self.json_response({
                'code': 3004,
                'error': 'can not find strategy file change request',
            })
            sc.close()
            return False

        status = payload.get('status', '')
        if status not in ('APPROVED', 'REJECTED'):
            self.json_response({
                'code': 3006,
                'error': 'status must be APPROVED or REJECTED',
            })
            sc.close()
            return False
        if r.status in ('APPROVED', 'REJECTED'):
            self.json_response({
                'code': 3007,
                'error': 'request is already audited',
            })
            sc.close()
            return False

        r.status = status
        r.audit_user_id = self.current_user['id']
        r.auditer = self.current_user['username']
        r.audit_msg = payload.get('msg', '')

        old_portfolio, old_vs = sc.query(StrategyPortfolio, VStrategies).filter(
            StrategyPortfolio.id == VStrategies.portfolio_id,
            VStrategies.id == r.vs_id
        ).first()

        new_strategy = sc.query(Strategy).filter(
            Strategy.id == r.new_strategy_id,
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
        ).first()

        new_portfolio = StrategyPortfolio(
            name=old_portfolio.name + '_Upgrade_' + r.trading_date,
            fund=old_portfolio.fund,
            description=old_portfolio.description,
            status=13,
            r_create_user_id=old_portfolio.r_create_user_id,
            r_update_user_id=old_portfolio.r_update_user_id,
            live_time=r.trading_date.strftime('%Y-%m-%d 00:00:00'),
            username=old_portfolio.username,
            source=old_portfolio.source,
        )
        sc.add(new_portfolio)
        sc.flush()

        forex_rate = KdbQuery().get_forex_rate(datetime.datetime.now().strftime('%Y.%m.%d'))

        old_vs_accounts = {}
        for acc in old_vs.symbols_accounts:
            exch = acc['exchange']
            currency = acc.get('currency', 'CNY')
            _amount = acc['amount'] if currency == 'CNY' else acc['amount_rmb']
            _actual_amount = acc['actual_amount'] if currency == 'CNY' else acc['actual_amount_rmb']
            if exch not in old_vs_accounts:
                old_vs_accounts[exch] = {
                    'account': acc['account'],
                    'amount': _amount,
                    'actual_amount': _actual_amount,
                }
            else:
                if old_vs_accounts[exch]['account'] != acc['account']:
                    raise ValueError('account error')
                else:
                    old_vs_accounts[exch]['amount'] += _amount
                    old_vs_accounts[exch]['actual_amount'] += _actual_amount

        symbols_accounts = []
        exchange2products = {}

        for p in new_strategy.products[0]:
            exchange2products[p['exch']] = exchange2products.get(p['exch'], []) + [p['symbol']]

        for p in new_strategy.products[0]:
            if p['exch'] in (consts.FUTURE_EXCHANGE + consts.FOREIGN_EXCHANGE):
                if p['exch'] == 'LME':
                    rank = ''
                else:
                    rank = '|'.join(sorted(map(str, p['rank'])))
            elif p['type'] == 'index':
                rank = 'index'
            elif p['exch'] in ('SSE', 'SZSE'):
                rank = 'stock'
            else:
                rank = ''

            amount = float(old_vs_accounts[p['exch']]['amount']) / len(exchange2products[p['exch']])
            actual_amount = float(old_vs_accounts[p['exch']]['actual_amount']) / len(exchange2products[p['exch']])

            _symbol_account = {
                'product': p['symbol'],
                'account': old_vs_accounts[p['exch']]['account'],
                'exchange': p['exch'],
                'amount': amount,
                'rank': rank,
                'max_vol': '',
                'currency': 'USD' if p['exch'].upper() in consts.FOREIGN_EXCHANGE else 'CNY',
                'actual_amount': actual_amount,
                'amount_rmb': amount,
                'actual_amount_rmb': actual_amount,
                'rate': 1,
            }
            if _symbol_account['currency'] != 'CNY':
                _symbol_account['amount'] /= forex_rate[_symbol_account['currency'].lower()]
                _symbol_account['actual_amount'] /= forex_rate[_symbol_account['currency'].lower()]
                _symbol_account['rate'] = forex_rate[_symbol_account['currency'].lower()]
            symbols_accounts.append(_symbol_account)

        if new_strategy.day_night == 2:
            symbols_accounts_detail = {
                'day': symbols_accounts,
                'night': symbols_accounts,
            }
        elif new_strategy.day_night == 1:
            symbols_accounts_detail = {
                'day': [],
                'night': symbols_accounts,
            }
        elif new_strategy.day_night == 0:
            symbols_accounts_detail = {
                'day': symbols_accounts,
                'night': []
            }
        else:
            sc.rollback()
            sc.close()
            self.json_response({
                'code': 1118,
                'error': 'strategy day_night() is error' % new_strategy.day_night
            })
            return

        new_vs = VStrategies(
            status=13,
            portfolio_id=new_portfolio.id,
            strategy_id=r.new_strategy_id,
            strategy_weight=1,
            symbols_accounts_detail=symbols_accounts_detail,
            source=old_vs.source,
            name=old_vs.name,
        )
        sc.add(new_vs)
        sc.flush()
        r.new_portfolio_name = new_portfolio.name
        r.new_vs_id = new_vs.id
        new_strategy.strategy_status = 'LT'
        if not new_strategy.live_time:
            new_strategy.live_time = r.trading_date.strftime('%Y-%m-%d 00:00:00')
        sc.commit()
        if status == 'APPROVED':
            user_emails = [
                u[0] for u in sc.query(Users.email).filter(Users.id.in_([r.r_create_user_id, self.current_user['id']]))
            ]
            title = '%s 策略升级审核通知' % r.new_strategy_id_no
            user_emails.extend(
                [
                    CompanyEmailGroup.quant_dev,
                    CompanyEmailGroup.quant_ops,
                    CompanyEmailGroup.LiShaoFeng,
                    CompanyEmailGroup.LuoYang,
                    CompanyEmailGroup.ZengDan
                ]
            )
            msg = '请部署 %s策略, 并停掉%s的相关定时任务' % (r.new_strategy_id_no, r.vs_id)
        else:
            user_emails = [
                u[0] for u in sc.query(Users.email).filter(Users.id.in_([r.r_create_user_id, self.current_user['id']]))
            ]
            title = '%s 策略升级审核通知' % r.new_strategy_id_no
            msg = '策略升级审核不通过，原因:%s' % r.audit_msg
        if config.Debug:
            user_emails = [CompanyEmailGroup.quant_dev_test]
        upgrade_vs_position.delay(r.vs_id, r.new_vs_id, r.trading_date)
        sc.close()
        send_email(title, msg, list(set(user_emails)))
        notify_operation_wechat(title + ':' + msg)
        self.json_response({
            'code': 0,
            'data': '',
        })
        return True


class VstrategiesServerHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):

        business = ['stock', 'future']
        if self.is_stock_page():
            business = ['stock']
        elif self.is_future_page():
            business = ['future']

        sc = session()
        servers = [r[0] for r in
                   sc.query(distinct(LiveQuoteServer.server)).filter(LiveQuoteServer.business.in_(business))]
        servers.insert(0, 'default')
        self.json_response({
            'code': 0,
            'data': servers,
        })
        return True


class StrategyToBeDeleteListHandler(CurrentUserMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False

        page = int(self.get_argument('page', 0))
        size = int(self.get_argument('size', 20))

        sc = session()
        group_ids = self.get_user_group()

        strategies = sc.query(
            Strategy.id.label('id'),
            Strategy.id_no.label('id_no'),
            Strategy.username.label('username'),
            Strategy.r_create_time.label('r_create_time'),
            ToBeDeletedStrategy.r_create_time.label('tobedeleted_time'),
        ).join(
            ToBeDeletedStrategy, ToBeDeletedStrategy.strategy_id == Strategy.id
        ).filter(
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
        )
        if not ((self.current_user['is_superuser']) or (3 in group_ids)):
            strategies = strategies.filter(
                Strategy.r_create_user_id == self.current_user['id']
            )

        total = strategies.count()
        strategies = strategies.order_by(Strategy.id.desc()).offset(page * size).limit(size)

        data = []
        for s in strategies:
            data.append({
                'id': s.id,
                'id_no': s.id_no,
                'username': s.username,
                'r_create_time': s.r_create_time.strftime('%Y%m%d %X'),
                'tobedeleted_time': s.tobedeleted_time.strftime('%Y%m%d %X'),
            })
        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'total': total,
                'strategies': data,
            },
            'total': total,
        })
        return True


class StrategyToBeDeleteHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):

        self.get_current_user()
        if not self.current_user:
            return False

        strategy_id = int(kwargs['id'])
        group_ids = self.get_user_group()
        if not ((self.current_user['is_superuser']) or (3 in group_ids)):
            self.json_response({
                'code': 1124,
                'error': 'only investment group has permission'
            })
            return True

        sc = session()
        s = sc.query(
            ToBeDeletedStrategy
        ).filter(
            ToBeDeletedStrategy.strategy_id == strategy_id
        ).first()
        if not s:
            s = ToBeDeletedStrategy(
                r_create_user_id=self.current_user['id'],
                strategy_id=strategy_id
            )
            sc.add(s)
            sc.commit()
        sc.close()
        self.json_response({
            'code': 0,
            'data': {},
        })
        return

    @gen.coroutine
    def delete(self, *args, **kwargs):

        self.get_current_user()
        if not self.current_user:
            return False

        strategy_id = int(kwargs['id'])
        group_ids = self.get_user_group()
        if not ((self.current_user['is_superuser']) or (3 in group_ids)):
            self.json_response({
                'code': 1124,
                'error': 'only investment group has permission'
            })
            return True

        sc = session()
        sc.query(
            ToBeDeletedStrategy
        ).filter(
            ToBeDeletedStrategy.strategy_id == strategy_id
        ).delete()
        sc.commit()
        sc.close()
        self.json_response({
            'code': 0,
            'data': {},
        })
        return


class StrategyConfidenceHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):

        self.get_current_user()
        if not self.current_user:
            return False

        strategy_id = int(kwargs['id'])

        pay_load = self.get_payload()
        confidence = float(pay_load['confidence'])

        sc = session()
        s = sc.query(Strategy).filter(
            Strategy.id == strategy_id
        ).first()
        if not s:
            self.json_response({
                'code': 1300,
                'error': 'can not find strategy'
            })
            return True
        if confidence == float(s.confidence):
            sc.close()
            self.json_response({
                'code': 0,
                'data': {}
            })
            return True
        s.confidence = confidence
        sc.commit()
        update_strategy_confidence.delay(s.id)
        sc.close()
        self.json_response({
            'code': 0,
            'data': {}
        })
        return True

    @gen.coroutine
    def get(self, *args, **kwargs):

        self.get_current_user()
        if not self.current_user:
            return False

        strategy_id = int(kwargs['id'])

        sc = session()
        s = sc.query(Strategy.confidence).filter(
            Strategy.id == strategy_id
        ).first()
        if not s:
            self.json_response({
                'code': 1300,
                'error': 'can not find strategy'
            })
            return True
        confidence = float(s[0])
        sc.close()
        self.json_response({
            'code': 0,
            'data': {
                'confidence': confidence
            }
        })
        return True


class StockVsUpgradeHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        pay_load = self.get_payload()
        old_vs_id = pay_load['vs_id']
        account = pay_load['account']
        cash = float(pay_load['cash'])
        portfolio_name = pay_load['portfolio_name']
        new_strategy_id = pay_load['new_strategy_id']

        trading_calendar = TradeCalendar.init_from_kdb(**config.kdb_config)
        today = datetime.datetime.today()
        if trading_calendar.is_trading_date() and today.strftime('%H%M') <= '0930':
            live_time = today.date()
        else:
            live_time = trading_calendar.get_next_trading_date().astype(datetime.date)

        # now = datetime.datetime.now()
        # week_day = now.weekday()
        # now_hour = now.strftime('%H%M')
        # if week_day == 5:
        #     live_time = (now + datetime.timedelta(days=2)).strftime('%Y-%m-%d 00:00:00')
        # elif week_day == 6:
        #     live_time = (now + datetime.timedelta(days=1)).strftime('%Y-%m-%d 00:00:00')
        # else:
        #     if now_hour <= '0930':
        #         live_time = now.strftime('%Y-%m-%d 00:00:00')
        #     else:
        #         if week_day == 4:
        #             live_time = (now + datetime.timedelta(days=3)).strftime('%Y-%m-%d 00:00:00')
        #         else:
        #             live_time = (now + datetime.timedelta(days=1)).strftime('%Y-%m-%d 00:00:00')

        sc = session()
        old_portfolio, old_vs = sc.query(StrategyPortfolio, VStrategies).filter(
            StrategyPortfolio.id == VStrategies.portfolio_id,
            VStrategies.id == old_vs_id
        ).first()

        new_strategy = sc.query(Strategy).filter(
            Strategy.id_no == new_strategy_id,
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
        ).first()

        new_portfolio = StrategyPortfolio(
            name=portfolio_name,
            fund=cash,
            description=pay_load.get('desc', '') or '',
            r_create_user_id=old_portfolio.r_create_user_id,
            username=old_portfolio.username,
            live_time=live_time,
            status=consts.STRATEGY_TOBE_AUDITED,
            source='platform',
            business=old_portfolio.business,
        )
        sc.add(new_portfolio)
        sc.flush()

        symbols_accounts = []
        exchange2products = {}
        for p in new_strategy.products[0]:
            exchange2products[p['exch']] = exchange2products.get(p['exch'], []) + [p['symbol']]
        for p in new_strategy.products[0]:
            if p['exch'] in (consts.FUTURE_EXCHANGE + consts.FOREIGN_EXCHANGE):
                if p['exch'] == 'LME':
                    rank = ''
                else:
                    rank = '|'.join(sorted(map(str, p['rank'])))
            elif p['type'] == 'index':
                rank = 'index'
            elif p['exch'] in ('SSE', 'SZSE'):
                if p['type'] == 'stock_factor_FACTOR':
                    rank = 'stock_factor'
                else:
                    rank = 'stock'
            else:
                rank = ''

            amount = cash / len(new_strategy.products[0])
            actual_amount = amount
            _symbol_account = {
                'product': p['symbol'],
                'account': account,
                'exchange': p['exch'],
                'amount': amount,
                'rank': rank,
                'max_vol': '',
                'currency': 'CNY',
                'actual_amount': actual_amount,
                'amount_rmb': amount,
                'actual_amount_rmb': actual_amount,
                'rate': 1,
            }
            symbols_accounts.append(_symbol_account)

        if new_strategy.day_night == 2:
            symbols_accounts_detail = {
                'day': symbols_accounts,
                'night': symbols_accounts,
            }
        elif new_strategy.day_night == 1:
            symbols_accounts_detail = {
                'day': [],
                'night': symbols_accounts,
            }
        elif new_strategy.day_night == 0:
            symbols_accounts_detail = {
                'day': symbols_accounts,
                'night': []
            }
        else:
            symbols_accounts_detail = {
                'day': [],
                'night': []
            }

        vs_paras = {
            'portfolio_id': new_portfolio.id,
            'strategy_id': new_strategy.id,
            'strategy_weight': 1,
            'symbols_accounts_detail': symbols_accounts_detail,
            'status': consts.STRATEGY_TOBE_AUDITED,
            'source': 'platform',
            'group_id': 0,
        }
        vs = VStrategies(**vs_paras)
        sc.add(vs)
        sc.commit()

        on_line_request = OnlineRequest(
            portfolio_id=new_portfolio.id,
            status=0,
            action=0,
            r_create_user=old_portfolio.username
        )
        sc.add(on_line_request)
        sc.commit()

        vs_account_detail = VStrategyAccountDetail(
            vstrategy_id=vs.id,
            portfolio_id=new_portfolio.id,
            account=account,
            amount=cash,
            actual_amount=cash,
            exchange='SSE',
        )
        sc.add(vs_account_detail)
        sc.commit()
        sc.close()
        notify_operation_wechat('新组合(%s)提交实盘，请尽快审核并部署' % portfolio_name)
        self.json_response({
            'code': 0,
            'data': {}
        })
        return True


class StrategyEvFilterHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self):
        '''
        :return: 根据过滤字段date 和 day_night 返回evs
        '''
        self.get_current_user()
        if not self.current_user:
            return False
        trading_date = self.get_argument('date', '')
        day_night = int(self.get_argument('day_night', -1))
        if trading_date:
            # 校验date：规范
            try:
                datetime.datetime.strptime(trading_date, '%Y%m%d')
            except ValueError:
                self.json_response({
                    'code': 1300,
                    'error': 'The date format is incorrect, the correct date format for example : 20190625',
                })
                return True

        # 校验参数day_night的合法性
        if day_night not in [0, 1, -1]:
            self.json_response({
                'code': 1300,
                'data': 'day_night must be 0 or 1 or -1',
            })

        data = live_ev_check2(trading_date=trading_date, day_night=day_night)
        self.json_response({
            'code': 0,
            'data': sorted(data.values(), key=lambda d: d['id']),
        })
        return True


class StrategyEvErrorLogHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, id):
        '''
        :param id: ev_id
        :return: 返回ev的错误日志
        '''
        self.get_current_user()
        if not self.current_user:
            return False
        # 校验date：必传+规范
        try:
            date = self.get_argument('date')
        except MissingArgumentError:
            self.json_response({
                'code': 1300,
                'error': 'Missing argument date'
            })
            return True

        try:
            datetime.datetime.strptime(date, '%Y%m%d')
        except ValueError:
            self.json_response({
                'code': 1300,
                'error': 'The date format is incorrect, the correct date format for example : 20190625',
            })
            return True

        sc = session()
        strategy_result = sc.query(StrategyResult).filter(
            StrategyResult.strategy_id == id,
            StrategyResult.date == date
        ).first()
        if not strategy_result:
            sc.close()
            self.json_response({
                'code': 1300,
                'error': 'can not find strategy_result'
            })
            return True

        error_log_msg = strategy_result.detail if strategy_result.status != 0 else None
        sc.close()
        self.json_response({
            'code': 0,
            'data': error_log_msg
        })
        return True


class StrategyEvDependHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, id):
        '''
        :param id: ev_id
        :return: ev的所有依赖
        '''
        self.get_current_user()
        if not self.current_user:
            return False
        # 校验trading_date：必传+规范
        try:
            trading_date = self.get_argument('date')
        except MissingArgumentError:
            self.json_response({
                'code': 1300,
                'error': 'Missing argument date'
            })
            return True
        try:
            datetime.datetime.strptime(trading_date, '%Y%m%d')
        except ValueError:
            self.json_response({
                'code': 1300,
                'data': 'The date format is incorrect, the correct date format for example : 20190625',
            })
        day_night = int(self.get_argument('day_night', '-1'))

        # 校验day_night
        if day_night not in [0, 1, -1]:
            self.json_response({
                'code': 1300,
                'data': 'day_night must be 0 or 1 or -1',
            })
        # 获取当前ev的所有依赖
        res = get_strategy_dep_id(id)
        # 返回''代表没有数据库中没有改ev
        if res == '':
            self.json_response({
                'code': 1300,
                'error': 'can not find strategy'
            })
            return True
        sc = session()
        ev_deps = sc.query(Strategy.id, Strategy.name, Strategy.status).filter(Strategy.id.in_(res))
        ev_deps_list = [{**{'id': ev_dep.id,
                            'name': ev_dep.name},
                         **get_filename_and_status(ev_dep.id, trading_date, day_night)}
                        for ev_dep in ev_deps]
        sc.close()
        self.json_response({
            'code': 0,
            'data': ev_deps_list

        })
        return True


class StrategyAlphasAndTosHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self):
        """
        return: alpha策略和t0策略，以及每个策略的账户
        """
        self.get_current_user()
        if not self.current_user:
            return False

        sc = session()
        four_table_records = sc.query(VStrategies.id, StrategyPortfolio.name, Strategy.id_no, Strategy.strategy_type,
                                      VStrategyAccountDetail.account).join(
            Strategy, Strategy.id == VStrategies.strategy_id).join(
            StrategyPortfolio, VStrategies.portfolio_id == StrategyPortfolio.id).join(
            VStrategyAccountDetail, VStrategyAccountDetail.vstrategy_id == VStrategies.id).filter(
            VStrategyAccountDetail.trading_date.is_(None),
            VStrategies.status == VStrategiesConstant.Status.Live.value
        ).all()

        alphas = {}
        t0s = {}
        for ret in four_table_records:
            if ret.strategy_type in consts.alpha_stock_strategy_type:
                if ret.id in alphas:
                    if ret.account not in alphas[ret.id]['accounts']:
                        alphas[ret.id]['accounts'].append(ret.account)
                else:
                    alphas[ret.id] = {'name': ret.name, 'id_no': ret.id_no, 'accounts': [ret.account, ]}
            if ret.strategy_type in consts.t0_stock_strategy_type:
                if ret.id in t0s:
                    if ret.account not in t0s[ret.id]['accounts']:
                        t0s[ret.id]['accounts'].append(ret.account)
                else:
                    t0s[ret.id] = {'name': ret.name, 'id_no': ret.id_no, 'accounts': [ret.account, ]}

        sc.close()
        self.json_response({
            'code': 0,
            'data': {'alphas': alphas,
                     't0s': t0s,
                     }
        })
        return True


class StrategyAlphasAndHedgesHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    def get(self, *args, **kwargs):
        """
        return: alpha策略和hedge策略
        """
        self.get_current_user()
        if not self.current_user:
            return

        sc = session()
        records = sc.query(VStrategies.id, StrategyPortfolio.name, Strategy.id_no, Strategy.strategy_type,
                           VStrategyAccountDetail.account).join(
            Strategy, Strategy.id == VStrategies.strategy_id).join(
            StrategyPortfolio, VStrategies.portfolio_id == StrategyPortfolio.id).join(
            VStrategyAccountDetail, VStrategyAccountDetail.vstrategy_id == VStrategies.id).filter(
            VStrategyAccountDetail.trading_date.is_(None),
            VStrategies.status == VStrategiesConstant.Status.Live.value
        ).all()

        alphas = {}
        hedges = {}
        for r in records:
            if r.strategy_type in consts.alpha_stock_strategy_type:
                if r.id in alphas:
                    if r.account not in alphas[r.id]['accounts']:
                        alphas[r.id]['accounts'].append(r.account)
                else:
                    alphas[r.id] = {'name': r.name, 'id_no': r.id_no, 'accounts': [r.account]}
            if r.strategy_type in consts.hedge_stock_strategy_type:
                if r.id in hedges:
                    if r.account not in hedges[r.id]['accounts']:
                        hedges[r.id]['accounts'].append(r.account)
                else:
                    hedges[r.id] = {'name': r.name, 'id_no': r.id_no, 'accounts': [r.account]}

        sc.close()
        data = {
            'alphas': alphas,
            'hedges': hedges
        }
        self.json_response({
            'code': 0,
            'data': data
        })


class StrategyHedgeSubscriberHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    def get(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return

        sc = session()
        hedge_alpha_records = sc.query(StockHedgeVs).join(
            VStrategies, VStrategies.id == StockHedgeVs.stock_vs_id).filter(
            StockHedgeVs.valid == True,
            VStrategies.status.in_(VStrategiesConstant.Status.normal_status())
        ).all()
        all_vs_ids = [r.stock_vs_id for r in hedge_alpha_records] + [r.future_vs_id for r in hedge_alpha_records]
        all_vs_ids = list(set(all_vs_ids))
        vs_records = sc.query(VStrategies.id.label('vs_id'), StrategyPortfolio.name, Strategy.id_no).join(
            Strategy, Strategy.id == VStrategies.strategy_id).join(
            StrategyPortfolio, VStrategies.portfolio_id == StrategyPortfolio.id
        ).filter(
            VStrategies.id.in_(all_vs_ids)
        ).all()
        vs_info = {r.vs_id: {'name': r.name, 'id_no': r.id_no} for r in vs_records}
        sc.close()

        hedge_alpha_dic = {}
        for r in hedge_alpha_records:
            alpha_info = {
                "vs_id": r.stock_vs_id,
            }
            alpha_info.update(vs_info[r.stock_vs_id])
            hedge_info = {
                "vs_id": r.future_vs_id,
            }
            hedge_info.update(vs_info[r.future_vs_id])
            hedge_alpha_dic.update({
                r.id: {
                    "alpha": alpha_info,
                    "hedge": hedge_info
                }
            })

        self.json_response({
            'code': 0,
            'data': hedge_alpha_dic,
        })

    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return

        # post data validation
        payload = self.get_payload()
        if not payload:
            self.json_response({
                'code': 1300,
                'error': 'alpha vs id and hedge vs id needed'
            })
            return
        alpha_vs_id = payload.get('alpha_vs_id', None)
        hedge_vs_id = payload.get('hedge_vs_id', None)
        if not (alpha_vs_id and hedge_vs_id):
            self.json_response({
                'code': 1300,
                'error': 'alpha vs id and hedge vs id needed'
            })
            return

        with session_context() as sc:
            record = StockHedgeVs(stock_vs_id=alpha_vs_id, future_vs_id=hedge_vs_id)
            sc.add(record)

        self.json_response({
            'code': 0,
            'data': 'success'
        })

    def delete(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return

        record_ids = self.get_argument('record_ids', None)
        if not record_ids:
            self.json_response({
                'code': 1300,
                'error': 'record ids needed'
            })
            return
        record_ids = [int(ele) for ele in record_ids.split(',')]
        if record_ids:
            with session_context() as sc:
                records = sc.query(StockHedgeVs).filter(StockHedgeVs.id.in_(record_ids)).all()
                for r in records:
                    r.valid = False

        self.json_response({
            'code': 0,
            'data': 'success',
        })


class VStrategyReplacementInfoHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    def get(self, *args, **kwargs):
        vs_id = int(self.get_argument('vs_id', 0))
        self.json_response({
            'code': 0,
            'data': VstrategyUpgrade.get_vs_replacement(vs_id) if vs_id else {}
        })

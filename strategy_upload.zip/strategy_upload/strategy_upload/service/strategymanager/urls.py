# -*-coding:utf-8-*-

from service.strategymanager.handlers import *

urls = [
    (r'/api/v1/platform/strategymanager/sofile$', StrategySoChangeHandler),
    (r'/api/v1/platform/strategymanager/sofile/strategy$', StrategySoChangeStrategyHandler),
    (r'/api/v1/platform/strategymanager/sofile/audit$', StrategySoChangeAuditHandler),
    (r'/api/v1/platform/strategymanager/sofile/audit/(?P<id>\d+)$', StrategySoChangeAuditDetailHandler),
    (r'/api/v1/platform/strategymanager/strategy/basic/(?P<id>\w+)$', StrategyManagerBasicHandler),
    (r'/api/v1/platform/strategymanager/strategy/ev/(?P<id>\d+)$', EvRedoHandler),
    (r'/api/v1/platform/strategymanager/strategy/papertrading/(?P<id>\d+)$', StrategyPaperTradingRedoHandler),
    # 盘后分析->重新运行
    (r'/api/v1/platform/strategymanager/vstrategy/backtest/(?P<id>\d+)$', VstrategiesbacktestRedoHandler),

    (r'/api/v1/platform/strategymanager/trading_dates$', TradingDatesHandler),
    (r'/api/v1/platform/strategymanager/vs_upgrade$', VsUpgradeRequestHandler),
    (r'/api/v1/platform/strategymanager/vs_upgrade/strategy$', VsUpgradeStrategyHandler),
    (r'/api/v1/platform/strategymanager/vs_upgrade/audit$', VsUpgradeAuditHandler),
    (r'/api/v1/platform/strategymanager/vs_upgrade/audit/(?P<id>\d+)$', VsUpgradeAuditDetailHandler),

    # vs replacement info
    (r'/api/v1/platform/strategymanager/vs_replacement_info$', VStrategyReplacementInfoHandler),

    (r'/api/v1/platform/strategymanager/vstrategy/backtest$', VstrategiesbacktestDetailHandler),

    (r'/api/v1/platform/strategymanager/strategy/papertrading$', StrategyPapertradingDetailHandler),

    (r'/api/v1/platform/strategymanager/strategy/pending$', StrategyToBeDeleteListHandler),
    (r'/api/v1/platform/strategymanager/strategy/pending/(?P<id>\d+)$', StrategyToBeDeleteHandler),

    (r'/api/v1/platform/strategymanager/strategy/ev$', StrategyEvDetailHandler),

    (r'/api/v1/platform/strategymanager/server$', VstrategiesServerHandler),

    (r'/api/v1/platform/strategymanager/strategy/confidence/(?P<id>\d+)$', StrategyConfidenceHandler),

    (r'/api/v1/platform/strategymanager/stock/vs/upgrade$', StockVsUpgradeHandler),

    (r'/api/v1/platform/strategymanager/strategy/evs$', StrategyEvFilterHandler),

    (r'/api/v1/platform/strategymanager/ev/dependencies/(?P<id>\d+)$', StrategyEvDependHandler),
    # operation/ev-manager.htm中查看error_log
    (r'/api/v1/platform/strategymanager/ev/errorlogs/(?P<id>\d+)$', StrategyEvErrorLogHandler),

    (r'/api/v1/platform/strategymanager/strategy/alphas_and_t0s$', StrategyAlphasAndTosHandler),

    # (r'/api/v1/platform/strategymanager/strategy/t0_subscriber$', StrategyT0SubscriberHandler),
    # 修改t0_subscriber属性
    # (r'/api/v1/platform/strategymanager/strategy/t0_subscriber_attribute$', StrategyT0SubscriberAttributeHandler),

    (r'/api/v1/platform/strategymanager/strategy/alphas_and_hedges$', StrategyAlphasAndHedgesHandler),

    (r'/api/v1/platform/strategymanager/strategy/hedge_subscriber$', StrategyHedgeSubscriberHandler),

]

# -*-coding:utf-8-*-

import os
import datetime
import copy
from sqlalchemy import func
from dateutil.parser import parse

from service.back_test.models import Strategy, VStrategies, StrategyResult, StockSmartExecutionVersion
from db import session
from kdb_query import KdbQuery

import consts
from config import config


def get_link(val):
    return '<a href="https://quant.mycapital.net{}">tail10</a>'.format(val)


def live_ev_check():
    sc = session()
    trading_date = Strategy.get_trading_date()
    now_hour = datetime.datetime.now().hour

    if 5 <= now_hour < 18:
        day_night = 0
        day_night_str = 'day'
    else:
        day_night = 1
        day_night_str = 'night'

    strategies = sc.query(
        Strategy.dependency
    ).join(
        VStrategies, VStrategies.strategy_id == Strategy.id
    ).filter(
        VStrategies.status == 15,
        Strategy.day_night.in_([day_night, 2]),
    )

    ev_ids = set([dep['id'] for s in strategies for dep in (s[0] or [])])

    if day_night == 0:
        ev_ids.update(consts.STOCK_FACTOR_EV)
        for smart_s in sc.query(Strategy).filter(
                Strategy.id.in_(sc.query(StockSmartExecutionVersion.strategy_id))
        ):
            ev_ids.update([_dep['id'] for _dep in (smart_s.dependency or [])])

    ev_strategies = sc.query(
        Strategy
    ).filter(
        Strategy.id.in_(ev_ids)
    )

    today_ev_files = sc.query(
        StrategyResult.strategy_id.label('ev_id'),
        StrategyResult.result_file_name.label('result_file_name'),
    ).filter(
        StrategyResult.strategy_id.in_(ev_ids),
        StrategyResult.date == trading_date,
        StrategyResult.config_id == 0,
        StrategyResult.status == consts.TASK_FINISHED,
        StrategyResult.result_file_name.isnot(None),
    )
    today_ev_files = {r.ev_id: r.result_file_name for r in today_ev_files}

    last_date_files = sc.query(
        StrategyResult.strategy_id.label('ev_id'),
        func.max(StrategyResult.date).label('date'),
    ).filter(
        StrategyResult.strategy_id.in_(ev_ids),
        StrategyResult.date < trading_date,
        StrategyResult.config_id == 0,
        StrategyResult.status == consts.TASK_FINISHED,
        StrategyResult.result_file_name.isnot(None),
    ).group_by(
        StrategyResult.strategy_id
    )
    last_date_files = {r.ev_id: r.date for r in last_date_files}

    data = {}

    for ev in ev_strategies:
        ev_name = ev.name.strip().replace(' ', '')
        filename = """strategy_upload/output/{username}/{ev_name}/ev_output_{trading_date}_{ev_id}_{day_night_str}.csv""".format(
            **{
                'username': ev.username,
                'ev_name': ev_name,
                'trading_date': trading_date,
                'ev_id': ev.id,
                'day_night_str': day_night_str,
            })

        if filename not in today_ev_files.get(ev.id, ''):
            filename = 'N/A'

        last_date = last_date_files.get(ev.id, '')
        if last_date:
            last_filename = """strategy_upload/output/{username}/{ev_name}/ev_output_{trading_date}_{ev_id}_{day_night_str}.csv""".format(
                **{
                    'username': ev.username,
                    'ev_name': ev_name,
                    'trading_date': last_date,
                    'ev_id': ev.id,
                    'day_night_str': day_night_str,
                })
        else:
            last_filename = 'N/A'

        data[ev.id] = {
            'id': ev.id,
            'user_name': ev.username,
            'name': ev_name,
            'filename': filename,
            'short_filename': os.path.basename(filename),
            'file_link': os.path.join('/media', filename),
            'size': '',
            'line': 0,
            'last_filename': last_filename,
            'short_last_filename': os.path.basename(last_filename),
            'last_file_link': os.path.join('/media', last_filename),
            'last_size': '',
            'last_lines': 0,
            'tail10': '/api/v1/platform/strategymanager/strategy/ev/{ev_id}/tail10'.format(ev_id=ev.id)
        }

    for ev_id, ev_file in data.items():
        ev_file_stat = get_file_stat(ev_file['filename'])
        ev_file['filename'] = ev_file_stat['filename']
        ev_file['size'] = ev_file_stat['size']
        ev_file['lines'] = ev_file_stat['line']

        ev_file_stat = get_file_stat(ev_file['last_filename'])
        ev_file['last_filename'] = ev_file_stat['filename']
        ev_file['last_size'] = ev_file_stat['size']
        ev_file['last_lines'] = ev_file_stat['line']

    return data


def get_file_size(size):
    def strofsize(integer, remainder, level):
        if integer >= 1024:
            remainder = integer % 1024
            integer //= 1024
            level += 1
            return strofsize(integer, remainder, level)
        else:
            return integer, remainder, level

    units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB']
    integer, remainder, level = strofsize(size, 0, 0)
    if level + 1 > len(units):
        level = -1
    return '{}.{:>03d} {}'.format(integer, remainder, units[level])


def get_file_stat(filename):
    _fname = os.path.join(config.media, filename)
    try:
        size = get_file_size(os.stat(_fname).st_size)
        line = 'N/A'  # int(os.popen('wc -l "%s"' % _fname).read().split()[0])
    except Exception as e:
        filename = 'N/A'
        size = 'N/A'
        line = 'N/A'

    staus = {
        'filename': filename,
        'size': size,
        'line': line,
    }
    return staus


def live_ev_check2(trading_date='', day_night=-1, check_ev_ids=None):
    sc = session()
    if trading_date:
        trading_date = parse(trading_date).strftime('%Y%m%d')
    else:
        trading_date = Strategy.get_trading_date()

    kdb = KdbQuery()

    try:
        nerbor_dates = kdb.get_nebor_trading_date(trading_date)
        last_trading_date = nerbor_dates['prev']
    except Exception as e:
        last_trading_date = (parse(trading_date) - datetime.timedelta(days=1)).strftime('%Y%m%d')

    now_hour = datetime.datetime.now().hour

    if day_night == -1:
        if 5 <= now_hour < 18:
            day_night = 0
            day_night_str = 'day'
        else:
            day_night = 1
            day_night_str = 'night'
    else:
        day_night_str = {
            0: 'day',
            1: 'night',
        }[day_night]

    strategies = sc.query(
        Strategy.dependency
    ).join(
        VStrategies, VStrategies.strategy_id == Strategy.id
    ).filter(
        VStrategies.status == 15,
        Strategy.day_night.in_([day_night, 2]),
    )

    ev_ids = set([dep['id'] for s in strategies for dep in (s[0] or [])])

    if day_night == 0:
        ev_ids.update(consts.STOCK_FACTOR_EV)
        smart_execution_deps = sc.query(StockSmartExecutionVersion).join(
            Strategy, Strategy.id == StockSmartExecutionVersion.strategy_id).filter(
            StockSmartExecutionVersion.valid == True).with_entities(Strategy.dependency)
        for dep in smart_execution_deps:
            if not dep[0]:
                continue
            ev_ids.update([_dep['id'] for _dep in dep[0]])

    if check_ev_ids:
        ev_ids = copy.deepcopy(check_ev_ids)

    ev_strategies = sc.query(
        Strategy
    ).filter(
        Strategy.id.in_(ev_ids)
    )

    today_ev_files = sc.query(
        StrategyResult.strategy_id.label('ev_id'),
        StrategyResult.result_file_name.label('result_file_name'),
    ).filter(
        StrategyResult.strategy_id.in_(ev_ids),
        StrategyResult.date == trading_date,
        StrategyResult.config_id == 0,
        StrategyResult.status == consts.TASK_FINISHED,
        StrategyResult.result_file_name.isnot(None),
    )
    today_ev_files = {r.ev_id: r.result_file_name for r in today_ev_files}

    # last_date_files = sc.query(
    #     StrategyResult.strategy_id.label('ev_id'),
    #     func.max(StrategyResult.date).label('date'),
    # ).filter(
    #     StrategyResult.strategy_id.in_(ev_ids),
    #     StrategyResult.date < trading_date,
    #     StrategyResult.config_id == 0,
    #     StrategyResult.status == consts.TASK_FINISHED,
    #     StrategyResult.result_file_name.isnot(None),
    # ).group_by(
    #     StrategyResult.strategy_id
    # )
    # last_date_files = {r.ev_id: r.date for r in last_date_files}

    last_date_files = sc.query(
        StrategyResult.strategy_id.label('ev_id'),
        StrategyResult.date.label('date'),
    ).filter(
        StrategyResult.strategy_id.in_(ev_ids),
        StrategyResult.date == last_trading_date,
        StrategyResult.config_id == 0,
        StrategyResult.status == consts.TASK_FINISHED,
        StrategyResult.result_file_name.isnot(None),
    )
    last_date_files = {r.ev_id: r.date for r in last_date_files}

    data = {}

    for ev in ev_strategies:
        ev_name = ev.name.strip().replace(' ', '')
        filename = """strategy_upload/output/{username}/{ev_name}/ev_output_{trading_date}_{ev_id}_{day_night_str}.csv""".format(
            **{
                'username': ev.username,
                'ev_name': ev_name,
                'trading_date': trading_date,
                'ev_id': ev.id,
                'day_night_str': day_night_str,
            })

        if filename not in today_ev_files.get(ev.id, ''):
            filename = 'N/A'

        last_date = last_date_files.get(ev.id, '')
        if last_date:
            last_filename = """strategy_upload/output/{username}/{ev_name}/ev_output_{trading_date}_{ev_id}_{day_night_str}.csv""".format(
                **{
                    'username': ev.username,
                    'ev_name': ev_name,
                    'trading_date': last_date,
                    'ev_id': ev.id,
                    'day_night_str': day_night_str,
                })
        else:
            last_filename = 'N/A'

        data[ev.id] = {
            'id': ev.id,
            'user_name': ev.username,
            'name': ev_name,
            'filename': filename,
            'short_filename': os.path.basename(filename),
            'file_link': os.path.join('/media', filename),
            'size': '',
            'line': 0,
            'last_filename': last_filename,
            'short_last_filename': os.path.basename(last_filename),
            'last_file_link': os.path.join('/media', last_filename),
            'last_size': '',
            'last_lines': 0,
            'tail10': '/api/v1/platform/strategymanager/strategy/ev/{ev_id}/tail10'.format(ev_id=ev.id)
        }

    for ev_id, ev_file in data.items():
        ev_file_stat = get_file_stat(ev_file['filename'])
        ev_file['filename'] = ev_file_stat['filename']
        ev_file['size'] = ev_file_stat['size']
        ev_file['lines'] = ev_file_stat['line']

        ev_file_stat = get_file_stat(ev_file['last_filename'])
        ev_file['last_filename'] = ev_file_stat['filename']
        ev_file['last_size'] = ev_file_stat['size']
        ev_file['last_lines'] = ev_file_stat['line']

    return data


def get_strategy_dep_id(s_id):
    '''
    递归获取某个ev的所有依赖
    '''
    sc = session()
    s = sc.query(Strategy).filter(Strategy.id == s_id).first()
    if not s:
        sc.close()
        return []
    dep_s_ids = [dep['id'] for dep in s.dependency]
    factor_ids = [int(p['symbol'].split('_')[2]) for p in s.products[0] if p.get('type', '') == 'stock_factor_FACTOR']
    res = dep_s_ids + factor_ids
    dep_s_ids.extend(factor_ids)
    sc.close()
    for dep_id in dep_s_ids:
        res.extend(get_strategy_dep_id(dep_id))
    return sorted(set(res))


def get_filename_and_status(ev_id, trading_date, day_night):
    '''
    :param ev_id: ev的依赖的id
    :param : trading_date： 交易日期
    :param : day_night：  0：日盘   1：夜盘
    :return: filename和该filename
             dependence_status： ‘succeed’ ---成功生成该filename ；‘failed’ ---没有生存该filename
    '''
    now_hour = datetime.datetime.now().hour
    if day_night == -1:
        if 6 <= now_hour < 18:
            day_night = 0
            day_night_str = 'day'
        else:
            day_night = 1
            day_night_str = 'night'
    else:
        day_night_str = {
            0: 'day',
            1: 'night',
        }[day_night]

    sc = session()
    ev = sc.query(Strategy).filter(Strategy.id == ev_id).first()
    ev_name = ev.name.strip().replace(' ', '')
    filename = """strategy_upload/output/{username}/{ev_name}/ev_output_{trading_date}_{ev_id}_{day_night_str}.csv""".format(
        **{
            'username': ev.username,
            'ev_name': ev_name,
            'trading_date': trading_date,
            'ev_id': ev.id,
            'day_night_str': day_night_str,
        })

    strategy_result = sc.query(StrategyResult.result_file_name).filter(StrategyResult.strategy_id == ev_id,
                                                                       StrategyResult.date == trading_date,
                                                                       StrategyResult.status == 0).first()

    sc.close()
    dependence_status = 'succeed'
    if not strategy_result or filename not in strategy_result.result_file_name:
        dependence_status = 'failed'

    return {'filename': filename, 'dependence_status': dependence_status}

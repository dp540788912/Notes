# -*-coding:utf-8-*-

from service.operation_deploy.handlers import *

urls = [
    (r'/api/v1/platform/operation/vstrategy/position$', VstrategyPositionHandler),
    (r'/api/v1/platform/operation/vstrategy/session/position$', VstrategySessionPositionHandler),
    (r'/api/v1/platform/operation/vstrategy/tradelogs$', ManualTradelogsHandler),
    (r'/api/v1/platform/operation/tradelist/audit$', PenghuaAuditTradeList),

    (r'/api/v1/platform/operation/blacklist$', AccountBlackListHandler),

    (r'/api/v1/platform/operation/stock/strategy$', StockStrategyListHandler),

    (r'/api/v1/platform/operation/stock/upgrade/vstrategy$', StockUpgradeVstrategyHandler),
    (r'/api/v1/platform/operation/stock/upgrade/vstrategy/(?P<vs_id>\d+)$', StockUpgradeVstrategyHandler),
    (r'/api/v1/platform/operation/stock/upgrade/conf$', StockUpgradeConfHandler),
    (r'/api/v1/platform/operation/stock/upgrade/position$', StockUpgradePositionHandler),
    (r'/api/v1/platform/operation/stock/upgrade/position_data$', StockUpgradePositionDataHandler),
]

import os
import sys

root_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
if root_path not in sys.path:
    sys.path.append(root_path)
from dateutil.parser import parse
import requests
import pandas as pd
from kdb_query import KdbQuery
from config import config


def get_live_close_price():
    """
    try to get live close price from api,if get kdb data failure
    this close price is not exactly like kdb data
    """

    resp = requests.get("http://%s/api/v1/speedquote/equityquote" % config.quote_api_host)
    data = resp.json()
    df = pd.DataFrame(data["data"], index=['LastPrice'])
    df = df.T
    df["symbol"] = df.index
    df = df.rename(columns={"LastPrice": "trade_price"}, copy=False)
    return df


def make_price_df(trading_date, day_night):
    kdb = KdbQuery()
    kdb_trading_date = trading_date.replace("-", ".")
    if day_night == 1:
        prev_trading_date = kdb.get_nebor_trading_date(kdb_trading_date)['prev']
        kdb_trading_date = parse(prev_trading_date).strftime('%Y.%m.%d')
    sql = '.gw.asyncexec[\"select SYMBOL,S_DQ_CLOSE from AShareEODPrices  where  TRADE_DT=%s\";`EquityFactor]' % kdb_trading_date
    price_df = kdb.async_query(sql, pandas=True)
    if len(price_df.index) == 0:
        price_df = get_live_close_price()
    else:
        price_df.columns = ["symbol", "trade_price"]
        price_df["symbol"], _ = price_df["symbol"].str.decode("utf-8").str.split(".").str
    return price_df

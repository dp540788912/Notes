import os
import sys

root_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
sys.path.append(root_path)
from db import session_context, engine
from service.back_test.models import VStrategies, SettlementManualTradelog, TradeLogs
from sqlalchemy import or_
from .price import make_price_df
from .position import VsIdDBPosition
from datetime import timedelta
import time
from io import StringIO
from constant import CompanyEmailGroup
import pandas as pd
from extensions import sentry

try:
    from errors import SettlementNegativePositionError, SettlementPositionZeroError
except:
    SettlementNegativePositionError = "找到超买超卖错误"
    SettlementPositionZeroError = "找到交易记录顺序错误"


def get_live_vstrategies(vs_id, trading_date):
    """
    get live vs_id at trading_date
    """
    with session_context() as sc:
        vstrategies = sc.query(VStrategies)
        if vs_id != 0:
            vstrategies = vstrategies.filter(VStrategies.id == vs_id)
        else:
            print("find all vs_id trade in today")
            deploy_trade_log_vs_ids = sc.query(
                TradeLogs.vstrategy_id
            ).filter(
                TradeLogs.trading_date == trading_date
            ).distinct()

            deploy_manual_trade_log_vs_ids2 = sc.query(
                SettlementManualTradelog.vstrategy_id
            ).filter(
                SettlementManualTradelog.trading_date == trading_date
            ).distinct()

            deploy_vs_ids = [0]

            deploy_vs_ids.extend([x[0] for x in deploy_trade_log_vs_ids])
            deploy_vs_ids.extend([x[0]
                                  for x in deploy_manual_trade_log_vs_ids2])
            vstrategies = sc.query(VStrategies).filter(
                or_(
                    VStrategies.status == 15,
                    VStrategies.id.in_(
                        deploy_vs_ids
                    )
                )
            )
        rs = [i.id for i in vstrategies]
        return rs


def check_df(df, callback):
    if len(df.index) <= 0:
        return

    gp = df.groupby(['symbol', "vstrategy_id", "long_short", "account", "trading_date", "daynight"], as_index=False)
    check_obos(gp, callback)
    check_order(gp, callback)


def check_obos(df, callback):
    """
    check over buy and over sell
    """
    position = df[["vol"]].sum()
    obos = ((position["vol"] < 0) & (position["long_short"] == 1)) | (position["vol"] > 0) & (
            position["long_short"] == -1)
    if obos.any():
        obos_position = position[obos].copy()
        callback(SettlementNegativePositionError, obos_position)


def check_order(df, callback):
    """
    check trade log order
    """
    for symbol, trade_log in df:
        if len(trade_log.index) <= 1:
            continue
        cum_vol = trade_log["vol"].cumsum()
        idx = (cum_vol[1:] == 0) & (trade_log["open_close"] == 0)
        if idx.any():
            callback(SettlementPositionZeroError, trade_log[idx])


class SettlementCallback:
    def finish(self):
        print("finish")

    def __call__(self, error_type, data):
        print(error_type)
        print(data)


class IPythonSettlementCallback(SettlementCallback):
    def __call__(self, error_type, data):
        from IPython.display import display
        display(error_type)
        display(data)


class SettlementCallbackResult(dict):
    def __missing__(self, key):
        buf = StringIO()
        self[key] = buf
        # write header for specific error
        if key is SettlementNegativePositionError:
            buf.write(
                "account|serial_no|vstrategy_id|trading_date|daynight|symbol|direction|open_close|trade_price|trade_vol|trade_time|entrust_no\n")
        elif key is SettlementPositionZeroError:
            buf.write("vstrategy_id|symbol|trade_time\n")
        return buf


class WeiXinSettlementCallback(SettlementCallback):
    def __init__(self, trading_date, day_night):
        self.trading_date = trading_date
        self.day_night = day_night
        # get close price or live price
        self.price_df = make_price_df(self.trading_date, self.day_night)
        self.result = SettlementCallbackResult()

    def finish(self):
        from cron.strategy_upload_task import quant_ops_wechat_app_send_text_task, rss_mail_task, \
            quant_dev_wechat_app_send_text_task
        # not find settlement error,only send successful msg to quant_dev
        if len(self.result) == 0:
            body = "模拟结算未发现错误"
            quant_dev_wechat_app_send_text_task.delay(body)
            rss_mail_task.delay(body, body, [CompanyEmailGroup.quant_dev])
        else:
            for error_type, buf in self.result.items():
                msg = buf.getvalue()
                # simple way to format datetime to required csv
                # trim trading_date format %Y-%m-%d,%H:%M:%S to %Y-%m-%d
                msg = msg.replace(",00:00:00", "")
                body = error_type.render(msg)
                quant_ops_wechat_app_send_text_task.delay(body)
                quant_dev_wechat_app_send_text_task.delay(body)
                rss_mail_task.delay(error_type.error_type, body,
                                    [CompanyEmailGroup.quant_dev, CompanyEmailGroup.quant_ops])

    def __call__(self, error_type, data):
        if error_type is SettlementNegativePositionError:
            # format DataFrame to required csv
            key_order = ["account", "serial_no", "vstrategy_id", "trading_date", "daynight", "symbol", "direction",
                         "open_close", "trade_price", "trade_vol", "trade_time", "entrust_no"]
            short = data["long_short"] == -1
            data.loc[:, "direction"] = "BUY"
            data.loc[:, "trade_vol"] = abs(data["vol"])
            data.loc[short, "direction"] = "SELL"
            data.loc[:, "open_close"] = "OPEN"
            ts = int(time.time() * 10000)
            data.loc[:, "serial_no"] = [ts + i for i in range(len(data.index))]
            data = data.merge(self.price_df, how='left', left_on="symbol", right_on="symbol", left_index=True)
            delta = timedelta(hours=9) if self.day_night == 0 else timedelta(hours=21)
            data.loc[:, "trade_time"] = data["trading_date"] + delta
            data.loc[:, "entrust_no"] = 0
            data[key_order].to_csv(self.result[error_type], sep="|", index=False, header=False,
                                   date_format='%Y-%m-%d,%H:%M:%S')
        elif error_type is SettlementPositionZeroError:
            data[["vstrategy_id", "symbol", "trade_time"]].to_csv(self.result[error_type], sep="|", index=False,
                                                                  header=False, date_format='%Y-%m-%d,%H:%M:%S')


class MysqlSettlementCallback(WeiXinSettlementCallback):
    def finish(self):
        from cron.strategy_upload_task import quant_ops_wechat_app_send_text_task, rss_mail_task, \
            quant_dev_wechat_app_send_text_task
        # not find settlement error,only send successful msg to quant_dev
        if len(self.result) == 0:
            body = "模拟结算未发现错误"
            quant_dev_wechat_app_send_text_task.delay(body)
            rss_mail_task.delay(body, body, [CompanyEmailGroup.quant_dev])
        else:
            for error_type, buf in self.result.items():
                msg = buf.getvalue()
                # simple way to format datetime to required csv
                # trim trading_date format %Y-%m-%d,%H:%M:%S to %Y-%m-%d
                msg = msg.replace(",00:00:00", "")
                # write to mysql
                status = "[未解决]"
                if SettlementNegativePositionError is error_type:
                    try:
                        df = pd.read_csv(StringIO(msg), sep="|", index_col=None)
                        df.to_sql(name=SettlementManualTradelog.__tablename__, con=engine, if_exists="append",
                                  index=None)
                        status = "[已解决]"
                    except:
                        status = "[自动插入错误]"
                        sentry.captureException()
                body = error_type.render(msg)
                quant_ops_wechat_app_send_text_task.delay(body)
                quant_dev_wechat_app_send_text_task.delay(body)
                rss_mail_task.delay(error_type.error_type + status, body,
                                    [CompanyEmailGroup.quant_dev, CompanyEmailGroup.quant_ops])


def settlement_position_simulator(vs_id, trading_date, day_night, callback=None):
    if callback is None:
        callback = SettlementCallback()
    vs_ids = get_live_vstrategies(vs_id, trading_date)
    position = VsIdDBPosition(trading_date, day_night)
    for vs_id in vs_ids:
        df = position[vs_id]
        check_df(df, callback)
    callback.finish()

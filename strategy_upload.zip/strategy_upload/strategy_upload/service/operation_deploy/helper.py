from db import session_context
from utils import set_cache
from constant import StrategyConstant, StrategyPortfolioConstant, VStrategiesConstant, RedisKeyConstant
from service.back_test.models import Strategy, StrategyPortfolio, VStrategies
from service.statistic.track import StrategyTrackService
from config import config
from utility.db_util.kdb_helper import TradeCalendar
from datetime import datetime


def update_live_stock_vs_position_abstract_info():
    with session_context() as sc:
        records = sc.query(
            Strategy.id_no.label('id_no'), StrategyPortfolio.name.label('portfolio_name')
        ).join(
            VStrategies, VStrategies.strategy_id == Strategy.id
        ).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id
        ).filter(
            Strategy.strategy_type.in_([StrategyConstant.StrategyType.StockAlpha.value,
                                        StrategyConstant.StrategyType.StockT0.value]),
            StrategyPortfolio.business == StrategyPortfolioConstant.Business.Stock.value,
            VStrategies.status == VStrategiesConstant.Status.Live.value
        ).all()
        for r in records:
            st_track = StrategyTrackService(id_no=r.id_no, portfolio_name=r.portfolio_name)
            st_track.get_live_quote()
            position_data = st_track.get_live_position()
            for d in position_data:
                cache_key = RedisKeyConstant.LiveStockVSPositionAbstractInfo.value.format(vs_id=d['vstrategy_id'],
                                                                                          account=d['account'])
                set_cache(cache_key, d['abstract_info'], expire_seconds=60 * 60 * 9)


def generate_redo_settlement(settle_date, effect_date, day_night):
    """
    get dates need to redo settlement

    :param settle_date: datetime.date settlement_date
    :param effect_date: datetime.date the cash change effect
    :param day_night: str "DAY" or "NIGHT"
    :return:
    """
    calendar = TradeCalendar.init_from_kdb(host=config.KDB_HOST, port=config.KDB_PORT, username=config.KDB_USER,
                                           password=config.KDB_PASSWD)
    settle_date = calendar[settle_date]
    effect_date_yesterday = calendar[effect_date, -1]
    date_range = calendar[effect_date_yesterday:settle_date]

    redo = [(d.astype(datetime), t) for d in date_range for t in ["NIGHT", "DAY"]]
    redo = redo[1:]

    if settle_date >= effect_date_yesterday:
        if settle_date != effect_date_yesterday:
            redo.append((settle_date.astype(datetime), "NIGHT"))
        if day_night == "DAY":
            redo.append((settle_date.astype(datetime), "DAY"))
    # do not need first night settlement
    return redo


if __name__ == '__main__':
    # update_live_stock_vs_position_abstract_info()
    pass

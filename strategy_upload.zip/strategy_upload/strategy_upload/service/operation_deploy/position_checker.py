import os
import sys

root_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
if root_path not in sys.path:
    sys.path.append(root_path)

from io import StringIO
import time
from constant import CompanyEmailGroup
from datetime import datetime, timedelta
from .position import TunnelPosition, AccountTradeLog
from .price import make_price_df


class PositionCheckerPrintCallback:
    def __init__(self):
        self.output = print

    def finish(self):
        self.output("finish")

    def __call__(self, account, trade_log, gap):
        self.output("\n账户错误[%s]\n" % account)
        # 根据交易记录的symbol,vs_id,long_short分组的vol的总和，生成数据库vs_id的symbol持仓量
        position = trade_log.groupby(["symbol", "vstrategy_id", "long_short"], as_index=False)[["vol"]].sum()
        # 历遍所有不同
        for index, value in gap.items():
            # index 由symbol 和 long_short组成
            symbol, long_short = index
            self.output(
                "\nsymbol:{symbol} 多空:{long_short} 差值:{gap}:\n".format(symbol=symbol, long_short=long_short, gap=value))
            # 转换long_short,由于上面的position的DataFrame为了可读性使用 `long`或者 `short`表示空多方向
            # 而交易记录的DataFrame是用 1=多 -1=空
            long_short = 1 if long_short == "long" else -1
            idx = (position["symbol"] == symbol) & (position["long_short"] == long_short)
            # 交易记录没有合成该symbol的可用vs_id
            if not idx.any():
                self.output("未找到可用仓位，请运营手动检查\n")
                continue
            symbol_position = position.loc[idx, :]
            symbol_position = symbol_position.copy()
            # vol是净仓位空仓是负的，多仓是正的,但是差值value是由两个正值相减，所以需要把vol转换成绝对值
            symbol_position_vol = abs(symbol_position["vol"])
            symbol_cum_position_vol = symbol_position_vol.cumsum() + value
            # 通道多仓-数据库多仓 < 0 或者 通道空仓-数据库空仓 < 0, 数据库多开了 需要找到可供抵消的vs_id平仓
            # 会出现一个不够，要多个才能完全抵消的情况
            condition = symbol_position_vol > 0
            if value < 0:
                symbol_cum_position_vol = symbol_cum_position_vol[condition]
                symbol_cum_position_vol[symbol_cum_position_vol < 0] = 0
                result = symbol_position_vol[condition] - symbol_cum_position_vol[condition]
                symbol_position["trade_vol"] = result
                symbol_position["open_close"] = "CLOSE"
                symbol_position["direction"] = "SELL" if long_short == 1 else "BUY"
            # 通道空仓-数据库空仓 < 0 或者 通道多仓-数据库多仓 < 0, 数据库少开了，这种情况很简单，去第一个补齐
            else:
                symbol_position["trade_vol"] = 0
                symbol_position.iloc[0]["trade_vol"] = value
                symbol_position["open_close"] = "OPEN"
                symbol_position["direction"] = "SELL" if long_short == -1 else "BUY"

            self.suggestion(account, symbol_position)
            #             self.output("全部可用vstrategy:\n" + symbol_position.to_string())
            self.output("\n")

    def suggestion(self, account, symbol_position):
        symbol_position["account"] = account
        suggestion_idx = symbol_position["trade_vol"] > 0
        if not suggestion_idx.any():
            self.output("未找到可用仓位，请运营手动检查\n")
            return
        self.output("建议:\n" + symbol_position[suggestion_idx].to_string() + "\n")


class PositionCheckerMailCallback(PositionCheckerPrintCallback):

    def __init__(self, trading_date, day_night):
        super().__init__()
        self.trading_date_str = trading_date
        self.trading_date = datetime.strptime(self.trading_date_str, "%Y-%m-%d")
        self.day_night = day_night
        self.price_df = make_price_df(self.trading_date_str, self.day_night)
        self.result = StringIO()
        self.output = self.result.write

    def suggestion(self, account, symbol_position):
        suggestion_idx = symbol_position["trade_vol"] > 0
        self.output("建议:\n")
        if not suggestion_idx.any():
            self.output("未找到可用仓位，请运营手动检查\n")
            return
        ts = int(time.time() * 10000)
        symbol_position["account"] = account
        symbol_position.loc[:, "serial_no"] = [ts + i for i in range(len(symbol_position.index))]
        symbol_position.loc[:, "entrust_no"] = symbol_position["serial_no"]
        symbol_position["daynight"] = "DAY" if self.day_night == 0 else "NIGHT"
        symbol_position["trading_date"] = self.trading_date
        symbol_position["trade_time"] = symbol_position["trading_date"] + timedelta(hours=9)
        symbol_position["trade_time"] = symbol_position["trade_time"][
                                            symbol_position["open_close"] == "CLOSE"] + timedelta(hours=6)
        symbol_position = symbol_position.merge(self.price_df, how='left', left_on="symbol", right_on="symbol",
                                                left_index=True)
        key_order = ["account", "serial_no", "vstrategy_id", "trading_date", "daynight", "symbol", "direction",
                     "open_close", "trade_price", "trade_vol", "trade_time", "entrust_no"]
        result = symbol_position[key_order]
        result[result["trade_vol"] > 0].to_csv(self.result, sep="|", index=False, date_format='%Y-%m-%d,%H:%M:%S')
        self.output("\n")

    def finish(self):
        from cron.strategy_upload_task import rss_mail_task
        msg = self.result.getvalue()
        msg = msg.replace(",00:00:00", "")
        rss_mail_task.delay("仓位比对结果", msg, [CompanyEmailGroup.quant_ops, CompanyEmailGroup.quant_dev])


def check_position_by_account(trading_date, day_night, callback=PositionCheckerPrintCallback()):
    """
    this is a complex function to calc position difference between tunnel and db

    """
    account_trade_log = AccountTradeLog(trading_date, day_night)
    tunnel = TunnelPosition(trading_date, day_night)
    for account_name in tunnel:
        # get tunnel position
        tunnel_position = tunnel[account_name]
        # get db position
        account_position = account_trade_log.calc_position(account_name)
        # get db trade log
        account_trade_log_detail = account_trade_log[account_name]
        if len(tunnel_position.index) == 0 or len(account_position.index) == 0:
            continue
        diff = position_compare(tunnel_position, account_position)
        if len(diff) == 0:
            continue
        callback(account_name, account_trade_log_detail, diff)
    callback.finish()


def position_compare(a, b):
    """
    generate diff between a and b based by symbol


    :param a: BasePosition
    :param b: BasePosition
    :return: pandas.Series
                 vol
        000001    1
        000002   -1
    """
    total_position = a.merge(b, how="outer", left_index=True, right_index=True).fillna(0)
    diff = total_position[total_position.columns[0]] - total_position[total_position.columns[1]]
    diff = diff[diff != 0]
    condition = []
    diff_symbols = diff.index.get_level_values(0)
    # 计算净仓位
    for i in diff_symbols:
        detail = diff.xs((i,)).values
        condition.append(not (len(detail) == 2 and detail[0] == detail[1]))
    return diff[condition]

# -*-coding:utf-8-*-

import csv
import pandas as pd
import datetime

import consts
from config import config
from dateutil.parser import parse
from tornado import gen
from sqlalchemy import tuple_, func
from service.basehandler import BaseHandler, CurrentUserMixin, JsonPayloadMixin
from service.back_test.models import SettlementManualTradelog, Strategy, VStrategies, StrategyPortfolio, \
    ResearchStrategyPortfolio, ResearchStrategyPortfolioDetail, VStrategyAccountDetail, \
    OnlineRequest, StockHedgeVs, StrategyPerfInput
# from service.stock_factor.models import T0Subscriber, T0SubscriberHistory
from service.back_test.live_position_models import VsBase, VsAccount, VsPosition
from service.operation_deploy.models import TradeListAuditStrategy, TradeListAuditLog, AccountBlackList, \
    PreStrategyConfs, VstrategyUpgrade
from service.statistic.track import StrategyTrackService
from db import session, engine, session_context
from utils import send_email, get_cache
from extensions import sentry
from constant import RedisKeyConstant, CompanyEmailGroup
from utility.db_util import TradeCalendar
from models.strategy import VsT0Relation

operation_user = {
    'id': 16,
    'name': 'sandy'
}


class VstrategyPositionHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        ids = self.get_argument('ids')

        ids = [int(v_id) for v_id in ids.split(',')]
        data = {}
        if ids:
            sc = session()
            vs_bases_filter1 = sc.query(
                VsBase.vstrategy_id, func.max(VsBase.settle_date)
            ).filter(
                VsBase.vstrategy_id.in_(ids)
            ).group_by(
                VsBase.vstrategy_id
            )

            vs_bases_filter2 = sc.query(
                VsBase.vstrategy_id, VsBase.settle_date, func.min(VsBase.daynight)
            ).filter(
                tuple_(
                    VsBase.vstrategy_id, VsBase.settle_date
                ).in_(
                    vs_bases_filter1
                )
            ).group_by(
                VsBase.vstrategy_id, VsBase.settle_date
            )

            vs_bases = sc.query(
                VsBase
            ).filter(
                tuple_(VsBase.vstrategy_id, VsBase.settle_date, VsBase.daynight).in_(
                    vs_bases_filter2
                )
            )

            vs_positions = sc.query(
                VsPosition
            ).filter(
                tuple_(
                    VsPosition.vstrategy_id, VsPosition.settle_date, VsPosition.daynight
                ).in_(
                    vs_bases_filter2
                )
            )

            vs_accounts = sc.query(
                VsAccount
            ).filter(
                tuple_(
                    VsAccount.vstrategy_id, VsAccount.settle_date, VsAccount.daynight
                ).in_(
                    vs_bases_filter2
                )
            )

            for row in vs_bases:
                data[row.vstrategy_id] = {
                    'settle_date': row.settle_date.strftime('%Y-%m-%d'),
                    'daynight': row.daynight,
                    'cash': float(row.cash),
                    'cumulative_pnl': float(row.accumulated_pnl),
                    'available_cash': float(row.available_cash),
                    'data': {},
                    'accounts': {},
                }

            for row in vs_positions:
                data[row.vstrategy_id]['data'][row.symbol] = {
                    'yest_long_pos': int(row.yest_long_pos),
                    'yest_long_avg_price': float(row.yest_long_avg_price),
                    'yest_short_pos': int(row.yest_short_pos),
                    'yest_short_avg_price': float(row.yest_short_avg_price),
                    'today_long_pos': int(row.today_long_pos),
                    'today_long_avg_price': float(row.today_long_avg_price),
                    'today_short_pos': int(row.today_short_pos),
                    'today_short_avg_price': float(row.today_short_avg_price),
                    'account': row.account,
                }
            for row in vs_accounts:
                data[row.vstrategy_id]['accounts'][row.vstrategy_id] = {
                    'cash': float(row.cash),
                    'cumulative_pnl': float(row.accumulated_pnl),
                    'available_cash': float(row.available_cash),
                }

            sc.close()

        self.json_response({
            'code': 0,
            'error': '',
            'data': data,
        })
        return True


class VstrategySessionPositionHandler(BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        vs_id = int(self.get_argument('id'))
        settle_date = parse(self.get_argument('settle_date')).strftime('%Y-%m-%d')
        daynight = self.get_argument('daynight').upper()
        data = {}
        sc = session()
        vs_bases = sc.query(
            VsBase
        ).filter(
            VsBase.vstrategy_id == vs_id,
            VsBase.settle_date == settle_date,
            VsBase.daynight == daynight
        )

        vs_positions = sc.query(
            VsPosition
        ).filter(
            VsPosition.vstrategy_id == vs_id,
            VsPosition.settle_date == settle_date,
            VsPosition.daynight == daynight
        )

        vs_accounts = sc.query(
            VsAccount
        ).filter(
            VsAccount.vstrategy_id == vs_id,
            VsAccount.settle_date == settle_date,
            VsAccount.daynight == daynight
        )

        for row in vs_bases:
            data[row.vstrategy_id] = {
                'settle_date': row.settle_date.strftime('%Y-%m-%d'),
                'daynight': row.daynight,
                'cash': float(row.cash),
                'cumulative_pnl': float(row.accumulated_pnl),
                'available_cash': float(row.available_cash),
                'data': {},
                'accounts': {},
            }

        for row in vs_positions:
            data[row.vstrategy_id]['data'][row.symbol] = {
                'yest_long_pos': int(row.yest_long_pos),
                'yest_long_avg_price': float(row.yest_long_avg_price),
                'yest_short_pos': int(row.yest_short_pos),
                'yest_short_avg_price': float(row.yest_short_avg_price),
                'today_long_pos': int(row.today_long_pos),
                'today_long_avg_price': float(row.today_long_avg_price),
                'today_short_pos': int(row.today_short_pos),
                'today_short_avg_price': float(row.today_short_avg_price),
                'account': row.account,
                'symbol_pnl': float(row.symbol_pnl),
                'symbol_fee': float(row.symbol_fee),
            }
        for row in vs_accounts:
            data[row.vstrategy_id]['accounts'][row.vstrategy_id] = {
                'cash': float(row.cash),
                'cumulative_pnl': float(row.accumulated_pnl),
                'available_cash': float(row.available_cash),
            }

        self.json_response({
            'code': 0,
            'error': '',
            'data': data,
        })
        return True


class ManualTradelogsHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):

        self.get_current_user()
        if not self.current_user:
            return False

        group_ids = self.get_user_group()
        if not (consts.OPERATION_GROUP in group_ids):
            self.json_response({
                'code': 401,
                'error': 'user not login or do not have privileges',
            })
            return False
        f_content = self.request.files['manual_tradelogs_file'][0]['body'].decode('utf-8')
        self.application.logger.info(f_content)
        content = f_content.split('\n')

        reader = csv.DictReader(content, delimiter='|')
        sc = session()
        data = []
        for row in reader:
            obj = SettlementManualTradelog()
            obj.account = row['account']
            obj.serial_no = row['serial_no']
            obj.vstrategy_id = row['vstrategy_id']
            obj.trading_date = row['trading_date']
            obj.daynight = row['daynight']
            obj.symbol = row['symbol']
            obj.direction = row['direction']
            obj.open_close = row['open_close']
            obj.trade_price = row['trade_price']
            obj.trade_vol = row['trade_vol']
            obj.trade_time = row['trade_time']
            if row['symbol'] in ('204001', b'204001') and int(row['trade_vol']) >= 1000:
                obj.trade_vol = str((int(row['trade_vol']) / 1000))
            sc.add(obj)
            data.append(row)
        sc.commit()

        title = 'UploadManualTradeLog'
        df = pd.DataFrame(data)
        to_addrs = [
            CompanyEmailGroup.quant_dev,
            CompanyEmailGroup.quant_ops
        ]
        send_email(title, df.to_html(), to_addrs, content_type='html')
        sc.close()
        self.json_response({
            'code': 0,
            'data': '',
            'error': '',
        })
        return True


class PenghuaAuditTradeList(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        trading_date = parse(self.get_argument('trading_date')).strftime('%Y%m%d')
        data = TradeListAuditStrategy.get_trade_list(trading_date)
        self.json_response({
            'code': 0,
            'data': data
        })
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):
        self.get_current_user()
        if not self.current_user:
            return False
        pay_load = self.get_payload()

        trading_date = parse(pay_load['trading_date']).strftime('%Y%m%d')

        sc = session()
        sc.query(TradeListAuditLog).filter(TradeListAuditLog.trading_date == trading_date).delete()
        l = TradeListAuditLog(
            status=pay_load['status'],
            audit_msg=pay_load.get('msg', ''),
            audit_user_id=self.current_user['id'],
            trading_date=trading_date
        )
        sc.add(l)
        sc.commit()
        sc.close()

        self.json_response({
            'code': 0,
            'data': {}
        })
        return True


class AccountBlackListHandler(CurrentUserMixin, JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        data = AccountBlackList.get_blacklist()
        self.json_response({
            'code': 0,
            'data': data
        })
        return True

    @gen.coroutine
    def post(self, *args, **kwargs):

        self.get_current_user()
        if not self.current_user:
            return False
        pay_load = self.get_payload()

        action = pay_load['action']
        if action == 'add':
            AccountBlackList.add_blacklist(pay_load)
        elif action == 'remove':
            AccountBlackList.remove_blacklist(pay_load)
        self.json_response({
            'code': 0,
            'data': {}
        })
        return True


class StockStrategyListHandler(JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        data = []
        sc = session()
        strategies = sc.query(
            Strategy.id.label('id'),
            Strategy.id_no.label('id_no'),
            Strategy.username.label('username'),
            Strategy.name.label('name'),
        ).filter(
            Strategy.node.in_(['back_test', 'union_simu']),
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.strategy_type.in_(consts.stock_strategy_type + consts.hedge_stock_strategy_type)
        ).order_by(
            Strategy.id.desc()
        )
        for s in strategies:
            data.append({
                'id': s.id,
                'strategy_id': s.id_no,
                'name': s.name,
                'username': s.username,
            })
        sc.close()
        self.json_response({
            'code': 0,
            'data': data
        })
        return True


class StockUpgradeVstrategyHandler(JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        try:
            pay_load = self.get_payload()
            account = pay_load['account']
            old_vs_id = pay_load['old_vs_id']
            new_strategy_id = int(pay_load['new_strategy_id'])
            portfolio_name = pay_load['portfolio_name']
            cash = float(pay_load['cash'])
            add_cash = float(pay_load.get('add_cash', 0))  # add cash, optional
        except Exception as e:
            sentry.captureException()
            self.json_response({
                'code': 400,
                'error': 'payload error'
            })
            return

        sc = session()
        try:
            old_vs = sc.query(VStrategies).filter(
                VStrategies.id == old_vs_id
            ).first()

            old_strategy_id = old_vs.strategy_id
            old_strategy = sc.query(Strategy).filter(Strategy.id == old_strategy_id).first()

            r_portfolio = ResearchStrategyPortfolio(
                r_create_user_id=operation_user['id'],
                r_update_user_id=operation_user['id'],
                username=operation_user['name'],
                name=portfolio_name,
                fund=cash,
                description=pay_load.get('desc', ''),
                status='LT',
                weight_type=1,
                is_public=True,
                create_type=2,
            )
            sc.add(r_portfolio)

            sc.flush()

            sd = ResearchStrategyPortfolioDetail(
                portfolio_id=r_portfolio.id,
                strategy_id=new_strategy_id,
                strategy_weight=1,
                group_id=0,
            )
            sc.add(sd)
            sc.commit()

            trading_calendar = TradeCalendar.init_from_kdb(**config.kdb_config)
            today = datetime.datetime.today()
            if trading_calendar.is_trading_date() and today.strftime('%H%M') <= '0930':
                live_time = today.date()
            else:
                live_time = trading_calendar.get_next_trading_date().astype(datetime.date)

            portfolio = StrategyPortfolio(
                name=portfolio_name,
                fund=cash,
                description=pay_load.get('desc', '') or '',
                r_create_user_id=operation_user['id'],
                username=operation_user['name'],
                live_time=live_time,
                status=consts.STRATEGY_TOBE_DEPLOY,
                source='platform',
                research_portfolio_id=r_portfolio.id,
                business='stock',
            )
            sc.add(portfolio)
            sc.commit()

            s = sc.query(Strategy).filter(Strategy.id == new_strategy_id).first()
            s.strategy_status = 'LT'
            # update live_time if first live
            if not s.live_time:
                s.live_time = live_time

            products = s.products[0]

            if products:
                avg_cash = cash / len(products)
            else:
                avg_cash = cash

            symbols_accounts = []
            exchange2products = {}
            for p in s.products[0]:
                exchange2products[p['exch']] = exchange2products.get(p['exch'], []) + [p['symbol']]
            for p in s.products[0]:
                if p['exch'] in (consts.FUTURE_EXCHANGE + consts.FOREIGN_EXCHANGE):
                    if p['exch'] == 'LME':
                        rank = ''
                    else:
                        rank = '|'.join(sorted(map(str, p['rank'])))
                elif p['type'] == 'index':
                    rank = 'index'
                elif p['exch'] in ('SSE', 'SZSE'):
                    if p['type'] == 'stock_factor_FACTOR':
                        rank = 'stock_factor'
                    else:
                        rank = 'stock'
                else:
                    rank = ''

                _symbol_account = {
                    'product': p['symbol'],
                    'account': account,
                    'exchange': p['exch'],
                    'amount': avg_cash,
                    'rank': rank,
                    'max_vol': '',
                    'currency': 'USD' if p['exch'].upper() in consts.FOREIGN_EXCHANGE else 'CNY',
                    'actual_amount': avg_cash,
                    'amount_rmb': avg_cash,
                    'actual_amount_rmb': avg_cash,
                    'rate': 1,
                }
                symbols_accounts.append(_symbol_account)

            symbols_accounts_detail = {
                'day': symbols_accounts,
                'night': []
            }

            vs_paras = {
                'portfolio_id': portfolio.id,
                'strategy_id': new_strategy_id,
                'strategy_weight': 1,
                'symbols_accounts_detail': symbols_accounts_detail,
                'status': consts.STRATEGY_TOBE_DEPLOY,
                'source': 'platform',
                'group_id': 0,
            }
            vs = VStrategies(**vs_paras)
            sc.add(vs)
            sc.commit()

            vs_account_detail = VStrategyAccountDetail(
                vstrategy_id=vs.id,
                portfolio_id=portfolio.id,
                account=account,
                amount=cash,
                actual_amount=cash,
                exchange='SSE',
                start_time=93000,
                end_time=93000,
            )

            vs_account_detail2 = VStrategyAccountDetail(
                vstrategy_id=old_vs_id,
                portfolio_id=old_vs.portfolio_id,
                trading_date=live_time,
                account=account,
                amount=-cash,
                actual_amount=-cash,
                exchange='SSE',
                start_time=93000,
                end_time=93000,
            )
            sc.add(vs_account_detail)
            sc.add(vs_account_detail2)

            # handle add cash case
            if add_cash != 0:
                add_cash_vs_account_detail = VStrategyAccountDetail(
                    vstrategy_id=vs.id,
                    portfolio_id=portfolio.id,
                    account=account,
                    amount=add_cash,
                    actual_amount=add_cash,
                    exchange='SSE',
                    start_time=0,
                    end_time=0,
                    trading_date=live_time
                )
                sc.add(add_cash_vs_account_detail)

            sc.commit()

            on_line_request = OnlineRequest(
                portfolio_id=portfolio.id,
                status=1,
                action=0,
                r_create_user=operation_user['name']
            )
            sc.add(on_line_request)
            sc.commit()

            # hedge_vs = sc.query(StockHedgeVs).filter(
            #     StockHedgeVs.stock_vs_id == old_vs_id,
            #     StockHedgeVs.valid == True
            # ).order_by(StockHedgeVs.id.desc()).first()
            # if hedge_vs:
            #     hedge_vs.valid = False
            #     new_hedge_vs = StockHedgeVs(
            #         stock_vs_id=vs.id,
            #         future_vs_id=hedge_vs.future_vs_id
            #     )
            #     sc.add(new_hedge_vs)
            #     sc.commit()

            new_vs_id = vs.id
            u = VstrategyUpgrade(
                new_vs_id=new_vs_id,
                old_vs_id=old_vs_id,
                new_strategy_id=new_strategy_id,
                old_strategy_id=old_strategy_id,
                switch_date=live_time,
                old_strategy_id_no=old_strategy.id_no,
                new_strategy_id_no=s.id_no
            )
            sc.add(u)
            sc.commit()

            # t0_subscriber = sc.query(T0Subscriber).filter(
            #     T0Subscriber.alpha_vs_id == old_vs_id
            # ).first()
            # if t0_subscriber:
            #     t0_subscriber.alpha_vs_id = new_vs_id
            #     t0_subscriber_his = T0SubscriberHistory(
            #         t0_vs_id=t0_subscriber.t0_vs_id,
            #         alpha_vs_id=new_vs_id,
            #         r_create_user_id=operation_user['id'],
            #         trading_date=live_time
            #     )
            #     sc.add(t0_subscriber_his)
            #     sc.commit()

            # t0_record = sc.query(VsT0Relation).filter(
            #     VsT0Relation.link_vs_id == old_vs_id,
            #     VsT0Relation.deleted == False
            # ).first()
            # if t0_record:
            #     t0_record.deleted = True
            #     t0_record.r_update_user_id = operation_user['id']
            #     t0_record.unlink_date = live_time
            #     new_t0_record = VsT0Relation(
            #         vs_id=t0_record.vs_id,
            #         link_vs_id=new_vs_id,
            #         link_date=live_time,
            #         share_resp=t0_record.share_resp,
            #         r_create_user_id=operation_user['id'],
            #         r_update_user_id=operation_user['id']
            #     )
            #     sc.add(new_t0_record)
            #     sc.commit()

            sc.close()
            VstrategyUpgrade.get_vs_upgrades(cache=False)
            self.json_response({
                'code': 0,
                'data': {
                    'new_vs_id': new_vs_id
                }
            })
        except Exception as e:
            sentry.captureException()
            sc.close()
            self.json_response({
                'code': 1126,
                'error': 'fail'
            })

    @gen.coroutine
    def delete(self, *args, **kwargs):
        vs_id = int(kwargs["vs_id"])

        with session_context() as sc:
            vs = sc.query(VStrategies).filter(VStrategies.id == vs_id).first()
            if vs:
                vs.closing_out = consts.STRATEGY_CLOSING_OUT
                vs.set_close_time = datetime.datetime.now()

        self.json_response({
            'code': 0,
            'data': {
                "success": True
            }
        })
        return True


class StockUpgradeConfHandler(JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        pay_load = self.get_payload()
        old_vs_id = pay_load['old_vs_id']
        new_vs_id = pay_load['new_vs_id']
        process_num = pay_load['process_num']
        sc = session()
        old_conf = sc.query(PreStrategyConfs).filter(
            PreStrategyConfs.vstrategy_id == old_vs_id
        ).first()

        if not old_conf:
            sc.close()
            msg = 'can not find old conf(vs_id=%s)' % old_vs_id
            self.json_response({
                'code': 4001,
                'data': msg,
                'error': msg,
            })
            return True

        new_conf = sc.query(PreStrategyConfs).filter(
            PreStrategyConfs.vstrategy_id == new_vs_id
        ).first()
        if not new_conf:
            new_conf = PreStrategyConfs(
                server_id=old_conf.server_id,
                day_quote_conf=old_conf.day_quote_conf,
                day_tunnel_conf=old_conf.day_tunnel_conf,
                day_trader_conf=old_conf.day_trader_conf,
                night_quote_conf=old_conf.night_quote_conf,
                night_tunnel_conf=old_conf.night_tunnel_conf,
                night_trader_conf=old_conf.night_trader_conf,
                merge_vstrategy_id=old_conf.merge_vstrategy_id,
                vstrategy_id=new_vs_id,
                process_num=process_num
            )
            sc.add(new_conf)
        else:
            new_conf.server_id = old_conf.server_id
            new_conf.day_quote_conf = old_conf.day_quote_conf
            new_conf.day_tunnel_conf = old_conf.day_tunnel_conf
            new_conf.day_trader_conf = old_conf.day_trader_conf
            new_conf.night_quote_conf = old_conf.night_quote_conf
            new_conf.night_tunnel_conf = old_conf.night_tunnel_conf
            new_conf.night_trader_conf = old_conf.night_trader_conf
            new_conf.merge_vstrategy_id = old_conf.merge_vstrategy_id
            new_conf.process_num = process_num
        sc.commit()
        sc.close()
        self.json_response({
            'code': 0,
            'data': {}
        })
        return True


class StockUpgradePositionHandler(JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def post(self, *args, **kwargs):
        pay_load = self.get_payload()
        from_vs_id = pay_load['old_vs_id']
        to_vs_id = pay_load['new_vs_id']

        sc = session()

        vs_detail = sc.query(
            Strategy.id_no.label('id_no'),
            StrategyPortfolio.name.label('sp_name'),
        ).join(
            VStrategies, VStrategies.strategy_id == Strategy.id
        ).join(
            StrategyPortfolio, VStrategies.portfolio_id == StrategyPortfolio.id
        ).filter(
            VStrategies.id == from_vs_id
        ).first()
        if not vs_detail:
            sc.close()
            self.json_response({
                'code': 4002,
                'data': 'can not find vs',
                'error': 'can not find vs'
            })
            return
        s_id_no = vs_detail.id_no
        portfolio_name = vs_detail.sp_name

        try:
            ss = StrategyTrackService(id_no=s_id_no, portfolio_name=portfolio_name)
            yield ss.async_get_live_quote()
            detail = ss.strategy_track()
            detail['position_data'] = ss.get_live_position()

            trading_date, _ = StrategyPerfInput.get_trading_date_day_night()
            trading_date = parse(trading_date)
            open_trade_time = trading_date.strftime('%Y-%m-%d 14:28:00')
            close_trade_time = trading_date.strftime('%Y-%m-%d 15:02:00')

            from_vs_id_str = str(from_vs_id)
            to_vs_id_str = str(to_vs_id)

            columns = [
                'account', 'daynight', 'direction', 'entrust_no', 'open_close', 'serial_no',
                'symbol', 'trade_price', 'trade_time', 'trade_vol', 'trading_date', 'vstrategy_id'
            ]
            column_index = {c: i for i, c in enumerate(columns)}

            close_data = []
            buy_data = []
            for l in detail['position_data']:
                for s in l['detail_info']:
                    if int(s['vstrategy_id']) != from_vs_id:
                        continue

                    if s['symbol'] in ('204001', '131810'):
                        continue

                    if s['direction'] == 0:
                        d1, o1 = 'SELL', 'CLOSE'
                        d2, o2 = 'BUY', 'OPEN'
                    elif s['direction'] == 1:
                        d1, o1 = 'BUY', 'CLOSE'
                        d2, o2 = 'SELL', 'OPEN'
                    else:
                        continue

                    trade_vol = s['total_position']
                    trade_price = s['last_price']
                    serial_no = ''.join([from_vs_id_str, s['symbol']])

                    close_data.append([
                        s['account'], 'DAY', d1, 111111111, o1, serial_no,
                        s['symbol'], trade_price, close_trade_time, trade_vol, trading_date, from_vs_id
                    ])

                    if to_vs_id:
                        serial_no = ''.join([to_vs_id_str, s['symbol']])
                        buy_data.append([
                            s['account'], 'DAY', d2, 111111111, o2, serial_no,
                            s['symbol'], trade_price, open_trade_time, trade_vol, trading_date, to_vs_id
                        ])

            for l in close_data:
                if l[column_index['trade_vol']] <= 0:
                    continue
                l = SettlementManualTradelog(
                    account=l[column_index['account']],
                    serial_no='%s%s' % (l[column_index['symbol']], datetime.datetime.now().strftime('%H%M%S%f')),
                    vstrategy_id=l[column_index['vstrategy_id']],
                    trading_date=l[column_index['trading_date']],
                    daynight=l[column_index['daynight']],
                    symbol=l[column_index['symbol']],
                    direction=l[column_index['direction']],
                    open_close=l[column_index['open_close']],
                    trade_price=l[column_index['trade_price']],
                    trade_vol=l[column_index['trade_vol']],
                    trade_time=l[column_index['trade_time']],
                    entrust_no=l[column_index['entrust_no']],
                )
                sc.add(l)

            for l in buy_data:
                if l[column_index['trade_vol']] <= 0:
                    continue
                l = SettlementManualTradelog(
                    account=l[column_index['account']],
                    serial_no='%s%s' % (l[column_index['symbol']], datetime.datetime.now().strftime('%H%M%S%f')),
                    vstrategy_id=l[column_index['vstrategy_id']],
                    trading_date=l[column_index['trading_date']],
                    daynight=l[column_index['daynight']],
                    symbol=l[column_index['symbol']],
                    direction=l[column_index['direction']],
                    open_close=l[column_index['open_close']],
                    trade_price=l[column_index['trade_price']],
                    trade_vol=l[column_index['trade_vol']],
                    trade_time=l[column_index['trade_time']],
                    entrust_no=l[column_index['entrust_no']],
                )
                sc.add(l)

            sc.commit()
        except Exception as e:
            sentry.captureException()
            sc.rollback()

        sc.close()

        df = pd.read_sql_query(
            """select * from settlement_manual_tradelogs
               where vstrategy_id in (%s, %s) and trading_date='%s' and entrust_no=111111111
            """ % (from_vs_id, to_vs_id, trading_date),
            engine
        )

        title = '%s Upgrade Vs tradelogs' % trading_date
        content = '\n\n'.join([df.to_html()])
        to_addr = [
            CompanyEmailGroup.quant_dev
        ]
        send_email(title, content, to_addr, content_type='html')
        self.json_response({
            'code': 0,
            'data': {}
        })
        return True


class StockUpgradePositionDataHandler(JsonPayloadMixin, BaseHandler):

    @gen.coroutine
    def get(self, *args, **kwargs):
        old_vs_id = self.get_argument('old_vs_id', None)
        account = self.get_argument('account', None)
        if not old_vs_id or not account:
            self.json_response({
                'code': 4001,
                'error': "invalid argument"
            })
            return

        cache_abstract_info = get_cache(RedisKeyConstant.LiveStockVSPositionAbstractInfo.value.format(vs_id=old_vs_id,
                                                                                                      account=account))
        if cache_abstract_info:
            self.json_response({
                'code': 0,
                'data': cache_abstract_info
            })
            return

        with session_context() as sc:
            vs_detail = sc.query(
                Strategy.id_no.label('id_no'),
                StrategyPortfolio.name.label('sp_name'),
            ).join(
                VStrategies, VStrategies.strategy_id == Strategy.id
            ).join(
                StrategyPortfolio, VStrategies.portfolio_id == StrategyPortfolio.id
            ).filter(
                VStrategies.id == old_vs_id
            ).first()
            if not vs_detail:
                self.json_response({
                    'code': 4002,
                    'error': 'can not find vs'
                })
                return
            s_id_no = vs_detail.id_no
            portfolio_name = vs_detail.sp_name

        try:
            ss = StrategyTrackService(id_no=s_id_no, portfolio_name=portfolio_name)
            yield ss.async_get_live_quote()
            position_data = ss.get_live_position()
            for d in position_data:
                abstract_info = d['abstract_info']
                if abstract_info['account'] == str(account) and abstract_info['vstrategy_id'] == int(old_vs_id):
                    self.json_response({
                        'code': 0,
                        'data': abstract_info
                    })
                    return
            self.json_response({
                'code': 4002,
                'error': 'total asset not found'
            })
        except Exception as e:
            sentry.captureException()
            self.json_response({
                'code': 1126,
                'error': 'get track data error'
            })

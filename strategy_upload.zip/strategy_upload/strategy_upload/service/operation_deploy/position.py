import os
import sys

root_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
if root_path not in sys.path:
    sys.path.append(root_path)

from db import engine
from datetime import datetime, timedelta
import requests
from config import config
import pandas as pd


class BasePosition(dict):
    def __init__(self, trading_date, day_night):
        self.trading_date = trading_date
        self.day_night = day_night


class BaseTradeLog(dict):
    def __init__(self, trading_date, day_night):
        self.trading_date = trading_date
        self.day_night = day_night


class TunnelPosition(BasePosition):
    """
    default dict for position in tunnel
    """

    def __init__(self, trading_date, day_night):
        super().__init__(trading_date, day_night)
        self.init_position()

    def init_position(self):
        req = requests.get("http://%s/api/v1/speedquote/equitytrader" % config.account_query_host)
        data = req.json()
        data = data["data"]
        for account, value in data.items():
            tmp = {}
            position = value["data"]
            for detail in position:
                for symbol in detail:
                    long = detail[symbol]["long"]
                    short = detail[symbol]["short"]
                    tmp[(symbol, "long")] = {account: long}
                    tmp[(symbol, "short")] = {account: short}
            self[account] = pd.DataFrame.from_dict(tmp, orient="index")


# position group by account
class AccountTradeLog(BaseTradeLog):
    TRADE_LOGS_SQL_BY_ACCOUNT = "SELECT symbol,trade_vol,direction,open_close,TIMESTAMP(trading_date,calendar_time) AS trade_time,vstrategy_id, account FROM trade_logs WHERE trading_date = '{trading_date}' AND log_type = '3' AND account='{account}' AND day_night=%s"
    MANUAL_LOGS_SQL_BY_ACCOUNT = "SELECT symbol,CAST(trade_vol AS SIGNED) AS trade_vol,IF(STRCMP(direction,'BUY'),1,0) AS direction,IF(STRCMP(open_close,'OPEN'),3,0) AS open_close,trade_time ,vstrategy_id,account FROM settlement_manual_tradelogs WHERE trading_date = '{trading_date}' AND account='{account}' AND daynight='%s'"
    VS_POSITION_LONG_SQL_BY_ACCOUNT = "SELECT symbol,today_long_pos AS trade_vol,0 AS direction,0 AS open_close,settle_date AS trade_time,vstrategy_id ,account FROM vs_positions WHERE settle_date = '%s' AND account='{account}' AND daynight = '%s'"
    VS_POSITION_SHORT_SQL_BY_ACCOUNT = "SELECT symbol,today_short_pos AS trade_vol,1 AS direction,0 AS open_close,settle_date AS trade_time,vstrategy_id ,account FROM vs_positions WHERE settle_date = '%s' AND account='{account}' AND daynight = '%s'"

    @classmethod
    def make_tradelog(cls, account, trading_date, day_night):
        """

        :param account: str account name
        :param trading_date: str %Y-%m-%d
        :param day_night: int 0=DAY 1=NIGHT
        :return:
        """
        if day_night == 0:
            prev_settle_daynight = "NIGHT"
            prev_settle_date = trading_date
        else:
            prev_settle_daynight = "DAY"
            prev_settle_date = (datetime.strptime(
                trading_date, "%Y-%m-%d") - timedelta(days=1)).strftime("%Y-%m-%d")
        trade_logs_query = cls.TRADE_LOGS_SQL_BY_ACCOUNT % (str(day_night))
        settlement_manual_tradelogs_query = cls.MANUAL_LOGS_SQL_BY_ACCOUNT % (
            "DAY" if day_night == 0 else "NIGHT")
        vs_positions_long_query = cls.VS_POSITION_LONG_SQL_BY_ACCOUNT % (
            prev_settle_date, prev_settle_daynight)
        vs_positions_short_query = cls.VS_POSITION_SHORT_SQL_BY_ACCOUNT % (
            prev_settle_date, prev_settle_daynight)
        query = " UNION ALL ".join([trade_logs_query, settlement_manual_tradelogs_query,
                                    vs_positions_long_query, vs_positions_short_query])
        query += " ORDER BY trade_time ASC"
        query = query.format(trading_date=trading_date, account=account)
        df = pd.read_sql_query(query, engine)
        buy_open = (df["direction"] == 0) & (df["open_close"] == 0)
        sell_open = (df["direction"] == 1) & (df["open_close"] == 0)
        buy_close = (df["direction"] == 0) & (df["open_close"] != 0)
        sell_close = (df["direction"] == 1) & (df["open_close"] != 0)
        df["side"] = 1
        df["long_short"] = 1
        df.loc[sell_open | sell_close, "side"] = -1
        df.loc[sell_open | buy_close, "long_short"] = -1
        df["vol"] = df["side"] * df["trade_vol"]
        df["daynight"] = "DAY" if day_night == 0 else "NIGHT"
        return df

    def calc_position(self, account):
        """
        generate database based on trade log
        :param account:
        :return:
        """
        tradelog = self[account]
        gp = tradelog.groupby(["symbol"], as_index=False)
        tmp = {}
        for symbol, val in gp:
            long_position = val.loc[val["long_short"]
                                    == 1, "vol"].cumsum().values
            short_position = val.loc[val["long_short"]
                                     == -1, "vol"].cumsum().values
            if len(long_position) > 0:
                tmp[(symbol, "long")] = {account: long_position[-1]}
            else:
                tmp[(symbol, "long")] = {account: 0}
            if len(short_position) > 0:
                # identify stock symbol to avoid stock T0 strategy has short position
                if symbol.isdigit() and len(symbol) == 6:
                    tmp[(symbol, "long")][account] += short_position[-1]
                    tmp[(symbol, "short")] = {account: 0}
                else:
                    tmp[(symbol, "short")] = {account: abs(short_position[-1])}
            else:
                tmp[(symbol, "short")] = {account: 0}
        account_position = pd.DataFrame.from_dict(tmp, orient="index")
        return account_position

    def __missing__(self, account):
        if account in self:
            return account
        p = self.make_tradelog(account, self.trading_date, self.day_night)
        if p is None:
            raise KeyError
        self[account] = p
        return p


# position group by vs_id
class VsIdDBPosition(BaseTradeLog):
    TRADE_LOGS_SQL_BY_VS_ID = "SELECT symbol,trade_vol,direction,open_close,TIMESTAMP(trading_date,calendar_time) AS trade_time,vstrategy_id, account FROM trade_logs WHERE trading_date = '{trading_date}' AND log_type = '3' AND vstrategy_id = {vs_id} AND day_night=%s"
    MANUAL_LOGS_SQL_BY_VS_ID = "SELECT symbol,CAST(trade_vol AS SIGNED) AS trade_vol,IF(STRCMP(direction,'BUY'),1,0) AS direction,IF(STRCMP(open_close,'OPEN'),3,0) AS open_close,trade_time ,vstrategy_id,account FROM settlement_manual_tradelogs WHERE trading_date = '{trading_date}' AND vstrategy_id = {vs_id} AND daynight='%s'"
    VS_POSITION_LONG_SQL_BY_VS_ID = "SELECT symbol,today_long_pos AS trade_vol,0 AS direction,0 AS open_close,settle_date AS trade_time,vstrategy_id ,account FROM vs_positions WHERE settle_date = '%s' AND vstrategy_id = {vs_id} AND daynight = '%s'"
    VS_POSITION_SHORT_SQL_BY_VS_ID = "SELECT symbol,today_short_pos AS trade_vol,1 AS direction,0 AS open_close,settle_date AS trade_time,vstrategy_id ,account FROM vs_positions WHERE settle_date = '%s' AND vstrategy_id = {vs_id} AND daynight = '%s'"

    @classmethod
    def make_tradelog(cls, vs_id, trading_date, day_night):
        """
        aggregate trade_logs，settlement_manual_tradelogs，vs_positions table filter by vs_id into a big trade log DataFrame


        :param vs_id: int
        :param trading_date: str %Y-%m-%d
        :param day_night: int 0=DAY 1=NIGHT
        :return:
        """
        if day_night == 0:
            prev_settle_daynight = "NIGHT"
            prev_settle_date = trading_date
        else:
            prev_settle_daynight = "DAY"
            prev_settle_date = (datetime.strptime(trading_date, "%Y-%m-%d") - timedelta(days=1)).strftime("%Y-%m-%d")
        trade_logs_query = cls.TRADE_LOGS_SQL_BY_VS_ID % (str(day_night))
        settlement_manual_tradelogs_query = cls.MANUAL_LOGS_SQL_BY_VS_ID % ("DAY" if day_night == 0 else "NIGHT")
        vs_positions_long_query = cls.VS_POSITION_LONG_SQL_BY_VS_ID % (prev_settle_date, prev_settle_daynight)
        vs_positions_short_query = cls.VS_POSITION_SHORT_SQL_BY_VS_ID % (prev_settle_date, prev_settle_daynight)
        query = " UNION ALL ".join([trade_logs_query, settlement_manual_tradelogs_query,
                                    vs_positions_long_query, vs_positions_short_query])
        query += " ORDER BY trade_time ASC"
        query = query.format(trading_date=trading_date, vs_id=vs_id)
        df = pd.read_sql_query(query, engine)
        buy_open = (df["direction"] == 0) & (df["open_close"] == 0)
        sell_open = (df["direction"] == 1) & (df["open_close"] == 0)
        buy_close = (df["direction"] == 0) & (df["open_close"] != 0)
        sell_close = (df["direction"] == 1) & (df["open_close"] != 0)
        df["side"] = 1
        df["long_short"] = 1
        df.loc[sell_open | sell_close, "side"] = -1
        df.loc[sell_open | buy_close, "long_short"] = -1
        df["trading_date"] = datetime.strptime(trading_date, "%Y-%m-%d")
        df["vol"] = df["side"] * df["trade_vol"]
        df["daynight"] = "DAY" if day_night == 0 else "NIGHT"
        return df

    def __missing__(self, vs_id):
        if vs_id in self:
            return self[vs_id]
        p = self.make_tradelog(vs_id, self.trading_date, self.day_night)
        self[vs_id] = p
        return p

# -*-coding:utf-8-*-

import datetime
import copy
import pandas as pd
from dateutil.parser import parse
from sqlalchemy.sql import func
from sqlalchemy import BigInteger, Column, Date, DateTime, Enum, Float, Index, Integer, String, Time, text, JSON
from sqlalchemy.dialects.mysql import BIGINT, VARCHAR, FLOAT, BOOLEAN, DATETIME, INTEGER, JSON, DOUBLE, TEXT, DATE, TIME
from db import ModelBase, session, session_context
from utils import get_cache, set_cache

from service.order_list.models import OrderList


class TradeListAuditStrategy(ModelBase):
    __tablename__ = 'tradelist_audit_strategy'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    partner = Column(VARCHAR(32), nullable=False, index=True)
    strategy_id = Column(INTEGER, nullable=False)

    @staticmethod
    def get_trade_list(trading_date, partner='penghua'):
        sc = session()
        data = {
            'columns': ['symbol', 'weight', 'size', 'limit_price', 'algo', 'start', 'end'],
            'values': [],
            'status': 'PENDING',
        }
        s = sc.query(TradeListAuditStrategy).filter(TradeListAuditStrategy.partner == partner).first()
        if s:
            order_list_id = s.strategy_id

            order_list = sc.query(OrderList).filter(
                OrderList.date == trading_date,
                OrderList.strategy_id == order_list_id
            )
            for o in order_list:
                o_d = o.detail()
                data['values'].append([o_d[c] for c in data['columns']])
        l = sc.query(TradeListAuditLog).filter(
            TradeListAuditLog.trading_date == trading_date
        ).first()
        if l:
            data['status'] = l.status
        sc.close()
        return data


class TradeListAuditLog(ModelBase):
    __tablename__ = 'tradelist_audit_log'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    status = Column(Enum('PENDING', 'APPROVED', 'REJECTED'), nullable=False, default='PENDING')
    audit_msg = Column(VARCHAR(512), nullable=True, default="")
    audit_user_id = Column(INTEGER, nullable=True)
    trading_date = Column(DATE, nullable=False)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())


class AccountBlackList(ModelBase):
    __tablename__ = 'account_black_list'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    account = Column(VARCHAR(64), nullable=False)
    symbol = Column(VARCHAR(64), nullable=False)
    begin_trading_date = Column(DATE, nullable=False)
    end_trading_date = Column(DATE, nullable=True)
    r_create_time = Column(DATETIME, nullable=False, server_default=func.now())
    r_update_time = Column(DATETIME, nullable=False, server_default=func.now(), onupdate=func.now())

    @staticmethod
    def add_blacklist(data):
        trading_date = datetime.datetime.now().strftime('%Y%m%d')
        sc = session()
        for s in data['symbol']:
            l = AccountBlackList(
                account=data['account'],
                symbol=s,
                begin_trading_date=trading_date
            )
            sc.add(l)
        sc.commit()
        sc.close()
        return True

    @staticmethod
    def remove_blacklist(data):
        sc = session()
        blacklist = sc.query(AccountBlackList).filter(
            AccountBlackList.account == data['account'],
            AccountBlackList.symbol.in_(data['symbol'])
        )
        trading_date = datetime.datetime.now().strftime('%Y%m%d')
        for l in blacklist:
            l.end_trading_date = trading_date
        sc.commit()
        sc.close()
        return True

    @staticmethod
    def get_blacklist(account='', **kwargs):
        trading_date = datetime.datetime.now().strftime('%Y%m%d')
        sc = session()
        black_list = sc.query(AccountBlackList)
        if account:
            black_list = black_list.filter(
                AccountBlackList.account == account
            )
        data = {}
        for l in black_list:
            acc_black_list = data.setdefault(l.account, [])
            if (not l.end_trading_date) or (trading_date < l.end_trading_date.strftime('%Y%m%d')):
                acc_black_list.append(l.symbol)
        return data


class PreStrategyConfs(ModelBase):
    __tablename__ = 'pre_strategy_confs'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    name = Column(VARCHAR(64), nullable=True)
    server_id = Column(BIGINT(unsigned=True))
    day_quote_conf = Column(VARCHAR(256), nullable=False)
    day_tunnel_conf = Column(VARCHAR(256), nullable=False)
    day_trader_conf = Column(VARCHAR(256), nullable=False)
    night_quote_conf = Column(VARCHAR(256), nullable=False)
    night_tunnel_conf = Column(VARCHAR(256), nullable=False)
    night_trader_conf = Column(VARCHAR(256), nullable=False)
    vstrategy_id = Column(BIGINT(unsigned=True))
    process_num = Column(INTEGER)
    merge_vstrategy_id = Column(BIGINT)


class VstrategyUpgrade(ModelBase):
    __tablename__ = 'vstrategy_upgrade'

    id = Column(BIGINT(unsigned=True), primary_key=True)
    old_vs_id = Column(BIGINT(unsigned=True), index=True)
    new_vs_id = Column(BIGINT(unsigned=True))
    old_strategy_id = Column(BIGINT(unsigned=True))
    new_strategy_id = Column(BIGINT(unsigned=True))
    old_strategy_id_no = Column(VARCHAR(32))
    new_strategy_id_no = Column(VARCHAR(32))
    switch_date = Column(DATE)

    def replacement_ds(self):
        return {
            self.switch_date.strftime("%Y%m%d"): {
                "old_vs_id": self.old_vs_id,
                "new_vs_id": self.new_vs_id,
                "old_strategy_id": self.old_strategy_id_no,
                "new_strategy_id": self.new_strategy_id_no
            }
        }

    @staticmethod
    def get_vs_upgrades(cache=True):
        cache_key = 'vs_upgrade_version'
        if cache:
            data = get_cache(cache_key)
            if data:
                return data
                
        tmp = {}
        sc = session()        
        for r in sc.query(VstrategyUpgrade):
            tmp[r.new_vs_id] = [r.old_vs_id]
        sc.close()

        data = {}
        for n_id, o_ids in sorted(tmp.items(), key=lambda x: x[0]):
            data[n_id] = copy.deepcopy(o_ids)
            for o_id in o_ids:
                if o_id == n_id:
                    continue
                data[n_id].extend(tmp.get(o_id, []))
                data[n_id].extend(data.get(o_id, []))
        data = {str(k): sorted(set(v), reverse=True) for k, v in data.items()}
        if data:
            set_cache(cache_key, data, 86400)
        
        return data

    @staticmethod
    def get_vs_replacement(vs_id, cache=True):
        cache_key = "vs_replacement:{}".format(vs_id)
        if cache:
            data = get_cache(cache_key)
            if data:
                return data
        vs_upgrades = VstrategyUpgrade.get_vs_upgrades()
        old_vs_list = vs_upgrades.get(str(vs_id), [])
        data = {}
        if old_vs_list:
            with session_context() as sc:
                records = sc.query(VstrategyUpgrade).filter(VstrategyUpgrade.old_vs_id.in_(old_vs_list)).order_by(
                    VstrategyUpgrade.old_vs_id.asc()).all()
                for r in records:
                    data.update(r.replacement_ds())
                if data:
                    set_cache(cache_key, data, 12 * 60 * 60)
        return data


if __name__ == '__main__':
    # from service.back_test.models import Strategy
    #
    # with session_context() as sc:
    #     records = sc.query(VstrategyUpgrade).all()
    #     for r in records:
    #         old_s = sc.query(Strategy).filter(Strategy.id == r.old_strategy_id).first()
    #         new_s = sc.query(Strategy).filter(Strategy.id == r.new_strategy_id).first()
    #         r.old_strategy_id_no = old_s.id_no
    #         r.new_strategy_id_no = new_s.id_no

    # data1 = VstrategyUpgrade.get_vs_upgrades()
    # for k, v in data1.items():
    #     for vv in v:
    #         print(type(vv), vv)
    # data2 = VstrategyUpgrade.get_vs_replacement(vs_id=2123)
    # print(data2)
    pass

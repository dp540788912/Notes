# -*-coding:utf-8-*-

from service.back_test.urls import urls as back_test_url
from service.vwap.urls import urls as vwap_urls
from service.order_list.urls import urls as order_list_urls
from service.cash_io.urls import urls as cash_io_list_urls
from service.openapi.urls import urls as openapi_urls
from service.account_funds.urls import urls as account_funds_url
from service.statistic.urls import urls as investment_performance_url
from service.strategymanager.urls import urls as strategymanager_url
from service.operation_deploy.urls import urls as operation_deploy_url
from service._analysis.urls import urls as analysis_url
from service.livetrading.urls import urls as livetrading_url
from service.stock_factor.urls import urls as stock_factor_url
from service.file_upload.urls import urls as file_upload_url
from service.operation.urls import urls as operation_url
from service.dependence.urls import urls as dependence_url
from service.live_control.urls import urls as live_control_url
from service.monitor.urls import urls as monitor_url

urls = back_test_url
urls += vwap_urls
urls += order_list_urls
urls += cash_io_list_urls
urls += openapi_urls
urls += account_funds_url
urls += investment_performance_url
urls += strategymanager_url
urls += operation_deploy_url
urls += analysis_url
urls += livetrading_url
urls += stock_factor_url
urls += file_upload_url
urls += operation_url
urls += dependence_url
urls += live_control_url
urls += monitor_url

# -*-coding:utf-8-*-

import codecs
import json
import simplejson
import requests
from utils import check_session, get_cache, set_cache, MyEncoder
from tornado.web import RequestHandler
from io import StringIO
from db import session
from constant import UserGroupConstant, UserRoleConstant


class BaseHandler(RequestHandler):

    @staticmethod
    def parse_list(list_str):
        """

        :param list_str: string, like "1,2,3"
        :return:
        """
        list_int = list()
        if list_str:
            list_int = [int(ele) for ele in list_str.split(',')]
        return list_int

    def json_response(self, data):
        self.set_header("Content-Type", "application/json; charset=UTF-8")
        self.write(simplejson.dumps(data, cls=MyEncoder, ignore_nan=True))
        return True

    def user_role(self):
        user_group_set = set(self.get_user_group())
        if set(UserGroupConstant.manager_group()) & user_group_set:
            role = UserRoleConstant.Manager.value
        elif set(UserGroupConstant.stock_group()) & user_group_set:
            role = UserRoleConstant.TraderStock.value
        elif set(UserGroupConstant.future_group()) & user_group_set:
            role = UserRoleConstant.TraderFuture.value
        else:
            role = UserRoleConstant.Empty.value
        return role

    def is_stock_group(self):
        if self.current_user and any([i in (39, 41) for i in self.get_user_group()]):
            return True
        return False

    def is_future_group(self):
        if self.current_user and any([i in (39, 42) for i in self.get_user_group()]):
            return True
        return False

    def is_manage_department(self):
        if self.current_user and any([i in (55,) for i in self.get_user_group()]):
            return True
        return False

    def is_stock_page(self):
        if self.get_argument('type', '') == 'stock':
            return True
        if 'type=stock' in self.request.headers.get('referer', ''):
            return True
        if 'type%3Dstock' in self.request.headers.get('referer', ''):
            return True
        return False

    def is_future_page(self):
        if self.get_argument('type', '') == 'future':
            return True
        if 'type=future' in self.request.headers.get('referer', ''):
            return True
        if 'type%3Dfuture' in self.request.headers.get('referer', ''):
            return True
        return False

    def is_hft_group(self):
        if self.current_user and any([i in (7, 39, 42) for i in self.get_user_group()]):
            return True
        return False


class CurrentUserMixin(object):

    def get_current_user(self):
        session_id = self.get_cookie('sessionid')
        if not session_id:
            self.json_response({
                'code': 401,
                'error': 'Session id not found.'
            })
            self.current_user = {}
            self.finish()
            return
        res = check_session(session_id)
        if not res:
            self.json_response({
                'code': 401,
                'error': 'User not login.',
            })
            self.finish()
            self.current_user = {}
            return

        self.current_user = res

    def check_login(self):
        se_id = self.get_cookie('sessionid')
        if se_id:
            res = check_session(se_id)
            if res:
                return res['id']
        return None

    def get_user_detail(self):
        sessionid = self.get_cookie('sessionid')
        # TODO: Replace with tornado's built-in async-httpclient.
        me = requests.get('http://127.0.0.1/api/v1/user', cookies={'sessionid': sessionid}).json()['data']
        return me

    def get_user_id(self):
        info = self.get_user_detail()
        return {'id': info['id'], 'name': info['username']}

    def get_user_group(self):
        if not self.current_user:
            return []

        cache_key = 'platform_user_group_cache_%s' % self.current_user['id']
        data = get_cache(cache_key)
        if data:
            return data

        group_ids = self._get_user_group_ids(self.current_user['id'])
        if group_ids:
            set_cache(cache_key, group_ids, 24 * 3600)

        return group_ids

    @staticmethod
    def _get_user_group_ids(uid):
        res = []
        sc = session()
        for r in sc.execute('select user_group_id from user_group_info where user_id={user_id}'.format(user_id=uid)):
            res.append(r[0])
        sc.close()
        return res


# for citic, on 2018.1.14
class CurrentUserMixin_V2(CurrentUserMixin):

    def get_current_user(self):
        if self.request.headers.get('whitelist'):
            self.current_user = {
                'id': 1,
                'username': 'root',
                'nickname': 'root',
                'is_superuser': True,
            }
        else:
            sessionid = self.get_cookie('sessionid')
            if not sessionid:
                self.write(json.dumps({
                    'code': 401,
                    'error': 'Sessionid not found.'
                }))
                self.current_user = {}
                self.finish()
                return
            res = check_session(sessionid)
            if not res:
                self.write(json.dumps({
                    'code': 401,
                    'error': 'User not login.',
                }))
                self.finish()
                self.current_user = {}
                return
            self.current_user = res

    def check_login(self):
        if self.request.headers.get('whitelist'):
            return 1
        else:
            se_id = self.get_cookie('sessionid')
            if se_id:
                res = check_session(se_id)
                if res:
                    return res['id']
            return None

    def get_user_id(self):
        if self.request.headers.get('whitelist'):
            return {'id': 1, 'name': 'root'}
        else:
            info = self.get_user_detail()
            return {'id': info['id'], 'name': info['username']}

    def get_user_group(self):
        if self.request.headers.get('whitelist'):
            return [9]
        else:
            info = self.get_user_detail()
            group_ids = [int(g['id']) for g in info['groups']]
            return group_ids


class JsonPayloadMixin(object):

    def get_payload(self):
        if self.request.headers['content-type'].lower().startswith("application/json"):
            return json.loads(str(self.request.body, 'utf-8'))
        return {}


class DownloadMixin(object):

    def downfile(self, df, filename):
        strIO = StringIO()
        strIO.write(str(codecs.BOM_UTF8, encoding='utf-8'))
        df.to_csv(strIO, index=False, encoding='utf-8')
        strIO.seek(0)
        self.set_header('Content-Type', 'application/octet-stream')
        self.set_header('Content-Disposition', 'attachment; filename=' + filename)
        self.write(strIO.read())
        self.finish()
        return

    def downfile2(self, df, filename):
        strIO = StringIO()
        df.to_csv(strIO, index=False, encoding='utf-8', sep='|')
        strIO.seek(0)
        self.set_header('Content-Type', 'application/octet-stream')
        self.set_header('Content-Disposition', 'attachment; filename=' + filename)
        self.write(strIO.read())
        self.finish()
        return

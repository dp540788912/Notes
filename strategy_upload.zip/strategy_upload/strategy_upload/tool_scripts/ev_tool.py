import os
from pprint import pprint

from service.back_test.models import Strategy, StrategyResult
from service.back_test.ev_task import get_live_ev_ids_cache
from constant import StrategyConstant, CompanyUser
from db import session_context
from extensions import sentry
from cron.strategy_upload_task import strategy_ev_task, choose_task_queue
import consts
from kdb_query import KdbQuery


def start_strategy_ev_task(user_id, date, day_night, is_live=True):
    with session_context() as sc:
        s_records = sc.query(Strategy).filter(
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.end_date >= date,
            Strategy.status != StrategyConstant.Status.STOPPED.value,
            Strategy.node == StrategyConstant.Node.EV.value,
            Strategy.r_create_user_id == user_id
        )
        if is_live:
            s_records = s_records.filter(Strategy.id.in_(get_live_ev_ids_cache()))

        s_records = s_records.order_by(Strategy.id.asc()).all()

        for s in s_records:
            if (s.day_night != 2) and (s.day_night != day_night):
                continue
            try:
                strategy_ev_task.delay(s.id, date, st_uuid=s.st_uuid)
            except Exception as e:
                sentry.captureException()
                continue


def test0():
    date = '20200422'
    with session_context() as sc:
        s_records = sc.query(Strategy).filter(
            Strategy.is_delete == 0,
            Strategy.is_test == 0,
            Strategy.end_date >= date,
            Strategy.status != StrategyConstant.Status.STOPPED.value,
            Strategy.node == StrategyConstant.Node.EV.value,
            # Strategy.r_create_user_id.in_(CompanyUser.stock_ev_user_ids()),
            # Strategy.r_create_user_id.notin_(CompanyUser.stock_ev_user_ids()),
            Strategy.id.in_(consts.STOCK_FACTOR_EV)
            # Strategy.id.notin_(consts.STOCK_FACTOR_EV),
            # Strategy.id.in_(get_live_ev_ids_cache()),
            # Strategy.id.notin_(get_live_ev_ids_cache())
        ).order_by(Strategy.id.asc()).all()

        print(len(s_records))
        queue_stat = dict()
        for s in s_records:
            q = choose_task_queue(uid=s.r_create_user_id, s_id=s.id)
            queue_stat.setdefault(q, 0)
            queue_stat[q] += 1
            # print(s.id, s.r_create_user_id, s.username, s.name, s.day_night, s.status)
            # r = sc.query(StrategyResult).filter(
            #     StrategyResult.strategy_id == s.id,
            #     StrategyResult.date == date
            # ).first()
        pprint(queue_stat)


def test1():
    # kdb = KdbQuery()
    # days = kdb.get_trading_days('20200416', '20200416')
    # print(days)
    trading_date = Strategy.get_trading_date()
    print(trading_date)


if __name__ == '__main__':
    # test0()
    # test1()
    pass

from models.util import migrate, BaseModel
from db import engine

"""
migrate orm here
"""


def migrate_example_model():
    from models.example import ExampleModel

    migrate(base_model=BaseModel, engine=engine, model=ExampleModel)


def migrate_vs_t0_relation():
    from models.strategy import VsT0Relation

    migrate(base_model=BaseModel, engine=engine, model=VsT0Relation)


def migrate_vs_hedge_relation():
    from models.strategy import VsHedgeRelation

    migrate(base_model=BaseModel, engine=engine, model=VsHedgeRelation)


def migrate_union_simu_strategy_relation():
    from models.strategy import UnionSimuStrategyRelation

    migrate(base_model=BaseModel, engine=engine, model=UnionSimuStrategyRelation)


if __name__ == '__main__':
    # migrate_example_model()
    # migrate_vs_t0_relation()
    # migrate_vs_hedge_relation()
    # migrate_union_simu_strategy_relation()
    pass

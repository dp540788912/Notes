import pandas


def find_nan_rows(file_name):
    df = pandas.read_csv(file_name)
    is_nan = df.isna()
    row_has_nan = is_nan.any(axis=1)
    rows_with_nan = df[row_has_nan]
    print(rows_with_nan)


if __name__ == '__main__':
    # find_nan_rows(file_name='20190830_217751_performance.csv')
    pass

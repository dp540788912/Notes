from new_settlement.new_settlement.models import SettlementManualTradelog
from kdb_query import KdbQuery
from db import session_context

kdb = KdbQuery()


def amend_trade_price(vs_ids, trading_date, symbols):
    close_prices = kdb.get_stock_close_price(trading_date=trading_date, day_night=0)
    with session_context() as sc:
        records = sc.query(SettlementManualTradelog).filter(
            SettlementManualTradelog.vstrategy_id.in_(vs_ids),
            SettlementManualTradelog.trading_date == trading_date,
            SettlementManualTradelog.entrust_no == 111111111
        )
        if symbols:
            records.filter(
                SettlementManualTradelog.symbol.in_(symbols)
            )
        records = records.all()
        for r in records:
            close_price = close_prices[r.symbol]
            print(r.vstrategy_id, r.trading_date, r.symbol, r.trade_price, close_price)
            r.trade_price = close_price


if __name__ == '__main__':
    # amend_trade_price(vs_ids=[2216, 2219], trading_date='20200310', symbols=[])
    pass

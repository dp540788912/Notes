import pandas as pd

from service.back_test.ev_task import add_factor_products
from service.back_test.models import Strategy
from db import session_context
from config import RedisCache0
from constant import StockFactorEvaluationQueueEvent, RedisKeyConstant


def batch_import_factor_dependence_from_csv(sid, csv_file):
    """
    batch add factor dependence of strategy from a csv file
    :param sid: int, strategy id
    :param csv_file: string, path to csv file, csv file contain column 'factor_id'
    :return:
    """
    df = pd.read_csv(csv_file)
    factor_ids = list()
    for i, row in df.iterrows():
        factor_ids.append(row['factor_id'])

    try:
        add_factor_products(ev_id=sid, factor_ids=factor_ids)
    except Exception as e:
        print(str(e))


def add_factor_dependence_from_other_strategy(to_sid, from_sid):
    """

    :param to_sid: int, strategy id, add to this strategy
    :param from_sid: int, strategy id, factor from this strategy
    :return:
    """
    with session_context() as sc:
        from_s = sc.query(Strategy).filter(Strategy.id == from_sid).first()
        if from_s:
            direct_dep_factor_ids = from_s.direct_dep_factor_ids()
            add_factor_products(ev_id=to_sid, factor_ids=direct_dep_factor_ids)


def get_running_factor_evaluation_ids(event):
    """
    get factor ids running one of factor evaluation events
    :param event: string, constant.StockFactorEvaluationQueueEvent
    :return: list, factor ids
    """
    if event == StockFactorEvaluationQueueEvent.Simulator.value:
        key_pattern = RedisKeyConstant.FactorSimulatorStatus.value.format(factor_id='*')
    elif event == StockFactorEvaluationQueueEvent.Papertrading.value:
        key_pattern = RedisKeyConstant.FactorPaperTradingStatus.value.format(factor_id='*')
    else:
        key_pattern = ''

    if key_pattern:
        rds = RedisCache0()
        keys = rds.keys(key_pattern)
        return [int(k.decode('utf-8').split('_')[-1]) for k in keys]

    return []


if __name__ == '__main__':
    # batch_import_factor_dependence_from_csv(sid=218899, csv_file='218899.csv')
    # add_factor_dependence_from_other_strategy(to_sid=217080, from_sid=216377)
    # print(get_running_factor_evaluation_ids(event=StockFactorEvaluationQueueEvent.Papertrading.value))
    # print(get_running_factor_evaluation_ids(event=StockFactorEvaluationQueueEvent.Simulator.value))
    pass

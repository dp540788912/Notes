import copy
import time
import os
import shutil

import pandas as pd

from service.back_test.models import Strategy, VStrategies
from db import session_context
from constant import CompanyUser, VStrategiesConstant


def remove_future_strategy_products(s_id, symbols):
    """

    :param s_id: int
    :param symbols: list[string]
    :return:
    """
    modified = False
    with session_context() as sc:
        s = sc.query(Strategy).filter(Strategy.id == s_id).first()
        if not s:
            return modified
        products = copy.deepcopy(s.products)
        new_products = list()
        for p in products[0]:
            if p.get('type', '') == 'futures' and p.get('symbol', '') in symbols:
                continue
            new_products.append(p)
        if len(new_products) != len(products[0]):
            modified = True
        new_products = [new_products]
        s.products = new_products
        detail = copy.deepcopy(s.detail)
        detail['products'] = new_products
        s.detail = detail
    return modified


def add_future_strategy_products(s_id, symbol, rank, exchange):
    """

    :param s_id: int
    :param symbol: string
    :param rank: list, [1,2]
    :param exchange: string
    :return:
    """
    product = {
        "exch": exchange,
        "name": symbol,
        "rank": rank,
        "type": "futures",
        "symbol": symbol
    }
    with session_context() as sc:
        s = sc.query(Strategy).filter(Strategy.id == s_id).first()
        if not s:
            return False
        new_products = copy.deepcopy(s.products)
        new_products[0].append(product)
        s.products = new_products
        detail = copy.deepcopy(s.detail)
        detail['products'] = new_products
        s.detail = detail
    return True


def remove_future_vs_symbols_accounts_detail(vs_id, symbols, day_night):
    """

    :param vs_id: int
    :param symbols: string
    :param day_night: string, day|night|both
    :return:
    """
    modified = False
    with session_context() as sc:
        vs = sc.query(VStrategies).filter(VStrategies.id == vs_id).first()
        if not vs:
            return modified
        symbols_accounts_detail = copy.deepcopy(vs.symbols_accounts_detail)
        if day_night == 'both':
            symbols_accounts_detail['day'] = [r for r in symbols_accounts_detail['day'] if
                                              r.get('product', '') not in symbols]
            symbols_accounts_detail['night'] = [r for r in symbols_accounts_detail['night'] if
                                                r.get('product', '') not in symbols]
        else:
            symbols_accounts_detail[day_night] = [r for r in symbols_accounts_detail[day_night] if
                                                  r.get('product', '') not in symbols]

        if len(symbols_accounts_detail['day']) != len(vs.symbols_accounts_detail['day']) or len(
                symbols_accounts_detail['night']) != len(
            vs.symbols_accounts_detail['night']):
            modified = True

        vs.symbols_accounts_detail = symbols_accounts_detail

    return modified


def add_future_vs_symbols_accounts_detail(vs_id, symbol, day_night, rank, account, exchange):
    """

    :param vs_id: int
    :param symbol: string
    :param day_night: string, day|night|both
    :param rank: string, "1","1|2"
    :param account: string
    :param exchange: string
    :return:
    """
    element = {
        "rank": rank,
        "rate": 1,
        "amount": 0,
        "account": account,
        "max_vol": "",
        "product": symbol,
        "currency": "CNY",
        "exchange": exchange,
        "amount_rmb": 0,
        "actual_amount": 0,
        "actual_amount_rmb": 0
    }
    with session_context() as sc:
        vs = sc.query(VStrategies).filter(VStrategies.id == vs_id).first()
        if not vs:
            return False
        symbols_accounts_detail = copy.deepcopy(vs.symbols_accounts_detail)
        if day_night == 'both':
            symbols_accounts_detail['day'].append(element)
            symbols_accounts_detail['night'].append(element)
        else:
            symbols_accounts_detail[day_night].append(element)

        vs.symbols_accounts_detail = symbols_accounts_detail
    return True


def rename_strategy(s_id_no, new_name):
    """
    rename strategy name
    :param s_id_no: string, strategy id_no
    :param new_name: string, strategy new name
    :return:
    """
    with session_context() as sc:
        st = sc.query(Strategy).filter(
            Strategy.id_no == s_id_no
        ).first()
        if st:
            st.name = new_name
            detail = copy.deepcopy(st.detail)
            detail['name'] = new_name
            st.detail = detail


def copy_so_files(s_ids, src_path):
    """
    copy or substitute strategy so files
    :param s_ids: list, strategy id
    :param src_path: source so file path, so file name format is {s_id}.so
    :return:
    """
    try:
        with session_context() as sc:
            for s_id in s_ids:
                s = sc.query(Strategy).filter(Strategy.id == s_id).first()
                if s:
                    src_file = os.path.join(src_path, '{s_id}.so'.format(s_id=s_id))
                    dst_file = s.strategy_upload_file['abs_path']
                    print("from: ", src_file, "to: ", dst_file)
                    print("dst file before copy: ", time.ctime(os.path.getmtime(dst_file)))
                    shutil.copyfile(src_file, dst_file)
                    print("dst file after copy: ", time.ctime(os.path.getmtime(dst_file)))
    except Exception as e:
        print(str(e))


def get_symbols_info_from_csv(csv_path):
    """
    csv file download from create strategy web page
    :param csv_path: string, path to csv file, csv file contains columns [symbol, exchange, ranks]
    ['ic', 'CFFEX', '1|2']
    :return:
    """
    df = pd.read_csv(csv_path)
    symbols_info = list()
    for _, row in df.iterrows():
        symbols_info.append({
            'symbol': row['symbol'],
            'exchange': row['exchange'],
            'rank': row['ranks'],
            'rank_list': [int(ele) if ele != 'A' else ele for ele in row['ranks'].split("|")]
        })
    return symbols_info


def update_future_strategy_products_from_csv(s_id, csv_path):
    """
    update future strategy products, to be the same with listed symbols in csv
    :param s_id: int, strategy id
    :param csv_path: string, path to csv file
    :return:
    """
    symbols_info = get_symbols_info_from_csv(csv_path=csv_path)

    with session_context() as sc:
        s = sc.query(Strategy).filter(
            Strategy.id == s_id
        ).first()
        if not s:
            print("strategy record not found")
            return False

        new_products = list()
        for info in symbols_info:
            new_products.append({
                "exch": info['exchange'],
                "name": info['symbol'],
                "symbol": info['symbol'],
                "rank": info['rank_list'],
                "type": "futures",
            })
        new_products = [new_products]
        s.products = new_products
        detail = copy.deepcopy(s.detail)
        detail['products'] = new_products
        s.detail = detail

    return True


def update_future_vs_symbols_accounts_detail(s_id, csv_path):
    """
    update future vs strategy symbols accounts detail, to be the same with listed symbols in csv
    :param s_id: int, strategy id
    :param csv_path: string, path to csv file
    :return:
    """
    symbols_info = get_symbols_info_from_csv(csv_path=csv_path)
    symbols_info_dict = {ele['symbol']: ele for ele in symbols_info}
    symbols_list = symbols_info_dict.keys()

    with session_context() as sc:
        s = sc.query(Strategy).filter(
            Strategy.id == s_id
        ).first()
        if not s:
            print("strategy not found")
            return False

        day_night = s.day_night
        vs_records = sc.query(VStrategies).filter(
            VStrategies.strategy_id == s_id,
            VStrategies.status == VStrategiesConstant.Status.Live.value
        ).all()
        for vs in vs_records:
            symbols_accounts_detail = copy.deepcopy(vs.symbols_accounts_detail)
            if day_night in [0, 2]:
                symbols_accounts_detail = symbols_accounts_detail['day']
            elif day_night == 1:
                symbols_accounts_detail = symbols_accounts_detail['night']
            else:
                print("day_night is {day_night}".format(day_night=day_night))
                return False

            exchange_info = dict()
            for ele in symbols_accounts_detail:
                exchange_info.setdefault(ele['exchange'], {
                    'currency': ele['currency'],
                    'account': ele['account'],
                    'rate': ele['rate']
                })

            symbols_accounts = list()
            # handle delete or update case
            for ele in symbols_accounts_detail:
                symbol = ele['product']
                if symbol not in symbols_list:
                    continue
                ele['rank'] = symbols_info_dict[symbol]['rank']
                symbols_accounts.append(ele)

            symbols_accounts_list = [ele['product'] for ele in symbols_accounts]
            # handle add new symbol case
            for ele in symbols_list:
                if ele not in symbols_accounts_list:
                    exchange = symbols_info_dict[ele]['exchange']
                    new_ele = {
                        'rank': symbols_info_dict[ele]['rank'],
                        'exchange': exchange,
                        'product': ele,
                        'amount': 0,
                        'amount_rmb': 0,
                        'actual_amount': 0,
                        'actual_amount_rmb': 0,
                        'max_vol': ""
                    }
                    new_ele.update(exchange_info[exchange])
                    symbols_accounts.append(new_ele)

            if day_night == 0:
                new_symbols_accounts_detail = {
                    'day': symbols_accounts,
                    'night': []
                }
            elif day_night == 1:
                new_symbols_accounts_detail = {
                    'day': [],
                    'night': symbols_accounts
                }
            elif day_night == 2:
                new_symbols_accounts_detail = {
                    'day': symbols_accounts,
                    'night': symbols_accounts
                }
            else:
                print("day_night is {day_night}".format(day_night=day_night))
                return False

            vs.symbols_accounts_detail = new_symbols_accounts_detail

    return True


def script1():
    with session_context() as sc:
        s_records = sc.query(Strategy.id.label('s_id')).filter(
            Strategy.r_create_user_id == CompanyUser.JiangMingMing['id'],
            Strategy.is_delete == 0,
            Strategy.is_test == 0
        ).all()
        s_ids = [r.s_id for r in s_records]

        vs_records = sc.query(VStrategies.id.label('vs_id')).filter(
            VStrategies.strategy_id.in_(s_ids),
            VStrategies.status == VStrategiesConstant.Status.Live.value
        ).all()
        vs_ids = [r.vs_id for r in vs_records]

    print(len(s_ids))
    print(s_ids)
    print(len(vs_ids))
    print(vs_ids)

    for s_id in s_ids:
        print(s_id, remove_future_strategy_products(s_id=s_id, symbols=['cj']))

    for vs_id in vs_ids:
        print(vs_id, remove_future_vs_symbols_accounts_detail(vs_id=vs_id, symbols=['cj'], day_night='both'))


def script2():
    id_no_name_mapping = {
        # 'MJI01_12_20191011_001': 'st6nosh1',
        # 'MJI01_12_20191011_006': 'st6nosh2',
        # 'MJI01_12_20191011_008': 'st6nosh4',
        # 'MJI01_12_20191008_005': 'stminlength1',
        # 'MJI01_12_20191118_002': 'st9nosh3',
        # 'MJI01_12_20190711_002': 'st9nosh1',
        # 'MJI01_12_20191118_002': 'st7Calmanoshshift1'
    }
    for k, v in id_no_name_mapping.items():
        rename_strategy(s_id_no=k, new_name=v)


def script3():
    csv_path = 'symbol_ranks.csv'
    id_nos = [
        # "ALE01_12_20200628_002", "ALE01_12_20200628_003", "ALE01_12_20200628_004", "ALE01_12_20200628_005",
        # "ALE01_12_20200628_006", "ALE01_12_20200628_007",
        # "ALE01_12_20200628_008", "ALE01_12_20200628_009", "ALE01_12_20200628_010", "ALE01_12_20200628_011",
        # "ALE01_12_20200628_012",
        # "ALE01_12_20200628_013"
    ]
    with session_context() as sc:
        s_records = sc.query(Strategy).filter(
            Strategy.id_no.in_(id_nos)
        ).all()
        s_ids = [ele.id for ele in s_records]
        for s_id in s_ids:
            print(s_id, update_future_strategy_products_from_csv(s_id=s_id, csv_path=csv_path))
            print(s_id, update_future_vs_symbols_accounts_detail(s_id=s_id, csv_path=csv_path))


if __name__ == '__main__':
    # script1()
    # script2()
    # s_id = 204259
    # csv_path = 'symbol_ranks.csv'
    # status = update_future_strategy_products_from_csv(s_id=s_id, csv_path=csv_path)
    # status = update_future_vs_symbols_accounts_detail(s_id=s_id, csv_path=csv_path)
    # print(status)
    # print(get_symbols_info_from_csv(csv_path=csv_path))
    # script3()
    pass

from pprint import pprint

from db import session_context
from service.vwap.models import VsVwapResult
from service.statistic.models import VsBacktestTradingVolumeRatio
from service.back_test.models import BackTestTradeLogs, VstrategyBackTestResult, VstrategyBackTestResultDetail, \
    VstrategyBackTestResultAccount
from extensions import sentry


def delete_vs_back_test_data(vs_id, trading_date):
    """

    :param vs_id: int, vstrategy id
    :param trading_date: str, "%Y%m%d"
    :return:
    """
    try:
        with session_context() as sc:
            sc.query(BackTestTradeLogs).filter(
                BackTestTradeLogs.vstrategy_id == vs_id,
                BackTestTradeLogs.trading_date == trading_date
            ).delete()

            sc.query(VstrategyBackTestResult).filter(
                VstrategyBackTestResult.vstrategy_id == vs_id,
                VstrategyBackTestResult.trading_date == trading_date
            ).delete()

            sc.query(VstrategyBackTestResultDetail).filter(
                VstrategyBackTestResultDetail.vstrategy_id == vs_id,
                VstrategyBackTestResultDetail.trading_date == trading_date
            ).delete()

            sc.query(VstrategyBackTestResultAccount).filter(
                VstrategyBackTestResultAccount.vstrategy_id == vs_id,
                VstrategyBackTestResultAccount.trading_date == trading_date
            ).delete()

            sc.query(VsVwapResult).filter(
                VsVwapResult.vstrategy_id == vs_id,
                VsVwapResult.trading_date == trading_date
            ).delete()

            sc.query(VsBacktestTradingVolumeRatio).filter(
                VsBacktestTradingVolumeRatio.vs_id == vs_id,
                VsBacktestTradingVolumeRatio.trading_date == trading_date
            ).delete()
    except Exception as e:
        sentry.captureException()
        pprint(str(e))


if __name__ == '__main__':
    # delete_vs_back_test_data(vs_id=2219, trading_date='20200319')
    pass

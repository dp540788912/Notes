from pprint import pprint
from data_brick import StrategyBasicData, VsBasicData
from utility.func_util import record_time


@record_time
def strategy_basic_data_test():
    identifiers = [218928, 217445, 217444, 217442]
    # data = StrategyBasicData.get_one(identifier=218928)
    data = StrategyBasicData.get_many(identifiers=identifiers)
    pprint(data)
    # StrategyBasicData.update_caches(identifiers=identifiers)
    # StrategyBasicData.update_cache(identifier=218928)


@record_time
def vs_basic_data_test():
    identifiers = [2697, 2698, 2699]
    data = VsBasicData.get_many(identifiers=identifiers, cache=True)
    # data = VsBasicData.get_one(identifier=1565, cache=True)
    pprint(data)
    pprint(data[2697])


if __name__ == '__main__':
    # strategy_basic_data_test()
    # vs_basic_data_test()
    pass

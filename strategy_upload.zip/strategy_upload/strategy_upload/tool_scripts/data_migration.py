import datetime

from service.stock_factor.models import T0SubscriberHistory
from service.back_test.models import StockHedgeVs, Strategy
from models.strategy import VsT0Relation, VsHedgeRelation, UnionSimuStrategyRelation
from db import session_context
from utility.db_util import TradeCalendar
from config import config
from constant import StrategyConstant


def migrate_t0_relation_data():
    old_records_dict = dict()
    with session_context() as sc:
        old_records = sc.query(T0SubscriberHistory).order_by(
            T0SubscriberHistory.id.asc()
        ).all()
        new_records = sc.query(VsT0Relation).all()
        for r in new_records:
            key = (r.vs_id, r.link_vs_id)
            old_records_dict[key] = True

        for r in old_records:
            key = (r.t0_vs_id, r.alpha_vs_id)
            if not old_records_dict.get(key, False):
                old_records_dict[key] = True
                print(key)
                new_record = VsT0Relation(
                    vs_id=r.t0_vs_id,
                    link_vs_id=r.alpha_vs_id,
                    link_date=r.trading_date,
                    r_create_user_id=82,
                    r_update_user_id=82
                )
                # sc.add(new_record)


def migrate_hedge_relation_data():
    with session_context() as sc:
        old_records_dict = dict()
        old_records = sc.query(StockHedgeVs).all()
        new_records = sc.query(VsHedgeRelation).all()
        for r in new_records:
            key = (r.vs_id, r.link_vs_id)
            old_records_dict[key] = True

        for r in old_records:
            new_record = VsHedgeRelation(
                vs_id=r.future_vs_id,
                link_vs_id=r.stock_vs_id,
                r_create_user_id=82,
                r_update_user_id=82,
                deleted=not r.valid
            )
            sc.add(new_record)
            key = (r.future_vs_id, r.stock_vs_id)
            if not old_records_dict.get(key, False):
                old_records_dict[key] = True
                print(key)
                new_record = VsHedgeRelation(
                    vs_id=r.future_vs_id,
                    link_vs_id=r.stock_vs_id,
                    r_create_user_id=82,
                    r_update_user_id=82,
                    deleted=not r.valid
                )
                # sc.add(new_record)


def migrate_union_simu_strategy_relation_data():
    with session_context() as sc:
        s_records = sc.query(Strategy).filter(
            Strategy.strategy_type == StrategyConstant.StrategyType.JointSimulationStrategy.value,
            Strategy.is_delete == False,
            Strategy.is_derive_strategy == False
        ).all()
        for s in s_records:
            link_s_ids = s.detail['sub_sts']
            for s_id in link_s_ids:
                relation = UnionSimuStrategyRelation(
                    main_s_id=s.id,
                    link_s_id=s_id
                )
                # sc.add(relation)


if __name__ == '__main__':
    # migrate_t0_relation_data()
    # migrate_hedge_relation_data()
    # migrate_union_simu_strategy_relation_data()
    pass

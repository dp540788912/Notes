import os
import shutil

from constant import CommonPath
from db import session_context
from service.back_test.models import StrategyResult
from extensions import sentry


def copy_portfolio_optimization_ev_output_files(sid_dst_ev_name_map):
    """
    help to copy history portfolio optimization ev output files to path used by stock team and live strategy
    :param sid_dst_ev_name_map: dict, structure ref to consts.portfolio_optimization_ev_name
                                example: {216367: 'portfolio_optimization_ev_v3_%s.csv'}
    :return:
    """
    try:
        with session_context() as sc:
            for sid, info in sid_dst_ev_name_map.items():
                records = sc.query(StrategyResult).filter(StrategyResult.strategy_id == sid).order_by(
                    StrategyResult.id.asc()).all()
                for r in records:
                    if r.result_file_name.endswith('day.csv'):
                        src_file = os.path.join(CommonPath.media, r.result_file_name)
                        dst_file_name = info % r.date
                        dst_file1 = os.path.join(CommonPath.portfolio_optimization_ev, dst_file_name)
                        dst_file2 = os.path.join(CommonPath.portfolio_optimization_ev_share, dst_file_name)
                        shutil.copy(src_file, dst_file1)
                        shutil.copy(src_file, dst_file2)
    except Exception as e:
        sentry.captureException()

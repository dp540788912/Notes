# -*-coding:utf-8-*-


import sys
import os
import json
import redis

app_root = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
if app_root not in sys.path:
    sys.path.append(app_root)

from tornado import gen
from tornado.ioloop import IOLoop

import consts
from log import logger
from service.back_test.models import StrategyResult
from extensions import sentry
from config import config


class BaseCoroutineServer(object):

    def __init__(self):
        self.load_handlers()
        self.start()

    def get_workers(self):
        raise NotImplementedError()

    def load_handlers(self):

        self.handlers = []
        for worker in self.get_workers():
            self.handlers.append(worker().run())

    @gen.coroutine
    def listen(self):
        if self.handlers:
            yield self.handlers

    def start(self):
        IOLoop.current().run_sync(self.listen)


class BaseWorker(object):

    def __init__(self, seconds=1):
        self.seconds = seconds

    @gen.coroutine
    def run(self):
        while True:
            try:
                self.work_process()
            except Exception as e:
                sentry.captureException()
                logger.exception(e)
            yield gen.sleep(self.seconds)


class TaskCoroutineServer(BaseCoroutineServer):

    def __init__(self, mode='all'):
        self.mode = mode
        super(TaskCoroutineServer, self).__init__()

    def get_workers(self):
        return [TaskResponseWorker]


class TaskResponseWorker(BaseWorker):

    def __init__(self, *args, **kwargs):
        self.rds = redis.Redis(host=config.redis['host'], port=config.redis['port'], db=config.redis['db'])
        self.max_iter = 10
        super(TaskResponseWorker, self).__init__()

    def work_process(self):
        for i in range(self.max_iter):
            try:
                msg = self.rds.lpop(consts.AGENT_RESULT_QUEUE)
                if not msg:
                    continue
                data = json.loads(str(msg, 'utf-8'))
                StrategyResult.handle_result_v4(data)  # 回测结果接收函数
            except Exception as e:
                sentry.captureException()


if __name__ == "__main__":
    TaskCoroutineServer()

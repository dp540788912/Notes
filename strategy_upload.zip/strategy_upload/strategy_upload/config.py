# -*-coding:utf-8-*-

import netifaces
import sys
import copy

from utility.func_util import singleton
from utility.wechat_util import CompanyWeChatAPP
from utility.mail_util import CompanyMail
from utility.redis_util import RedisClient
from constant import CompanyWeChatAPPSetting, CompanyMailSetting


class CommonConfig(object):
    KDB_HOST = '192.168.1.44'
    KDB_PORT = 9000
    KDB_USER = 'superuser1'
    KDB_PASSWD = 'password'

    # email params
    FROM_ADDR = 'rss@mycapital.net'
    PASSWORD = 'Mycapital0427'
    SMTP_SERVER = 'smtp.qiye.163.com'
    SMTP_SERVER_PORT = 25

    dependency = []

    quote_api_host = '121.46.13.124:10010'
    quote_api_url = 'api/v1/speedquote/equityquote'

    ev_work_path = '/home/rss/userworkspace'

    otc_redis_config = {
        'host': '39.104.90.38',
        'port': 6380,
        'db': 3,
        'password': 'Mycap@2018'
    }

    notify_api = ''


class TestConfig(CommonConfig):
    Debug = False

    KDB_HOST = '192.168.10.102'

    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }

    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql

    redis = {
        'host': '127.0.0.1',
        'port': 6379,
        'db': 0
    }

    data_cache = {
        'host': '127.0.0.1',
        'port': 6379,
        'db': 0
    }

    session_cache = {
        'host': '127.0.0.1',
        'port': 6379,
        'db': 0
    }

    websocket_redis_queue = {
        'host': '127.0.0.1',
        'port': 6379,
        'db': 0
    }

    media = '/mnt/beegfs_platform/media'

    renv = '/mnt/beegfs_platform/media/renv'

    analysis_service_dir = '/home/rss/analysis_service/'

    sentry_dsn = 'http://9635333dfb4d47e9b30d9cdf82031636:e475f82630c94660905159549234fda3@121.46.13.124:9090/2'
    sentry_mod = sentry_dsn

    statsd = {
        'host': '192.168.3.183',
        'port': 8125,
    }

    analysis_service = '127.0.0.1/analysis-service'

    dependency = [
        analysis_service_dir,
    ]

    quote_api_host = '192.168.10.100:10010'

    user_nb_dir_template = '/home/rss/jupyter_userworkspace/%s_%s/'


class DebugConfig(CommonConfig):
    Debug = True

    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }

    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql

    redis = {
        'host': '127.0.0.1',
        'port': 6379,
        'db': 0
    }

    data_cache = {
        'host': '127.0.0.1',
        'port': 6379,
        'db': 0
    }

    session_cache = {
        'host': '127.0.0.1',
        'port': 6379,
        'db': 0
    }

    websocket_redis_queue = {
        'host': '127.0.0.1',
        'port': 6379,
        'db': 0
    }

    media = '/mnt/beegfs_platform/media'

    renv = '/mnt/beegfs_platform/media/renv'

    analysis_service_dir = '/home/rss/analysis_service/'

    sentry_dsn = 'http://bfba18c5268d440b9cd058436998bb25:fb41da137a234b39b18dc8166e33234a@121.46.13.124:9090/6'

    sentry_mod = sentry_dsn

    statsd = {
        'host': '192.168.3.183',
        'port': 8125,
    }

    analysis_service = '127.0.0.1/analysis-service'

    dependency = [
        analysis_service_dir,
    ]

    account_query_host = '192.168.1.170:13333'
    account_funds_url = 'api/v1/speedquote/equityaccount'
    wx_url = 'http://192.168.1.13:18886/api/v1/event_handle/qywx/message/send/text'

    user_nb_dir_template = '/home/rss/jupyterhub-mappings/jupyterhub-user-%s_%s/'


class DebugConfig170(CommonConfig):
    Debug = True

    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': 'Mycap@123',
    }

    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql

    redis = {
        'host': '127.0.0.1',
        'port': 6379,
        'db': 0
    }

    data_cache = {
        'host': '127.0.0.1',
        'port': 6379,
        'db': 0
    }

    session_cache = {
        'host': '127.0.0.1',
        'port': 6379,
        'db': 0
    }

    websocket_redis_queue = {
        'host': '127.0.0.1',
        'port': 6379,
        'db': 0
    }

    media = '/mnt/beegfs_platform/media'

    renv = '/mnt/beegfs_platform/media/renv'

    sentry_dsn = 'http://273ee67dcba14394be45a51cf3d17fa8:870b9d09193849378c2c2b9c133e93dc@121.46.13.124:9090/9'

    sentry_mod = sentry_dsn

    statsd = {
        'host': '192.168.3.183',
        'port': 8125,
    }

    analysis_service = '127.0.0.1/analysis-service'


class DebugConfigCommon(CommonConfig):
    Debug = True

    mysql = {
        'host': '192.168.1.14',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }

    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql

    redis = {
        'host': '192.168.1.14',
        'port': 6379,
        'db': 0
    }

    data_cache = {
        'host': '192.168.1.14',
        'port': 6379,
        'db': 0
    }

    session_cache = {
        'host': '192.168.1.14',
        'port': 6379,
        'db': 0
    }

    websocket_redis_queue = {
        'host': '192.168.1.14',
        'port': 6379,
        'db': 0
    }

    media = '/mnt/beegfs_platform/media'

    renv = '/mnt/beegfs_platform/media/renv'

    analysis_service_dir = '/home/rss/analysis_service/'

    sentry_dsn = 'http://bfba18c5268d440b9cd058436998bb25:fb41da137a234b39b18dc8166e33234a@121.46.13.124:9090/6'

    sentry_mod = sentry_dsn

    statsd = {
        'host': '192.168.3.183',
        'port': 8125,
    }

    analysis_service = '192.168.1.14/analysis-service'

    dependency = [
        analysis_service_dir,
    ]

    user_nb_dir_template = '/home/rss/jupyterhub-mappings/jupyterhub-user-%s_%s/'


class ProductConfigIDC(object):
    Debug = False

    KDB_HOST = '192.168.10.102'
    KDB_PORT = 9000
    KDB_USER = 'superuser1'
    KDB_PASSWD = 'password'

    # kdb config
    kdb_config = {
        'host': '192.168.10.102',
        'port': 9000,
        'username': 'superuser1',
        'password': 'password'
    }

    # email params
    FROM_ADDR = 'rss@mycapital.net'
    PASSWORD = 'Mycapital0427'
    SMTP_SERVER = 'smtp.qiye.163.com'
    SMTP_SERVER_PORT = 25

    mysql = {
        'host': '127.0.0.1',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }

    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql

    redis = {
        'host': '192.168.10.99',
        'port': 6379,
        'db': 0
    }

    data_cache = {
        'host': '192.168.10.99',
        'port': 6379,
        'db': 0
    }

    session_cache = {
        'host': '192.168.10.99',
        'port': 6379,
        'db': 0
    }

    websocket_redis_queue = {
        'host': '192.168.10.99',
        'port': 6379,
        'db': 0
    }

    media = '/mnt/beegfs_platform/media'

    renv = '/mnt/beegfs_platform/media/renv'

    analysis_service_dir = '/home/rss/analysis_service/'

    sentry_dsn = 'https://9635333dfb4d47e9b30d9cdf82031636:e475f82630c94660905159549234fda3@sentry.mycapital.net/2'

    sentry_mod = 'https://39cea4d695fd4aa79185b633832bae4a:1bb4f19ed1ba4ec0b02519c3e23976c3@sentry.mycapital.net/22'

    statsd = {
        'host': '192.168.3.183',
        'port': 8125,
    }

    analysis_service = '192.168.10.101:20000'

    dependency = [
        analysis_service_dir,
    ]

    quote_api_host = '192.168.10.100:10010'
    quote_api_url = 'api/v1/speedquote/equityquote'
    account_query_host = '192.168.10.100:13333'
    account_funds_url = 'api/v1/speedquote/equityaccount'
    wx_url = 'http://192.168.10.100:18886/api/v1/event_handle/qywx/message/send/text'

    user_nb_dir_template = '/home/rss/jupyter_userworkspace/%s_%s/'

    ev_work_path = '/home/rss/jupyter_userworkspace/'

    otc_redis_config = {
        'host': '119.23.46.51',
        'port': 6380,
        'db': 2,
        'password': 'Mycap@2018'
    }

    notify_api = 'https://quant.mycapital.net/api/v1/platform/events'


class EvProductConfig(ProductConfigIDC):
    mysql = {
        'host': '192.168.10.80',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }

    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql

    redis = {
        'host': '192.168.10.99',
        'port': 6379,
        'db': 0
    }

    data_cache = {
        'host': '192.168.10.99',
        'port': 6379,
        'db': 0
    }

    session_cache = {
        'host': '192.168.10.99',
        'port': 6379,
        'db': 0
    }

    websocket_redis_queue = {
        'host': '192.168.10.99',
        'port': 6379,
        'db': 0
    }

    sentry_dsn = 'https://9635333dfb4d47e9b30d9cdf82031636:e475f82630c94660905159549234fda3@sentry.mycapital.net/2'

    sentry_mod = 'https://39cea4d695fd4aa79185b633832bae4a:1bb4f19ed1ba4ec0b02519c3e23976c3@sentry.mycapital.net/22'


class ProductionVIPCronConfig(ProductConfigIDC):
    mysql = {
        'host': '192.168.10.80',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }

    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql

    redis = {
        'host': '192.168.10.99',
        'port': 6379,
        'db': 0
    }

    data_cache = {
        'host': '192.168.10.99',
        'port': 6379,
        'db': 0
    }

    session_cache = {
        'host': '192.168.10.99',
        'port': 6379,
        'db': 0
    }

    websocket_redis_queue = {
        'host': '192.168.10.99',
        'port': 6379,
        'db': 0
    }


class DevConfig(object):
    Debug = True

    KDB_HOST = '127.0.0.1'
    KDB_PORT = 9000
    KDB_USER = 'superuser1'
    KDB_PASSWD = 'password'

    # kdb config
    kdb_config = {
        'host': '127.0.0.1',
        'port': 9000,
        'username': 'superuser1',
        'password': 'password'
    }

    # email params
    FROM_ADDR = 'rss@mycapital.net'
    PASSWORD = 'Mycapital0427'
    SMTP_SERVER = 'smtp.qiye.163.com'
    SMTP_SERVER_PORT = 25

    mysql = {
        'host': '192.168.30.100',
        'port': 3306,
        'db': 'datahub',
        'user': 'dev2',
        'passwd': 'admin123',
    }

    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql

    redis = {
        'host': '192.168.30.99',
        'port': 6379,
        'db': 0
    }

    data_cache = {
        'host': '192.168.30.99',
        'port': 6379,
        'db': 0
    }

    session_cache = {
        'host': '192.168.30.99',
        'port': 6379,
        'db': 0
    }

    websocket_redis_queue = {
        'host': '192.168.30.99',
        'port': 6379,
        'db': 0
    }

    media = '/mnt/beegfs_platform/media'

    renv = '/mnt/beegfs_platform/media/renv'

    sentry_dsn = 'https://2065c4df8ab24f878f0fa842a7d40d0e:a34f48d701c74a8eb9a28493600e384f@sentry.mycapital.net/19'

    sentry_mod = sentry_dsn

    statsd = {
        'host': '192.168.3.183',
        'port': 8125,
    }

    analysis_service = '192.168.10.101:20000'

    quote_api_host = '192.168.30.100:10010'
    quote_api_url = 'api/v1/speedquote/equityquote'
    account_query_host = '192.168.30.100:13333'
    account_funds_url = 'api/v1/speedquote/equityaccount'
    wx_url = 'http://192.168.30.100:18886/api/v1/event_handle/qywx/message/send/text'

    user_nb_dir_template = '/home/rss/jupyter_userworkspace/%s_%s/'

    ev_work_path = '/home/rss/jupyter_userworkspace/'

    notify_api = 'https://quant.mycapital.net/api/v1/platform/events'

    # rewrite the flowing field
    analysis_service_dir = ''
    dependency = [
        analysis_service_dir,
    ]


class MackDevConfig(DevConfig):
    analysis_service_dir = '/home/mack/works/analysis_service'
    dependency = [
        analysis_service_dir,
    ]


class ChenyijianDevConfig(object):
    Debug = True

    KDB_HOST = '127.0.0.1'
    # KDB_HOST = '121.46.13.127'  # public ip
    KDB_PORT = 9000
    KDB_USER = 'superuser1'
    KDB_PASSWD = 'password'

    # email params
    FROM_ADDR = 'rss@mycapital.net'
    PASSWORD = 'Mycapital0427'
    SMTP_SERVER = 'smtp.qiye.163.com'
    SMTP_SERVER_PORT = 25
    kdb_config = {
        'host': '127.0.0.1',
        'port': 9000,
        'username': 'superuser1',
        'password': 'password'
    }

    mysql = {
        'host': '192.168.30.100',
        'port': 3306,
        'db': 'datahub',
        'user': 'chenyijian',
        'passwd': '123456',
    }

    mysql['db_uri'] = 'mysql://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql

    redis = {
        'host': '192.168.30.99',
        'port': 6379,
        'db': 0
    }

    data_cache = {
        'host': '192.168.30.99',
        'port': 6379,
        'db': 0
    }

    session_cache = {
        'host': '192.168.30.99',
        'port': 6379,
        'db': 0
    }

    websocket_redis_queue = {
        'host': '192.168.30.99',
        'port': 6379,
        'db': 0
    }

    media = '/mnt/beegfs_platform/media'

    renv = '/mnt/beegfs_platform/media/renv'

    analysis_service_dir = '/home/rss/analysis_service'

    sentry_dsn = 'https://2065c4df8ab24f878f0fa842a7d40d0e:a34f48d701c74a8eb9a28493600e384f@sentry.mycapital.net/19'

    sentry_mod = sentry_dsn

    statsd = {
        'host': '192.168.3.183',
        'port': 8125,
    }

    analysis_service = '192.168.10.101:20000'

    dependency = [
        analysis_service_dir,
    ]

    quote_api_host = '192.168.30.100:10010'
    quote_api_url = 'api/v1/speedquote/equityquote'
    account_query_host = '192.168.30.100:13333'
    account_funds_url = 'api/v1/speedquote/equityaccount'
    wx_url = 'http://192.168.30.100:18886/api/v1/event_handle/qywx/message/send/text'

    user_nb_dir_template = '/home/rss/jupyter_userworkspace/%s_%s/'

    ev_work_path = '/home/rss/jupyter_userworkspace/'

    otc_redis_config = {
        'host': '119.23.46.51',
        'port': 6380,
        'db': 2,
        'password': 'Mycap@2018'
    }

    notify_api = 'https://quant.mycapital.net/api/v1/platform/events'


class MarkConfig(DevConfig):
    analysis_service_dir = '/home/mark/Documents/code/quant_analysis_service'
    dependency = [
        analysis_service_dir,
    ]
    mysql = {
        'host': '192.168.30.100',
        'port': 3306,
        'db': 'datahub',
        'user': 'dev2',
        'passwd': 'admin123',
    }
    mysql['db_uri'] = 'mysql+mysqlconnector://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % mysql


class FrankConfig(DevConfig):
    analysis_dir = "/home/frank/project/quant_analysis_service"
    dependency = [analysis_dir]
    KDB_HOST = '192.168.1.44'
    KDB_PORT = 9000
    KDB_USER = 'superuser1'
    KDB_PASSWD = 'password'
    mysql = {
        'host': '192.168.1.14',
        'port': 3306,
        'db': 'datahub',
        'user': 'root',
        'passwd': '123456',
    }

    redis = {
        'host': 'localhost',
        'port': 6379,
        'db': 0
    }

    media = "/home/frank/Desktop/test"

    mysql['db_uri'] = 'mysql+mysqlconnector://%(user)s:%(passwd)s@%(host)s:%(port)s/%(db)s' % DevConfig.mysql


ip_list = [netifaces.ifaddresses(i).get(netifaces.AF_INET)[0]['addr']
           for i in netifaces.interfaces() if netifaces.ifaddresses(i).get(netifaces.AF_INET)]

debug_ip_list = ['192.168.1.14']

test_list = ['192.168.10.109']

product_idc_list = ['192.168.10.100']

product_vip_list = ['192.168.10.119']

gpu_product_list = ['192.168.10.116', '192.168.10.149', '192.168.10.60']

cron_product_list = ['192.168.10.120', '192.168.10.140']

mack_dev_ip_list = ["192.168.4.135", "192.168.30.190"]

chenyijian_dev_ip_list = ["192.168.4.165", "192.168.30.193"]

mark_dev_ip_list = ["192.168.88.128", "192.168.30.193"]

pandeng_dev_ip_list = ["192.168.4.27"]

if any([i in ip_list for i in product_idc_list]):
    Debug = False
    config = ProductConfigIDC()
elif any([i in ip_list for i in gpu_product_list]):
    Debug = False
    config = EvProductConfig()
elif any([i in ip_list for i in cron_product_list]):
    Debug = False
    config = EvProductConfig()
elif any([i in ip_list for i in product_vip_list]):
    Debug = False
    config = ProductionVIPCronConfig()
elif any([i in ip_list for i in debug_ip_list]):
    Debug = True
    config = DebugConfig()
elif any([i in ip_list for i in test_list]):
    Debug = True
    config = TestConfig()
elif any([i in ip_list for i in mack_dev_ip_list]):
    Debug = True
    config = MackDevConfig()
elif any([i in ip_list for i in chenyijian_dev_ip_list]):
    Debug = True
    config = ChenyijianDevConfig()
elif any([i in ip_list for i in pandeng_dev_ip_list]):
    Debug = True
    config = FrankConfig()
elif any([i in ip_list for i in mark_dev_ip_list]):
    Debug = True
    config = MarkConfig()
else:
    Debug = True
    config = DebugConfigCommon()

for path in config.dependency:
    if path not in sys.path:
        sys.path.append(path)


@singleton
class RedisCache0(RedisClient):
    def __init__(self):
        super().__init__(config.redis)


@singleton
class DataBrickRedisBackend(RedisClient):
    def __init__(self):
        redis_conf = copy.deepcopy(config.redis)
        redis_conf['db'] = 10
        super().__init__(redis_conf)


@singleton
class RssMail(CompanyMail):
    def __init__(self):
        super().__init__(**CompanyMailSetting.rss)


@singleton
class QuantDevWeChatAPP(CompanyWeChatAPP):
    def __init__(self):
        if Debug:
            quant_dev_setting = copy.deepcopy(CompanyWeChatAPPSetting.quant_dev_test)
        else:
            quant_dev_setting = copy.deepcopy(CompanyWeChatAPPSetting.quant_dev)
        quant_dev_setting.update({
            'redis_client': RedisCache0()
        })
        super().__init__(**quant_dev_setting)


@singleton
class QuantOpsWeChatAPP(CompanyWeChatAPP):
    def __init__(self):
        quant_ops_setting = copy.deepcopy(CompanyWeChatAPPSetting.quant_ops)
        quant_ops_setting.update({
            'redis_client': RedisCache0()
        })
        super().__init__(**quant_ops_setting)


@singleton
class CompanyPlatformWeChatAPP(CompanyWeChatAPP):
    def __init__(self):
        company_platform_setting = copy.deepcopy(CompanyWeChatAPPSetting.company_platform)
        company_platform_setting.update({
            'redis_client': RedisCache0()
        })
        super().__init__(**company_platform_setting)


if __name__ == '__main__':
    pass

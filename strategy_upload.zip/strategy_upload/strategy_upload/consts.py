# -*-coding:utf-8-*-

from enum import Enum, unique

STRATEGY_TYPE = {
    '01': 'CTA期货策略',
    '02': '股票策略',
    '03': '债券类策略',
    '04': '外汇类策略',
    '05': '混合类策略',
    '06': '套利类策略',
    '98': '参数交易策略',
    '99': '其它',
    'PO': '策略组合',
    '11': 'CTA单合约策略',
    '12': 'CTA多合约策略',
    '13': '期货多品种套利策略',
    '14': '期货跨期套利策略',
    '15': '股票Alpha策略',
    '16': '股票Long Only策略',
    '17': '股票Long Short策略',
    '18': '股票T+0策略',
    '19': '期权策略',
    '20': '股票Alpha对冲端策略',
    '22': '数字货币策略',
    '23': '期货外盘策略',
    '24': '股票算法交易模块',
    '25': '股票风险模块',
    '26': '股票因子策略',
    '27': 'HK股票Alpha策略',
    '28': 'HK股票T+0策略',
    '29': 'xxxx',
    '30': '股票因子评估策略',
    '31': '轧差交易策略',
    '32': '股票Master配置策略',
    '33': '股票Master交易策略',
    '34': '联合模拟策略',
}

stock_strategy_type = ('02', '15', '16', '17', '18', '26', '27', '28', '33', '34')

t0_stock_strategy_type = ('18', '28')

alpha_stock_strategy_type = ('15', '27', '33')

hedge_stock_strategy_type = ('20',)

STRATEGY_FEATURE = {
    '001': '趋势跟踪',
    '002': '趋势反转',
    '003': '技术指标-MA',
    '004': '技术指标-RSI',
    '005': '技术指标-Bands',
    '006': '技术指标-Momentum',
    '007': '技术指标-Acceleration',
    '008': '技术指标-MACD',
    '009': '技术指标-MFI',
    '010': '技术指标-Volume',
    '011': '技术指标-Oscillator',
    '012': '技术指标-其它',
    '999': '其它',
}

STRATEGY_UNDERLYING_TYPE = {
    '01': '单策略单品种',
    '02': '单策略独立多品种',
    '03': '单策略多品种组合',
    '04': '单策略单股票',
    '05': '单策略独立多股票',
    '06': '单策略多股票组合',
    '07': '其它',
}

STRATEGY_PARA_TYPE = {
    '0': '固定参数',
    '1': '自动更新',
    '2': '多参数优化',
}

STRATEGY_STATUE = {
    'NEW': '新增',
    'BT': 'Back Test',
    'PT': 'Paper Trading',
    'LT': '实盘',
    'CO': 'Closing Out'
}

# 用户所属组的常量定义

INVESTMENT_GROUP = 2
OPERATION_GROUP = 3

# 策略状态的常量定义

STRATEGY_SEMI_LIVE = 8
STRATEGY_SEMI_QUANTAMEMTAL = 9
STRATEGY_TOBE_AUDITED = 11
STRATEGY_TOBE_PRE_CONFIG = 12
STRATEGY_TOBE_DEPLOY = 13
STRATEGY_TOBE_CONFIG = 14
STRATEGY_LIVE = 15
STRATEGY_OFF_SHELF = 16
STRATEGY_CLOSING_OUT = 17
STRATEGY_CLOSED_DONE = 18
STRATEGY_DELETE = -1

VSTRATEGY_STATUE = {
    STRATEGY_TOBE_AUDITED: '待审核',
    STRATEGY_TOBE_PRE_CONFIG: '待预配置',
    STRATEGY_TOBE_DEPLOY: '待部署',
    STRATEGY_TOBE_CONFIG: '待生成配置',
    STRATEGY_LIVE: '实盘交易',
    STRATEGY_CLOSING_OUT: '清仓中',
    STRATEGY_OFF_SHELF: '下架',
    STRATEGY_DELETE: '删除',
}

TASK_NEW = 2
TASK_RUNNING = 1
TASK_FAILED = -1
TASK_FINISHED = 0
TASK_STOPPED = -2

STRATEGY_STATUS_MAP = {
    TASK_RUNNING: 'RUNNING',
    TASK_FINISHED: 'FINISHED',
    TASK_FAILED: 'FAILED',
    TASK_STOPPED: 'STOPPED',
    TASK_NEW: 'NEW'
}

STRATEGY_STATUS_MAP2 = {v: k for k, v in STRATEGY_STATUS_MAP.items()}

# 策略的构成形态
STRAT_SINGLE = 0  # 单个策略
STRAT_GROUP = 1  # 策略组合
INVEST_GROUP = 2  # 投资组合

PRODUCTSLONG2SHORT = {
    'dla': 'a',
    'dlb': 'b',
    'dlbb': 'bb',
    'dlc': 'c',
    'dlcs': 'cs',
    'dlfb': 'fb',
    'dli': 'i',
    'dlj': 'j',
    'dljd': 'jd',
    'dljm': 'jm',
    'dll': 'l',
    'dlm': 'm',
    'dlp': 'p',
    'dlpp': 'pp',
    'dlv': 'v',
    'dly': 'y',
    'ic': 'ic',
    'if': 'if',
    'ih': 'ih',
    'shag': 'ag',
    'shal': 'al',
    'shau': 'au',
    'shbu': 'bu',
    'shcu': 'cu',
    'shfu': 'fu',
    'shhc': 'hc',
    'shni': 'ni',
    'shpb': 'pb',
    'shrb': 'rb',
    'shru': 'ru',
    'shwr': 'wr',
    'shzn': 'zn',
    't': 't',
    'tf': 'tf',
    'zzcf': 'cf',
    'zzfg': 'fg',
    'zzjr': 'jr',
    'zzli': 'li',
    'zzma': 'ma',
    'zzme': 'me',
    'zzoi': 'oi',
    'zzpm': 'pm',
    'zzri': 'ri',
    'zzrm': 'rm',
    'zzrs': 'rs',
    'zzsf': 'sf',
    'zzsm': 'sm',
    'zzsr': 'sr',
    'zzta': 'ta',
    'zztc': 'tc',
    'zzwh': 'wh',
    'zzzc': 'zc',
    'zzap': 'ap',
    'SHFEALL': 'SHFEALL',
    'DCEALL': 'DCEALL',
    'CZCEALL': 'CZCEALL',
    'CFFEXALL': 'CFFEXALL',
}

PRODUCTSSHORT2LONG = {v: k for k, v in PRODUCTSLONG2SHORT.items()}

EXCHANGE = {
    'A': 'SHFE',
    'B': 'DCE',
    'C': 'CZCE',
    'G': 'CFFEX',
    '0': 'SZSE',
    '1': 'SSE',
    '2': 'SEHK',
    'D': 'SGE',
    'S': 'SGX',
    'F': 'CBOT',
    'M': 'CME',
    'L': 'LME',
    'N': 'NYMEX',
    'O': 'COMEX',
    'T': 'BITMEX',
    'U': 'BITFINEX',
    'X': 'BINANCE',
    'Y': 'OKEX',
    'Z': 'HUOBIEX',
    'E': 'ICEE',
    '9': 'IPE',
    'P': 'ICEU',
}

EXCHANGESHORTNAME = {v: k for k, v in EXCHANGE.items()}

SHORTPRODUCTS2EXCHANGE = {
    u'a': 'DCE',
    u'ag': 'SHFE',
    u'al': 'SHFE',
    u'au': 'SHFE',
    u'b': 'DCE',
    u'bb': 'DCE',
    u'bu': 'SHFE',
    u'c': 'DCE',
    u'cf': 'CZCE',
    u'cs': 'DCE',
    u'cu': 'SHFE',
    u'fb': 'DCE',
    u'fg': 'CZCE',
    u'fu': 'SHFE',
    u'hc': 'SHFE',
    u'i': 'DCE',
    u'ic': 'CFFEX',
    u'if': 'CFFEX',
    u'ih': 'CFFEX',
    u'j': 'DCE',
    u'jd': 'DCE',
    u'jm': 'DCE',
    u'jr': 'CZCE',
    u'l': 'DCE',
    u'li': 'CZCE',
    u'm': 'DCE',
    u'ma': 'CZCE',
    u'me': 'CZCE',
    u'ni': 'SHFE',
    u'oi': 'CZCE',
    u'p': 'DCE',
    u'pb': 'SHFE',
    u'pm': 'CZCE',
    u'pp': 'DCE',
    u'rb': 'SHFE',
    u'ri': 'CZCE',
    u'rm': 'CZCE',
    u'rs': 'CZCE',
    u'ru': 'SHFE',
    u'sf': 'CZCE',
    u'sm': 'CZCE',
    u'sr': 'CZCE',
    u't': 'CFFEX',
    u'ta': 'CZCE',
    u'tc': 'CZCE',
    u'tf': 'CFFEX',
    u'v': 'DCE',
    u'wh': 'CZCE',
    u'wr': 'SHFE',
    u'y': 'DCE',
    u'zc': 'CZCE',
    u'zn': 'SHFE',
    u'ap': 'CZCE',
    u'SHFEALL': 'SHFE',
    u'DCEALL': 'DCE',
    u'CZCEALL': 'CZCE',
    u'CFFEXALL': 'CFFEX',
}

LONGPRODUCT2EXCHANGE = {PRODUCTSSHORT2LONG[k]: v for k, v in SHORTPRODUCTS2EXCHANGE.items()}

MI_TYPE = {
    'SHFE': '6',
    'DCE': '1,3',
    'CZCE': '7',
    'CFFEX': '0',
    'SHFEx3': '12,6',
    'SHFEx1': '12',
    'SSE': '9',
    'SZSE': '9',
    'SSE_SZSE_INDEX': '10',
    'BMD': '25',
    'CBOT': '25',
    'CME': '25',
    'COMEX': '25',
    'HKEX': '25',
    'ICESG': '25',
    'ICEU': '25',
    'LME': '25',
    'NYMEX': '25',
    'SGX': '25',
    'TOCOM': '25',
    'SGE': '22',
    'IDEALPRO': '59',
    'ICEE': '25',
    'IPE': '25',
    'OKEX': '58',
    'APEX': '25',
}

BEGIN_END_TIME = {
    0: {"begin_time": 85800000, "end_time": 153000000},
    1: {"begin_time": 205800000, "end_time": 273000000},
    2: {"begin_time": 85800000, "end_time": 273000000},
}

COMMON_MATCH_PARAM = [
    '1,SHFE,any,0.8',
    '1,DCE,any,0.4',
    '1,CZCE,any,0.8',
    '1,CFFEX,any,0.7',
    '1,SSE,any,0.5',
    '1,SZSE,any,0.5',
    '1,BMD,any,0.7',
    '1,CBOT,any,0.7',
    '1,CME,any,0.7',
    '1,HKEX,any,0.7',
    '1,ICESG,any,0.7',
    '1,ICEU,any,0.7',
    '1,LME,any,0.7',
    '1,NYMEX,any,0.7',
    '1,SGX,any,0.7',
    '1,TOCOM,any,0.7',
    '1,INDEX,any,0.7',
    '1,SGE,any,0.7',
    '1,IDEALPRO,any,0.7',
    '1,ICEE,any,0.7',
    '1,IPE,any,0.7',
    '1,COMEX,any,0.7',
    '1,ICEU,any,0.7',
    '1,APEX,any,0.7',
]

FOREIGN_EXCHANGE = ['BMD', 'CBOT', 'CME', 'HKEX', 'ICESG', 'ICEU', 'LME', 'NYMEX', 'SGX', 'TOCOM', 'IDEALPRO', 'ICEE',
                    'IPE', 'COMEX', 'ICEU', 'APEX']
BTC_EXCHANGE = [
    'binance', 'bitfinex', 'bitmex', 'bitstamp', 'btcc', 'gdax', 'gemini', 'huobi',
    'kraken', 'okcoin', 'poloniex', 'quoine', 'zb', 'okex', 'huobiex'
]
BTC_EXCHANGE.extend([e.upper() for e in BTC_EXCHANGE])

FUTURE_EXCHANGE = ['SHFE', 'DCE', 'CZCE', 'CFFEX']
STOCK_EXCHANGE = ['SZSE', 'SSE']

AGENT_RESPONSE_CMD = 'a:rss:rsp'
AGENT_HOST_REGISTER = 'a:rss:hosts'
AGENT_DETAIL_REGISTER = 'a:rss:register'
WEB_SOCK_CONN = 'a:rss:websocket'

AGENT_LISTEN_CMD = "a:rss:cmd"

# AGENT_TASK_QUEUE = 'master_add_task'
NEW_AGENT_TASK_QUEUE = 'new_master_add_task'
AGENT_TASK_STOP_MAP = 'master_stop_task'
AGENT_RESULT_QUEUE = 'master_task_results'
# AGENT_TASK_STATUS_MAP = 'master_task_status'
# AGENT_TASK_LOG = 'master_task_screen_print'

# StockFactorEvaleQueue = 'stock_factor_evale_queue'

AGENT_TASK_INPROCESS = 0
AGENT_TASK_STOP = 1
AGENT_TASK_FINISHED = 2
AGENT_TASK_INQUEUE = 3
AGENT_TASK_FAILED = 4

# WEB_SOCK_STRATEGY_UPLOAD = 'strategy_upload'

# FEE_CACHE_KEY = 'platform_fee_cache'

TOTAL_POINT_RATIO = 0.2
PLATFORM_COST_RATIO = 0.1

# VWAP_ORDER_TYPE = {
#     1: 'PASSIVE',
#     2: 'AGGRESSIVE',
# }

place_order_req = '0'
place_order_rsp = '1'
order_rtn = '2'
trade_rtn = '3'
cancel_order_req = '4'
cancel_order_rsp = '5'
position_info = '6'


@unique
class Direction(Enum):
    buy = 0
    sell = 1


@unique
class OpenClose(Enum):
    open = 0
    close = 1
    force_close = 2
    close_today = 3


class DayNight(Enum):
    day = 0
    night = 1


# margin_ratio = 0.1
# stock_strategy = '02'

g_display_data = [
    {
        'prop': 'invest_funds',
        'title': '投入面值',
        'display': True,
        'sum': True
    },
    {
        'prop': 'today_pnl',
        'title': '当日盈亏额',
        'display': True,
        'sum': True
    },
    {
        'prop': 'total_pnl',
        'title': '总盈亏额',
        'display': True,
        'sum': True
    },
    {
        'prop': 'history_pnl',
        'title': '净值曲线',
        'display': True,
        'sum': False
    },
    {
        'prop': 'total_point',
        'title': '总分账成本',
        'display': True,
        'sum': True
    },
    {
        'prop': 'total_net_income',
        'title': '总净收入',
        'display': True,
        'sum': True
    },
    {
        'prop': 'trade_track',
        'title': '交易跟踪',
        'display': True,
        'sum': False
    },
    {
        'prop': 'vwap_slippage',
        'title': 'VWAP滑点(BP)<br>平均/标准差',
        'display': True,
        'sum': False
    },
    {
        'prop': 'status',
        'title': '策略状态',
        'display': True,
        'sum': False
    },
    {
        'prop': 'accounts',
        'title': '部署账户',
        'display': True,
        'sum': False
    },
    {
        'prop': 'notebook_links',
        'title': '分析',
        'display': True,
        'sum': False
    },
]

g_hide_data = [
    {
        'prop': 'strategy_feature',
        'title': '特点',
        'display': False,
        'sum': False
    },
    {
        'prop': 'products',
        'title': '品种',
        'display': False,
        'sum': False
    },
    {
        'prop': 'strategy_para_type',
        'title': '参数',
        'display': False,
        'sum': False
    },
    {
        'prop': 'desc',
        'title': '描述',
        'display': False,
        'sum': False
    }
]

investment_headers = {
    'portfolio': [
        {
            'prop': 'group_name',
            'title': '策略组合',
            'display': True
        },
        {
            'prop': 'name',
            'title': '名称',
            'display': True,
            'sum': False
        },
        {
            'prop': 'uptime',
            'title': '上载时间',
            'display': True,
            'sum': False
        },
        {
            'prop': 'realtime',
            'title': '实盘时间',
            'display': True,
            'sum': False
        }
    ],
    'strategy_type': [
        {
            'prop': 'type_name',
            'title': '策略类别',
            'display': True
        },
        {
            'prop': 'name',
            'title': '名称',
            'display': True,
            'sum': False
        },
        {
            'prop': 'uptime',
            'title': '上载时间',
            'display': True,
            'sum': False
        },
        {
            'prop': 'realtime',
            'title': '实盘时间',
            'display': True,
            'sum': False
        }
    ],
    'creator': [
        {
            'prop': 'strategy_id',
            'title': '策略ID',
            'display': True,
            'sum': False
        },
        {
            'prop': 'name',
            'title': '名称',
            'display': True,
            'sum': False
        },
        {
            'prop': 'creator',
            'title': '策略创建者',
            'display': True
        },
        {
            'prop': 'strategy_type',
            'title': '类型',
            'display': True,
            'sum': False,
        },
        {
            'prop': 'uptime',
            'title': '上载时间',
            'display': True,
            'sum': False
        },
        {
            'prop': 'realtime',
            'title': '实盘时间',
            'display': True,
            'sum': False
        }
    ]
}

children_investment_headers = [
    {
        'prop': 'strategy_id',
        'title': '策略ID',
        'display': True,
        'sum': False
    },
    {
        'prop': 'name',
        'title': '名称',
        'display': True,
        'sum': False
    },
    {
        'prop': 'uptime',
        'title': '上载时间',
        'display': True,
        'sum': False
    },
    {
        'prop': 'invest_funds',
        'title': '投入面值',
        'display': True,
        'sum': True
    },
    {
        'prop': 'today_pnl',
        'title': '当日盈亏额',
        'display': True,
        'sum': True
    },
    {
        'prop': 'total_pnl',
        'title': '总盈亏额',
        'display': True,
        'sum': True
    },
    {
        'prop': 'history_pnl',
        'title': '净值曲线',
        'display': True,
        'sum': False
    },
]

for k, v in investment_headers.items():
    v.extend(g_display_data)
    v.extend(g_hide_data)

LIVE_PERMISSION_GROUP = [9]

# Fund user IDs used by stock and futures departments.
# 302: yinhuo2, 494: stock1, 495: future1
investment_user_ids = [302, 494, 495]

factor_user_ids = [688, 692, 693, 694, 695, 696, 639, 708, 706]

stock_team_user_ids = [
    453, 407, 34, 609, 698
]

stock_ev_user_ids = list(set(stock_team_user_ids + list(factor_user_ids))) + [76, 18]

# gpu_user_ids = [698]

# future_team_user_ids = [
#     28, 29
# ]

# ev_user_100_server = [
#     38, 71, 501, 100, 76, 83, 487
# ]

# all offline
hk_stock_vs_ids = [
    1321,
    1322,
    1352,
    1377,
    1376,
    1375,
    1366,
    1388,
    1399,
    1423,
    1428,
    1439,
    1429,
    1421,
    1398,
    1476, 1479, 1480, 1477,
    1491, 1489, 1493, 1544, 1543, 1547, 1551, 1578, 1595, 1612, 1618, 1659, 1660, 1661, 1709, 1710, 1745, 1767,
    1756,
]

# all offline
hk_hedge_vs_ids = [
    1327,
    1328,
    1353,
    1378,
    1380,
    1379,
    1546,
]

FOREGIN_ACCOUNT = {
    'mycapi205': 'USD',
    '5938': 'USD',
    '910086': 'CNY',
    '920171': 'USD',
    '006571': 'USD',
}

# portfolio_optimization_ev = 208554

portfolio_optimization_ev_name = {
    208554: 'portfolio_optimization_ev_%s.csv',
    209902: 'portfolio_optimization_ev_rtn_%s.csv',
    209914: 'portfolio_optimization_ev_cov_%s.csv',
    209953: 'portfolio_optimization_ev_year_%s.csv',
    210006: 'portfolio_optimization_ev_plus_%s.csv',
    211037: 'portfolio_optimization_ev_volume_%s.csv',
    211109: 'portfolio_optimization_ev_bias_%s.csv',
    211567: 'portfolio_optimization_ev_indexmember_%s.csv',
    216367: 'portfolio_optimization_ev_v3_%s.csv',
    216406: 'portfolio_optimization_ev_rtn_v3_%s.csv',
    216434: 'portfolio_optimization_ev_cov_v3_%s.csv',
    216473: 'portfolio_optimization_ev_1minvol_%s.csv',
    218533: 'portfolio_optimization_ev_indexweight_%s.csv'
}

STOCK_FACTOR_EV = [208418] + list(portfolio_optimization_ev_name.keys())

# daily_ev_tasks = []

stock_user = {
    'id': 494,
    'is_superuser': False,
    'username': 'stock1',
    'nickname': 'stock1',
}

future_user = {
    'id': 495,
    'is_superuser': False,
    'username': 'future1',
    'nickname': 'future1',
}

stock_night_ev_ids = [
    208418,
]

future_risk_accounts = {
    # '920171': {
    #     'account': '920171',
    #     'currency': 'USD',
    #     'account_name': '魏振宇',
    #     'broker': '金瑞期货',
    # },
    # '910086': {
    #     'account': '910086',
    #     'currency': 'RMB',
    #     'account_name': '陈小英',
    #     'broker': '金瑞期货',
    # },
    # '85011366': {
    #    'account': '85011366',
    #    'currency': 'RMB',
    #    'account_name': '经典CTA-1',
    #    'broker': '海通期货',
    # },
    '80002928': {
        'account': '80002928',
        'currency': 'RMB',
        'account_name': '经典CTA-2',
        'broker': '华泰期货',
    },
    # '2100053': {
    #     'account': '2100053',
    #     'currency': 'RMB',
    #     'account_name': '经典CTA-2',
    #     'broker': '金瑞期货',
    # },
    # '85011682': {
    #     'account': '85011682',
    #     'currency': 'RMB',
    #     'account_name': '长岛2号',
    #     'broker': '海通期货',
    # },
    '006571': {
        'account': '006571',
        'currency': 'USD',
        'account_name': '套利直达账户	',
        'broker': '直达国际',
    },
    '80030010': {
        'account': '80030010',
        'currency': 'RMB',
        'account_name': '套利ctp	',
        'broker': '中融期货',
    },
    '80001865': {
        'account': '80001865',
        'currency': 'RMB',
        'account_name': '凡二英火1号',
        'broker': '华泰期货',
    },
    '21000087': {
        'account': '21000087',
        'currency': 'RMB',
        'account_name': '经典CTA-6',
        'broker': '金瑞期货',
    },
    '80003702': {
        'account': '80003702',
        'currency': 'RMB',
        'account_name': '经典CTA-5',
        'broker': '华泰期货	',
    },
    # '21000092': {
    #    'account': '21000092',
    #    'currency': 'RMB',
    #    'account_name': '经典CTA-8',
    #    'broker': '金瑞期货',
    # },
    '0380000868': {
        'account': '0380000868',
        'currency': 'RMB',
        'account_name': '经典CTA-8',
        'broker': '招商期货',
    },
    '21000020': {
        'account': '21000020',
        'currency': 'RMB',
        'account_name': '经典CTA-1',
        'broker': '金瑞期货',
    },
    '27800662': {
        'account': '27800662',
        'currency': 'RMB',
        'account_name': '经典CTA-9',
        'broker': '鲁证期货',
    },
    '27800686': {
        'account': '27800686',
        'currency': 'RMB',
        'account_name': '郭晓燕',
        'broker': '鲁证期货',
    },
    '80005750': {
        'account': '80005750',
        'currency': 'RMB',
        'account_name': '经典CTA-15',
        'broker': '华泰期货',
    },
    '120302736': {
        'account': '120302736',
        'currency': 'RMB',
        'account_name': '招享量化CTA1号',
        'broker': '中信期货',
    },
    '27800685': {
        'account': '27800685',
        'currency': 'RMB',
        'account_name': '招享混合策略1号',
        'broker': '鲁证期货',
    },
}

factor_pool = [
    211919,
    211930,
    211934,
    211935,
    211936,
    211937,
    211938,
    211939,
]

t0_vs_ids_version_01 = (
    1483,
    1487,
    1490,
    1491,
    1530,
    1570,
    1576,
    1651,
    1656,
    1661,
    1682
)

if __name__ == '__main__':
    pass

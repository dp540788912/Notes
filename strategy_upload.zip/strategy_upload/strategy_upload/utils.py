# -*-coding:utf-8-*-

import time
import redis
import json
import simplejson
import base64
import smtplib
import requests
import decimal
import numpy
import datetime
import os
from email.header import Header
from email.mime.text import MIMEText
from email.utils import parseaddr, formataddr
from config import config
from consts import *
from constant import CompanyWeChatAccount

websocket_rds = None
session_rds = None
cache_rds = None
redis_pool = None


class MyEncoder(simplejson.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, numpy.integer):
            return int(obj)
        elif isinstance(obj, numpy.int64):
            return int(obj)
        elif isinstance(obj, numpy.floating):
            return round(float(obj), 5)
        elif isinstance(obj, float):
            return round(float(obj), 5)
        elif isinstance(obj, numpy.ndarray):
            return obj.tolist()
        elif isinstance(obj, decimal.Decimal):
            return round(float(obj), 5)
        elif isinstance(obj, datetime.datetime):
            return obj.strftime('%Y%m%d %X.%f')
        elif isinstance(obj, datetime.date):
            return obj.strftime('%Y%m%d')
        else:
            return super(MyEncoder, self).default(obj)

    '''
    def iterencode(self, obj, _one_shot=False):
        if isinstance(obj, float):
            if obj != obj or obj == float("inf") or obj == -float("inf"):
                if obj != obj:
                    text = 'NaN'
                elif obj == float('inf'):
                    text = 'Infinity'
                elif obj == -float('inf'):
                    text = '-Infinity'

                if self.ignore_nan:
                    text = 'null'
                elif not self.allow_nan:
                    raise ValueError("Out of range float values are not JSON compliant: " + repr(obj))
                yield text
            else:
                if type(obj) != float:
                    obj = float(obj)
                yield repr(round(obj, 5))
        elif isinstance(obj, dict):
            last_index = len(obj) - 1
            yield '{'
            i = 0
            for key, value in obj.items():
                yield '"' + key + '": '
                if key == 912:
                    print(value, type(value))
                for chunk in MyEncoder.iterencode(self, value, _one_shot):
                    yield chunk
                if i != last_index:
                    yield ", "
                i += 1
            yield '}'
        elif isinstance(obj, list):
            last_index = len(obj) - 1
            yield "["
            for i, o in enumerate(obj):
                for chunk in MyEncoder.iterencode(self, o, _one_shot):
                    yield chunk
                if i != last_index:
                    yield ", "
            yield "]"
        else:
            for chunk in simplejson.JSONEncoder.iterencode(self, obj, _one_shot):
                yield chunk
    '''


def send_websocket(msg_type, msg_data, user_id=None, socket_id=None):
    """
    data = {
        'msg_type': '1111',
        'msg_data': '22222',
        'user_id': 2,
    }
    """
    data = {
        'msg_type': msg_type,
        'msg_data': msg_data,
        'user_id': user_id,
        'socket_id': socket_id,
    }
    global websocket_rds
    if not websocket_rds:
        websocket_rds = redis.Redis(host=config.websocket_redis_queue['host'],
                                    port=config.websocket_redis_queue['port'])
    return websocket_rds.publish("websocketmessage", json.dumps(data))


def get_type_agent(agent_type):
    global websocket_rds
    if not websocket_rds:
        websocket_rds = redis.Redis(host=config.websocket_redis_queue['host'],
                                    port=config.websocket_redis_queue['port'])
    agents = []
    for _, v in websocket_rds.hgetall(WEB_SOCK_CONN).items():
        a = json.loads(str(v, 'utf-8'))
        if (a['msg_type'] == agent_type) or (agent_type == 'all'):
            agents.append(a)
    return agents


def check_session(session_id):
    global session_rds
    if not session_rds:
        session_rds = redis.Redis(config.session_cache['host'], config.session_cache['port'])
    s = session_rds.get('session:%s' % session_id)
    if s:
        # TODO: store session with a more efficient data type(pickle?).
        data = json.loads(str(base64.b64decode(s), 'utf-8').split(':', 1)[-1])
        if '_auth_user_id' in data:
            res = {
                'id': int(data['_auth_user_id']),
                'username': data.get('_auth_user_name', ''),
                'nickname': data.get('_auth_user_nickname', ''),
                'type': data.get('type', ''),
                'company_id': data.get('company_id', ''),
            }

            res['is_superuser'] = res['username'] == 'root'
            return res
    return {}


def format_date(date, split='.', origin_split=None):
    _f = split.join(['%Y', '%m', '%d'])
    if origin_split is not None:
        return time.strftime(_f, time.strptime(date, origin_split.join(['%Y', '%m', '%d'])))
    for f in ['%Y%m%d', '%Y-%m-%d', '%Y.%m.%d']:
        try:
            return time.strftime(_f, time.strptime(date, f))
        except Exception as e:
            continue
    raise ValueError('data error: %s' % date)


def get_shortname_by_longname(p):
    return PRODUCTSLONG2SHORT[p]


def get_longname_by_shortname(p):
    return PRODUCTSSHORT2LONG[p]


def get_exchange_by_shortname(p):
    return SHORTPRODUCTS2EXCHANGE[p]


def get_exchange_by_longname(p):
    return LONGPRODUCT2EXCHANGE[p]


def get_exchange_short_name(e):
    return EXCHANGESHORTNAME[e]


def get_mitype(e):
    return MI_TYPE[e]


def format_addr(address):
    name, addr = parseaddr(address)
    return formataddr((Header(name, 'utf-8').encode(), addr))


def send_email(title, content, to_addrs, content_type='plain'):
    if not isinstance(to_addrs, list):
        to_addrs = [to_addrs]
    msg = MIMEText(content, content_type, "utf-8")
    msg["From"] = format_addr("<%s>" % config.FROM_ADDR)
    msg["To"] = ','.join([format_addr("<%s>" % _a) for _a in to_addrs])
    msg["Subject"] = Header(title, "utf-8").encode()
    server = smtplib.SMTP(config.SMTP_SERVER, config.SMTP_SERVER_PORT)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login(config.FROM_ADDR, config.PASSWORD)
    server.sendmail(config.FROM_ADDR, to_addrs, msg.as_string())
    server.quit()
    return True


def send_wx(agentid, secret, content, wx_list):
    payload = {
        'touser': '|'.join(wx_list),
        'msg': content,
        'agentid': agentid,
        'secret': secret,
    }
    headers = {
        'content-type': 'application/json',
        'whitelist': 'operater',
    }

    try:
        r = requests.post(config.wx_url, data=json.dumps(payload), headers=headers)
    except Exception as e:
        return -1, str(e)

    rsp = r.json()
    if rsp['code'] == 0:
        return 0, "success"
    else:
        return rsp['code'], rsp['msg']


def set_cache(key, data, expire_seconds):
    global cache_rds
    if not cache_rds:
        cache_rds = redis.Redis(
            host=config.data_cache['host'],
            port=config.data_cache['port'],
            db=config.data_cache['db']
        )
    if not expire_seconds:
        return cache_rds.set(key, simplejson.dumps(data, cls=MyEncoder, ignore_nan=True))
    return cache_rds.setex(name=key, value=simplejson.dumps(data, cls=MyEncoder, ignore_nan=True),
                           time=int(expire_seconds))


def get_cache(key):
    global cache_rds
    if not cache_rds:
        cache_rds = redis.Redis(
            host=config.data_cache['host'],
            port=config.data_cache['port'],
            db=config.data_cache['db']
        )
    data = cache_rds.get(key)
    return data and simplejson.loads(str(data, 'utf-8'))


def set_str_cache(key, data, expire_seconds):
    global cache_rds
    if not cache_rds:
        cache_rds = redis.Redis(
            host=config.data_cache['host'],
            port=config.data_cache['port'],
            db=config.data_cache['db']
        )
    if not expire_seconds:
        return cache_rds.set(key, data)
    return cache_rds.setex(name=key, value=data, time=int(expire_seconds))


def get_str_cache(key):
    global cache_rds
    if not cache_rds:
        cache_rds = redis.Redis(
            host=config.data_cache['host'],
            port=config.data_cache['port'],
            db=config.data_cache['db']
        )
    data = cache_rds.get(key)
    return data and str(data, 'utf-8')


def get_hash_cache(key, field, json_load=True):
    """
    same as redis command HGET and HGETALL.
    response will be decode to json default
    :param key, key in redis
    :param field, key in hash map, if it's None, return all
    :param json_load, return dict format
    """
    global redis_pool
    redis_pool = redis.ConnectionPool(host=config.redis['host'], port=config.redis['port'],
                                      db=config.redis['db'], decode_responses=True)
    cache_redis = redis.Redis(connection_pool=redis_pool, decode_responses=json_load)
    if field is None:
        return cache_redis.hgetall(key)
    data = cache_redis.hget(key, field)
    if isinstance(data, str):
        if json_load:
            try:
                return json.loads(data)
            except json.JSONDecodeError:
                pass
    return data


def ttl_cache(key):
    global cache_rds
    if not cache_rds:
        cache_rds = redis.Redis(
            host=config.data_cache['host'],
            port=config.data_cache['port'],
            db=config.data_cache['db']
        )
    return cache_rds.ttl(key)


def del_cache(key):
    global cache_rds
    if not cache_rds:
        cache_rds = redis.Redis(
            host=config.data_cache['host'],
            port=config.data_cache['port'],
            db=config.data_cache['db']
        )
    return cache_rds.delete(key)


def del_map_cache(namespace, key):
    global cache_rds
    if not cache_rds:
        cache_rds = redis.Redis(
            host=config.data_cache['host'],
            port=config.data_cache['port'],
            db=config.data_cache['db']
        )
    return cache_rds.hdel(namespace, key)


def get_stock_detail():
    cache_key = 'analysis_service_stock_detail'
    stock_detail = get_cache(cache_key)
    if stock_detail:
        return stock_detail

    stock_detail = {}
    try:
        data = requests.get('http://127.0.0.1/analysis-service/v1/ticker?exch=SSE').json()['data']
        for stock in data:
            stock_detail[stock['symbol']] = stock['exch']
        data = requests.get('http://127.0.0.1/analysis-service/v1/ticker?exch=SZSE').json()['data']
        for stock in data:
            stock_detail[stock['symbol']] = stock['exch']
        data = requests.get('http://127.0.0.1/analysis-service/v1/ticker?etf=ALL').json()['data']
        for stock in data:
            stock_detail[stock['symbol']] = stock['exch']
    except Exception as e:
        stock_detail = {}

    if stock_detail:
        set_cache(cache_key, stock_detail, 28800)
    return stock_detail


def get_all_products_unit():
    cache_key = 'platform_all_products_unit'
    product_unit = get_cache(cache_key)
    if product_unit:
        return product_unit
    from kdb_query import KdbQuery
    kdb = KdbQuery()
    product_unit = kdb.get_all_products_unit()
    if product_unit:
        set_cache(cache_key, product_unit, 86400)
    return product_unit


# def max_drawdown_rate(timeseries):
#     timeseries2 = [float(i) for i in timeseries]
#     accumulate_max = numpy.maximum.accumulate(timeseries2)
#     accumulate_max_div = [d if d != 0 else float('inf') for d in accumulate_max]
#     return numpy.nanmax((accumulate_max - timeseries2) / accumulate_max_div)


# def notify_wechat(recipients, message):
#     agentid = 1000003
#     secret = 'EIXZMCl-lX4jsyJRTjfYOmQksySB3UeZkJiczOh5Ulo'
#     corpid = 'ww7c9916c2f31d5aa4'
#     token_url = 'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=%s&corpsecret=%s' % (corpid, secret)
#     msg_url = 'https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=%s'
#     try:
#         response = requests.get(token_url)
#         if response.status_code == 200:
#             token = response.json()['access_token']
#             msg_url = msg_url % token
#             payload = {
#                 "touser": "|".join(recipients),
#                 "toparty": "",
#                 "msgtype": "text",
#                 "agentid": agentid,
#                 "text": {
#                     "content": message
#                 },
#                 "safe": "0"
#             }
#             response = requests.post(msg_url, json=payload)
#             json_data = response.json()
#             if json_data['errcode'] == 0:
#                 return True
#             raise RuntimeError("发送微信失败: %s" % json_data['errmsg'])
#         else:
#             raise RuntimeError("无法连接微信服务器")
#     except Exception as e:
#         return False


def notify_operation_wechat(message):
    from cron.strategy_upload_task import company_platform_wechat_app_send_text_task
    company_platform_wechat_app_send_text_task.delay(message)
    # account_list = CompanyWeChatAccount.quant_ops + CompanyWeChatAccount.quant_dev
    # return notify_wechat(account_list, message)


def symlink_insurance(src, target):
    """
    The same behavior as bash `ln -sf src target`
    """
    symlink_state = os.path.islink(target) and os.readlink(target) == src
    if not symlink_state:
        # TODO: Add a sentry exception catch up.
        if os.path.exists(target):
            os.remove(target)
        os.symlink(src, target)


if __name__ == '__main__':
    pass

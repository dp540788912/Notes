import sys
import os
import datetime
import queue
import copy
from pprint import pprint
from contextlib import contextmanager

import redis
from sqlalchemy.sql import func
from sqlalchemy import distinct, Column
from sqlalchemy.dialects.mysql import INTEGER

from service.back_test.models import Strategy, VStrategies, VStrategyAccountDetail, StrategyResult, StrategyPortfolio
from new_settlement.new_settlement.models import VsBase
from db import session_context, ModelBase
from constant import StrategyConstant

DATE_FORMAT1 = '%Y%m%d'


class Test(ModelBase):
    __tablename__ = 'test'
    id = Column(INTEGER, primary_key=True, autoincrement=True)
    v1 = Column(INTEGER)
    v2 = Column(INTEGER)


def import_project_path():
    strategy_path = os.path.dirname(os.path.realpath(__file__))
    strategy_src_path = os.path.join(strategy_path, 'strategy_upload')
    if strategy_src_path not in sys.path:
        sys.path.append(strategy_src_path)


def review_vs(vs_id):
    with session_context() as sc:
        vs = sc.query(VStrategies).filter(VStrategies.id == vs_id).first()
        if vs is not None:
            print("symbols_accounts:")
            for acc in vs.symbols_accounts:
                pprint(acc)


def review_strategy(s_id):
    with session_context() as sc:
        s = sc.query(Strategy).filter(Strategy.id == s_id).first()
        if s is not None:
            # print("detail:")
            # pprint(s.detail)
            print("strategy_type:", s.strategy_type)


def review_vs_base(vs_id):
    with session_context() as sc:
        records = sc.query(VsBase).filter(VsBase.vstrategy_id == vs_id).order_by(VsBase.settle_date.desc(),
                                                                                 VsBase.daynight.asc()).limit(4)
        for r in records:
            print(r.vstrategy_id, r.settle_date, r.daynight, r.position_cash)


def review_strategy_result():
    # with session_context() as sc:
    #     records = sc.query(StrategyResult.strategy_id, func.max(StrategyResult.date)).filter(
    #         StrategyResult.status == 0,
    #         StrategyResult.config_id == 0).group_by(
    #         StrategyResult.strategy_id)
    #     for r in records:
    #         print(r[0], r[1])
    pass


def get_stock_running_vs_ids():
    with session_context() as sc:
        records = sc.query(distinct(VStrategies.id)).join(
            Strategy, Strategy.id == VStrategies.strategy_id).join(
            StrategyPortfolio, StrategyPortfolio.id == VStrategies.portfolio_id).filter(
            VStrategies.status == 15,
            Strategy.strategy_type.in_(['15', '18']),
            StrategyPortfolio.business == "stock").all()
        return [r[0] for r in records]


def get_auto_daily_task_s_ids():
    today = datetime.datetime.today().strftime(DATE_FORMAT1)
    with session_context() as sc:
        records = sc.query(Strategy).filter(Strategy.is_delete == 0, Strategy.is_test == 0, Strategy.end_date >= today,
                                            Strategy.status == StrategyConstant.Status.FINISHED.value).order_by(
            Strategy.id.desc()).all()
        s_ids = [r.id for r in records]
        return s_ids


def context_manager_test():
    @contextmanager
    def test_context():
        value = 1
        try:
            yield value
            raise ValueError(value)
        except Exception:
            raise
        finally:
            print(value)

    with test_context() as tc:
        c = tc
        print(c + 1)

    print("not here")


def redis_test():
    redis_config = {
        'host': '192.168.1.14',
        'port': 6379,
        'db': 15
    }
    redis_client = redis.Redis(**redis_config)
    test_id = 1
    key = 'test_{}'.format(test_id)
    exists = redis_client.exists(key)
    print(type(exists), exists)
    redis_client.set(key, test_id)
    exists = redis_client.exists(key)
    print(type(exists), exists)
    redis_client.delete(key)
    exists = redis_client.exists(key)
    print(type(exists), exists)

    for num in range(100000, 100010):
        key = 'test_{}'.format(num)
        redis_client.set(key, num)
        res = redis_client.get(key)
        print(type(res), res, int(res) == num)

    not_exists = redis_client.get('test_{}'.format(10))
    print(type(not_exists), not_exists)

    res_list = redis_client.keys('test_*')
    print(type(res_list), res_list)
    res_list = [int(k.decode('utf-8').split('_')[-1]) for k in res_list]
    print(res_list)
    print([type(ele) for ele in res_list])
    redis_client.delete(*res_list)


def mysql_test():
    with session_context() as sc:
        record = sc.query(Test).filter(Test.v1 == 1, Test.v2 == 3).first()
        if record is None:
            record = Test(v1=1)
            sc.add(record)
        record.v2 = 4


class DependenceGraph(object):
    def __init__(self, graph=None):
        self.graph = graph if graph else dict()
        self.full_graph = dict()
        self.calculate_full_dependence()

    def set_default(self, ele):
        self.graph.setdefault(ele, set())

    def add_dependence(self, ele, dep_list):
        self.set_default(ele)
        self.graph[ele].update(set(dep_list))

    def remove_dependence(self, ele, dep_list):
        self.set_default(ele)
        self.graph[ele].difference_update(set(dep_list))

    def get_direct_dependence(self, ele):
        return self.graph.get(ele, set())

    def get_full_dependence(self, ele):
        search_queue = queue.Queue()
        search_queue.put(ele)
        all_deps = set()
        while not search_queue.empty():
            current_ele = search_queue.get()
            if current_ele is None:
                break
            deps = self.get_direct_dependence(current_ele)
            for dep in deps:
                if dep not in all_deps:
                    search_queue.put(dep)
                    all_deps.add(dep)
        return all_deps

    def show(self):
        pprint(self.graph)

    def calculate_full_dependence(self):
        for ele in self.graph.keys():
            self.full_graph[ele] = self.get_full_dependence(ele)

    def show_full(self):
        pprint(self.full_graph)


def dependence_graph_test():
    init_graph = {1: {2, 3}, 4: {3, 5}, 6: {5, 7}, 7: {2}}
    dep_graph = DependenceGraph(graph=init_graph)
    current_full_graph = copy.deepcopy(dep_graph.full_graph)
    del current_full_graph[6]
    del current_full_graph[7]
    end_full_graph = copy.deepcopy(dep_graph.full_graph)
    del end_full_graph[1]
    current_state = set()
    for k, v in current_full_graph.items():
        current_state.add(k)
        current_state.update(v)
    end_state = set()
    for k, v in end_full_graph.items():
        end_state.add(k)
        end_state.update(v)
    print('down:', current_state.difference(end_state))
    print('up:', end_state.difference(current_state))


if __name__ == '__main__':
    # import_project_path()
    # review_vs(vs_id=2123)
    # review_strategy(s_id=216343)
    # review_vs_base(vs_id=2123)
    # review_strategy_result()
    # print(len(get_auto_daily_task_s_ids()))
    # context_manager_test()
    # redis_test()
    # mysql_test()

    pass
